; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
define dso_local void @compiler_2fmir_2eFn_2edefer(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Fn"
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca %"compiler/mir:Local"
  %l23 = alloca i32
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/mir:Lvalue"
  %l34 = alloca { i64, [21 x i64] }
  %l40 = alloca { i64, [21 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca { i64, [21 x i64] }
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/mir:Lvalue"
  %l64 = alloca { i64, [21 x i64] }
  %l70 = alloca { i64, [21 x i64] }
  %l72 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/mir:Lvalue"
  %l80 = alloca { i64, [21 x i64] }
  %l85 = alloca { i64, [21 x i64] }
  %l92 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t11 = alloca %"compiler/mir:Fn", align 8
  %t31 = alloca { i64, [1 x i64] }, align 8
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t62 = alloca { i64, [15 x i64] }, align 8
  %t68 = alloca { i64, [21 x i64] }, align 8
  %t85 = alloca { i64, [21 x i64] }, align 8
  %t104 = alloca { i64, [4 x i64] }, align 8
  %t111 = alloca { i64, [15 x i64] }, align 8
  %t117 = alloca { i64, [21 x i64] }, align 8
  %t133 = alloca { i64, [8 x i64] }, align 8
  %t149 = alloca { i64, [4 x i64] }, align 8
  %t156 = alloca { i64, [15 x i64] }, align 8
  %t162 = alloca { i64, [21 x i64] }, align 8
  %t179 = alloca { i64, [21 x i64] }, align 8
  %t198 = alloca { i64, [4 x i64] }, align 8
  %t205 = alloca { i64, [15 x i64] }, align 8
  %t211 = alloca { i64, [21 x i64] }, align 8
  %t227 = alloca { i64, [21 x i64] }, align 8
  %t240 = alloca { i64, [4 x i64] }, align 8
  %t243 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t6, i32 0, i32 %t7, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2eFn_2etfn(ptr %t11, ptr %v0, ptr %v1, ptr %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t11, i64 808, i1 false)
  br label %bb3
bb3:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t14, ptr %lp2
  %t15 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %l12, i64 808, i1 false)
  %t16 = load ptr, ptr %lp2
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v2, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t26, ptr %s0, ptr %t27, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t28, ptr %l17
  br label %bb4
bb4:
  %t29 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t30 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 0
  store i64 3, ptr %t32
  %t33 = load { i64, [1 x i64] }, ptr %t31
  %t34 = load i32, ptr %l17, !tbaa !23
  %t39 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t34, %"compiler/source:Span" %t29, i32 %t30, i32 2, { i64, [1 x i64] } %t33)
  store %"compiler/mir:Local" %t39, ptr %l22
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load %"compiler/mir:Local", ptr %l22
  %t42 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t40, %"compiler/mir:Local" %t41)
  store i32 %t42, ptr %l23
  br label %bb6
bb6:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t44 = load ptr, ptr %lp2
  %t46 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t44)
  store i32 %t46, ptr %l25
  br label %bb7
bb7:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %lp2
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  store i32 %t49, ptr %l27, !tbaa !23
  %t50 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t50, ptr %l28
  %t51 = load i32, ptr %l3, !tbaa !23
  %t53 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t51)
  store %"compiler/mir:Lvalue" %t53, ptr %l30
  br label %bb8
bb8:
  %t54 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { i32, i64 } undef, i32 %t54, 0
  %t59 = insertvalue { i32, i64 } %t58, i64 1, 1
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { i32, i64 } %t59, ptr %t60
  %t61 = load { i64, [4 x i64] }, ptr %t55
  store { i64, [15 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t65 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t61, 0
  %t66 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 1
  store { { i64, [4 x i64] } } %t65, ptr %t66
  %t67 = load { i64, [15 x i64] }, ptr %t62
  store { i64, [21 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t70 = load %"compiler/source:Span", ptr %l28
  %t71 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t70, 0
  %t72 = load %"compiler/mir:Lvalue", ptr %l30
  %t73 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t71, %"compiler/mir:Lvalue" %t72, 1
  %t75 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t73, { i64, [15 x i64] } %t67, 2
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t75, ptr %t76
  %t77 = load { i64, [21 x i64] }, ptr %t68
  store { i64, [21 x i64] } %t77, ptr %l34
  %t78 = load ptr, ptr %l26, !tbaa !29
  %t79 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t78, i32 %t79, ptr %l34)
  br label %bb9
bb9:
  %t81 = load ptr, ptr %lp2
  %t82 = load i32, ptr %l4, !tbaa !23
  %t83 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t84 = load i32, ptr %l5, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 0
  store i64 19, ptr %t86
  %t88 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t83, 0
  %t89 = insertvalue { %"compiler/source:Span", i32, i32 } %t88, i32 0, 1
  %t91 = insertvalue { %"compiler/source:Span", i32, i32 } %t89, i32 %t84, 2
  %t92 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t91, ptr %t92
  %t93 = load { i64, [21 x i64] }, ptr %t85
  store { i64, [21 x i64] } %t93, ptr %l40
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t81, i32 %t82, ptr %l40)
  br label %bb10
bb10:
  %t97 = load ptr, ptr %lp2
  store ptr %t97, ptr %l42, !tbaa !29
  %t98 = load i32, ptr %l5, !tbaa !23
  store i32 %t98, ptr %l43, !tbaa !23
  %t99 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t99, ptr %l44
  %t100 = load i32, ptr %l3, !tbaa !23
  %t102 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t100)
  store %"compiler/mir:Lvalue" %t102, ptr %l46
  br label %bb11
bb11:
  %t103 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 0
  store i64 2, ptr %t105
  %t107 = insertvalue { i32, i64 } undef, i32 %t103, 0
  %t108 = insertvalue { i32, i64 } %t107, i64 2, 1
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  store { i32, i64 } %t108, ptr %t109
  %t110 = load { i64, [4 x i64] }, ptr %t104
  store { i64, [15 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t111, i32 0, i32 0
  store i64 0, ptr %t112
  %t114 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t110, 0
  %t115 = getelementptr { i64, [15 x i64] }, ptr %t111, i32 0, i32 1
  store { { i64, [4 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [15 x i64] }, ptr %t111
  store { i64, [21 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [21 x i64] }, ptr %t117, i32 0, i32 0
  store i64 0, ptr %t118
  %t119 = load %"compiler/source:Span", ptr %l44
  %t120 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t119, 0
  %t121 = load %"compiler/mir:Lvalue", ptr %l46
  %t122 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t120, %"compiler/mir:Lvalue" %t121, 1
  %t124 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t122, { i64, [15 x i64] } %t116, 2
  %t125 = getelementptr { i64, [21 x i64] }, ptr %t117, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t124, ptr %t125
  %t126 = load { i64, [21 x i64] }, ptr %t117
  store { i64, [21 x i64] } %t126, ptr %l50
  %t127 = load ptr, ptr %l42, !tbaa !29
  %t128 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t127, i32 %t128, ptr %l50)
  br label %bb12
bb12:
  %t130 = load ptr, ptr %lp2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t132 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [8 x i64] }, ptr %t133, i32 0, i32 0
  store i64 10, ptr %t134
  %t136 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t132, 0
  %t137 = getelementptr { i64, [8 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span" } %t136, ptr %t137
  %t138 = load { i64, [8 x i64] }, ptr %t133
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t130, i32 %t131, { i64, [8 x i64] } %t138)
  br label %bb13
bb13:
  %t142 = load ptr, ptr %lp2
  store ptr %t142, ptr %l56, !tbaa !29
  %t143 = load i32, ptr %l4, !tbaa !23
  store i32 %t143, ptr %l57, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t144, ptr %l58
  %t145 = load i32, ptr %l3, !tbaa !23
  %t147 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t145)
  store %"compiler/mir:Lvalue" %t147, ptr %l60
  br label %bb14
bb14:
  %t148 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 0
  store i64 2, ptr %t150
  %t152 = insertvalue { i32, i64 } undef, i32 %t148, 0
  %t153 = insertvalue { i32, i64 } %t152, i64 3, 1
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  store { i32, i64 } %t153, ptr %t154
  %t155 = load { i64, [4 x i64] }, ptr %t149
  store { i64, [15 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [15 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t159 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t155, 0
  %t160 = getelementptr { i64, [15 x i64] }, ptr %t156, i32 0, i32 1
  store { { i64, [4 x i64] } } %t159, ptr %t160
  %t161 = load { i64, [15 x i64] }, ptr %t156
  store { i64, [21 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [21 x i64] }, ptr %t162, i32 0, i32 0
  store i64 0, ptr %t163
  %t164 = load %"compiler/source:Span", ptr %l58
  %t165 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t164, 0
  %t166 = load %"compiler/mir:Lvalue", ptr %l60
  %t167 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t165, %"compiler/mir:Lvalue" %t166, 1
  %t169 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t167, { i64, [15 x i64] } %t161, 2
  %t170 = getelementptr { i64, [21 x i64] }, ptr %t162, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [21 x i64] }, ptr %t162
  store { i64, [21 x i64] } %t171, ptr %l64
  %t172 = load ptr, ptr %l56, !tbaa !29
  %t173 = load i32, ptr %l57, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t172, i32 %t173, ptr %l64)
  br label %bb15
bb15:
  %t175 = load ptr, ptr %lp2
  %t176 = load i32, ptr %l4, !tbaa !23
  %t177 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t178 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 0
  store i64 19, ptr %t180
  %t182 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t177, 0
  %t183 = insertvalue { %"compiler/source:Span", i32, i32 } %t182, i32 0, 1
  %t185 = insertvalue { %"compiler/source:Span", i32, i32 } %t183, i32 %t178, 2
  %t186 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t185, ptr %t186
  %t187 = load { i64, [21 x i64] }, ptr %t179
  store { i64, [21 x i64] } %t187, ptr %l70
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t175, i32 %t176, ptr %l70)
  br label %bb16
bb16:
  %t191 = load ptr, ptr %lp2
  store ptr %t191, ptr %l72, !tbaa !29
  %t192 = load i32, ptr %l4, !tbaa !23
  store i32 %t192, ptr %l73, !tbaa !23
  %t193 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t193, ptr %l74
  %t194 = load i32, ptr %l3, !tbaa !23
  %t196 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t194)
  store %"compiler/mir:Lvalue" %t196, ptr %l76
  br label %bb17
bb17:
  %t197 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 0
  store i64 2, ptr %t199
  %t201 = insertvalue { i32, i64 } undef, i32 %t197, 0
  %t202 = insertvalue { i32, i64 } %t201, i64 2, 1
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  store { i32, i64 } %t202, ptr %t203
  %t204 = load { i64, [4 x i64] }, ptr %t198
  store { i64, [15 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [15 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t208 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t204, 0
  %t209 = getelementptr { i64, [15 x i64] }, ptr %t205, i32 0, i32 1
  store { { i64, [4 x i64] } } %t208, ptr %t209
  %t210 = load { i64, [15 x i64] }, ptr %t205
  store { i64, [21 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [21 x i64] }, ptr %t211, i32 0, i32 0
  store i64 0, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l74
  %t214 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t213, 0
  %t215 = load %"compiler/mir:Lvalue", ptr %l76
  %t216 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t214, %"compiler/mir:Lvalue" %t215, 1
  %t218 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t216, { i64, [15 x i64] } %t210, 2
  %t219 = getelementptr { i64, [21 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t218, ptr %t219
  %t220 = load { i64, [21 x i64] }, ptr %t211
  store { i64, [21 x i64] } %t220, ptr %l80
  %t221 = load ptr, ptr %l72, !tbaa !29
  %t222 = load i32, ptr %l73, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t221, i32 %t222, ptr %l80)
  br label %bb18
bb18:
  %t224 = load ptr, ptr %lp2
  %t225 = load i32, ptr %l4, !tbaa !23
  %t226 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 0
  store i64 4, ptr %t228
  %t230 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t226, 0
  %t231 = insertvalue { %"compiler/source:Span", i32 } %t230, i32 0, 1
  %t232 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t231, ptr %t232
  %t233 = load { i64, [21 x i64] }, ptr %t227
  store { i64, [21 x i64] } %t233, ptr %l85
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t224, i32 %t225, ptr %l85)
  br label %bb19
bb19:
  %t237 = load ptr, ptr %lp2
  %t238 = load i32, ptr %l4, !tbaa !23
  %t239 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [4 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 0
  store i64 0, ptr %t241
  %t242 = load { i64, [4 x i64] }, ptr %t240
  store { i64, [8 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 0
  store i64 5, ptr %t244
  %t246 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t239, 0
  %t248 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t246, { i64, [4 x i64] } %t242, 1
  %t249 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t248, ptr %t249
  %t250 = load { i64, [8 x i64] }, ptr %t243
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t237, i32 %t238, { i64, [8 x i64] } %t250)
  br label %bb20
bb20:
  %t254 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %t254, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l92, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eFn_2eloop(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca %"compiler/mir:Fn"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l43 = alloca i32
  %l48 = alloca %"compiler/mir:Local"
  %l49 = alloca i32
  %l53 = alloca i32
  %l57 = alloca i32
  %l61 = alloca i32
  %l65 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i32
  %l77 = alloca i32
  %l79 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l83 = alloca %"compiler/mir:Lvalue"
  %l87 = alloca { i64, [21 x i64] }
  %l92 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/mir:Lvalue"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca ptr
  %l101 = alloca %"compiler/mir:Lvalue"
  %l102 = alloca { i64, [4 x i64] }
  %l104 = alloca %"compiler/mir:Lvalue"
  %l106 = alloca { i64, ptr }
  %l107 = alloca %"compiler/mir:Range"
  %l109 = alloca { i64, [21 x i64] }
  %l111 = alloca ptr
  %l112 = alloca i32
  %l114 = alloca %"compiler/mir:Lvalue"
  %l123 = alloca { i64, [21 x i64] }
  %l125 = alloca ptr
  %l128 = alloca { i64, [7 x i64] }
  %l129 = alloca ptr
  %l131 = alloca %"compiler/mir:Lvalue"
  %l133 = alloca { i64, ptr }
  %l134 = alloca %"compiler/mir:Range"
  %l135 = alloca %"compiler/mir:Range"
  %l137 = alloca %"compiler/mir:Lvalue"
  %l141 = alloca %"compiler/mir:Call"
  %l142 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca i32
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca %"compiler/mir:Lvalue"
  %l153 = alloca i32
  %l154 = alloca i32
  %l155 = alloca ptr
  %l157 = alloca %"compiler/mir:Lvalue"
  %l161 = alloca { i64, ptr }
  %l162 = alloca %"compiler/mir:Range"
  %l164 = alloca { i64, [21 x i64] }
  %l170 = alloca { i64, [21 x i64] }
  %l179 = alloca { i64, [21 x i64] }
  %l181 = alloca ptr
  %l182 = alloca i32
  %l183 = alloca %"compiler/source:Span"
  %l185 = alloca %"compiler/mir:Lvalue"
  %l188 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca %"compiler/source:Span"
  %l192 = alloca %"compiler/mir:Lvalue"
  %l194 = alloca %"compiler/mir:Lvalue"
  %l199 = alloca { i64, [21 x i64] }
  %l205 = alloca { i64, [21 x i64] }
  %l210 = alloca { i64, [21 x i64] }
  %l212 = alloca ptr
  %l213 = alloca i32
  %l214 = alloca %"compiler/source:Span"
  %l216 = alloca %"compiler/mir:Lvalue"
  %l219 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t25 = alloca %"compiler/mir:Fn", align 8
  %t59 = alloca { i64, [1 x i64] }, align 8
  %t137 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [15 x i64] }, align 8
  %t150 = alloca { i64, [21 x i64] }, align 8
  %t164 = alloca { i64, [8 x i64] }, align 8
  %t183 = alloca { i64, [4 x i64] }, align 8
  %t192 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [15 x i64] }, align 8
  %t223 = alloca { i64, [21 x i64] }, align 8
  %t241 = alloca { i64, [4 x i64] }, align 8
  %t249 = alloca { i64, [8 x i64] }, align 8
  %t266 = alloca { i64, [21 x i64] }, align 8
  %t278 = alloca { i64, [2 x i64] }, align 8
  %t284 = alloca { i64, [7 x i64] }, align 8
  %t296 = alloca { i64, [4 x i64] }, align 8
  %t336 = alloca { i64, [8 x i64] }, align 8
  %t358 = alloca { i64, [4 x i64] }, align 8
  %t365 = alloca { i64, [4 x i64] }, align 8
  %t387 = alloca { i64, [15 x i64] }, align 8
  %t397 = alloca { i64, [21 x i64] }, align 8
  %t414 = alloca { i64, [21 x i64] }, align 8
  %t428 = alloca { i64, [8 x i64] }, align 8
  %t440 = alloca { i64, [21 x i64] }, align 8
  %t456 = alloca { i64, [4 x i64] }, align 8
  %t462 = alloca { i64, [8 x i64] }, align 8
  %t482 = alloca { i64, [4 x i64] }, align 8
  %t490 = alloca { i64, [15 x i64] }, align 8
  %t500 = alloca { i64, [21 x i64] }, align 8
  %t517 = alloca { i64, [21 x i64] }, align 8
  %t531 = alloca { i64, [21 x i64] }, align 8
  %t547 = alloca { i64, [4 x i64] }, align 8
  %t553 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load i32, ptr %l19, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i32, ptr %l22, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l23, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l24, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l27
  br label %bb3
bb3:
  %t18 = load i32, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t20, i32 %t21, i32 %t18, i32 %t19, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t24, ptr %l30
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2eFn_2etfn(ptr %t25, ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t25, i64 808, i1 false)
  br label %bb5
bb5:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t28, ptr %lp3
  %t29 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l31, i64 808, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l35
  br label %bb6
bb6:
  %t36 = load i32, ptr %l1, !tbaa !23
  %t37 = load i32, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l32, !tbaa !29
  %t39 = load i32, ptr %l35, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t38, i32 %t39, i32 %t36, i32 %t37, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t42, ptr %l38
  br label %bb7
bb7:
  %t43 = load i32, ptr %l38, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  store i32 0, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp3
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = call ptr @__olang_scope_or(ptr %v2, ptr %t49)
  %t51 = call ptr @__olang_scope_hold(ptr %t50)
  %t52 = ptrtoint ptr %t51 to i64
  %t54 = inttoptr i64 %t52 to ptr
  %t55 = load ptr, ptr %l41, !tbaa !29
  %t56 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t54, ptr %s0, ptr %t55, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t56, ptr %l43
  br label %bb8
bb8:
  %t57 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t58 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [1 x i64] }, ptr %t59, i32 0, i32 0
  store i64 3, ptr %t60
  %t61 = load { i64, [1 x i64] }, ptr %t59
  %t62 = load i32, ptr %l43, !tbaa !23
  %t67 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t62, %"compiler/source:Span" %t57, i32 %t58, i32 2, { i64, [1 x i64] } %t61)
  store %"compiler/mir:Local" %t67, ptr %l48
  br label %bb9
bb9:
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t69 = load %"compiler/mir:Local", ptr %l48
  %t70 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t68, %"compiler/mir:Local" %t69)
  store i32 %t70, ptr %l49
  br label %bb10
bb10:
  %t71 = load i32, ptr %l49, !tbaa !23
  store i32 %t71, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %lp3
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t78 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t72, i32 %t73, %"compiler/source:Span" %t74)
  store i32 %t78, ptr %l53
  br label %bb11
bb11:
  %t79 = load i32, ptr %l53, !tbaa !23
  store i32 %t79, ptr %l7, !tbaa !23
  %t80 = load ptr, ptr %lp3
  %t81 = load i32, ptr %l1, !tbaa !23
  %t82 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t86 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t80, i32 %t81, %"compiler/source:Span" %t82)
  store i32 %t86, ptr %l57
  br label %bb12
bb12:
  %t87 = load i32, ptr %l57, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %lp3
  %t89 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t90 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t94 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t88, i32 %t89, %"compiler/source:Span" %t90)
  store i32 %t94, ptr %l61
  br label %bb13
bb13:
  %t95 = load i32, ptr %l61, !tbaa !23
  store i32 %t95, ptr %l9, !tbaa !23
  %t96 = load ptr, ptr %lp3
  %t97 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t98 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t96, i32 %t97, %"compiler/source:Span" %t98)
  store i32 %t102, ptr %l65
  br label %bb14
bb14:
  %t103 = load i32, ptr %l65, !tbaa !23
  store i32 %t103, ptr %l10, !tbaa !23
  %t104 = load ptr, ptr %lp3
  %t105 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t109 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t104, i32 2, i32 0, i32 1, %"compiler/source:Span" %t105, i32 0)
  store i32 %t109, ptr %l69
  br label %bb15
bb15:
  %t110 = load i32, ptr %l69, !tbaa !23
  store i32 %t110, ptr %l11, !tbaa !23
  %t111 = load ptr, ptr %lp3
  %t113 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t111)
  store i32 %t113, ptr %l71
  br label %bb16
bb16:
  %t114 = load i32, ptr %l71, !tbaa !23
  store i32 %t114, ptr %l12, !tbaa !23
  %t115 = load ptr, ptr %lp3
  %t117 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t115)
  store i32 %t117, ptr %l73
  br label %bb17
bb17:
  %t118 = load i32, ptr %l73, !tbaa !23
  store i32 %t118, ptr %l13, !tbaa !23
  %t119 = load ptr, ptr %lp3
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t119)
  store i32 %t121, ptr %l75
  br label %bb18
bb18:
  %t122 = load i32, ptr %l75, !tbaa !23
  store i32 %t122, ptr %l14, !tbaa !23
  %t123 = load ptr, ptr %lp3
  %t125 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l77
  br label %bb19
bb19:
  %t126 = load i32, ptr %l77, !tbaa !23
  store i32 %t126, ptr %l15, !tbaa !23
  %t127 = load ptr, ptr %lp3
  %t129 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t127)
  store i32 %t129, ptr %l79
  br label %bb20
bb20:
  %t130 = load i32, ptr %l79, !tbaa !23
  store i32 %t130, ptr %l16, !tbaa !23
  %t131 = load ptr, ptr %lp3
  store ptr %t131, ptr %l80, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t132, ptr %l81
  %t133 = load i32, ptr %l6, !tbaa !23
  %t135 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t133)
  store %"compiler/mir:Lvalue" %t135, ptr %l83
  br label %bb21
bb21:
  %t136 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 0
  store i64 2, ptr %t138
  %t140 = insertvalue { i32, i64 } undef, i32 %t136, 0
  %t141 = insertvalue { i32, i64 } %t140, i64 0, 1
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  store { i32, i64 } %t141, ptr %t142
  %t143 = load { i64, [4 x i64] }, ptr %t137
  store { i64, [15 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [15 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t147 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t143, 0
  %t148 = getelementptr { i64, [15 x i64] }, ptr %t144, i32 0, i32 1
  store { { i64, [4 x i64] } } %t147, ptr %t148
  %t149 = load { i64, [15 x i64] }, ptr %t144
  store { i64, [21 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [21 x i64] }, ptr %t150, i32 0, i32 0
  store i64 0, ptr %t151
  %t152 = load %"compiler/source:Span", ptr %l81
  %t153 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t152, 0
  %t154 = load %"compiler/mir:Lvalue", ptr %l83
  %t155 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t153, %"compiler/mir:Lvalue" %t154, 1
  %t157 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t155, { i64, [15 x i64] } %t149, 2
  %t158 = getelementptr { i64, [21 x i64] }, ptr %t150, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t157, ptr %t158
  %t159 = load { i64, [21 x i64] }, ptr %t150
  store { i64, [21 x i64] } %t159, ptr %l87
  %t160 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t160, i32 0, ptr %l87)
  br label %bb22
bb22:
  %t162 = load ptr, ptr %lp3
  %t163 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [8 x i64] }, ptr %t164, i32 0, i32 0
  store i64 1, ptr %t165
  %t167 = insertvalue { i32 } undef, i32 %t163, 0
  %t168 = getelementptr { i64, [8 x i64] }, ptr %t164, i32 0, i32 1
  store { i32 } %t167, ptr %t168
  %t169 = load { i64, [8 x i64] }, ptr %t164
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t162, i32 0, { i64, [8 x i64] } %t169)
  br label %bb23
bb23:
  %t172 = load ptr, ptr %lp3
  store ptr %t172, ptr %l92, !tbaa !29
  %t173 = load i32, ptr %l12, !tbaa !23
  store i32 %t173, ptr %l93, !tbaa !23
  %t174 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t174, ptr %l94
  %t175 = load i32, ptr %l7, !tbaa !23
  %t177 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t175)
  store %"compiler/mir:Lvalue" %t177, ptr %l96
  br label %bb24
bb24:
  store i32 15, ptr %l97
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t178, ptr %l98, !tbaa !23
  %t179 = load ptr, ptr %lp3
  store ptr %t179, ptr %l99, !tbaa !29
  %t180 = load i32, ptr %l6, !tbaa !23
  %t182 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t180)
  store %"compiler/mir:Lvalue" %t182, ptr %l101
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t183
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t183, i32 0, i32 0
  store i64 1, ptr %t184
  %t185 = load %"compiler/mir:Lvalue", ptr %l101
  %t186 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t185, 0
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t183, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t186, ptr %t187
  %t188 = load { i64, [4 x i64] }, ptr %t183
  store { i64, [4 x i64] } %t188, ptr %l102
  %t189 = load i32, ptr %l5, !tbaa !23
  %t191 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t189)
  store %"compiler/mir:Lvalue" %t191, ptr %l104
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 0
  store i64 1, ptr %t193
  %t194 = load %"compiler/mir:Lvalue", ptr %l104
  %t195 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t194, 0
  %t196 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t195, ptr %t196
  %t197 = load { i64, [4 x i64] }, ptr %t192
  %t198 = mul i64 2, 40
  %t199 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 2, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l106, !tbaa !27
  %t202 = load { i64, [4 x i64] }, ptr %l102
  %t203 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t204, i64 0
  store { i64, [4 x i64] } %t202, ptr %t205
  %t207 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i64 1
  store { i64, [4 x i64] } %t197, ptr %t209
  %t210 = load ptr, ptr %l99, !tbaa !29
  %t211 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t212 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t210, { i64, ptr } %t211)
  store %"compiler/mir:Range" %t212, ptr %l107
  br label %bb27
bb27:
  store { i64, [15 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [15 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load i32, ptr %l97, !range !{i32 0, i32 54}
  %t216 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t215, 0
  %t217 = load i32, ptr %l98, !tbaa !23
  %t218 = insertvalue { i32, i32, %"compiler/mir:Range" } %t216, i32 %t217, 1
  %t219 = load %"compiler/mir:Range", ptr %l107
  %t220 = insertvalue { i32, i32, %"compiler/mir:Range" } %t218, %"compiler/mir:Range" %t219, 2
  %t221 = getelementptr { i64, [15 x i64] }, ptr %t213, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t220, ptr %t221
  %t222 = load { i64, [15 x i64] }, ptr %t213
  store { i64, [21 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [21 x i64] }, ptr %t223, i32 0, i32 0
  store i64 0, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l94
  %t226 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t225, 0
  %t227 = load %"compiler/mir:Lvalue", ptr %l96
  %t228 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t226, %"compiler/mir:Lvalue" %t227, 1
  %t230 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t228, { i64, [15 x i64] } %t222, 2
  %t231 = getelementptr { i64, [21 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t230, ptr %t231
  %t232 = load { i64, [21 x i64] }, ptr %t223
  store { i64, [21 x i64] } %t232, ptr %l109
  %t233 = load ptr, ptr %l92, !tbaa !29
  %t234 = load i32, ptr %l93, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t233, i32 %t234, ptr %l109)
  br label %bb28
bb28:
  %t236 = load ptr, ptr %lp3
  store ptr %t236, ptr %l111, !tbaa !29
  %t237 = load i32, ptr %l12, !tbaa !23
  store i32 %t237, ptr %l112, !tbaa !23
  %t238 = load i32, ptr %l7, !tbaa !23
  %t240 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t238)
  store %"compiler/mir:Lvalue" %t240, ptr %l114
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 0
  store i64 1, ptr %t242
  %t243 = load %"compiler/mir:Lvalue", ptr %l114
  %t244 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t243, 0
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t244, ptr %t245
  %t246 = load { i64, [4 x i64] }, ptr %t241
  %t247 = load i32, ptr %l13, !tbaa !23
  %t248 = load i32, ptr %l15, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [8 x i64] }, ptr %t249, i32 0, i32 0
  store i64 2, ptr %t250
  %t252 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t246, 0
  %t254 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t252, i32 %t247, 1
  %t256 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t254, i32 %t248, 2
  %t257 = getelementptr { i64, [8 x i64] }, ptr %t249, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t256, ptr %t257
  %t258 = load { i64, [8 x i64] }, ptr %t249
  %t259 = load ptr, ptr %l111, !tbaa !29
  %t260 = load i32, ptr %l112, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t259, i32 %t260, { i64, [8 x i64] } %t258)
  br label %bb30
bb30:
  %t262 = load ptr, ptr %lp3
  %t263 = load i32, ptr %l13, !tbaa !23
  %t264 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t265 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [21 x i64] }, ptr %t266, i32 0, i32 0
  store i64 3, ptr %t267
  %t269 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t264, 0
  %t271 = insertvalue { %"compiler/source:Span", i32 } %t269, i32 %t265, 1
  %t272 = getelementptr { i64, [21 x i64] }, ptr %t266, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t271, ptr %t272
  %t273 = load { i64, [21 x i64] }, ptr %t266
  store { i64, [21 x i64] } %t273, ptr %l123
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t262, i32 %t263, ptr %l123)
  br label %bb31
bb31:
  %t277 = load ptr, ptr %lp3
  store ptr %t277, ptr %l125, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [2 x i64] }, ptr %t278, i32 0, i32 0
  store i64 0, ptr %t279
  %t280 = insertvalue { i32 } undef, i32 1, 0
  %t281 = getelementptr { i64, [2 x i64] }, ptr %t278, i32 0, i32 1
  store { i32 } %t280, ptr %t281
  %t282 = load { i64, [2 x i64] }, ptr %t278
  %t283 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [7 x i64] }, ptr %t284, i32 0, i32 0
  store i64 0, ptr %t285
  %t287 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t282, 0
  %t289 = insertvalue { { i64, [2 x i64] }, i32 } %t287, i32 %t283, 1
  %t290 = getelementptr { i64, [7 x i64] }, ptr %t284, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t289, ptr %t290
  %t291 = load { i64, [7 x i64] }, ptr %t284
  store { i64, [7 x i64] } %t291, ptr %l128
  %t292 = load ptr, ptr %lp3
  store ptr %t292, ptr %l129, !tbaa !29
  %t293 = load i32, ptr %l6, !tbaa !23
  %t295 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t293)
  store %"compiler/mir:Lvalue" %t295, ptr %l131
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t296
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 0
  store i64 1, ptr %t297
  %t298 = load %"compiler/mir:Lvalue", ptr %l131
  %t299 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t298, 0
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t299, ptr %t300
  %t301 = load { i64, [4 x i64] }, ptr %t296
  %t302 = mul i64 1, 40
  %t303 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 1, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l133, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i64 0
  store { i64, [4 x i64] } %t301, ptr %t309
  %t310 = load ptr, ptr %l129, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t312 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t310, { i64, ptr } %t311)
  store %"compiler/mir:Range" %t312, ptr %l134
  br label %bb33
bb33:
  %t313 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t313, ptr %l135
  %t314 = load i32, ptr %l8, !tbaa !23
  %t316 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t314)
  store %"compiler/mir:Lvalue" %t316, ptr %l137
  br label %bb34
bb34:
  %t317 = load i32, ptr %l14, !tbaa !23
  %t318 = load i32, ptr %l9, !tbaa !23
  %t319 = load i32, ptr %l16, !tbaa !23
  %t320 = load { i64, [7 x i64] }, ptr %l128
  %t321 = load %"compiler/mir:Range", ptr %l134
  %t322 = load %"compiler/mir:Range", ptr %l135
  %t323 = load %"compiler/mir:Lvalue", ptr %l137
  %t327 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t320, %"compiler/mir:Range" %t321, %"compiler/mir:Range" %t322, %"compiler/mir:Lvalue" %t323, i1 true, i32 %t317, i32 %t318, i32 %t319)
  store %"compiler/mir:Call" %t327, ptr %l141
  br label %bb35
bb35:
  %t328 = load ptr, ptr %l125, !tbaa !29
  %t329 = load %"compiler/mir:Call", ptr %l141
  %t330 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t328, %"compiler/mir:Call" %t329)
  store i32 %t330, ptr %l142
  br label %bb36
bb36:
  %t331 = load i32, ptr %l142, !tbaa !23
  %t332 = load ptr, ptr %lp3
  %t333 = load i32, ptr %l13, !tbaa !23
  %t334 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [8 x i64] }, ptr %t336, i32 0, i32 0
  store i64 4, ptr %t337
  %t339 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t334, 0
  %t341 = insertvalue { %"compiler/source:Span", i32 } %t339, i32 %t331, 1
  %t342 = getelementptr { i64, [8 x i64] }, ptr %t336, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t341, ptr %t342
  %t343 = load { i64, [8 x i64] }, ptr %t336
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t332, i32 %t333, { i64, [8 x i64] } %t343)
  br label %bb37
bb37:
  %t347 = load ptr, ptr %lp3
  store ptr %t347, ptr %l148, !tbaa !29
  %t348 = load i32, ptr %l14, !tbaa !23
  store i32 %t348, ptr %l149, !tbaa !23
  %t349 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t349, ptr %l150
  %t350 = load i32, ptr %l6, !tbaa !23
  %t352 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t350)
  store %"compiler/mir:Lvalue" %t352, ptr %l152
  br label %bb38
bb38:
  store i32 3, ptr %l153
  %t353 = load i32, ptr %l1, !tbaa !23
  store i32 %t353, ptr %l154, !tbaa !23
  %t354 = load ptr, ptr %lp3
  store ptr %t354, ptr %l155, !tbaa !29
  %t355 = load i32, ptr %l6, !tbaa !23
  %t357 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t355)
  store %"compiler/mir:Lvalue" %t357, ptr %l157
  br label %bb39
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 0
  store i64 1, ptr %t359
  %t360 = load %"compiler/mir:Lvalue", ptr %l157
  %t361 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t360, 0
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t361, ptr %t362
  %t363 = load { i64, [4 x i64] }, ptr %t358
  %t364 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 0
  store i64 2, ptr %t366
  %t368 = insertvalue { i32, i64 } undef, i32 %t364, 0
  %t369 = insertvalue { i32, i64 } %t368, i64 1, 1
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 1
  store { i32, i64 } %t369, ptr %t370
  %t371 = load { i64, [4 x i64] }, ptr %t365
  %t372 = mul i64 2, 40
  %t373 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 2, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l161, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t378, i64 0
  store { i64, [4 x i64] } %t363, ptr %t379
  %t381 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr { i64, [4 x i64] }, ptr %t382, i64 1
  store { i64, [4 x i64] } %t371, ptr %t383
  %t384 = load ptr, ptr %l155, !tbaa !29
  %t385 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t386 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t384, { i64, ptr } %t385)
  store %"compiler/mir:Range" %t386, ptr %l162
  br label %bb40
bb40:
  store { i64, [15 x i64] } zeroinitializer, ptr %t387
  %t388 = getelementptr { i64, [15 x i64] }, ptr %t387, i32 0, i32 0
  store i64 3, ptr %t388
  %t389 = load i32, ptr %l153, !range !{i32 0, i32 54}
  %t390 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t389, 0
  %t391 = load i32, ptr %l154, !tbaa !23
  %t392 = insertvalue { i32, i32, %"compiler/mir:Range" } %t390, i32 %t391, 1
  %t393 = load %"compiler/mir:Range", ptr %l162
  %t394 = insertvalue { i32, i32, %"compiler/mir:Range" } %t392, %"compiler/mir:Range" %t393, 2
  %t395 = getelementptr { i64, [15 x i64] }, ptr %t387, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t394, ptr %t395
  %t396 = load { i64, [15 x i64] }, ptr %t387
  store { i64, [21 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [21 x i64] }, ptr %t397, i32 0, i32 0
  store i64 0, ptr %t398
  %t399 = load %"compiler/source:Span", ptr %l150
  %t400 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t399, 0
  %t401 = load %"compiler/mir:Lvalue", ptr %l152
  %t402 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t400, %"compiler/mir:Lvalue" %t401, 1
  %t404 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t402, { i64, [15 x i64] } %t396, 2
  %t405 = getelementptr { i64, [21 x i64] }, ptr %t397, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t404, ptr %t405
  %t406 = load { i64, [21 x i64] }, ptr %t397
  store { i64, [21 x i64] } %t406, ptr %l164
  %t407 = load ptr, ptr %l148, !tbaa !29
  %t408 = load i32, ptr %l149, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t407, i32 %t408, ptr %l164)
  br label %bb41
bb41:
  %t410 = load ptr, ptr %lp3
  %t411 = load i32, ptr %l14, !tbaa !23
  %t412 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t413 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [21 x i64] }, ptr %t414, i32 0, i32 0
  store i64 4, ptr %t415
  %t417 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t412, 0
  %t419 = insertvalue { %"compiler/source:Span", i32 } %t417, i32 %t413, 1
  %t420 = getelementptr { i64, [21 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t419, ptr %t420
  %t421 = load { i64, [21 x i64] }, ptr %t414
  store { i64, [21 x i64] } %t421, ptr %l170
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t410, i32 %t411, ptr %l170)
  br label %bb42
bb42:
  %t425 = load ptr, ptr %lp3
  %t426 = load i32, ptr %l14, !tbaa !23
  %t427 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [8 x i64] }, ptr %t428, i32 0, i32 0
  store i64 1, ptr %t429
  %t431 = insertvalue { i32 } undef, i32 %t427, 0
  %t432 = getelementptr { i64, [8 x i64] }, ptr %t428, i32 0, i32 1
  store { i32 } %t431, ptr %t432
  %t433 = load { i64, [8 x i64] }, ptr %t428
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t425, i32 %t426, { i64, [8 x i64] } %t433)
  br label %bb43
bb43:
  %t437 = load ptr, ptr %lp3
  %t438 = load i32, ptr %l15, !tbaa !23
  %t439 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [21 x i64] }, ptr %t440, i32 0, i32 0
  store i64 4, ptr %t441
  %t443 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t439, 0
  %t444 = insertvalue { %"compiler/source:Span", i32 } %t443, i32 0, 1
  %t445 = getelementptr { i64, [21 x i64] }, ptr %t440, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t444, ptr %t445
  %t446 = load { i64, [21 x i64] }, ptr %t440
  store { i64, [21 x i64] } %t446, ptr %l179
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t437, i32 %t438, ptr %l179)
  br label %bb44
bb44:
  %t450 = load ptr, ptr %lp3
  store ptr %t450, ptr %l181, !tbaa !29
  %t451 = load i32, ptr %l15, !tbaa !23
  store i32 %t451, ptr %l182, !tbaa !23
  %t452 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t452, ptr %l183
  %t453 = load i32, ptr %l6, !tbaa !23
  %t455 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t453)
  store %"compiler/mir:Lvalue" %t455, ptr %l185
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 0
  store i64 1, ptr %t457
  %t458 = load %"compiler/mir:Lvalue", ptr %l185
  %t459 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t458, 0
  %t460 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t459, ptr %t460
  %t461 = load { i64, [4 x i64] }, ptr %t456
  store { i64, [8 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [8 x i64] }, ptr %t462, i32 0, i32 0
  store i64 5, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l183
  %t465 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t464, 0
  %t467 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t465, { i64, [4 x i64] } %t461, 1
  %t468 = getelementptr { i64, [8 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t467, ptr %t468
  %t469 = load { i64, [8 x i64] }, ptr %t462
  %t470 = load ptr, ptr %l181, !tbaa !29
  %t471 = load i32, ptr %l182, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t470, i32 %t471, { i64, [8 x i64] } %t469)
  br label %bb46
bb46:
  %t473 = load ptr, ptr %lp3
  store ptr %t473, ptr %l188, !tbaa !29
  %t474 = load i32, ptr %l16, !tbaa !23
  store i32 %t474, ptr %l189, !tbaa !23
  %t475 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t475, ptr %l190
  %t476 = load i32, ptr %l10, !tbaa !23
  %t478 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t476)
  store %"compiler/mir:Lvalue" %t478, ptr %l192
  br label %bb47
bb47:
  %t479 = load i32, ptr %l9, !tbaa !23
  %t481 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t479)
  store %"compiler/mir:Lvalue" %t481, ptr %l194
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t482
  %t483 = getelementptr { i64, [4 x i64] }, ptr %t482, i32 0, i32 0
  store i64 1, ptr %t483
  %t484 = load %"compiler/mir:Lvalue", ptr %l194
  %t485 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t484, 0
  %t486 = getelementptr { i64, [4 x i64] }, ptr %t482, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t485, ptr %t486
  %t487 = load { i64, [4 x i64] }, ptr %t482
  %t488 = load i32, ptr %l2, !tbaa !23
  %t489 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t490
  %t491 = getelementptr { i64, [15 x i64] }, ptr %t490, i32 0, i32 0
  store i64 11, ptr %t491
  %t493 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t487, 0
  %t495 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t493, i32 %t488, 1
  %t497 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t495, i32 %t489, 2
  %t498 = getelementptr { i64, [15 x i64] }, ptr %t490, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t497, ptr %t498
  %t499 = load { i64, [15 x i64] }, ptr %t490
  store { i64, [21 x i64] } zeroinitializer, ptr %t500
  %t501 = getelementptr { i64, [21 x i64] }, ptr %t500, i32 0, i32 0
  store i64 0, ptr %t501
  %t502 = load %"compiler/source:Span", ptr %l190
  %t503 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t502, 0
  %t504 = load %"compiler/mir:Lvalue", ptr %l192
  %t505 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t503, %"compiler/mir:Lvalue" %t504, 1
  %t507 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t505, { i64, [15 x i64] } %t499, 2
  %t508 = getelementptr { i64, [21 x i64] }, ptr %t500, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t507, ptr %t508
  %t509 = load { i64, [21 x i64] }, ptr %t500
  store { i64, [21 x i64] } %t509, ptr %l199
  %t510 = load ptr, ptr %l188, !tbaa !29
  %t511 = load i32, ptr %l189, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t510, i32 %t511, ptr %l199)
  br label %bb49
bb49:
  %t513 = load ptr, ptr %lp3
  %t514 = load i32, ptr %l16, !tbaa !23
  %t515 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t516 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t517
  %t518 = getelementptr { i64, [21 x i64] }, ptr %t517, i32 0, i32 0
  store i64 4, ptr %t518
  %t520 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t515, 0
  %t522 = insertvalue { %"compiler/source:Span", i32 } %t520, i32 %t516, 1
  %t523 = getelementptr { i64, [21 x i64] }, ptr %t517, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t522, ptr %t523
  %t524 = load { i64, [21 x i64] }, ptr %t517
  store { i64, [21 x i64] } %t524, ptr %l205
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t513, i32 %t514, ptr %l205)
  br label %bb50
bb50:
  %t528 = load ptr, ptr %lp3
  %t529 = load i32, ptr %l16, !tbaa !23
  %t530 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t531
  %t532 = getelementptr { i64, [21 x i64] }, ptr %t531, i32 0, i32 0
  store i64 4, ptr %t532
  %t534 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t530, 0
  %t535 = insertvalue { %"compiler/source:Span", i32 } %t534, i32 0, 1
  %t536 = getelementptr { i64, [21 x i64] }, ptr %t531, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t535, ptr %t536
  %t537 = load { i64, [21 x i64] }, ptr %t531
  store { i64, [21 x i64] } %t537, ptr %l210
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t528, i32 %t529, ptr %l210)
  br label %bb51
bb51:
  %t541 = load ptr, ptr %lp3
  store ptr %t541, ptr %l212, !tbaa !29
  %t542 = load i32, ptr %l16, !tbaa !23
  store i32 %t542, ptr %l213, !tbaa !23
  %t543 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t543, ptr %l214
  %t544 = load i32, ptr %l10, !tbaa !23
  %t546 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t544)
  store %"compiler/mir:Lvalue" %t546, ptr %l216
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t547
  %t548 = getelementptr { i64, [4 x i64] }, ptr %t547, i32 0, i32 0
  store i64 1, ptr %t548
  %t549 = load %"compiler/mir:Lvalue", ptr %l216
  %t550 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t549, 0
  %t551 = getelementptr { i64, [4 x i64] }, ptr %t547, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t550, ptr %t551
  %t552 = load { i64, [4 x i64] }, ptr %t547
  store { i64, [8 x i64] } zeroinitializer, ptr %t553
  %t554 = getelementptr { i64, [8 x i64] }, ptr %t553, i32 0, i32 0
  store i64 7, ptr %t554
  %t555 = load %"compiler/source:Span", ptr %l214
  %t556 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t555, 0
  %t558 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t556, { i64, [4 x i64] } %t552, 1
  %t559 = getelementptr { i64, [8 x i64] }, ptr %t553, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t558, ptr %t559
  %t560 = load { i64, [8 x i64] }, ptr %t553
  %t561 = load ptr, ptr %l212, !tbaa !29
  %t562 = load i32, ptr %l213, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t561, i32 %t562, { i64, [8 x i64] } %t560)
  br label %bb53
bb53:
  %t564 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l219, ptr %t564, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l219, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l64 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l77 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1, i32 %t2, i64 %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t11 = trunc i64 0 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb7
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t18 = mul i64 2, 4
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 2, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 0
  store i32 %t16, ptr %t25, !tbaa !33
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 1
  store i32 %t17, ptr %t29, !tbaa !33
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } %t31)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t34 = load ptr, ptr %l11, !tbaa !29
  %t35 = load i32, ptr %l16, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t34, i32 %t35, i32 %t33, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t37, ptr %l18
  br label %bb6
bb6:
  %t38 = load i32, ptr %l18, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb51
bb7:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = mul i64 2, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 2, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t46, ptr %t55, !tbaa !33
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 1
  store i32 %t47, ptr %t59, !tbaa !33
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t45, { i64, ptr } %t61)
  store i32 %t62, ptr %l26
  br label %bb11
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t64 = load ptr, ptr %l21, !tbaa !29
  %t65 = load i32, ptr %l26, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t64, i32 %t65, i32 %t63, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t67, ptr %l28
  br label %bb12
bb12:
  %t68 = load i32, ptr %l28, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb13:
  %t69 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l31, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l34
  br label %bb17
bb17:
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load ptr, ptr %l31, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t81, i32 %t82, i32 %t80, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t84, ptr %l36
  br label %bb18
bb18:
  %t85 = load i32, ptr %l36, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  br label %bb51
bb19:
  %t86 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t91, i32 0, i32 %t92, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t95, ptr %l41
  br label %bb23
bb23:
  %t96 = load i32, ptr %l41, !tbaa !23
  store i32 %t96, ptr %l8, !tbaa !23
  br label %bb51
bb24:
  %t97 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t99 = trunc i64 4 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t102 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t104 = trunc i64 5 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l46, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l49
  br label %bb30
bb30:
  %t113 = load i32, ptr %l2, !tbaa !23
  %t114 = load ptr, ptr %l46, !tbaa !29
  %t115 = load i32, ptr %l49, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t114, i32 %t115, i32 %t113, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t117, ptr %l51
  br label %bb31
bb31:
  %t118 = load i32, ptr %l51, !tbaa !23
  store i32 %t118, ptr %l8, !tbaa !23
  br label %bb51
bb32:
  %t119 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t121 = trunc i64 6 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t124 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t126 = trunc i64 7 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l56, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l57, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t137, ptr %l61
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l57, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb39
bb39:
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t142 = load ptr, ptr %l56, !tbaa !29
  %t143 = load i32, ptr %l62, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t142, i32 %t143, i32 %t141, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t145, ptr %l64
  br label %bb40
bb40:
  %t146 = load i32, ptr %l64, !tbaa !23
  store i32 %t146, ptr %l8, !tbaa !23
  br label %bb51
bb41:
  %t147 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t149 = trunc i64 8 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  %t152 = load i32, ptr %l1, !range !{i32 0, i32 10}
  %t154 = trunc i64 9 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l69, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l70, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l2, !tbaa !23
  %t161 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t159, i32 %t160, i64 %t161)
  store i32 %t165, ptr %l74
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l70, !tbaa !29
  %t167 = load i32, ptr %l74, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t168, ptr %l75
  br label %bb48
bb48:
  %t169 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t170 = load ptr, ptr %l69, !tbaa !29
  %t171 = load i32, ptr %l75, !tbaa !23
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t170, i32 %t171, i32 %t169, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t173, ptr %l77
  br label %bb49
bb49:
  %t174 = load i32, ptr %l77, !tbaa !23
  store i32 %t174, ptr %l8, !tbaa !23
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_f3abe41a98405543_7d26227a2bded35f)
  unreachable
bb51:
  %t175 = load i32, ptr %l8, !tbaa !23
  store i32 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca { i64, [15 x i64] }
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca %"compiler/mir:Lvalue"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:Task"
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca %"compiler/mir:Range"
  %l30 = alloca ptr
  %l31 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l144 = alloca %"compiler/mir:Task"
  %l155 = alloca i32
  %l158 = alloca i32
  %l176 = alloca ptr
  %l184 = alloca { i64, [1 x i64] }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca i1
  %t269 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l4
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l5
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, [15 x i64] }, ptr %l5
  %t24 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2ervMentions(ptr %v0, ptr %v2, ptr %t22, { i64, [15 x i64] } %t23, ptr %t24)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/mir:Lvalue", ptr %l4
  %t30 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2etarget(ptr %v0, ptr %v2, ptr %v3, ptr %t28, %"compiler/mir:Lvalue" %t29, ptr %t30, ptr %a3)
  br label %bb7
bb7:
  br label %bb114
bb8:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t37 = load ptr, ptr %l45, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l45, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 20}
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l46, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l46, !tbaa !21
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [21 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t47, i32 0, i32 1
  %t49 = load { i64, [1 x i64] }, ptr %t48
  store { i64, [1 x i64] } %t49, ptr %l6
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [21 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t53, i32 0, i32 3
  %t55 = load { i64, [4 x i64] }, ptr %t54
  store { i64, [4 x i64] } %t55, ptr %l7
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, [1 x i64] }, ptr %l6
  %t59 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v2, ptr %t57, { i64, [1 x i64] } %t58, ptr %t59)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, [4 x i64] }, ptr %l7
  %t65 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t63, { i64, [4 x i64] } %t64, ptr %t65)
  br label %bb15
bb15:
  br label %bb114
bb16:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t70 = load ptr, ptr %l59, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t73 = load ptr, ptr %l59, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 20}
  %t76 = icmp eq i64 %t74, 6
  store i1 %t76, ptr %l60, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l60, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [21 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t80, i32 0, i32 1
  %t82 = load %"compiler/mir:Lvalue", ptr %t81
  store %"compiler/mir:Lvalue" %t82, ptr %l8
  br label %bb29
bb20:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t85 = load ptr, ptr %l65, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load ptr, ptr %l65, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 20}
  %t91 = icmp eq i64 %t89, 7
  store i1 %t91, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t92 = load i1, ptr %l66, !tbaa !21
  br i1 %t92, label %bb23, label %bb24
bb23:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [21 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t95, i32 0, i32 1
  %t97 = load %"compiler/mir:Lvalue", ptr %t96
  store %"compiler/mir:Lvalue" %t97, ptr %l8
  br label %bb29
bb24:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t100 = load ptr, ptr %l71, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 20}
  %t106 = icmp eq i64 %t104, 8
  store i1 %t106, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t107 = load i1, ptr %l72, !tbaa !21
  br i1 %t107, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [21 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t110, i32 0, i32 1
  %t112 = load %"compiler/mir:Lvalue", ptr %t111
  store %"compiler/mir:Lvalue" %t112, ptr %l8
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/mir:Lvalue", ptr %l8
  %t116 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v2, ptr %t114, %"compiler/mir:Lvalue" %t115, ptr %t116)
  br label %bb30
bb30:
  br label %bb114
bb31:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t121 = load ptr, ptr %l80, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb32, label %bb33
bb32:
  %t124 = load ptr, ptr %l80, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 20}
  %t127 = icmp eq i64 %t125, 9
  store i1 %t127, ptr %l81, !tbaa !21
  br label %bb33
bb33:
  %t128 = load i1, ptr %l81, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [21 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t131, i32 0, i32 1
  %t133 = load i32, ptr %t132
  store i32 %t133, ptr %l9, !tbaa !23
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [21 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t137, i32 0, i32 2
  %t139 = load %"compiler/mir:Lvalue", ptr %t138
  store %"compiler/mir:Lvalue" %t139, ptr %l10
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v2, ptr %t141, i32 %t142)
  br label %bb37
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/mir:Lvalue", ptr %l10
  %t147 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v2, ptr %t145, %"compiler/mir:Lvalue" %t146, ptr %t147)
  br label %bb38
bb38:
  br label %bb114
bb39:
  %t151 = load ptr, ptr %l1, !tbaa !29
  store ptr %t151, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t152 = load ptr, ptr %l93, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb40, label %bb41
bb40:
  %t155 = load ptr, ptr %l93, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 20}
  %t158 = icmp eq i64 %t156, 10
  store i1 %t158, ptr %l94, !tbaa !21
  br label %bb41
bb41:
  %t159 = load i1, ptr %l94, !tbaa !21
  br i1 %t159, label %bb42, label %bb43
bb42:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr { i64, [21 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", i32 }, ptr %t162, i32 0, i32 1
  %t164 = load i32, ptr %t163
  store i32 %t164, ptr %l11, !tbaa !23
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t167 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v2, ptr %t166, i32 %t167)
  br label %bb45
bb45:
  br label %bb114
bb46:
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t171 = load ptr, ptr %l101, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb47, label %bb48
bb47:
  %t174 = load ptr, ptr %l101, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 20}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l102, !tbaa !21
  br label %bb48
bb48:
  %t178 = load i1, ptr %l102, !tbaa !21
  br i1 %t178, label %bb49, label %bb50
bb49:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [21 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t181, i32 0, i32 1
  %t183 = load { i64, [1 x i64] }, ptr %t182
  store { i64, [1 x i64] } %t183, ptr %l12
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr { i64, [21 x i64] }, ptr %t185, i32 0, i32 1
  %t188 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t187, i32 0, i32 3
  %t189 = load { i64, [4 x i64] }, ptr %t188
  store { i64, [4 x i64] } %t189, ptr %l13
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load { i64, [1 x i64] }, ptr %l12
  %t193 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v2, ptr %t191, { i64, [1 x i64] } %t192, ptr %t193)
  br label %bb52
bb52:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load { i64, [4 x i64] }, ptr %l13
  %t199 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t197, { i64, [4 x i64] } %t198, ptr %t199)
  br label %bb53
bb53:
  br label %bb114
bb54:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t204 = load ptr, ptr %l115, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb55, label %bb56
bb55:
  %t207 = load ptr, ptr %l115, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 20}
  %t210 = icmp eq i64 %t208, 12
  store i1 %t210, ptr %l116, !tbaa !21
  br label %bb56
bb56:
  %t211 = load i1, ptr %l116, !tbaa !21
  br i1 %t211, label %bb57, label %bb58
bb57:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [21 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t214, i32 0, i32 1
  %t216 = load %"compiler/mir:Lvalue", ptr %t215
  store %"compiler/mir:Lvalue" %t216, ptr %l14
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [21 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t220, i32 0, i32 2
  %t222 = load %"compiler/mir:Lvalue", ptr %t221
  store %"compiler/mir:Lvalue" %t222, ptr %l15
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [21 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t226, i32 0, i32 3
  %t228 = load { i64, [4 x i64] }, ptr %t227
  store { i64, [4 x i64] } %t228, ptr %l16
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/mir:Lvalue", ptr %l14
  %t232 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v2, ptr %t230, %"compiler/mir:Lvalue" %t231, ptr %t232)
  br label %bb60
bb60:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load %"compiler/mir:Lvalue", ptr %l15
  %t238 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v2, ptr %t236, %"compiler/mir:Lvalue" %t237, ptr %t238)
  br label %bb61
bb61:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load { i64, [4 x i64] }, ptr %l16
  %t244 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t242, { i64, [4 x i64] } %t243, ptr %t244)
  br label %bb62
bb62:
  br label %bb114
bb63:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t249 = load ptr, ptr %l134, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb64, label %bb65
bb64:
  %t252 = load ptr, ptr %l134, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 20}
  %t255 = icmp eq i64 %t253, 13
  store i1 %t255, ptr %l135, !tbaa !21
  br label %bb65
bb65:
  %t256 = load i1, ptr %l135, !tbaa !21
  br i1 %t256, label %bb66, label %bb67
bb66:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [21 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t259, i32 0, i32 2
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l17, !tbaa !23
  br label %bb68
bb67:
  br label %bb86
bb68:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/mir:Fn", ptr %t263, i32 0, i32 16
  %t266 = load i32, ptr %l17, !tbaa !23
  %t268 = sext i32 %t266 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t269, ptr %v0, ptr %t265, i64 %t268)
  call void @llvm.memmove.p0.p0.i64(ptr %l144, ptr %t269, i64 144, i1 false)
  br label %bb69
bb69:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l144, i64 144, i1 false)
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:Task", ptr %l18, i32 0, i32 0
  %t274 = load { i64, [7 x i64] }, ptr %t273
  %t275 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2ecalleeMentions(ptr %v0, ptr %v2, ptr %t272, { i64, [7 x i64] } %t274, ptr %t275)
  br label %bb70
bb70:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/mir:Task", ptr %l18, i32 0, i32 1
  %t281 = load %"compiler/mir:Range", ptr %t280
  %t282 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v2, ptr %t279, %"compiler/mir:Range" %t281, ptr %t282)
  br label %bb71
bb71:
  store i32 0, ptr %l19, !tbaa !23
  %t286 = getelementptr %"compiler/mir:Task", ptr %l18, i32 0, i32 2
  %t287 = getelementptr %"compiler/mir:Range", ptr %t286, i32 0, i32 1
  %t288 = load i32, ptr %t287, !tbaa !23
  store i32 %t288, ptr %l20, !tbaa !23
  store i32 1, ptr %l21, !tbaa !23
  %t290 = load i32, ptr %l20, !tbaa !23
  %t291 = load i32, ptr %l19, !tbaa !23
  %t294 = icmp sgt i32 %t290, %t291
  br i1 %t294, label %bb72, label %bb73
bb72:
  %t296 = load i32, ptr %l21, !tbaa !23
  %t298 = icmp sgt i32 %t296, 0
  br i1 %t298, label %bb74, label %bb75
bb73:
  store i32 0, ptr %l155, !tbaa !23
  br label %bb77
bb74:
  %t300 = load i32, ptr %l20, !tbaa !23
  %t301 = load i32, ptr %l19, !tbaa !23
  %t304 = sub i32 %t300, %t301
  %t305 = load i32, ptr %l21, !tbaa !23
  %t308 = add i32 %t304, %t305
  %t310 = sub i32 %t308, 1
  %t311 = load i32, ptr %l21, !tbaa !23
  %t314 = sdiv i32 %t310, %t311
  store i32 %t314, ptr %l158, !tbaa !23
  br label %bb76
bb75:
  store i32 0, ptr %l158, !tbaa !23
  br label %bb76
bb76:
  %t316 = load i32, ptr %l158, !tbaa !23
  store i32 %t316, ptr %l155, !tbaa !23
  br label %bb77
bb77:
  %t317 = load i32, ptr %l155, !tbaa !23
  store i32 %t317, ptr %l22, !tbaa !23
  store i32 0, ptr %l23, !tbaa !23
  br label %bb78
bb78:
  %t318 = load i32, ptr %l23, !tbaa !23
  %t319 = load i32, ptr %l22, !tbaa !23
  %t322 = icmp slt i32 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb79, label %bb80
bb79:
  br label %bb85
bb80:
  br label %bb81
bb81:
  %t326 = load i32, ptr %l19, !tbaa !23
  %t327 = load i32, ptr %l23, !tbaa !23
  %t328 = load i32, ptr %l21, !tbaa !23
  %t331 = mul i32 %t327, %t328
  %t334 = add i32 %t326, %t331
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l176, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/mir:Fn", ptr %t337, i32 0, i32 12
  %t340 = getelementptr %"compiler/mir:Task", ptr %l18, i32 0, i32 2
  %t341 = getelementptr %"compiler/mir:Range", ptr %t340, i32 0, i32 0
  %t342 = load i32, ptr %t341, !tbaa !23
  %t344 = sext i32 %t342 to i64
  %t347 = sext i32 %t334 to i64
  %t350 = add i64 %t344, %t347
  %t353 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t339, i64 %t350)
  store { i64, [1 x i64] } %t353, ptr %l184
  br label %bb82
bb82:
  %t354 = load ptr, ptr %l2, !tbaa !29
  %t355 = load ptr, ptr %l176, !tbaa !29
  %t356 = load { i64, [1 x i64] }, ptr %l184
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v2, ptr %t355, { i64, [1 x i64] } %t356, ptr %t354)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t358 = load i32, ptr %l23, !tbaa !23
  %t361 = add i32 %t358, 1
  store i32 %t361, ptr %l23, !tbaa !23
  br label %bb78
bb85:
  br label %bb114
bb86:
  %t363 = load ptr, ptr %l1, !tbaa !29
  store ptr %t363, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t364 = load ptr, ptr %l189, !tbaa !29
  %t365 = icmp ne ptr %t364, null
  br i1 %t365, label %bb87, label %bb88
bb87:
  %t367 = load ptr, ptr %l189, !tbaa !29
  %t368 = load i64, ptr %t367, !range !{i64 0, i64 20}
  %t370 = icmp eq i64 %t368, 15
  store i1 %t370, ptr %l190, !tbaa !21
  br label %bb88
bb88:
  %t371 = load i1, ptr %l190, !tbaa !21
  br i1 %t371, label %bb89, label %bb90
bb89:
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [21 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t374, i32 0, i32 1
  %t376 = load { i64, [4 x i64] }, ptr %t375
  store { i64, [4 x i64] } %t376, ptr %l25
  br label %bb91
bb90:
  br label %bb93
bb91:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load { i64, [4 x i64] }, ptr %l25
  %t380 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t378, { i64, [4 x i64] } %t379, ptr %t380)
  br label %bb92
bb92:
  br label %bb114
bb93:
  %t384 = load ptr, ptr %l1, !tbaa !29
  store ptr %t384, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t385 = load ptr, ptr %l198, !tbaa !29
  %t386 = icmp ne ptr %t385, null
  br i1 %t386, label %bb94, label %bb95
bb94:
  %t388 = load ptr, ptr %l198, !tbaa !29
  %t389 = load i64, ptr %t388, !range !{i64 0, i64 20}
  %t391 = icmp eq i64 %t389, 17
  store i1 %t391, ptr %l199, !tbaa !21
  br label %bb95
bb95:
  %t392 = load i1, ptr %l199, !tbaa !21
  br i1 %t392, label %bb96, label %bb97
bb96:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr { i64, [21 x i64] }, ptr %t393, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t395, i32 0, i32 1
  %t397 = load { i64, [4 x i64] }, ptr %t396
  store { i64, [4 x i64] } %t397, ptr %l26
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t401 = getelementptr { i64, [21 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t401, i32 0, i32 2
  %t403 = load { i64, [4 x i64] }, ptr %t402
  store { i64, [4 x i64] } %t403, ptr %l27
  br label %bb98
bb97:
  br label %bb101
bb98:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load { i64, [4 x i64] }, ptr %l26
  %t407 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t405, { i64, [4 x i64] } %t406, ptr %t407)
  br label %bb99
bb99:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load { i64, [4 x i64] }, ptr %l27
  %t413 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t411, { i64, [4 x i64] } %t412, ptr %t413)
  br label %bb100
bb100:
  br label %bb114
bb101:
  %t417 = load ptr, ptr %l1, !tbaa !29
  store ptr %t417, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t418 = load ptr, ptr %l212, !tbaa !29
  %t419 = icmp ne ptr %t418, null
  br i1 %t419, label %bb102, label %bb103
bb102:
  %t421 = load ptr, ptr %l212, !tbaa !29
  %t422 = load i64, ptr %t421, !range !{i64 0, i64 20}
  %t424 = icmp eq i64 %t422, 18
  store i1 %t424, ptr %l213, !tbaa !21
  br label %bb103
bb103:
  %t425 = load i1, ptr %l213, !tbaa !21
  br i1 %t425, label %bb104, label %bb105
bb104:
  %t426 = load ptr, ptr %l1, !tbaa !29
  %t428 = getelementptr { i64, [21 x i64] }, ptr %t426, i32 0, i32 1
  %t429 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t428, i32 0, i32 1
  %t430 = load { i64, [4 x i64] }, ptr %t429
  store { i64, [4 x i64] } %t430, ptr %l28
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr { i64, [21 x i64] }, ptr %t432, i32 0, i32 1
  %t435 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t434, i32 0, i32 3
  %t436 = load %"compiler/mir:Range", ptr %t435
  store %"compiler/mir:Range" %t436, ptr %l29
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load { i64, [4 x i64] }, ptr %l28
  %t440 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v2, ptr %t438, { i64, [4 x i64] } %t439, ptr %t440)
  br label %bb107
bb107:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/mir:Range", ptr %l29
  %t446 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v2, ptr %t444, %"compiler/mir:Range" %t445, ptr %t446)
  br label %bb108
bb108:
  br label %bb114
bb109:
  br i1 true, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_769ae05158a21e45_1e3756f4622c6ab9)
  unreachable
bb114:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca %"compiler/mir:Call"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l39 = alloca %"compiler/mir:Call"
  %l50 = alloca i32
  %l53 = alloca i32
  %l71 = alloca ptr
  %l79 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [8 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l4
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l4
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t10, { i64, [4 x i64] } %t11, ptr %t12)
  br label %bb4
bb4:
  br label %bb68
bb5:
  %t16 = load { i64, [8 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [8 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 3
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t21, i32 0, i32 0
  %t23 = load { i64, [4 x i64] }, ptr %t22
  store { i64, [4 x i64] } %t23, ptr %l5
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, [4 x i64] }, ptr %l5
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t25, { i64, [4 x i64] } %t26, ptr %t27)
  br label %bb9
bb9:
  br label %bb68
bb10:
  %t31 = load { i64, [8 x i64] }, ptr %l1
  %t33 = extractvalue { i64, [8 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 4
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32 }, ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l6, !tbaa !23
  br label %bb15
bb12:
  %t40 = load { i64, [8 x i64] }, ptr %l1
  %t42 = extractvalue { i64, [8 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 6
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32 }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb41
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Fn", ptr %t49, i32 0, i32 14
  %t52 = load i32, ptr %l6, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t57 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t51, i64 %t54)
  store %"compiler/mir:Call" %t57, ptr %l39
  br label %bb16
bb16:
  %t58 = load %"compiler/mir:Call", ptr %l39
  store %"compiler/mir:Call" %t58, ptr %l7
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 0
  %t61 = load { i64, [7 x i64] }, ptr %t60
  %t62 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2ecalleeMentions(ptr %v0, ptr %v1, ptr %t59, { i64, [7 x i64] } %t61, ptr %t62)
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 1
  %t68 = load %"compiler/mir:Range", ptr %t67
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v1, ptr %t66, %"compiler/mir:Range" %t68, ptr %t69)
  br label %bb18
bb18:
  store i32 0, ptr %l8, !tbaa !23
  %t73 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 2
  %t74 = getelementptr %"compiler/mir:Range", ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  store i32 %t75, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t77 = load i32, ptr %l9, !tbaa !23
  %t78 = load i32, ptr %l8, !tbaa !23
  %t81 = icmp sgt i32 %t77, %t78
  br i1 %t81, label %bb19, label %bb20
bb19:
  %t83 = load i32, ptr %l10, !tbaa !23
  %t85 = icmp sgt i32 %t83, 0
  br i1 %t85, label %bb21, label %bb22
bb20:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb24
bb21:
  %t87 = load i32, ptr %l9, !tbaa !23
  %t88 = load i32, ptr %l8, !tbaa !23
  %t91 = sub i32 %t87, %t88
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = add i32 %t91, %t92
  %t97 = sub i32 %t95, 1
  %t98 = load i32, ptr %l10, !tbaa !23
  %t101 = sdiv i32 %t97, %t98
  store i32 %t101, ptr %l53, !tbaa !23
  br label %bb23
bb22:
  store i32 0, ptr %l53, !tbaa !23
  br label %bb23
bb23:
  %t103 = load i32, ptr %l53, !tbaa !23
  store i32 %t103, ptr %l50, !tbaa !23
  br label %bb24
bb24:
  %t104 = load i32, ptr %l50, !tbaa !23
  store i32 %t104, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb25
bb25:
  %t105 = load i32, ptr %l12, !tbaa !23
  %t106 = load i32, ptr %l11, !tbaa !23
  %t109 = icmp slt i32 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t113 = load i32, ptr %l8, !tbaa !23
  %t114 = load i32, ptr %l12, !tbaa !23
  %t115 = load i32, ptr %l10, !tbaa !23
  %t118 = mul i32 %t114, %t115
  %t121 = add i32 %t113, %t118
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/mir:Fn", ptr %t124, i32 0, i32 12
  %t127 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 2
  %t128 = getelementptr %"compiler/mir:Range", ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t131 = sext i32 %t129 to i64
  %t134 = sext i32 %t121 to i64
  %t137 = add i64 %t131, %t134
  %t140 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t126, i64 %t137)
  store { i64, [1 x i64] } %t140, ptr %l79
  br label %bb29
bb29:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load ptr, ptr %l71, !tbaa !29
  %t143 = load { i64, [1 x i64] }, ptr %l79
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t142, { i64, [1 x i64] } %t143, ptr %t141)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t145 = load i32, ptr %l12, !tbaa !23
  %t148 = add i32 %t145, 1
  store i32 %t148, ptr %l12, !tbaa !23
  br label %bb25
bb32:
  %t150 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 4
  %t151 = load i1, ptr %t150, !tbaa !21
  br i1 %t151, label %bb33, label %bb34
bb33:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 3
  %t155 = load %"compiler/mir:Lvalue", ptr %t154
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %t153, %"compiler/mir:Lvalue" %t155, ptr %t156, ptr %t157)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t162 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 6
  %t163 = load i32, ptr %t162, !tbaa !23
  %t164 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t167 = icmp ne i32 %t163, %t164
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t170 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 6
  %t171 = load i32, ptr %t170, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v2, ptr %t169, i32 %t171)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb68
bb41:
  %t174 = load { i64, [8 x i64] }, ptr %l1
  %t176 = extractvalue { i64, [8 x i64] } %t174, 0
  %t177 = icmp eq i64 %t176, 5
  br i1 %t177, label %bb42, label %bb43
bb42:
  %t179 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t179, i32 0, i32 1
  %t181 = load { i64, [4 x i64] }, ptr %t180
  store { i64, [4 x i64] } %t181, ptr %l14
  br label %bb48
bb43:
  %t183 = load { i64, [8 x i64] }, ptr %l1
  %t185 = extractvalue { i64, [8 x i64] } %t183, 0
  %t186 = icmp eq i64 %t185, 7
  br i1 %t186, label %bb44, label %bb45
bb44:
  %t188 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t188, i32 0, i32 1
  %t190 = load { i64, [4 x i64] }, ptr %t189
  store { i64, [4 x i64] } %t190, ptr %l14
  br label %bb48
bb45:
  %t192 = load { i64, [8 x i64] }, ptr %l1
  %t194 = extractvalue { i64, [8 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 9
  br i1 %t195, label %bb46, label %bb47
bb46:
  %t197 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t197, i32 0, i32 2
  %t199 = load { i64, [4 x i64] }, ptr %t198
  store { i64, [4 x i64] } %t199, ptr %l14
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, [4 x i64] }, ptr %l14
  %t203 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t201, { i64, [4 x i64] } %t202, ptr %t203)
  br label %bb49
bb49:
  br label %bb68
bb50:
  %t207 = load { i64, [8 x i64] }, ptr %l1
  %t209 = extractvalue { i64, [8 x i64] } %t207, 0
  %t210 = icmp eq i64 %t209, 11
  br i1 %t210, label %bb51, label %bb52
bb51:
  %t212 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t212, i32 0, i32 1
  %t214 = load { i64, [4 x i64] }, ptr %t213
  store { i64, [4 x i64] } %t214, ptr %l15
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load { i64, [4 x i64] }, ptr %l15
  %t218 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t216, { i64, [4 x i64] } %t217, ptr %t218)
  br label %bb54
bb54:
  br label %bb68
bb55:
  %t222 = load { i64, [8 x i64] }, ptr %l1
  %t224 = extractvalue { i64, [8 x i64] } %t222, 0
  %t225 = icmp eq i64 %t224, 8
  br i1 %t225, label %bb56, label %bb57
bb56:
  %t227 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t228 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t227, i32 0, i32 3
  %t229 = load i32, ptr %t228
  store i32 %t229, ptr %l16, !tbaa !23
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t231 = load i32, ptr %l16, !tbaa !23
  %t232 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t235 = icmp ne i32 %t231, %t232
  br i1 %t235, label %bb59, label %bb60
bb59:
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t238 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v2, ptr %t237, i32 %t238)
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_db3046abc31727db_4ab50a6c65a9ddb7)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2ervMentions(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l123 = alloca i32
  %l126 = alloca i32
  %l144 = alloca ptr
  %l152 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l3
  br label %bb9
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 11
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l3
  br label %bb9
bb4:
  %t19 = load { i64, [15 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [15 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 17
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] } }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l3
  br label %bb9
bb6:
  %t28 = load { i64, [15 x i64] }, ptr %l1
  %t30 = extractvalue { i64, [15 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 24
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t34 = getelementptr { { i64, [4 x i64] } }, ptr %t33, i32 0, i32 0
  %t35 = load { i64, [4 x i64] }, ptr %t34
  store { i64, [4 x i64] } %t35, ptr %l3
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, [4 x i64] }, ptr %l3
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t37, { i64, [4 x i64] } %t38, ptr %t39)
  br label %bb10
bb10:
  br label %bb101
bb11:
  %t43 = load { i64, [15 x i64] }, ptr %l1
  %t45 = extractvalue { i64, [15 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 1
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t49 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t48, i32 0, i32 0
  %t50 = load %"compiler/mir:Lvalue", ptr %t49
  store %"compiler/mir:Lvalue" %t50, ptr %l4
  br label %bb20
bb13:
  %t52 = load { i64, [15 x i64] }, ptr %l1
  %t54 = extractvalue { i64, [15 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 2
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/mir:Lvalue", ptr %t58
  store %"compiler/mir:Lvalue" %t59, ptr %l4
  br label %bb20
bb15:
  %t61 = load { i64, [15 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [15 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 5
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t66, i32 0, i32 0
  %t68 = load %"compiler/mir:Lvalue", ptr %t67
  store %"compiler/mir:Lvalue" %t68, ptr %l4
  br label %bb20
bb17:
  %t70 = load { i64, [15 x i64] }, ptr %l1
  %t72 = extractvalue { i64, [15 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 23
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t76 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/mir:Lvalue", ptr %t76
  store %"compiler/mir:Lvalue" %t77, ptr %l4
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/mir:Lvalue", ptr %l4
  %t81 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v1, ptr %t79, %"compiler/mir:Lvalue" %t80, ptr %t81)
  br label %bb21
bb21:
  br label %bb101
bb22:
  %t85 = load { i64, [15 x i64] }, ptr %l1
  %t87 = extractvalue { i64, [15 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 3
  br i1 %t88, label %bb23, label %bb24
bb23:
  %t90 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t91 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t90, i32 0, i32 2
  %t92 = load %"compiler/mir:Range", ptr %t91
  store %"compiler/mir:Range" %t92, ptr %l5
  br label %bb29
bb24:
  %t94 = load { i64, [15 x i64] }, ptr %l1
  %t96 = extractvalue { i64, [15 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 4
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t99, i32 0, i32 2
  %t101 = load %"compiler/mir:Range", ptr %t100
  store %"compiler/mir:Range" %t101, ptr %l5
  br label %bb29
bb26:
  %t103 = load { i64, [15 x i64] }, ptr %l1
  %t105 = extractvalue { i64, [15 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 6
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t109 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t108, i32 0, i32 2
  %t110 = load %"compiler/mir:Range", ptr %t109
  store %"compiler/mir:Range" %t110, ptr %l5
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/mir:Range", ptr %l5
  %t114 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v1, ptr %t112, %"compiler/mir:Range" %t113, ptr %t114)
  br label %bb30
bb30:
  br label %bb101
bb31:
  %t118 = load { i64, [15 x i64] }, ptr %l1
  %t120 = extractvalue { i64, [15 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 7
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t124 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t123, i32 0, i32 0
  %t125 = load { i64, [1 x i64] }, ptr %t124
  store { i64, [1 x i64] } %t125, ptr %l6
  %t127 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t128 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t127, i32 0, i32 1
  %t129 = load { i64, [4 x i64] }, ptr %t128
  store { i64, [4 x i64] } %t129, ptr %l7
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, [1 x i64] }, ptr %l6
  %t133 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t131, { i64, [1 x i64] } %t132, ptr %t133)
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, [4 x i64] }, ptr %l7
  %t139 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t137, { i64, [4 x i64] } %t138, ptr %t139)
  br label %bb36
bb36:
  br label %bb101
bb37:
  %t143 = load { i64, [15 x i64] }, ptr %l1
  %t145 = extractvalue { i64, [15 x i64] } %t143, 0
  %t146 = icmp eq i64 %t145, 8
  br i1 %t146, label %bb38, label %bb39
bb38:
  %t148 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t149 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t148, i32 0, i32 0
  %t150 = load { i64, [1 x i64] }, ptr %t149
  store { i64, [1 x i64] } %t150, ptr %l8
  %t152 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t153 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, [4 x i64] }, ptr %t153
  store { i64, [4 x i64] } %t154, ptr %l9
  %t156 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t157 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t156, i32 0, i32 3
  %t158 = load { i64, [4 x i64] }, ptr %t157
  store { i64, [4 x i64] } %t158, ptr %l10
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, [1 x i64] }, ptr %l8
  %t162 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t160, { i64, [1 x i64] } %t161, ptr %t162)
  br label %bb41
bb41:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, [4 x i64] }, ptr %l9
  %t168 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t166, { i64, [4 x i64] } %t167, ptr %t168)
  br label %bb42
bb42:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, [4 x i64] }, ptr %l10
  %t174 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t172, { i64, [4 x i64] } %t173, ptr %t174)
  br label %bb43
bb43:
  br label %bb101
bb44:
  %t178 = load { i64, [15 x i64] }, ptr %l1
  %t180 = extractvalue { i64, [15 x i64] } %t178, 0
  %t181 = icmp eq i64 %t180, 9
  br i1 %t181, label %bb45, label %bb46
bb45:
  %t183 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t184 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t183, i32 0, i32 0
  %t185 = load %"compiler/mir:Lvalue", ptr %t184
  store %"compiler/mir:Lvalue" %t185, ptr %l11
  %t187 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t188 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t187, i32 0, i32 1
  %t189 = load { i64, [4 x i64] }, ptr %t188
  store { i64, [4 x i64] } %t189, ptr %l12
  %t191 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t192 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t191, i32 0, i32 2
  %t193 = load { i64, [4 x i64] }, ptr %t192
  store { i64, [4 x i64] } %t193, ptr %l13
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load %"compiler/mir:Lvalue", ptr %l11
  %t197 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v1, ptr %t195, %"compiler/mir:Lvalue" %t196, ptr %t197)
  br label %bb48
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, [4 x i64] }, ptr %l12
  %t203 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t201, { i64, [4 x i64] } %t202, ptr %t203)
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load { i64, [4 x i64] }, ptr %l13
  %t209 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t207, { i64, [4 x i64] } %t208, ptr %t209)
  br label %bb50
bb50:
  br label %bb101
bb51:
  %t213 = load { i64, [15 x i64] }, ptr %l1
  %t215 = extractvalue { i64, [15 x i64] } %t213, 0
  %t216 = icmp eq i64 %t215, 10
  br i1 %t216, label %bb52, label %bb53
bb52:
  %t218 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t219 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, [1 x i64] }, ptr %t219
  store { i64, [1 x i64] } %t220, ptr %l14
  %t222 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t223 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t222, i32 0, i32 3
  %t224 = load %"compiler/mir:Range", ptr %t223
  store %"compiler/mir:Range" %t224, ptr %l15
  %t226 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t227 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t226, i32 0, i32 4
  %t228 = load %"compiler/mir:Range", ptr %t227
  store %"compiler/mir:Range" %t228, ptr %l16
  br label %bb54
bb53:
  br label %bb71
bb54:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, [1 x i64] }, ptr %l14
  %t232 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t230, { i64, [1 x i64] } %t231, ptr %t232)
  br label %bb55
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load %"compiler/mir:Range", ptr %l15
  %t238 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v1, ptr %t236, %"compiler/mir:Range" %t237, ptr %t238)
  br label %bb56
bb56:
  store i32 0, ptr %l17, !tbaa !23
  %t242 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 1
  %t243 = load i32, ptr %t242, !tbaa !23
  store i32 %t243, ptr %l18, !tbaa !23
  store i32 1, ptr %l19, !tbaa !23
  %t245 = load i32, ptr %l18, !tbaa !23
  %t246 = load i32, ptr %l17, !tbaa !23
  %t249 = icmp sgt i32 %t245, %t246
  br i1 %t249, label %bb57, label %bb58
bb57:
  %t251 = load i32, ptr %l19, !tbaa !23
  %t253 = icmp sgt i32 %t251, 0
  br i1 %t253, label %bb59, label %bb60
bb58:
  store i32 0, ptr %l123, !tbaa !23
  br label %bb62
bb59:
  %t255 = load i32, ptr %l18, !tbaa !23
  %t256 = load i32, ptr %l17, !tbaa !23
  %t259 = sub i32 %t255, %t256
  %t260 = load i32, ptr %l19, !tbaa !23
  %t263 = add i32 %t259, %t260
  %t265 = sub i32 %t263, 1
  %t266 = load i32, ptr %l19, !tbaa !23
  %t269 = sdiv i32 %t265, %t266
  store i32 %t269, ptr %l126, !tbaa !23
  br label %bb61
bb60:
  store i32 0, ptr %l126, !tbaa !23
  br label %bb61
bb61:
  %t271 = load i32, ptr %l126, !tbaa !23
  store i32 %t271, ptr %l123, !tbaa !23
  br label %bb62
bb62:
  %t272 = load i32, ptr %l123, !tbaa !23
  store i32 %t272, ptr %l20, !tbaa !23
  store i32 0, ptr %l21, !tbaa !23
  br label %bb63
bb63:
  %t273 = load i32, ptr %l21, !tbaa !23
  %t274 = load i32, ptr %l20, !tbaa !23
  %t277 = icmp slt i32 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  br label %bb66
bb66:
  %t281 = load i32, ptr %l17, !tbaa !23
  %t282 = load i32, ptr %l21, !tbaa !23
  %t283 = load i32, ptr %l19, !tbaa !23
  %t286 = mul i32 %t282, %t283
  %t289 = add i32 %t281, %t286
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l144, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/mir:Fn", ptr %t292, i32 0, i32 12
  %t295 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 0
  %t296 = load i32, ptr %t295, !tbaa !23
  %t298 = sext i32 %t296 to i64
  %t301 = sext i32 %t289 to i64
  %t304 = add i64 %t298, %t301
  %t307 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t294, i64 %t304)
  store { i64, [1 x i64] } %t307, ptr %l152
  br label %bb67
bb67:
  %t308 = load ptr, ptr %l2, !tbaa !29
  %t309 = load ptr, ptr %l144, !tbaa !29
  %t310 = load { i64, [1 x i64] }, ptr %l152
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t309, { i64, [1 x i64] } %t310, ptr %t308)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t312 = load i32, ptr %l21, !tbaa !23
  %t315 = add i32 %t312, 1
  store i32 %t315, ptr %l21, !tbaa !23
  br label %bb63
bb70:
  br label %bb101
bb71:
  %t317 = load { i64, [15 x i64] }, ptr %l1
  %t319 = extractvalue { i64, [15 x i64] } %t317, 0
  %t320 = icmp eq i64 %t319, 12
  br i1 %t320, label %bb72, label %bb73
bb72:
  %t322 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t323 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t322, i32 0, i32 0
  %t324 = load { i64, [1 x i64] }, ptr %t323
  store { i64, [1 x i64] } %t324, ptr %l23
  %t326 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t327 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t326, i32 0, i32 1
  %t328 = load { i64, [1 x i64] }, ptr %t327
  store { i64, [1 x i64] } %t328, ptr %l24
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, [1 x i64] }, ptr %l23
  %t332 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t330, { i64, [1 x i64] } %t331, ptr %t332)
  br label %bb75
bb75:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, [1 x i64] }, ptr %l24
  %t338 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t336, { i64, [1 x i64] } %t337, ptr %t338)
  br label %bb76
bb76:
  br label %bb101
bb77:
  %t342 = load { i64, [15 x i64] }, ptr %l1
  %t344 = extractvalue { i64, [15 x i64] } %t342, 0
  %t345 = icmp eq i64 %t344, 13
  br i1 %t345, label %bb78, label %bb79
bb78:
  %t347 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t348 = getelementptr { { i64, [1 x i64] } }, ptr %t347, i32 0, i32 0
  %t349 = load { i64, [1 x i64] }, ptr %t348
  store { i64, [1 x i64] } %t349, ptr %l25
  br label %bb86
bb79:
  %t351 = load { i64, [15 x i64] }, ptr %l1
  %t353 = extractvalue { i64, [15 x i64] } %t351, 0
  %t354 = icmp eq i64 %t353, 14
  br i1 %t354, label %bb80, label %bb81
bb80:
  %t356 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t357 = getelementptr { { i64, [1 x i64] } }, ptr %t356, i32 0, i32 0
  %t358 = load { i64, [1 x i64] }, ptr %t357
  store { i64, [1 x i64] } %t358, ptr %l25
  br label %bb86
bb81:
  %t360 = load { i64, [15 x i64] }, ptr %l1
  %t362 = extractvalue { i64, [15 x i64] } %t360, 0
  %t363 = icmp eq i64 %t362, 15
  br i1 %t363, label %bb82, label %bb83
bb82:
  %t365 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t366 = getelementptr { { i64, [1 x i64] } }, ptr %t365, i32 0, i32 0
  %t367 = load { i64, [1 x i64] }, ptr %t366
  store { i64, [1 x i64] } %t367, ptr %l25
  br label %bb86
bb83:
  %t369 = load { i64, [15 x i64] }, ptr %l1
  %t371 = extractvalue { i64, [15 x i64] } %t369, 0
  %t372 = icmp eq i64 %t371, 20
  br i1 %t372, label %bb84, label %bb85
bb84:
  %t374 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t375 = getelementptr { { i64, [1 x i64] } }, ptr %t374, i32 0, i32 0
  %t376 = load { i64, [1 x i64] }, ptr %t375
  store { i64, [1 x i64] } %t376, ptr %l25
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load { i64, [1 x i64] }, ptr %l25
  %t380 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t378, { i64, [1 x i64] } %t379, ptr %t380)
  br label %bb87
bb87:
  br label %bb101
bb88:
  %t384 = load { i64, [15 x i64] }, ptr %l1
  %t386 = extractvalue { i64, [15 x i64] } %t384, 0
  %t387 = icmp eq i64 %t386, 16
  br i1 %t387, label %bb89, label %bb90
bb89:
  %t389 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t390 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t389, i32 0, i32 0
  %t391 = load { i64, [4 x i64] }, ptr %t390
  store { i64, [4 x i64] } %t391, ptr %l26
  %t393 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t394 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t393, i32 0, i32 1
  %t395 = load { i64, [1 x i64] }, ptr %t394
  store { i64, [1 x i64] } %t395, ptr %l27
  br label %bb93
bb90:
  %t397 = load { i64, [15 x i64] }, ptr %l1
  %t399 = extractvalue { i64, [15 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 18
  br i1 %t400, label %bb91, label %bb92
bb91:
  %t402 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t403 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] } }, ptr %t402, i32 0, i32 0
  %t404 = load { i64, [1 x i64] }, ptr %t403
  store { i64, [1 x i64] } %t404, ptr %l27
  %t406 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t407 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] } }, ptr %t406, i32 0, i32 1
  %t408 = load { i64, [4 x i64] }, ptr %t407
  store { i64, [4 x i64] } %t408, ptr %l26
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load { i64, [4 x i64] }, ptr %l26
  %t412 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %t410, { i64, [4 x i64] } %t411, ptr %t412)
  br label %bb94
bb94:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load { i64, [1 x i64] }, ptr %l27
  %t418 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %t416, { i64, [1 x i64] } %t417, ptr %t418)
  br label %bb95
bb95:
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_6ed074f69d52fee5_6027e9a1c2de62d1)
  unreachable
bb101:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eholdsArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i1
  %l53 = alloca i32
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l87 = alloca i32
  %l90 = alloca i1
  %l98 = alloca i1
  %l101 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l135 = alloca i32
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:GenInfo", ptr %t5, i32 0, i32 11
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l23
  br label %bb3
bb3:
  %t12 = load i1, ptr %l23, !tbaa !21
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:GenInfo", ptr %t15, i32 0, i32 11
  %t18 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t17, i32 %t18, i1 true)
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l30
  br label %bb9
bb9:
  %t26 = load i32, ptr %l30, !range !{i32 0, i32 33}
  store i32 %t26, ptr %l4
  %t27 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t29 = trunc i64 21 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t32 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t34 = trunc i64 29 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l33, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t40 = trunc i64 25 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l36, !tbaa !21
  br i1 %t43, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t45 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t47 = trunc i64 20 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l46
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t57 = load ptr, ptr %l43, !tbaa !29
  %t58 = load i32, ptr %l46, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t57, i32 %t58)
  store i32 %t59, ptr %l47
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l42, !tbaa !29
  %t61 = load i32, ptr %l47, !tbaa !23
  %t62 = call i1 @compiler_2fmir_2erunArray(ptr %v1, ptr %t60, i32 %t61)
  store i1 %t62, ptr %l48
  br label %bb23
bb23:
  %t63 = load i1, ptr %l48, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb24:
  %t64 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t66 = trunc i64 19 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v1, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l53
  br label %bb27
bb26:
  br label %bb34
bb27:
  %t74 = load i32, ptr %l53, !tbaa !23
  %t75 = icmp eq i32 %t74, 0
  br i1 %t75, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb33
bb29:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l56, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l57, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l58, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v1, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l61
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l58, !tbaa !29
  %t86 = load i32, ptr %l61, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t85, i32 %t86)
  store i32 %t87, ptr %l62
  br label %bb31
bb31:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t92 = load ptr, ptr %l57, !tbaa !29
  %t93 = load i32, ptr %l62, !tbaa !23
  %t95 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eholdsArray(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i32 %t93, i64 %t90)
  store i1 %t95, ptr %l65
  br label %bb32
bb32:
  %t96 = load i1, ptr %l65, !tbaa !21
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l55, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i1 @compiler_2fmir_2eHasFields(ptr %v1, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l68
  br label %bb35
bb35:
  %t103 = load i1, ptr %l68, !tbaa !21
  br i1 %t103, label %bb36, label %bb37
bb36:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l69, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t106 = load i32, ptr %l2, !tbaa !23
  %t109 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v1, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l72
  br label %bb38
bb37:
  br label %bb51
bb38:
  %t110 = load ptr, ptr %l69, !tbaa !29
  %t111 = load i32, ptr %l72, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t110, i32 %t111)
  store { i64, ptr } %t112, ptr %l73
  br label %bb39
bb39:
  %t113 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t113, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb50
bb42:
  br label %bb43
bb43:
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t126, ptr %l80, !tbaa !27
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l83, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l84, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t136, i32 %t132)
  store i32 %t140, ptr %l87
  br label %bb44
bb44:
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = add i64 %t141, 1
  %t144 = load ptr, ptr %l83, !tbaa !29
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t146 = load i32, ptr %l87, !tbaa !23
  %t148 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eholdsArray(ptr %v0, ptr %v1, ptr %t144, ptr %t145, i32 %t146, i64 %t143)
  store i1 %t148, ptr %l90
  br label %bb45
bb45:
  %t149 = load i1, ptr %l90, !tbaa !21
  br i1 %t149, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t151 = load i64, ptr %l6, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l6, !tbaa !24
  br label %bb40
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t158 = load i32, ptr %l2, !tbaa !23
  %t161 = call i1 @compiler_2fmir_2eHasCases(ptr %v1, ptr %t157, i32 %t158)
  store i1 %t161, ptr %l98
  br label %bb52
bb52:
  %t162 = load i1, ptr %l98, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb53, label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t166 = load ptr, ptr %l1, !tbaa !29
  store ptr %t166, ptr %l101, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load i32, ptr %l2, !tbaa !23
  %t171 = call i32 @compiler_2fmir_2eCasesOf(ptr %v1, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l104
  br label %bb56
bb56:
  %t172 = load ptr, ptr %l101, !tbaa !29
  %t173 = load i32, ptr %l104, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l105
  br label %bb57
bb57:
  %t175 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t175, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  store i64 %t178, ptr %l11, !tbaa !24
  br label %bb58
bb58:
  %t180 = load i64, ptr %l10, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb59, label %bb60
bb59:
  br label %bb79
bb60:
  br label %bb61
bb61:
  %t188 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t188, ptr %l112, !tbaa !27
  %t189 = load i64, ptr %l10, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t189
  %t194 = load i32, ptr %t193, !tbaa !33
  store i32 %t194, ptr %l12, !tbaa !23
  %t196 = load i32, ptr %l12, !tbaa !23
  %t198 = icmp eq i32 %t196, 0
  br i1 %t198, label %bb62, label %bb63
bb62:
  br label %bb78
bb63:
  br label %bb64
bb64:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l117, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t202 = load i32, ptr %l12, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v1, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l120
  br label %bb65
bb65:
  %t206 = load ptr, ptr %l117, !tbaa !29
  %t207 = load i32, ptr %l120, !tbaa !23
  %t208 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t206, i32 %t207)
  store { i64, ptr } %t208, ptr %l121
  br label %bb66
bb66:
  %t209 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t209, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l15, !tbaa !24
  br label %bb67
bb67:
  %t214 = load i64, ptr %l14, !tbaa !24
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb68, label %bb69
bb68:
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t222 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t222, ptr %l128, !tbaa !27
  %t223 = load i64, ptr %l14, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l131, !tbaa !29
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l132, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t232, i32 %t228)
  store i32 %t236, ptr %l135
  br label %bb71
bb71:
  %t237 = load i64, ptr %l3, !tbaa !24
  %t239 = add i64 %t237, 1
  %t240 = load ptr, ptr %l131, !tbaa !29
  %t241 = load ptr, ptr %l132, !tbaa !29
  %t242 = load i32, ptr %l135, !tbaa !23
  %t244 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eholdsArray(ptr %v0, ptr %v1, ptr %t240, ptr %t241, i32 %t242, i64 %t239)
  store i1 %t244, ptr %l138
  br label %bb72
bb72:
  %t245 = load i1, ptr %l138, !tbaa !21
  br i1 %t245, label %bb73, label %bb74
bb73:
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t247 = load i64, ptr %l14, !tbaa !24
  %t250 = add i64 %t247, 1
  store i64 %t250, ptr %l14, !tbaa !24
  br label %bb67
bb77:
  br label %bb78
bb78:
  %t252 = load i64, ptr %l10, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l10, !tbaa !24
  br label %bb58
bb79:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eleavesThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i1
  %l26 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i32
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l91 = alloca i64
  %l94 = alloca i64
  %l116 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca i32
  %l128 = alloca i1
  %l136 = alloca i1
  %l139 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l173 = alloca i32
  %l176 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:GenInfo", ptr %t5, i32 0, i32 11
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l26
  br label %bb3
bb3:
  %t12 = load i1, ptr %l26, !tbaa !21
  store i1 %t12, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l22, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:GenInfo", ptr %t15, i32 0, i32 11
  %t18 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t17, i32 %t18, i1 true)
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2enote(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i32 %t23)
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t33 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %t27, ptr %t28, i32 %t29)
  store i1 %t33, ptr %l37
  br label %bb10
bb10:
  %t34 = load i1, ptr %l37, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t37 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eLeaves(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i32 %t37)
  store i1 %t41, ptr %l42
  br label %bb13
bb12:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l42, !tbaa !21
  store i1 %t42, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l38, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l46
  br label %bb18
bb18:
  %t50 = load i32, ptr %l46, !range !{i32 0, i32 33}
  store i32 %t50, ptr %l4
  %t51 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t53 = trunc i64 20 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l49, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l50, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l53
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t63 = load ptr, ptr %l49, !tbaa !29
  %t64 = load ptr, ptr %l50, !tbaa !29
  %t65 = load i32, ptr %l53, !tbaa !23
  %t66 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65)
  store i1 %t66, ptr %l54
  br label %bb22
bb22:
  %t67 = load i1, ptr %l54, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l56, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l57, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l58, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l61
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb28
bb25:
  %t76 = load ptr, ptr %l58, !tbaa !29
  %t77 = load i32, ptr %l61, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l62
  br label %bb26
bb26:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = add i64 %t79, 1
  %t82 = load ptr, ptr %l56, !tbaa !29
  %t83 = load ptr, ptr %l57, !tbaa !29
  %t84 = load i32, ptr %l62, !tbaa !23
  %t86 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eleavesThrough(ptr %v0, ptr %v1, ptr %t82, ptr %t83, i32 %t84, i64 %t81)
  store i1 %t86, ptr %l65
  br label %bb27
bb27:
  %t87 = load i1, ptr %l65, !tbaa !21
  store i1 %t87, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l55, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb29:
  %t89 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t91 = trunc i64 19 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb30, label %bb31
bb30:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l68, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l69, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l70, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v1, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l73
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t102 = load ptr, ptr %l70, !tbaa !29
  %t103 = load i32, ptr %l73, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l74
  br label %bb33
bb33:
  %t105 = load i64, ptr %l3, !tbaa !24
  %t107 = add i64 %t105, 1
  %t108 = load ptr, ptr %l68, !tbaa !29
  %t109 = load ptr, ptr %l69, !tbaa !29
  %t110 = load i32, ptr %l74, !tbaa !23
  %t112 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eleavesThrough(ptr %v0, ptr %v1, ptr %t108, ptr %t109, i32 %t110, i64 %t107)
  store i1 %t112, ptr %l77
  br label %bb34
bb34:
  %t113 = load i1, ptr %l77, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb35:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t115 = load i32, ptr %l2, !tbaa !23
  %t118 = call i1 @compiler_2fmir_2eHasFields(ptr %v1, ptr %t114, i32 %t115)
  store i1 %t118, ptr %l80
  br label %bb36
bb36:
  %t119 = load i1, ptr %l80, !tbaa !21
  br i1 %t119, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l81, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load i32, ptr %l2, !tbaa !23
  %t125 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v1, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l84
  br label %bb39
bb38:
  br label %bb62
bb39:
  %t126 = load ptr, ptr %l81, !tbaa !29
  %t127 = load i32, ptr %l84, !tbaa !23
  %t128 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t126, i32 %t127)
  store { i64, ptr } %t128, ptr %l85
  br label %bb40
bb40:
  %t129 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t129, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb41, label %bb42
bb41:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb46
bb43:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l6, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l94, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb45
bb45:
  %t160 = load i64, ptr %l94, !tbaa !24
  store i64 %t160, ptr %l91, !tbaa !24
  br label %bb46
bb46:
  %t161 = load i64, ptr %l91, !tbaa !24
  store i64 %t161, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb47
bb47:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t163 = load i64, ptr %l9, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb48, label %bb49
bb48:
  br label %bb61
bb49:
  br label %bb50
bb50:
  %t170 = load i64, ptr %l6, !tbaa !24
  %t171 = load i64, ptr %l10, !tbaa !24
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l11, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t183 = load i64, ptr %l11, !tbaa !24
  %t188 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %t180, ptr %t181, i32 %t182, i64 %t183)
  store i1 %t188, ptr %l116
  br label %bb51
bb51:
  %t189 = load i1, ptr %l116, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb52, label %bb53
bb52:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l119, !tbaa !29
  %t193 = load ptr, ptr %l1, !tbaa !29
  store ptr %t193, ptr %l120, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t195, ptr %l122, !tbaa !27
  %t196 = load i64, ptr %l11, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i32, ptr %t199, i64 %t196
  %t201 = load i32, ptr %t200, !tbaa !33
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t194, i32 %t201)
  store i32 %t204, ptr %l125
  br label %bb54
bb53:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb56
bb54:
  %t205 = load i64, ptr %l3, !tbaa !24
  %t207 = add i64 %t205, 1
  %t208 = load ptr, ptr %l119, !tbaa !29
  %t209 = load ptr, ptr %l120, !tbaa !29
  %t210 = load i32, ptr %l125, !tbaa !23
  %t212 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eleavesThrough(ptr %v0, ptr %v1, ptr %t208, ptr %t209, i32 %t210, i64 %t207)
  store i1 %t212, ptr %l128
  br label %bb55
bb55:
  %t213 = load i1, ptr %l128, !tbaa !21
  store i1 %t213, ptr %l118, !tbaa !21
  br label %bb56
bb56:
  %t214 = load i1, ptr %l118, !tbaa !21
  br i1 %t214, label %bb57, label %bb58
bb57:
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l10, !tbaa !24
  br label %bb47
bb61:
  store i1 false, ptr %rv
  br label %ret
bb62:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load i32, ptr %l2, !tbaa !23
  %t226 = call i1 @compiler_2fmir_2eHasCases(ptr %v1, ptr %t222, i32 %t223)
  store i1 %t226, ptr %l136
  br label %bb63
bb63:
  %t227 = load i1, ptr %l136, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb64, label %bb65
bb64:
  store i1 false, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l139, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t233 = load i32, ptr %l2, !tbaa !23
  %t236 = call i32 @compiler_2fmir_2eCasesOf(ptr %v1, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l142
  br label %bb67
bb67:
  %t237 = load ptr, ptr %l139, !tbaa !29
  %t238 = load i32, ptr %l142, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t237, i32 %t238)
  store { i64, ptr } %t239, ptr %l143
  br label %bb68
bb68:
  %t240 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t240, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l14, !tbaa !24
  br label %bb69
bb69:
  %t245 = load i64, ptr %l13, !tbaa !24
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb70, label %bb71
bb70:
  br label %bb90
bb71:
  br label %bb72
bb72:
  %t253 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t253, ptr %l150, !tbaa !27
  %t254 = load i64, ptr %l13, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i32, ptr %t257, i64 %t254
  %t259 = load i32, ptr %t258, !tbaa !33
  store i32 %t259, ptr %l15, !tbaa !23
  %t261 = load i32, ptr %l15, !tbaa !23
  %t263 = icmp eq i32 %t261, 0
  br i1 %t263, label %bb73, label %bb74
bb73:
  br label %bb89
bb74:
  br label %bb75
bb75:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l155, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t267 = load i32, ptr %l15, !tbaa !23
  %t270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v1, ptr %t266, i32 %t267)
  store i32 %t270, ptr %l158
  br label %bb76
bb76:
  %t271 = load ptr, ptr %l155, !tbaa !29
  %t272 = load i32, ptr %l158, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t271, i32 %t272)
  store { i64, ptr } %t273, ptr %l159
  br label %bb77
bb77:
  %t274 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t274, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t275 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l18, !tbaa !24
  br label %bb78
bb78:
  %t279 = load i64, ptr %l17, !tbaa !24
  %t280 = load i64, ptr %l18, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb79, label %bb80
bb79:
  br label %bb88
bb80:
  br label %bb81
bb81:
  %t287 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t287, ptr %l166, !tbaa !27
  %t288 = load i64, ptr %l17, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i32, ptr %t291, i64 %t288
  %t293 = load i32, ptr %t292, !tbaa !33
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l169, !tbaa !29
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l170, !tbaa !29
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t301 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t297, i32 %t293)
  store i32 %t301, ptr %l173
  br label %bb82
bb82:
  %t302 = load i64, ptr %l3, !tbaa !24
  %t304 = add i64 %t302, 1
  %t305 = load ptr, ptr %l169, !tbaa !29
  %t306 = load ptr, ptr %l170, !tbaa !29
  %t307 = load i32, ptr %l173, !tbaa !23
  %t309 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eleavesThrough(ptr %v0, ptr %v1, ptr %t305, ptr %t306, i32 %t307, i64 %t304)
  store i1 %t309, ptr %l176
  br label %bb83
bb83:
  %t310 = load i1, ptr %l176, !tbaa !21
  br i1 %t310, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t312 = load i64, ptr %l17, !tbaa !24
  %t315 = add i64 %t312, 1
  store i64 %t315, ptr %l17, !tbaa !24
  br label %bb78
bb88:
  br label %bb89
bb89:
  %t317 = load i64, ptr %l13, !tbaa !24
  %t320 = add i64 %t317, 1
  store i64 %t320, ptr %l13, !tbaa !24
  br label %bb69
bb90:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  %t11 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %v2, ptr %t6, %"compiler/mir:Lvalue" %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  call void @olang_textcopy(ptr %t19, ptr %t15, i64 %t16)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  %t23 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t23, { i64, ptr } %t21)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  store ptr %l2, ptr %l11, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t27 = load { i64, [7 x i64] }, ptr %t26
  %t30 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %v3, ptr %v2, ptr %t25, { i64, [7 x i64] } %t27)
  store { i64, ptr } %t30, ptr %l14
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t33 = load %"compiler/mir:Range", ptr %t32
  %t36 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t31, %"compiler/mir:Range" %t33)
  store { i64, ptr } %t36, ptr %l17
  br label %bb8
bb8:
  %t37 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = add i64 %t38, %t41
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t37, i64 %t38)
  %t54 = getelementptr i8, ptr %t53, i64 %t38
  call void @olang_textcopy(ptr %t54, ptr %t40, i64 %t41)
  %t55 = getelementptr i8, ptr %t54, i64 %t41
  call void @olang_textcopy(ptr %t55, ptr %t43, i64 %t44)
  %t56 = getelementptr i8, ptr %t55, i64 %t44
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t50, i64 %t51)
  %t58 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t53, 1
  %t61 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t61, { i64, ptr } %t59)
  br label %bb9
bb9:
  %t63 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t64 = getelementptr %"compiler/mir:Range", ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = icmp sgt i32 %t65, 0
  br i1 %t67, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l22, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t71 = load %"compiler/mir:Range", ptr %t70
  %t74 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s4, ptr %v2, ptr %t69, %"compiler/mir:Range" %t71)
  store { i64, ptr } %t74, ptr %l25
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t75 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t77 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t75, i64 %t76)
  %t85 = getelementptr i8, ptr %t84, i64 %t76
  call void @olang_textcopy(ptr %t85, ptr %t78, i64 %t79)
  %t86 = getelementptr i8, ptr %t85, i64 %t79
  call void @olang_textcopy(ptr %t86, ptr %t81, i64 %t82)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t84, 1
  %t90 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t90, { i64, ptr } %t88)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t92 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t93 = load i32, ptr %t92, !tbaa !23
  %t94 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t97 = sext i32 %t93 to i64
  %t98 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t97)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t100, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t104)
  br label %bb15
bb15:
  %t108 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t113 = icmp ne i32 %t109, %t110
  br i1 %t113, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t116 = load i32, ptr %t115, !tbaa !23
  %t117 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t122 = sext i32 %t116 to i64
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t129 = sext i32 %t118 to i64
  %t130 = call i64 @__olang_fmt_i64(ptr null, i64 %t129)
  %t131 = add i64 %t127, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t119, i64 %t120)
  %t133 = getelementptr i8, ptr %t132, i64 %t120
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t122)
  %t135 = getelementptr i8, ptr %t133, i64 %t123
  call void @olang_textcopy(ptr %t135, ptr %t125, i64 %t126)
  %t136 = getelementptr i8, ptr %t135, i64 %t126
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %t129)
  %t138 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t132, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t139)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb19
bb19:
  %t144 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t144, ptr %l41
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i64
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %v2, ptr %t10, { i64, [2 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l14
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  br label %bb25
bb5:
  %t16 = load { i64, [7 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { i64, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t29 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %l8, !tbaa !27
  br label %bb25
bb9:
  %t37 = load { i64, [7 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [7 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 2
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [4 x i64] } }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l4
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l4
  %t50 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %v3, ptr %v2, ptr %t46, { i64, [4 x i64] } %t47)
  store { i64, ptr } %t50, ptr %l25
  br label %bb13
bb13:
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb14:
  %t66 = load { i64, [7 x i64] }, ptr %l1
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 3
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t72 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t73, ptr %l5
  %t75 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t76 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l31, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, [4 x i64] }, ptr %l5
  %t84 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %v3, ptr %v2, ptr %t80, { i64, [4 x i64] } %t81)
  store { i64, ptr } %t84, ptr %l34
  br label %bb18
bb18:
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t87 = load i64, ptr %l31, !tbaa !24
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t85, i64 %t86)
  %t101 = getelementptr i8, ptr %t100, i64 %t86
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t87)
  %t103 = getelementptr i8, ptr %t101, i64 %t88
  call void @olang_textcopy(ptr %t103, ptr %t90, i64 %t91)
  %t104 = getelementptr i8, ptr %t103, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t94, i64 %t95)
  %t105 = getelementptr i8, ptr %t104, i64 %t95
  call void @olang_textcopy(ptr %t105, ptr %t97, i64 %t98)
  %t106 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t100, 1
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb19:
  %t109 = load { i64, [7 x i64] }, ptr %l1
  %t111 = extractvalue { i64, [7 x i64] } %t109, 0
  %t112 = icmp eq i64 %t111, 4
  br i1 %t112, label %bb20, label %bb21
bb20:
  %t114 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t115 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %t114, i32 0, i32 0
  %t116 = load { i64, [4 x i64] }, ptr %t115
  store { i64, [4 x i64] } %t116, ptr %l7
  br label %bb22
bb21:
  br label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s8
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, [4 x i64] }, ptr %l7
  %t122 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s8, ptr %v3, ptr %v2, ptr %t118, { i64, [4 x i64] } %t119)
  store { i64, ptr } %t122, ptr %l41
  br label %bb23
bb23:
  %t123 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t125 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267)
  unreachable
bb25:
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t138, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:dumper", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/mir:dumper", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v2, ptr %t15)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t11 to ptr
  %t23 = inttoptr i64 %t19 to ptr
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t21, ptr %t23, ptr %t24, i32 %a1)
  store { i64, ptr } %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb3, label %bb4
bb3:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t59 = load i64, ptr %l24, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  store ptr %l2, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l48, !tbaa !27
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/mir:dumper", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l50, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t86, ptr %l51, !tbaa !27
  %t87 = load i64, ptr %l9, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t87
  %t92 = load i32, ptr %t91, !tbaa !33
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = call ptr @__olang_scope_or(ptr %v2, ptr %t93)
  %t95 = call ptr @__olang_scope_hold(ptr %t94)
  %t96 = ptrtoint ptr %t95 to i64
  %t98 = inttoptr i64 %t96 to ptr
  %t100 = inttoptr i64 0 to ptr
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t98, ptr %s2, ptr %t100, ptr %t101, i32 %t92)
  store { i64, ptr } %t103, ptr %l56
  br label %bb16
bb16:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t116, { i64, ptr } %t114)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t124 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t124, ptr %l63
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Lvalue"
  %l16 = alloca i32
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca %"compiler/mir:Range"
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i1
  %l122 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i1
  %l132 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l143 = alloca i64
  %l146 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l167 = alloca i32
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca i1
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca i1
  %l207 = alloca i32
  %l208 = alloca ptr
  %l211 = alloca ptr
  %l215 = alloca %"compiler/mir:Task"
  %l216 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l219 = alloca i1
  %l222 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l225 = alloca i1
  %l232 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l235 = alloca i1
  %l238 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca i1
  %l250 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l256 = alloca i1
  %l267 = alloca { i64, ptr }
  %l269 = alloca ptr
  %l273 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i1
  %l286 = alloca i32
  %l290 = alloca { i64, ptr }
  %l295 = alloca i64
  %l296 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t602 = alloca %"compiler/mir:Task", align 8
  %t608 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t2 = load ptr, ptr %l34, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l34, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l35, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %v3, ptr %t22, %"compiler/mir:Lvalue" %t23)
  store { i64, ptr } %t26, ptr %l44
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l3
  %t31 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %s1, ptr %v3, ptr %v4, ptr %t27, { i64, [15 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l47
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = getelementptr i8, ptr %t43, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  store { i64, ptr } %t46, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb148
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t49 = load ptr, ptr %l49, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %l49, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 20}
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l50, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l50, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [21 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = getelementptr i8, ptr %t70, i64 %t65
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t67)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  store { i64, ptr } %t74, ptr %l33, !tbaa !27
  br label %bb148
bb14:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l57, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 20}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t91 = load i32, ptr %l5, !tbaa !23
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t95 = sext i32 %t91 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t92, i64 %t93)
  %t99 = getelementptr i8, ptr %t98, i64 %t93
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t95)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l33, !tbaa !27
  br label %bb148
bb20:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t105 = load ptr, ptr %l65, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %l65, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 20}
  %t111 = icmp eq i64 %t109, 3
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t112 = load i1, ptr %l66, !tbaa !21
  br i1 %t112, label %bb23, label %bb24
bb23:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32 }, ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l6, !tbaa !23
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t123 = sext i32 %t119 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  %t128 = call i64 @__olang_fmt_i64(ptr %t127, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l33, !tbaa !27
  br label %bb148
bb26:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t133 = load ptr, ptr %l73, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l73, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 20}
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb28
bb28:
  %t140 = load i1, ptr %l74, !tbaa !21
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32 }, ptr %t143, i32 0, i32 1
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l7, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t147 = load i32, ptr %l7, !tbaa !23
  %t148 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t151 = sext i32 %t147 to i64
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t151)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l33, !tbaa !27
  br label %bb148
bb32:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t161 = load ptr, ptr %l81, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = load ptr, ptr %l81, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 20}
  %t167 = icmp eq i64 %t165, 5
  store i1 %t167, ptr %l82, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l82, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t171, i32 0, i32 1
  %t173 = load { i64, [1 x i64] }, ptr %t172
  store { i64, [1 x i64] } %t173, ptr %l8
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t177, i32 0, i32 2
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l9, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t183, i32 0, i32 3
  %t185 = load { i64, [4 x i64] }, ptr %t184
  store { i64, [4 x i64] } %t185, ptr %l10
  br label %bb37
bb36:
  br label %bb41
bb37:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/mir:dumper", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  store ptr %t190, ptr %l92, !tbaa !29
  %t191 = load i32, ptr %l9, !tbaa !23
  %t192 = load ptr, ptr %l92, !tbaa !29
  %t193 = call ptr @__olang_scope_or(ptr %v4, ptr %t192)
  %t194 = call ptr @__olang_scope_hold(ptr %t193)
  %t195 = ptrtoint ptr %t194 to i64
  %t197 = inttoptr i64 %t195 to ptr
  %t199 = inttoptr i64 0 to ptr
  %t200 = load ptr, ptr %l92, !tbaa !29
  %t202 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t197, ptr %s11, ptr %t199, ptr %t200, i32 %t191)
  store { i64, ptr } %t202, ptr %l96
  br label %bb38
bb38:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [4 x i64] }, ptr %l10
  %t207 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %v3, ptr %v4, ptr %t203, { i64, [4 x i64] } %t204)
  store { i64, ptr } %t207, ptr %l99
  br label %bb39
bb39:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, [1 x i64] }, ptr %l8
  %t212 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s11, ptr %t208, { i64, [1 x i64] } %t209)
  store { i64, ptr } %t212, ptr %l102
  br label %bb40
bb40:
  %t213 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t215 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t213, i64 %t214)
  %t234 = getelementptr i8, ptr %t233, i64 %t214
  call void @olang_textcopy(ptr %t234, ptr %t216, i64 %t217)
  %t235 = getelementptr i8, ptr %t234, i64 %t217
  call void @olang_textcopy(ptr %t235, ptr %t219, i64 %t220)
  %t236 = getelementptr i8, ptr %t235, i64 %t220
  call void @olang_textcopy(ptr %t236, ptr %t223, i64 %t224)
  %t237 = getelementptr i8, ptr %t236, i64 %t224
  call void @olang_textcopy(ptr %t237, ptr %t226, i64 %t227)
  %t238 = getelementptr i8, ptr %t237, i64 %t227
  call void @olang_textcopy(ptr %t238, ptr %t230, i64 %t231)
  %t239 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t233, 1
  store { i64, ptr } %t240, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb148
bb41:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t243 = load ptr, ptr %l104, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb42, label %bb43
bb42:
  %t246 = load ptr, ptr %l104, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 20}
  %t249 = icmp eq i64 %t247, 6
  store i1 %t249, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t250 = load i1, ptr %l105, !tbaa !21
  br i1 %t250, label %bb44, label %bb45
bb44:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [21 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t253, i32 0, i32 1
  %t255 = load %"compiler/mir:Lvalue", ptr %t254
  store %"compiler/mir:Lvalue" %t255, ptr %l11
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/mir:Lvalue", ptr %l11
  %t261 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s13, ptr %v3, ptr %t257, %"compiler/mir:Lvalue" %t258)
  store { i64, ptr } %t261, ptr %l112
  br label %bb47
bb47:
  %t262 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t264 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t262, i64 %t263)
  %t269 = getelementptr i8, ptr %t268, i64 %t263
  call void @olang_textcopy(ptr %t269, ptr %t265, i64 %t266)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t268, 1
  store { i64, ptr } %t271, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb148
bb48:
  %t273 = load ptr, ptr %l1, !tbaa !29
  store ptr %t273, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t274 = load ptr, ptr %l114, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb49, label %bb50
bb49:
  %t277 = load ptr, ptr %l114, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 20}
  %t280 = icmp eq i64 %t278, 7
  store i1 %t280, ptr %l115, !tbaa !21
  br label %bb50
bb50:
  %t281 = load i1, ptr %l115, !tbaa !21
  br i1 %t281, label %bb51, label %bb52
bb51:
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t284 = getelementptr { i64, [21 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t284, i32 0, i32 1
  %t286 = load %"compiler/mir:Lvalue", ptr %t285
  store %"compiler/mir:Lvalue" %t286, ptr %l12
  br label %bb53
bb52:
  br label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load %"compiler/mir:Lvalue", ptr %l12
  %t292 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s15, ptr %v3, ptr %t288, %"compiler/mir:Lvalue" %t289)
  store { i64, ptr } %t292, ptr %l122
  br label %bb54
bb54:
  %t293 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t295 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = add i64 %t294, %t297
  %t299 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t298)
  call void @olang_textcopy(ptr %t299, ptr %t293, i64 %t294)
  %t300 = getelementptr i8, ptr %t299, i64 %t294
  call void @olang_textcopy(ptr %t300, ptr %t296, i64 %t297)
  %t301 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t299, 1
  store { i64, ptr } %t302, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb148
bb55:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t305 = load ptr, ptr %l124, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb56, label %bb57
bb56:
  %t308 = load ptr, ptr %l124, !tbaa !29
  %t309 = load i64, ptr %t308, !range !{i64 0, i64 20}
  %t311 = icmp eq i64 %t309, 8
  store i1 %t311, ptr %l125, !tbaa !21
  br label %bb57
bb57:
  %t312 = load i1, ptr %l125, !tbaa !21
  br i1 %t312, label %bb58, label %bb59
bb58:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [21 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t315, i32 0, i32 1
  %t317 = load %"compiler/mir:Lvalue", ptr %t316
  store %"compiler/mir:Lvalue" %t317, ptr %l13
  br label %bb60
bb59:
  br label %bb62
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/mir:Lvalue", ptr %l13
  %t323 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s17, ptr %v3, ptr %t319, %"compiler/mir:Lvalue" %t320)
  store { i64, ptr } %t323, ptr %l132
  br label %bb61
bb61:
  %t324 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t326 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t324, i64 %t325)
  %t331 = getelementptr i8, ptr %t330, i64 %t325
  call void @olang_textcopy(ptr %t331, ptr %t327, i64 %t328)
  %t332 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t330, 1
  store { i64, ptr } %t333, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb148
bb62:
  %t335 = load ptr, ptr %l1, !tbaa !29
  store ptr %t335, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t336 = load ptr, ptr %l134, !tbaa !29
  %t337 = icmp ne ptr %t336, null
  br i1 %t337, label %bb63, label %bb64
bb63:
  %t339 = load ptr, ptr %l134, !tbaa !29
  %t340 = load i64, ptr %t339, !range !{i64 0, i64 20}
  %t342 = icmp eq i64 %t340, 9
  store i1 %t342, ptr %l135, !tbaa !21
  br label %bb64
bb64:
  %t343 = load i1, ptr %l135, !tbaa !21
  br i1 %t343, label %bb65, label %bb66
bb65:
  %t344 = load ptr, ptr %l1, !tbaa !29
  %t346 = getelementptr { i64, [21 x i64] }, ptr %t344, i32 0, i32 1
  %t347 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t346, i32 0, i32 1
  %t348 = load i32, ptr %t347
  store i32 %t348, ptr %l14, !tbaa !23
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr { i64, [21 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t352, i32 0, i32 2
  %t354 = load %"compiler/mir:Lvalue", ptr %t353
  store %"compiler/mir:Lvalue" %t354, ptr %l15
  br label %bb67
bb66:
  br label %bb69
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t356 = load i32, ptr %l14, !tbaa !23
  %t358 = sext i32 %t356 to i64
  store i64 %t358, ptr %l143, !tbaa !24
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load %"compiler/mir:Lvalue", ptr %l15
  %t363 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s19, ptr %v3, ptr %t359, %"compiler/mir:Lvalue" %t360)
  store { i64, ptr } %t363, ptr %l146
  br label %bb68
bb68:
  %t364 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t366 = load i64, ptr %l143, !tbaa !24
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t368 = add i64 %t365, %t367
  %t369 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = add i64 %t371, %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t364, i64 %t365)
  %t377 = getelementptr i8, ptr %t376, i64 %t365
  %t378 = call i64 @__olang_fmt_i64(ptr %t377, i64 %t366)
  %t379 = getelementptr i8, ptr %t377, i64 %t367
  call void @olang_textcopy(ptr %t379, ptr %t369, i64 %t370)
  %t380 = getelementptr i8, ptr %t379, i64 %t370
  call void @olang_textcopy(ptr %t380, ptr %t373, i64 %t374)
  %t381 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t376, 1
  store { i64, ptr } %t382, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb148
bb69:
  %t384 = load ptr, ptr %l1, !tbaa !29
  store ptr %t384, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t385 = load ptr, ptr %l148, !tbaa !29
  %t386 = icmp ne ptr %t385, null
  br i1 %t386, label %bb70, label %bb71
bb70:
  %t388 = load ptr, ptr %l148, !tbaa !29
  %t389 = load i64, ptr %t388, !range !{i64 0, i64 20}
  %t391 = icmp eq i64 %t389, 10
  store i1 %t391, ptr %l149, !tbaa !21
  br label %bb71
bb71:
  %t392 = load i1, ptr %l149, !tbaa !21
  br i1 %t392, label %bb72, label %bb73
bb72:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr { i64, [21 x i64] }, ptr %t393, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", i32 }, ptr %t395, i32 0, i32 1
  %t397 = load i32, ptr %t396
  store i32 %t397, ptr %l16, !tbaa !23
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t399 = load i32, ptr %l16, !tbaa !23
  %t401 = sext i32 %t399 to i64
  %t402 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t405 = call i64 @__olang_fmt_i64(ptr null, i64 %t401)
  %t406 = add i64 %t403, %t405
  %t407 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t406)
  call void @olang_textcopy(ptr %t407, ptr %t402, i64 %t403)
  %t408 = getelementptr i8, ptr %t407, i64 %t403
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t401)
  %t410 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t407, 1
  store { i64, ptr } %t411, ptr %l33, !tbaa !27
  br label %bb148
bb75:
  %t413 = load ptr, ptr %l1, !tbaa !29
  store ptr %t413, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t414 = load ptr, ptr %l157, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb76, label %bb77
bb76:
  %t417 = load ptr, ptr %l157, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 20}
  %t420 = icmp eq i64 %t418, 11
  store i1 %t420, ptr %l158, !tbaa !21
  br label %bb77
bb77:
  %t421 = load i1, ptr %l158, !tbaa !21
  br i1 %t421, label %bb78, label %bb79
bb78:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr { i64, [21 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t424, i32 0, i32 1
  %t426 = load { i64, [1 x i64] }, ptr %t425
  store { i64, [1 x i64] } %t426, ptr %l17
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t430 = getelementptr { i64, [21 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t430, i32 0, i32 2
  %t432 = load i32, ptr %t431, !range !{i32 0, i32 8}
  store i32 %t432, ptr %l18
  %t434 = load ptr, ptr %l1, !tbaa !29
  %t436 = getelementptr { i64, [21 x i64] }, ptr %t434, i32 0, i32 1
  %t437 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t436, i32 0, i32 3
  %t438 = load { i64, [4 x i64] }, ptr %t437
  store { i64, [4 x i64] } %t438, ptr %l19
  br label %bb80
bb79:
  br label %bb85
bb80:
  store %olang.scope zeroinitializer, ptr %s23
  %t440 = load i32, ptr %l18, !range !{i32 0, i32 8}
  store i32 %t440, ptr %l167
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s24, ptr %l167, i64 0)
  br label %bb81
bb81:
  %t442 = load ptr, ptr %s24
  %t443 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t444 = load i64, ptr %t443
  %t445 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t444)
  call void @olang_textcopy(ptr %t445, ptr %t442, i64 %t444)
  %t446 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  store { i64, ptr } %t447, ptr %l169, !tbaa !27
  %t448 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t449 = load ptr, ptr %t448
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %sbgrew.451, label %sbdone.452
sbgrew.451:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.452
sbdone.452:
  %t453 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t455 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s23, ptr %s23, { i64, ptr } %t453)
  store { i64, ptr } %t455, ptr %l171
  br label %bb82
bb82:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load { i64, [4 x i64] }, ptr %l19
  %t460 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s23, ptr %v3, ptr %v4, ptr %t456, { i64, [4 x i64] } %t457)
  store { i64, ptr } %t460, ptr %l174
  br label %bb83
bb83:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load { i64, [1 x i64] }, ptr %l17
  %t465 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s23, ptr %t461, { i64, [1 x i64] } %t462)
  store { i64, ptr } %t465, ptr %l177
  br label %bb84
bb84:
  %t466 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t468 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t468, 1
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t475, 1
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = add i64 %t474, %t477
  %t479 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t481 = add i64 %t478, %t480
  %t482 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 1
  %t484 = extractvalue { i64, ptr } %t482, 0
  %t485 = add i64 %t481, %t484
  %t486 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t485)
  call void @olang_textcopy(ptr %t486, ptr %t466, i64 %t467)
  %t487 = getelementptr i8, ptr %t486, i64 %t467
  call void @olang_textcopy(ptr %t487, ptr %t469, i64 %t470)
  %t488 = getelementptr i8, ptr %t487, i64 %t470
  call void @olang_textcopy(ptr %t488, ptr %t472, i64 %t473)
  %t489 = getelementptr i8, ptr %t488, i64 %t473
  call void @olang_textcopy(ptr %t489, ptr %t476, i64 %t477)
  %t490 = getelementptr i8, ptr %t489, i64 %t477
  call void @olang_textcopy(ptr %t490, ptr %t479, i64 %t480)
  %t491 = getelementptr i8, ptr %t490, i64 %t480
  call void @olang_textcopy(ptr %t491, ptr %t483, i64 %t484)
  %t492 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t486, 1
  store { i64, ptr } %t493, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s23)
  br label %bb148
bb85:
  %t495 = load ptr, ptr %l1, !tbaa !29
  store ptr %t495, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t496 = load ptr, ptr %l179, !tbaa !29
  %t497 = icmp ne ptr %t496, null
  br i1 %t497, label %bb86, label %bb87
bb86:
  %t499 = load ptr, ptr %l179, !tbaa !29
  %t500 = load i64, ptr %t499, !range !{i64 0, i64 20}
  %t502 = icmp eq i64 %t500, 12
  store i1 %t502, ptr %l180, !tbaa !21
  br label %bb87
bb87:
  %t503 = load i1, ptr %l180, !tbaa !21
  br i1 %t503, label %bb88, label %bb89
bb88:
  %t504 = load ptr, ptr %l1, !tbaa !29
  %t506 = getelementptr { i64, [21 x i64] }, ptr %t504, i32 0, i32 1
  %t507 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t506, i32 0, i32 1
  %t508 = load %"compiler/mir:Lvalue", ptr %t507
  store %"compiler/mir:Lvalue" %t508, ptr %l20
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t512, i32 0, i32 2
  %t514 = load %"compiler/mir:Lvalue", ptr %t513
  store %"compiler/mir:Lvalue" %t514, ptr %l21
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [21 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t518, i32 0, i32 3
  %t520 = load { i64, [4 x i64] }, ptr %t519
  store { i64, [4 x i64] } %t520, ptr %l22
  br label %bb90
bb89:
  br label %bb94
bb90:
  store %olang.scope zeroinitializer, ptr %s26
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load { i64, [4 x i64] }, ptr %l22
  %t526 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s26, ptr %v3, ptr %v4, ptr %t522, { i64, [4 x i64] } %t523)
  store { i64, ptr } %t526, ptr %l191
  br label %bb91
bb91:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load %"compiler/mir:Lvalue", ptr %l21
  %t531 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s26, ptr %v3, ptr %t527, %"compiler/mir:Lvalue" %t528)
  store { i64, ptr } %t531, ptr %l194
  br label %bb92
bb92:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load %"compiler/mir:Lvalue", ptr %l20
  %t536 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s26, ptr %v3, ptr %t532, %"compiler/mir:Lvalue" %t533)
  store { i64, ptr } %t536, ptr %l197
  br label %bb93
bb93:
  %t537 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t539 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = add i64 %t538, %t541
  %t543 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t544 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t545 = add i64 %t542, %t544
  %t546 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 1
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t549 = add i64 %t545, %t548
  %t550 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t551 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t552 = add i64 %t549, %t551
  %t553 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t553, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = add i64 %t552, %t555
  %t557 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t556)
  call void @olang_textcopy(ptr %t557, ptr %t537, i64 %t538)
  %t558 = getelementptr i8, ptr %t557, i64 %t538
  call void @olang_textcopy(ptr %t558, ptr %t540, i64 %t541)
  %t559 = getelementptr i8, ptr %t558, i64 %t541
  call void @olang_textcopy(ptr %t559, ptr %t543, i64 %t544)
  %t560 = getelementptr i8, ptr %t559, i64 %t544
  call void @olang_textcopy(ptr %t560, ptr %t547, i64 %t548)
  %t561 = getelementptr i8, ptr %t560, i64 %t548
  call void @olang_textcopy(ptr %t561, ptr %t550, i64 %t551)
  %t562 = getelementptr i8, ptr %t561, i64 %t551
  call void @olang_textcopy(ptr %t562, ptr %t554, i64 %t555)
  %t563 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t557, 1
  store { i64, ptr } %t564, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s26)
  br label %bb148
bb94:
  %t566 = load ptr, ptr %l1, !tbaa !29
  store ptr %t566, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t567 = load ptr, ptr %l199, !tbaa !29
  %t568 = icmp ne ptr %t567, null
  br i1 %t568, label %bb95, label %bb96
bb95:
  %t570 = load ptr, ptr %l199, !tbaa !29
  %t571 = load i64, ptr %t570, !range !{i64 0, i64 20}
  %t573 = icmp eq i64 %t571, 13
  store i1 %t573, ptr %l200, !tbaa !21
  br label %bb96
bb96:
  %t574 = load i1, ptr %l200, !tbaa !21
  br i1 %t574, label %bb97, label %bb98
bb97:
  %t575 = load ptr, ptr %l1, !tbaa !29
  %t577 = getelementptr { i64, [21 x i64] }, ptr %t575, i32 0, i32 1
  %t578 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t577, i32 0, i32 1
  %t579 = load i32, ptr %t578
  store i32 %t579, ptr %l23, !tbaa !23
  %t581 = load ptr, ptr %l1, !tbaa !29
  %t583 = getelementptr { i64, [21 x i64] }, ptr %t581, i32 0, i32 1
  %t584 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t583, i32 0, i32 2
  %t585 = load i32, ptr %t584
  store i32 %t585, ptr %l24, !tbaa !23
  br label %bb99
bb98:
  br label %bb102
bb99:
  store %olang.scope zeroinitializer, ptr %s28
  %t587 = load i32, ptr %l23, !tbaa !23
  store i32 %t587, ptr %l207, !tbaa !23
  %t588 = load ptr, ptr %l0, !tbaa !29
  store ptr %t588, ptr %l208, !tbaa !29
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/mir:dumper", ptr %t589, i32 0, i32 0
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t594 = getelementptr %"compiler/mir:Fn", ptr %t592, i32 0, i32 16
  store ptr %t594, ptr %l211, !tbaa !29
  %t595 = load i32, ptr %l24, !tbaa !23
  %t597 = sext i32 %t595 to i64
  %t598 = load ptr, ptr %l211, !tbaa !29
  %t599 = call ptr @__olang_scope_or(ptr %v3, ptr %t598)
  %t600 = call ptr @__olang_scope_hold(ptr %t599)
  %t601 = ptrtoint ptr %t600 to i64
  %t604 = inttoptr i64 %t601 to ptr
  %t605 = load ptr, ptr %l211, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t602, ptr %t604, ptr %t605, i64 %t597)
  call void @llvm.memmove.p0.p0.i64(ptr %l215, ptr %t602, i64 144, i1 false)
  br label %bb100
bb100:
  %t607 = load ptr, ptr %l208, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t608, ptr %l215, i64 144, i1 false)
  %t609 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %s28, ptr %v3, ptr %v4, ptr %t607, ptr %t608)
  store { i64, ptr } %t609, ptr %l216
  br label %bb101
bb101:
  %t610 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t611 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t612 = load i32, ptr %l207, !tbaa !23
  %t613 = sext i32 %t612 to i64
  %t614 = call i64 @__olang_fmt_i64(ptr null, i64 %t613)
  %t615 = add i64 %t611, %t614
  %t616 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t618 = add i64 %t615, %t617
  %t619 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 1
  %t621 = extractvalue { i64, ptr } %t619, 0
  %t622 = add i64 %t618, %t621
  %t623 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t622)
  call void @olang_textcopy(ptr %t623, ptr %t610, i64 %t611)
  %t624 = getelementptr i8, ptr %t623, i64 %t611
  %t625 = call i64 @__olang_fmt_i64(ptr %t624, i64 %t613)
  %t626 = getelementptr i8, ptr %t624, i64 %t614
  call void @olang_textcopy(ptr %t626, ptr %t616, i64 %t617)
  %t627 = getelementptr i8, ptr %t626, i64 %t617
  call void @olang_textcopy(ptr %t627, ptr %t620, i64 %t621)
  %t628 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t623, 1
  store { i64, ptr } %t629, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  br label %bb148
bb102:
  %t631 = load ptr, ptr %l1, !tbaa !29
  store ptr %t631, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t632 = load ptr, ptr %l218, !tbaa !29
  %t633 = icmp ne ptr %t632, null
  br i1 %t633, label %bb103, label %bb104
bb103:
  %t635 = load ptr, ptr %l218, !tbaa !29
  %t636 = load i64, ptr %t635, !range !{i64 0, i64 20}
  %t638 = icmp eq i64 %t636, 14
  store i1 %t638, ptr %l219, !tbaa !21
  br label %bb104
bb104:
  %t639 = load i1, ptr %l219, !tbaa !21
  br i1 %t639, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l222, !tbaa !27
  %t640 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t640, ptr %l33, !tbaa !27
  br label %bb148
bb108:
  %t642 = load ptr, ptr %l1, !tbaa !29
  store ptr %t642, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t643 = load ptr, ptr %l224, !tbaa !29
  %t644 = icmp ne ptr %t643, null
  br i1 %t644, label %bb109, label %bb110
bb109:
  %t646 = load ptr, ptr %l224, !tbaa !29
  %t647 = load i64, ptr %t646, !range !{i64 0, i64 20}
  %t649 = icmp eq i64 %t647, 15
  store i1 %t649, ptr %l225, !tbaa !21
  br label %bb110
bb110:
  %t650 = load i1, ptr %l225, !tbaa !21
  br i1 %t650, label %bb111, label %bb112
bb111:
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr { i64, [21 x i64] }, ptr %t651, i32 0, i32 1
  %t654 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t653, i32 0, i32 1
  %t655 = load { i64, [4 x i64] }, ptr %t654
  store { i64, [4 x i64] } %t655, ptr %l25
  br label %bb113
bb112:
  br label %bb115
bb113:
  store %olang.scope zeroinitializer, ptr %s31
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load { i64, [4 x i64] }, ptr %l25
  %t661 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s31, ptr %v3, ptr %v4, ptr %t657, { i64, [4 x i64] } %t658)
  store { i64, ptr } %t661, ptr %l232
  br label %bb114
bb114:
  %t662 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t663 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t664 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t664, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = add i64 %t663, %t666
  %t668 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t667)
  call void @olang_textcopy(ptr %t668, ptr %t662, i64 %t663)
  %t669 = getelementptr i8, ptr %t668, i64 %t663
  call void @olang_textcopy(ptr %t669, ptr %t665, i64 %t666)
  %t670 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t668, 1
  store { i64, ptr } %t671, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s31)
  br label %bb148
bb115:
  %t673 = load ptr, ptr %l1, !tbaa !29
  store ptr %t673, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t674 = load ptr, ptr %l234, !tbaa !29
  %t675 = icmp ne ptr %t674, null
  br i1 %t675, label %bb116, label %bb117
bb116:
  %t677 = load ptr, ptr %l234, !tbaa !29
  %t678 = load i64, ptr %t677, !range !{i64 0, i64 20}
  %t680 = icmp eq i64 %t678, 16
  store i1 %t680, ptr %l235, !tbaa !21
  br label %bb117
bb117:
  %t681 = load i1, ptr %l235, !tbaa !21
  br i1 %t681, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l238, !tbaa !27
  %t682 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t682, ptr %l33, !tbaa !27
  br label %bb148
bb121:
  %t684 = load ptr, ptr %l1, !tbaa !29
  store ptr %t684, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t685 = load ptr, ptr %l240, !tbaa !29
  %t686 = icmp ne ptr %t685, null
  br i1 %t686, label %bb122, label %bb123
bb122:
  %t688 = load ptr, ptr %l240, !tbaa !29
  %t689 = load i64, ptr %t688, !range !{i64 0, i64 20}
  %t691 = icmp eq i64 %t689, 17
  store i1 %t691, ptr %l241, !tbaa !21
  br label %bb123
bb123:
  %t692 = load i1, ptr %l241, !tbaa !21
  br i1 %t692, label %bb124, label %bb125
bb124:
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr { i64, [21 x i64] }, ptr %t693, i32 0, i32 1
  %t696 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t695, i32 0, i32 1
  %t697 = load { i64, [4 x i64] }, ptr %t696
  store { i64, [4 x i64] } %t697, ptr %l26
  %t699 = load ptr, ptr %l1, !tbaa !29
  %t701 = getelementptr { i64, [21 x i64] }, ptr %t699, i32 0, i32 1
  %t702 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t701, i32 0, i32 2
  %t703 = load { i64, [4 x i64] }, ptr %t702
  store { i64, [4 x i64] } %t703, ptr %l27
  br label %bb126
bb125:
  br label %bb129
bb126:
  store %olang.scope zeroinitializer, ptr %s34
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load { i64, [4 x i64] }, ptr %l26
  %t709 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s34, ptr %v3, ptr %v4, ptr %t705, { i64, [4 x i64] } %t706)
  store { i64, ptr } %t709, ptr %l250
  br label %bb127
bb127:
  %t710 = load ptr, ptr %l0, !tbaa !29
  %t711 = load { i64, [4 x i64] }, ptr %l27
  %t714 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s34, ptr %v3, ptr %v4, ptr %t710, { i64, [4 x i64] } %t711)
  store { i64, ptr } %t714, ptr %l253
  br label %bb128
bb128:
  %t715 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t717 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t718 = extractvalue { i64, ptr } %t717, 1
  %t719 = extractvalue { i64, ptr } %t717, 0
  %t720 = add i64 %t716, %t719
  %t721 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t723 = add i64 %t720, %t722
  %t724 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t725 = extractvalue { i64, ptr } %t724, 1
  %t726 = extractvalue { i64, ptr } %t724, 0
  %t727 = add i64 %t723, %t726
  %t728 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t727)
  call void @olang_textcopy(ptr %t728, ptr %t715, i64 %t716)
  %t729 = getelementptr i8, ptr %t728, i64 %t716
  call void @olang_textcopy(ptr %t729, ptr %t718, i64 %t719)
  %t730 = getelementptr i8, ptr %t729, i64 %t719
  call void @olang_textcopy(ptr %t730, ptr %t721, i64 %t722)
  %t731 = getelementptr i8, ptr %t730, i64 %t722
  call void @olang_textcopy(ptr %t731, ptr %t725, i64 %t726)
  %t732 = insertvalue { i64, ptr } undef, i64 %t727, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t728, 1
  store { i64, ptr } %t733, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s34)
  br label %bb148
bb129:
  %t735 = load ptr, ptr %l1, !tbaa !29
  store ptr %t735, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t736 = load ptr, ptr %l255, !tbaa !29
  %t737 = icmp ne ptr %t736, null
  br i1 %t737, label %bb130, label %bb131
bb130:
  %t739 = load ptr, ptr %l255, !tbaa !29
  %t740 = load i64, ptr %t739, !range !{i64 0, i64 20}
  %t742 = icmp eq i64 %t740, 18
  store i1 %t742, ptr %l256, !tbaa !21
  br label %bb131
bb131:
  %t743 = load i1, ptr %l256, !tbaa !21
  br i1 %t743, label %bb132, label %bb133
bb132:
  %t744 = load ptr, ptr %l1, !tbaa !29
  %t746 = getelementptr { i64, [21 x i64] }, ptr %t744, i32 0, i32 1
  %t747 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t746, i32 0, i32 1
  %t748 = load { i64, [4 x i64] }, ptr %t747
  store { i64, [4 x i64] } %t748, ptr %l28
  %t750 = load ptr, ptr %l1, !tbaa !29
  %t752 = getelementptr { i64, [21 x i64] }, ptr %t750, i32 0, i32 1
  %t753 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t752, i32 0, i32 2
  %t754 = load i32, ptr %t753
  store i32 %t754, ptr %l29, !tbaa !23
  %t756 = load ptr, ptr %l1, !tbaa !29
  %t758 = getelementptr { i64, [21 x i64] }, ptr %t756, i32 0, i32 1
  %t759 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t758, i32 0, i32 3
  %t760 = load %"compiler/mir:Range", ptr %t759
  store %"compiler/mir:Range" %t760, ptr %l30
  br label %bb134
bb133:
  br label %bb138
bb134:
  store %olang.scope zeroinitializer, ptr %s36
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load { i64, [4 x i64] }, ptr %l28
  %t766 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s36, ptr %v3, ptr %v4, ptr %t762, { i64, [4 x i64] } %t763)
  store { i64, ptr } %t766, ptr %l267
  br label %bb135
bb135:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t769 = getelementptr %"compiler/mir:dumper", ptr %t767, i32 0, i32 1
  %t770 = load ptr, ptr %t769, !tbaa !29
  store ptr %t770, ptr %l269, !tbaa !29
  %t771 = load i32, ptr %l29, !tbaa !23
  %t772 = load ptr, ptr %l269, !tbaa !29
  %t773 = call ptr @__olang_scope_or(ptr %v4, ptr %t772)
  %t774 = call ptr @__olang_scope_hold(ptr %t773)
  %t775 = ptrtoint ptr %t774 to i64
  %t777 = inttoptr i64 %t775 to ptr
  %t779 = inttoptr i64 0 to ptr
  %t780 = load ptr, ptr %l269, !tbaa !29
  %t782 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t777, ptr %s36, ptr %t779, ptr %t780, i32 %t771)
  store { i64, ptr } %t782, ptr %l273
  br label %bb136
bb136:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load %"compiler/mir:Range", ptr %l30
  %t787 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s36, ptr %v3, ptr %v4, ptr %t783, %"compiler/mir:Range" %t784)
  store { i64, ptr } %t787, ptr %l276
  br label %bb137
bb137:
  %t788 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t790 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t791 = extractvalue { i64, ptr } %t790, 1
  %t792 = extractvalue { i64, ptr } %t790, 0
  %t793 = add i64 %t789, %t792
  %t794 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t795 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t796 = add i64 %t793, %t795
  %t797 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t797, 1
  %t799 = extractvalue { i64, ptr } %t797, 0
  %t800 = add i64 %t796, %t799
  %t801 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t802 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t803 = add i64 %t800, %t802
  %t804 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t804, 1
  %t806 = extractvalue { i64, ptr } %t804, 0
  %t807 = add i64 %t803, %t806
  %t808 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t810 = add i64 %t807, %t809
  %t811 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t810)
  call void @olang_textcopy(ptr %t811, ptr %t788, i64 %t789)
  %t812 = getelementptr i8, ptr %t811, i64 %t789
  call void @olang_textcopy(ptr %t812, ptr %t791, i64 %t792)
  %t813 = getelementptr i8, ptr %t812, i64 %t792
  call void @olang_textcopy(ptr %t813, ptr %t794, i64 %t795)
  %t814 = getelementptr i8, ptr %t813, i64 %t795
  call void @olang_textcopy(ptr %t814, ptr %t798, i64 %t799)
  %t815 = getelementptr i8, ptr %t814, i64 %t799
  call void @olang_textcopy(ptr %t815, ptr %t801, i64 %t802)
  %t816 = getelementptr i8, ptr %t815, i64 %t802
  call void @olang_textcopy(ptr %t816, ptr %t805, i64 %t806)
  %t817 = getelementptr i8, ptr %t816, i64 %t806
  call void @olang_textcopy(ptr %t817, ptr %t808, i64 %t809)
  %t818 = insertvalue { i64, ptr } undef, i64 %t810, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr %t811, 1
  store { i64, ptr } %t819, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s36)
  br label %bb148
bb138:
  %t821 = load ptr, ptr %l1, !tbaa !29
  store ptr %t821, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t822 = load ptr, ptr %l278, !tbaa !29
  %t823 = icmp ne ptr %t822, null
  br i1 %t823, label %bb139, label %bb140
bb139:
  %t825 = load ptr, ptr %l278, !tbaa !29
  %t826 = load i64, ptr %t825, !range !{i64 0, i64 20}
  %t828 = icmp eq i64 %t826, 19
  store i1 %t828, ptr %l279, !tbaa !21
  br label %bb140
bb140:
  %t829 = load i1, ptr %l279, !tbaa !21
  br i1 %t829, label %bb141, label %bb142
bb141:
  %t830 = load ptr, ptr %l1, !tbaa !29
  %t832 = getelementptr { i64, [21 x i64] }, ptr %t830, i32 0, i32 1
  %t833 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t832, i32 0, i32 1
  %t834 = load i32, ptr %t833
  store i32 %t834, ptr %l31, !tbaa !23
  %t836 = load ptr, ptr %l1, !tbaa !29
  %t838 = getelementptr { i64, [21 x i64] }, ptr %t836, i32 0, i32 1
  %t839 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t838, i32 0, i32 2
  %t840 = load i32, ptr %t839
  store i32 %t840, ptr %l32, !tbaa !23
  br label %bb143
bb142:
  br label %bb147
bb143:
  store %olang.scope zeroinitializer, ptr %s38
  %t842 = load i32, ptr %l31, !tbaa !23
  store i32 %t842, ptr %l286, !tbaa !23
  %t843 = load i32, ptr %l32, !tbaa !23
  %t844 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t847 = icmp ne i32 %t843, %t844
  br i1 %t847, label %bb144, label %bb145
bb144:
  %t849 = load i32, ptr %l32, !tbaa !23
  %t850 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t851 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t853 = sext i32 %t849 to i64
  %t854 = call i64 @__olang_fmt_i64(ptr null, i64 %t853)
  %t855 = add i64 %t851, %t854
  %t856 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t855)
  call void @olang_textcopy(ptr %t856, ptr %t850, i64 %t851)
  %t857 = getelementptr i8, ptr %t856, i64 %t851
  %t858 = call i64 @__olang_fmt_i64(ptr %t857, i64 %t853)
  %t859 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t860 = insertvalue { i64, ptr } %t859, ptr %t856, 1
  store { i64, ptr } %t860, ptr %l290, !tbaa !27
  br label %bb146
bb145:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l290, !tbaa !27
  br label %bb146
bb146:
  %t863 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t865 = load i32, ptr %l286, !tbaa !23
  %t866 = sext i32 %t865 to i64
  %t867 = call i64 @__olang_fmt_i64(ptr null, i64 %t866)
  %t868 = add i64 %t864, %t867
  %t869 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t872)
  call void @olang_textcopy(ptr %t873, ptr %t863, i64 %t864)
  %t874 = getelementptr i8, ptr %t873, i64 %t864
  %t875 = call i64 @__olang_fmt_i64(ptr %t874, i64 %t866)
  %t876 = getelementptr i8, ptr %t874, i64 %t867
  call void @olang_textcopy(ptr %t876, ptr %t870, i64 %t871)
  %t877 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t873, 1
  store { i64, ptr } %t878, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s38)
  br label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_63d4bc85d5a0ee63_941776bd89ba250f)
  unreachable
bb148:
  %t880 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 0
  store i64 %t881, ptr %l295, !tbaa !24
  %t882 = load i64, ptr %l295, !tbaa !24
  %t883 = mul i64 %t882, 1
  %t884 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t883)
  %t885 = insertvalue { i64, ptr } undef, i64 %t882, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t884, 1
  store { i64, ptr } %t886, ptr %l296, !tbaa !27
  %t887 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t888 = load ptr, ptr %t887, !tbaa !27
  %t889 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t890 = load ptr, ptr %t889, !tbaa !27
  %t891 = load i64, ptr %l295, !tbaa !24
  %t892 = mul i64 %t891, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t888, ptr %t890, i64 %t892, i1 false)
  %t893 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t893, ptr %l33, !tbaa !27
  %t894 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t894, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca %"compiler/mir:Call"
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca %"compiler/mir:Call"
  %l81 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l126 = alloca i32
  %l127 = alloca i32
  %l131 = alloca { i64, ptr }
  %l141 = alloca i32
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t11, ptr %l26, !tbaa !27
  br label %bb75
bb4:
  %t13 = load { i64, [8 x i64] }, ptr %l1
  %t15 = extractvalue { i64, [8 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  br label %bb75
bb8:
  %t35 = load { i64, [8 x i64] }, ptr %l1
  %t37 = extractvalue { i64, [8 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 2
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t40, i32 0, i32 0
  %t42 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t42, ptr %l4
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l4
  %t56 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %v2, ptr %v3, ptr %t52, { i64, [4 x i64] } %t53)
  store { i64, ptr } %t56, ptr %l43
  br label %bb12
bb12:
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t69 = sext i32 %t57 to i64
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = sext i32 %t58 to i64
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t59, i64 %t60)
  %t80 = getelementptr i8, ptr %t79, i64 %t60
  call void @olang_textcopy(ptr %t80, ptr %t62, i64 %t63)
  %t81 = getelementptr i8, ptr %t80, i64 %t63
  call void @olang_textcopy(ptr %t81, ptr %t65, i64 %t66)
  %t82 = getelementptr i8, ptr %t81, i64 %t66
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t69)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t76)
  %t87 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t79, 1
  store { i64, ptr } %t88, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb75
bb13:
  %t90 = load { i64, [8 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [8 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb14, label %bb15
bb14:
  %t95 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t95, i32 0, i32 0
  %t97 = load { i64, [4 x i64] }, ptr %t96
  store { i64, [4 x i64] } %t97, ptr %l7
  %t99 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t99, i32 0, i32 1
  %t101 = load %"compiler/mir:Range", ptr %t100
  store %"compiler/mir:Range" %t101, ptr %l8
  %t103 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t104 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t103, i32 0, i32 2
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l9, !tbaa !23
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, [4 x i64] }, ptr %l7
  %t111 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %v2, ptr %v3, ptr %t107, { i64, [4 x i64] } %t108)
  store { i64, ptr } %t111, ptr %l54
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/mir:Range", ptr %l8
  %t116 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %s6, ptr %v2, ptr %t112, %"compiler/mir:Range" %t113)
  store { i64, ptr } %t116, ptr %l57
  br label %bb18
bb18:
  %t117 = load i32, ptr %l9, !tbaa !23
  %t118 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t120 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t117 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t121, i64 %t122)
  %t140 = getelementptr i8, ptr %t139, i64 %t122
  call void @olang_textcopy(ptr %t140, ptr %t124, i64 %t125)
  %t141 = getelementptr i8, ptr %t140, i64 %t125
  call void @olang_textcopy(ptr %t141, ptr %t128, i64 %t129)
  %t142 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t135)
  %t145 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t138, 1
  store { i64, ptr } %t146, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb75
bb19:
  %t148 = load { i64, [8 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [8 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb20, label %bb21
bb20:
  %t153 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32 }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l10, !tbaa !23
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l63, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/mir:Fn", ptr %t158, i32 0, i32 14
  store ptr %t160, ptr %l65, !tbaa !29
  %t161 = load i32, ptr %l10, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t164 = load ptr, ptr %l65, !tbaa !29
  %t165 = call ptr @__olang_scope_or(ptr %v2, ptr %t164)
  %t166 = call ptr @__olang_scope_hold(ptr %t165)
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = inttoptr i64 %t167 to ptr
  %t170 = load ptr, ptr %l65, !tbaa !29
  %t172 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t169, ptr %t170, i64 %t163)
  store %"compiler/mir:Call" %t172, ptr %l69
  br label %bb23
bb23:
  %t173 = load ptr, ptr %l63, !tbaa !29
  %t174 = load %"compiler/mir:Call", ptr %l69
  %t175 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t173, %"compiler/mir:Call" %t174)
  store { i64, ptr } %t175, ptr %l70
  br label %bb24
bb24:
  %t176 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t176, ptr %l26, !tbaa !27
  br label %bb75
bb25:
  %t177 = load { i64, [8 x i64] }, ptr %l1
  %t179 = extractvalue { i64, [8 x i64] } %t177, 0
  %t180 = icmp eq i64 %t179, 6
  br i1 %t180, label %bb26, label %bb27
bb26:
  %t182 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32 }, ptr %t182, i32 0, i32 1
  %t184 = load i32, ptr %t183
  store i32 %t184, ptr %l11, !tbaa !23
  br label %bb28
bb27:
  br label %bb31
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l74, !tbaa !29
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t189 = getelementptr %"compiler/mir:Fn", ptr %t187, i32 0, i32 14
  store ptr %t189, ptr %l76, !tbaa !29
  %t190 = load i32, ptr %l11, !tbaa !23
  %t192 = sext i32 %t190 to i64
  %t193 = load ptr, ptr %l76, !tbaa !29
  %t194 = call ptr @__olang_scope_or(ptr %v2, ptr %t193)
  %t195 = call ptr @__olang_scope_hold(ptr %t194)
  %t196 = ptrtoint ptr %t195 to i64
  %t198 = inttoptr i64 %t196 to ptr
  %t199 = load ptr, ptr %l76, !tbaa !29
  %t201 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t198, ptr %t199, i64 %t192)
  store %"compiler/mir:Call" %t201, ptr %l80
  br label %bb29
bb29:
  %t202 = load ptr, ptr %l74, !tbaa !29
  %t203 = load %"compiler/mir:Call", ptr %l80
  %t204 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %s9, ptr %v2, ptr %v3, ptr %t202, %"compiler/mir:Call" %t203)
  store { i64, ptr } %t204, ptr %l81
  br label %bb30
bb30:
  %t205 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t207 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t205, i64 %t206)
  %t212 = getelementptr i8, ptr %t211, i64 %t206
  call void @olang_textcopy(ptr %t212, ptr %t208, i64 %t209)
  %t213 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  store { i64, ptr } %t214, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb75
bb31:
  %t216 = load { i64, [8 x i64] }, ptr %l1
  %t218 = extractvalue { i64, [8 x i64] } %t216, 0
  %t219 = icmp eq i64 %t218, 5
  br i1 %t219, label %bb32, label %bb33
bb32:
  %t221 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t221, i32 0, i32 1
  %t223 = load { i64, [4 x i64] }, ptr %t222
  store { i64, [4 x i64] } %t223, ptr %l12
  br label %bb34
bb33:
  br label %bb39
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t225 = load { i64, [4 x i64] }, ptr %l12
  %t227 = extractvalue { i64, [4 x i64] } %t225, 0
  %t228 = icmp eq i64 %t227, 0
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb35, label %bb36
bb35:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, [4 x i64] }, ptr %l12
  %t236 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %v2, ptr %v3, ptr %t232, { i64, [4 x i64] } %t233)
  store { i64, ptr } %t236, ptr %l92
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb38
bb37:
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t239 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l89, !tbaa !27
  br label %bb38
bb38:
  %t249 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t251 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t249, i64 %t250)
  %t256 = getelementptr i8, ptr %t255, i64 %t250
  call void @olang_textcopy(ptr %t256, ptr %t252, i64 %t253)
  %t257 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t255, 1
  store { i64, ptr } %t258, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb39:
  %t260 = load { i64, [8 x i64] }, ptr %l1
  %t262 = extractvalue { i64, [8 x i64] } %t260, 0
  %t263 = icmp eq i64 %t262, 7
  br i1 %t263, label %bb40, label %bb41
bb40:
  %t265 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t265, i32 0, i32 1
  %t267 = load { i64, [4 x i64] }, ptr %t266
  store { i64, [4 x i64] } %t267, ptr %l13
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s14
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load { i64, [4 x i64] }, ptr %l13
  %t273 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s14, ptr %v2, ptr %v3, ptr %t269, { i64, [4 x i64] } %t270)
  store { i64, ptr } %t273, ptr %l101
  br label %bb43
bb43:
  %t274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t276 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = add i64 %t275, %t278
  %t280 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t274, i64 %t275)
  %t281 = getelementptr i8, ptr %t280, i64 %t275
  call void @olang_textcopy(ptr %t281, ptr %t277, i64 %t278)
  %t282 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t280, 1
  store { i64, ptr } %t283, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb44:
  %t285 = load { i64, [8 x i64] }, ptr %l1
  %t287 = extractvalue { i64, [8 x i64] } %t285, 0
  %t288 = icmp eq i64 %t287, 11
  br i1 %t288, label %bb45, label %bb46
bb45:
  %t290 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t290, i32 0, i32 1
  %t292 = load { i64, [4 x i64] }, ptr %t291
  store { i64, [4 x i64] } %t292, ptr %l14
  %t294 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t294, i32 0, i32 2
  %t296 = load i32, ptr %t295
  store i32 %t296, ptr %l15, !tbaa !23
  %t298 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t298, i32 0, i32 3
  %t300 = load %"compiler/mir:Range", ptr %t299
  store %"compiler/mir:Range" %t300, ptr %l16
  %t302 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t302, i32 0, i32 4
  %t304 = load i32, ptr %t303
  store i32 %t304, ptr %l17, !tbaa !23
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s16
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load { i64, [4 x i64] }, ptr %l14
  %t310 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s16, ptr %v2, ptr %v3, ptr %t306, { i64, [4 x i64] } %t307)
  store { i64, ptr } %t310, ptr %l111
  br label %bb48
bb48:
  %t311 = load i32, ptr %l15, !tbaa !23
  %t312 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 1
  %t313 = load i32, ptr %t312, !tbaa !23
  %t314 = load i32, ptr %l17, !tbaa !23
  %t315 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t317 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = add i64 %t316, %t319
  %t321 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t323 = add i64 %t320, %t322
  %t325 = sext i32 %t311 to i64
  %t326 = call i64 @__olang_fmt_i64(ptr null, i64 %t325)
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t332 = sext i32 %t313 to i64
  %t333 = call i64 @__olang_fmt_i64(ptr null, i64 %t332)
  %t334 = add i64 %t330, %t333
  %t335 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t336 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t337 = add i64 %t334, %t336
  %t339 = sext i32 %t314 to i64
  %t340 = call i64 @__olang_fmt_i64(ptr null, i64 %t339)
  %t341 = add i64 %t337, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t315, i64 %t316)
  %t343 = getelementptr i8, ptr %t342, i64 %t316
  call void @olang_textcopy(ptr %t343, ptr %t318, i64 %t319)
  %t344 = getelementptr i8, ptr %t343, i64 %t319
  call void @olang_textcopy(ptr %t344, ptr %t321, i64 %t322)
  %t345 = getelementptr i8, ptr %t344, i64 %t322
  %t346 = call i64 @__olang_fmt_i64(ptr %t345, i64 %t325)
  %t347 = getelementptr i8, ptr %t345, i64 %t326
  call void @olang_textcopy(ptr %t347, ptr %t328, i64 %t329)
  %t348 = getelementptr i8, ptr %t347, i64 %t329
  %t349 = call i64 @__olang_fmt_i64(ptr %t348, i64 %t332)
  %t350 = getelementptr i8, ptr %t348, i64 %t333
  call void @olang_textcopy(ptr %t350, ptr %t335, i64 %t336)
  %t351 = getelementptr i8, ptr %t350, i64 %t336
  %t352 = call i64 @__olang_fmt_i64(ptr %t351, i64 %t339)
  %t353 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t342, 1
  store { i64, ptr } %t354, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb75
bb49:
  %t356 = load { i64, [8 x i64] }, ptr %l1
  %t358 = extractvalue { i64, [8 x i64] } %t356, 0
  %t359 = icmp eq i64 %t358, 12
  br i1 %t359, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t361, ptr %l26, !tbaa !27
  br label %bb75
bb53:
  %t363 = load { i64, [8 x i64] }, ptr %l1
  %t365 = extractvalue { i64, [8 x i64] } %t363, 0
  %t366 = icmp eq i64 %t365, 8
  br i1 %t366, label %bb54, label %bb55
bb54:
  %t368 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t368, i32 0, i32 1
  %t370 = load i32, ptr %t369
  store i32 %t370, ptr %l18, !tbaa !23
  %t372 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t372, i32 0, i32 2
  %t374 = load i32, ptr %t373
  store i32 %t374, ptr %l19, !tbaa !23
  %t376 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t376, i32 0, i32 3
  %t378 = load i32, ptr %t377
  store i32 %t378, ptr %l20, !tbaa !23
  %t380 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t380, i32 0, i32 4
  %t382 = load i32, ptr %t381
  store i32 %t382, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb60
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t384 = load i32, ptr %l18, !tbaa !23
  store i32 %t384, ptr %l126, !tbaa !23
  %t385 = load i32, ptr %l19, !tbaa !23
  store i32 %t385, ptr %l127, !tbaa !23
  %t386 = load i32, ptr %l21, !tbaa !23
  %t387 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t390 = icmp ne i32 %t386, %t387
  br i1 %t390, label %bb57, label %bb58
bb57:
  %t392 = load i32, ptr %l20, !tbaa !23
  %t393 = load i32, ptr %l21, !tbaa !23
  %t394 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t397 = sext i32 %t392 to i64
  %t398 = call i64 @__olang_fmt_i64(ptr null, i64 %t397)
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t404 = sext i32 %t393 to i64
  %t405 = call i64 @__olang_fmt_i64(ptr null, i64 %t404)
  %t406 = add i64 %t402, %t405
  %t407 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t406)
  call void @olang_textcopy(ptr %t407, ptr %t394, i64 %t395)
  %t408 = getelementptr i8, ptr %t407, i64 %t395
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t397)
  %t410 = getelementptr i8, ptr %t408, i64 %t398
  call void @olang_textcopy(ptr %t410, ptr %t400, i64 %t401)
  %t411 = getelementptr i8, ptr %t410, i64 %t401
  %t412 = call i64 @__olang_fmt_i64(ptr %t411, i64 %t404)
  %t413 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t407, 1
  store { i64, ptr } %t414, ptr %l131, !tbaa !27
  br label %bb59
bb58:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l131, !tbaa !27
  br label %bb59
bb59:
  %t417 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t419 = load i32, ptr %l126, !tbaa !23
  %t420 = sext i32 %t419 to i64
  %t421 = call i64 @__olang_fmt_i64(ptr null, i64 %t420)
  %t422 = add i64 %t418, %t421
  %t423 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t425 = add i64 %t422, %t424
  %t426 = load i32, ptr %l127, !tbaa !23
  %t427 = sext i32 %t426 to i64
  %t428 = call i64 @__olang_fmt_i64(ptr null, i64 %t427)
  %t429 = add i64 %t425, %t428
  %t430 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = add i64 %t429, %t432
  %t434 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t433)
  call void @olang_textcopy(ptr %t434, ptr %t417, i64 %t418)
  %t435 = getelementptr i8, ptr %t434, i64 %t418
  %t436 = call i64 @__olang_fmt_i64(ptr %t435, i64 %t420)
  %t437 = getelementptr i8, ptr %t435, i64 %t421
  call void @olang_textcopy(ptr %t437, ptr %t423, i64 %t424)
  %t438 = getelementptr i8, ptr %t437, i64 %t424
  %t439 = call i64 @__olang_fmt_i64(ptr %t438, i64 %t427)
  %t440 = getelementptr i8, ptr %t438, i64 %t428
  call void @olang_textcopy(ptr %t440, ptr %t431, i64 %t432)
  %t441 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t434, 1
  store { i64, ptr } %t442, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb75
bb60:
  %t444 = load { i64, [8 x i64] }, ptr %l1
  %t446 = extractvalue { i64, [8 x i64] } %t444, 0
  %t447 = icmp eq i64 %t446, 9
  br i1 %t447, label %bb61, label %bb62
bb61:
  %t449 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t449, i32 0, i32 1
  %t451 = load i32, ptr %t450, !range !{i32 0, i32 20}
  store i32 %t451, ptr %l22
  %t453 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t453, i32 0, i32 2
  %t455 = load { i64, [4 x i64] }, ptr %t454
  store { i64, [4 x i64] } %t455, ptr %l23
  br label %bb63
bb62:
  br label %bb70
bb63:
  store %olang.scope zeroinitializer, ptr %s22
  %t457 = load i32, ptr %l22, !range !{i32 0, i32 20}
  store i32 %t457, ptr %l141
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s23, ptr %l141, i64 0)
  br label %bb64
bb64:
  %t459 = load ptr, ptr %s23
  %t460 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t461 = load i64, ptr %t460
  %t462 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t461)
  call void @olang_textcopy(ptr %t462, ptr %t459, i64 %t461)
  %t463 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l143, !tbaa !27
  %t465 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t466 = load ptr, ptr %t465
  %t467 = icmp ne ptr %t466, null
  br i1 %t467, label %sbgrew.468, label %sbdone.469
sbgrew.468:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.469
sbdone.469:
  %t470 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t472 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s22, ptr %s22, { i64, ptr } %t470)
  store { i64, ptr } %t472, ptr %l145
  br label %bb65
bb65:
  %t473 = load { i64, [4 x i64] }, ptr %l23
  %t475 = extractvalue { i64, [4 x i64] } %t473, 0
  %t476 = icmp eq i64 %t475, 0
  %t478 = xor i1 %t476, true
  br i1 %t478, label %bb66, label %bb67
bb66:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, [4 x i64] }, ptr %l23
  %t484 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s22, ptr %v2, ptr %v3, ptr %t480, { i64, [4 x i64] } %t481)
  store { i64, ptr } %t484, ptr %l152
  br label %bb68
bb67:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l149, !tbaa !27
  br label %bb69
bb68:
  %t485 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t487 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 1
  %t489 = extractvalue { i64, ptr } %t487, 0
  %t490 = add i64 %t486, %t489
  %t491 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t490)
  call void @olang_textcopy(ptr %t491, ptr %t485, i64 %t486)
  %t492 = getelementptr i8, ptr %t491, i64 %t486
  call void @olang_textcopy(ptr %t492, ptr %t488, i64 %t489)
  %t493 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t491, 1
  store { i64, ptr } %t494, ptr %l149, !tbaa !27
  br label %bb69
bb69:
  %t497 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t498 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t499 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 1
  %t501 = extractvalue { i64, ptr } %t499, 0
  %t502 = add i64 %t498, %t501
  %t503 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = extractvalue { i64, ptr } %t503, 0
  %t506 = add i64 %t502, %t505
  %t507 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t506)
  call void @olang_textcopy(ptr %t507, ptr %t497, i64 %t498)
  %t508 = getelementptr i8, ptr %t507, i64 %t498
  call void @olang_textcopy(ptr %t508, ptr %t500, i64 %t501)
  %t509 = getelementptr i8, ptr %t508, i64 %t501
  call void @olang_textcopy(ptr %t509, ptr %t504, i64 %t505)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t507, 1
  store { i64, ptr } %t511, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb75
bb70:
  %t513 = load { i64, [8 x i64] }, ptr %l1
  %t515 = extractvalue { i64, [8 x i64] } %t513, 0
  %t516 = icmp eq i64 %t515, 10
  br i1 %t516, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l158, !tbaa !27
  %t518 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t518, ptr %l26, !tbaa !27
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_8b20d2ead933ce67_842549c98b36ec43)
  unreachable
bb75:
  %t520 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t520, 0
  store i64 %t521, ptr %l160, !tbaa !24
  %t522 = load i64, ptr %l160, !tbaa !24
  %t523 = mul i64 %t522, 1
  %t524 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t523)
  %t525 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t524, 1
  store { i64, ptr } %t526, ptr %l161, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = load i64, ptr %l160, !tbaa !24
  %t532 = mul i64 %t531, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t528, ptr %t530, i64 %t532, i1 false)
  %t533 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t533, ptr %l26, !tbaa !27
  %t534 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t534, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l25 = alloca i32
  %l29 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca i32
  %l89 = alloca ptr
  %l92 = alloca i32
  %l101 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l120 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i64
  %l129 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l145 = alloca i32
  %l149 = alloca ptr
  %l152 = alloca i32
  %l154 = alloca ptr
  %l157 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %v1, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l25
  br label %bb1
bb1:
  %t16 = load i32, ptr %l25, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l4, !tbaa !29
  store ptr %t23, ptr %l29, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t25 = load ptr, ptr %l29, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l29, !tbaa !29
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t30, ptr %t31, i32 %t24)
  store i32 %t33, ptr %l32
  br label %bb4
bb3:
  br label %bb34
bb4:
  %t34 = load i32, ptr %l32, !tbaa !23
  store i32 %t34, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l7, !tbaa !23
  %t37 = icmp eq i32 %t35, 0
  br i1 %t37, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb8
bb6:
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l36, !tbaa !29
  %t40 = load i32, ptr %l7, !tbaa !23
  %t41 = load ptr, ptr %l36, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v1, ptr %t41)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t44 to ptr
  %t47 = load ptr, ptr %l36, !tbaa !29
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t46, ptr %t47, i32 %t40)
  store i32 %t49, ptr %l39
  br label %bb7
bb7:
  %t50 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t52 = trunc i64 26 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb12
bb10:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %l44, !tbaa !29
  %t59 = load i32, ptr %l7, !tbaa !23
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v1, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t68 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %t65, ptr %t66, i32 %t59)
  store i64 %t68, ptr %l47
  br label %bb11
bb11:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l47, !tbaa !24
  %t72 = icmp ne i64 %t70, %t69
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t74 = load i1, ptr %l43, !tbaa !21
  br i1 %t74, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l50, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %v1, ptr %t76, i32 %t77)
  store { i64, ptr } %t80, ptr %l53
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t84 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = add i64 %t83, %t86
  %t88 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t93 = add i64 %t90, %t92
  %t94 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t82, i64 %t83)
  %t98 = getelementptr i8, ptr %t97, i64 %t83
  call void @olang_textcopy(ptr %t98, ptr %t85, i64 %t86)
  %t99 = getelementptr i8, ptr %t98, i64 %t86
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t81)
  %t102 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t94, i64 %t95)
  %t103 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t97, 1
  %t106 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t106, { i64, ptr } %t104)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  store i64 %t108, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = load i64, ptr %l10, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb23
bb20:
  %t120 = load i64, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l64, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb22
bb22:
  %t136 = load i64, ptr %l64, !tbaa !24
  store i64 %t136, ptr %l61, !tbaa !24
  br label %bb23
bb23:
  %t137 = load i64, ptr %l61, !tbaa !24
  store i64 %t137, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t146 = load i64, ptr %l8, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t148 = load i64, ptr %l10, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l13, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l82, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/mir:Range", ptr %l3
  %t160 = load i64, ptr %l13, !tbaa !24
  %t164 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %v2, ptr %t158, %"compiler/mir:Range" %t159, i64 %t160)
  store { i64, [4 x i64] } %t164, ptr %l87
  br label %bb28
bb28:
  %t165 = load ptr, ptr %l83, !tbaa !29
  %t166 = load { i64, [4 x i64] }, ptr %l87
  %t167 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v1, ptr %t165, { i64, [4 x i64] } %t166)
  store i32 %t167, ptr %l88
  br label %bb29
bb29:
  %t168 = load ptr, ptr %l4, !tbaa !29
  store ptr %t168, ptr %l89, !tbaa !29
  %t169 = load i32, ptr %l6, !tbaa !23
  %t170 = load ptr, ptr %l89, !tbaa !29
  %t171 = call ptr @__olang_scope_or(ptr %v1, ptr %t170)
  %t172 = call ptr @__olang_scope_hold(ptr %t171)
  %t173 = ptrtoint ptr %t172 to i64
  %t175 = inttoptr i64 %t173 to ptr
  %t176 = load ptr, ptr %l89, !tbaa !29
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t175, ptr %t176, i32 %t169)
  store i32 %t178, ptr %l92
  br label %bb30
bb30:
  %t179 = load i64, ptr %l13, !tbaa !24
  %t180 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t183 = call i64 @__olang_fmt_i64(ptr null, i64 %t179)
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t180, i64 %t181)
  %t186 = getelementptr i8, ptr %t185, i64 %t181
  %t187 = call i64 @__olang_fmt_i64(ptr %t186, i64 %t179)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t185, 1
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i32, ptr %l88, !tbaa !23
  %t193 = load i32, ptr %l92, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s5, ptr %v1, ptr %t191, i32 %t192, i32 %t193, { i64, ptr } %t189)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t195 = load i64, ptr %l12, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l12, !tbaa !24
  br label %bb24
bb33:
  %t200 = load i32, ptr %l1, !tbaa !23
  store i32 %t200, ptr %rv
  br label %ret
bb34:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/mir:verifier", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  store ptr %t205, ptr %l101, !tbaa !29
  %t206 = load i32, ptr %l1, !tbaa !23
  %t207 = load ptr, ptr %l101, !tbaa !29
  %t208 = call ptr @__olang_scope_or(ptr %v1, ptr %t207)
  %t209 = call ptr @__olang_scope_hold(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  %t212 = inttoptr i64 %t210 to ptr
  %t213 = load ptr, ptr %l101, !tbaa !29
  %t215 = call i32 @compiler_2fmir_2eCasesOf(ptr %t212, ptr %t213, i32 %t206)
  store i32 %t215, ptr %l104
  br label %bb35
bb35:
  %t216 = load i32, ptr %l104, !tbaa !23
  store i32 %t216, ptr %l14, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/mir:verifier", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  store ptr %t220, ptr %l106, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t222 = load ptr, ptr %l106, !tbaa !29
  %t223 = call ptr @__olang_scope_or(ptr %v1, ptr %t222)
  %t224 = call ptr @__olang_scope_hold(ptr %t223)
  %t225 = ptrtoint ptr %t224 to i64
  %t227 = inttoptr i64 %t225 to ptr
  %t228 = load ptr, ptr %l106, !tbaa !29
  %t230 = call i1 @compiler_2fmir_2eHasCases(ptr %t227, ptr %t228, i32 %t221)
  store i1 %t230, ptr %l109
  br label %bb36
bb36:
  %t231 = load i1, ptr %l109, !tbaa !21
  store i1 %t231, ptr %l15, !tbaa !21
  %t232 = load ptr, ptr %l4, !tbaa !29
  store ptr %t232, ptr %l110, !tbaa !29
  %t233 = load i32, ptr %l14, !tbaa !23
  %t234 = load ptr, ptr %l110, !tbaa !29
  %t235 = call ptr @__olang_scope_or(ptr %v1, ptr %t234)
  %t236 = call ptr @__olang_scope_hold(ptr %t235)
  %t237 = ptrtoint ptr %t236 to i64
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/mir:verifier", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = call ptr @__olang_scope_or(ptr %v1, ptr %t241)
  %t244 = call ptr @__olang_scope_hold(ptr %t243)
  %t245 = ptrtoint ptr %t244 to i64
  %t247 = inttoptr i64 %t237 to ptr
  %t249 = inttoptr i64 %t245 to ptr
  %t250 = load ptr, ptr %l110, !tbaa !29
  %t252 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t247, ptr %t249, ptr %t250, i32 %t233)
  store { i64, ptr } %t252, ptr %l116
  br label %bb37
bb37:
  %t253 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t253, ptr %l16, !tbaa !27
  %t254 = load i1, ptr %l15, !tbaa !21
  br i1 %t254, label %bb38, label %bb39
bb38:
  %t256 = load i64, ptr %l2, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  br i1 %t258, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb42
bb41:
  %t260 = load i64, ptr %l2, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t266 = icmp sge i64 %t260, %t263
  store i1 %t266, ptr %l120, !tbaa !21
  br label %bb42
bb42:
  %t268 = load i1, ptr %l120, !tbaa !21
  br i1 %t268, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load i64, ptr %l2, !tbaa !24
  store i64 %t270, ptr %l126, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i32, ptr %l1, !tbaa !23
  %t275 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %v1, ptr %t271, i32 %t272)
  store { i64, ptr } %t275, ptr %l129
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t276 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t278 = load i64, ptr %l126, !tbaa !24
  %t279 = call i64 @__olang_fmt_i64(ptr null, i64 %t278)
  %t280 = add i64 %t277, %t279
  %t281 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t287 = add i64 %t283, %t286
  %t288 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t287)
  call void @olang_textcopy(ptr %t288, ptr %t276, i64 %t277)
  %t289 = getelementptr i8, ptr %t288, i64 %t277
  %t290 = call i64 @__olang_fmt_i64(ptr %t289, i64 %t278)
  %t291 = getelementptr i8, ptr %t289, i64 %t279
  call void @olang_textcopy(ptr %t291, ptr %t281, i64 %t282)
  %t292 = getelementptr i8, ptr %t291, i64 %t282
  call void @olang_textcopy(ptr %t292, ptr %t285, i64 %t286)
  %t293 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t288, 1
  %t296 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t296, { i64, ptr } %t294)
  br label %bb46
bb46:
  %t298 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t298, ptr %rv
  br label %ret
bb47:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l133, !tbaa !29
  %t301 = load i32, ptr %l1, !tbaa !23
  store i32 %t301, ptr %l134, !tbaa !23
  %t302 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t302, ptr %l135, !tbaa !27
  %t303 = load i64, ptr %l2, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t310 = icmp ne i32 %t308, 0
  br i1 %t310, label %bb48, label %bb49
bb48:
  %t312 = load ptr, ptr %l4, !tbaa !29
  store ptr %t312, ptr %l140, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t313, ptr %l141, !tbaa !27
  %t314 = load i64, ptr %l2, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr i32, ptr %t317, i64 %t314
  %t319 = load i32, ptr %t318, !tbaa !33
  %t320 = load ptr, ptr %l140, !tbaa !29
  %t321 = call ptr @__olang_scope_or(ptr %v1, ptr %t320)
  %t322 = call ptr @__olang_scope_hold(ptr %t321)
  %t323 = ptrtoint ptr %t322 to i64
  %t325 = inttoptr i64 %t323 to ptr
  %t326 = load ptr, ptr %l140, !tbaa !29
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t325, ptr %t326, i32 %t319)
  store i32 %t328, ptr %l145
  br label %bb50
bb49:
  store i32 0, ptr %l139, !tbaa !23
  br label %bb51
bb50:
  %t329 = load i32, ptr %l145, !tbaa !23
  store i32 %t329, ptr %l139, !tbaa !23
  br label %bb51
bb51:
  %t330 = load %"compiler/mir:Range", ptr %l3
  %t331 = load ptr, ptr %l133, !tbaa !29
  %t332 = load i32, ptr %l134, !tbaa !23
  %t333 = load i32, ptr %l139, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %t331, i32 %t332, i32 %t333, %"compiler/mir:Range" %t330)
  br label %bb52
bb52:
  %t335 = load i32, ptr %l1, !tbaa !23
  store i32 %t335, ptr %rv
  br label %ret
bb53:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/mir:verifier", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  store ptr %t340, ptr %l149, !tbaa !29
  %t341 = load i32, ptr %l1, !tbaa !23
  %t342 = load ptr, ptr %l149, !tbaa !29
  %t343 = call ptr @__olang_scope_or(ptr %v1, ptr %t342)
  %t344 = call ptr @__olang_scope_hold(ptr %t343)
  %t345 = ptrtoint ptr %t344 to i64
  %t347 = inttoptr i64 %t345 to ptr
  %t348 = load ptr, ptr %l149, !tbaa !29
  %t350 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t347, ptr %t348, i32 %t341)
  store i32 %t350, ptr %l152
  br label %bb54
bb54:
  %t351 = load i32, ptr %l152, !tbaa !23
  store i32 %t351, ptr %l17, !tbaa !23
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/mir:verifier", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  store ptr %t355, ptr %l154, !tbaa !29
  %t356 = load i32, ptr %l1, !tbaa !23
  %t357 = load ptr, ptr %l154, !tbaa !29
  %t358 = call ptr @__olang_scope_or(ptr %v1, ptr %t357)
  %t359 = call ptr @__olang_scope_hold(ptr %t358)
  %t360 = ptrtoint ptr %t359 to i64
  %t362 = inttoptr i64 %t360 to ptr
  %t363 = load ptr, ptr %l154, !tbaa !29
  %t365 = call i1 @compiler_2fmir_2eHasFields(ptr %t362, ptr %t363, i32 %t356)
  store i1 %t365, ptr %l157
  br label %bb55
bb55:
  %t366 = load i1, ptr %l157, !tbaa !21
  %t369 = xor i1 %t366, true
  br i1 %t369, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l160, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr %l1, !tbaa !23
  %t376 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %v1, ptr %t372, i32 %t373)
  store { i64, ptr } %t376, ptr %l163
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t377 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t379 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = add i64 %t378, %t381
  %t383 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t385 = add i64 %t382, %t384
  %t386 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t377, i64 %t378)
  %t387 = getelementptr i8, ptr %t386, i64 %t378
  call void @olang_textcopy(ptr %t387, ptr %t380, i64 %t381)
  %t388 = getelementptr i8, ptr %t387, i64 %t381
  call void @olang_textcopy(ptr %t388, ptr %t383, i64 %t384)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t386, 1
  %t392 = load ptr, ptr %l160, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t392, { i64, ptr } %t390)
  br label %bb59
bb59:
  %t394 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  store i32 %t394, ptr %rv
  br label %ret
bb60:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load i32, ptr %l1, !tbaa !23
  %t398 = load i32, ptr %l17, !tbaa !23
  %t399 = load %"compiler/mir:Range", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %t396, i32 %t397, i32 %t398, %"compiler/mir:Range" %t399)
  br label %bb61
bb61:
  %t404 = load i32, ptr %l1, !tbaa !23
  store i32 %t404, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l65 = alloca i64
  %l68 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, [4 x i64] }
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i1
  %l122 = alloca i1
  %l127 = alloca i1
  %l138 = alloca i1
  %l150 = alloca i32
  %l153 = alloca i32
  %l173 = alloca ptr
  %l180 = alloca { i64, [1 x i64] }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  store ptr %t7, ptr %l26, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l26, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v1, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l26, !tbaa !29
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t14, ptr %t15, i32 %t8)
  store i32 %t17, ptr %l29
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l25, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/mir:verifier", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t21 to ptr
  %t33 = inttoptr i64 %t29 to ptr
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load i32, ptr %l29, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t31, ptr %t33, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l34
  br label %bb2
bb2:
  %t37 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  %t38 = load { i64, [7 x i64] }, ptr %l1
  %t40 = extractvalue { i64, [7 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 1
  br i1 %t41, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t43 = load { i64, [7 x i64] }, ptr %l1
  %t45 = extractvalue { i64, [7 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 4
  br i1 %t46, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd)
  unreachable
bb13:
  %t48 = load i1, ptr %l35, !tbaa !21
  store i1 %t48, ptr %l7, !tbaa !21
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t58 = icmp ne i64 %t51, %t55
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = load i1, ptr %l7, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb16:
  %t62 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp sgt i64 %t65, %t68
  store i1 %t71, ptr %l47, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l47, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l45, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t86 = sext i32 %t79 to i64
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t94 = add i64 %t91, %t93
  %t95 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t83, i64 %t84)
  %t99 = getelementptr i8, ptr %t98, i64 %t84
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t86)
  %t101 = getelementptr i8, ptr %t99, i64 %t87
  call void @olang_textcopy(ptr %t101, ptr %t89, i64 %t90)
  %t102 = getelementptr i8, ptr %t101, i64 %t90
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t82)
  %t104 = getelementptr i8, ptr %t102, i64 %t93
  call void @olang_textcopy(ptr %t104, ptr %t95, i64 %t96)
  %t105 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t98, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } %t106)
  br label %bb22
bb21:
  store i64 0, ptr %l8, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb23, label %bb24
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb28
bb25:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l10, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l68, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb27
bb27:
  %t140 = load i64, ptr %l68, !tbaa !24
  store i64 %t140, ptr %l65, !tbaa !24
  br label %bb28
bb28:
  %t141 = load i64, ptr %l65, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb31:
  br label %bb32
bb32:
  %t150 = load i64, ptr %l8, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l10, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l13, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load %"compiler/mir:Range", ptr %l3
  %t163 = load i64, ptr %l13, !tbaa !24
  %t167 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %v2, ptr %t161, %"compiler/mir:Range" %t162, i64 %t163)
  store { i64, [4 x i64] } %t167, ptr %l90
  br label %bb33
bb33:
  %t168 = load ptr, ptr %l86, !tbaa !29
  %t169 = load { i64, [4 x i64] }, ptr %l90
  %t170 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v1, ptr %t168, { i64, [4 x i64] } %t169)
  store i32 %t170, ptr %l91
  br label %bb34
bb34:
  %t171 = load i32, ptr %l91, !tbaa !23
  store i32 %t171, ptr %l14, !tbaa !23
  %t172 = load i1, ptr %l7, !tbaa !21
  br i1 %t172, label %bb35, label %bb36
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t175, ptr %l95, !tbaa !27
  %t176 = load i64, ptr %l13, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t176
  %t181 = load i32, ptr %t180, !tbaa !33
  %t184 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %v1, ptr %t174, i32 %t181)
  store i1 %t184, ptr %l98
  br label %bb37
bb36:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb38
bb37:
  %t185 = load i1, ptr %l98, !tbaa !21
  store i1 %t185, ptr %l93, !tbaa !21
  br label %bb38
bb38:
  %t186 = load i1, ptr %l93, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l14, !tbaa !23
  %t191 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %v1, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l102
  br label %bb41
bb40:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb42
bb41:
  %t192 = load i1, ptr %l102, !tbaa !21
  store i1 %t192, ptr %l99, !tbaa !21
  br label %bb42
bb42:
  %t193 = load i1, ptr %l99, !tbaa !21
  br i1 %t193, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l14, !tbaa !23
  %t196 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t196, ptr %l105, !tbaa !27
  %t197 = load i64, ptr %l13, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i32, ptr %t200, i64 %t197
  %t202 = load i32, ptr %t201, !tbaa !33
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t207 = call i64 @__olang_fmt_i64(ptr null, i64 %t203)
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = getelementptr i8, ptr %t209, i64 %t205
  %t211 = call i64 @__olang_fmt_i64(ptr %t210, i64 %t203)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t209, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s7, ptr %v1, ptr %t194, i32 %t195, i32 %t202, { i64, ptr } %t213)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb47:
  %t219 = load i64, ptr %l12, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l12, !tbaa !24
  br label %bb29
bb48:
  br label %bb49
bb49:
  %t224 = load ptr, ptr %l5, !tbaa !29
  store ptr %t224, ptr %l114, !tbaa !29
  %t225 = load { i64, [7 x i64] }, ptr %l1
  %t226 = load i32, ptr %l2, !tbaa !23
  %t227 = load ptr, ptr %l114, !tbaa !29
  %t228 = call ptr @__olang_scope_or(ptr %v1, ptr %t227)
  %t229 = call ptr @__olang_scope_hold(ptr %t228)
  %t230 = ptrtoint ptr %t229 to i64
  %t232 = inttoptr i64 %t230 to ptr
  %t233 = load ptr, ptr %l114, !tbaa !29
  %t236 = call i64 @compiler_2fmir_2ePassedCount(ptr %t232, ptr %t233, { i64, [7 x i64] } %t225, i32 %t226)
  store i64 %t236, ptr %l118
  br label %bb50
bb50:
  %t237 = load i64, ptr %l118, !tbaa !24
  store i64 %t237, ptr %l15, !tbaa !24
  %t238 = load { i64, [7 x i64] }, ptr %l1
  %t240 = extractvalue { i64, [7 x i64] } %t238, 0
  %t241 = icmp eq i64 %t240, 0
  br i1 %t241, label %bb51, label %bb52
bb51:
  %t243 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t244 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t243, i32 0, i32 0
  %t245 = load { i64, [2 x i64] }, ptr %t244
  %t247 = extractvalue { i64, [2 x i64] } %t245, 0
  %t248 = icmp eq i64 %t247, 0
  store i1 %t248, ptr %l122, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb53
bb53:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb54, label %bb55
bb54:
  br label %bb61
bb55:
  %t251 = load { i64, [7 x i64] }, ptr %l1
  %t253 = extractvalue { i64, [7 x i64] } %t251, 0
  %t254 = icmp eq i64 %t253, 0
  br i1 %t254, label %bb56, label %bb57
bb56:
  %t256 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t257 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t256, i32 0, i32 0
  %t258 = load { i64, [2 x i64] }, ptr %t257
  %t260 = extractvalue { i64, [2 x i64] } %t258, 0
  %t261 = icmp eq i64 %t260, 6
  store i1 %t261, ptr %l127, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb58
bb58:
  %t263 = load i1, ptr %l127, !tbaa !21
  br i1 %t263, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t264 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t265 = load i32, ptr %t264, !tbaa !23
  %t267 = sext i32 %t265 to i64
  %t268 = load i64, ptr %l15, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  store i1 %t271, ptr %l119, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_2214b4a83e210b00_93c2dace4d13d4cc)
  unreachable
bb67:
  %t273 = load i1, ptr %l119, !tbaa !21
  store i1 %t273, ptr %l16, !tbaa !21
  %t274 = load i64, ptr %l15, !tbaa !24
  %t275 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  %t281 = icmp ne i64 %t274, %t278
  br i1 %t281, label %bb68, label %bb69
bb68:
  %t283 = load i1, ptr %l16, !tbaa !21
  %t285 = xor i1 %t283, true
  store i1 %t285, ptr %l138, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb70
bb70:
  %t287 = load i1, ptr %l138, !tbaa !21
  br i1 %t287, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load i64, ptr %l15, !tbaa !24
  %t292 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t295 = sext i32 %t290 to i64
  %t296 = call i64 @__olang_fmt_i64(ptr null, i64 %t295)
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t302 = call i64 @__olang_fmt_i64(ptr null, i64 %t291)
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t292, i64 %t293)
  %t305 = getelementptr i8, ptr %t304, i64 %t293
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t295)
  %t307 = getelementptr i8, ptr %t305, i64 %t296
  call void @olang_textcopy(ptr %t307, ptr %t298, i64 %t299)
  %t308 = getelementptr i8, ptr %t307, i64 %t299
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t291)
  %t310 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t304, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t288, { i64, ptr } %t311)
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb74
bb74:
  store i32 0, ptr %l17, !tbaa !23
  %t315 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t316 = load i32, ptr %t315, !tbaa !23
  store i32 %t316, ptr %l18, !tbaa !23
  store i32 1, ptr %l19, !tbaa !23
  %t318 = load i32, ptr %l18, !tbaa !23
  %t319 = load i32, ptr %l17, !tbaa !23
  %t322 = icmp sgt i32 %t318, %t319
  br i1 %t322, label %bb75, label %bb76
bb75:
  %t324 = load i32, ptr %l19, !tbaa !23
  %t326 = icmp sgt i32 %t324, 0
  br i1 %t326, label %bb77, label %bb78
bb76:
  store i32 0, ptr %l150, !tbaa !23
  br label %bb80
bb77:
  %t328 = load i32, ptr %l18, !tbaa !23
  %t329 = load i32, ptr %l17, !tbaa !23
  %t332 = sub i32 %t328, %t329
  %t333 = load i32, ptr %l19, !tbaa !23
  %t336 = add i32 %t332, %t333
  %t338 = sub i32 %t336, 1
  %t339 = load i32, ptr %l19, !tbaa !23
  %t342 = sdiv i32 %t338, %t339
  store i32 %t342, ptr %l153, !tbaa !23
  br label %bb79
bb78:
  store i32 0, ptr %l153, !tbaa !23
  br label %bb79
bb79:
  %t344 = load i32, ptr %l153, !tbaa !23
  store i32 %t344, ptr %l150, !tbaa !23
  br label %bb80
bb80:
  %t345 = load i32, ptr %l150, !tbaa !23
  store i32 %t345, ptr %l20, !tbaa !23
  store i32 0, ptr %l21, !tbaa !23
  br label %bb81
bb81:
  %t346 = load i32, ptr %l21, !tbaa !23
  %t347 = load i32, ptr %l20, !tbaa !23
  %t350 = icmp slt i32 %t346, %t347
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb82, label %bb83
bb82:
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t354 = load i32, ptr %l17, !tbaa !23
  %t355 = load i32, ptr %l21, !tbaa !23
  %t356 = load i32, ptr %l19, !tbaa !23
  %t359 = mul i32 %t355, %t356
  %t362 = add i32 %t354, %t359
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/mir:verifier", ptr %t364, i32 0, i32 0
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t369 = getelementptr %"compiler/mir:Fn", ptr %t367, i32 0, i32 12
  store ptr %t369, ptr %l173, !tbaa !29
  %t370 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t371 = load i32, ptr %t370, !tbaa !23
  %t373 = sext i32 %t371 to i64
  %t376 = sext i32 %t362 to i64
  %t379 = add i64 %t373, %t376
  %t380 = load ptr, ptr %l173, !tbaa !29
  %t381 = call ptr @__olang_scope_or(ptr %v2, ptr %t380)
  %t382 = call ptr @__olang_scope_hold(ptr %t381)
  %t383 = ptrtoint ptr %t382 to i64
  %t385 = inttoptr i64 %t383 to ptr
  %t386 = load ptr, ptr %l173, !tbaa !29
  %t388 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t385, ptr %t386, i64 %t379)
  store { i64, [1 x i64] } %t388, ptr %l180
  br label %bb85
bb85:
  %t389 = load { i64, [1 x i64] }, ptr %l180
  %t391 = extractvalue { i64, [1 x i64] } %t389, 0
  %t392 = icmp eq i64 %t391, 3
  br i1 %t392, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s17
  %t394 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t394, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t396 = load i32, ptr %l21, !tbaa !23
  %t399 = add i32 %t396, 1
  store i32 %t399, ptr %l21, !tbaa !23
  br label %bb81
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:verifier", ptr %t15, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t17, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t19, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:verifier", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t33, i64 %t34)
  %t42 = getelementptr i8, ptr %t41, i64 %t34
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t32)
  %t44 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t38, i64 %t39)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t41, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t28, { i64, ptr } %t46)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s6
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/mir:verifier", ptr %t50, i32 0, i32 2
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/mir:verifier", ptr %t53, i32 0, i32 3
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:verifier", ptr %t57, i32 0, i32 4
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t64 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t65 = add i64 %t62, %t64
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t60)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t61, i64 %t62)
  %t76 = getelementptr i8, ptr %t75, i64 %t62
  %t77 = call i64 @__olang_fmt_i64(ptr %t76, i64 %t56)
  %t78 = getelementptr i8, ptr %t76, i64 %t64
  call void @olang_textcopy(ptr %t78, ptr %t66, i64 %t67)
  %t79 = getelementptr i8, ptr %t78, i64 %t67
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t60)
  %t81 = getelementptr i8, ptr %t79, i64 %t70
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t52, { i64, ptr } %t83)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/mir:verifier", ptr %t87, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %a1)
  br label %bb13
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/mir:verifier", ptr %t93, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t95, i8 10)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i64
  %l33 = alloca i32
  %rv = alloca i32
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v1, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t32 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %t28, ptr %t29, i32 %a1, i64 %a2)
  store i64 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t34 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp ne i64 %t34, %t33
  store i1 %t36, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l12, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t39 = load i32, ptr %l3, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v1, ptr %t44)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t47 to ptr
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t49, ptr %t50, i32 %t43)
  store i32 %t52, ptr %l25
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l4, !tbaa !29
  store ptr %t53, ptr %l26, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = call ptr @__olang_scope_or(ptr %v1, ptr %t55)
  %t57 = call ptr @__olang_scope_hold(ptr %t56)
  %t58 = ptrtoint ptr %t57 to i64
  %t60 = inttoptr i64 %t58 to ptr
  %t61 = load ptr, ptr %l26, !tbaa !29
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t60, ptr %t61, i32 %t54)
  store i64 %t63, ptr %l29
  br label %bb10
bb10:
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t65 = load i64, ptr %l29, !tbaa !24
  %t67 = or i64 %t65, %t64
  %t68 = load ptr, ptr %l21, !tbaa !29
  %t69 = call ptr @__olang_scope_or(ptr %v1, ptr %t68)
  %t70 = call ptr @__olang_scope_hold(ptr %t69)
  %t71 = ptrtoint ptr %t70 to i64
  %t73 = inttoptr i64 %t71 to ptr
  %t74 = load ptr, ptr %l21, !tbaa !29
  %t75 = load i32, ptr %l25, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t73, ptr %t74, i32 %t75, i64 %t67)
  store i32 %t77, ptr %l33
  br label %bb11
bb11:
  %t78 = load i32, ptr %l33, !tbaa !23
  store i32 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb5
bb2:
  %t10 = load { i64, [7 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [7 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 4
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t20 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %t20)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_43daeee16a7347fc_3936ff71893c42a0)
  unreachable
bb12:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l10 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t11, ptr %t12, i32 %t5)
  store i32 %t14, ptr %l6
  br label %bb1
bb1:
  %t15 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t17 = trunc i64 21 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/mir:verifier", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l12, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v1, ptr %t27)
  %t29 = call ptr @__olang_scope_hold(ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  %t32 = inttoptr i64 %t30 to ptr
  %t33 = load ptr, ptr %l12, !tbaa !29
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %t32, ptr %t33, i32 %t26)
  store i1 %t35, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t36 = load i1, ptr %l15, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l10, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l17, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v1, ptr %t41, i32 %t42)
  store { i64, ptr } %t45, ptr %l20
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t48 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t57, { i64, ptr } %t55)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t59 = load i32, ptr %l1, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l65 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i32
  %l86 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l14, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t13, ptr %t14, i32 %t7)
  store i32 %t16, ptr %l17
  br label %bb1
bb1:
  %t17 = load i32, ptr %l17, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l18, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t25, ptr %t26, i32 %t19)
  store i32 %t28, ptr %l21
  br label %bb2
bb2:
  %t29 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t31 = trunc i64 22 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l24, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l25, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v1, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t42, ptr %t43, i32 %t36)
  store i32 %t45, ptr %l28
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v1, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/mir:verifier", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @__olang_scope_or(ptr %v1, ptr %t53)
  %t56 = call ptr @__olang_scope_hold(ptr %t55)
  %t57 = ptrtoint ptr %t56 to i64
  %t59 = inttoptr i64 %t49 to ptr
  %t61 = inttoptr i64 %t57 to ptr
  %t62 = load ptr, ptr %l24, !tbaa !29
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t59, ptr %t61, ptr %t62, i32 %t63)
  store { i64, ptr } %t64, ptr %l33
  br label %bb6
bb6:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l4, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l35, !tbaa !24
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  br i1 %t70, label %bb7, label %bb8
bb7:
  %t72 = load i64, ptr %l35, !tbaa !24
  %t73 = icmp sle i64 %t72, 2305843009213693951
  br i1 %t73, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb9:
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = mul i64 %t75, 4
  %t77 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb11:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb16
bb13:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l47, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb15
bb15:
  %t111 = load i64, ptr %l47, !tbaa !24
  store i64 %t111, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t112 = load i64, ptr %l44, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  store i64 %t131, ptr %l65, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  %t136 = load i64, ptr %l11, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i32, ptr %t139, i64 %t136
  %t141 = load i32, ptr %t140, !tbaa !33
  %t146 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %v1, ptr %t132, i32 %t133, i64 %t134, i32 %t141)
  store i32 %t146, ptr %l72
  br label %bb21
bb21:
  %t147 = load i32, ptr %l72, !tbaa !23
  %t148 = load i64, ptr %l65, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t148
  store i32 %t147, ptr %t151, !tbaa !33
  br label %bb22
bb22:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb17
bb23:
  %t157 = load ptr, ptr %l2, !tbaa !29
  store ptr %t157, ptr %l76, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  store ptr %t158, ptr %l77, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t160 = load ptr, ptr %l77, !tbaa !29
  %t161 = call ptr @__olang_scope_or(ptr %v1, ptr %t160)
  %t162 = call ptr @__olang_scope_hold(ptr %t161)
  %t163 = ptrtoint ptr %t162 to i64
  %t165 = inttoptr i64 %t163 to ptr
  %t166 = load ptr, ptr %l77, !tbaa !29
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %t165, ptr %s1, ptr %t166, { i64, ptr } %t159)
  store i32 %t168, ptr %l80
  br label %bb24
bb24:
  %t169 = load ptr, ptr %l76, !tbaa !29
  %t170 = call ptr @__olang_scope_or(ptr %v1, ptr %t169)
  %t171 = call ptr @__olang_scope_hold(ptr %t170)
  %t172 = ptrtoint ptr %t171 to i64
  %t174 = inttoptr i64 %t172 to ptr
  %t175 = load ptr, ptr %l76, !tbaa !29
  %t176 = load i32, ptr %l80, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %t174, ptr %t175, i32 %t176)
  store i32 %t177, ptr %l82
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t178 = load i32, ptr %l82, !tbaa !23
  store i32 %t178, ptr %rv
  br label %ret
bb26:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  %t181 = load i32, ptr %l3, !tbaa !23
  %t185 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %v1, ptr %t179, i32 %t180, i64 0, i32 %t181)
  store i32 %t185, ptr %l86
  br label %bb27
bb27:
  %t186 = load i32, ptr %l86, !tbaa !23
  store i32 %t186, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l37 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l14, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/mir:verifier", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 20
  store ptr %t55, ptr %l37, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = sext i32 %t48 to i64
  %t65 = add i64 %t59, %t62
  %t66 = load ptr, ptr %l37, !tbaa !29
  %t67 = call ptr @__olang_scope_or(ptr %v1, ptr %t66)
  %t68 = call ptr @__olang_scope_hold(ptr %t67)
  %t69 = ptrtoint ptr %t68 to i64
  %t71 = inttoptr i64 %t69 to ptr
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %t71, ptr %t72, i64 %t65)
  store i32 %t74, ptr %l44
  br label %bb11
bb11:
  %t75 = load i32, ptr %l44, !tbaa !23
  store i32 %t75, ptr %l9, !tbaa !23
  %t76 = load i32, ptr %l9, !tbaa !23
  %t78 = icmp slt i32 %t76, 0
  br i1 %t78, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  %t80 = load i32, ptr %l9, !tbaa !23
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = trunc i64 %t81 to i32
  %t86 = icmp sge i32 %t80, %t83
  store i1 %t86, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t88 = load i1, ptr %l47, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l2, !tbaa !24
  %t91 = load i32, ptr %l9, !tbaa !23
  %t92 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t95 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t96 = add i64 %t93, %t95
  %t97 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t101 = sext i32 %t91 to i64
  %t102 = call i64 @__olang_fmt_i64(ptr null, i64 %t101)
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t92, i64 %t93)
  %t108 = getelementptr i8, ptr %t107, i64 %t93
  %t109 = call i64 @__olang_fmt_i64(ptr %t108, i64 %t90)
  %t110 = getelementptr i8, ptr %t108, i64 %t95
  call void @olang_textcopy(ptr %t110, ptr %t97, i64 %t98)
  %t111 = getelementptr i8, ptr %t110, i64 %t98
  %t112 = call i64 @__olang_fmt_i64(ptr %t111, i64 %t101)
  %t113 = getelementptr i8, ptr %t111, i64 %t102
  call void @olang_textcopy(ptr %t113, ptr %t104, i64 %t105)
  %t114 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t107, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t89, { i64, ptr } %t115)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = add i32 %t119, 1
  store i32 %t122, ptr %l7, !tbaa !23
  br label %bb7
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca ptr
  %l65 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v1, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t14, ptr %t15, i32 %t8)
  store i32 %t17, ptr %l13
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t23, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l15
  br label %bb2
bb2:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v1, ptr %t31)
  %t33 = call ptr @__olang_scope_hold(ptr %t32)
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = inttoptr i64 %t34 to ptr
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t36, ptr %t37, i32 %t30)
  store i32 %t39, ptr %l21
  br label %bb5
bb4:
  %t40 = load i32, ptr %l1, !tbaa !23
  store i32 %t40, ptr %l16, !tbaa !23
  br label %bb7
bb5:
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t43 = call ptr @__olang_scope_or(ptr %v1, ptr %t42)
  %t44 = call ptr @__olang_scope_hold(ptr %t43)
  %t45 = ptrtoint ptr %t44 to i64
  %t47 = inttoptr i64 %t45 to ptr
  %t48 = load ptr, ptr %l17, !tbaa !29
  %t49 = load i32, ptr %l21, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t47, ptr %t48, i32 %t49)
  store i32 %t50, ptr %l23
  br label %bb6
bb6:
  %t51 = load i32, ptr %l23, !tbaa !23
  store i32 %t51, ptr %l16, !tbaa !23
  br label %bb7
bb7:
  %t52 = load i32, ptr %l16, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %v1, ptr %t53, i32 %t52)
  store i32 %t57, ptr %l27
  br label %bb8
bb8:
  %t58 = load i32, ptr %l27, !tbaa !23
  store i32 %t58, ptr %l6, !tbaa !23
  %t59 = load i32, ptr %l6, !tbaa !23
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t63 = icmp eq i32 %t59, %t60
  br i1 %t63, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb12
bb10:
  %t65 = load ptr, ptr %l4, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  %t66 = load i32, ptr %l6, !tbaa !23
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = call ptr @__olang_scope_or(ptr %v1, ptr %t67)
  %t69 = call ptr @__olang_scope_hold(ptr %t68)
  %t70 = ptrtoint ptr %t69 to i64
  %t72 = inttoptr i64 %t70 to ptr
  %t73 = load ptr, ptr %l32, !tbaa !29
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t72, ptr %t73, i32 %t66)
  store i32 %t75, ptr %l35
  br label %bb11
bb11:
  %t76 = load i32, ptr %l35, !tbaa !23
  %t77 = icmp ne i32 %t76, 0
  store i1 %t77, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t79 = load i1, ptr %l31, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l37, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v1, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l40
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t86 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t88 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t86, i64 %t87)
  %t96 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t96, ptr %t89, i64 %t90)
  %t97 = getelementptr i8, ptr %t96, i64 %t90
  call void @olang_textcopy(ptr %t97, ptr %t92, i64 %t93)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  %t101 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t101, { i64, ptr } %t99)
  br label %bb16
bb16:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t103, ptr %rv
  br label %ret
bb17:
  %t105 = load ptr, ptr %l4, !tbaa !29
  store ptr %t105, ptr %l44, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  store ptr %t106, ptr %l45, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t111 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v1, ptr %t107, { i64, [4 x i64] } %a2)
  store i32 %t111, ptr %l48
  br label %bb18
bb18:
  %t112 = load ptr, ptr %l45, !tbaa !29
  %t113 = call ptr @__olang_scope_or(ptr %v1, ptr %t112)
  %t114 = call ptr @__olang_scope_hold(ptr %t113)
  %t115 = ptrtoint ptr %t114 to i64
  %t117 = inttoptr i64 %t115 to ptr
  %t118 = load ptr, ptr %l45, !tbaa !29
  %t119 = load i32, ptr %l48, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t117, ptr %t118, i32 %t119)
  store i32 %t120, ptr %l50
  br label %bb19
bb19:
  %t121 = load ptr, ptr %l44, !tbaa !29
  %t122 = call ptr @__olang_scope_or(ptr %v1, ptr %t121)
  %t123 = call ptr @__olang_scope_hold(ptr %t122)
  %t124 = ptrtoint ptr %t123 to i64
  %t126 = inttoptr i64 %t124 to ptr
  %t127 = load ptr, ptr %l44, !tbaa !29
  %t128 = load i32, ptr %l50, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t126, ptr %t127, i32 %t128)
  store i1 %t129, ptr %l52
  br label %bb20
bb20:
  %t130 = load i1, ptr %l52, !tbaa !21
  %t131 = xor i1 %t130, true
  br i1 %t131, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t133 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t133, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t135 = load { i64, [4 x i64] }, ptr %l3
  %t137 = extractvalue { i64, [4 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 0
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l58, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, [4 x i64] }, ptr %l3
  %t147 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v1, ptr %t143, { i64, [4 x i64] } %t144)
  store i32 %t147, ptr %l61
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t148 = load ptr, ptr %l4, !tbaa !29
  store ptr %t148, ptr %l62, !tbaa !29
  %t149 = load i32, ptr %l6, !tbaa !23
  %t150 = load ptr, ptr %l62, !tbaa !29
  %t151 = call ptr @__olang_scope_or(ptr %v1, ptr %t150)
  %t152 = call ptr @__olang_scope_hold(ptr %t151)
  %t153 = ptrtoint ptr %t152 to i64
  %t155 = inttoptr i64 %t153 to ptr
  %t156 = load ptr, ptr %l62, !tbaa !29
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t155, ptr %t156, i32 %t149)
  store i32 %t158, ptr %l65
  br label %bb28
bb28:
  %t159 = load ptr, ptr %l58, !tbaa !29
  %t160 = load i32, ptr %l61, !tbaa !23
  %t161 = load i32, ptr %l65, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %v1, ptr %t159, i32 %t160, i32 %t161, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t162 = load i32, ptr %l1, !tbaa !23
  store i32 %t162, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l8 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t8 = trunc i64 3 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t13 = trunc i64 4 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t23 = trunc i64 6 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp eq i32 %t27, 2
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb21
bb10:
  %t31 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t33 = trunc i64 0 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l8, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97)
  unreachable
bb21:
  %t46 = load i1, ptr %l8, !tbaa !21
  %t49 = xor i1 %t46, true
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 54}
  store i32 %t52, ptr %l28
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s5, ptr %l28, i64 0)
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t54 = load ptr, ptr %s5
  %t55 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l30, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.64
sbdone.64:
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s4, ptr %s4, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l32
  br label %bb25
bb25:
  %t68 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t72 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = sext i32 %t69 to i64
  %t81 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t70, i64 %t71)
  %t87 = getelementptr i8, ptr %t86, i64 %t71
  call void @olang_textcopy(ptr %t87, ptr %t73, i64 %t74)
  %t88 = getelementptr i8, ptr %t87, i64 %t74
  call void @olang_textcopy(ptr %t88, ptr %t76, i64 %t77)
  %t89 = getelementptr i8, ptr %t88, i64 %t77
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t80)
  %t91 = getelementptr i8, ptr %t89, i64 %t81
  call void @olang_textcopy(ptr %t91, ptr %t83, i64 %t84)
  %t92 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t86, 1
  %t95 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t95, { i64, ptr } %t93)
  br label %bb26
bb26:
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t97, ptr %rv
  br label %ret
bb27:
  %t99 = load ptr, ptr %l4, !tbaa !29
  store ptr %t99, ptr %l37, !tbaa !29
  %t100 = load ptr, ptr %l4, !tbaa !29
  store ptr %t100, ptr %l38, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = call ptr @__olang_scope_or(ptr %v1, ptr %t102)
  %t104 = call ptr @__olang_scope_hold(ptr %t103)
  %t105 = ptrtoint ptr %t104 to i64
  %t107 = inttoptr i64 %t105 to ptr
  %t108 = load ptr, ptr %l38, !tbaa !29
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t107, ptr %t108, i32 %t101)
  store i32 %t110, ptr %l41
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l37, !tbaa !29
  %t112 = call ptr @__olang_scope_or(ptr %v1, ptr %t111)
  %t113 = call ptr @__olang_scope_hold(ptr %t112)
  %t114 = ptrtoint ptr %t113 to i64
  %t116 = inttoptr i64 %t114 to ptr
  %t117 = load ptr, ptr %l37, !tbaa !29
  %t118 = load i32, ptr %l41, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t116, ptr %t117, i32 %t118)
  store i1 %t119, ptr %l43
  br label %bb29
bb29:
  %t120 = load i1, ptr %l43, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l45, !tbaa !29
  %t124 = load i32, ptr %l1, !range !{i32 0, i32 54}
  store i32 %t124, ptr %l46
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l46, i64 0)
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t126 = load ptr, ptr %s8
  %t127 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t128 = load i64, ptr %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t126, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l48, !tbaa !27
  %t132 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t133 = load ptr, ptr %t132
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %sbgrew.135, label %sbdone.136
sbgrew.135:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.136
sbdone.136:
  %t137 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t139 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t137)
  store { i64, ptr } %t139, ptr %l50
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l2, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s7, ptr %v1, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l53
  br label %bb34
bb34:
  %t145 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t147 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t153 = add i64 %t150, %t152
  %t154 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t145, i64 %t146)
  %t162 = getelementptr i8, ptr %t161, i64 %t146
  call void @olang_textcopy(ptr %t162, ptr %t148, i64 %t149)
  %t163 = getelementptr i8, ptr %t162, i64 %t149
  call void @olang_textcopy(ptr %t163, ptr %t151, i64 %t152)
  %t164 = getelementptr i8, ptr %t163, i64 %t152
  call void @olang_textcopy(ptr %t164, ptr %t155, i64 %t156)
  %t165 = getelementptr i8, ptr %t164, i64 %t156
  call void @olang_textcopy(ptr %t165, ptr %t158, i64 %t159)
  %t166 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t161, 1
  %t169 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t169, { i64, ptr } %t167)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t171 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t171, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:verifier", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v1, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t15, ptr %t16, i32 %a1)
  store i32 %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t24 = inttoptr i64 %t22 to ptr
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t24, ptr %t25, i32 %t26)
  store i32 %t27, ptr %l11
  br label %bb2
bb2:
  %t28 = load i32, ptr %l11, !range !{i32 0, i32 33}
  store i32 %t28, ptr %l2
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t31 = trunc i64 20 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t36 = trunc i64 19 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l14, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t42 = trunc i64 15 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l17, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/mir:verifier", ptr %t9, i32 0, i32 17
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t19, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %t22
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 17
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/mir:verifier", ptr %t40, i32 0, i32 17
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l27
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t51 = sext i32 %t46 to i64
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t47, 1
  %t59 = extractvalue { i64, ptr } %t47, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t51)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } %t71)
  br label %bb15
bb12:
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = sub i64 %t75, 1
  %t77 = load ptr, ptr %l24, !tbaa !29
  %t79 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t77, i64 %t76)
  store i32 %t79, ptr %l29
  br label %bb13
bb13:
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t82 = load i32, ptr %l21, !tbaa !23
  %t83 = sext i32 %t82 to i64
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = load i32, ptr %l29, !tbaa !23
  %t97 = sext i32 %t96 to i64
  %t98 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t80, i64 %t81)
  %t104 = getelementptr i8, ptr %t103, i64 %t81
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t83)
  %t106 = getelementptr i8, ptr %t104, i64 %t84
  call void @olang_textcopy(ptr %t106, ptr %t86, i64 %t87)
  %t107 = getelementptr i8, ptr %t106, i64 %t87
  call void @olang_textcopy(ptr %t107, ptr %t90, i64 %t91)
  %t108 = getelementptr i8, ptr %t107, i64 %t91
  call void @olang_textcopy(ptr %t108, ptr %t93, i64 %t94)
  %t109 = getelementptr i8, ptr %t108, i64 %t94
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t97)
  %t111 = getelementptr i8, ptr %t109, i64 %t98
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t103, 1
  %t115 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t115, { i64, ptr } %t113)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/mir:verifier", ptr %t117, i32 0, i32 17
  %t121 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t119)
  %t122 = extractvalue { i32, i32 } %t121, 1
  %t123 = extractvalue { i32, i32 } %t121, 0
  store i32 %t123, ptr %l41
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb19, label %ok.125, !prof !99
ok.125:
  store i32 %t122, ptr %l40
  br label %bb18
bb18:
  %t126 = load i32, ptr %l40, !tbaa !23
  store i32 %t126, ptr %l37, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_check_failed(ptr @olang_loc_525ae97147cf6b9b_c46e40fbd793c77f)
  unreachable
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [21 x i64] }
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca %"compiler/mir:BasicBlock"
  %l57 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca %"compiler/mir:BasicBlock"
  %l84 = alloca %"compiler/mir:BasicBlock"
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, [21 x i64] }
  %l94 = alloca { i64, [21 x i64] }
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i32
  %l115 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l134 = alloca i64
  %l137 = alloca i64
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t6, ptr %l24, !tbaa !29
  %t7 = load ptr, ptr %l24, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v1, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l24, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t12, ptr %t13)
  store i64 %t14, ptr %l26
  br label %bb1
bb1:
  %t15 = load i64, ptr %l26, !tbaa !24
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l27, !tbaa !29
  %t17 = call ptr @__olang_scope_hold(ptr %v0)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l28, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fmir_3averifier_2e13
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = call ptr @__olang_region_make(ptr %v0)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l28, !tbaa !24
  br label %bb3
bb3:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l30, !tbaa !24
  %t24 = load i64, ptr %l30, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load i64, ptr %l30, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = load i64, ptr %l28
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %t30, i64 %t28)
  %t32 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load ptr, ptr %l27, !tbaa !29
  %t35 = getelementptr %"compiler/mir:verifier", ptr %t34, i32 0, i32 13
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l33, !tbaa !27
  %t38 = load ptr, ptr %l27, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t38, i32 0, i32 13
  store { i64, ptr } %t33, ptr %t39, !tbaa !27
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2fmir_3averifier_2e13
  br i1 %t40, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608)
  unreachable
bb6:
  %t42 = load { i64, ptr }, ptr %l33
  %t43 = extractvalue { i64, ptr } %t42, 1
  call void @__olang_region_release(ptr %t43)
  store { i64, ptr } zeroinitializer, ptr %l33
  br label %bb7
bb7:
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l35
  br label %bb8
bb8:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 0)
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/mir:verifier", ptr %t47, i32 0, i32 13
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l38, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i1, ptr %t52, i64 0
  store i1 true, ptr %t53, !tbaa !31
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  store i64 %t55, ptr %l40
  br label %bb11
bb11:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = icmp sgt i64 %t56, 0
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb65
bb13:
  br label %bb14
bb14:
  %t62 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  %t63 = extractvalue { i32, i32 } %t62, 1
  %t64 = extractvalue { i32, i32 } %t62, 0
  store i32 %t64, ptr %l46
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb16, label %ok.66, !prof !99
ok.66:
  store i32 %t63, ptr %l45
  br label %bb15
bb15:
  %t67 = load i32, ptr %l45, !tbaa !23
  store i32 %t67, ptr %l43, !tbaa !23
  br label %bb18
bb16:
  br label %bb17
bb17:
  call void @__olang_check_failed(ptr @olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6)
  unreachable
bb18:
  %t68 = load i32, ptr %l43, !tbaa !23
  store i32 %t68, ptr %l3, !tbaa !23
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l47
  br label %bb19
bb19:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l48, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/mir:verifier", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/mir:Fn", ptr %t75, i32 0, i32 9
  store ptr %t77, ptr %l51, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load ptr, ptr %l51, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v1, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t86 = inttoptr i64 %t84 to ptr
  %t87 = load ptr, ptr %l51, !tbaa !29
  %t89 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t86, ptr %s3, ptr %t87, i64 %t80)
  store %"compiler/mir:BasicBlock" %t89, ptr %l55
  br label %bb20
bb20:
  %t90 = getelementptr %"compiler/mir:BasicBlock", ptr %l55, i32 0, i32 1
  %t91 = load { i64, [8 x i64] }, ptr %t90
  %t92 = load ptr, ptr %l48, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %s3, ptr %v1, ptr %t92, { i64, [8 x i64] } %t91)
  store { i64, ptr } %t94, ptr %l57
  br label %bb21
bb21:
  %t95 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t95, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t109, ptr %l65, !tbaa !27
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t115)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l6, !tbaa !24
  br label %bb22
bb28:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s6
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/mir:verifier", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/mir:Fn", ptr %t128, i32 0, i32 9
  store ptr %t130, ptr %l75, !tbaa !29
  %t131 = load i32, ptr %l3, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t135 = call ptr @__olang_scope_or(ptr %v1, ptr %t134)
  %t136 = call ptr @__olang_scope_hold(ptr %t135)
  %t137 = ptrtoint ptr %t136 to i64
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/mir:verifier", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = call ptr @__olang_scope_or(ptr %v1, ptr %t141)
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l81, !tbaa !24
  %t147 = inttoptr i64 %t137 to ptr
  %t148 = load i64, ptr %l81
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t152 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t147, ptr %t149, ptr %t150, i64 %t133)
  store %"compiler/mir:BasicBlock" %t152, ptr %l82
  br label %bb29
bb29:
  %t153 = load i64, ptr %l81
  %t154 = inttoptr i64 %t153 to ptr
  %t156 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %t154, ptr %l82)
  store %"compiler/mir:BasicBlock" %t156, ptr %l84
  br label %bb30
bb30:
  %t157 = getelementptr %"compiler/mir:BasicBlock", ptr %l84, i32 0, i32 0
  store ptr %t157, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t159 = load i64, ptr %l10, !tbaa !24
  store i64 %t159, ptr %l86, !tbaa !24
  %t160 = load ptr, ptr %l9, !tbaa !29
  %t162 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %s6, ptr %t160)
  store i64 %t162, ptr %l88
  br label %bb32
bb32:
  %t163 = load i64, ptr %l86, !tbaa !24
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb33, label %bb34
bb33:
  br label %bb51
bb34:
  br label %bb35
bb35:
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t170 = load i64, ptr %l10, !tbaa !24
  %t173 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %s6, ptr %t169, i64 %t170)
  store { i64, [21 x i64] } %t173, ptr %l93
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l93, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %l11, i64 176, i1 false)
  %t174 = load { i64, [21 x i64] }, ptr %l94
  %t175 = extractvalue { i64, [21 x i64] } %t174, 0
  %t176 = icmp eq i64 %t175, 19
  br i1 %t176, label %bb37, label %bb38
bb37:
  %t178 = getelementptr { i64, [21 x i64] }, ptr %l11, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t178, i32 0, i32 2
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l12, !tbaa !23
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t182 = load i32, ptr %l12, !tbaa !23
  %t183 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t186 = icmp ne i32 %t182, %t183
  br i1 %t186, label %bb40, label %bb41
bb40:
  %t188 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t188)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_7127dab5ce57c749_b077692428e4994d)
  unreachable
bb49:
  br label %bb50
bb50:
  %t191 = load i64, ptr %l10, !tbaa !24
  %t194 = add i64 %t191, 1
  store i64 %t194, ptr %l10, !tbaa !24
  br label %bb31
bb51:
  call void @__olang_scope_close(ptr %s6)
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb52
bb52:
  %t197 = load i64, ptr %l14, !tbaa !24
  store i64 %t197, ptr %l106, !tbaa !24
  %t198 = load ptr, ptr %l13, !tbaa !29
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t198)
  store i64 %t200, ptr %l108
  br label %bb53
bb53:
  %t201 = load i64, ptr %l106, !tbaa !24
  %t202 = load i64, ptr %l108, !tbaa !24
  %t203 = icmp slt i64 %t201, %t202
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb54, label %bb55
bb54:
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t208 = load i64, ptr %l14, !tbaa !24
  %t211 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l113
  br label %bb57
bb57:
  %t212 = load i32, ptr %l113, !tbaa !23
  store i32 %t212, ptr %l15, !tbaa !23
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/mir:verifier", ptr %t213, i32 0, i32 13
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l115, !tbaa !27
  %t217 = load i32, ptr %l15, !tbaa !23
  %t219 = sext i32 %t217 to i64
  %t221 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i1, ptr %t222, i64 %t219
  %t224 = load i1, ptr %t223, !tbaa !31
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb58, label %bb59
bb58:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/mir:verifier", ptr %t228, i32 0, i32 13
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l121, !tbaa !27
  %t232 = load i32, ptr %l15, !tbaa !23
  %t234 = sext i32 %t232 to i64
  %t236 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i1, ptr %t237, i64 %t234
  store i1 true, ptr %t238, !tbaa !31
  %t239 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 %t239)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t242 = load i64, ptr %l14, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l14, !tbaa !24
  br label %bb52
bb63:
  call void @__olang_scope_close(ptr %s1)
  br label %bb64
bb64:
  br label %bb10
bb65:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/mir:verifier", ptr %t247, i32 0, i32 4
  store i64 -1, ptr %t249, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t250 = load i64, ptr %l1, !tbaa !24
  store i64 %t250, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t253 = load i64, ptr %l16, !tbaa !24
  %t256 = icmp sgt i64 %t252, %t253
  br i1 %t256, label %bb66, label %bb67
bb66:
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = icmp sgt i64 %t258, 0
  br i1 %t260, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb71
bb68:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l16, !tbaa !24
  %t266 = sub i64 %t262, %t263
  %t267 = load i64, ptr %l18, !tbaa !24
  %t270 = add i64 %t266, %t267
  %t272 = sub i64 %t270, 1
  %t273 = load i64, ptr %l18, !tbaa !24
  %t276 = sdiv i64 %t272, %t273
  store i64 %t276, ptr %l137, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb70
bb70:
  %t278 = load i64, ptr %l137, !tbaa !24
  store i64 %t278, ptr %l134, !tbaa !24
  br label %bb71
bb71:
  %t279 = load i64, ptr %l134, !tbaa !24
  store i64 %t279, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb72
bb72:
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = load i64, ptr %l19, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb73, label %bb74
bb73:
  br label %bb81
bb74:
  br label %bb75
bb75:
  %t288 = load i64, ptr %l16, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l18, !tbaa !24
  %t293 = mul i64 %t289, %t290
  %t296 = add i64 %t288, %t293
  store i64 %t296, ptr %l21, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/mir:verifier", ptr %t298, i32 0, i32 13
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l156, !tbaa !27
  %t302 = load i64, ptr %l21, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i1, ptr %t305, i64 %t302
  %t307 = load i1, ptr %t306, !tbaa !31
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s18
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = getelementptr %"compiler/mir:verifier", ptr %t311, i32 0, i32 3
  store i64 %t312, ptr %t315, !tbaa !24
  %t316 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t316, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t318 = load i64, ptr %l20, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l20, !tbaa !24
  br label %bb72
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l11, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v1, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l14
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t26 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t28 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = getelementptr i8, ptr %t32, i64 %t27
  call void @olang_textcopy(ptr %t33, ptr %t29, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t37 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t37, { i64, ptr } %t35)
  br label %bb5
bb5:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t39, ptr %rv
  br label %ret
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp ne i32 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l22, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  store i32 %t48, ptr %l23, !tbaa !23
  %t49 = load ptr, ptr %l3, !tbaa !29
  store ptr %t49, ptr %l24, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v1, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l24, !tbaa !29
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t56, ptr %t57, i32 %t50)
  store i32 %t59, ptr %l27
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t60 = load ptr, ptr %l22, !tbaa !29
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = load i32, ptr %l27, !tbaa !23
  %t63 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %v1, ptr %t60, i32 %t61, i32 %t62)
  store i1 %t63, ptr %l28
  br label %bb10
bb10:
  %t64 = load i1, ptr %l28, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t67 = load i1, ptr %l21, !tbaa !21
  br i1 %t67, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l30, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %v1, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l33
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %v1, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l36
  br label %bb15
bb15:
  %t79 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = add i64 %t80, %t83
  %t85 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t79, i64 %t80)
  %t93 = getelementptr i8, ptr %t92, i64 %t80
  call void @olang_textcopy(ptr %t93, ptr %t82, i64 %t83)
  %t94 = getelementptr i8, ptr %t93, i64 %t83
  call void @olang_textcopy(ptr %t94, ptr %t85, i64 %t86)
  %t95 = getelementptr i8, ptr %t94, i64 %t86
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t92, 1
  %t99 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t99, { i64, ptr } %t97)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t101 = load i32, ptr %l2, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:verifier", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/mir:verifier", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l9, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v1, ptr %t16)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t21, ptr %t22, i32 %t15)
  store i32 %t24, ptr %l12
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i32, ptr %l12, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t30, ptr %t31, i32 %t32)
  store i1 %t33, ptr %l14
  br label %bb4
bb4:
  %t34 = load i1, ptr %l14, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l5, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l16, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v1, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t46 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t44, i64 %t45)
  %t51 = getelementptr i8, ptr %t50, i64 %t45
  call void @olang_textcopy(ptr %t51, ptr %t47, i64 %t48)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  %t55 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t55, { i64, ptr } %t53)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t57 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca { i64, [1 x i64] }
  %l112 = alloca i32
  %l115 = alloca i32
  %l133 = alloca ptr
  %l136 = alloca ptr
  %l143 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb7
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 11
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb7
bb4:
  %t19 = load { i64, [15 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [15 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 24
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [4 x i64] } }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [4 x i64] }, ptr %t25
  store { i64, [4 x i64] } %t26, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t28, { i64, [4 x i64] } %t29)
  br label %bb8
bb8:
  br label %bb121
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 1
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Lvalue", ptr %t38
  store %"compiler/mir:Lvalue" %t39, ptr %l3
  br label %bb18
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Lvalue", ptr %t47
  store %"compiler/mir:Lvalue" %t48, ptr %l3
  br label %bb18
bb13:
  %t50 = load { i64, [15 x i64] }, ptr %l1
  %t52 = extractvalue { i64, [15 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 5
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t56 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/mir:Lvalue", ptr %t56
  store %"compiler/mir:Lvalue" %t57, ptr %l3
  br label %bb18
bb15:
  %t59 = load { i64, [15 x i64] }, ptr %l1
  %t61 = extractvalue { i64, [15 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 23
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t65 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/mir:Lvalue", ptr %t65
  store %"compiler/mir:Lvalue" %t66, ptr %l3
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/mir:Lvalue", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %v1, ptr %t68, %"compiler/mir:Lvalue" %t69)
  br label %bb19
bb19:
  br label %bb121
bb20:
  %t72 = load { i64, [15 x i64] }, ptr %l1
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 3
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t78 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/mir:Range", ptr %t78
  store %"compiler/mir:Range" %t79, ptr %l4
  br label %bb27
bb22:
  %t81 = load { i64, [15 x i64] }, ptr %l1
  %t83 = extractvalue { i64, [15 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 4
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t87 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t86, i32 0, i32 2
  %t88 = load %"compiler/mir:Range", ptr %t87
  store %"compiler/mir:Range" %t88, ptr %l4
  br label %bb27
bb24:
  %t90 = load { i64, [15 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [15 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 6
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t95, i32 0, i32 2
  %t97 = load %"compiler/mir:Range", ptr %t96
  store %"compiler/mir:Range" %t97, ptr %l4
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %v1, ptr %t99, %"compiler/mir:Range" %t100)
  br label %bb28
bb28:
  br label %bb121
bb29:
  %t103 = load { i64, [15 x i64] }, ptr %l1
  %t105 = extractvalue { i64, [15 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 7
  br i1 %t106, label %bb30, label %bb31
bb30:
  %t108 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t109 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t108, i32 0, i32 0
  %t110 = load { i64, [1 x i64] }, ptr %t109
  store { i64, [1 x i64] } %t110, ptr %l5
  %t112 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t113 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t112, i32 0, i32 1
  %t114 = load { i64, [4 x i64] }, ptr %t113
  store { i64, [4 x i64] } %t114, ptr %l6
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t116, { i64, [4 x i64] } %t117)
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %t120, { i64, [1 x i64] } %t121)
  br label %bb34
bb34:
  br label %bb121
bb35:
  %t124 = load { i64, [15 x i64] }, ptr %l1
  %t126 = extractvalue { i64, [15 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 8
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t129 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t130 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t129, i32 0, i32 0
  %t131 = load { i64, [1 x i64] }, ptr %t130
  store { i64, [1 x i64] } %t131, ptr %l7
  %t133 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t134 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t133, i32 0, i32 2
  %t135 = load { i64, [4 x i64] }, ptr %t134
  store { i64, [4 x i64] } %t135, ptr %l8
  %t137 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t137, i32 0, i32 3
  %t139 = load { i64, [4 x i64] }, ptr %t138
  store { i64, [4 x i64] } %t139, ptr %l9
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t141, { i64, [4 x i64] } %t142)
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t145, { i64, [4 x i64] } %t146)
  br label %bb40
bb40:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %t149, { i64, [1 x i64] } %t150)
  br label %bb41
bb41:
  br label %bb121
bb42:
  %t153 = load { i64, [15 x i64] }, ptr %l1
  %t155 = extractvalue { i64, [15 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 9
  br i1 %t156, label %bb43, label %bb44
bb43:
  %t158 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t159 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t158, i32 0, i32 0
  %t160 = load %"compiler/mir:Lvalue", ptr %t159
  store %"compiler/mir:Lvalue" %t160, ptr %l10
  %t162 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t163 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t162, i32 0, i32 1
  %t164 = load { i64, [4 x i64] }, ptr %t163
  store { i64, [4 x i64] } %t164, ptr %l11
  %t166 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t167 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t166, i32 0, i32 2
  %t168 = load { i64, [4 x i64] }, ptr %t167
  store { i64, [4 x i64] } %t168, ptr %l12
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %v1, ptr %t170, %"compiler/mir:Lvalue" %t171)
  br label %bb46
bb46:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t174, { i64, [4 x i64] } %t175)
  br label %bb47
bb47:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t178, { i64, [4 x i64] } %t179)
  br label %bb48
bb48:
  br label %bb121
bb49:
  %t182 = load { i64, [15 x i64] }, ptr %l1
  %t184 = extractvalue { i64, [15 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 10
  br i1 %t185, label %bb50, label %bb51
bb50:
  %t187 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t188 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t187, i32 0, i32 2
  %t189 = load { i64, [1 x i64] }, ptr %t188
  store { i64, [1 x i64] } %t189, ptr %l13
  %t191 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t192 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t191, i32 0, i32 3
  %t193 = load %"compiler/mir:Range", ptr %t192
  store %"compiler/mir:Range" %t193, ptr %l14
  %t195 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t196 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t195, i32 0, i32 4
  %t197 = load %"compiler/mir:Range", ptr %t196
  store %"compiler/mir:Range" %t197, ptr %l15
  br label %bb52
bb51:
  br label %bb72
bb52:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %v1, ptr %t199, %"compiler/mir:Range" %t200)
  br label %bb53
bb53:
  %t203 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t204 = load i32, ptr %t203, !tbaa !23
  %t206 = icmp sgt i32 %t204, 0
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %t208, { i64, [1 x i64] } %t209)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  store i32 0, ptr %l16, !tbaa !23
  %t212 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 1
  %t213 = load i32, ptr %t212, !tbaa !23
  store i32 %t213, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t215 = load i32, ptr %l17, !tbaa !23
  %t216 = load i32, ptr %l16, !tbaa !23
  %t219 = icmp sgt i32 %t215, %t216
  br i1 %t219, label %bb58, label %bb59
bb58:
  %t221 = load i32, ptr %l18, !tbaa !23
  %t223 = icmp sgt i32 %t221, 0
  br i1 %t223, label %bb60, label %bb61
bb59:
  store i32 0, ptr %l112, !tbaa !23
  br label %bb63
bb60:
  %t225 = load i32, ptr %l17, !tbaa !23
  %t226 = load i32, ptr %l16, !tbaa !23
  %t229 = sub i32 %t225, %t226
  %t230 = load i32, ptr %l18, !tbaa !23
  %t233 = add i32 %t229, %t230
  %t235 = sub i32 %t233, 1
  %t236 = load i32, ptr %l18, !tbaa !23
  %t239 = sdiv i32 %t235, %t236
  store i32 %t239, ptr %l115, !tbaa !23
  br label %bb62
bb61:
  store i32 0, ptr %l115, !tbaa !23
  br label %bb62
bb62:
  %t241 = load i32, ptr %l115, !tbaa !23
  store i32 %t241, ptr %l112, !tbaa !23
  br label %bb63
bb63:
  %t242 = load i32, ptr %l112, !tbaa !23
  store i32 %t242, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb64
bb64:
  %t243 = load i32, ptr %l20, !tbaa !23
  %t244 = load i32, ptr %l19, !tbaa !23
  %t247 = icmp slt i32 %t243, %t244
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t251 = load i32, ptr %l16, !tbaa !23
  %t252 = load i32, ptr %l20, !tbaa !23
  %t253 = load i32, ptr %l18, !tbaa !23
  %t256 = mul i32 %t252, %t253
  %t259 = add i32 %t251, %t256
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l133, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/mir:verifier", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/mir:Fn", ptr %t265, i32 0, i32 12
  store ptr %t267, ptr %l136, !tbaa !29
  %t268 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 0
  %t269 = load i32, ptr %t268, !tbaa !23
  %t271 = sext i32 %t269 to i64
  %t274 = sext i32 %t259 to i64
  %t277 = add i64 %t271, %t274
  %t278 = load ptr, ptr %l136, !tbaa !29
  %t279 = call ptr @__olang_scope_or(ptr %v1, ptr %t278)
  %t280 = call ptr @__olang_scope_hold(ptr %t279)
  %t281 = ptrtoint ptr %t280 to i64
  %t283 = inttoptr i64 %t281 to ptr
  %t284 = load ptr, ptr %l136, !tbaa !29
  %t286 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t283, ptr %t284, i64 %t277)
  store { i64, [1 x i64] } %t286, ptr %l143
  br label %bb68
bb68:
  %t287 = load ptr, ptr %l133, !tbaa !29
  %t288 = load { i64, [1 x i64] }, ptr %l143
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t287, { i64, [1 x i64] } %t288)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t289 = load i32, ptr %l20, !tbaa !23
  %t292 = add i32 %t289, 1
  store i32 %t292, ptr %l20, !tbaa !23
  br label %bb64
bb71:
  br label %bb121
bb72:
  %t294 = load { i64, [15 x i64] }, ptr %l1
  %t296 = extractvalue { i64, [15 x i64] } %t294, 0
  %t297 = icmp eq i64 %t296, 12
  br i1 %t297, label %bb73, label %bb74
bb73:
  %t299 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t300 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t299, i32 0, i32 0
  %t301 = load { i64, [1 x i64] }, ptr %t300
  store { i64, [1 x i64] } %t301, ptr %l22
  %t303 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t304 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t303, i32 0, i32 1
  %t305 = load { i64, [1 x i64] }, ptr %t304
  store { i64, [1 x i64] } %t305, ptr %l23
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load { i64, [1 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t307, { i64, [1 x i64] } %t308)
  br label %bb76
bb76:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load { i64, [1 x i64] }, ptr %l23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %t311, { i64, [1 x i64] } %t312)
  br label %bb77
bb77:
  br label %bb121
bb78:
  %t315 = load { i64, [15 x i64] }, ptr %l1
  %t317 = extractvalue { i64, [15 x i64] } %t315, 0
  %t318 = icmp eq i64 %t317, 13
  br i1 %t318, label %bb79, label %bb80
bb79:
  %t320 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t321 = getelementptr { { i64, [1 x i64] } }, ptr %t320, i32 0, i32 0
  %t322 = load { i64, [1 x i64] }, ptr %t321
  store { i64, [1 x i64] } %t322, ptr %l24
  br label %bb85
bb80:
  %t324 = load { i64, [15 x i64] }, ptr %l1
  %t326 = extractvalue { i64, [15 x i64] } %t324, 0
  %t327 = icmp eq i64 %t326, 14
  br i1 %t327, label %bb81, label %bb82
bb81:
  %t329 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t330 = getelementptr { { i64, [1 x i64] } }, ptr %t329, i32 0, i32 0
  %t331 = load { i64, [1 x i64] }, ptr %t330
  store { i64, [1 x i64] } %t331, ptr %l24
  br label %bb85
bb82:
  %t333 = load { i64, [15 x i64] }, ptr %l1
  %t335 = extractvalue { i64, [15 x i64] } %t333, 0
  %t336 = icmp eq i64 %t335, 15
  br i1 %t336, label %bb83, label %bb84
bb83:
  %t338 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t339 = getelementptr { { i64, [1 x i64] } }, ptr %t338, i32 0, i32 0
  %t340 = load { i64, [1 x i64] }, ptr %t339
  store { i64, [1 x i64] } %t340, ptr %l24
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load { i64, [1 x i64] }, ptr %l24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %t342, { i64, [1 x i64] } %t343)
  br label %bb86
bb86:
  br label %bb121
bb87:
  %t346 = load { i64, [15 x i64] }, ptr %l1
  %t348 = extractvalue { i64, [15 x i64] } %t346, 0
  %t349 = icmp eq i64 %t348, 16
  br i1 %t349, label %bb88, label %bb89
bb88:
  %t351 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t352 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t351, i32 0, i32 0
  %t353 = load { i64, [4 x i64] }, ptr %t352
  store { i64, [4 x i64] } %t353, ptr %l25
  %t355 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t356 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t355, i32 0, i32 1
  %t357 = load { i64, [1 x i64] }, ptr %t356
  store { i64, [1 x i64] } %t357, ptr %l26
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load { i64, [4 x i64] }, ptr %l25
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t359, { i64, [4 x i64] } %t360)
  br label %bb91
bb91:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load { i64, [1 x i64] }, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t363, { i64, [1 x i64] } %t364)
  br label %bb92
bb92:
  br label %bb121
bb93:
  %t367 = load { i64, [15 x i64] }, ptr %l1
  %t369 = extractvalue { i64, [15 x i64] } %t367, 0
  %t370 = icmp eq i64 %t369, 17
  br i1 %t370, label %bb94, label %bb95
bb94:
  %t372 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t373 = getelementptr { { i64, [4 x i64] } }, ptr %t372, i32 0, i32 0
  %t374 = load { i64, [4 x i64] }, ptr %t373
  store { i64, [4 x i64] } %t374, ptr %l27
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load { i64, [4 x i64] }, ptr %l27
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t376, { i64, [4 x i64] } %t377)
  br label %bb97
bb97:
  br label %bb121
bb98:
  %t380 = load { i64, [15 x i64] }, ptr %l1
  %t382 = extractvalue { i64, [15 x i64] } %t380, 0
  %t383 = icmp eq i64 %t382, 18
  br i1 %t383, label %bb99, label %bb100
bb99:
  %t385 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t386 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] } }, ptr %t385, i32 0, i32 0
  %t387 = load { i64, [1 x i64] }, ptr %t386
  store { i64, [1 x i64] } %t387, ptr %l28
  %t389 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t390 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] } }, ptr %t389, i32 0, i32 1
  %t391 = load { i64, [4 x i64] }, ptr %t390
  store { i64, [4 x i64] } %t391, ptr %l29
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load { i64, [1 x i64] }, ptr %l28
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t393, { i64, [1 x i64] } %t394)
  br label %bb102
bb102:
  %t397 = load { i64, [4 x i64] }, ptr %l29
  %t399 = extractvalue { i64, [4 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 0
  %t402 = xor i1 %t400, true
  br i1 %t402, label %bb103, label %bb104
bb103:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, [4 x i64] }, ptr %l29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %t404, { i64, [4 x i64] } %t405)
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb106
bb106:
  br label %bb121
bb107:
  %t408 = load { i64, [15 x i64] }, ptr %l1
  %t410 = extractvalue { i64, [15 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 21
  br i1 %t411, label %bb108, label %bb109
bb108:
  br label %bb114
bb109:
  %t413 = load { i64, [15 x i64] }, ptr %l1
  %t415 = extractvalue { i64, [15 x i64] } %t413, 0
  %t416 = icmp eq i64 %t415, 22
  br i1 %t416, label %bb110, label %bb111
bb110:
  br label %bb114
bb111:
  %t418 = load { i64, [15 x i64] }, ptr %l1
  %t420 = extractvalue { i64, [15 x i64] } %t418, 0
  %t421 = icmp eq i64 %t420, 19
  br i1 %t421, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb121
bb115:
  %t423 = load { i64, [15 x i64] }, ptr %l1
  %t425 = extractvalue { i64, [15 x i64] } %t423, 0
  %t426 = icmp eq i64 %t425, 20
  br i1 %t426, label %bb116, label %bb117
bb116:
  %t428 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t429 = getelementptr { { i64, [1 x i64] } }, ptr %t428, i32 0, i32 0
  %t430 = load { i64, [1 x i64] }, ptr %t429
  store { i64, [1 x i64] } %t430, ptr %l30
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load { i64, [1 x i64] }, ptr %l30
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t432, { i64, [1 x i64] } %t433)
  br label %bb119
bb119:
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f)
  unreachable
bb121:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Range"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca i32
  %l33 = alloca i32
  %l42 = alloca i32
  %l47 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca i32
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l70 = alloca i32
  %l80 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i32
  %l98 = alloca i32
  %l103 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca i32
  %l118 = alloca i32
  %l125 = alloca ptr
  %l128 = alloca i32
  %l132 = alloca i32
  %l138 = alloca i32
  %l142 = alloca ptr
  %l145 = alloca i32
  %l147 = alloca i32
  %l155 = alloca i32
  %l166 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca i32
  %l174 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca i32
  %l184 = alloca i32
  %l186 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca i32
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb5
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 24
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] } }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l2
  %t23 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t19, { i64, [4 x i64] } %t20)
  store i32 %t23, ptr %l42
  br label %bb6
bb6:
  %t24 = load i32, ptr %l42, !tbaa !23
  store i32 %t24, ptr %l33, !tbaa !23
  br label %bb121
bb7:
  %t25 = load { i64, [15 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [15 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 1
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t30, i32 0, i32 0
  %t32 = load %"compiler/mir:Lvalue", ptr %t31
  store %"compiler/mir:Lvalue" %t32, ptr %l3
  %t34 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l47, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/mir:Lvalue", ptr %l3
  %t43 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %t39, %"compiler/mir:Lvalue" %t40)
  store i32 %t43, ptr %l50
  br label %bb11
bb11:
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l47, !tbaa !29
  %t46 = load i32, ptr %l50, !tbaa !23
  %t48 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %v2, ptr %t45, i32 %t46, i32 %t44)
  store i32 %t48, ptr %l52
  br label %bb12
bb12:
  %t49 = load i32, ptr %l52, !tbaa !23
  store i32 %t49, ptr %l33, !tbaa !23
  br label %bb121
bb13:
  %t50 = load { i64, [15 x i64] }, ptr %l1
  %t52 = extractvalue { i64, [15 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 2
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t56 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/mir:Lvalue", ptr %t56
  store %"compiler/mir:Lvalue" %t57, ptr %l5
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l56, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/mir:Lvalue", ptr %l5
  %t64 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %t60, %"compiler/mir:Lvalue" %t61)
  store i32 %t64, ptr %l59
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l56, !tbaa !29
  %t66 = load i32, ptr %l59, !tbaa !23
  %t67 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l60
  br label %bb18
bb18:
  %t68 = load i32, ptr %l60, !tbaa !23
  store i32 %t68, ptr %l33, !tbaa !23
  br label %bb121
bb19:
  %t69 = load { i64, [15 x i64] }, ptr %l1
  %t71 = extractvalue { i64, [15 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 3
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 54}
  store i32 %t76, ptr %l6
  %t78 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t79 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t78, i32 0, i32 1
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l7, !tbaa !23
  %t82 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t82, i32 0, i32 2
  %t84 = load %"compiler/mir:Range", ptr %t83
  store %"compiler/mir:Range" %t84, ptr %l8
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l6, !range !{i32 0, i32 54}
  %t88 = load i32, ptr %l7, !tbaa !23
  %t89 = load %"compiler/mir:Range", ptr %l8
  %t94 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %v1, ptr %v2, ptr %t86, i32 %t87, i32 %t88, %"compiler/mir:Range" %t89)
  store i32 %t94, ptr %l70
  br label %bb23
bb23:
  %t95 = load i32, ptr %l70, !tbaa !23
  store i32 %t95, ptr %l33, !tbaa !23
  br label %bb121
bb24:
  %t96 = load { i64, [15 x i64] }, ptr %l1
  %t98 = extractvalue { i64, [15 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 4
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t101 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t101, i32 0, i32 0
  %t103 = load i32, ptr %t102, !range !{i32 0, i32 54}
  store i32 %t103, ptr %l9
  %t105 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t106 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106
  store i32 %t107, ptr %l10, !tbaa !23
  %t109 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t110 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t109, i32 0, i32 2
  %t111 = load %"compiler/mir:Range", ptr %t110
  store %"compiler/mir:Range" %t111, ptr %l11
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t115 = load i32, ptr %l10, !tbaa !23
  %t116 = load %"compiler/mir:Range", ptr %l11
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %v2, ptr %t113, i32 %t114, i32 %t115, %"compiler/mir:Range" %t116)
  store i32 %t121, ptr %l80
  br label %bb28
bb28:
  %t122 = load i32, ptr %l80, !tbaa !23
  store i32 %t122, ptr %l33, !tbaa !23
  br label %bb121
bb29:
  %t123 = load { i64, [15 x i64] }, ptr %l1
  %t125 = extractvalue { i64, [15 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 5
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t129 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/mir:Lvalue", ptr %t129
  store %"compiler/mir:Lvalue" %t130, ptr %l12
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l84, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/mir:Lvalue", ptr %l12
  %t137 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %t133, %"compiler/mir:Lvalue" %t134)
  store i32 %t137, ptr %l87
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l84, !tbaa !29
  %t139 = load i32, ptr %l87, !tbaa !23
  %t140 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %v2, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l88
  br label %bb34
bb34:
  %t141 = load i32, ptr %l88, !tbaa !23
  store i32 %t141, ptr %l33, !tbaa !23
  br label %bb121
bb35:
  %t142 = load { i64, [15 x i64] }, ptr %l1
  %t144 = extractvalue { i64, [15 x i64] } %t142, 0
  %t145 = icmp eq i64 %t144, 6
  br i1 %t145, label %bb36, label %bb37
bb36:
  %t147 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t147, i32 0, i32 0
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l13, !tbaa !23
  %t151 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t152 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t151, i32 0, i32 1
  %t153 = load i64, ptr %t152
  store i64 %t153, ptr %l14, !tbaa !24
  %t155 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t156 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t155, i32 0, i32 2
  %t157 = load %"compiler/mir:Range", ptr %t156
  store %"compiler/mir:Range" %t157, ptr %l15
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l13, !tbaa !23
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load %"compiler/mir:Range", ptr %l15
  %t167 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %v2, ptr %v1, ptr %t159, i32 %t160, i64 %t161, %"compiler/mir:Range" %t162)
  store i32 %t167, ptr %l98
  br label %bb39
bb39:
  %t168 = load i32, ptr %l98, !tbaa !23
  store i32 %t168, ptr %l33, !tbaa !23
  br label %bb121
bb40:
  %t169 = load { i64, [15 x i64] }, ptr %l1
  %t171 = extractvalue { i64, [15 x i64] } %t169, 0
  %t172 = icmp eq i64 %t171, 7
  br i1 %t172, label %bb41, label %bb42
bb41:
  %t174 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t175 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t174, i32 0, i32 1
  %t176 = load { i64, [4 x i64] }, ptr %t175
  store { i64, [4 x i64] } %t176, ptr %l16
  %t178 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t179 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t178, i32 0, i32 2
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l17, !tbaa !23
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l103, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load { i64, [4 x i64] }, ptr %l16
  %t187 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t183, { i64, [4 x i64] } %t184)
  store i32 %t187, ptr %l106
  br label %bb44
bb44:
  %t188 = load i32, ptr %l17, !tbaa !23
  %t189 = load ptr, ptr %l103, !tbaa !29
  %t190 = load i32, ptr %l106, !tbaa !23
  %t192 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %v2, ptr %t189, i32 %t190, i32 %t188)
  store i32 %t192, ptr %l108
  br label %bb45
bb45:
  %t193 = load i32, ptr %l108, !tbaa !23
  store i32 %t193, ptr %l33, !tbaa !23
  br label %bb121
bb46:
  %t194 = load { i64, [15 x i64] }, ptr %l1
  %t196 = extractvalue { i64, [15 x i64] } %t194, 0
  %t197 = icmp eq i64 %t196, 8
  br i1 %t197, label %bb47, label %bb48
bb47:
  %t199 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t200 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t199, i32 0, i32 1
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l18, !tbaa !23
  %t203 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t204 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t203, i32 0, i32 2
  %t205 = load { i64, [4 x i64] }, ptr %t204
  store { i64, [4 x i64] } %t205, ptr %l19
  %t207 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t208 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t207, i32 0, i32 3
  %t209 = load { i64, [4 x i64] }, ptr %t208
  store { i64, [4 x i64] } %t209, ptr %l20
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i32, ptr %l18, !tbaa !23
  %t213 = load { i64, [4 x i64] }, ptr %l19
  %t214 = load { i64, [4 x i64] }, ptr %l20
  %t219 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %v2, ptr %v1, ptr %t211, i32 %t212, { i64, [4 x i64] } %t213, { i64, [4 x i64] } %t214)
  store i32 %t219, ptr %l118
  br label %bb50
bb50:
  %t220 = load i32, ptr %l118, !tbaa !23
  store i32 %t220, ptr %l33, !tbaa !23
  br label %bb121
bb51:
  %t221 = load { i64, [15 x i64] }, ptr %l1
  %t223 = extractvalue { i64, [15 x i64] } %t221, 0
  %t224 = icmp eq i64 %t223, 9
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t226 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t227 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t226, i32 0, i32 0
  %t228 = load %"compiler/mir:Lvalue", ptr %t227
  store %"compiler/mir:Lvalue" %t228, ptr %l21
  %t230 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t231 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t230, i32 0, i32 1
  %t232 = load { i64, [4 x i64] }, ptr %t231
  store { i64, [4 x i64] } %t232, ptr %l22
  %t234 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t235 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t234, i32 0, i32 2
  %t236 = load { i64, [4 x i64] }, ptr %t235
  store { i64, [4 x i64] } %t236, ptr %l23
  %t238 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t239 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t238, i32 0, i32 3
  %t240 = load i32, ptr %t239
  store i32 %t240, ptr %l24, !tbaa !23
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l125, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/mir:Lvalue", ptr %l21
  %t247 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %t243, %"compiler/mir:Lvalue" %t244)
  store i32 %t247, ptr %l128
  br label %bb55
bb55:
  %t248 = load { i64, [4 x i64] }, ptr %l22
  %t249 = load { i64, [4 x i64] }, ptr %l23
  %t250 = load i32, ptr %l24, !tbaa !23
  %t251 = load ptr, ptr %l125, !tbaa !29
  %t252 = load i32, ptr %l128, !tbaa !23
  %t256 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %v2, ptr %v1, ptr %t251, i32 %t252, { i64, [4 x i64] } %t248, { i64, [4 x i64] } %t249, i32 %t250)
  store i32 %t256, ptr %l132
  br label %bb56
bb56:
  %t257 = load i32, ptr %l132, !tbaa !23
  store i32 %t257, ptr %l33, !tbaa !23
  br label %bb121
bb57:
  %t258 = load { i64, [15 x i64] }, ptr %l1
  %t260 = extractvalue { i64, [15 x i64] } %t258, 0
  %t261 = icmp eq i64 %t260, 10
  br i1 %t261, label %bb58, label %bb59
bb58:
  %t263 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t264 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t263, i32 0, i32 1
  %t265 = load i32, ptr %t264
  store i32 %t265, ptr %l25, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l25, !tbaa !23
  %t271 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %v2, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l138
  br label %bb61
bb61:
  %t272 = load i32, ptr %l138, !tbaa !23
  store i32 %t272, ptr %l33, !tbaa !23
  br label %bb121
bb62:
  %t273 = load { i64, [15 x i64] }, ptr %l1
  %t275 = extractvalue { i64, [15 x i64] } %t273, 0
  %t276 = icmp eq i64 %t275, 11
  br i1 %t276, label %bb63, label %bb64
bb63:
  %t278 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t279 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t278, i32 0, i32 0
  %t280 = load { i64, [4 x i64] }, ptr %t279
  store { i64, [4 x i64] } %t280, ptr %l26
  br label %bb65
bb64:
  br label %bb68
bb65:
  store %olang.scope zeroinitializer, ptr %s12
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l142, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load { i64, [4 x i64] }, ptr %l26
  %t287 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t283, { i64, [4 x i64] } %t284)
  store i32 %t287, ptr %l145
  br label %bb66
bb66:
  %t288 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t289 = load ptr, ptr %l142, !tbaa !29
  %t290 = load i32, ptr %l145, !tbaa !23
  %t292 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s12, ptr %v2, ptr %t289, i32 %t290, i32 %t288, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i32 %t292, ptr %l147
  br label %bb67
bb67:
  %t293 = load i32, ptr %l147, !tbaa !23
  store i32 %t293, ptr %l33, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb68:
  %t294 = load { i64, [15 x i64] }, ptr %l1
  %t296 = extractvalue { i64, [15 x i64] } %t294, 0
  %t297 = icmp eq i64 %t296, 12
  br i1 %t297, label %bb69, label %bb70
bb69:
  %t299 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t300 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t299, i32 0, i32 0
  %t301 = load { i64, [1 x i64] }, ptr %t300
  store { i64, [1 x i64] } %t301, ptr %l27
  %t303 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t304 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t303, i32 0, i32 2
  %t305 = load i32, ptr %t304
  store i32 %t305, ptr %l28, !tbaa !23
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load { i64, [1 x i64] }, ptr %l27
  %t309 = load i32, ptr %l28, !tbaa !23
  %t313 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %v1, ptr %v2, ptr %t307, { i64, [1 x i64] } %t308, i32 %t309)
  store i32 %t313, ptr %l155
  br label %bb72
bb72:
  %t314 = load i32, ptr %l155, !tbaa !23
  store i32 %t314, ptr %l33, !tbaa !23
  br label %bb121
bb73:
  %t315 = load { i64, [15 x i64] }, ptr %l1
  %t317 = extractvalue { i64, [15 x i64] } %t315, 0
  %t318 = icmp eq i64 %t317, 13
  br i1 %t318, label %bb74, label %bb75
bb74:
  br label %bb80
bb75:
  %t320 = load { i64, [15 x i64] }, ptr %l1
  %t322 = extractvalue { i64, [15 x i64] } %t320, 0
  %t323 = icmp eq i64 %t322, 14
  br i1 %t323, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  %t325 = load { i64, [15 x i64] }, ptr %l1
  %t327 = extractvalue { i64, [15 x i64] } %t325, 0
  %t328 = icmp eq i64 %t327, 15
  br i1 %t328, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t330 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t330, ptr %l33, !tbaa !23
  br label %bb121
bb81:
  %t332 = load { i64, [15 x i64] }, ptr %l1
  %t334 = extractvalue { i64, [15 x i64] } %t332, 0
  %t335 = icmp eq i64 %t334, 16
  br i1 %t335, label %bb82, label %bb83
bb82:
  %t337 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t338 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t337, i32 0, i32 0
  %t339 = load { i64, [4 x i64] }, ptr %t338
  store { i64, [4 x i64] } %t339, ptr %l29
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l166, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load { i64, [4 x i64] }, ptr %l29
  %t346 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t342, { i64, [4 x i64] } %t343)
  store i32 %t346, ptr %l169
  br label %bb85
bb85:
  %t347 = load ptr, ptr %l166, !tbaa !29
  %t348 = load i32, ptr %l169, !tbaa !23
  %t349 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %v2, ptr %t347, i32 %t348)
  store i32 %t349, ptr %l170
  br label %bb86
bb86:
  %t350 = load i32, ptr %l170, !tbaa !23
  store i32 %t350, ptr %l33, !tbaa !23
  br label %bb121
bb87:
  %t351 = load { i64, [15 x i64] }, ptr %l1
  %t353 = extractvalue { i64, [15 x i64] } %t351, 0
  %t354 = icmp eq i64 %t353, 17
  br i1 %t354, label %bb88, label %bb89
bb88:
  %t356 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t357 = getelementptr { { i64, [4 x i64] } }, ptr %t356, i32 0, i32 0
  %t358 = load { i64, [4 x i64] }, ptr %t357
  store { i64, [4 x i64] } %t358, ptr %l30
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l174, !tbaa !29
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, [4 x i64] }, ptr %l30
  %t365 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t361, { i64, [4 x i64] } %t362)
  store i32 %t365, ptr %l177
  br label %bb91
bb91:
  %t366 = load ptr, ptr %l174, !tbaa !29
  %t367 = load i32, ptr %l177, !tbaa !23
  %t368 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %v2, ptr %t366, i32 %t367)
  store i32 %t368, ptr %l178
  br label %bb92
bb92:
  %t369 = load i32, ptr %l178, !tbaa !23
  store i32 %t369, ptr %l33, !tbaa !23
  br label %bb121
bb93:
  %t370 = load { i64, [15 x i64] }, ptr %l1
  %t372 = extractvalue { i64, [15 x i64] } %t370, 0
  %t373 = icmp eq i64 %t372, 18
  br i1 %t373, label %bb94, label %bb95
bb94:
  %t375 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t376 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] } }, ptr %t375, i32 0, i32 1
  %t377 = load { i64, [4 x i64] }, ptr %t376
  store { i64, [4 x i64] } %t377, ptr %l31
  br label %bb96
bb95:
  br label %bb102
bb96:
  %t379 = load { i64, [4 x i64] }, ptr %l31
  %t381 = extractvalue { i64, [4 x i64] } %t379, 0
  %t382 = icmp eq i64 %t381, 0
  br i1 %t382, label %bb97, label %bb98
bb97:
  %t384 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t384, ptr %l184, !tbaa !23
  br label %bb101
bb98:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l186, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load { i64, [4 x i64] }, ptr %l31
  %t391 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t387, { i64, [4 x i64] } %t388)
  store i32 %t391, ptr %l189
  br label %bb99
bb99:
  %t392 = load ptr, ptr %l186, !tbaa !29
  %t393 = load i32, ptr %l189, !tbaa !23
  %t394 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %v2, ptr %t392, i32 %t393)
  store i32 %t394, ptr %l190
  br label %bb100
bb100:
  %t395 = load i32, ptr %l190, !tbaa !23
  store i32 %t395, ptr %l184, !tbaa !23
  br label %bb101
bb101:
  %t396 = load i32, ptr %l184, !tbaa !23
  store i32 %t396, ptr %l33, !tbaa !23
  br label %bb121
bb102:
  %t397 = load { i64, [15 x i64] }, ptr %l1
  %t399 = extractvalue { i64, [15 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 21
  br i1 %t400, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t402 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t402, ptr %l33, !tbaa !23
  br label %bb121
bb106:
  %t404 = load { i64, [15 x i64] }, ptr %l1
  %t406 = extractvalue { i64, [15 x i64] } %t404, 0
  %t407 = icmp eq i64 %t406, 22
  br i1 %t407, label %bb107, label %bb108
bb107:
  %t409 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t410 = getelementptr { i32 }, ptr %t409, i32 0, i32 0
  %t411 = load i32, ptr %t410
  store i32 %t411, ptr %l32, !tbaa !23
  br label %bb111
bb108:
  %t413 = load { i64, [15 x i64] }, ptr %l1
  %t415 = extractvalue { i64, [15 x i64] } %t413, 0
  %t416 = icmp eq i64 %t415, 23
  br i1 %t416, label %bb109, label %bb110
bb109:
  %t418 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t419 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t418, i32 0, i32 1
  %t420 = load i32, ptr %t419
  store i32 %t420, ptr %l32, !tbaa !23
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t422 = load i32, ptr %l32, !tbaa !23
  store i32 %t422, ptr %l33, !tbaa !23
  br label %bb121
bb112:
  %t424 = load { i64, [15 x i64] }, ptr %l1
  %t426 = extractvalue { i64, [15 x i64] } %t424, 0
  %t427 = icmp eq i64 %t426, 19
  br i1 %t427, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t429 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t429, ptr %l33, !tbaa !23
  br label %bb121
bb116:
  %t431 = load { i64, [15 x i64] }, ptr %l1
  %t433 = extractvalue { i64, [15 x i64] } %t431, 0
  %t434 = icmp eq i64 %t433, 20
  br i1 %t434, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t436 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t436, ptr %l33, !tbaa !23
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_3d9554dfcf1aeb63_1386be72809b2127)
  unreachable
bb121:
  %t438 = load i32, ptr %l33, !tbaa !23
  store i32 %t438, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l2
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %v1, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l41
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l41
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t60, { i64, [4 x i64] } %t61)
  store i32 %t62, ptr %l42
  br label %bb12
bb12:
  %t63 = load i32, ptr %l42, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:verifier", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l46, !tbaa !29
  %t72 = load i32, ptr %l10, !tbaa !23
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = call ptr @__olang_scope_or(ptr %v2, ptr %t73)
  %t75 = call ptr @__olang_scope_hold(ptr %t74)
  %t76 = ptrtoint ptr %t75 to i64
  %t78 = inttoptr i64 %t76 to ptr
  %t79 = load ptr, ptr %l46, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t78, ptr %t79, i32 %t72)
  store i32 %t81, ptr %l49
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/mir:verifier", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l51, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = load ptr, ptr %l51, !tbaa !29
  %t88 = call ptr @__olang_scope_or(ptr %v2, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t92, ptr %t93, i32 %t86)
  store i32 %t95, ptr %l54
  br label %bb14
bb14:
  %t96 = load ptr, ptr %l44, !tbaa !29
  %t97 = call ptr @__olang_scope_or(ptr %v2, ptr %t96)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t102 = load ptr, ptr %l44, !tbaa !29
  %t103 = load i32, ptr %l49, !tbaa !23
  %t104 = load i32, ptr %l54, !tbaa !23
  %t105 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t101, ptr %t102, i32 %t103, i32 %t104)
  store i1 %t105, ptr %l56
  br label %bb15
bb15:
  %t106 = load i1, ptr %l56, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l58, !tbaa !29
  store i32 %a1, ptr %l59
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s4, ptr %l59, i64 0)
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t112 = load ptr, ptr %s4
  %t113 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t114 = load i64, ptr %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t112, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l61, !tbaa !27
  %t118 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t119 = load ptr, ptr %t118
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %sbgrew.121, label %sbdone.122
sbgrew.121:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.122
sbdone.122:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t125 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s3, ptr %s3, { i64, ptr } %t123)
  store { i64, ptr } %t125, ptr %l63
  br label %bb19
bb19:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l3, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %v2, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l66
  br label %bb20
bb20:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %v2, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l69
  br label %bb21
bb21:
  %t136 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t137, i64 %t138)
  %t154 = getelementptr i8, ptr %t153, i64 %t138
  call void @olang_textcopy(ptr %t154, ptr %t139, i64 %t140)
  %t155 = getelementptr i8, ptr %t154, i64 %t140
  call void @olang_textcopy(ptr %t155, ptr %t143, i64 %t144)
  %t156 = getelementptr i8, ptr %t155, i64 %t144
  call void @olang_textcopy(ptr %t156, ptr %t146, i64 %t147)
  %t157 = getelementptr i8, ptr %t156, i64 %t147
  call void @olang_textcopy(ptr %t157, ptr %t150, i64 %t151)
  %t158 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t153, 1
  %t161 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t161, { i64, ptr } %t159)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = add i32 %t163, 1
  store i32 %t166, ptr %l8, !tbaa !23
  br label %bb7
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l11
  br label %bb1
bb1:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = call ptr @__olang_scope_or(ptr %v1, ptr %t20)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t25, ptr %t26, i32 %a2)
  store i32 %t28, ptr %l15
  br label %bb2
bb2:
  %t29 = load i32, ptr %l15, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l16, !tbaa !29
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t38, ptr %t39, i32 %t31, i32 %t32)
  store i1 %t42, ptr %l20
  br label %bb3
bb3:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l3, !tbaa !29
  store ptr %t45, ptr %l22, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v1, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l22, !tbaa !29
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t52, ptr %t53, i32 %t46)
  store i32 %t55, ptr %l25
  br label %bb7
bb7:
  %t56 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb8, label %bb9
bb8:
  %t61 = load ptr, ptr %l3, !tbaa !29
  store ptr %t61, ptr %l29, !tbaa !29
  %t62 = load i32, ptr %l5, !tbaa !23
  %t63 = load ptr, ptr %l29, !tbaa !29
  %t64 = call ptr @__olang_scope_or(ptr %v1, ptr %t63)
  %t65 = call ptr @__olang_scope_hold(ptr %t64)
  %t66 = ptrtoint ptr %t65 to i64
  %t68 = inttoptr i64 %t66 to ptr
  %t69 = load ptr, ptr %l29, !tbaa !29
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t68, ptr %t69, i32 %t62)
  store i32 %t71, ptr %l32
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t72 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t74 = trunc i64 19 to i32
  %t75 = icmp eq i32 %t72, %t74
  store i1 %t75, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t77 = load i1, ptr %l28, !tbaa !21
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  %t79 = load i32, ptr %l4, !tbaa !23
  %t80 = load ptr, ptr %l35, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l35, !tbaa !29
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t85, ptr %t86, i32 %t79)
  store i32 %t88, ptr %l38
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t89 = load ptr, ptr %l3, !tbaa !29
  store ptr %t89, ptr %l39, !tbaa !29
  %t90 = load i32, ptr %l5, !tbaa !23
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = call ptr @__olang_scope_or(ptr %v1, ptr %t91)
  %t93 = call ptr @__olang_scope_hold(ptr %t92)
  %t94 = ptrtoint ptr %t93 to i64
  %t96 = inttoptr i64 %t94 to ptr
  %t97 = load ptr, ptr %l39, !tbaa !29
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t96, ptr %t97, i32 %t90)
  store i32 %t99, ptr %l42
  br label %bb15
bb15:
  %t100 = load i32, ptr %l38, !tbaa !23
  %t101 = load i32, ptr %l42, !tbaa !23
  %t102 = icmp eq i32 %t100, %t101
  br i1 %t102, label %bb16, label %bb17
bb16:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l45, !tbaa !29
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l46, !tbaa !29
  %t106 = load i32, ptr %l4, !tbaa !23
  %t107 = load ptr, ptr %l46, !tbaa !29
  %t108 = call ptr @__olang_scope_or(ptr %v1, ptr %t107)
  %t109 = call ptr @__olang_scope_hold(ptr %t108)
  %t110 = ptrtoint ptr %t109 to i64
  %t112 = inttoptr i64 %t110 to ptr
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t112, ptr %t113, i32 %t106)
  store i32 %t115, ptr %l49
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb21
bb18:
  %t116 = load ptr, ptr %l3, !tbaa !29
  store ptr %t116, ptr %l50, !tbaa !29
  %t117 = load i32, ptr %l5, !tbaa !23
  %t118 = load ptr, ptr %l50, !tbaa !29
  %t119 = call ptr @__olang_scope_or(ptr %v1, ptr %t118)
  %t120 = call ptr @__olang_scope_hold(ptr %t119)
  %t121 = ptrtoint ptr %t120 to i64
  %t123 = inttoptr i64 %t121 to ptr
  %t124 = load ptr, ptr %l50, !tbaa !29
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t123, ptr %t124, i32 %t117)
  store i32 %t126, ptr %l53
  br label %bb19
bb19:
  %t127 = load ptr, ptr %l45, !tbaa !29
  %t128 = load i32, ptr %l49, !tbaa !23
  %t129 = load i32, ptr %l53, !tbaa !23
  %t130 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %v1, ptr %t127, i32 %t128, i32 %t129)
  store i1 %t130, ptr %l54
  br label %bb20
bb20:
  %t131 = load i1, ptr %l54, !tbaa !21
  store i1 %t131, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t132 = load i1, ptr %l44, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/mir:Local"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/mir:Call"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:Case"
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/mir:Task"
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l52 = alloca %"compiler/mir:TaskClause"
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca { i64, [1 x i64] }
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, [1 x i64] }
  %l70 = alloca %"compiler/mir:Range"
  %l71 = alloca %"compiler/mir:Range"
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l91 = alloca i64
  %l97 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca i32
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i32
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l140 = alloca i64
  %l144 = alloca ptr
  %l146 = alloca i64
  %l150 = alloca i64
  %l153 = alloca i64
  %l171 = alloca ptr
  %l173 = alloca ptr
  %l176 = alloca i32
  %l177 = alloca i1
  %l179 = alloca ptr
  %l181 = alloca ptr
  %l184 = alloca i32
  %l187 = alloca %"compiler/mir:Local"
  %l191 = alloca ptr
  %l192 = alloca i64
  %l194 = alloca ptr
  %l197 = alloca i32
  %l204 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l211 = alloca i1
  %l212 = alloca i1
  %l214 = alloca ptr
  %l217 = alloca i1
  %l218 = alloca i1
  %l220 = alloca ptr
  %l222 = alloca ptr
  %l225 = alloca i32
  %l227 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l232 = alloca i32
  %l234 = alloca i1
  %l239 = alloca i1
  %l241 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l247 = alloca i1
  %l249 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i64
  %l255 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l261 = alloca ptr
  %l262 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l275 = alloca i64
  %l276 = alloca ptr
  %l278 = alloca i64
  %l281 = alloca ptr
  %l284 = alloca i32
  %l287 = alloca i1
  %l288 = alloca i1
  %l290 = alloca ptr
  %l294 = alloca %"compiler/mir:Local"
  %l306 = alloca ptr
  %l308 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i64
  %l334 = alloca ptr
  %l337 = alloca %"compiler/mir:Local"
  %l351 = alloca ptr
  %l353 = alloca i64
  %l357 = alloca i64
  %l360 = alloca i64
  %l379 = alloca ptr
  %l382 = alloca %"compiler/mir:ScopeInfo"
  %l389 = alloca i1
  %l403 = alloca i64
  %l404 = alloca ptr
  %l406 = alloca i64
  %l409 = alloca ptr
  %l412 = alloca %"compiler/mir:Call"
  %l427 = alloca i1
  %l433 = alloca i1
  %l436 = alloca i1
  %l442 = alloca i64
  %l443 = alloca ptr
  %l445 = alloca i64
  %l448 = alloca ptr
  %l451 = alloca %"compiler/mir:Case"
  %l454 = alloca i1
  %l460 = alloca i64
  %l461 = alloca ptr
  %l463 = alloca i64
  %l466 = alloca ptr
  %l469 = alloca %"compiler/mir:Task"
  %l482 = alloca i1
  %l492 = alloca ptr
  %l493 = alloca %"compiler/mir:Range"
  %l495 = alloca ptr
  %l497 = alloca i64
  %l498 = alloca i1
  %l503 = alloca i32
  %l506 = alloca i32
  %l524 = alloca ptr
  %l526 = alloca ptr
  %l533 = alloca %"compiler/mir:Lvalue"
  %l537 = alloca ptr
  %l538 = alloca %"compiler/mir:Range"
  %l540 = alloca ptr
  %l542 = alloca i64
  %l543 = alloca i1
  %l548 = alloca i32
  %l551 = alloca i32
  %l570 = alloca ptr
  %l577 = alloca %"compiler/mir:TaskClause"
  %l578 = alloca ptr
  %l579 = alloca %"compiler/mir:Range"
  %l581 = alloca ptr
  %l583 = alloca i64
  %l584 = alloca i1
  %l595 = alloca i64
  %l596 = alloca ptr
  %l598 = alloca i64
  %l601 = alloca ptr
  %l604 = alloca { i64, [4 x i64] }
  %l612 = alloca i64
  %l613 = alloca ptr
  %l615 = alloca i64
  %l618 = alloca ptr
  %l621 = alloca { i64, [1 x i64] }
  %l629 = alloca i64
  %l630 = alloca ptr
  %l632 = alloca i64
  %l635 = alloca ptr
  %l638 = alloca { i64, [1 x i64] }
  %l644 = alloca i1
  %l649 = alloca ptr
  %l651 = alloca i64
  %l655 = alloca i64
  %l658 = alloca i64
  %l677 = alloca ptr
  %l680 = alloca { i64, [1 x i64] }
  %l684 = alloca ptr
  %l685 = alloca %"compiler/mir:Range"
  %l687 = alloca ptr
  %l689 = alloca i64
  %l690 = alloca i1
  %l694 = alloca ptr
  %l695 = alloca %"compiler/mir:Range"
  %l697 = alloca ptr
  %l699 = alloca i64
  %l700 = alloca i1
  %l708 = alloca ptr
  %l710 = alloca i64
  %l714 = alloca i64
  %l717 = alloca i64
  %l738 = alloca ptr
  %l744 = alloca ptr
  %l746 = alloca ptr
  %l748 = alloca i64
  %l752 = alloca i64
  %l755 = alloca i64
  %l775 = alloca ptr
  %l777 = alloca ptr
  %l780 = alloca { i64, [21 x i64] }
  %l798 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %rv = alloca i1
  %t1012 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l91
  br label %bb1
bb1:
  %t11 = load i64, ptr %l91, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 3
  store i64 -1, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t17, i32 0, i32 4
  store i64 -1, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/mir:Fn", ptr %t22, i32 0, i32 9
  store ptr %t24, ptr %l97, !tbaa !29
  %t25 = load ptr, ptr %l97, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l97, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t30, ptr %t31)
  store i64 %t32, ptr %l99
  br label %bb2
bb2:
  %t33 = load i64, ptr %l99, !tbaa !24
  %t34 = icmp eq i64 %t33, 0
  br i1 %t34, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t36, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/mir:verifier", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l104, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/mir:Fn", ptr %t43, i32 0, i32 1
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = load ptr, ptr %l104, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v2, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l104, !tbaa !29
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t52, ptr %t53, i32 %t46)
  store i32 %t55, ptr %l108
  br label %bb7
bb7:
  %t56 = load i32, ptr %l108, !range !{i32 0, i32 33}
  %t58 = trunc i64 21 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t63, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/mir:verifier", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l115, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l117, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/mir:Fn", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l117, !tbaa !29
  %t79 = call ptr @__olang_scope_or(ptr %v2, ptr %t78)
  %t80 = call ptr @__olang_scope_hold(ptr %t79)
  %t81 = ptrtoint ptr %t80 to i64
  %t83 = inttoptr i64 %t81 to ptr
  %t84 = load ptr, ptr %l117, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t83, ptr %t84, i32 %t77)
  store i32 %t86, ptr %l121
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l115, !tbaa !29
  %t88 = call ptr @__olang_scope_or(ptr %v2, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/mir:verifier", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = call ptr @__olang_scope_or(ptr %v2, ptr %t94)
  %t97 = call ptr @__olang_scope_hold(ptr %t96)
  %t98 = ptrtoint ptr %t97 to i64
  %t100 = inttoptr i64 %t90 to ptr
  %t102 = inttoptr i64 %t98 to ptr
  %t103 = load ptr, ptr %l115, !tbaa !29
  %t104 = load i32, ptr %l121, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t100, ptr %t102, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l126
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t106, ptr %l5, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l128, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/mir:Fn", ptr %t110, i32 0, i32 4
  store ptr %t112, ptr %l130, !tbaa !29
  %t113 = load ptr, ptr %l130, !tbaa !29
  %t114 = call ptr @__olang_scope_or(ptr %v1, ptr %t113)
  %t115 = call ptr @__olang_scope_hold(ptr %t114)
  %t116 = ptrtoint ptr %t115 to i64
  %t118 = inttoptr i64 %t116 to ptr
  %t119 = load ptr, ptr %l130, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t118, ptr %t119)
  store i64 %t120, ptr %l132
  br label %bb14
bb14:
  %t121 = load i64, ptr %l128, !tbaa !24
  %t122 = load i64, ptr %l132, !tbaa !24
  %t123 = icmp ne i64 %t121, %t122
  br i1 %t123, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l134, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l136, !tbaa !24
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/mir:Fn", ptr %t129, i32 0, i32 4
  store ptr %t131, ptr %l138, !tbaa !29
  %t132 = load ptr, ptr %l138, !tbaa !29
  %t133 = call ptr @__olang_scope_or(ptr %v1, ptr %t132)
  %t134 = call ptr @__olang_scope_hold(ptr %t133)
  %t135 = ptrtoint ptr %t134 to i64
  %t137 = inttoptr i64 %t135 to ptr
  %t138 = load ptr, ptr %l138, !tbaa !29
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t137, ptr %t138)
  store i64 %t139, ptr %l140
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t140 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t142 = load i64, ptr %l136, !tbaa !24
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t141, %t143
  %t145 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = load i64, ptr %l140, !tbaa !24
  %t149 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t140, i64 %t141)
  %t152 = getelementptr i8, ptr %t151, i64 %t141
  %t153 = call i64 @__olang_fmt_i64(ptr %t152, i64 %t142)
  %t154 = getelementptr i8, ptr %t152, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t145, i64 %t146)
  %t155 = getelementptr i8, ptr %t154, i64 %t146
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t148)
  %t157 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t151, 1
  %t160 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t160, { i64, ptr } %t158)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/mir:Fn", ptr %t162, i32 0, i32 4
  store ptr %t164, ptr %l144, !tbaa !29
  %t165 = load ptr, ptr %l144, !tbaa !29
  %t166 = call ptr @__olang_scope_or(ptr %v1, ptr %t165)
  %t167 = call ptr @__olang_scope_hold(ptr %t166)
  %t168 = ptrtoint ptr %t167 to i64
  %t170 = inttoptr i64 %t168 to ptr
  %t171 = load ptr, ptr %l144, !tbaa !29
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t170, ptr %t171)
  store i64 %t172, ptr %l146
  br label %bb20
bb20:
  %t173 = load i64, ptr %l146, !tbaa !24
  store i64 %t173, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t174 = load i64, ptr %l7, !tbaa !24
  %t175 = load i64, ptr %l6, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb21, label %bb22
bb21:
  %t180 = load i64, ptr %l8, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb26
bb23:
  %t184 = load i64, ptr %l7, !tbaa !24
  %t185 = load i64, ptr %l6, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l8, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l8, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l153, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb25
bb25:
  %t200 = load i64, ptr %l153, !tbaa !24
  store i64 %t200, ptr %l150, !tbaa !24
  br label %bb26
bb26:
  %t201 = load i64, ptr %l150, !tbaa !24
  store i64 %t201, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t203 = load i64, ptr %l9, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb28, label %bb29
bb28:
  br label %bb71
bb29:
  br label %bb30
bb30:
  %t210 = load i64, ptr %l6, !tbaa !24
  %t211 = load i64, ptr %l10, !tbaa !24
  %t212 = load i64, ptr %l8, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l11, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l171, !tbaa !29
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr %"compiler/mir:Fn", ptr %t221, i32 0, i32 4
  store ptr %t223, ptr %l173, !tbaa !29
  %t224 = load i64, ptr %l11, !tbaa !24
  %t225 = load ptr, ptr %l173, !tbaa !29
  %t226 = call ptr @__olang_scope_or(ptr %v1, ptr %t225)
  %t227 = call ptr @__olang_scope_hold(ptr %t226)
  %t228 = ptrtoint ptr %t227 to i64
  %t230 = inttoptr i64 %t228 to ptr
  %t231 = load ptr, ptr %l173, !tbaa !29
  %t233 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t230, ptr %t231, i64 %t224)
  store i32 %t233, ptr %l176
  br label %bb31
bb31:
  %t234 = load ptr, ptr %l171, !tbaa !29
  %t235 = load i32, ptr %l176, !tbaa !23
  %t236 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %t234, i32 %t235)
  store i1 %t236, ptr %l177
  br label %bb32
bb32:
  %t237 = load i1, ptr %l177, !tbaa !21
  br i1 %t237, label %bb33, label %bb34
bb33:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr %"compiler/mir:Fn", ptr %t238, i32 0, i32 7
  store ptr %t240, ptr %l179, !tbaa !29
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr %"compiler/mir:Fn", ptr %t241, i32 0, i32 4
  store ptr %t243, ptr %l181, !tbaa !29
  %t244 = load i64, ptr %l11, !tbaa !24
  %t245 = load ptr, ptr %l181, !tbaa !29
  %t246 = call ptr @__olang_scope_or(ptr %v1, ptr %t245)
  %t247 = call ptr @__olang_scope_hold(ptr %t246)
  %t248 = ptrtoint ptr %t247 to i64
  %t250 = inttoptr i64 %t248 to ptr
  %t251 = load ptr, ptr %l181, !tbaa !29
  %t253 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t250, ptr %t251, i64 %t244)
  store i32 %t253, ptr %l184
  br label %bb35
bb34:
  br label %bb69
bb35:
  %t254 = load i32, ptr %l184, !tbaa !23
  %t255 = sext i32 %t254 to i64
  %t256 = load ptr, ptr %l179, !tbaa !29
  %t257 = call ptr @__olang_scope_or(ptr %v1, ptr %t256)
  %t258 = call ptr @__olang_scope_hold(ptr %t257)
  %t259 = ptrtoint ptr %t258 to i64
  %t261 = inttoptr i64 %t259 to ptr
  %t262 = load ptr, ptr %l179, !tbaa !29
  %t264 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t261, ptr %t262, i64 %t255)
  store %"compiler/mir:Local" %t264, ptr %l187
  br label %bb36
bb36:
  %t265 = load %"compiler/mir:Local", ptr %l187
  store %"compiler/mir:Local" %t265, ptr %l12
  %t266 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t267 = load i32, ptr %t266, !range !{i32 0, i32 4}
  %t269 = trunc i64 0 to i32
  %t270 = icmp eq i32 %t267, %t269
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l191, !tbaa !29
  %t275 = load i64, ptr %l11, !tbaa !24
  store i64 %t275, ptr %l192, !tbaa !24
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = getelementptr %"compiler/mir:Fn", ptr %t276, i32 0, i32 4
  store ptr %t278, ptr %l194, !tbaa !29
  %t279 = load i64, ptr %l11, !tbaa !24
  %t280 = load ptr, ptr %l194, !tbaa !29
  %t281 = call ptr @__olang_scope_or(ptr %v1, ptr %t280)
  %t282 = call ptr @__olang_scope_hold(ptr %t281)
  %t283 = ptrtoint ptr %t282 to i64
  %t285 = inttoptr i64 %t283 to ptr
  %t286 = load ptr, ptr %l194, !tbaa !29
  %t288 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t285, ptr %t286, i64 %t279)
  store i32 %t288, ptr %l197
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t289 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t291 = load i64, ptr %l192, !tbaa !24
  %t292 = call i64 @__olang_fmt_i64(ptr null, i64 %t291)
  %t293 = add i64 %t290, %t292
  %t294 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = load i32, ptr %l197, !tbaa !23
  %t298 = sext i32 %t297 to i64
  %t299 = call i64 @__olang_fmt_i64(ptr null, i64 %t298)
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t289, i64 %t290)
  %t305 = getelementptr i8, ptr %t304, i64 %t290
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t291)
  %t307 = getelementptr i8, ptr %t305, i64 %t292
  call void @olang_textcopy(ptr %t307, ptr %t294, i64 %t295)
  %t308 = getelementptr i8, ptr %t307, i64 %t295
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t298)
  %t310 = getelementptr i8, ptr %t308, i64 %t299
  call void @olang_textcopy(ptr %t310, ptr %t301, i64 %t302)
  %t311 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t304, 1
  %t314 = load ptr, ptr %l191, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t314, { i64, ptr } %t312)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t316 = load i64, ptr %l11, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t322 = icmp slt i64 %t316, %t319
  br i1 %t322, label %bb42, label %bb43
bb42:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/mir:verifier", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  store ptr %t327, ptr %l206, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t328, ptr %l207, !tbaa !27
  %t329 = load i64, ptr %l11, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i32, ptr %t332, i64 %t329
  %t334 = load i32, ptr %t333, !tbaa !33
  %t335 = load ptr, ptr %l206, !tbaa !29
  %t336 = call ptr @__olang_scope_or(ptr %v2, ptr %t335)
  %t337 = call ptr @__olang_scope_hold(ptr %t336)
  %t338 = ptrtoint ptr %t337 to i64
  %t340 = inttoptr i64 %t338 to ptr
  %t341 = load ptr, ptr %l206, !tbaa !29
  %t343 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %t340, ptr %t341, i32 %t334)
  store i1 %t343, ptr %l211
  br label %bb44
bb43:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb45
bb44:
  %t344 = load i1, ptr %l211, !tbaa !21
  store i1 %t344, ptr %l204, !tbaa !21
  br label %bb45
bb45:
  %t345 = load i1, ptr %l204, !tbaa !21
  br i1 %t345, label %bb46, label %bb47
bb46:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/mir:verifier", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l214, !tbaa !29
  %t350 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t351 = load i32, ptr %t350, !tbaa !23
  %t352 = load ptr, ptr %l214, !tbaa !29
  %t353 = call ptr @__olang_scope_or(ptr %v2, ptr %t352)
  %t354 = call ptr @__olang_scope_hold(ptr %t353)
  %t355 = ptrtoint ptr %t354 to i64
  %t357 = inttoptr i64 %t355 to ptr
  %t358 = load ptr, ptr %l214, !tbaa !29
  %t360 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t357, ptr %t358, i32 %t351)
  store i1 %t360, ptr %l217
  br label %bb48
bb47:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb49
bb48:
  %t361 = load i1, ptr %l217, !tbaa !21
  store i1 %t361, ptr %l212, !tbaa !21
  br label %bb49
bb49:
  %t362 = load i1, ptr %l212, !tbaa !21
  br i1 %t362, label %bb50, label %bb51
bb50:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/mir:verifier", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  store ptr %t366, ptr %l220, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/mir:verifier", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  store ptr %t370, ptr %l222, !tbaa !29
  %t371 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t372 = load i32, ptr %t371, !tbaa !23
  %t373 = load ptr, ptr %l222, !tbaa !29
  %t374 = call ptr @__olang_scope_or(ptr %v2, ptr %t373)
  %t375 = call ptr @__olang_scope_hold(ptr %t374)
  %t376 = ptrtoint ptr %t375 to i64
  %t378 = inttoptr i64 %t376 to ptr
  %t379 = load ptr, ptr %l222, !tbaa !29
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t378, ptr %t379, i32 %t372)
  store i32 %t381, ptr %l225
  br label %bb52
bb51:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb55
bb52:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/mir:verifier", ptr %t382, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !29
  store ptr %t385, ptr %l227, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t386, ptr %l228, !tbaa !27
  %t387 = load i64, ptr %l11, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr i32, ptr %t390, i64 %t387
  %t392 = load i32, ptr %t391, !tbaa !33
  %t393 = load ptr, ptr %l227, !tbaa !29
  %t394 = call ptr @__olang_scope_or(ptr %v2, ptr %t393)
  %t395 = call ptr @__olang_scope_hold(ptr %t394)
  %t396 = ptrtoint ptr %t395 to i64
  %t398 = inttoptr i64 %t396 to ptr
  %t399 = load ptr, ptr %l227, !tbaa !29
  %t401 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t398, ptr %t399, i32 %t392)
  store i32 %t401, ptr %l232
  br label %bb53
bb53:
  %t402 = load ptr, ptr %l220, !tbaa !29
  %t403 = call ptr @__olang_scope_or(ptr %v2, ptr %t402)
  %t404 = call ptr @__olang_scope_hold(ptr %t403)
  %t405 = ptrtoint ptr %t404 to i64
  %t407 = inttoptr i64 %t405 to ptr
  %t408 = load ptr, ptr %l220, !tbaa !29
  %t409 = load i32, ptr %l225, !tbaa !23
  %t410 = load i32, ptr %l232, !tbaa !23
  %t411 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t407, ptr %t408, i32 %t409, i32 %t410)
  store i1 %t411, ptr %l234
  br label %bb54
bb54:
  %t412 = load i1, ptr %l234, !tbaa !21
  store i1 %t412, ptr %l218, !tbaa !21
  br label %bb55
bb55:
  %t413 = load i1, ptr %l218, !tbaa !21
  store i1 %t413, ptr %l13, !tbaa !21
  %t414 = load i64, ptr %l11, !tbaa !24
  %t415 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t420 = icmp slt i64 %t414, %t417
  br i1 %t420, label %bb56, label %bb57
bb56:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/mir:verifier", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  store ptr %t425, ptr %l241, !tbaa !29
  %t426 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t427 = load i32, ptr %t426, !tbaa !23
  %t428 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t428, ptr %l243, !tbaa !27
  %t429 = load i64, ptr %l11, !tbaa !24
  %t431 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr i32, ptr %t432, i64 %t429
  %t434 = load i32, ptr %t433, !tbaa !33
  %t435 = load ptr, ptr %l241, !tbaa !29
  %t436 = call ptr @__olang_scope_or(ptr %v2, ptr %t435)
  %t437 = call ptr @__olang_scope_hold(ptr %t436)
  %t438 = ptrtoint ptr %t437 to i64
  %t440 = inttoptr i64 %t438 to ptr
  %t441 = load ptr, ptr %l241, !tbaa !29
  %t444 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t440, ptr %t441, i32 %t427, i32 %t434)
  store i1 %t444, ptr %l247
  br label %bb58
bb57:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb59
bb58:
  %t445 = load i1, ptr %l247, !tbaa !21
  %t446 = xor i1 %t445, true
  store i1 %t446, ptr %l239, !tbaa !21
  br label %bb59
bb59:
  %t448 = load i1, ptr %l239, !tbaa !21
  br i1 %t448, label %bb60, label %bb61
bb60:
  %t449 = load i1, ptr %l13, !tbaa !21
  %t451 = xor i1 %t449, true
  store i1 %t451, ptr %l249, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb62
bb62:
  %t453 = load i1, ptr %l249, !tbaa !21
  br i1 %t453, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l252, !tbaa !29
  %t455 = load i64, ptr %l11, !tbaa !24
  store i64 %t455, ptr %l253, !tbaa !24
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/mir:verifier", ptr %t456, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !29
  store ptr %t459, ptr %l255, !tbaa !29
  %t460 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t461 = load i32, ptr %t460, !tbaa !23
  %t462 = load ptr, ptr %l255, !tbaa !29
  %t463 = call ptr @__olang_scope_or(ptr %v2, ptr %t462)
  %t464 = call ptr @__olang_scope_hold(ptr %t463)
  %t465 = ptrtoint ptr %t464 to i64
  %t467 = inttoptr i64 %t465 to ptr
  %t469 = inttoptr i64 0 to ptr
  %t470 = load ptr, ptr %l255, !tbaa !29
  %t472 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t467, ptr %s10, ptr %t469, ptr %t470, i32 %t461)
  store { i64, ptr } %t472, ptr %l259
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/mir:verifier", ptr %t473, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !29
  store ptr %t476, ptr %l261, !tbaa !29
  %t477 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t477, ptr %l262, !tbaa !27
  %t478 = load i64, ptr %l11, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr i32, ptr %t481, i64 %t478
  %t483 = load i32, ptr %t482, !tbaa !33
  %t484 = load ptr, ptr %l261, !tbaa !29
  %t485 = call ptr @__olang_scope_or(ptr %v2, ptr %t484)
  %t486 = call ptr @__olang_scope_hold(ptr %t485)
  %t487 = ptrtoint ptr %t486 to i64
  %t489 = inttoptr i64 %t487 to ptr
  %t491 = inttoptr i64 0 to ptr
  %t492 = load ptr, ptr %l261, !tbaa !29
  %t494 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t489, ptr %s10, ptr %t491, ptr %t492, i32 %t483)
  store { i64, ptr } %t494, ptr %l267
  br label %bb66
bb66:
  %t495 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t497 = load i64, ptr %l253, !tbaa !24
  %t498 = call i64 @__olang_fmt_i64(ptr null, i64 %t497)
  %t499 = add i64 %t496, %t498
  %t500 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t501 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t502 = add i64 %t499, %t501
  %t503 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = extractvalue { i64, ptr } %t503, 0
  %t506 = add i64 %t502, %t505
  %t507 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t508 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t509 = add i64 %t506, %t508
  %t510 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 1
  %t512 = extractvalue { i64, ptr } %t510, 0
  %t513 = add i64 %t509, %t512
  %t514 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t513)
  call void @olang_textcopy(ptr %t514, ptr %t495, i64 %t496)
  %t515 = getelementptr i8, ptr %t514, i64 %t496
  %t516 = call i64 @__olang_fmt_i64(ptr %t515, i64 %t497)
  %t517 = getelementptr i8, ptr %t515, i64 %t498
  call void @olang_textcopy(ptr %t517, ptr %t500, i64 %t501)
  %t518 = getelementptr i8, ptr %t517, i64 %t501
  call void @olang_textcopy(ptr %t518, ptr %t504, i64 %t505)
  %t519 = getelementptr i8, ptr %t518, i64 %t505
  call void @olang_textcopy(ptr %t519, ptr %t507, i64 %t508)
  %t520 = getelementptr i8, ptr %t519, i64 %t508
  call void @olang_textcopy(ptr %t520, ptr %t511, i64 %t512)
  %t521 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t514, 1
  %t524 = load ptr, ptr %l252, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t524, { i64, ptr } %t522)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t526 = load i64, ptr %l10, !tbaa !24
  %t529 = add i64 %t526, 1
  store i64 %t529, ptr %l10, !tbaa !24
  br label %bb27
bb71:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr %"compiler/mir:Fn", ptr %t531, i32 0, i32 5
  store ptr %t533, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb72
bb72:
  %t535 = load i64, ptr %l15, !tbaa !24
  store i64 %t535, ptr %l275, !tbaa !24
  %t536 = load ptr, ptr %l14, !tbaa !29
  store ptr %t536, ptr %l276, !tbaa !29
  %t537 = load ptr, ptr %l276, !tbaa !29
  %t538 = call ptr @__olang_scope_or(ptr %v1, ptr %t537)
  %t539 = call ptr @__olang_scope_hold(ptr %t538)
  %t540 = ptrtoint ptr %t539 to i64
  %t542 = inttoptr i64 %t540 to ptr
  %t543 = load ptr, ptr %l276, !tbaa !29
  %t544 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t542, ptr %t543)
  store i64 %t544, ptr %l278
  br label %bb73
bb73:
  %t545 = load i64, ptr %l275, !tbaa !24
  %t546 = load i64, ptr %l278, !tbaa !24
  %t547 = icmp slt i64 %t545, %t546
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb74, label %bb75
bb74:
  br label %bb88
bb75:
  br label %bb76
bb76:
  %t551 = load ptr, ptr %l14, !tbaa !29
  store ptr %t551, ptr %l281, !tbaa !29
  %t552 = load i64, ptr %l15, !tbaa !24
  %t553 = load ptr, ptr %l281, !tbaa !29
  %t554 = call ptr @__olang_scope_or(ptr %v1, ptr %t553)
  %t555 = call ptr @__olang_scope_hold(ptr %t554)
  %t556 = ptrtoint ptr %t555 to i64
  %t558 = inttoptr i64 %t556 to ptr
  %t559 = load ptr, ptr %l281, !tbaa !29
  %t561 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t558, ptr %t559, i64 %t552)
  store i32 %t561, ptr %l284
  br label %bb77
bb77:
  %t562 = load i32, ptr %l284, !tbaa !23
  store i32 %t562, ptr %l16, !tbaa !23
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i32, ptr %l16, !tbaa !23
  %t567 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %t563, i32 %t564)
  store i1 %t567, ptr %l287
  br label %bb78
bb78:
  %t568 = load i1, ptr %l287, !tbaa !21
  br i1 %t568, label %bb79, label %bb80
bb79:
  %t569 = load ptr, ptr %l1, !tbaa !29
  %t571 = getelementptr %"compiler/mir:Fn", ptr %t569, i32 0, i32 7
  store ptr %t571, ptr %l290, !tbaa !29
  %t572 = load i32, ptr %l16, !tbaa !23
  %t574 = sext i32 %t572 to i64
  %t575 = load ptr, ptr %l290, !tbaa !29
  %t576 = call ptr @__olang_scope_or(ptr %v1, ptr %t575)
  %t577 = call ptr @__olang_scope_hold(ptr %t576)
  %t578 = ptrtoint ptr %t577 to i64
  %t580 = inttoptr i64 %t578 to ptr
  %t581 = load ptr, ptr %l290, !tbaa !29
  %t583 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t580, ptr %t581, i64 %t574)
  store %"compiler/mir:Local" %t583, ptr %l294
  br label %bb81
bb80:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb82
bb81:
  %t584 = getelementptr %"compiler/mir:Local", ptr %l294, i32 0, i32 3
  %t585 = load i32, ptr %t584, !range !{i32 0, i32 4}
  %t587 = trunc i64 1 to i32
  %t588 = icmp eq i32 %t585, %t587
  %t590 = xor i1 %t588, true
  store i1 %t590, ptr %l288, !tbaa !21
  br label %bb82
bb82:
  %t592 = load i1, ptr %l288, !tbaa !21
  br i1 %t592, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s15
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load i32, ptr %l16, !tbaa !23
  %t595 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t596 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t598 = sext i32 %t594 to i64
  %t599 = call i64 @__olang_fmt_i64(ptr null, i64 %t598)
  %t600 = add i64 %t596, %t599
  %t601 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t602 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t603 = add i64 %t600, %t602
  %t604 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t595, i64 %t596)
  %t605 = getelementptr i8, ptr %t604, i64 %t596
  %t606 = call i64 @__olang_fmt_i64(ptr %t605, i64 %t598)
  %t607 = getelementptr i8, ptr %t605, i64 %t599
  call void @olang_textcopy(ptr %t607, ptr %t601, i64 %t602)
  %t608 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t604, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t593, { i64, ptr } %t609)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t613 = load i64, ptr %l15, !tbaa !24
  %t616 = add i64 %t613, 1
  store i64 %t616, ptr %l15, !tbaa !24
  br label %bb72
bb88:
  store i64 0, ptr %l17, !tbaa !24
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr %"compiler/mir:Fn", ptr %t618, i32 0, i32 7
  store ptr %t620, ptr %l306, !tbaa !29
  %t621 = load ptr, ptr %l306, !tbaa !29
  %t622 = call ptr @__olang_scope_or(ptr %v1, ptr %t621)
  %t623 = call ptr @__olang_scope_hold(ptr %t622)
  %t624 = ptrtoint ptr %t623 to i64
  %t626 = inttoptr i64 %t624 to ptr
  %t627 = load ptr, ptr %l306, !tbaa !29
  %t628 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t626, ptr %t627)
  store i64 %t628, ptr %l308
  br label %bb89
bb89:
  %t629 = load i64, ptr %l308, !tbaa !24
  store i64 %t629, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t630 = load i64, ptr %l18, !tbaa !24
  %t631 = load i64, ptr %l17, !tbaa !24
  %t634 = icmp sgt i64 %t630, %t631
  br i1 %t634, label %bb90, label %bb91
bb90:
  %t636 = load i64, ptr %l19, !tbaa !24
  %t638 = icmp sgt i64 %t636, 0
  br i1 %t638, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l312, !tbaa !24
  br label %bb95
bb92:
  %t640 = load i64, ptr %l18, !tbaa !24
  %t641 = load i64, ptr %l17, !tbaa !24
  %t644 = sub i64 %t640, %t641
  %t645 = load i64, ptr %l19, !tbaa !24
  %t648 = add i64 %t644, %t645
  %t650 = sub i64 %t648, 1
  %t651 = load i64, ptr %l19, !tbaa !24
  %t654 = sdiv i64 %t650, %t651
  store i64 %t654, ptr %l315, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb94
bb94:
  %t656 = load i64, ptr %l315, !tbaa !24
  store i64 %t656, ptr %l312, !tbaa !24
  br label %bb95
bb95:
  %t657 = load i64, ptr %l312, !tbaa !24
  store i64 %t657, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb96
bb96:
  %t658 = load i64, ptr %l21, !tbaa !24
  %t659 = load i64, ptr %l20, !tbaa !24
  %t662 = icmp slt i64 %t658, %t659
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb97, label %bb98
bb97:
  br label %bb107
bb98:
  br label %bb99
bb99:
  %t666 = load i64, ptr %l17, !tbaa !24
  %t667 = load i64, ptr %l21, !tbaa !24
  %t668 = load i64, ptr %l19, !tbaa !24
  %t671 = mul i64 %t667, %t668
  %t674 = add i64 %t666, %t671
  store i64 %t674, ptr %l22, !tbaa !24
  %t676 = load ptr, ptr %l1, !tbaa !29
  %t678 = getelementptr %"compiler/mir:Fn", ptr %t676, i32 0, i32 7
  store ptr %t678, ptr %l334, !tbaa !29
  %t679 = load i64, ptr %l22, !tbaa !24
  %t680 = load ptr, ptr %l334, !tbaa !29
  %t681 = call ptr @__olang_scope_or(ptr %v1, ptr %t680)
  %t682 = call ptr @__olang_scope_hold(ptr %t681)
  %t683 = ptrtoint ptr %t682 to i64
  %t685 = inttoptr i64 %t683 to ptr
  %t686 = load ptr, ptr %l334, !tbaa !29
  %t688 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t685, ptr %t686, i64 %t679)
  store %"compiler/mir:Local" %t688, ptr %l337
  br label %bb100
bb100:
  %t689 = load %"compiler/mir:Local", ptr %l337
  store %"compiler/mir:Local" %t689, ptr %l23
  %t690 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 2
  %t691 = load i32, ptr %t690, !tbaa !23
  %t692 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t695 = icmp eq i32 %t691, %t692
  br i1 %t695, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s20
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t698 = load i64, ptr %l22, !tbaa !24
  %t699 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t702 = call i64 @__olang_fmt_i64(ptr null, i64 %t698)
  %t703 = add i64 %t700, %t702
  %t704 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t705 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t706 = add i64 %t703, %t705
  %t707 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t706)
  call void @olang_textcopy(ptr %t707, ptr %t699, i64 %t700)
  %t708 = getelementptr i8, ptr %t707, i64 %t700
  %t709 = call i64 @__olang_fmt_i64(ptr %t708, i64 %t698)
  %t710 = getelementptr i8, ptr %t708, i64 %t702
  call void @olang_textcopy(ptr %t710, ptr %t704, i64 %t705)
  %t711 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t707, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t697, { i64, ptr } %t712)
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb104
bb104:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 4
  %t718 = load { i64, [1 x i64] }, ptr %t717
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %v1, ptr %t716, { i64, [1 x i64] } %t718)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t721 = load i64, ptr %l21, !tbaa !24
  %t724 = add i64 %t721, 1
  store i64 %t724, ptr %l21, !tbaa !24
  br label %bb96
bb107:
  store i64 0, ptr %l24, !tbaa !24
  %t726 = load ptr, ptr %l1, !tbaa !29
  %t728 = getelementptr %"compiler/mir:Fn", ptr %t726, i32 0, i32 8
  store ptr %t728, ptr %l351, !tbaa !29
  %t729 = load ptr, ptr %l351, !tbaa !29
  %t730 = call ptr @__olang_scope_or(ptr %v1, ptr %t729)
  %t731 = call ptr @__olang_scope_hold(ptr %t730)
  %t732 = ptrtoint ptr %t731 to i64
  %t734 = inttoptr i64 %t732 to ptr
  %t735 = load ptr, ptr %l351, !tbaa !29
  %t736 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t734, ptr %t735)
  store i64 %t736, ptr %l353
  br label %bb108
bb108:
  %t737 = load i64, ptr %l353, !tbaa !24
  store i64 %t737, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t738 = load i64, ptr %l25, !tbaa !24
  %t739 = load i64, ptr %l24, !tbaa !24
  %t742 = icmp sgt i64 %t738, %t739
  br i1 %t742, label %bb109, label %bb110
bb109:
  %t744 = load i64, ptr %l26, !tbaa !24
  %t746 = icmp sgt i64 %t744, 0
  br i1 %t746, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l357, !tbaa !24
  br label %bb114
bb111:
  %t748 = load i64, ptr %l25, !tbaa !24
  %t749 = load i64, ptr %l24, !tbaa !24
  %t752 = sub i64 %t748, %t749
  %t753 = load i64, ptr %l26, !tbaa !24
  %t756 = add i64 %t752, %t753
  %t758 = sub i64 %t756, 1
  %t759 = load i64, ptr %l26, !tbaa !24
  %t762 = sdiv i64 %t758, %t759
  store i64 %t762, ptr %l360, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l360, !tbaa !24
  br label %bb113
bb113:
  %t764 = load i64, ptr %l360, !tbaa !24
  store i64 %t764, ptr %l357, !tbaa !24
  br label %bb114
bb114:
  %t765 = load i64, ptr %l357, !tbaa !24
  store i64 %t765, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb115
bb115:
  %t766 = load i64, ptr %l28, !tbaa !24
  %t767 = load i64, ptr %l27, !tbaa !24
  %t770 = icmp slt i64 %t766, %t767
  %t772 = xor i1 %t770, true
  br i1 %t772, label %bb116, label %bb117
bb116:
  br label %bb128
bb117:
  br label %bb118
bb118:
  %t774 = load i64, ptr %l24, !tbaa !24
  %t775 = load i64, ptr %l28, !tbaa !24
  %t776 = load i64, ptr %l26, !tbaa !24
  %t779 = mul i64 %t775, %t776
  %t782 = add i64 %t774, %t779
  store i64 %t782, ptr %l29, !tbaa !24
  %t784 = load ptr, ptr %l1, !tbaa !29
  %t786 = getelementptr %"compiler/mir:Fn", ptr %t784, i32 0, i32 8
  store ptr %t786, ptr %l379, !tbaa !29
  %t787 = load i64, ptr %l29, !tbaa !24
  %t788 = load ptr, ptr %l379, !tbaa !29
  %t789 = call ptr @__olang_scope_or(ptr %v1, ptr %t788)
  %t790 = call ptr @__olang_scope_hold(ptr %t789)
  %t791 = ptrtoint ptr %t790 to i64
  %t793 = inttoptr i64 %t791 to ptr
  %t794 = load ptr, ptr %l379, !tbaa !29
  %t796 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t793, ptr %t794, i64 %t787)
  store %"compiler/mir:ScopeInfo" %t796, ptr %l382
  br label %bb119
bb119:
  %t797 = getelementptr %"compiler/mir:ScopeInfo", ptr %l382, i32 0, i32 1
  %t798 = load i32, ptr %t797, !tbaa !23
  store i32 %t798, ptr %l30, !tbaa !23
  %t800 = load i32, ptr %l30, !tbaa !23
  %t801 = load i64, ptr %l29, !tbaa !24
  %t803 = trunc i64 %t801 to i32
  %t807 = icmp sge i32 %t800, %t803
  br i1 %t807, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l389, !tbaa !21
  br label %bb122
bb121:
  %t809 = load i32, ptr %l30, !tbaa !23
  %t810 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t813 = icmp slt i32 %t809, %t810
  store i1 %t813, ptr %l389, !tbaa !21
  br label %bb122
bb122:
  %t815 = load i1, ptr %l389, !tbaa !21
  br i1 %t815, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s25
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t817 = load i64, ptr %l29, !tbaa !24
  %t818 = load i32, ptr %l30, !tbaa !23
  %t819 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t820 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t822 = call i64 @__olang_fmt_i64(ptr null, i64 %t817)
  %t823 = add i64 %t820, %t822
  %t824 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t825 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t826 = add i64 %t823, %t825
  %t828 = sext i32 %t818 to i64
  %t829 = call i64 @__olang_fmt_i64(ptr null, i64 %t828)
  %t830 = add i64 %t826, %t829
  %t831 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t832 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t833 = add i64 %t830, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t819, i64 %t820)
  %t835 = getelementptr i8, ptr %t834, i64 %t820
  %t836 = call i64 @__olang_fmt_i64(ptr %t835, i64 %t817)
  %t837 = getelementptr i8, ptr %t835, i64 %t822
  call void @olang_textcopy(ptr %t837, ptr %t824, i64 %t825)
  %t838 = getelementptr i8, ptr %t837, i64 %t825
  %t839 = call i64 @__olang_fmt_i64(ptr %t838, i64 %t828)
  %t840 = getelementptr i8, ptr %t838, i64 %t829
  call void @olang_textcopy(ptr %t840, ptr %t831, i64 %t832)
  %t841 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t834, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t816, { i64, ptr } %t842)
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t846 = load i64, ptr %l28, !tbaa !24
  %t849 = add i64 %t846, 1
  store i64 %t849, ptr %l28, !tbaa !24
  br label %bb115
bb128:
  %t851 = load ptr, ptr %l1, !tbaa !29
  %t853 = getelementptr %"compiler/mir:Fn", ptr %t851, i32 0, i32 14
  store ptr %t853, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb129
bb129:
  %t855 = load i64, ptr %l32, !tbaa !24
  store i64 %t855, ptr %l403, !tbaa !24
  %t856 = load ptr, ptr %l31, !tbaa !29
  store ptr %t856, ptr %l404, !tbaa !29
  %t857 = load ptr, ptr %l404, !tbaa !29
  %t858 = call ptr @__olang_scope_or(ptr %v1, ptr %t857)
  %t859 = call ptr @__olang_scope_hold(ptr %t858)
  %t860 = ptrtoint ptr %t859 to i64
  %t862 = inttoptr i64 %t860 to ptr
  %t863 = load ptr, ptr %l404, !tbaa !29
  %t864 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %t862, ptr %t863)
  store i64 %t864, ptr %l406
  br label %bb130
bb130:
  %t865 = load i64, ptr %l403, !tbaa !24
  %t866 = load i64, ptr %l406, !tbaa !24
  %t867 = icmp slt i64 %t865, %t866
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb131, label %bb132
bb131:
  br label %bb152
bb132:
  br label %bb133
bb133:
  %t871 = load ptr, ptr %l31, !tbaa !29
  store ptr %t871, ptr %l409, !tbaa !29
  %t872 = load i64, ptr %l32, !tbaa !24
  %t873 = load ptr, ptr %l409, !tbaa !29
  %t874 = call ptr @__olang_scope_or(ptr %v1, ptr %t873)
  %t875 = call ptr @__olang_scope_hold(ptr %t874)
  %t876 = ptrtoint ptr %t875 to i64
  %t878 = inttoptr i64 %t876 to ptr
  %t879 = load ptr, ptr %l409, !tbaa !29
  %t881 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t878, ptr %t879, i64 %t872)
  store %"compiler/mir:Call" %t881, ptr %l412
  br label %bb134
bb134:
  %t882 = load %"compiler/mir:Call", ptr %l412
  store %"compiler/mir:Call" %t882, ptr %l33
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 0
  %t885 = load { i64, [7 x i64] }, ptr %t884
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %v1, ptr %t883, { i64, [7 x i64] } %t885)
  br label %bb135
bb135:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 1
  %t890 = load %"compiler/mir:Range", ptr %t889
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %v1, ptr %t888, %"compiler/mir:Range" %t890)
  br label %bb136
bb136:
  %t893 = load ptr, ptr %l0, !tbaa !29
  %t894 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 2
  %t895 = load %"compiler/mir:Range", ptr %t894
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %v1, ptr %t893, %"compiler/mir:Range" %t895)
  br label %bb137
bb137:
  %t898 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 4
  %t899 = load i1, ptr %t898, !tbaa !21
  br i1 %t899, label %bb138, label %bb139
bb138:
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t902 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 3
  %t903 = load %"compiler/mir:Lvalue", ptr %t902
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v1, ptr %t901, %"compiler/mir:Lvalue" %t903)
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  %t906 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t907 = load i32, ptr %t906, !tbaa !23
  %t908 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t911 = icmp ne i32 %t907, %t908
  br i1 %t911, label %bb142, label %bb143
bb142:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t915 = load i32, ptr %t914, !tbaa !23
  %t918 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t913, i32 %t915)
  store i1 %t918, ptr %l427
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  %t919 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t920 = load i32, ptr %t919, !tbaa !23
  %t921 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t924 = icmp ne i32 %t920, %t921
  br i1 %t924, label %bb146, label %bb147
bb146:
  %t926 = load ptr, ptr %l0, !tbaa !29
  %t927 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t928 = load i32, ptr %t927, !tbaa !23
  %t931 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t926, i32 %t928)
  store i1 %t931, ptr %l433
  br label %bb148
bb147:
  br label %bb150
bb148:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 6
  %t934 = load i32, ptr %t933, !tbaa !23
  %t937 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %t932, i32 %t934)
  store i1 %t937, ptr %l436
  br label %bb149
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t938 = load i64, ptr %l32, !tbaa !24
  %t941 = add i64 %t938, 1
  store i64 %t941, ptr %l32, !tbaa !24
  br label %bb129
bb152:
  %t943 = load ptr, ptr %l1, !tbaa !29
  %t945 = getelementptr %"compiler/mir:Fn", ptr %t943, i32 0, i32 15
  store ptr %t945, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb153
bb153:
  %t947 = load i64, ptr %l35, !tbaa !24
  store i64 %t947, ptr %l442, !tbaa !24
  %t948 = load ptr, ptr %l34, !tbaa !29
  store ptr %t948, ptr %l443, !tbaa !29
  %t949 = load ptr, ptr %l443, !tbaa !29
  %t950 = call ptr @__olang_scope_or(ptr %v1, ptr %t949)
  %t951 = call ptr @__olang_scope_hold(ptr %t950)
  %t952 = ptrtoint ptr %t951 to i64
  %t954 = inttoptr i64 %t952 to ptr
  %t955 = load ptr, ptr %l443, !tbaa !29
  %t956 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %t954, ptr %t955)
  store i64 %t956, ptr %l445
  br label %bb154
bb154:
  %t957 = load i64, ptr %l442, !tbaa !24
  %t958 = load i64, ptr %l445, !tbaa !24
  %t959 = icmp slt i64 %t957, %t958
  %t961 = xor i1 %t959, true
  br i1 %t961, label %bb155, label %bb156
bb155:
  br label %bb161
bb156:
  br label %bb157
bb157:
  %t963 = load ptr, ptr %l34, !tbaa !29
  store ptr %t963, ptr %l448, !tbaa !29
  %t964 = load i64, ptr %l35, !tbaa !24
  %t965 = load ptr, ptr %l448, !tbaa !29
  %t966 = call ptr @__olang_scope_or(ptr %v1, ptr %t965)
  %t967 = call ptr @__olang_scope_hold(ptr %t966)
  %t968 = ptrtoint ptr %t967 to i64
  %t970 = inttoptr i64 %t968 to ptr
  %t971 = load ptr, ptr %l448, !tbaa !29
  %t973 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t970, ptr %t971, i64 %t964)
  store %"compiler/mir:Case" %t973, ptr %l451
  br label %bb158
bb158:
  %t974 = load %"compiler/mir:Case", ptr %l451
  store %"compiler/mir:Case" %t974, ptr %l36
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t976 = getelementptr %"compiler/mir:Case", ptr %l36, i32 0, i32 1
  %t977 = load i32, ptr %t976, !tbaa !23
  %t980 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t975, i32 %t977)
  store i1 %t980, ptr %l454
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t981 = load i64, ptr %l35, !tbaa !24
  %t984 = add i64 %t981, 1
  store i64 %t984, ptr %l35, !tbaa !24
  br label %bb153
bb161:
  %t986 = load ptr, ptr %l1, !tbaa !29
  %t988 = getelementptr %"compiler/mir:Fn", ptr %t986, i32 0, i32 16
  store ptr %t988, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s38
  %t990 = load i64, ptr %l38, !tbaa !24
  store i64 %t990, ptr %l460, !tbaa !24
  %t991 = load ptr, ptr %l37, !tbaa !29
  store ptr %t991, ptr %l461, !tbaa !29
  %t992 = load ptr, ptr %l461, !tbaa !29
  %t993 = call ptr @__olang_scope_or(ptr %v1, ptr %t992)
  %t994 = call ptr @__olang_scope_hold(ptr %t993)
  %t995 = ptrtoint ptr %t994 to i64
  %t997 = inttoptr i64 %t995 to ptr
  %t998 = load ptr, ptr %l461, !tbaa !29
  %t999 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %t997, ptr %t998)
  store i64 %t999, ptr %l463
  br label %bb163
bb163:
  %t1000 = load i64, ptr %l460, !tbaa !24
  %t1001 = load i64, ptr %l463, !tbaa !24
  %t1002 = icmp slt i64 %t1000, %t1001
  %t1004 = xor i1 %t1002, true
  br i1 %t1004, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s38)
  br label %bb226
bb165:
  br label %bb166
bb166:
  %t1006 = load ptr, ptr %l37, !tbaa !29
  store ptr %t1006, ptr %l466, !tbaa !29
  %t1007 = load i64, ptr %l38, !tbaa !24
  %t1008 = load ptr, ptr %l466, !tbaa !29
  %t1009 = call ptr @__olang_scope_or(ptr %v1, ptr %t1008)
  %t1010 = call ptr @__olang_scope_hold(ptr %t1009)
  %t1011 = ptrtoint ptr %t1010 to i64
  %t1014 = inttoptr i64 %t1011 to ptr
  %t1015 = load ptr, ptr %l466, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t1012, ptr %t1014, ptr %t1015, i64 %t1007)
  call void @llvm.memmove.p0.p0.i64(ptr %l469, ptr %t1012, i64 144, i1 false)
  br label %bb167
bb167:
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %l469, i64 144, i1 false)
  %t1017 = load ptr, ptr %l0, !tbaa !29
  %t1018 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 0
  %t1019 = load { i64, [7 x i64] }, ptr %t1018
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %v1, ptr %t1017, { i64, [7 x i64] } %t1019)
  br label %bb168
bb168:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1023 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 1
  %t1024 = load %"compiler/mir:Range", ptr %t1023
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %v1, ptr %t1022, %"compiler/mir:Range" %t1024)
  br label %bb169
bb169:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 5
  %t1029 = load %"compiler/mir:Range", ptr %t1028
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %v1, ptr %t1027, %"compiler/mir:Range" %t1029)
  br label %bb170
bb170:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1033 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 2
  %t1034 = load %"compiler/mir:Range", ptr %t1033
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %v1, ptr %t1032, %"compiler/mir:Range" %t1034)
  br label %bb171
bb171:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  %t1038 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t1039 = load %"compiler/mir:Range", ptr %t1038
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %v1, ptr %t1037, %"compiler/mir:Range" %t1039)
  br label %bb172
bb172:
  %t1042 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t1043 = getelementptr %"compiler/mir:Range", ptr %t1042, i32 0, i32 1
  %t1044 = load i32, ptr %t1043, !tbaa !23
  %t1046 = icmp ne i32 %t1044, 0
  br i1 %t1046, label %bb173, label %bb174
bb173:
  %t1048 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t1049 = getelementptr %"compiler/mir:Range", ptr %t1048, i32 0, i32 1
  %t1050 = load i32, ptr %t1049, !tbaa !23
  %t1051 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t1052 = getelementptr %"compiler/mir:Range", ptr %t1051, i32 0, i32 1
  %t1053 = load i32, ptr %t1052, !tbaa !23
  %t1056 = icmp ne i32 %t1050, %t1053
  store i1 %t1056, ptr %l482, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l482, !tbaa !21
  br label %bb175
bb175:
  %t1058 = load i1, ptr %l482, !tbaa !21
  br i1 %t1058, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s39
  %t1059 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t1059, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d150, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s39)
  br label %bb179
bb179:
  %t1061 = load ptr, ptr %l0, !tbaa !29
  %t1062 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 10
  %t1063 = load %"compiler/mir:Range", ptr %t1062
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %v1, ptr %t1061, %"compiler/mir:Range" %t1063)
  br label %bb180
bb180:
  %t1066 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 10
  %t1067 = getelementptr %"compiler/mir:Range", ptr %t1066, i32 0, i32 1
  %t1068 = load i32, ptr %t1067, !tbaa !23
  %t1070 = icmp sgt i32 %t1068, 1
  br i1 %t1070, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s40
  %t1072 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s40, ptr %t1072, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d151, i32 0, i32 1) })
  br label %bb183
bb182:
  br label %bb184
bb183:
  call void @__olang_scope_close(ptr %s40)
  br label %bb184
bb184:
  %t1074 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1074, ptr %l492, !tbaa !29
  %t1075 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t1076 = load %"compiler/mir:Range", ptr %t1075
  store %"compiler/mir:Range" %t1076, ptr %l493
  %t1077 = load ptr, ptr %l1, !tbaa !29
  %t1079 = getelementptr %"compiler/mir:Fn", ptr %t1077, i32 0, i32 13
  store ptr %t1079, ptr %l495, !tbaa !29
  %t1080 = load ptr, ptr %l495, !tbaa !29
  %t1081 = call ptr @__olang_scope_or(ptr %v1, ptr %t1080)
  %t1082 = call ptr @__olang_scope_hold(ptr %t1081)
  %t1083 = ptrtoint ptr %t1082 to i64
  %t1085 = inttoptr i64 %t1083 to ptr
  %t1086 = load ptr, ptr %l495, !tbaa !29
  %t1087 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %t1085, ptr %t1086)
  store i64 %t1087, ptr %l497
  br label %bb185
bb185:
  %t1088 = load ptr, ptr %l492, !tbaa !29
  %t1089 = load %"compiler/mir:Range", ptr %l493
  %t1090 = load i64, ptr %l497, !tbaa !24
  %t1091 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t1088, %"compiler/mir:Range" %t1089, i64 %t1090, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t1091, ptr %l498
  br label %bb186
bb186:
  %t1092 = load i1, ptr %l498, !tbaa !21
  br i1 %t1092, label %bb187, label %bb188
bb187:
  store i32 0, ptr %l40, !tbaa !23
  %t1093 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t1094 = getelementptr %"compiler/mir:Range", ptr %t1093, i32 0, i32 1
  %t1095 = load i32, ptr %t1094, !tbaa !23
  store i32 %t1095, ptr %l41, !tbaa !23
  store i32 1, ptr %l42, !tbaa !23
  %t1097 = load i32, ptr %l41, !tbaa !23
  %t1098 = load i32, ptr %l40, !tbaa !23
  %t1101 = icmp sgt i32 %t1097, %t1098
  br i1 %t1101, label %bb189, label %bb190
bb188:
  br label %bb203
bb189:
  %t1103 = load i32, ptr %l42, !tbaa !23
  %t1105 = icmp sgt i32 %t1103, 0
  br i1 %t1105, label %bb191, label %bb192
bb190:
  store i32 0, ptr %l503, !tbaa !23
  br label %bb194
bb191:
  %t1107 = load i32, ptr %l41, !tbaa !23
  %t1108 = load i32, ptr %l40, !tbaa !23
  %t1111 = sub i32 %t1107, %t1108
  %t1112 = load i32, ptr %l42, !tbaa !23
  %t1115 = add i32 %t1111, %t1112
  %t1117 = sub i32 %t1115, 1
  %t1118 = load i32, ptr %l42, !tbaa !23
  %t1121 = sdiv i32 %t1117, %t1118
  store i32 %t1121, ptr %l506, !tbaa !23
  br label %bb193
bb192:
  store i32 0, ptr %l506, !tbaa !23
  br label %bb193
bb193:
  %t1123 = load i32, ptr %l506, !tbaa !23
  store i32 %t1123, ptr %l503, !tbaa !23
  br label %bb194
bb194:
  %t1124 = load i32, ptr %l503, !tbaa !23
  store i32 %t1124, ptr %l43, !tbaa !23
  store i32 0, ptr %l44, !tbaa !23
  br label %bb195
bb195:
  %t1125 = load i32, ptr %l44, !tbaa !23
  %t1126 = load i32, ptr %l43, !tbaa !23
  %t1129 = icmp slt i32 %t1125, %t1126
  %t1131 = xor i1 %t1129, true
  br i1 %t1131, label %bb196, label %bb197
bb196:
  br label %bb202
bb197:
  br label %bb198
bb198:
  %t1133 = load i32, ptr %l40, !tbaa !23
  %t1134 = load i32, ptr %l44, !tbaa !23
  %t1135 = load i32, ptr %l42, !tbaa !23
  %t1138 = mul i32 %t1134, %t1135
  %t1141 = add i32 %t1133, %t1138
  %t1143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1143, ptr %l524, !tbaa !29
  %t1144 = load ptr, ptr %l1, !tbaa !29
  %t1146 = getelementptr %"compiler/mir:Fn", ptr %t1144, i32 0, i32 13
  store ptr %t1146, ptr %l526, !tbaa !29
  %t1147 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t1148 = getelementptr %"compiler/mir:Range", ptr %t1147, i32 0, i32 0
  %t1149 = load i32, ptr %t1148, !tbaa !23
  %t1151 = sext i32 %t1149 to i64
  %t1154 = sext i32 %t1141 to i64
  %t1157 = add i64 %t1151, %t1154
  %t1158 = load ptr, ptr %l526, !tbaa !29
  %t1159 = call ptr @__olang_scope_or(ptr %v1, ptr %t1158)
  %t1160 = call ptr @__olang_scope_hold(ptr %t1159)
  %t1161 = ptrtoint ptr %t1160 to i64
  %t1163 = inttoptr i64 %t1161 to ptr
  %t1164 = load ptr, ptr %l526, !tbaa !29
  %t1166 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t1163, ptr %t1164, i64 %t1157)
  store %"compiler/mir:Lvalue" %t1166, ptr %l533
  br label %bb199
bb199:
  %t1167 = load ptr, ptr %l524, !tbaa !29
  %t1168 = load %"compiler/mir:Lvalue", ptr %l533
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v1, ptr %t1167, %"compiler/mir:Lvalue" %t1168)
  br label %bb200
bb200:
  br label %bb201
bb201:
  %t1169 = load i32, ptr %l44, !tbaa !23
  %t1172 = add i32 %t1169, 1
  store i32 %t1172, ptr %l44, !tbaa !23
  br label %bb195
bb202:
  br label %bb203
bb203:
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l537, !tbaa !29
  %t1175 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1176 = load %"compiler/mir:Range", ptr %t1175
  store %"compiler/mir:Range" %t1176, ptr %l538
  %t1177 = load ptr, ptr %l1, !tbaa !29
  %t1179 = getelementptr %"compiler/mir:Fn", ptr %t1177, i32 0, i32 17
  store ptr %t1179, ptr %l540, !tbaa !29
  %t1180 = load ptr, ptr %l540, !tbaa !29
  %t1181 = call ptr @__olang_scope_or(ptr %v1, ptr %t1180)
  %t1182 = call ptr @__olang_scope_hold(ptr %t1181)
  %t1183 = ptrtoint ptr %t1182 to i64
  %t1185 = inttoptr i64 %t1183 to ptr
  %t1186 = load ptr, ptr %l540, !tbaa !29
  %t1187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %t1185, ptr %t1186)
  store i64 %t1187, ptr %l542
  br label %bb204
bb204:
  %t1188 = load ptr, ptr %l537, !tbaa !29
  %t1189 = load %"compiler/mir:Range", ptr %l538
  %t1190 = load i64, ptr %l542, !tbaa !24
  %t1191 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t1188, %"compiler/mir:Range" %t1189, i64 %t1190, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t1191, ptr %l543
  br label %bb205
bb205:
  %t1192 = load i1, ptr %l543, !tbaa !21
  br i1 %t1192, label %bb206, label %bb207
bb206:
  store i32 0, ptr %l46, !tbaa !23
  %t1193 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1194 = getelementptr %"compiler/mir:Range", ptr %t1193, i32 0, i32 1
  %t1195 = load i32, ptr %t1194, !tbaa !23
  store i32 %t1195, ptr %l47, !tbaa !23
  store i32 1, ptr %l48, !tbaa !23
  %t1197 = load i32, ptr %l47, !tbaa !23
  %t1198 = load i32, ptr %l46, !tbaa !23
  %t1201 = icmp sgt i32 %t1197, %t1198
  br i1 %t1201, label %bb208, label %bb209
bb207:
  br label %bb224
bb208:
  %t1203 = load i32, ptr %l48, !tbaa !23
  %t1205 = icmp sgt i32 %t1203, 0
  br i1 %t1205, label %bb210, label %bb211
bb209:
  store i32 0, ptr %l548, !tbaa !23
  br label %bb213
bb210:
  %t1207 = load i32, ptr %l47, !tbaa !23
  %t1208 = load i32, ptr %l46, !tbaa !23
  %t1211 = sub i32 %t1207, %t1208
  %t1212 = load i32, ptr %l48, !tbaa !23
  %t1215 = add i32 %t1211, %t1212
  %t1217 = sub i32 %t1215, 1
  %t1218 = load i32, ptr %l48, !tbaa !23
  %t1221 = sdiv i32 %t1217, %t1218
  store i32 %t1221, ptr %l551, !tbaa !23
  br label %bb212
bb211:
  store i32 0, ptr %l551, !tbaa !23
  br label %bb212
bb212:
  %t1223 = load i32, ptr %l551, !tbaa !23
  store i32 %t1223, ptr %l548, !tbaa !23
  br label %bb213
bb213:
  %t1224 = load i32, ptr %l548, !tbaa !23
  store i32 %t1224, ptr %l49, !tbaa !23
  store i32 0, ptr %l50, !tbaa !23
  br label %bb214
bb214:
  store %olang.scope zeroinitializer, ptr %s47
  %t1225 = load i32, ptr %l50, !tbaa !23
  %t1226 = load i32, ptr %l49, !tbaa !23
  %t1229 = icmp slt i32 %t1225, %t1226
  %t1231 = xor i1 %t1229, true
  br i1 %t1231, label %bb215, label %bb216
bb215:
  call void @__olang_scope_close(ptr %s47)
  br label %bb223
bb216:
  br label %bb217
bb217:
  %t1233 = load i32, ptr %l46, !tbaa !23
  %t1234 = load i32, ptr %l50, !tbaa !23
  %t1235 = load i32, ptr %l48, !tbaa !23
  %t1238 = mul i32 %t1234, %t1235
  %t1241 = add i32 %t1233, %t1238
  %t1243 = load ptr, ptr %l1, !tbaa !29
  %t1245 = getelementptr %"compiler/mir:Fn", ptr %t1243, i32 0, i32 17
  store ptr %t1245, ptr %l570, !tbaa !29
  %t1246 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1247 = getelementptr %"compiler/mir:Range", ptr %t1246, i32 0, i32 0
  %t1248 = load i32, ptr %t1247, !tbaa !23
  %t1250 = sext i32 %t1248 to i64
  %t1253 = sext i32 %t1241 to i64
  %t1256 = add i64 %t1250, %t1253
  %t1257 = load ptr, ptr %l570, !tbaa !29
  %t1258 = call ptr @__olang_scope_or(ptr %v1, ptr %t1257)
  %t1259 = call ptr @__olang_scope_hold(ptr %t1258)
  %t1260 = ptrtoint ptr %t1259 to i64
  %t1262 = inttoptr i64 %t1260 to ptr
  %t1263 = load ptr, ptr %l570, !tbaa !29
  %t1265 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t1262, ptr %t1263, i64 %t1256)
  store %"compiler/mir:TaskClause" %t1265, ptr %l577
  br label %bb218
bb218:
  %t1266 = load %"compiler/mir:TaskClause", ptr %l577
  store %"compiler/mir:TaskClause" %t1266, ptr %l52
  %t1267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1267, ptr %l578, !tbaa !29
  %t1268 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 0
  %t1269 = load %"compiler/mir:Range", ptr %t1268
  store %"compiler/mir:Range" %t1269, ptr %l579
  %t1270 = load ptr, ptr %l1, !tbaa !29
  %t1272 = getelementptr %"compiler/mir:Fn", ptr %t1270, i32 0, i32 18
  store ptr %t1272, ptr %l581, !tbaa !29
  %t1273 = load ptr, ptr %l581, !tbaa !29
  %t1274 = call ptr @__olang_scope_or(ptr %v1, ptr %t1273)
  %t1275 = call ptr @__olang_scope_hold(ptr %t1274)
  %t1276 = ptrtoint ptr %t1275 to i64
  %t1278 = inttoptr i64 %t1276 to ptr
  %t1279 = load ptr, ptr %l581, !tbaa !29
  %t1280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %t1278, ptr %t1279)
  store i64 %t1280, ptr %l583
  br label %bb219
bb219:
  %t1281 = load ptr, ptr %l578, !tbaa !29
  %t1282 = load %"compiler/mir:Range", ptr %l579
  %t1283 = load i64, ptr %l583, !tbaa !24
  %t1284 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s47, ptr %t1281, %"compiler/mir:Range" %t1282, i64 %t1283, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t1284, ptr %l584
  br label %bb220
bb220:
  %t1285 = load ptr, ptr %l0, !tbaa !29
  %t1286 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 2
  %t1287 = load { i64, [4 x i64] }, ptr %t1286
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t1285, { i64, [4 x i64] } %t1287)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s47)
  br label %bb222
bb222:
  %t1290 = load i32, ptr %l50, !tbaa !23
  %t1293 = add i32 %t1290, 1
  store i32 %t1293, ptr %l50, !tbaa !23
  br label %bb214
bb223:
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s38)
  br label %bb225
bb225:
  %t1295 = load i64, ptr %l38, !tbaa !24
  %t1298 = add i64 %t1295, 1
  store i64 %t1298, ptr %l38, !tbaa !24
  br label %bb162
bb226:
  %t1300 = load ptr, ptr %l1, !tbaa !29
  %t1302 = getelementptr %"compiler/mir:Fn", ptr %t1300, i32 0, i32 11
  store ptr %t1302, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb227
bb227:
  %t1304 = load i64, ptr %l54, !tbaa !24
  store i64 %t1304, ptr %l595, !tbaa !24
  %t1305 = load ptr, ptr %l53, !tbaa !29
  store ptr %t1305, ptr %l596, !tbaa !29
  %t1306 = load ptr, ptr %l596, !tbaa !29
  %t1307 = call ptr @__olang_scope_or(ptr %v1, ptr %t1306)
  %t1308 = call ptr @__olang_scope_hold(ptr %t1307)
  %t1309 = ptrtoint ptr %t1308 to i64
  %t1311 = inttoptr i64 %t1309 to ptr
  %t1312 = load ptr, ptr %l596, !tbaa !29
  %t1313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %t1311, ptr %t1312)
  store i64 %t1313, ptr %l598
  br label %bb228
bb228:
  %t1314 = load i64, ptr %l595, !tbaa !24
  %t1315 = load i64, ptr %l598, !tbaa !24
  %t1316 = icmp slt i64 %t1314, %t1315
  %t1318 = xor i1 %t1316, true
  br i1 %t1318, label %bb229, label %bb230
bb229:
  br label %bb235
bb230:
  br label %bb231
bb231:
  %t1320 = load ptr, ptr %l53, !tbaa !29
  store ptr %t1320, ptr %l601, !tbaa !29
  %t1321 = load i64, ptr %l54, !tbaa !24
  %t1322 = load ptr, ptr %l601, !tbaa !29
  %t1323 = call ptr @__olang_scope_or(ptr %v1, ptr %t1322)
  %t1324 = call ptr @__olang_scope_hold(ptr %t1323)
  %t1325 = ptrtoint ptr %t1324 to i64
  %t1327 = inttoptr i64 %t1325 to ptr
  %t1328 = load ptr, ptr %l601, !tbaa !29
  %t1330 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t1327, ptr %t1328, i64 %t1321)
  store { i64, [4 x i64] } %t1330, ptr %l604
  br label %bb232
bb232:
  %t1331 = load { i64, [4 x i64] }, ptr %l604
  %t1332 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t1332, { i64, [4 x i64] } %t1331)
  br label %bb233
bb233:
  br label %bb234
bb234:
  %t1336 = load i64, ptr %l54, !tbaa !24
  %t1339 = add i64 %t1336, 1
  store i64 %t1339, ptr %l54, !tbaa !24
  br label %bb227
bb235:
  %t1341 = load ptr, ptr %l1, !tbaa !29
  %t1343 = getelementptr %"compiler/mir:Fn", ptr %t1341, i32 0, i32 12
  store ptr %t1343, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb236
bb236:
  %t1345 = load i64, ptr %l57, !tbaa !24
  store i64 %t1345, ptr %l612, !tbaa !24
  %t1346 = load ptr, ptr %l56, !tbaa !29
  store ptr %t1346, ptr %l613, !tbaa !29
  %t1347 = load ptr, ptr %l613, !tbaa !29
  %t1348 = call ptr @__olang_scope_or(ptr %v1, ptr %t1347)
  %t1349 = call ptr @__olang_scope_hold(ptr %t1348)
  %t1350 = ptrtoint ptr %t1349 to i64
  %t1352 = inttoptr i64 %t1350 to ptr
  %t1353 = load ptr, ptr %l613, !tbaa !29
  %t1354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1352, ptr %t1353)
  store i64 %t1354, ptr %l615
  br label %bb237
bb237:
  %t1355 = load i64, ptr %l612, !tbaa !24
  %t1356 = load i64, ptr %l615, !tbaa !24
  %t1357 = icmp slt i64 %t1355, %t1356
  %t1359 = xor i1 %t1357, true
  br i1 %t1359, label %bb238, label %bb239
bb238:
  br label %bb244
bb239:
  br label %bb240
bb240:
  %t1361 = load ptr, ptr %l56, !tbaa !29
  store ptr %t1361, ptr %l618, !tbaa !29
  %t1362 = load i64, ptr %l57, !tbaa !24
  %t1363 = load ptr, ptr %l618, !tbaa !29
  %t1364 = call ptr @__olang_scope_or(ptr %v1, ptr %t1363)
  %t1365 = call ptr @__olang_scope_hold(ptr %t1364)
  %t1366 = ptrtoint ptr %t1365 to i64
  %t1368 = inttoptr i64 %t1366 to ptr
  %t1369 = load ptr, ptr %l618, !tbaa !29
  %t1371 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1368, ptr %t1369, i64 %t1362)
  store { i64, [1 x i64] } %t1371, ptr %l621
  br label %bb241
bb241:
  %t1372 = load { i64, [1 x i64] }, ptr %l621
  %t1373 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %v1, ptr %t1373, { i64, [1 x i64] } %t1372)
  br label %bb242
bb242:
  br label %bb243
bb243:
  %t1377 = load i64, ptr %l57, !tbaa !24
  %t1380 = add i64 %t1377, 1
  store i64 %t1380, ptr %l57, !tbaa !24
  br label %bb236
bb244:
  %t1382 = load ptr, ptr %l1, !tbaa !29
  %t1384 = getelementptr %"compiler/mir:Fn", ptr %t1382, i32 0, i32 10
  store ptr %t1384, ptr %l59, !tbaa !29
  store i64 0, ptr %l60, !tbaa !24
  br label %bb245
bb245:
  %t1386 = load i64, ptr %l60, !tbaa !24
  store i64 %t1386, ptr %l629, !tbaa !24
  %t1387 = load ptr, ptr %l59, !tbaa !29
  store ptr %t1387, ptr %l630, !tbaa !29
  %t1388 = load ptr, ptr %l630, !tbaa !29
  %t1389 = call ptr @__olang_scope_or(ptr %v1, ptr %t1388)
  %t1390 = call ptr @__olang_scope_hold(ptr %t1389)
  %t1391 = ptrtoint ptr %t1390 to i64
  %t1393 = inttoptr i64 %t1391 to ptr
  %t1394 = load ptr, ptr %l630, !tbaa !29
  %t1395 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %t1393, ptr %t1394)
  store i64 %t1395, ptr %l632
  br label %bb246
bb246:
  %t1396 = load i64, ptr %l629, !tbaa !24
  %t1397 = load i64, ptr %l632, !tbaa !24
  %t1398 = icmp slt i64 %t1396, %t1397
  %t1400 = xor i1 %t1398, true
  br i1 %t1400, label %bb247, label %bb248
bb247:
  br label %bb262
bb248:
  br label %bb249
bb249:
  %t1402 = load ptr, ptr %l59, !tbaa !29
  store ptr %t1402, ptr %l635, !tbaa !29
  %t1403 = load i64, ptr %l60, !tbaa !24
  %t1404 = load ptr, ptr %l635, !tbaa !29
  %t1405 = call ptr @__olang_scope_or(ptr %v1, ptr %t1404)
  %t1406 = call ptr @__olang_scope_hold(ptr %t1405)
  %t1407 = ptrtoint ptr %t1406 to i64
  %t1409 = inttoptr i64 %t1407 to ptr
  %t1410 = load ptr, ptr %l635, !tbaa !29
  %t1412 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t1409, ptr %t1410, i64 %t1403)
  store { i64, [1 x i64] } %t1412, ptr %l638
  br label %bb250
bb250:
  %t1413 = load { i64, [1 x i64] }, ptr %l638
  store { i64, [1 x i64] } %t1413, ptr %l61
  %t1414 = load { i64, [1 x i64] }, ptr %l61
  %t1416 = extractvalue { i64, [1 x i64] } %t1414, 0
  %t1417 = icmp eq i64 %t1416, 1
  br i1 %t1417, label %bb251, label %bb252
bb251:
  %t1419 = getelementptr { i64, [1 x i64] }, ptr %l61, i32 0, i32 1
  %t1420 = getelementptr { i32 }, ptr %t1419, i32 0, i32 0
  %t1421 = load i32, ptr %t1420
  store i32 %t1421, ptr %l62, !tbaa !23
  br label %bb253
bb252:
  br label %bb255
bb253:
  %t1423 = load ptr, ptr %l0, !tbaa !29
  %t1424 = load i32, ptr %l62, !tbaa !23
  %t1427 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %t1423, i32 %t1424)
  store i1 %t1427, ptr %l644
  br label %bb254
bb254:
  br label %bb260
bb255:
  br i1 true, label %bb256, label %bb257
bb256:
  br label %bb258
bb257:
  br label %bb259
bb258:
  br label %bb260
bb259:
  call void @__olang_check_failed(ptr @olang_loc_729af306d1a375bd_3b9d78bce782a851)
  unreachable
bb260:
  br label %bb261
bb261:
  %t1428 = load i64, ptr %l60, !tbaa !24
  %t1431 = add i64 %t1428, 1
  store i64 %t1431, ptr %l60, !tbaa !24
  br label %bb245
bb262:
  store i64 0, ptr %l63, !tbaa !24
  %t1433 = load ptr, ptr %l1, !tbaa !29
  %t1435 = getelementptr %"compiler/mir:Fn", ptr %t1433, i32 0, i32 19
  store ptr %t1435, ptr %l649, !tbaa !29
  %t1436 = load ptr, ptr %l649, !tbaa !29
  %t1437 = call ptr @__olang_scope_or(ptr %v1, ptr %t1436)
  %t1438 = call ptr @__olang_scope_hold(ptr %t1437)
  %t1439 = ptrtoint ptr %t1438 to i64
  %t1441 = inttoptr i64 %t1439 to ptr
  %t1442 = load ptr, ptr %l649, !tbaa !29
  %t1443 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %t1441, ptr %t1442)
  store i64 %t1443, ptr %l651
  br label %bb263
bb263:
  %t1444 = load i64, ptr %l651, !tbaa !24
  store i64 %t1444, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t1445 = load i64, ptr %l64, !tbaa !24
  %t1446 = load i64, ptr %l63, !tbaa !24
  %t1449 = icmp sgt i64 %t1445, %t1446
  br i1 %t1449, label %bb264, label %bb265
bb264:
  %t1451 = load i64, ptr %l65, !tbaa !24
  %t1453 = icmp sgt i64 %t1451, 0
  br i1 %t1453, label %bb266, label %bb267
bb265:
  store i64 0, ptr %l655, !tbaa !24
  br label %bb269
bb266:
  %t1455 = load i64, ptr %l64, !tbaa !24
  %t1456 = load i64, ptr %l63, !tbaa !24
  %t1459 = sub i64 %t1455, %t1456
  %t1460 = load i64, ptr %l65, !tbaa !24
  %t1463 = add i64 %t1459, %t1460
  %t1465 = sub i64 %t1463, 1
  %t1466 = load i64, ptr %l65, !tbaa !24
  %t1469 = sdiv i64 %t1465, %t1466
  store i64 %t1469, ptr %l658, !tbaa !24
  br label %bb268
bb267:
  store i64 0, ptr %l658, !tbaa !24
  br label %bb268
bb268:
  %t1471 = load i64, ptr %l658, !tbaa !24
  store i64 %t1471, ptr %l655, !tbaa !24
  br label %bb269
bb269:
  %t1472 = load i64, ptr %l655, !tbaa !24
  store i64 %t1472, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb270
bb270:
  %t1473 = load i64, ptr %l67, !tbaa !24
  %t1474 = load i64, ptr %l66, !tbaa !24
  %t1477 = icmp slt i64 %t1473, %t1474
  %t1479 = xor i1 %t1477, true
  br i1 %t1479, label %bb271, label %bb272
bb271:
  br label %bb297
bb272:
  br label %bb273
bb273:
  %t1481 = load i64, ptr %l63, !tbaa !24
  %t1482 = load i64, ptr %l67, !tbaa !24
  %t1483 = load i64, ptr %l65, !tbaa !24
  %t1486 = mul i64 %t1482, %t1483
  %t1489 = add i64 %t1481, %t1486
  store i64 %t1489, ptr %l68, !tbaa !24
  %t1491 = load ptr, ptr %l1, !tbaa !29
  %t1493 = getelementptr %"compiler/mir:Fn", ptr %t1491, i32 0, i32 19
  store ptr %t1493, ptr %l677, !tbaa !29
  %t1494 = load i64, ptr %l68, !tbaa !24
  %t1495 = load ptr, ptr %l677, !tbaa !29
  %t1496 = call ptr @__olang_scope_or(ptr %v1, ptr %t1495)
  %t1497 = call ptr @__olang_scope_hold(ptr %t1496)
  %t1498 = ptrtoint ptr %t1497 to i64
  %t1500 = inttoptr i64 %t1498 to ptr
  %t1501 = load ptr, ptr %l677, !tbaa !29
  %t1503 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %t1500, ptr %t1501, i64 %t1494)
  store { i64, [1 x i64] } %t1503, ptr %l680
  br label %bb274
bb274:
  %t1504 = load { i64, [1 x i64] }, ptr %l680
  store { i64, [1 x i64] } %t1504, ptr %l69
  %t1505 = load { i64, [1 x i64] }, ptr %l69
  %t1507 = extractvalue { i64, [1 x i64] } %t1505, 0
  %t1508 = icmp eq i64 %t1507, 1
  br i1 %t1508, label %bb275, label %bb276
bb275:
  %t1510 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1511 = getelementptr { %"compiler/mir:Range" }, ptr %t1510, i32 0, i32 0
  %t1512 = load %"compiler/mir:Range", ptr %t1511
  store %"compiler/mir:Range" %t1512, ptr %l70
  br label %bb277
bb276:
  br label %bb280
bb277:
  store %olang.scope zeroinitializer, ptr %s63
  %t1514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1514, ptr %l684, !tbaa !29
  %t1515 = load %"compiler/mir:Range", ptr %l70
  store %"compiler/mir:Range" %t1515, ptr %l685
  %t1516 = load ptr, ptr %l1, !tbaa !29
  %t1518 = getelementptr %"compiler/mir:Fn", ptr %t1516, i32 0, i32 21
  store ptr %t1518, ptr %l687, !tbaa !29
  %t1519 = load ptr, ptr %l687, !tbaa !29
  %t1520 = call ptr @__olang_scope_or(ptr %v1, ptr %t1519)
  %t1521 = call ptr @__olang_scope_hold(ptr %t1520)
  %t1522 = ptrtoint ptr %t1521 to i64
  %t1524 = inttoptr i64 %t1522 to ptr
  %t1525 = load ptr, ptr %l687, !tbaa !29
  %t1526 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %t1524, ptr %t1525)
  store i64 %t1526, ptr %l689
  br label %bb278
bb278:
  %t1527 = load ptr, ptr %l684, !tbaa !29
  %t1528 = load %"compiler/mir:Range", ptr %l685
  %t1529 = load i64, ptr %l689, !tbaa !24
  %t1530 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s63, ptr %t1527, %"compiler/mir:Range" %t1528, i64 %t1529, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t1530, ptr %l690
  br label %bb279
bb279:
  call void @__olang_scope_close(ptr %s63)
  br label %bb295
bb280:
  %t1531 = load { i64, [1 x i64] }, ptr %l69
  %t1533 = extractvalue { i64, [1 x i64] } %t1531, 0
  %t1534 = icmp eq i64 %t1533, 2
  br i1 %t1534, label %bb281, label %bb282
bb281:
  %t1536 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1537 = getelementptr { %"compiler/mir:Range" }, ptr %t1536, i32 0, i32 0
  %t1538 = load %"compiler/mir:Range", ptr %t1537
  store %"compiler/mir:Range" %t1538, ptr %l71
  br label %bb283
bb282:
  br label %bb290
bb283:
  store %olang.scope zeroinitializer, ptr %s64
  %t1540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1540, ptr %l694, !tbaa !29
  %t1541 = load %"compiler/mir:Range", ptr %l71
  store %"compiler/mir:Range" %t1541, ptr %l695
  %t1542 = load ptr, ptr %l1, !tbaa !29
  %t1544 = getelementptr %"compiler/mir:Fn", ptr %t1542, i32 0, i32 20
  store ptr %t1544, ptr %l697, !tbaa !29
  %t1545 = load ptr, ptr %l697, !tbaa !29
  %t1546 = call ptr @__olang_scope_or(ptr %v1, ptr %t1545)
  %t1547 = call ptr @__olang_scope_hold(ptr %t1546)
  %t1548 = ptrtoint ptr %t1547 to i64
  %t1550 = inttoptr i64 %t1548 to ptr
  %t1551 = load ptr, ptr %l697, !tbaa !29
  %t1552 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %t1550, ptr %t1551)
  store i64 %t1552, ptr %l699
  br label %bb284
bb284:
  %t1553 = load ptr, ptr %l694, !tbaa !29
  %t1554 = load %"compiler/mir:Range", ptr %l695
  %t1555 = load i64, ptr %l699, !tbaa !24
  %t1556 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s64, ptr %t1553, %"compiler/mir:Range" %t1554, i64 %t1555, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store i1 %t1556, ptr %l700
  br label %bb285
bb285:
  %t1557 = load i1, ptr %l700, !tbaa !21
  br i1 %t1557, label %bb286, label %bb287
bb286:
  %t1558 = load ptr, ptr %l0, !tbaa !29
  %t1559 = load %"compiler/mir:Range", ptr %l71
  %t1560 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %v1, ptr %t1558, %"compiler/mir:Range" %t1559, i64 %t1560)
  br label %bb288
bb287:
  br label %bb289
bb288:
  br label %bb289
bb289:
  call void @__olang_scope_close(ptr %s64)
  br label %bb295
bb290:
  br i1 true, label %bb291, label %bb292
bb291:
  br label %bb293
bb292:
  br label %bb294
bb293:
  br label %bb295
bb294:
  call void @__olang_check_failed(ptr @olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0)
  unreachable
bb295:
  br label %bb296
bb296:
  %t1564 = load i64, ptr %l67, !tbaa !24
  %t1567 = add i64 %t1564, 1
  store i64 %t1567, ptr %l67, !tbaa !24
  br label %bb270
bb297:
  store i64 0, ptr %l72, !tbaa !24
  %t1569 = load ptr, ptr %l1, !tbaa !29
  %t1571 = getelementptr %"compiler/mir:Fn", ptr %t1569, i32 0, i32 9
  store ptr %t1571, ptr %l708, !tbaa !29
  %t1572 = load ptr, ptr %l708, !tbaa !29
  %t1573 = call ptr @__olang_scope_or(ptr %v1, ptr %t1572)
  %t1574 = call ptr @__olang_scope_hold(ptr %t1573)
  %t1575 = ptrtoint ptr %t1574 to i64
  %t1577 = inttoptr i64 %t1575 to ptr
  %t1578 = load ptr, ptr %l708, !tbaa !29
  %t1579 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t1577, ptr %t1578)
  store i64 %t1579, ptr %l710
  br label %bb298
bb298:
  %t1580 = load i64, ptr %l710, !tbaa !24
  store i64 %t1580, ptr %l73, !tbaa !24
  store i64 1, ptr %l74, !tbaa !24
  %t1581 = load i64, ptr %l73, !tbaa !24
  %t1582 = load i64, ptr %l72, !tbaa !24
  %t1585 = icmp sgt i64 %t1581, %t1582
  br i1 %t1585, label %bb299, label %bb300
bb299:
  %t1587 = load i64, ptr %l74, !tbaa !24
  %t1589 = icmp sgt i64 %t1587, 0
  br i1 %t1589, label %bb301, label %bb302
bb300:
  store i64 0, ptr %l714, !tbaa !24
  br label %bb304
bb301:
  %t1591 = load i64, ptr %l73, !tbaa !24
  %t1592 = load i64, ptr %l72, !tbaa !24
  %t1595 = sub i64 %t1591, %t1592
  %t1596 = load i64, ptr %l74, !tbaa !24
  %t1599 = add i64 %t1595, %t1596
  %t1601 = sub i64 %t1599, 1
  %t1602 = load i64, ptr %l74, !tbaa !24
  %t1605 = sdiv i64 %t1601, %t1602
  store i64 %t1605, ptr %l717, !tbaa !24
  br label %bb303
bb302:
  store i64 0, ptr %l717, !tbaa !24
  br label %bb303
bb303:
  %t1607 = load i64, ptr %l717, !tbaa !24
  store i64 %t1607, ptr %l714, !tbaa !24
  br label %bb304
bb304:
  %t1608 = load i64, ptr %l714, !tbaa !24
  store i64 %t1608, ptr %l75, !tbaa !24
  store i64 0, ptr %l76, !tbaa !24
  br label %bb305
bb305:
  %t1609 = load i64, ptr %l76, !tbaa !24
  %t1610 = load i64, ptr %l75, !tbaa !24
  %t1613 = icmp slt i64 %t1609, %t1610
  %t1615 = xor i1 %t1613, true
  br i1 %t1615, label %bb306, label %bb307
bb306:
  br label %bb327
bb307:
  br label %bb308
bb308:
  %t1617 = load i64, ptr %l72, !tbaa !24
  %t1618 = load i64, ptr %l76, !tbaa !24
  %t1619 = load i64, ptr %l74, !tbaa !24
  %t1622 = mul i64 %t1618, %t1619
  %t1625 = add i64 %t1617, %t1622
  store i64 %t1625, ptr %l77, !tbaa !24
  %t1627 = load ptr, ptr %l0, !tbaa !29
  %t1628 = load i64, ptr %l77, !tbaa !24
  %t1631 = getelementptr %"compiler/mir:verifier", ptr %t1627, i32 0, i32 3
  store i64 %t1628, ptr %t1631, !tbaa !24
  %t1632 = load ptr, ptr %l1, !tbaa !29
  %t1634 = getelementptr %"compiler/mir:Fn", ptr %t1632, i32 0, i32 9
  store ptr %t1634, ptr %l738, !tbaa !29
  %t1635 = load i64, ptr %l77, !tbaa !24
  %t1636 = load ptr, ptr %l738, !tbaa !29
  %t1637 = call ptr @__olang_scope_or(ptr %v1, ptr %t1636)
  %t1638 = call ptr @__olang_scope_hold(ptr %t1637)
  %t1639 = ptrtoint ptr %t1638 to i64
  %t1640 = load ptr, ptr %l0, !tbaa !29
  %t1642 = getelementptr %"compiler/mir:verifier", ptr %t1640, i32 0, i32 0
  %t1643 = load ptr, ptr %t1642, !tbaa !29
  %t1645 = call ptr @__olang_scope_or(ptr %v1, ptr %t1643)
  %t1646 = call ptr @__olang_scope_hold(ptr %t1645)
  %t1647 = ptrtoint ptr %t1646 to i64
  %t1649 = inttoptr i64 %t1639 to ptr
  %t1651 = inttoptr i64 %t1647 to ptr
  %t1652 = load ptr, ptr %l738, !tbaa !29
  %t1654 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t1649, ptr %t1651, ptr %t1652, i64 %t1635)
  store ptr %t1654, ptr %l744
  br label %bb309
bb309:
  %t1655 = load ptr, ptr %l744, !tbaa !29
  store ptr %t1655, ptr %l78, !tbaa !29
  store i64 0, ptr %l79, !tbaa !24
  %t1656 = load ptr, ptr %l78, !tbaa !29
  %t1658 = getelementptr %"compiler/mir:BasicBlock", ptr %t1656, i32 0, i32 0
  store ptr %t1658, ptr %l746, !tbaa !29
  %t1659 = load ptr, ptr %l746, !tbaa !29
  %t1660 = call ptr @__olang_scope_or(ptr %v1, ptr %t1659)
  %t1661 = call ptr @__olang_scope_hold(ptr %t1660)
  %t1662 = ptrtoint ptr %t1661 to i64
  %t1664 = inttoptr i64 %t1662 to ptr
  %t1665 = load ptr, ptr %l746, !tbaa !29
  %t1666 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %t1664, ptr %t1665)
  store i64 %t1666, ptr %l748
  br label %bb310
bb310:
  %t1667 = load i64, ptr %l748, !tbaa !24
  store i64 %t1667, ptr %l80, !tbaa !24
  store i64 1, ptr %l81, !tbaa !24
  %t1668 = load i64, ptr %l80, !tbaa !24
  %t1669 = load i64, ptr %l79, !tbaa !24
  %t1672 = icmp sgt i64 %t1668, %t1669
  br i1 %t1672, label %bb311, label %bb312
bb311:
  %t1674 = load i64, ptr %l81, !tbaa !24
  %t1676 = icmp sgt i64 %t1674, 0
  br i1 %t1676, label %bb313, label %bb314
bb312:
  store i64 0, ptr %l752, !tbaa !24
  br label %bb316
bb313:
  %t1678 = load i64, ptr %l80, !tbaa !24
  %t1679 = load i64, ptr %l79, !tbaa !24
  %t1682 = sub i64 %t1678, %t1679
  %t1683 = load i64, ptr %l81, !tbaa !24
  %t1686 = add i64 %t1682, %t1683
  %t1688 = sub i64 %t1686, 1
  %t1689 = load i64, ptr %l81, !tbaa !24
  %t1692 = sdiv i64 %t1688, %t1689
  store i64 %t1692, ptr %l755, !tbaa !24
  br label %bb315
bb314:
  store i64 0, ptr %l755, !tbaa !24
  br label %bb315
bb315:
  %t1694 = load i64, ptr %l755, !tbaa !24
  store i64 %t1694, ptr %l752, !tbaa !24
  br label %bb316
bb316:
  %t1695 = load i64, ptr %l752, !tbaa !24
  store i64 %t1695, ptr %l82, !tbaa !24
  store i64 0, ptr %l83, !tbaa !24
  br label %bb317
bb317:
  store %olang.scope zeroinitializer, ptr %s71
  %t1696 = load i64, ptr %l83, !tbaa !24
  %t1697 = load i64, ptr %l82, !tbaa !24
  %t1700 = icmp slt i64 %t1696, %t1697
  %t1702 = xor i1 %t1700, true
  br i1 %t1702, label %bb318, label %bb319
bb318:
  call void @__olang_scope_close(ptr %s71)
  br label %bb324
bb319:
  br label %bb320
bb320:
  %t1704 = load i64, ptr %l79, !tbaa !24
  %t1705 = load i64, ptr %l83, !tbaa !24
  %t1706 = load i64, ptr %l81, !tbaa !24
  %t1709 = mul i64 %t1705, %t1706
  %t1712 = add i64 %t1704, %t1709
  store i64 %t1712, ptr %l84, !tbaa !24
  %t1714 = load ptr, ptr %l0, !tbaa !29
  %t1715 = load i64, ptr %l84, !tbaa !24
  %t1718 = getelementptr %"compiler/mir:verifier", ptr %t1714, i32 0, i32 4
  store i64 %t1715, ptr %t1718, !tbaa !24
  %t1719 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1719, ptr %l775, !tbaa !29
  %t1720 = load ptr, ptr %l78, !tbaa !29
  %t1722 = getelementptr %"compiler/mir:BasicBlock", ptr %t1720, i32 0, i32 0
  store ptr %t1722, ptr %l777, !tbaa !29
  %t1723 = load i64, ptr %l84, !tbaa !24
  %t1724 = load ptr, ptr %l777, !tbaa !29
  %t1725 = call ptr @__olang_scope_or(ptr %v1, ptr %t1724)
  %t1726 = call ptr @__olang_scope_hold(ptr %t1725)
  %t1727 = ptrtoint ptr %t1726 to i64
  %t1729 = inttoptr i64 %t1727 to ptr
  %t1730 = load ptr, ptr %l777, !tbaa !29
  %t1732 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t1729, ptr %t1730, i64 %t1723)
  store { i64, [21 x i64] } %t1732, ptr %l780
  br label %bb321
bb321:
  %t1733 = load { i64, [21 x i64] }, ptr %l780
  %t1734 = call ptr @__olang_scope_alloc_a(ptr %s71, i64 176, i64 8)
  store { i64, [21 x i64] } %t1733, ptr %t1734
  %t1735 = load ptr, ptr %l775, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %s71, ptr %v1, ptr %t1735, ptr %t1734)
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s71)
  br label %bb323
bb323:
  %t1737 = load i64, ptr %l83, !tbaa !24
  %t1740 = add i64 %t1737, 1
  store i64 %t1740, ptr %l83, !tbaa !24
  br label %bb317
bb324:
  %t1742 = load ptr, ptr %l0, !tbaa !29
  %t1744 = getelementptr %"compiler/mir:verifier", ptr %t1742, i32 0, i32 4
  store i64 -1, ptr %t1744, !tbaa !24
  %t1745 = load ptr, ptr %l0, !tbaa !29
  %t1746 = load ptr, ptr %l78, !tbaa !29
  %t1748 = getelementptr %"compiler/mir:BasicBlock", ptr %t1746, i32 0, i32 1
  %t1749 = load { i64, [8 x i64] }, ptr %t1748
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %v1, ptr %t1745, { i64, [8 x i64] } %t1749)
  br label %bb325
bb325:
  br label %bb326
bb326:
  %t1752 = load i64, ptr %l76, !tbaa !24
  %t1755 = add i64 %t1752, 1
  store i64 %t1755, ptr %l76, !tbaa !24
  br label %bb305
bb327:
  %t1757 = load ptr, ptr %l0, !tbaa !29
  %t1761 = getelementptr %"compiler/mir:verifier", ptr %t1757, i32 0, i32 3
  store i64 -1, ptr %t1761, !tbaa !24
  %t1762 = load ptr, ptr %l0, !tbaa !29
  %t1766 = getelementptr %"compiler/mir:verifier", ptr %t1762, i32 0, i32 4
  store i64 -1, ptr %t1766, !tbaa !24
  %t1767 = load ptr, ptr %l0, !tbaa !29
  %t1769 = getelementptr %"compiler/mir:verifier", ptr %t1767, i32 0, i32 2
  %t1771 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1769)
  store i64 %t1771, ptr %l798
  br label %bb328
bb328:
  %t1772 = load i64, ptr %l2, !tbaa !24
  %t1773 = load i64, ptr %l798, !tbaa !24
  %t1775 = icmp eq i64 %t1773, %t1772
  store i1 %t1775, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca %"compiler/mir:Lvalue"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca %"compiler/mir:Range"
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l110 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l160 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i64
  %l168 = alloca ptr
  %l170 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l226 = alloca i1
  %l232 = alloca i1
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t2 = load ptr, ptr %l26, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l26, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 20}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l27, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l27, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v2, ptr %t22, %"compiler/mir:Lvalue" %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [15 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %v2, ptr %t26, { i64, [15 x i64] } %t27)
  br label %bb7
bb7:
  br label %bb145
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t31 = load ptr, ptr %l38, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 20}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t46 = load ptr, ptr %l44, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l44, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 20}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l45, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v2, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l52
  br label %bb18
bb18:
  br label %bb145
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t66 = load ptr, ptr %l53, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l53, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 20}
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l54, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l54, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32 }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t81 = load ptr, ptr %l59, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 20}
  %t87 = icmp eq i64 %t85, 4
  store i1 %t87, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l60, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l5, !tbaa !23
  %t99 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %v2, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l67
  br label %bb29
bb29:
  br label %bb145
bb30:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t101 = load ptr, ptr %l68, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l68, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 20}
  %t107 = icmp eq i64 %t105, 5
  store i1 %t107, ptr %l69, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l69, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [21 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 1
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l6
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t117, i32 0, i32 3
  %t119 = load { i64, [4 x i64] }, ptr %t118
  store { i64, [4 x i64] } %t119, ptr %l7
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %v2, ptr %t121, { i64, [1 x i64] } %t122)
  br label %bb36
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t125, { i64, [4 x i64] } %t126)
  br label %bb37
bb37:
  br label %bb145
bb38:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t130 = load ptr, ptr %l80, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l80, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 20}
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l81, !tbaa !21
  br label %bb40
bb40:
  %t137 = load i1, ptr %l81, !tbaa !21
  br i1 %t137, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [21 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t140, i32 0, i32 1
  %t142 = load %"compiler/mir:Lvalue", ptr %t141
  store %"compiler/mir:Lvalue" %t142, ptr %l8
  br label %bb51
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t145 = load ptr, ptr %l86, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l86, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 20}
  %t151 = icmp eq i64 %t149, 7
  store i1 %t151, ptr %l87, !tbaa !21
  br label %bb44
bb44:
  %t152 = load i1, ptr %l87, !tbaa !21
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [21 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t155, i32 0, i32 1
  %t157 = load %"compiler/mir:Lvalue", ptr %t156
  store %"compiler/mir:Lvalue" %t157, ptr %l8
  br label %bb51
bb46:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t160 = load ptr, ptr %l92, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t163 = load ptr, ptr %l92, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 20}
  %t166 = icmp eq i64 %t164, 8
  store i1 %t166, ptr %l93, !tbaa !21
  br label %bb48
bb48:
  %t167 = load i1, ptr %l93, !tbaa !21
  br i1 %t167, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [21 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t170, i32 0, i32 1
  %t172 = load %"compiler/mir:Lvalue", ptr %t171
  store %"compiler/mir:Lvalue" %t172, ptr %l8
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Lvalue", ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v2, ptr %t174, %"compiler/mir:Lvalue" %t175)
  br label %bb52
bb52:
  br label %bb145
bb53:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t179 = load ptr, ptr %l100, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb54, label %bb55
bb54:
  %t182 = load ptr, ptr %l100, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 20}
  %t185 = icmp eq i64 %t183, 9
  store i1 %t185, ptr %l101, !tbaa !21
  br label %bb55
bb55:
  %t186 = load i1, ptr %l101, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t189, i32 0, i32 1
  %t191 = load i32, ptr %t190
  store i32 %t191, ptr %l9, !tbaa !23
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [21 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t195, i32 0, i32 2
  %t197 = load %"compiler/mir:Lvalue", ptr %t196
  store %"compiler/mir:Lvalue" %t197, ptr %l10
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l9, !tbaa !23
  %t203 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v2, ptr %t199, i32 %t200)
  store i1 %t203, ptr %l110
  br label %bb59
bb59:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v2, ptr %t204, %"compiler/mir:Lvalue" %t205)
  br label %bb60
bb60:
  br label %bb145
bb61:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t209 = load ptr, ptr %l113, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb62, label %bb63
bb62:
  %t212 = load ptr, ptr %l113, !tbaa !29
  %t213 = load i64, ptr %t212, !range !{i64 0, i64 20}
  %t215 = icmp eq i64 %t213, 10
  store i1 %t215, ptr %l114, !tbaa !21
  br label %bb63
bb63:
  %t216 = load i1, ptr %l114, !tbaa !21
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [21 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32 }, ptr %t219, i32 0, i32 1
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l11, !tbaa !23
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l11, !tbaa !23
  %t227 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v2, ptr %t223, i32 %t224)
  store i1 %t227, ptr %l121
  br label %bb67
bb67:
  br label %bb145
bb68:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t229 = load ptr, ptr %l122, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb69, label %bb70
bb69:
  %t232 = load ptr, ptr %l122, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 20}
  %t235 = icmp eq i64 %t233, 11
  store i1 %t235, ptr %l123, !tbaa !21
  br label %bb70
bb70:
  %t236 = load i1, ptr %l123, !tbaa !21
  br i1 %t236, label %bb71, label %bb72
bb71:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [21 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t239, i32 0, i32 1
  %t241 = load { i64, [1 x i64] }, ptr %t240
  store { i64, [1 x i64] } %t241, ptr %l12
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr { i64, [21 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t245, i32 0, i32 3
  %t247 = load { i64, [4 x i64] }, ptr %t246
  store { i64, [4 x i64] } %t247, ptr %l13
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load { i64, [1 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %v2, ptr %t249, { i64, [1 x i64] } %t250)
  br label %bb74
bb74:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, [4 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t253, { i64, [4 x i64] } %t254)
  br label %bb75
bb75:
  br label %bb145
bb76:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t258 = load ptr, ptr %l134, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb77, label %bb78
bb77:
  %t261 = load ptr, ptr %l134, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 20}
  %t264 = icmp eq i64 %t262, 12
  store i1 %t264, ptr %l135, !tbaa !21
  br label %bb78
bb78:
  %t265 = load i1, ptr %l135, !tbaa !21
  br i1 %t265, label %bb79, label %bb80
bb79:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [21 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t268, i32 0, i32 1
  %t270 = load %"compiler/mir:Lvalue", ptr %t269
  store %"compiler/mir:Lvalue" %t270, ptr %l14
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [21 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t274, i32 0, i32 2
  %t276 = load %"compiler/mir:Lvalue", ptr %t275
  store %"compiler/mir:Lvalue" %t276, ptr %l15
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [21 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t280, i32 0, i32 3
  %t282 = load { i64, [4 x i64] }, ptr %t281
  store { i64, [4 x i64] } %t282, ptr %l16
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/mir:Lvalue", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v2, ptr %t284, %"compiler/mir:Lvalue" %t285)
  br label %bb82
bb82:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load %"compiler/mir:Lvalue", ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v2, ptr %t288, %"compiler/mir:Lvalue" %t289)
  br label %bb83
bb83:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, [4 x i64] }, ptr %l16
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t292, { i64, [4 x i64] } %t293)
  br label %bb84
bb84:
  br label %bb145
bb85:
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t297 = load ptr, ptr %l150, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  br i1 %t298, label %bb86, label %bb87
bb86:
  %t300 = load ptr, ptr %l150, !tbaa !29
  %t301 = load i64, ptr %t300, !range !{i64 0, i64 20}
  %t303 = icmp eq i64 %t301, 13
  store i1 %t303, ptr %l151, !tbaa !21
  br label %bb87
bb87:
  %t304 = load i1, ptr %l151, !tbaa !21
  br i1 %t304, label %bb88, label %bb89
bb88:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [21 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t307, i32 0, i32 1
  %t309 = load i32, ptr %t308
  store i32 %t309, ptr %l17, !tbaa !23
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [21 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t313, i32 0, i32 2
  %t315 = load i32, ptr %t314
  store i32 %t315, ptr %l18, !tbaa !23
  br label %bb90
bb89:
  br label %bb100
bb90:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l17, !tbaa !23
  %t321 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %v2, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l160
  br label %bb91
bb91:
  %t322 = load i32, ptr %l18, !tbaa !23
  %t324 = icmp slt i32 %t322, 0
  br i1 %t324, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb95
bb93:
  %t326 = load i32, ptr %l18, !tbaa !23
  %t328 = sext i32 %t326 to i64
  store i64 %t328, ptr %l165, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/mir:verifier", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = getelementptr %"compiler/mir:Fn", ptr %t332, i32 0, i32 16
  store ptr %t334, ptr %l168, !tbaa !29
  %t335 = load ptr, ptr %l168, !tbaa !29
  %t336 = call ptr @__olang_scope_or(ptr %v2, ptr %t335)
  %t337 = call ptr @__olang_scope_hold(ptr %t336)
  %t338 = ptrtoint ptr %t337 to i64
  %t340 = inttoptr i64 %t338 to ptr
  %t341 = load ptr, ptr %l168, !tbaa !29
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %t340, ptr %t341)
  store i64 %t342, ptr %l170
  br label %bb94
bb94:
  %t343 = load i64, ptr %l165, !tbaa !24
  %t344 = load i64, ptr %l170, !tbaa !24
  %t345 = icmp sge i64 %t343, %t344
  store i1 %t345, ptr %l163, !tbaa !21
  br label %bb95
bb95:
  %t347 = load i1, ptr %l163, !tbaa !21
  br i1 %t347, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s11
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l18, !tbaa !23
  %t350 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t351 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t353 = sext i32 %t349 to i64
  %t354 = call i64 @__olang_fmt_i64(ptr null, i64 %t353)
  %t355 = add i64 %t351, %t354
  %t356 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t350, i64 %t351)
  %t357 = getelementptr i8, ptr %t356, i64 %t351
  %t358 = call i64 @__olang_fmt_i64(ptr %t357, i64 %t353)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t356, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t348, { i64, ptr } %t360)
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb99:
  br label %bb145
bb100:
  %t364 = load ptr, ptr %l1, !tbaa !29
  store ptr %t364, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t365 = load ptr, ptr %l176, !tbaa !29
  %t366 = icmp ne ptr %t365, null
  br i1 %t366, label %bb101, label %bb102
bb101:
  %t368 = load ptr, ptr %l176, !tbaa !29
  %t369 = load i64, ptr %t368, !range !{i64 0, i64 20}
  %t371 = icmp eq i64 %t369, 14
  store i1 %t371, ptr %l177, !tbaa !21
  br label %bb102
bb102:
  %t372 = load i1, ptr %l177, !tbaa !21
  br i1 %t372, label %bb103, label %bb104
bb103:
  br label %bb109
bb104:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t374 = load ptr, ptr %l180, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb105, label %bb106
bb105:
  %t377 = load ptr, ptr %l180, !tbaa !29
  %t378 = load i64, ptr %t377, !range !{i64 0, i64 20}
  %t380 = icmp eq i64 %t378, 16
  store i1 %t380, ptr %l181, !tbaa !21
  br label %bb106
bb106:
  %t381 = load i1, ptr %l181, !tbaa !21
  br i1 %t381, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb145
bb110:
  %t382 = load ptr, ptr %l1, !tbaa !29
  store ptr %t382, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t383 = load ptr, ptr %l184, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb111, label %bb112
bb111:
  %t386 = load ptr, ptr %l184, !tbaa !29
  %t387 = load i64, ptr %t386, !range !{i64 0, i64 20}
  %t389 = icmp eq i64 %t387, 15
  store i1 %t389, ptr %l185, !tbaa !21
  br label %bb112
bb112:
  %t390 = load i1, ptr %l185, !tbaa !21
  br i1 %t390, label %bb113, label %bb114
bb113:
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr { i64, [21 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t393, i32 0, i32 1
  %t395 = load { i64, [4 x i64] }, ptr %t394
  store { i64, [4 x i64] } %t395, ptr %l19
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, [4 x i64] }, ptr %l19
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t397, { i64, [4 x i64] } %t398)
  br label %bb116
bb116:
  br label %bb145
bb117:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t402 = load ptr, ptr %l192, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb118, label %bb119
bb118:
  %t405 = load ptr, ptr %l192, !tbaa !29
  %t406 = load i64, ptr %t405, !range !{i64 0, i64 20}
  %t408 = icmp eq i64 %t406, 17
  store i1 %t408, ptr %l193, !tbaa !21
  br label %bb119
bb119:
  %t409 = load i1, ptr %l193, !tbaa !21
  br i1 %t409, label %bb120, label %bb121
bb120:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [21 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t412, i32 0, i32 1
  %t414 = load { i64, [4 x i64] }, ptr %t413
  store { i64, [4 x i64] } %t414, ptr %l20
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr { i64, [21 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t418, i32 0, i32 2
  %t420 = load { i64, [4 x i64] }, ptr %t419
  store { i64, [4 x i64] } %t420, ptr %l21
  br label %bb122
bb121:
  br label %bb125
bb122:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load { i64, [4 x i64] }, ptr %l20
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t422, { i64, [4 x i64] } %t423)
  br label %bb123
bb123:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load { i64, [4 x i64] }, ptr %l21
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t426, { i64, [4 x i64] } %t427)
  br label %bb124
bb124:
  br label %bb145
bb125:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t431 = load ptr, ptr %l204, !tbaa !29
  %t432 = icmp ne ptr %t431, null
  br i1 %t432, label %bb126, label %bb127
bb126:
  %t434 = load ptr, ptr %l204, !tbaa !29
  %t435 = load i64, ptr %t434, !range !{i64 0, i64 20}
  %t437 = icmp eq i64 %t435, 18
  store i1 %t437, ptr %l205, !tbaa !21
  br label %bb127
bb127:
  %t438 = load i1, ptr %l205, !tbaa !21
  br i1 %t438, label %bb128, label %bb129
bb128:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [21 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t441, i32 0, i32 1
  %t443 = load { i64, [4 x i64] }, ptr %t442
  store { i64, [4 x i64] } %t443, ptr %l22
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = getelementptr { i64, [21 x i64] }, ptr %t445, i32 0, i32 1
  %t448 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t447, i32 0, i32 3
  %t449 = load %"compiler/mir:Range", ptr %t448
  store %"compiler/mir:Range" %t449, ptr %l23
  br label %bb130
bb129:
  br label %bb133
bb130:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load { i64, [4 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v2, ptr %t451, { i64, [4 x i64] } %t452)
  br label %bb131
bb131:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/mir:Range", ptr %l23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %v2, ptr %t455, %"compiler/mir:Range" %t456)
  br label %bb132
bb132:
  br label %bb145
bb133:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t460 = load ptr, ptr %l216, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb134, label %bb135
bb134:
  %t463 = load ptr, ptr %l216, !tbaa !29
  %t464 = load i64, ptr %t463, !range !{i64 0, i64 20}
  %t466 = icmp eq i64 %t464, 19
  store i1 %t466, ptr %l217, !tbaa !21
  br label %bb135
bb135:
  %t467 = load i1, ptr %l217, !tbaa !21
  br i1 %t467, label %bb136, label %bb137
bb136:
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [21 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t470, i32 0, i32 1
  %t472 = load i32, ptr %t471
  store i32 %t472, ptr %l24, !tbaa !23
  %t474 = load ptr, ptr %l1, !tbaa !29
  %t476 = getelementptr { i64, [21 x i64] }, ptr %t474, i32 0, i32 1
  %t477 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t476, i32 0, i32 2
  %t478 = load i32, ptr %t477
  store i32 %t478, ptr %l25, !tbaa !23
  br label %bb138
bb137:
  br label %bb144
bb138:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l24, !tbaa !23
  %t484 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %v2, ptr %t480, i32 %t481)
  store i1 %t484, ptr %l226
  br label %bb139
bb139:
  %t485 = load i32, ptr %l25, !tbaa !23
  %t486 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t489 = icmp ne i32 %t485, %t486
  br i1 %t489, label %bb140, label %bb141
bb140:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i32, ptr %l25, !tbaa !23
  %t495 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v2, ptr %t491, i32 %t492)
  store i1 %t495, ptr %l232
  br label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb143
bb143:
  br label %bb145
bb144:
  call void @__olang_check_failed(ptr @olang_loc_145fd452f8e36c9b_ff9c6902187c9987)
  unreachable
bb145:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Lvalue"
  %l16 = alloca i32
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca i32
  %l21 = alloca i32
  %l23 = alloca %"compiler/mir:Lvalue"
  %l24 = alloca %"compiler/mir:Lvalue"
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca %"compiler/mir:Task"
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i32
  %l48 = alloca i32
  %l51 = alloca i1
  %l59 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l87 = alloca i32
  %l90 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l104 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca i32
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca i32
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l141 = alloca i1
  %l143 = alloca i1
  %l144 = alloca ptr
  %l147 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca i64
  %l151 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca i1
  %l165 = alloca i32
  %l169 = alloca i1
  %l170 = alloca ptr
  %l173 = alloca i1
  %l175 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l182 = alloca i1
  %l189 = alloca i32
  %l193 = alloca i1
  %l194 = alloca ptr
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l199 = alloca i64
  %l201 = alloca i1
  %l202 = alloca ptr
  %l205 = alloca i1
  %l207 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca i1
  %l227 = alloca i32
  %l228 = alloca ptr
  %l231 = alloca i32
  %l232 = alloca i1
  %l239 = alloca i1
  %l248 = alloca ptr
  %l251 = alloca i1
  %l252 = alloca i1
  %l253 = alloca ptr
  %l256 = alloca i1
  %l260 = alloca ptr
  %l263 = alloca i1
  %l266 = alloca ptr
  %l269 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i32
  %l280 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca i1
  %l298 = alloca ptr
  %l301 = alloca i32
  %l302 = alloca i32
  %l303 = alloca ptr
  %l306 = alloca i32
  %l307 = alloca i32
  %l311 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca ptr
  %l321 = alloca i32
  %l323 = alloca i32
  %l324 = alloca ptr
  %l325 = alloca ptr
  %l328 = alloca i32
  %l330 = alloca i32
  %l332 = alloca i1
  %l334 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l343 = alloca ptr
  %l344 = alloca ptr
  %l347 = alloca i32
  %l349 = alloca i32
  %l351 = alloca i1
  %l354 = alloca ptr
  %l355 = alloca i1
  %l364 = alloca ptr
  %l368 = alloca %"compiler/mir:ScopeInfo"
  %l378 = alloca ptr
  %l382 = alloca %"compiler/mir:Task"
  %l385 = alloca i32
  %l394 = alloca ptr
  %l395 = alloca ptr
  %l396 = alloca ptr
  %l399 = alloca i32
  %l402 = alloca i32
  %l403 = alloca ptr
  %l406 = alloca i32
  %l408 = alloca i32
  %l410 = alloca { i64, ptr }
  %l413 = alloca i1
  %l430 = alloca i1
  %l431 = alloca ptr
  %l432 = alloca ptr
  %l435 = alloca i32
  %l437 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %t942 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t7 = load ptr, ptr %l35, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l35, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 20}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l36, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Lvalue", ptr %t18
  store %"compiler/mir:Lvalue" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l3
  %t31 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store i32 %t31, ptr %l45
  br label %bb6
bb6:
  %t32 = load i32, ptr %l45, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [15 x i64] }, ptr %l4
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %v2, ptr %v3, ptr %t33, { i64, [15 x i64] } %t34)
  store i32 %t37, ptr %l48
  br label %bb7
bb7:
  %t38 = load i32, ptr %l48, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load { i64, [15 x i64] }, ptr %l4
  %t41 = extractvalue { i64, [15 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, [4 x i64] }, ptr %t45
  %t48 = extractvalue { i64, [4 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l51, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l51, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { { i64, [4 x i64] } }, ptr %t52, i32 0, i32 0
  %t54 = load { i64, [4 x i64] }, ptr %t53
  store { i64, [4 x i64] } %t54, ptr %l7
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp ne i32 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  store i1 %t68, ptr %l59, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l59, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s3, ptr %v3, ptr %t71, i32 %t72, i32 %t73, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d158, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb244
bb21:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t78 = load ptr, ptr %l66, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = load ptr, ptr %l66, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 20}
  %t84 = icmp eq i64 %t82, 5
  store i1 %t84, ptr %l67, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l67, !tbaa !21
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [21 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l8, !tbaa !23
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [21 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t94, i32 0, i32 3
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l9
  br label %bb26
bb25:
  br label %bb50
bb26:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l9
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v3, ptr %t98, { i64, [4 x i64] } %t99)
  store i32 %t102, ptr %l76
  br label %bb27
bb27:
  %t103 = load i32, ptr %l76, !tbaa !23
  store i32 %t103, ptr %l10, !tbaa !23
  %t104 = load ptr, ptr %l2, !tbaa !29
  store ptr %t104, ptr %l77, !tbaa !29
  %t105 = load i32, ptr %l10, !tbaa !23
  %t106 = load ptr, ptr %l77, !tbaa !29
  %t107 = call ptr @__olang_scope_or(ptr %v3, ptr %t106)
  %t108 = call ptr @__olang_scope_hold(ptr %t107)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t109 to ptr
  %t112 = load ptr, ptr %l77, !tbaa !29
  %t114 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t111, ptr %t112, i32 %t105)
  store i1 %t114, ptr %l80
  br label %bb28
bb28:
  %t115 = load i1, ptr %l80, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb33
bb30:
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l83, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  store ptr %t119, ptr %l84, !tbaa !29
  %t120 = load i32, ptr %l10, !tbaa !23
  %t121 = load ptr, ptr %l84, !tbaa !29
  %t122 = call ptr @__olang_scope_or(ptr %v3, ptr %t121)
  %t123 = call ptr @__olang_scope_hold(ptr %t122)
  %t124 = ptrtoint ptr %t123 to i64
  %t126 = inttoptr i64 %t124 to ptr
  %t127 = load ptr, ptr %l84, !tbaa !29
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t126, ptr %t127, i32 %t120)
  store i32 %t129, ptr %l87
  br label %bb31
bb31:
  %t130 = load i32, ptr %l8, !tbaa !23
  %t131 = load ptr, ptr %l83, !tbaa !29
  %t132 = call ptr @__olang_scope_or(ptr %v3, ptr %t131)
  %t133 = call ptr @__olang_scope_hold(ptr %t132)
  %t134 = ptrtoint ptr %t133 to i64
  %t136 = inttoptr i64 %t134 to ptr
  %t137 = load ptr, ptr %l83, !tbaa !29
  %t138 = load i32, ptr %l87, !tbaa !23
  %t140 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t136, ptr %t137, i32 %t138, i32 %t130)
  store i1 %t140, ptr %l90
  br label %bb32
bb32:
  %t141 = load i1, ptr %l90, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t144 = load i1, ptr %l82, !tbaa !21
  br i1 %t144, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l92, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %v3, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l95
  br label %bb36
bb35:
  %t151 = load ptr, ptr %l2, !tbaa !29
  store ptr %t151, ptr %l101, !tbaa !29
  %t152 = load i32, ptr %l8, !tbaa !23
  %t153 = load ptr, ptr %l101, !tbaa !29
  %t154 = call ptr @__olang_scope_or(ptr %v3, ptr %t153)
  %t155 = call ptr @__olang_scope_hold(ptr %t154)
  %t156 = ptrtoint ptr %t155 to i64
  %t158 = inttoptr i64 %t156 to ptr
  %t159 = load ptr, ptr %l101, !tbaa !29
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t158, ptr %t159, i32 %t152)
  store i1 %t161, ptr %l104
  br label %bb39
bb36:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %v3, ptr %t162, i32 %t163)
  store { i64, ptr } %t166, ptr %l98
  br label %bb37
bb37:
  %t167 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t169 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = add i64 %t175, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t167, i64 %t168)
  %t181 = getelementptr i8, ptr %t180, i64 %t168
  call void @olang_textcopy(ptr %t181, ptr %t170, i64 %t171)
  %t182 = getelementptr i8, ptr %t181, i64 %t171
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t177, i64 %t178)
  %t184 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t180, 1
  %t187 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t187, { i64, ptr } %t185)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb39:
  %t189 = load i1, ptr %l104, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t192 = load ptr, ptr %l2, !tbaa !29
  store ptr %t192, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l8, !tbaa !23
  %t194 = load ptr, ptr %l107, !tbaa !29
  %t195 = call ptr @__olang_scope_or(ptr %v3, ptr %t194)
  %t196 = call ptr @__olang_scope_hold(ptr %t195)
  %t197 = ptrtoint ptr %t196 to i64
  %t199 = inttoptr i64 %t197 to ptr
  %t200 = load ptr, ptr %l107, !tbaa !29
  %t202 = call i32 @compiler_2fmir_2eGuardOf(ptr %t199, ptr %t200, i32 %t193)
  store i32 %t202, ptr %l110
  br label %bb42
bb41:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb43
bb42:
  %t203 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t204 = load i32, ptr %l110, !tbaa !23
  %t206 = icmp eq i32 %t204, %t203
  store i1 %t206, ptr %l106, !tbaa !21
  br label %bb43
bb43:
  %t208 = load i1, ptr %l106, !tbaa !21
  br i1 %t208, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l113, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l8, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s8, ptr %v3, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l116
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t215 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t217 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t215, i64 %t216)
  %t225 = getelementptr i8, ptr %t224, i64 %t216
  call void @olang_textcopy(ptr %t225, ptr %t218, i64 %t219)
  %t226 = getelementptr i8, ptr %t225, i64 %t219
  call void @olang_textcopy(ptr %t226, ptr %t221, i64 %t222)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t224, 1
  %t230 = load ptr, ptr %l113, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t230, { i64, ptr } %t228)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb244
bb50:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t233 = load ptr, ptr %l119, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb51, label %bb52
bb51:
  %t236 = load ptr, ptr %l119, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 20}
  %t239 = icmp eq i64 %t237, 6
  store i1 %t239, ptr %l120, !tbaa !21
  br label %bb52
bb52:
  %t240 = load i1, ptr %l120, !tbaa !21
  br i1 %t240, label %bb53, label %bb54
bb53:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t243, i32 0, i32 1
  %t245 = load %"compiler/mir:Lvalue", ptr %t244
  store %"compiler/mir:Lvalue" %t245, ptr %l11
  br label %bb55
bb54:
  br label %bb75
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/mir:Lvalue", ptr %l11
  %t251 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t247, %"compiler/mir:Lvalue" %t248)
  store i32 %t251, ptr %l127
  br label %bb56
bb56:
  %t252 = load i32, ptr %l127, !tbaa !23
  store i32 %t252, ptr %l12, !tbaa !23
  %t253 = load i32, ptr %l12, !tbaa !23
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t257 = icmp ne i32 %t253, %t254
  br i1 %t257, label %bb57, label %bb58
bb57:
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l132, !tbaa !29
  %t260 = load i32, ptr %l12, !tbaa !23
  %t261 = load ptr, ptr %l132, !tbaa !29
  %t262 = call ptr @__olang_scope_or(ptr %v3, ptr %t261)
  %t263 = call ptr @__olang_scope_hold(ptr %t262)
  %t264 = ptrtoint ptr %t263 to i64
  %t266 = inttoptr i64 %t264 to ptr
  %t267 = load ptr, ptr %l132, !tbaa !29
  %t269 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t266, ptr %t267, i32 %t260)
  store i1 %t269, ptr %l135
  br label %bb59
bb58:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb60
bb59:
  %t270 = load i1, ptr %l135, !tbaa !21
  %t271 = xor i1 %t270, true
  store i1 %t271, ptr %l131, !tbaa !21
  br label %bb60
bb60:
  %t273 = load i1, ptr %l131, !tbaa !21
  br i1 %t273, label %bb61, label %bb62
bb61:
  %t274 = load ptr, ptr %l2, !tbaa !29
  store ptr %t274, ptr %l138, !tbaa !29
  %t275 = load i32, ptr %l12, !tbaa !23
  %t276 = load ptr, ptr %l138, !tbaa !29
  %t277 = call ptr @__olang_scope_or(ptr %v3, ptr %t276)
  %t278 = call ptr @__olang_scope_hold(ptr %t277)
  %t279 = ptrtoint ptr %t278 to i64
  %t281 = inttoptr i64 %t279 to ptr
  %t282 = load ptr, ptr %l138, !tbaa !29
  %t284 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t281, ptr %t282, i32 %t275)
  store i1 %t284, ptr %l141
  br label %bb63
bb62:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb64
bb63:
  %t285 = load i1, ptr %l141, !tbaa !21
  %t286 = xor i1 %t285, true
  store i1 %t286, ptr %l137, !tbaa !21
  br label %bb64
bb64:
  %t288 = load i1, ptr %l137, !tbaa !21
  br i1 %t288, label %bb65, label %bb66
bb65:
  %t289 = load ptr, ptr %l2, !tbaa !29
  store ptr %t289, ptr %l144, !tbaa !29
  %t290 = load i32, ptr %l12, !tbaa !23
  %t291 = load ptr, ptr %l144, !tbaa !29
  %t292 = call ptr @__olang_scope_or(ptr %v3, ptr %t291)
  %t293 = call ptr @__olang_scope_hold(ptr %t292)
  %t294 = ptrtoint ptr %t293 to i64
  %t296 = inttoptr i64 %t294 to ptr
  %t297 = load ptr, ptr %l144, !tbaa !29
  %t299 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %t296, ptr %s10, ptr %t297, i32 %t290)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %l147
  br label %bb67
bb66:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb69
bb67:
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s10, ptr %l147)
  store i64 %t301, ptr %l149
  br label %bb68
bb68:
  %t302 = load i64, ptr %l149, !tbaa !24
  %t303 = icmp eq i64 %t302, 0
  store i1 %t303, ptr %l143, !tbaa !21
  br label %bb69
bb69:
  %t305 = load i1, ptr %l143, !tbaa !21
  br i1 %t305, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s11
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l151, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l12, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %v3, ptr %t307, i32 %t308)
  store { i64, ptr } %t311, ptr %l154
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t312 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t314 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t312, i64 %t313)
  %t322 = getelementptr i8, ptr %t321, i64 %t313
  call void @olang_textcopy(ptr %t322, ptr %t315, i64 %t316)
  %t323 = getelementptr i8, ptr %t322, i64 %t316
  call void @olang_textcopy(ptr %t323, ptr %t318, i64 %t319)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t321, 1
  %t327 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t327, { i64, ptr } %t325)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb244
bb75:
  %t329 = load ptr, ptr %l1, !tbaa !29
  store ptr %t329, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t330 = load ptr, ptr %l157, !tbaa !29
  %t331 = icmp ne ptr %t330, null
  br i1 %t331, label %bb76, label %bb77
bb76:
  %t333 = load ptr, ptr %l157, !tbaa !29
  %t334 = load i64, ptr %t333, !range !{i64 0, i64 20}
  %t336 = icmp eq i64 %t334, 8
  store i1 %t336, ptr %l158, !tbaa !21
  br label %bb77
bb77:
  %t337 = load i1, ptr %l158, !tbaa !21
  br i1 %t337, label %bb78, label %bb79
bb78:
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t340 = getelementptr { i64, [21 x i64] }, ptr %t338, i32 0, i32 1
  %t341 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t340, i32 0, i32 1
  %t342 = load %"compiler/mir:Lvalue", ptr %t341
  store %"compiler/mir:Lvalue" %t342, ptr %l13
  br label %bb80
bb79:
  br label %bb91
bb80:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/mir:Lvalue", ptr %l13
  %t348 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t344, %"compiler/mir:Lvalue" %t345)
  store i32 %t348, ptr %l165
  br label %bb81
bb81:
  %t349 = load i32, ptr %l165, !tbaa !23
  store i32 %t349, ptr %l14, !tbaa !23
  %t350 = load i32, ptr %l14, !tbaa !23
  %t351 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t354 = icmp ne i32 %t350, %t351
  br i1 %t354, label %bb82, label %bb83
bb82:
  %t356 = load ptr, ptr %l2, !tbaa !29
  store ptr %t356, ptr %l170, !tbaa !29
  %t357 = load i32, ptr %l14, !tbaa !23
  %t358 = load ptr, ptr %l170, !tbaa !29
  %t359 = call ptr @__olang_scope_or(ptr %v3, ptr %t358)
  %t360 = call ptr @__olang_scope_hold(ptr %t359)
  %t361 = ptrtoint ptr %t360 to i64
  %t363 = inttoptr i64 %t361 to ptr
  %t364 = load ptr, ptr %l170, !tbaa !29
  %t366 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t363, ptr %t364, i32 %t357)
  store i1 %t366, ptr %l173
  br label %bb84
bb83:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb85
bb84:
  %t367 = load i1, ptr %l173, !tbaa !21
  %t368 = xor i1 %t367, true
  store i1 %t368, ptr %l169, !tbaa !21
  br label %bb85
bb85:
  %t370 = load i1, ptr %l169, !tbaa !21
  br i1 %t370, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s14
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l175, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr %l14, !tbaa !23
  %t376 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s14, ptr %v3, ptr %t372, i32 %t373)
  store { i64, ptr } %t376, ptr %l178
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t377 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t379 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = add i64 %t378, %t381
  %t383 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t385 = add i64 %t382, %t384
  %t386 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t377, i64 %t378)
  %t387 = getelementptr i8, ptr %t386, i64 %t378
  call void @olang_textcopy(ptr %t387, ptr %t380, i64 %t381)
  %t388 = getelementptr i8, ptr %t387, i64 %t381
  call void @olang_textcopy(ptr %t388, ptr %t383, i64 %t384)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t386, 1
  %t392 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t392, { i64, ptr } %t390)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb90:
  br label %bb244
bb91:
  %t394 = load ptr, ptr %l1, !tbaa !29
  store ptr %t394, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t395 = load ptr, ptr %l181, !tbaa !29
  %t396 = icmp ne ptr %t395, null
  br i1 %t396, label %bb92, label %bb93
bb92:
  %t398 = load ptr, ptr %l181, !tbaa !29
  %t399 = load i64, ptr %t398, !range !{i64 0, i64 20}
  %t401 = icmp eq i64 %t399, 9
  store i1 %t401, ptr %l182, !tbaa !21
  br label %bb93
bb93:
  %t402 = load i1, ptr %l182, !tbaa !21
  br i1 %t402, label %bb94, label %bb95
bb94:
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t405 = getelementptr { i64, [21 x i64] }, ptr %t403, i32 0, i32 1
  %t406 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t405, i32 0, i32 2
  %t407 = load %"compiler/mir:Lvalue", ptr %t406
  store %"compiler/mir:Lvalue" %t407, ptr %l15
  br label %bb96
bb95:
  br label %bb112
bb96:
  store %olang.scope zeroinitializer, ptr %s16
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load %"compiler/mir:Lvalue", ptr %l15
  %t413 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t409, %"compiler/mir:Lvalue" %t410)
  store i32 %t413, ptr %l189
  br label %bb97
bb97:
  %t414 = load i32, ptr %l189, !tbaa !23
  store i32 %t414, ptr %l16, !tbaa !23
  %t415 = load i32, ptr %l16, !tbaa !23
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t419 = icmp ne i32 %t415, %t416
  br i1 %t419, label %bb98, label %bb99
bb98:
  %t421 = load ptr, ptr %l2, !tbaa !29
  store ptr %t421, ptr %l194, !tbaa !29
  %t422 = load i32, ptr %l16, !tbaa !23
  %t423 = load ptr, ptr %l194, !tbaa !29
  %t424 = call ptr @__olang_scope_or(ptr %v3, ptr %t423)
  %t425 = call ptr @__olang_scope_hold(ptr %t424)
  %t426 = ptrtoint ptr %t425 to i64
  %t428 = inttoptr i64 %t426 to ptr
  %t429 = load ptr, ptr %l194, !tbaa !29
  %t431 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %t428, ptr %s16, ptr %t429, i32 %t422)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t431, ptr %l197
  br label %bb100
bb99:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb102
bb100:
  %t433 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s16, ptr %l197)
  store i64 %t433, ptr %l199
  br label %bb101
bb101:
  %t434 = load i64, ptr %l199, !tbaa !24
  %t435 = icmp eq i64 %t434, 0
  store i1 %t435, ptr %l193, !tbaa !21
  br label %bb102
bb102:
  %t437 = load i1, ptr %l193, !tbaa !21
  br i1 %t437, label %bb103, label %bb104
bb103:
  %t438 = load ptr, ptr %l2, !tbaa !29
  store ptr %t438, ptr %l202, !tbaa !29
  %t439 = load i32, ptr %l16, !tbaa !23
  %t440 = load ptr, ptr %l202, !tbaa !29
  %t441 = call ptr @__olang_scope_or(ptr %v3, ptr %t440)
  %t442 = call ptr @__olang_scope_hold(ptr %t441)
  %t443 = ptrtoint ptr %t442 to i64
  %t445 = inttoptr i64 %t443 to ptr
  %t446 = load ptr, ptr %l202, !tbaa !29
  %t448 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t445, ptr %t446, i32 %t439)
  store i1 %t448, ptr %l205
  br label %bb105
bb104:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb106
bb105:
  %t449 = load i1, ptr %l205, !tbaa !21
  %t450 = xor i1 %t449, true
  store i1 %t450, ptr %l201, !tbaa !21
  br label %bb106
bb106:
  %t452 = load i1, ptr %l201, !tbaa !21
  br i1 %t452, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s17
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l207, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i32, ptr %l16, !tbaa !23
  %t458 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s17, ptr %v3, ptr %t454, i32 %t455)
  store { i64, ptr } %t458, ptr %l210
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t459 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t461 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t459, i64 %t460)
  %t469 = getelementptr i8, ptr %t468, i64 %t460
  call void @olang_textcopy(ptr %t469, ptr %t462, i64 %t463)
  %t470 = getelementptr i8, ptr %t469, i64 %t463
  call void @olang_textcopy(ptr %t470, ptr %t465, i64 %t466)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t468, 1
  %t474 = load ptr, ptr %l207, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t474, { i64, ptr } %t472)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s16)
  br label %bb244
bb112:
  %t476 = load ptr, ptr %l1, !tbaa !29
  store ptr %t476, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t477 = load ptr, ptr %l213, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb113, label %bb114
bb113:
  %t480 = load ptr, ptr %l213, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 20}
  %t483 = icmp eq i64 %t481, 11
  store i1 %t483, ptr %l214, !tbaa !21
  br label %bb114
bb114:
  %t484 = load i1, ptr %l214, !tbaa !21
  br i1 %t484, label %bb115, label %bb116
bb115:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr { i64, [21 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t487, i32 0, i32 1
  %t489 = load { i64, [1 x i64] }, ptr %t488
  store { i64, [1 x i64] } %t489, ptr %l17
  %t491 = load ptr, ptr %l1, !tbaa !29
  %t493 = getelementptr { i64, [21 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t493, i32 0, i32 2
  %t495 = load i32, ptr %t494, !range !{i32 0, i32 8}
  store i32 %t495, ptr %l18
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [21 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t499, i32 0, i32 3
  %t501 = load { i64, [4 x i64] }, ptr %t500
  store { i64, [4 x i64] } %t501, ptr %l19
  br label %bb117
bb116:
  br label %bb165
bb117:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load { i64, [1 x i64] }, ptr %l17
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %v2, ptr %t503, { i64, [1 x i64] } %t504)
  br label %bb118
bb118:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load { i64, [4 x i64] }, ptr %l19
  %t511 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v3, ptr %t507, { i64, [4 x i64] } %t508)
  store i32 %t511, ptr %l227
  br label %bb119
bb119:
  %t512 = load i32, ptr %l227, !tbaa !23
  store i32 %t512, ptr %l20, !tbaa !23
  %t513 = load ptr, ptr %l2, !tbaa !29
  store ptr %t513, ptr %l228, !tbaa !29
  %t514 = load i32, ptr %l20, !tbaa !23
  %t515 = load ptr, ptr %l228, !tbaa !29
  %t516 = call ptr @__olang_scope_or(ptr %v3, ptr %t515)
  %t517 = call ptr @__olang_scope_hold(ptr %t516)
  %t518 = ptrtoint ptr %t517 to i64
  %t520 = inttoptr i64 %t518 to ptr
  %t521 = load ptr, ptr %l228, !tbaa !29
  %t523 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t520, ptr %t521, i32 %t514)
  store i32 %t523, ptr %l231
  br label %bb120
bb120:
  %t524 = load i32, ptr %l231, !tbaa !23
  store i32 %t524, ptr %l21, !tbaa !23
  %t525 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t527 = trunc i64 0 to i32
  %t528 = icmp eq i32 %t525, %t527
  br i1 %t528, label %bb121, label %bb122
bb121:
  br label %bb125
bb122:
  %t530 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t532 = trunc i64 1 to i32
  %t533 = icmp eq i32 %t530, %t532
  br i1 %t533, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load i32, ptr %l20, !tbaa !23
  %t539 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %v3, ptr %t535, i32 %t536)
  store i1 %t539, ptr %l239
  br label %bb126
bb126:
  %t540 = load i1, ptr %l239, !tbaa !21
  store i1 %t540, ptr %l232, !tbaa !21
  br label %bb157
bb127:
  %t541 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t543 = trunc i64 2 to i32
  %t544 = icmp eq i32 %t541, %t543
  br i1 %t544, label %bb128, label %bb129
bb128:
  br label %bb132
bb129:
  %t546 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t548 = trunc i64 3 to i32
  %t549 = icmp eq i32 %t546, %t548
  br i1 %t549, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  %t551 = load i32, ptr %l21, !tbaa !23
  %t553 = icmp eq i32 %t551, 7
  store i1 %t553, ptr %l232, !tbaa !21
  br label %bb157
bb133:
  %t555 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t557 = trunc i64 4 to i32
  %t558 = icmp eq i32 %t555, %t557
  br i1 %t558, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb142
bb136:
  %t560 = load ptr, ptr %l2, !tbaa !29
  store ptr %t560, ptr %l248, !tbaa !29
  %t561 = load i32, ptr %l21, !tbaa !23
  %t562 = load ptr, ptr %l248, !tbaa !29
  %t563 = call ptr @__olang_scope_or(ptr %v3, ptr %t562)
  %t564 = call ptr @__olang_scope_hold(ptr %t563)
  %t565 = ptrtoint ptr %t564 to i64
  %t567 = inttoptr i64 %t565 to ptr
  %t568 = load ptr, ptr %l248, !tbaa !29
  %t570 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t567, ptr %t568, i32 %t561)
  store i1 %t570, ptr %l251
  br label %bb137
bb137:
  %t571 = load i1, ptr %l251, !tbaa !21
  br i1 %t571, label %bb138, label %bb139
bb138:
  %t572 = load ptr, ptr %l2, !tbaa !29
  store ptr %t572, ptr %l253, !tbaa !29
  %t573 = load i32, ptr %l21, !tbaa !23
  %t574 = load ptr, ptr %l253, !tbaa !29
  %t575 = call ptr @__olang_scope_or(ptr %v3, ptr %t574)
  %t576 = call ptr @__olang_scope_hold(ptr %t575)
  %t577 = ptrtoint ptr %t576 to i64
  %t579 = inttoptr i64 %t577 to ptr
  %t580 = load ptr, ptr %l253, !tbaa !29
  %t582 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t579, ptr %t580, i32 %t573)
  store i1 %t582, ptr %l256
  br label %bb140
bb139:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb141
bb140:
  %t583 = load i1, ptr %l256, !tbaa !21
  %t584 = xor i1 %t583, true
  store i1 %t584, ptr %l252, !tbaa !21
  br label %bb141
bb141:
  %t586 = load i1, ptr %l252, !tbaa !21
  store i1 %t586, ptr %l232, !tbaa !21
  br label %bb157
bb142:
  %t587 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t589 = trunc i64 5 to i32
  %t590 = icmp eq i32 %t587, %t589
  br i1 %t590, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t592 = load ptr, ptr %l2, !tbaa !29
  store ptr %t592, ptr %l260, !tbaa !29
  %t593 = load i32, ptr %l21, !tbaa !23
  %t594 = load ptr, ptr %l260, !tbaa !29
  %t595 = call ptr @__olang_scope_or(ptr %v3, ptr %t594)
  %t596 = call ptr @__olang_scope_hold(ptr %t595)
  %t597 = ptrtoint ptr %t596 to i64
  %t599 = inttoptr i64 %t597 to ptr
  %t600 = load ptr, ptr %l260, !tbaa !29
  %t602 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t599, ptr %t600, i32 %t593)
  store i1 %t602, ptr %l263
  br label %bb146
bb146:
  %t603 = load i1, ptr %l263, !tbaa !21
  store i1 %t603, ptr %l232, !tbaa !21
  br label %bb157
bb147:
  %t604 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t606 = trunc i64 6 to i32
  %t607 = icmp eq i32 %t604, %t606
  br i1 %t607, label %bb148, label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t609 = load ptr, ptr %l2, !tbaa !29
  store ptr %t609, ptr %l266, !tbaa !29
  %t610 = load i32, ptr %l21, !tbaa !23
  %t611 = load ptr, ptr %l266, !tbaa !29
  %t612 = call ptr @__olang_scope_or(ptr %v3, ptr %t611)
  %t613 = call ptr @__olang_scope_hold(ptr %t612)
  %t614 = ptrtoint ptr %t613 to i64
  %t616 = inttoptr i64 %t614 to ptr
  %t617 = load ptr, ptr %l266, !tbaa !29
  %t619 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %t616, ptr %t617, i32 %t610)
  store i1 %t619, ptr %l269
  br label %bb151
bb151:
  %t620 = load i1, ptr %l269, !tbaa !21
  store i1 %t620, ptr %l232, !tbaa !21
  br label %bb157
bb152:
  %t621 = load i32, ptr %l18, !range !{i32 0, i32 8}
  %t623 = trunc i64 7 to i32
  %t624 = icmp eq i32 %t621, %t623
  br i1 %t624, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  %t626 = load i32, ptr %l21, !tbaa !23
  %t627 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t630 = icmp eq i32 %t626, %t627
  store i1 %t630, ptr %l232, !tbaa !21
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23)
  unreachable
bb157:
  %t632 = load i1, ptr %l232, !tbaa !21
  %t635 = xor i1 %t632, true
  br i1 %t635, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s26
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l277, !tbaa !29
  %t638 = load i32, ptr %l18, !range !{i32 0, i32 8}
  store i32 %t638, ptr %l278
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s27, ptr %l278, i64 0)
  br label %bb160
bb159:
  br label %bb164
bb160:
  %t640 = load ptr, ptr %s27
  %t641 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t642 = load i64, ptr %t641
  %t643 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t642)
  call void @olang_textcopy(ptr %t643, ptr %t640, i64 %t642)
  %t644 = insertvalue { i64, ptr } undef, i64 %t642, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t643, 1
  store { i64, ptr } %t645, ptr %l280, !tbaa !27
  %t646 = getelementptr %olang.builder, ptr %s27, i32 0, i32 3
  %t647 = load ptr, ptr %t646
  %t648 = icmp ne ptr %t647, null
  br i1 %t648, label %sbgrew.649, label %sbdone.650
sbgrew.649:
  call void @__olang_sb_done(ptr %s27)
  br label %sbdone.650
sbdone.650:
  %t651 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t653 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s26, ptr %s26, { i64, ptr } %t651)
  store { i64, ptr } %t653, ptr %l282
  br label %bb161
bb161:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load i32, ptr %l20, !tbaa !23
  %t658 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %v3, ptr %t654, i32 %t655)
  store { i64, ptr } %t658, ptr %l285
  br label %bb162
bb162:
  %t659 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t660 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t661 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 1
  %t663 = extractvalue { i64, ptr } %t661, 0
  %t664 = add i64 %t660, %t663
  %t665 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t666 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t667 = add i64 %t664, %t666
  %t668 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t669 = extractvalue { i64, ptr } %t668, 1
  %t670 = extractvalue { i64, ptr } %t668, 0
  %t671 = add i64 %t667, %t670
  %t672 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t671)
  call void @olang_textcopy(ptr %t672, ptr %t659, i64 %t660)
  %t673 = getelementptr i8, ptr %t672, i64 %t660
  call void @olang_textcopy(ptr %t673, ptr %t662, i64 %t663)
  %t674 = getelementptr i8, ptr %t673, i64 %t663
  call void @olang_textcopy(ptr %t674, ptr %t665, i64 %t666)
  %t675 = getelementptr i8, ptr %t674, i64 %t666
  call void @olang_textcopy(ptr %t675, ptr %t669, i64 %t670)
  %t676 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t677 = insertvalue { i64, ptr } %t676, ptr %t672, 1
  %t679 = load ptr, ptr %l277, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t679, { i64, ptr } %t677)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s26)
  br label %bb164
bb164:
  br label %bb244
bb165:
  %t681 = load ptr, ptr %l1, !tbaa !29
  store ptr %t681, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t682 = load ptr, ptr %l288, !tbaa !29
  %t683 = icmp ne ptr %t682, null
  br i1 %t683, label %bb166, label %bb167
bb166:
  %t685 = load ptr, ptr %l288, !tbaa !29
  %t686 = load i64, ptr %t685, !range !{i64 0, i64 20}
  %t688 = icmp eq i64 %t686, 12
  store i1 %t688, ptr %l289, !tbaa !21
  br label %bb167
bb167:
  %t689 = load i1, ptr %l289, !tbaa !21
  br i1 %t689, label %bb168, label %bb169
bb168:
  %t690 = load ptr, ptr %l1, !tbaa !29
  %t692 = getelementptr { i64, [21 x i64] }, ptr %t690, i32 0, i32 1
  %t693 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t692, i32 0, i32 1
  %t694 = load %"compiler/mir:Lvalue", ptr %t693
  store %"compiler/mir:Lvalue" %t694, ptr %l23
  %t696 = load ptr, ptr %l1, !tbaa !29
  %t698 = getelementptr { i64, [21 x i64] }, ptr %t696, i32 0, i32 1
  %t699 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t698, i32 0, i32 2
  %t700 = load %"compiler/mir:Lvalue", ptr %t699
  store %"compiler/mir:Lvalue" %t700, ptr %l24
  %t702 = load ptr, ptr %l1, !tbaa !29
  %t704 = getelementptr { i64, [21 x i64] }, ptr %t702, i32 0, i32 1
  %t705 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t704, i32 0, i32 3
  %t706 = load { i64, [4 x i64] }, ptr %t705
  store { i64, [4 x i64] } %t706, ptr %l25
  br label %bb170
bb169:
  br label %bb200
bb170:
  %t708 = load ptr, ptr %l0, !tbaa !29
  store ptr %t708, ptr %l298, !tbaa !29
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load %"compiler/mir:Lvalue", ptr %l23
  %t713 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t709, %"compiler/mir:Lvalue" %t710)
  store i32 %t713, ptr %l301
  br label %bb171
bb171:
  %t714 = load ptr, ptr %l298, !tbaa !29
  %t715 = load i32, ptr %l301, !tbaa !23
  %t716 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %v3, ptr %t714, i32 %t715)
  store i32 %t716, ptr %l302
  br label %bb172
bb172:
  %t717 = load i32, ptr %l302, !tbaa !23
  store i32 %t717, ptr %l26, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  store ptr %t718, ptr %l303, !tbaa !29
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load %"compiler/mir:Lvalue", ptr %l24
  %t723 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v2, ptr %v3, ptr %t719, %"compiler/mir:Lvalue" %t720)
  store i32 %t723, ptr %l306
  br label %bb173
bb173:
  %t724 = load ptr, ptr %l303, !tbaa !29
  %t725 = load i32, ptr %l306, !tbaa !23
  %t726 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %v3, ptr %t724, i32 %t725)
  store i32 %t726, ptr %l307
  br label %bb174
bb174:
  %t727 = load i32, ptr %l307, !tbaa !23
  store i32 %t727, ptr %l27, !tbaa !23
  %t728 = load i32, ptr %l26, !tbaa !23
  %t729 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t732 = icmp eq i32 %t728, %t729
  br i1 %t732, label %bb175, label %bb176
bb175:
  store i1 true, ptr %l311, !tbaa !21
  br label %bb177
bb176:
  %t734 = load i32, ptr %l27, !tbaa !23
  %t735 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t738 = icmp eq i32 %t734, %t735
  store i1 %t738, ptr %l311, !tbaa !21
  br label %bb177
bb177:
  %t740 = load i1, ptr %l311, !tbaa !21
  br i1 %t740, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s30
  %t741 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s30, ptr %t741, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb180
bb179:
  %t743 = load ptr, ptr %l2, !tbaa !29
  store ptr %t743, ptr %l316, !tbaa !29
  %t744 = load ptr, ptr %l2, !tbaa !29
  store ptr %t744, ptr %l317, !tbaa !29
  %t745 = load ptr, ptr %l2, !tbaa !29
  store ptr %t745, ptr %l318, !tbaa !29
  %t746 = load i32, ptr %l26, !tbaa !23
  %t747 = load ptr, ptr %l318, !tbaa !29
  %t748 = call ptr @__olang_scope_or(ptr %v3, ptr %t747)
  %t749 = call ptr @__olang_scope_hold(ptr %t748)
  %t750 = ptrtoint ptr %t749 to i64
  %t752 = inttoptr i64 %t750 to ptr
  %t753 = load ptr, ptr %l318, !tbaa !29
  %t755 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t752, ptr %t753, i32 %t746)
  store i32 %t755, ptr %l321
  br label %bb181
bb180:
  call void @__olang_scope_close(ptr %s30)
  br label %bb192
bb181:
  %t756 = load ptr, ptr %l317, !tbaa !29
  %t757 = call ptr @__olang_scope_or(ptr %v3, ptr %t756)
  %t758 = call ptr @__olang_scope_hold(ptr %t757)
  %t759 = ptrtoint ptr %t758 to i64
  %t761 = inttoptr i64 %t759 to ptr
  %t762 = load ptr, ptr %l317, !tbaa !29
  %t763 = load i32, ptr %l321, !tbaa !23
  %t764 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t761, ptr %t762, i32 %t763)
  store i32 %t764, ptr %l323
  br label %bb182
bb182:
  %t765 = load ptr, ptr %l2, !tbaa !29
  store ptr %t765, ptr %l324, !tbaa !29
  %t766 = load ptr, ptr %l2, !tbaa !29
  store ptr %t766, ptr %l325, !tbaa !29
  %t767 = load i32, ptr %l27, !tbaa !23
  %t768 = load ptr, ptr %l325, !tbaa !29
  %t769 = call ptr @__olang_scope_or(ptr %v3, ptr %t768)
  %t770 = call ptr @__olang_scope_hold(ptr %t769)
  %t771 = ptrtoint ptr %t770 to i64
  %t773 = inttoptr i64 %t771 to ptr
  %t774 = load ptr, ptr %l325, !tbaa !29
  %t776 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t773, ptr %t774, i32 %t767)
  store i32 %t776, ptr %l328
  br label %bb183
bb183:
  %t777 = load ptr, ptr %l324, !tbaa !29
  %t778 = call ptr @__olang_scope_or(ptr %v3, ptr %t777)
  %t779 = call ptr @__olang_scope_hold(ptr %t778)
  %t780 = ptrtoint ptr %t779 to i64
  %t782 = inttoptr i64 %t780 to ptr
  %t783 = load ptr, ptr %l324, !tbaa !29
  %t784 = load i32, ptr %l328, !tbaa !23
  %t785 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t782, ptr %t783, i32 %t784)
  store i32 %t785, ptr %l330
  br label %bb184
bb184:
  %t786 = load ptr, ptr %l316, !tbaa !29
  %t787 = call ptr @__olang_scope_or(ptr %v3, ptr %t786)
  %t788 = call ptr @__olang_scope_hold(ptr %t787)
  %t789 = ptrtoint ptr %t788 to i64
  %t791 = inttoptr i64 %t789 to ptr
  %t792 = load ptr, ptr %l316, !tbaa !29
  %t793 = load i32, ptr %l323, !tbaa !23
  %t794 = load i32, ptr %l330, !tbaa !23
  %t795 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t791, ptr %t792, i32 %t793, i32 %t794)
  store i1 %t795, ptr %l332
  br label %bb185
bb185:
  %t796 = load i1, ptr %l332, !tbaa !21
  %t797 = xor i1 %t796, true
  br i1 %t797, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s32
  %t799 = load ptr, ptr %l0, !tbaa !29
  store ptr %t799, ptr %l334, !tbaa !29
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t801 = load i32, ptr %l27, !tbaa !23
  %t804 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s32, ptr %v3, ptr %t800, i32 %t801)
  store { i64, ptr } %t804, ptr %l337
  br label %bb188
bb187:
  br label %bb191
bb188:
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t806 = load i32, ptr %l26, !tbaa !23
  %t809 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s32, ptr %v3, ptr %t805, i32 %t806)
  store { i64, ptr } %t809, ptr %l340
  br label %bb189
bb189:
  %t810 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t811 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t812 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t813 = extractvalue { i64, ptr } %t812, 1
  %t814 = extractvalue { i64, ptr } %t812, 0
  %t815 = add i64 %t811, %t814
  %t816 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t817 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t818 = add i64 %t815, %t817
  %t819 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t820 = extractvalue { i64, ptr } %t819, 1
  %t821 = extractvalue { i64, ptr } %t819, 0
  %t822 = add i64 %t818, %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t810, i64 %t811)
  %t824 = getelementptr i8, ptr %t823, i64 %t811
  call void @olang_textcopy(ptr %t824, ptr %t813, i64 %t814)
  %t825 = getelementptr i8, ptr %t824, i64 %t814
  call void @olang_textcopy(ptr %t825, ptr %t816, i64 %t817)
  %t826 = getelementptr i8, ptr %t825, i64 %t817
  call void @olang_textcopy(ptr %t826, ptr %t820, i64 %t821)
  %t827 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t828 = insertvalue { i64, ptr } %t827, ptr %t823, 1
  %t830 = load ptr, ptr %l334, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s32, ptr %t830, { i64, ptr } %t828)
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s32)
  br label %bb191
bb191:
  br label %bb192
bb192:
  %t832 = load ptr, ptr %l2, !tbaa !29
  store ptr %t832, ptr %l343, !tbaa !29
  %t833 = load ptr, ptr %l2, !tbaa !29
  store ptr %t833, ptr %l344, !tbaa !29
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load { i64, [4 x i64] }, ptr %l25
  %t838 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v2, ptr %v3, ptr %t834, { i64, [4 x i64] } %t835)
  store i32 %t838, ptr %l347
  br label %bb193
bb193:
  %t839 = load ptr, ptr %l344, !tbaa !29
  %t840 = call ptr @__olang_scope_or(ptr %v3, ptr %t839)
  %t841 = call ptr @__olang_scope_hold(ptr %t840)
  %t842 = ptrtoint ptr %t841 to i64
  %t844 = inttoptr i64 %t842 to ptr
  %t845 = load ptr, ptr %l344, !tbaa !29
  %t846 = load i32, ptr %l347, !tbaa !23
  %t847 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t844, ptr %t845, i32 %t846)
  store i32 %t847, ptr %l349
  br label %bb194
bb194:
  %t848 = load ptr, ptr %l343, !tbaa !29
  %t849 = call ptr @__olang_scope_or(ptr %v3, ptr %t848)
  %t850 = call ptr @__olang_scope_hold(ptr %t849)
  %t851 = ptrtoint ptr %t850 to i64
  %t853 = inttoptr i64 %t851 to ptr
  %t854 = load ptr, ptr %l343, !tbaa !29
  %t855 = load i32, ptr %l349, !tbaa !23
  %t856 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t853, ptr %t854, i32 %t855)
  store i1 %t856, ptr %l351
  br label %bb195
bb195:
  %t857 = load i1, ptr %l351, !tbaa !21
  %t858 = xor i1 %t857, true
  br i1 %t858, label %bb196, label %bb197
bb196:
  store %olang.scope zeroinitializer, ptr %s34
  %t860 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s34, ptr %t860, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb198
bb197:
  br label %bb199
bb198:
  call void @__olang_scope_close(ptr %s34)
  br label %bb199
bb199:
  br label %bb244
bb200:
  %t862 = load ptr, ptr %l1, !tbaa !29
  store ptr %t862, ptr %l354, !tbaa !29
  store i1 false, ptr %l355, !tbaa !21
  %t863 = load ptr, ptr %l354, !tbaa !29
  %t864 = icmp ne ptr %t863, null
  br i1 %t864, label %bb201, label %bb202
bb201:
  %t866 = load ptr, ptr %l354, !tbaa !29
  %t867 = load i64, ptr %t866, !range !{i64 0, i64 20}
  %t869 = icmp eq i64 %t867, 13
  store i1 %t869, ptr %l355, !tbaa !21
  br label %bb202
bb202:
  %t870 = load i1, ptr %l355, !tbaa !21
  br i1 %t870, label %bb203, label %bb204
bb203:
  %t871 = load ptr, ptr %l1, !tbaa !29
  %t873 = getelementptr { i64, [21 x i64] }, ptr %t871, i32 0, i32 1
  %t874 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t873, i32 0, i32 1
  %t875 = load i32, ptr %t874
  store i32 %t875, ptr %l28, !tbaa !23
  %t877 = load ptr, ptr %l1, !tbaa !29
  %t879 = getelementptr { i64, [21 x i64] }, ptr %t877, i32 0, i32 1
  %t880 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t879, i32 0, i32 2
  %t881 = load i32, ptr %t880
  store i32 %t881, ptr %l29, !tbaa !23
  br label %bb205
bb204:
  br label %bb239
bb205:
  store %olang.scope zeroinitializer, ptr %s35
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t885 = getelementptr %"compiler/mir:verifier", ptr %t883, i32 0, i32 0
  %t886 = load ptr, ptr %t885, !tbaa !29
  %t888 = getelementptr %"compiler/mir:Fn", ptr %t886, i32 0, i32 8
  store ptr %t888, ptr %l364, !tbaa !29
  %t889 = load i32, ptr %l28, !tbaa !23
  %t891 = sext i32 %t889 to i64
  %t892 = load ptr, ptr %l364, !tbaa !29
  %t893 = call ptr @__olang_scope_or(ptr %v2, ptr %t892)
  %t894 = call ptr @__olang_scope_hold(ptr %t893)
  %t895 = ptrtoint ptr %t894 to i64
  %t897 = inttoptr i64 %t895 to ptr
  %t898 = load ptr, ptr %l364, !tbaa !29
  %t900 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t897, ptr %t898, i64 %t891)
  store %"compiler/mir:ScopeInfo" %t900, ptr %l368
  br label %bb206
bb206:
  %t901 = getelementptr %"compiler/mir:ScopeInfo", ptr %l368, i32 0, i32 0
  %t902 = load i32, ptr %t901, !range !{i32 0, i32 7}
  %t904 = trunc i64 3 to i32
  %t905 = icmp eq i32 %t902, %t904
  %t907 = xor i1 %t905, true
  br i1 %t907, label %bb207, label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s36
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load i32, ptr %l28, !tbaa !23
  %t911 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t912 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t914 = sext i32 %t910 to i64
  %t915 = call i64 @__olang_fmt_i64(ptr null, i64 %t914)
  %t916 = add i64 %t912, %t915
  %t917 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t919 = add i64 %t916, %t918
  %t920 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t919)
  call void @olang_textcopy(ptr %t920, ptr %t911, i64 %t912)
  %t921 = getelementptr i8, ptr %t920, i64 %t912
  %t922 = call i64 @__olang_fmt_i64(ptr %t921, i64 %t914)
  %t923 = getelementptr i8, ptr %t921, i64 %t915
  call void @olang_textcopy(ptr %t923, ptr %t917, i64 %t918)
  %t924 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t925 = insertvalue { i64, ptr } %t924, ptr %t920, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t909, { i64, ptr } %t925)
  br label %bb209
bb208:
  br label %bb210
bb209:
  call void @__olang_scope_close(ptr %s36)
  br label %bb210
bb210:
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t931 = getelementptr %"compiler/mir:verifier", ptr %t929, i32 0, i32 0
  %t932 = load ptr, ptr %t931, !tbaa !29
  %t934 = getelementptr %"compiler/mir:Fn", ptr %t932, i32 0, i32 16
  store ptr %t934, ptr %l378, !tbaa !29
  %t935 = load i32, ptr %l29, !tbaa !23
  %t937 = sext i32 %t935 to i64
  %t938 = load ptr, ptr %l378, !tbaa !29
  %t939 = call ptr @__olang_scope_or(ptr %v2, ptr %t938)
  %t940 = call ptr @__olang_scope_hold(ptr %t939)
  %t941 = ptrtoint ptr %t940 to i64
  %t944 = inttoptr i64 %t941 to ptr
  %t945 = load ptr, ptr %l378, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t942, ptr %t944, ptr %t945, i64 %t937)
  call void @llvm.memmove.p0.p0.i64(ptr %l382, ptr %t942, i64 144, i1 false)
  br label %bb211
bb211:
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %l382, i64 144, i1 false)
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 0
  %t949 = load { i64, [7 x i64] }, ptr %t948
  %t952 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %v2, ptr %v3, ptr %t947, { i64, [7 x i64] } %t949)
  store i32 %t952, ptr %l385
  br label %bb212
bb212:
  %t953 = load i32, ptr %l385, !tbaa !23
  store i32 %t953, ptr %l31, !tbaa !23
  %t954 = load i32, ptr %l31, !tbaa !23
  %t955 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t958 = icmp ne i32 %t954, %t955
  br i1 %t958, label %bb213, label %bb214
bb213:
  store %olang.scope zeroinitializer, ptr %s38
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t961 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 0
  %t962 = load { i64, [7 x i64] }, ptr %t961
  %t963 = load i32, ptr %l31, !tbaa !23
  %t964 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 1
  %t965 = load %"compiler/mir:Range", ptr %t964
  %t966 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 2
  %t967 = load %"compiler/mir:Range", ptr %t966
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %v3, ptr %v2, ptr %t960, { i64, [7 x i64] } %t962, i32 %t963, %"compiler/mir:Range" %t965, %"compiler/mir:Range" %t967)
  br label %bb215
bb214:
  br label %bb238
bb215:
  %t973 = load ptr, ptr %l2, !tbaa !29
  store ptr %t973, ptr %l394, !tbaa !29
  %t974 = load ptr, ptr %l2, !tbaa !29
  store ptr %t974, ptr %l395, !tbaa !29
  %t975 = load ptr, ptr %l2, !tbaa !29
  store ptr %t975, ptr %l396, !tbaa !29
  %t976 = load i32, ptr %l31, !tbaa !23
  %t977 = load ptr, ptr %l396, !tbaa !29
  %t978 = call ptr @__olang_scope_or(ptr %v3, ptr %t977)
  %t979 = call ptr @__olang_scope_hold(ptr %t978)
  %t980 = ptrtoint ptr %t979 to i64
  %t982 = inttoptr i64 %t980 to ptr
  %t983 = load ptr, ptr %l396, !tbaa !29
  %t985 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t982, ptr %t983, i32 %t976)
  store i32 %t985, ptr %l399
  br label %bb216
bb216:
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t987 = load i32, ptr %l31, !tbaa !23
  %t990 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %v3, ptr %t986, i32 %t987)
  store i32 %t990, ptr %l402
  br label %bb217
bb217:
  %t991 = load ptr, ptr %l2, !tbaa !29
  store ptr %t991, ptr %l403, !tbaa !29
  %t992 = load i32, ptr %l31, !tbaa !23
  %t993 = load ptr, ptr %l403, !tbaa !29
  %t994 = call ptr @__olang_scope_or(ptr %v3, ptr %t993)
  %t995 = call ptr @__olang_scope_hold(ptr %t994)
  %t996 = ptrtoint ptr %t995 to i64
  %t998 = inttoptr i64 %t996 to ptr
  %t999 = load ptr, ptr %l403, !tbaa !29
  %t1001 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t998, ptr %t999, i32 %t992)
  store i32 %t1001, ptr %l406
  br label %bb218
bb218:
  %t1002 = load ptr, ptr %l395, !tbaa !29
  %t1003 = call ptr @__olang_scope_or(ptr %v3, ptr %t1002)
  %t1004 = call ptr @__olang_scope_hold(ptr %t1003)
  %t1005 = ptrtoint ptr %t1004 to i64
  %t1007 = inttoptr i64 %t1005 to ptr
  %t1008 = load ptr, ptr %l395, !tbaa !29
  %t1009 = load i32, ptr %l399, !tbaa !23
  %t1010 = load i32, ptr %l402, !tbaa !23
  %t1011 = load i32, ptr %l406, !tbaa !23
  %t1012 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %t1007, ptr %t1008, i32 %t1009, i32 %t1010, i32 %t1011, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t1012, ptr %l408
  br label %bb219
bb219:
  %t1013 = load ptr, ptr %l394, !tbaa !29
  %t1014 = call ptr @__olang_scope_or(ptr %v3, ptr %t1013)
  %t1015 = call ptr @__olang_scope_hold(ptr %t1014)
  %t1016 = ptrtoint ptr %t1015 to i64
  %t1018 = inttoptr i64 %t1016 to ptr
  %t1019 = load ptr, ptr %l394, !tbaa !29
  %t1020 = load i32, ptr %l408, !tbaa !23
  %t1021 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %t1018, ptr %s38, ptr %t1019, i32 %t1020)
  store { i64, ptr } %t1021, ptr %l410
  br label %bb220
bb220:
  %t1022 = load { i64, ptr }, ptr %l410, !tbaa !27
  store { i64, ptr } %t1022, ptr %l32, !tbaa !27
  %t1023 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 3
  %t1024 = getelementptr %"compiler/mir:Range", ptr %t1023, i32 0, i32 1
  %t1025 = load i32, ptr %t1024, !tbaa !23
  %t1027 = icmp sgt i32 %t1025, 0
  br i1 %t1027, label %bb221, label %bb222
bb221:
  %t1029 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 3
  %t1030 = getelementptr %"compiler/mir:Range", ptr %t1029, i32 0, i32 1
  %t1031 = load i32, ptr %t1030, !tbaa !23
  %t1033 = sext i32 %t1031 to i64
  %t1034 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1036 = extractvalue { i64, ptr } %t1034, 0
  %t1039 = icmp ne i64 %t1033, %t1036
  store i1 %t1039, ptr %l413, !tbaa !21
  br label %bb223
bb222:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb223
bb223:
  %t1041 = load i1, ptr %l413, !tbaa !21
  br i1 %t1041, label %bb224, label %bb225
bb224:
  store %olang.scope zeroinitializer, ptr %s39
  %t1042 = load ptr, ptr %l0, !tbaa !29
  %t1043 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 3
  %t1044 = getelementptr %"compiler/mir:Range", ptr %t1043, i32 0, i32 1
  %t1045 = load i32, ptr %t1044, !tbaa !23
  %t1046 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1048 = extractvalue { i64, ptr } %t1046, 0
  %t1049 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t1050 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t1052 = sext i32 %t1045 to i64
  %t1053 = call i64 @__olang_fmt_i64(ptr null, i64 %t1052)
  %t1054 = add i64 %t1050, %t1053
  %t1055 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t1056 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t1057 = add i64 %t1054, %t1056
  %t1059 = call i64 @__olang_fmt_i64(ptr null, i64 %t1048)
  %t1060 = add i64 %t1057, %t1059
  %t1061 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t1062 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t1063 = add i64 %t1060, %t1062
  %t1064 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1063)
  call void @olang_textcopy(ptr %t1064, ptr %t1049, i64 %t1050)
  %t1065 = getelementptr i8, ptr %t1064, i64 %t1050
  %t1066 = call i64 @__olang_fmt_i64(ptr %t1065, i64 %t1052)
  %t1067 = getelementptr i8, ptr %t1065, i64 %t1053
  call void @olang_textcopy(ptr %t1067, ptr %t1055, i64 %t1056)
  %t1068 = getelementptr i8, ptr %t1067, i64 %t1056
  %t1069 = call i64 @__olang_fmt_i64(ptr %t1068, i64 %t1048)
  %t1070 = getelementptr i8, ptr %t1068, i64 %t1059
  call void @olang_textcopy(ptr %t1070, ptr %t1061, i64 %t1062)
  %t1071 = insertvalue { i64, ptr } undef, i64 %t1063, 0
  %t1072 = insertvalue { i64, ptr } %t1071, ptr %t1064, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t1042, { i64, ptr } %t1072)
  br label %bb226
bb225:
  %t1076 = load ptr, ptr %l0, !tbaa !29
  %t1077 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %s35, ptr %s38, ptr %v2, ptr %v3, ptr %t1076, ptr %l30, { i64, ptr } %t1077)
  br label %bb227
bb226:
  call void @__olang_scope_close(ptr %s39)
  br label %bb228
bb227:
  br label %bb228
bb228:
  %t1081 = getelementptr %"compiler/mir:Task", ptr %l30, i32 0, i32 4
  %t1082 = getelementptr %"compiler/mir:Range", ptr %t1081, i32 0, i32 1
  %t1083 = load i32, ptr %t1082, !tbaa !23
  %t1085 = icmp sgt i32 %t1083, 0
  br i1 %t1085, label %bb229, label %bb230
bb229:
  %t1087 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1087, ptr %l431, !tbaa !29
  %t1088 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1088, ptr %l432, !tbaa !29
  %t1089 = load i32, ptr %l31, !tbaa !23
  %t1090 = load ptr, ptr %l432, !tbaa !29
  %t1091 = call ptr @__olang_scope_or(ptr %v3, ptr %t1090)
  %t1092 = call ptr @__olang_scope_hold(ptr %t1091)
  %t1093 = ptrtoint ptr %t1092 to i64
  %t1095 = inttoptr i64 %t1093 to ptr
  %t1096 = load ptr, ptr %l432, !tbaa !29
  %t1098 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t1095, ptr %t1096, i32 %t1089)
  store i32 %t1098, ptr %l435
  br label %bb231
bb230:
  store i1 false, ptr %l430, !tbaa !21
  br label %bb233
bb231:
  %t1099 = load ptr, ptr %l431, !tbaa !29
  %t1100 = call ptr @__olang_scope_or(ptr %v3, ptr %t1099)
  %t1101 = call ptr @__olang_scope_hold(ptr %t1100)
  %t1102 = ptrtoint ptr %t1101 to i64
  %t1104 = inttoptr i64 %t1102 to ptr
  %t1105 = load ptr, ptr %l431, !tbaa !29
  %t1106 = load i32, ptr %l435, !tbaa !23
  %t1107 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t1104, ptr %s38, ptr %t1105, i32 %t1106)
  store { i64, ptr } %t1107, ptr %l437
  br label %bb232
bb232:
  %t1108 = load { i64, ptr }, ptr %l437, !tbaa !27
  %t1109 = extractvalue { i64, ptr } %t1108, 0
  %t1111 = icmp eq i64 %t1109, 0
  store i1 %t1111, ptr %l430, !tbaa !21
  br label %bb233
bb233:
  %t1113 = load i1, ptr %l430, !tbaa !21
  br i1 %t1113, label %bb234, label %bb235
bb234:
  store %olang.scope zeroinitializer, ptr %s42
  %t1114 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s42, ptr %t1114, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d180, i32 0, i32 1) })
  br label %bb236
bb235:
  br label %bb237
bb236:
  call void @__olang_scope_close(ptr %s42)
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s38)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s35)
  br label %bb244
bb239:
  br i1 true, label %bb240, label %bb241
bb240:
  br label %bb242
bb241:
  br label %bb243
bb242:
  br label %bb244
bb243:
  call void @__olang_check_failed(ptr @olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22)
  unreachable
bb244:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l44 = alloca %"compiler/mir:Call"
  %l48 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l54 = alloca %"compiler/mir:Call"
  %l56 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca %"compiler/mir:Call"
  %l63 = alloca i32
  %l65 = alloca ptr
  %l69 = alloca %"compiler/mir:Call"
  %l71 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = mul i64 1, 4
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  store i32 %t15, ptr %t23, !tbaa !33
  %t24 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  br label %bb40
bb4:
  %t25 = load { i64, [8 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [8 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l4, !tbaa !23
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t38 = load i32, ptr %l4, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = mul i64 2, 4
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 2, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l27, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i32, ptr %t46, i64 0
  store i32 %t38, ptr %t47, !tbaa !33
  %t49 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 1
  store i32 %t39, ptr %t51, !tbaa !33
  %t52 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t52, ptr %l15, !tbaa !27
  br label %bb40
bb8:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb9, label %bb10
bb9:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 1
  %t60 = load %"compiler/mir:Range", ptr %t59
  store %"compiler/mir:Range" %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 2
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Range", ptr %l6
  %t68 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %v2, ptr %t66, %"compiler/mir:Range" %t67, i32 %t68)
  store { i64, ptr } %t72, ptr %l35
  br label %bb12
bb12:
  %t73 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t73, ptr %l15, !tbaa !27
  br label %bb40
bb13:
  %t74 = load { i64, [8 x i64] }, ptr %l1
  %t76 = extractvalue { i64, [8 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 4
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l8, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 14
  store ptr %t85, ptr %l40, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t89 = load ptr, ptr %l40, !tbaa !29
  %t90 = call ptr @__olang_scope_or(ptr %v2, ptr %t89)
  %t91 = call ptr @__olang_scope_hold(ptr %t90)
  %t92 = ptrtoint ptr %t91 to i64
  %t94 = inttoptr i64 %t92 to ptr
  %t95 = load ptr, ptr %l40, !tbaa !29
  %t97 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t94, ptr %t95, i64 %t88)
  store %"compiler/mir:Call" %t97, ptr %l44
  br label %bb17
bb17:
  %t98 = getelementptr %"compiler/mir:Call", ptr %l44, i32 0, i32 7
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t103 = icmp eq i32 %t99, %t100
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/mir:Fn", ptr %t105, i32 0, i32 14
  store ptr %t107, ptr %l50, !tbaa !29
  %t108 = load i32, ptr %l8, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = call ptr @__olang_scope_or(ptr %v2, ptr %t111)
  %t113 = call ptr @__olang_scope_hold(ptr %t112)
  %t114 = ptrtoint ptr %t113 to i64
  %t116 = inttoptr i64 %t114 to ptr
  %t117 = load ptr, ptr %l50, !tbaa !29
  %t119 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t116, ptr %t117, i64 %t110)
  store %"compiler/mir:Call" %t119, ptr %l54
  br label %bb20
bb19:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/mir:Fn", ptr %t120, i32 0, i32 14
  store ptr %t122, ptr %l58, !tbaa !29
  %t123 = load i32, ptr %l8, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t126 = load ptr, ptr %l58, !tbaa !29
  %t127 = call ptr @__olang_scope_or(ptr %v2, ptr %t126)
  %t128 = call ptr @__olang_scope_hold(ptr %t127)
  %t129 = ptrtoint ptr %t128 to i64
  %t131 = inttoptr i64 %t129 to ptr
  %t132 = load ptr, ptr %l58, !tbaa !29
  %t134 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t131, ptr %t132, i64 %t125)
  store %"compiler/mir:Call" %t134, ptr %l62
  br label %bb21
bb20:
  %t135 = getelementptr %"compiler/mir:Call", ptr %l54, i32 0, i32 5
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = mul i64 1, 4
  %t138 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t137)
  %t139 = insertvalue { i64, ptr } undef, i64 1, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  store { i64, ptr } %t140, ptr %l56, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 0
  store i32 %t136, ptr %t144, !tbaa !33
  %t145 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t145, ptr %l48, !tbaa !27
  br label %bb23
bb21:
  %t146 = getelementptr %"compiler/mir:Call", ptr %l62, i32 0, i32 5
  %t147 = load i32, ptr %t146, !tbaa !23
  store i32 %t147, ptr %l63, !tbaa !23
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/mir:Fn", ptr %t148, i32 0, i32 14
  store ptr %t150, ptr %l65, !tbaa !29
  %t151 = load i32, ptr %l8, !tbaa !23
  %t153 = sext i32 %t151 to i64
  %t154 = load ptr, ptr %l65, !tbaa !29
  %t155 = call ptr @__olang_scope_or(ptr %v2, ptr %t154)
  %t156 = call ptr @__olang_scope_hold(ptr %t155)
  %t157 = ptrtoint ptr %t156 to i64
  %t159 = inttoptr i64 %t157 to ptr
  %t160 = load ptr, ptr %l65, !tbaa !29
  %t162 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t159, ptr %t160, i64 %t153)
  store %"compiler/mir:Call" %t162, ptr %l69
  br label %bb22
bb22:
  %t163 = getelementptr %"compiler/mir:Call", ptr %l69, i32 0, i32 7
  %t164 = load i32, ptr %t163, !tbaa !23
  %t165 = mul i64 2, 4
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 2, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l71, !tbaa !27
  %t169 = load i32, ptr %l63, !tbaa !23
  %t170 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 0
  store i32 %t169, ptr %t172, !tbaa !33
  %t174 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i32, ptr %t175, i64 1
  store i32 %t164, ptr %t176, !tbaa !33
  %t177 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t177, ptr %l48, !tbaa !27
  br label %bb23
bb23:
  %t178 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t178, ptr %l15, !tbaa !27
  br label %bb40
bb24:
  %t179 = load { i64, [8 x i64] }, ptr %l1
  %t181 = extractvalue { i64, [8 x i64] } %t179, 0
  %t182 = icmp eq i64 %t181, 8
  br i1 %t182, label %bb25, label %bb26
bb25:
  %t184 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t184, i32 0, i32 2
  %t186 = load i32, ptr %t185
  store i32 %t186, ptr %l9, !tbaa !23
  %t188 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t188, i32 0, i32 4
  %t190 = load i32, ptr %t189
  store i32 %t190, ptr %l10, !tbaa !23
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t192 = load i32, ptr %l10, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t196 = icmp eq i32 %t192, %t193
  br i1 %t196, label %bb28, label %bb29
bb28:
  %t198 = load i32, ptr %l9, !tbaa !23
  %t199 = mul i64 1, 4
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 1, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l81, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 0
  store i32 %t198, ptr %t206, !tbaa !33
  %t207 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t207, ptr %l79, !tbaa !27
  br label %bb30
bb29:
  %t208 = load i32, ptr %l9, !tbaa !23
  %t209 = load i32, ptr %l10, !tbaa !23
  %t210 = mul i64 2, 4
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 2, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 0
  store i32 %t208, ptr %t217, !tbaa !33
  %t219 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i32, ptr %t220, i64 1
  store i32 %t209, ptr %t221, !tbaa !33
  %t222 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t222, ptr %l79, !tbaa !27
  br label %bb30
bb30:
  %t223 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t223, ptr %l15, !tbaa !27
  br label %bb40
bb31:
  %t224 = load { i64, [8 x i64] }, ptr %l1
  %t226 = extractvalue { i64, [8 x i64] } %t224, 0
  %t227 = icmp eq i64 %t226, 11
  br i1 %t227, label %bb32, label %bb33
bb32:
  %t229 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t229, i32 0, i32 2
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l11, !tbaa !23
  %t233 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t233, i32 0, i32 4
  %t235 = load i32, ptr %t234
  store i32 %t235, ptr %l12, !tbaa !23
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t237 = load i32, ptr %l11, !tbaa !23
  %t238 = load i32, ptr %l12, !tbaa !23
  %t239 = mul i64 2, 4
  %t240 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 2, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l91, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr i32, ptr %t245, i64 0
  store i32 %t237, ptr %t246, !tbaa !33
  %t248 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 1
  store i32 %t238, ptr %t250, !tbaa !33
  %t251 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t251, ptr %l15, !tbaa !27
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t252 = mul i64 0, 4
  %t253 = insertvalue { i64, ptr } undef, i64 0, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t254, ptr %l15, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7)
  unreachable
bb40:
  %t256 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  store i64 %t257, ptr %l93, !tbaa !24
  %t258 = load i64, ptr %l93, !tbaa !24
  %t259 = mul i64 %t258, 4
  %t260 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  store { i64, ptr } %t262, ptr %l94, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = load i64, ptr %l93, !tbaa !24
  %t268 = mul i64 %t267, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t264, ptr %t266, i64 %t268, i1 false)
  %t269 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t269, ptr %l15, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t270, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Range" %a1, i32 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i32
  %l41 = alloca i32
  %l44 = alloca ptr
  %l51 = alloca %"compiler/mir:Case"
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sle i64 %t10, 2305843009213693951
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = mul i64 %t13, 4
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i32 0, ptr %l4, !tbaa !23
  %t19 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = icmp sgt i32 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb5:
  %t28 = load i32, ptr %l6, !tbaa !23
  %t30 = icmp sgt i32 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l20, !tbaa !23
  br label %bb10
bb7:
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr %l4, !tbaa !23
  %t36 = sub i32 %t32, %t33
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i32 %t36, %t37
  %t42 = sub i32 %t40, 1
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = sdiv i32 %t42, %t43
  store i32 %t46, ptr %l23, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb9
bb9:
  %t48 = load i32, ptr %l23, !tbaa !23
  store i32 %t48, ptr %l20, !tbaa !23
  br label %bb10
bb10:
  %t49 = load i32, ptr %l20, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb11
bb11:
  %t50 = load i32, ptr %l8, !tbaa !23
  %t51 = load i32, ptr %l7, !tbaa !23
  %t54 = icmp slt i32 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t58 = load i32, ptr %l4, !tbaa !23
  %t59 = load i32, ptr %l8, !tbaa !23
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = mul i32 %t59, %t60
  %t66 = add i32 %t58, %t63
  store i32 %t66, ptr %l9, !tbaa !23
  %t68 = load i32, ptr %l9, !tbaa !23
  store i32 %t68, ptr %l41, !tbaa !23
  %t71 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 15
  store ptr %t74, ptr %l44, !tbaa !29
  %t75 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t79 = load i32, ptr %l9, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t84 = add i64 %t78, %t81
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = call ptr @__olang_scope_or(ptr %v2, ptr %t85)
  %t87 = call ptr @__olang_scope_hold(ptr %t86)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t93 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t90, ptr %t91, i64 %t84)
  store %"compiler/mir:Case" %t93, ptr %l51
  br label %bb15
bb15:
  %t94 = getelementptr %"compiler/mir:Case", ptr %l51, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  %t97 = load i32, ptr %l41, !tbaa !23
  %t98 = sext i32 %t97 to i64
  %t99 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 %t98
  store i32 %t95, ptr %t101, !tbaa !33
  br label %bb16
bb16:
  %t102 = load i32, ptr %l8, !tbaa !23
  %t105 = add i32 %t102, 1
  store i32 %t105, ptr %l8, !tbaa !23
  br label %bb11
bb17:
  %t107 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t114 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t110
  store i32 %a2, ptr %t116, !tbaa !33
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l4 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v1, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i1 @compiler_2fmir_2eHasCases(ptr %t11, ptr %t12, i32 %t5)
  store i1 %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load i1, ptr %l7, !tbaa !21
  store i1 %t15, ptr %l2, !tbaa !21
  %t16 = load i32, ptr %l1, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t20 = icmp ne i32 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i1, ptr %l2, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l11, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l17
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t33 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t36, i64 %t37)
  %t44 = getelementptr i8, ptr %t43, i64 %t37
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  %t48 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t48, { i64, ptr } %t46)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t50 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l50 = alloca %"compiler/mir:Lvalue"
  %l51 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Task", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t33 = load i32, ptr %l17, !tbaa !23
  store i32 %t33, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t34 = load i32, ptr %l14, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store { i64, ptr } %a2, ptr %l36, !tbaa !27
  %t55 = load i32, ptr %l8, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t57
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l38, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 13
  store ptr %t68, ptr %l42, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/mir:Task", ptr %t69, i32 0, i32 3
  %t72 = getelementptr %"compiler/mir:Range", ptr %t71, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = load i32, ptr %l8, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t81 = add i64 %t75, %t78
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = call ptr @__olang_scope_or(ptr %v3, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t88 = load ptr, ptr %l42, !tbaa !29
  %t90 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t87, ptr %t88, i64 %t81)
  store %"compiler/mir:Lvalue" %t90, ptr %l50
  br label %bb11
bb11:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load %"compiler/mir:Lvalue", ptr %l50
  %t93 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v3, ptr %v4, ptr %t91, %"compiler/mir:Lvalue" %t92)
  store i32 %t93, ptr %l51
  br label %bb12
bb12:
  %t94 = load i32, ptr %l8, !tbaa !23
  %t95 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t98 = sext i32 %t94 to i64
  %t99 = call i64 @__olang_fmt_i64(ptr null, i64 %t98)
  %t100 = add i64 %t96, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t95, i64 %t96)
  %t102 = getelementptr i8, ptr %t101, i64 %t96
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t98)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t101, 1
  %t107 = load ptr, ptr %l35, !tbaa !29
  %t108 = load i32, ptr %l38, !tbaa !23
  %t109 = load i32, ptr %l51, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s2, ptr %v4, ptr %t107, i32 %t108, i32 %t109, { i64, ptr } %t105)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t111 = load i32, ptr %l7, !tbaa !23
  %t114 = add i32 %t111, 1
  store i32 %t114, ptr %l7, !tbaa !23
  br label %bb7
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Range"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l27 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca %"compiler/mir:Range"
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i1
  %l58 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i64
  %l72 = alloca ptr
  %l74 = alloca i64
  %l101 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca %"compiler/mir:Range"
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i1
  %l128 = alloca i1
  %l131 = alloca i1
  %l137 = alloca i1
  %l140 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [8 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb81
bb5:
  %t8 = load { i64, [8 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [8 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t13 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l27
  br label %bb9
bb9:
  br label %bb81
bb10:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [4 x i64] } %t29, ptr %l3
  %t31 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t39, { i64, [4 x i64] } %t40)
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l37
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l40
  br label %bb16
bb16:
  br label %bb81
bb17:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 0
  %t60 = load { i64, [4 x i64] }, ptr %t59
  store { i64, [4 x i64] } %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 1
  %t64 = load %"compiler/mir:Range", ptr %t63
  store %"compiler/mir:Range" %t64, ptr %l7
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l8, !tbaa !23
  br label %bb20
bb19:
  br label %bb25
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t70, { i64, [4 x i64] } %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l48, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l7
  store %"compiler/mir:Range" %t75, ptr %l49
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 15
  store ptr %t81, ptr %l52, !tbaa !29
  %t82 = load ptr, ptr %l52, !tbaa !29
  %t83 = call ptr @__olang_scope_or(ptr %v1, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t88 = load ptr, ptr %l52, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %t87, ptr %t88)
  store i64 %t89, ptr %l54
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load %"compiler/mir:Range", ptr %l49
  %t92 = load i64, ptr %l54, !tbaa !24
  %t93 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s4, ptr %t90, %"compiler/mir:Range" %t91, i64 %t92, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i1 %t93, ptr %l55
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l8, !tbaa !23
  %t98 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t94, i32 %t95)
  store i1 %t98, ptr %l58
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb81
bb25:
  %t99 = load { i64, [8 x i64] }, ptr %l1
  %t101 = extractvalue { i64, [8 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 4
  br i1 %t102, label %bb26, label %bb27
bb26:
  %t104 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l9, !tbaa !23
  br label %bb30
bb27:
  %t108 = load { i64, [8 x i64] }, ptr %l1
  %t110 = extractvalue { i64, [8 x i64] } %t108, 0
  %t111 = icmp eq i64 %t110, 6
  br i1 %t111, label %bb28, label %bb29
bb28:
  %t113 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l9, !tbaa !23
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t117 = load i32, ptr %l9, !tbaa !23
  %t119 = icmp slt i32 %t117, 0
  br i1 %t119, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb34
bb32:
  %t121 = load i32, ptr %l9, !tbaa !23
  %t123 = sext i32 %t121 to i64
  store i64 %t123, ptr %l69, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/mir:verifier", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/mir:Fn", ptr %t127, i32 0, i32 14
  store ptr %t129, ptr %l72, !tbaa !29
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = call ptr @__olang_scope_or(ptr %v1, ptr %t130)
  %t132 = call ptr @__olang_scope_hold(ptr %t131)
  %t133 = ptrtoint ptr %t132 to i64
  %t135 = inttoptr i64 %t133 to ptr
  %t136 = load ptr, ptr %l72, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %t135, ptr %t136)
  store i64 %t137, ptr %l74
  br label %bb33
bb33:
  %t138 = load i64, ptr %l69, !tbaa !24
  %t139 = load i64, ptr %l74, !tbaa !24
  %t140 = icmp sge i64 %t138, %t139
  store i1 %t140, ptr %l67, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l9, !tbaa !23
  %t145 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t148 = sext i32 %t144 to i64
  %t149 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t150 = add i64 %t146, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t145, i64 %t146)
  %t152 = getelementptr i8, ptr %t151, i64 %t146
  %t153 = call i64 @__olang_fmt_i64(ptr %t152, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t151, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t143, { i64, ptr } %t155)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  br label %bb81
bb39:
  %t159 = load { i64, [8 x i64] }, ptr %l1
  %t161 = extractvalue { i64, [8 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 5
  br i1 %t162, label %bb40, label %bb41
bb40:
  %t164 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t164, i32 0, i32 1
  %t166 = load { i64, [4 x i64] }, ptr %t165
  store { i64, [4 x i64] } %t166, ptr %l10
  br label %bb46
bb41:
  %t168 = load { i64, [8 x i64] }, ptr %l1
  %t170 = extractvalue { i64, [8 x i64] } %t168, 0
  %t171 = icmp eq i64 %t170, 7
  br i1 %t171, label %bb42, label %bb43
bb42:
  %t173 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t173, i32 0, i32 1
  %t175 = load { i64, [4 x i64] }, ptr %t174
  store { i64, [4 x i64] } %t175, ptr %l10
  br label %bb46
bb43:
  %t177 = load { i64, [8 x i64] }, ptr %l1
  %t179 = extractvalue { i64, [8 x i64] } %t177, 0
  %t180 = icmp eq i64 %t179, 9
  br i1 %t180, label %bb44, label %bb45
bb44:
  %t182 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t182, i32 0, i32 2
  %t184 = load { i64, [4 x i64] }, ptr %t183
  store { i64, [4 x i64] } %t184, ptr %l10
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, [4 x i64] }, ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t186, { i64, [4 x i64] } %t187)
  br label %bb47
bb47:
  br label %bb81
bb48:
  %t190 = load { i64, [8 x i64] }, ptr %l1
  %t192 = extractvalue { i64, [8 x i64] } %t190, 0
  %t193 = icmp eq i64 %t192, 11
  br i1 %t193, label %bb49, label %bb50
bb49:
  %t195 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t195, i32 0, i32 1
  %t197 = load { i64, [4 x i64] }, ptr %t196
  store { i64, [4 x i64] } %t197, ptr %l11
  %t199 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t199, i32 0, i32 2
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l12, !tbaa !23
  %t203 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t203, i32 0, i32 3
  %t205 = load %"compiler/mir:Range", ptr %t204
  store %"compiler/mir:Range" %t205, ptr %l13
  %t207 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t207, i32 0, i32 4
  %t209 = load i32, ptr %t208
  store i32 %t209, ptr %l14, !tbaa !23
  br label %bb51
bb50:
  br label %bb57
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %t211, { i64, [4 x i64] } %t212)
  br label %bb52
bb52:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l12, !tbaa !23
  %t219 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t215, i32 %t216)
  store i1 %t219, ptr %l101
  br label %bb53
bb53:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l14, !tbaa !23
  %t224 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t220, i32 %t221)
  store i1 %t224, ptr %l104
  br label %bb54
bb54:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l105, !tbaa !29
  %t226 = load %"compiler/mir:Range", ptr %l13
  store %"compiler/mir:Range" %t226, ptr %l106
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/mir:verifier", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/mir:Fn", ptr %t230, i32 0, i32 12
  store ptr %t232, ptr %l109, !tbaa !29
  %t233 = load ptr, ptr %l109, !tbaa !29
  %t234 = call ptr @__olang_scope_or(ptr %v1, ptr %t233)
  %t235 = call ptr @__olang_scope_hold(ptr %t234)
  %t236 = ptrtoint ptr %t235 to i64
  %t238 = inttoptr i64 %t236 to ptr
  %t239 = load ptr, ptr %l109, !tbaa !29
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %t238, ptr %t239)
  store i64 %t240, ptr %l111
  br label %bb55
bb55:
  %t241 = load ptr, ptr %l105, !tbaa !29
  %t242 = load %"compiler/mir:Range", ptr %l106
  %t243 = load i64, ptr %l111, !tbaa !24
  %t244 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s9, ptr %t241, %"compiler/mir:Range" %t242, i64 %t243, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t244, ptr %l112
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb81
bb57:
  %t245 = load { i64, [8 x i64] }, ptr %l1
  %t247 = extractvalue { i64, [8 x i64] } %t245, 0
  %t248 = icmp eq i64 %t247, 12
  br i1 %t248, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/mir:verifier", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/mir:Fn", ptr %t253, i32 0, i32 25
  %t256 = load i1, ptr %t255, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  %t260 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t260, { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  br label %bb81
bb65:
  %t262 = load { i64, [8 x i64] }, ptr %l1
  %t264 = extractvalue { i64, [8 x i64] } %t262, 0
  %t265 = icmp eq i64 %t264, 8
  br i1 %t265, label %bb66, label %bb67
bb66:
  %t267 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t267, i32 0, i32 1
  %t269 = load i32, ptr %t268
  store i32 %t269, ptr %l15, !tbaa !23
  %t271 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t271, i32 0, i32 2
  %t273 = load i32, ptr %t272
  store i32 %t273, ptr %l16, !tbaa !23
  %t275 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t275, i32 0, i32 3
  %t277 = load i32, ptr %t276
  store i32 %t277, ptr %l17, !tbaa !23
  %t279 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t279, i32 0, i32 4
  %t281 = load i32, ptr %t280
  store i32 %t281, ptr %l18, !tbaa !23
  br label %bb68
bb67:
  br label %bb76
bb68:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l15, !tbaa !23
  %t287 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %v1, ptr %t283, i32 %t284)
  store i1 %t287, ptr %l128
  br label %bb69
bb69:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l16, !tbaa !23
  %t292 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t288, i32 %t289)
  store i1 %t292, ptr %l131
  br label %bb70
bb70:
  %t293 = load i32, ptr %l18, !tbaa !23
  %t294 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t297 = icmp ne i32 %t293, %t294
  br i1 %t297, label %bb71, label %bb72
bb71:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load i32, ptr %l18, !tbaa !23
  %t303 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %t299, i32 %t300)
  store i1 %t303, ptr %l137
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l17, !tbaa !23
  %t308 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %t304, i32 %t305)
  store i1 %t308, ptr %l140
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb81
bb76:
  %t309 = load { i64, [8 x i64] }, ptr %l1
  %t311 = extractvalue { i64, [8 x i64] } %t309, 0
  %t312 = icmp eq i64 %t311, 10
  br i1 %t312, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_4fdb0c87eb50ced7_f9856407ece22343)
  unreachable
bb81:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Call"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Call"
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l37 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l81 = alloca %"compiler/mir:Call"
  %l84 = alloca i32
  %l95 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca i32
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca { i64, ptr }
  %l116 = alloca i1
  %l123 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i32
  %l136 = alloca i32
  %l141 = alloca ptr
  %l145 = alloca %"compiler/mir:Call"
  %l148 = alloca i32
  %l158 = alloca i1
  %l162 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca ptr
  %l176 = alloca i32
  %l178 = alloca i1
  %l184 = alloca ptr
  %l188 = alloca i32
  %l194 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l207 = alloca i32
  %l216 = alloca ptr
  %l219 = alloca i32
  %l220 = alloca ptr
  %l224 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l233 = alloca i32
  %l235 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l242 = alloca i32
  %l244 = alloca i32
  %l251 = alloca ptr
  %l255 = alloca %"compiler/mir:ScopeInfo"
  %l263 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l270 = alloca i1
  %l277 = alloca i1
  %l285 = alloca ptr
  %l288 = alloca i32
  %l290 = alloca i32
  %l301 = alloca i1
  %l305 = alloca i1
  %l309 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i32
  %l316 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l324 = alloca i32
  %l325 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.builder
  %s39room = alloca [64 x i8], align 8
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load { i64, [8 x i64] }, ptr %l1
  %t13 = extractvalue { i64, [8 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 2
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t17 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t18, ptr %l4
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t20, { i64, [4 x i64] } %t21)
  store i32 %t24, ptr %l37
  br label %bb4
bb4:
  %t25 = load i32, ptr %l37, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l38, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr %l38, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v2, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t33, ptr %t34, i32 %t27)
  store i32 %t36, ptr %l41
  br label %bb5
bb5:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t38 = load i32, ptr %l41, !tbaa !23
  %t40 = icmp ne i32 %t38, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l44, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %v2, ptr %t43, i32 %t44)
  store { i64, ptr } %t47, ptr %l47
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t50 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = getelementptr i8, ptr %t54, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t59, { i64, ptr } %t57)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb196
bb11:
  %t61 = load { i64, [8 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [8 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 3
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l6
  %t70 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t70, i32 0, i32 1
  %t72 = load %"compiler/mir:Range", ptr %t71
  store %"compiler/mir:Range" %t72, ptr %l7
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l6
  %t78 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t74, { i64, [4 x i64] } %t75)
  store i32 %t78, ptr %l56
  br label %bb15
bb15:
  %t79 = load i32, ptr %l56, !tbaa !23
  store i32 %t79, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l57, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  store ptr %t81, ptr %l58, !tbaa !29
  %t82 = load i32, ptr %l8, !tbaa !23
  %t83 = load ptr, ptr %l58, !tbaa !29
  %t84 = call ptr @__olang_scope_or(ptr %v2, ptr %t83)
  %t85 = call ptr @__olang_scope_hold(ptr %t84)
  %t86 = ptrtoint ptr %t85 to i64
  %t88 = inttoptr i64 %t86 to ptr
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t88, ptr %t89, i32 %t82)
  store i32 %t91, ptr %l61
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l57, !tbaa !29
  %t93 = call ptr @__olang_scope_or(ptr %v2, ptr %t92)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t99 = load i32, ptr %l61, !tbaa !23
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t97, ptr %t98, i32 %t99)
  store i1 %t100, ptr %l63
  br label %bb17
bb17:
  %t101 = load i1, ptr %l63, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l65, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %v2, ptr %t105, i32 %t106)
  store { i64, ptr } %t109, ptr %l68
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t110 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t112 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t110, i64 %t111)
  %t117 = getelementptr i8, ptr %t116, i64 %t111
  call void @olang_textcopy(ptr %t117, ptr %t113, i64 %t114)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t121, { i64, ptr } %t119)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/mir:Range", ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %v1, ptr %t123, %"compiler/mir:Range" %t124)
  br label %bb23
bb23:
  br label %bb196
bb24:
  %t127 = load { i64, [8 x i64] }, ptr %l1
  %t129 = extractvalue { i64, [8 x i64] } %t127, 0
  %t130 = icmp eq i64 %t129, 4
  br i1 %t130, label %bb25, label %bb26
bb25:
  %t132 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32 }, ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb65
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/mir:Fn", ptr %t136, i32 0, i32 14
  store ptr %t138, ptr %l77, !tbaa !29
  %t139 = load i32, ptr %l9, !tbaa !23
  %t141 = sext i32 %t139 to i64
  %t142 = load ptr, ptr %l77, !tbaa !29
  %t143 = call ptr @__olang_scope_or(ptr %v1, ptr %t142)
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  %t147 = inttoptr i64 %t145 to ptr
  %t148 = load ptr, ptr %l77, !tbaa !29
  %t150 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t147, ptr %t148, i64 %t141)
  store %"compiler/mir:Call" %t150, ptr %l81
  br label %bb28
bb28:
  %t151 = load %"compiler/mir:Call", ptr %l81
  store %"compiler/mir:Call" %t151, ptr %l10
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t154 = load { i64, [7 x i64] }, ptr %t153
  %t157 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %v1, ptr %v2, ptr %t152, { i64, [7 x i64] } %t154)
  store i32 %t157, ptr %l84
  br label %bb29
bb29:
  %t158 = load i32, ptr %l84, !tbaa !23
  store i32 %t158, ptr %l11, !tbaa !23
  %t159 = load i32, ptr %l11, !tbaa !23
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t163 = icmp eq i32 %t159, %t160
  br i1 %t163, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t167 = load { i64, [7 x i64] }, ptr %t166
  %t168 = load i32, ptr %l11, !tbaa !23
  %t169 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 1
  %t170 = load %"compiler/mir:Range", ptr %t169
  %t171 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 2
  %t172 = load %"compiler/mir:Range", ptr %t171
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %v2, ptr %v1, ptr %t165, { i64, [7 x i64] } %t167, i32 %t168, %"compiler/mir:Range" %t170, %"compiler/mir:Range" %t172)
  br label %bb33
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l11, !tbaa !23
  %t182 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %v2, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l95
  br label %bb34
bb34:
  %t183 = load i32, ptr %l95, !tbaa !23
  store i32 %t183, ptr %l12, !tbaa !23
  %t184 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 4
  %t185 = load i1, ptr %t184, !tbaa !21
  br i1 %t185, label %bb35, label %bb36
bb35:
  %t187 = load i32, ptr %l12, !tbaa !23
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t191 = icmp eq i32 %t187, %t188
  br i1 %t191, label %bb37, label %bb38
bb36:
  br label %bb43
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t193, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d191, i32 0, i32 1) })
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s11
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l101, !tbaa !29
  %t196 = load i32, ptr %l12, !tbaa !23
  store i32 %t196, ptr %l102, !tbaa !23
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 3
  %t199 = load %"compiler/mir:Lvalue", ptr %t198
  %t202 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %t197, %"compiler/mir:Lvalue" %t199)
  store i32 %t202, ptr %l105
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb42
bb40:
  %t203 = load ptr, ptr %l101, !tbaa !29
  %t204 = load i32, ptr %l102, !tbaa !23
  %t205 = load i32, ptr %l105, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s11, ptr %v2, ptr %t203, i32 %t204, i32 %t205, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d192, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t206 = load ptr, ptr %l2, !tbaa !29
  store ptr %t206, ptr %l106, !tbaa !29
  %t207 = load ptr, ptr %l2, !tbaa !29
  store ptr %t207, ptr %l107, !tbaa !29
  %t208 = load i32, ptr %l11, !tbaa !23
  %t209 = load ptr, ptr %l107, !tbaa !29
  %t210 = call ptr @__olang_scope_or(ptr %v2, ptr %t209)
  %t211 = call ptr @__olang_scope_hold(ptr %t210)
  %t212 = ptrtoint ptr %t211 to i64
  %t214 = inttoptr i64 %t212 to ptr
  %t215 = load ptr, ptr %l107, !tbaa !29
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t214, ptr %t215, i32 %t208)
  store i32 %t217, ptr %l110
  br label %bb44
bb44:
  %t218 = load ptr, ptr %l106, !tbaa !29
  %t219 = call ptr @__olang_scope_or(ptr %v2, ptr %t218)
  %t220 = call ptr @__olang_scope_hold(ptr %t219)
  %t221 = ptrtoint ptr %t220 to i64
  %t223 = inttoptr i64 %t221 to ptr
  %t224 = load ptr, ptr %l106, !tbaa !29
  %t225 = load i32, ptr %l110, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t223, ptr %s7, ptr %t224, i32 %t225)
  store { i64, ptr } %t226, ptr %l112
  br label %bb45
bb45:
  %t227 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t230 = icmp sgt i64 %t228, 0
  store i1 %t230, ptr %l13, !tbaa !21
  %t232 = load i1, ptr %l13, !tbaa !21
  br i1 %t232, label %bb46, label %bb47
bb46:
  %t234 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t239 = icmp eq i32 %t235, %t236
  store i1 %t239, ptr %l116, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb48
bb48:
  %t241 = load i1, ptr %l116, !tbaa !21
  br i1 %t241, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t242 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s12, ptr %t242, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d193, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb52:
  %t244 = load i1, ptr %l13, !tbaa !21
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb53, label %bb54
bb53:
  %t248 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t249 = load i32, ptr %t248, !tbaa !23
  %t250 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t253 = icmp ne i32 %t249, %t250
  store i1 %t253, ptr %l123, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb55
bb55:
  %t255 = load i1, ptr %l123, !tbaa !21
  br i1 %t255, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t256 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t256, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  %t258 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t259 = load i32, ptr %t258, !tbaa !23
  %t260 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t263 = icmp ne i32 %t259, %t260
  br i1 %t263, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l131, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 6
  %t268 = load i32, ptr %t267, !tbaa !23
  %t271 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %v1, ptr %t266, i32 %t268)
  store i32 %t271, ptr %l134
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t272 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t273 = load ptr, ptr %l131, !tbaa !29
  %t274 = load i32, ptr %l134, !tbaa !23
  %t276 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s14, ptr %v2, ptr %t273, i32 %t274, i32 %t272, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d195, i32 0, i32 1) })
  store i32 %t276, ptr %l136
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb196
bb65:
  %t277 = load { i64, [8 x i64] }, ptr %l1
  %t279 = extractvalue { i64, [8 x i64] } %t277, 0
  %t280 = icmp eq i64 %t279, 6
  br i1 %t280, label %bb66, label %bb67
bb66:
  %t282 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32 }, ptr %t282, i32 0, i32 1
  %t284 = load i32, ptr %t283
  store i32 %t284, ptr %l14, !tbaa !23
  br label %bb68
bb67:
  br label %bb92
bb68:
  %t286 = load ptr, ptr %l3, !tbaa !29
  %t288 = getelementptr %"compiler/mir:Fn", ptr %t286, i32 0, i32 14
  store ptr %t288, ptr %l141, !tbaa !29
  %t289 = load i32, ptr %l14, !tbaa !23
  %t291 = sext i32 %t289 to i64
  %t292 = load ptr, ptr %l141, !tbaa !29
  %t293 = call ptr @__olang_scope_or(ptr %v1, ptr %t292)
  %t294 = call ptr @__olang_scope_hold(ptr %t293)
  %t295 = ptrtoint ptr %t294 to i64
  %t297 = inttoptr i64 %t295 to ptr
  %t298 = load ptr, ptr %l141, !tbaa !29
  %t300 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t297, ptr %t298, i64 %t291)
  store %"compiler/mir:Call" %t300, ptr %l145
  br label %bb69
bb69:
  %t301 = load %"compiler/mir:Call", ptr %l145
  store %"compiler/mir:Call" %t301, ptr %l15
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t304 = load { i64, [7 x i64] }, ptr %t303
  %t307 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %v1, ptr %v2, ptr %t302, { i64, [7 x i64] } %t304)
  store i32 %t307, ptr %l148
  br label %bb70
bb70:
  %t308 = load i32, ptr %l148, !tbaa !23
  store i32 %t308, ptr %l16, !tbaa !23
  %t309 = load i32, ptr %l16, !tbaa !23
  %t310 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t313 = icmp eq i32 %t309, %t310
  br i1 %t313, label %bb71, label %bb72
bb71:
  br label %ret
bb72:
  br label %bb73
bb73:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t317 = load { i64, [7 x i64] }, ptr %t316
  %t318 = load i32, ptr %l16, !tbaa !23
  %t319 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 1
  %t320 = load %"compiler/mir:Range", ptr %t319
  %t321 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 2
  %t322 = load %"compiler/mir:Range", ptr %t321
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %v2, ptr %v1, ptr %t315, { i64, [7 x i64] } %t317, i32 %t318, %"compiler/mir:Range" %t320, %"compiler/mir:Range" %t322)
  br label %bb74
bb74:
  %t328 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 4
  %t329 = load i1, ptr %t328, !tbaa !21
  br i1 %t329, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l158, !tbaa !21
  br label %bb77
bb76:
  %t331 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 5
  %t332 = load i32, ptr %t331, !tbaa !23
  %t333 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t336 = icmp ne i32 %t332, %t333
  store i1 %t336, ptr %l158, !tbaa !21
  br label %bb77
bb77:
  %t338 = load i1, ptr %l158, !tbaa !21
  br i1 %t338, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb80
bb79:
  %t339 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 7
  %t340 = load i32, ptr %t339, !tbaa !23
  %t341 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t344 = icmp ne i32 %t340, %t341
  store i1 %t344, ptr %l162, !tbaa !21
  br label %bb80
bb80:
  %t346 = load i1, ptr %l162, !tbaa !21
  br i1 %t346, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t347 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t347, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  %t349 = load ptr, ptr %l2, !tbaa !29
  store ptr %t349, ptr %l167, !tbaa !29
  %t350 = load ptr, ptr %l2, !tbaa !29
  store ptr %t350, ptr %l168, !tbaa !29
  %t351 = load i32, ptr %l16, !tbaa !23
  %t352 = load ptr, ptr %l168, !tbaa !29
  %t353 = call ptr @__olang_scope_or(ptr %v2, ptr %t352)
  %t354 = call ptr @__olang_scope_hold(ptr %t353)
  %t355 = ptrtoint ptr %t354 to i64
  %t357 = inttoptr i64 %t355 to ptr
  %t358 = load ptr, ptr %l168, !tbaa !29
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t357, ptr %t358, i32 %t351)
  store i32 %t360, ptr %l171
  br label %bb85
bb85:
  %t361 = load ptr, ptr %l2, !tbaa !29
  store ptr %t361, ptr %l172, !tbaa !29
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t364 = getelementptr %"compiler/mir:Fn", ptr %t362, i32 0, i32 1
  %t365 = load i32, ptr %t364, !tbaa !23
  %t366 = load ptr, ptr %l172, !tbaa !29
  %t367 = call ptr @__olang_scope_or(ptr %v2, ptr %t366)
  %t368 = call ptr @__olang_scope_hold(ptr %t367)
  %t369 = ptrtoint ptr %t368 to i64
  %t371 = inttoptr i64 %t369 to ptr
  %t372 = load ptr, ptr %l172, !tbaa !29
  %t374 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t371, ptr %t372, i32 %t365)
  store i32 %t374, ptr %l176
  br label %bb86
bb86:
  %t375 = load ptr, ptr %l167, !tbaa !29
  %t376 = call ptr @__olang_scope_or(ptr %v2, ptr %t375)
  %t377 = call ptr @__olang_scope_hold(ptr %t376)
  %t378 = ptrtoint ptr %t377 to i64
  %t380 = inttoptr i64 %t378 to ptr
  %t381 = load ptr, ptr %l167, !tbaa !29
  %t382 = load i32, ptr %l171, !tbaa !23
  %t383 = load i32, ptr %l176, !tbaa !23
  %t384 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t380, ptr %t381, i32 %t382, i32 %t383)
  store i1 %t384, ptr %l178
  br label %bb87
bb87:
  %t385 = load i1, ptr %l178, !tbaa !21
  %t386 = xor i1 %t385, true
  br i1 %t386, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  %t388 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t388, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb91:
  br label %bb196
bb92:
  %t390 = load { i64, [8 x i64] }, ptr %l1
  %t392 = extractvalue { i64, [8 x i64] } %t390, 0
  %t393 = icmp eq i64 %t392, 5
  br i1 %t393, label %bb93, label %bb94
bb93:
  %t395 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t395, i32 0, i32 1
  %t397 = load { i64, [4 x i64] }, ptr %t396
  store { i64, [4 x i64] } %t397, ptr %l17
  br label %bb95
bb94:
  br label %bb111
bb95:
  %t399 = load ptr, ptr %l2, !tbaa !29
  store ptr %t399, ptr %l184, !tbaa !29
  %t400 = load ptr, ptr %l3, !tbaa !29
  %t402 = getelementptr %"compiler/mir:Fn", ptr %t400, i32 0, i32 1
  %t403 = load i32, ptr %t402, !tbaa !23
  %t404 = load ptr, ptr %l184, !tbaa !29
  %t405 = call ptr @__olang_scope_or(ptr %v2, ptr %t404)
  %t406 = call ptr @__olang_scope_hold(ptr %t405)
  %t407 = ptrtoint ptr %t406 to i64
  %t409 = inttoptr i64 %t407 to ptr
  %t410 = load ptr, ptr %l184, !tbaa !29
  %t412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t409, ptr %t410, i32 %t403)
  store i32 %t412, ptr %l188
  br label %bb96
bb96:
  %t413 = load i32, ptr %l188, !tbaa !23
  store i32 %t413, ptr %l18, !tbaa !23
  %t414 = load { i64, [4 x i64] }, ptr %l17
  %t416 = extractvalue { i64, [4 x i64] } %t414, 0
  %t417 = icmp eq i64 %t416, 0
  br i1 %t417, label %bb97, label %bb98
bb97:
  %t419 = load i32, ptr %l18, !tbaa !23
  %t420 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t423 = icmp ne i32 %t419, %t420
  br i1 %t423, label %bb99, label %bb100
bb98:
  %t425 = load i32, ptr %l18, !tbaa !23
  %t426 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t429 = icmp eq i32 %t425, %t426
  br i1 %t429, label %bb104, label %bb105
bb99:
  store %olang.scope zeroinitializer, ptr %s21
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l194, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l18, !tbaa !23
  %t436 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s21, ptr %v2, ptr %t432, i32 %t433)
  store { i64, ptr } %t436, ptr %l197
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t437 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t439 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = add i64 %t438, %t441
  %t443 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t442)
  call void @olang_textcopy(ptr %t443, ptr %t437, i64 %t438)
  %t444 = getelementptr i8, ptr %t443, i64 %t438
  call void @olang_textcopy(ptr %t444, ptr %t440, i64 %t441)
  %t445 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t443, 1
  %t448 = load ptr, ptr %l194, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t448, { i64, ptr } %t446)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb103
bb103:
  br label %bb110
bb104:
  store %olang.scope zeroinitializer, ptr %s24
  %t450 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t450, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d199, i32 0, i32 1) })
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s25
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l204, !tbaa !29
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load { i64, [4 x i64] }, ptr %l17
  %t457 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t453, { i64, [4 x i64] } %t454)
  store i32 %t457, ptr %l207
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb107:
  %t458 = load i32, ptr %l18, !tbaa !23
  %t459 = load ptr, ptr %l204, !tbaa !29
  %t460 = load i32, ptr %l207, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s25, ptr %v2, ptr %t459, i32 %t460, i32 %t458, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s25)
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb196
bb111:
  %t462 = load { i64, [8 x i64] }, ptr %l1
  %t464 = extractvalue { i64, [8 x i64] } %t462, 0
  %t465 = icmp eq i64 %t464, 11
  br i1 %t465, label %bb112, label %bb113
bb112:
  %t467 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t468 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t467, i32 0, i32 1
  %t469 = load { i64, [4 x i64] }, ptr %t468
  store { i64, [4 x i64] } %t469, ptr %l19
  br label %bb114
bb113:
  br label %bb122
bb114:
  store %olang.scope zeroinitializer, ptr %s26
  %t471 = load ptr, ptr %l3, !tbaa !29
  %t473 = getelementptr %"compiler/mir:Fn", ptr %t471, i32 0, i32 25
  %t474 = load i1, ptr %t473, !tbaa !21
  %t476 = xor i1 %t474, true
  br i1 %t476, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s27
  %t478 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s27, ptr %t478, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d201, i32 0, i32 1) })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s27)
  br label %bb118
bb118:
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l216, !tbaa !29
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load { i64, [4 x i64] }, ptr %l19
  %t485 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t481, { i64, [4 x i64] } %t482)
  store i32 %t485, ptr %l219
  br label %bb119
bb119:
  %t486 = load ptr, ptr %l2, !tbaa !29
  store ptr %t486, ptr %l220, !tbaa !29
  %t487 = load ptr, ptr %l3, !tbaa !29
  %t489 = getelementptr %"compiler/mir:Fn", ptr %t487, i32 0, i32 1
  %t490 = load i32, ptr %t489, !tbaa !23
  %t491 = load ptr, ptr %l220, !tbaa !29
  %t492 = call ptr @__olang_scope_or(ptr %v2, ptr %t491)
  %t493 = call ptr @__olang_scope_hold(ptr %t492)
  %t494 = ptrtoint ptr %t493 to i64
  %t496 = inttoptr i64 %t494 to ptr
  %t497 = load ptr, ptr %l220, !tbaa !29
  %t499 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t496, ptr %t497, i32 %t490)
  store i32 %t499, ptr %l224
  br label %bb120
bb120:
  %t500 = load ptr, ptr %l216, !tbaa !29
  %t501 = load i32, ptr %l219, !tbaa !23
  %t502 = load i32, ptr %l224, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s26, ptr %v2, ptr %t500, i32 %t501, i32 %t502, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d202, i32 0, i32 1) })
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s26)
  br label %bb196
bb122:
  %t503 = load { i64, [8 x i64] }, ptr %l1
  %t505 = extractvalue { i64, [8 x i64] } %t503, 0
  %t506 = icmp eq i64 %t505, 7
  br i1 %t506, label %bb123, label %bb124
bb123:
  %t508 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t509 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t508, i32 0, i32 1
  %t510 = load { i64, [4 x i64] }, ptr %t509
  store { i64, [4 x i64] } %t510, ptr %l20
  br label %bb125
bb124:
  br label %bb134
bb125:
  store %olang.scope zeroinitializer, ptr %s28
  %t512 = load ptr, ptr %l2, !tbaa !29
  store ptr %t512, ptr %l228, !tbaa !29
  %t513 = load ptr, ptr %l2, !tbaa !29
  store ptr %t513, ptr %l229, !tbaa !29
  %t514 = load ptr, ptr %l3, !tbaa !29
  %t516 = getelementptr %"compiler/mir:Fn", ptr %t514, i32 0, i32 1
  %t517 = load i32, ptr %t516, !tbaa !23
  %t518 = load ptr, ptr %l229, !tbaa !29
  %t519 = call ptr @__olang_scope_or(ptr %v2, ptr %t518)
  %t520 = call ptr @__olang_scope_hold(ptr %t519)
  %t521 = ptrtoint ptr %t520 to i64
  %t523 = inttoptr i64 %t521 to ptr
  %t524 = load ptr, ptr %l229, !tbaa !29
  %t526 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t523, ptr %t524, i32 %t517)
  store i32 %t526, ptr %l233
  br label %bb126
bb126:
  %t527 = load ptr, ptr %l228, !tbaa !29
  %t528 = call ptr @__olang_scope_or(ptr %v2, ptr %t527)
  %t529 = call ptr @__olang_scope_hold(ptr %t528)
  %t530 = ptrtoint ptr %t529 to i64
  %t532 = inttoptr i64 %t530 to ptr
  %t533 = load ptr, ptr %l228, !tbaa !29
  %t534 = load i32, ptr %l233, !tbaa !23
  %t535 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t532, ptr %s28, ptr %t533, i32 %t534)
  store { i64, ptr } %t535, ptr %l235
  br label %bb127
bb127:
  %t536 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  %t539 = icmp eq i64 %t537, 0
  br i1 %t539, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s29
  %t541 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t541, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s29)
  br label %bb131
bb131:
  %t543 = load ptr, ptr %l0, !tbaa !29
  store ptr %t543, ptr %l239, !tbaa !29
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load { i64, [4 x i64] }, ptr %l20
  %t548 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t544, { i64, [4 x i64] } %t545)
  store i32 %t548, ptr %l242
  br label %bb132
bb132:
  %t549 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t550 = load ptr, ptr %l239, !tbaa !29
  %t551 = load i32, ptr %l242, !tbaa !23
  %t553 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s28, ptr %v2, ptr %t550, i32 %t551, i32 %t549, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d204, i32 0, i32 1) })
  store i32 %t553, ptr %l244
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s28)
  br label %bb196
bb134:
  %t554 = load { i64, [8 x i64] }, ptr %l1
  %t556 = extractvalue { i64, [8 x i64] } %t554, 0
  %t557 = icmp eq i64 %t556, 8
  br i1 %t557, label %bb135, label %bb136
bb135:
  %t559 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t559, i32 0, i32 1
  %t561 = load i32, ptr %t560
  store i32 %t561, ptr %l21, !tbaa !23
  %t563 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t563, i32 0, i32 3
  %t565 = load i32, ptr %t564
  store i32 %t565, ptr %l22, !tbaa !23
  %t567 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t567, i32 0, i32 4
  %t569 = load i32, ptr %t568
  store i32 %t569, ptr %l23, !tbaa !23
  br label %bb137
bb136:
  br label %bb163
bb137:
  store %olang.scope zeroinitializer, ptr %s30
  %t571 = load ptr, ptr %l3, !tbaa !29
  %t573 = getelementptr %"compiler/mir:Fn", ptr %t571, i32 0, i32 8
  store ptr %t573, ptr %l251, !tbaa !29
  %t574 = load i32, ptr %l21, !tbaa !23
  %t576 = sext i32 %t574 to i64
  %t577 = load ptr, ptr %l251, !tbaa !29
  %t578 = call ptr @__olang_scope_or(ptr %v1, ptr %t577)
  %t579 = call ptr @__olang_scope_hold(ptr %t578)
  %t580 = ptrtoint ptr %t579 to i64
  %t582 = inttoptr i64 %t580 to ptr
  %t583 = load ptr, ptr %l251, !tbaa !29
  %t585 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t582, ptr %t583, i64 %t576)
  store %"compiler/mir:ScopeInfo" %t585, ptr %l255
  br label %bb138
bb138:
  %t586 = load %"compiler/mir:ScopeInfo", ptr %l255
  store %"compiler/mir:ScopeInfo" %t586, ptr %l24
  %t587 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t588 = load i32, ptr %t587, !range !{i32 0, i32 7}
  %t590 = trunc i64 3 to i32
  %t591 = icmp eq i32 %t588, %t590
  %t593 = xor i1 %t591, true
  br i1 %t593, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s31
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l21, !tbaa !23
  %t597 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t598 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t600 = sext i32 %t596 to i64
  %t601 = call i64 @__olang_fmt_i64(ptr null, i64 %t600)
  %t602 = add i64 %t598, %t601
  %t603 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t604 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t605 = add i64 %t602, %t604
  %t606 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t605)
  call void @olang_textcopy(ptr %t606, ptr %t597, i64 %t598)
  %t607 = getelementptr i8, ptr %t606, i64 %t598
  %t608 = call i64 @__olang_fmt_i64(ptr %t607, i64 %t600)
  %t609 = getelementptr i8, ptr %t607, i64 %t601
  call void @olang_textcopy(ptr %t609, ptr %t603, i64 %t604)
  %t610 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t606, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t595, { i64, ptr } %t611)
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  %t615 = load ptr, ptr %l2, !tbaa !29
  store ptr %t615, ptr %l263, !tbaa !29
  %t616 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t617 = load i32, ptr %t616, !tbaa !23
  %t618 = load ptr, ptr %l263, !tbaa !29
  %t619 = call ptr @__olang_scope_or(ptr %v2, ptr %t618)
  %t620 = call ptr @__olang_scope_hold(ptr %t619)
  %t621 = ptrtoint ptr %t620 to i64
  %t623 = inttoptr i64 %t621 to ptr
  %t624 = load ptr, ptr %l263, !tbaa !29
  %t626 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t623, ptr %s30, ptr %t624, i32 %t617)
  store { i64, ptr } %t626, ptr %l266
  br label %bb143
bb143:
  %t627 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t627, 0
  %t630 = icmp sgt i64 %t628, 0
  store i1 %t630, ptr %l25, !tbaa !21
  %t632 = load i1, ptr %l25, !tbaa !21
  br i1 %t632, label %bb144, label %bb145
bb144:
  %t634 = load i32, ptr %l23, !tbaa !23
  %t635 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t638 = icmp eq i32 %t634, %t635
  store i1 %t638, ptr %l270, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb146
bb146:
  %t640 = load i1, ptr %l270, !tbaa !21
  br i1 %t640, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s33
  %t641 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t641, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb149
bb148:
  br label %bb150
bb149:
  call void @__olang_scope_close(ptr %s33)
  br label %bb150
bb150:
  %t643 = load i1, ptr %l25, !tbaa !21
  %t645 = xor i1 %t643, true
  br i1 %t645, label %bb151, label %bb152
bb151:
  %t647 = load i32, ptr %l23, !tbaa !23
  %t648 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t651 = icmp ne i32 %t647, %t648
  store i1 %t651, ptr %l277, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb153
bb153:
  %t653 = load i1, ptr %l277, !tbaa !21
  br i1 %t653, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s34
  %t654 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s34, ptr %t654, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d208, i32 0, i32 1) })
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s34)
  br label %bb157
bb157:
  %t656 = load i32, ptr %l23, !tbaa !23
  %t657 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t660 = icmp ne i32 %t656, %t657
  br i1 %t660, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s35
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l285, !tbaa !29
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load i32, ptr %l22, !tbaa !23
  %t667 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %v1, ptr %t663, i32 %t664)
  store i32 %t667, ptr %l288
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t668 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t669 = load ptr, ptr %l285, !tbaa !29
  %t670 = load i32, ptr %l288, !tbaa !23
  %t672 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s35, ptr %v2, ptr %t669, i32 %t670, i32 %t668, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store i32 %t672, ptr %l290
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s35)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s30)
  br label %bb196
bb163:
  %t673 = load { i64, [8 x i64] }, ptr %l1
  %t675 = extractvalue { i64, [8 x i64] } %t673, 0
  %t676 = icmp eq i64 %t675, 9
  br i1 %t676, label %bb164, label %bb165
bb164:
  %t678 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t679 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t678, i32 0, i32 1
  %t680 = load i32, ptr %t679, !range !{i32 0, i32 20}
  store i32 %t680, ptr %l26
  %t682 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t683 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t682, i32 0, i32 2
  %t684 = load { i64, [4 x i64] }, ptr %t683
  store { i64, [4 x i64] } %t684, ptr %l27
  br label %bb166
bb165:
  br label %bb191
bb166:
  %t686 = load { i64, [4 x i64] }, ptr %l27
  %t688 = extractvalue { i64, [4 x i64] } %t686, 0
  %t689 = icmp eq i64 %t688, 0
  %t691 = xor i1 %t689, true
  br i1 %t691, label %bb167, label %bb168
bb167:
  %t693 = load i32, ptr %l26, !range !{i32 0, i32 20}
  %t695 = trunc i64 7 to i32
  %t696 = icmp eq i32 %t693, %t695
  %t698 = xor i1 %t696, true
  br i1 %t698, label %bb169, label %bb170
bb168:
  br label %bb190
bb169:
  %t700 = load i32, ptr %l26, !range !{i32 0, i32 20}
  %t702 = trunc i64 3 to i32
  %t703 = icmp eq i32 %t700, %t702
  %t705 = xor i1 %t703, true
  store i1 %t705, ptr %l301, !tbaa !21
  br label %bb171
bb170:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb171
bb171:
  %t707 = load i1, ptr %l301, !tbaa !21
  br i1 %t707, label %bb172, label %bb173
bb172:
  %t708 = load i32, ptr %l26, !range !{i32 0, i32 20}
  %t710 = trunc i64 14 to i32
  %t711 = icmp eq i32 %t708, %t710
  %t713 = xor i1 %t711, true
  store i1 %t713, ptr %l305, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb174
bb174:
  %t715 = load i1, ptr %l305, !tbaa !21
  br i1 %t715, label %bb175, label %bb176
bb175:
  %t716 = load i32, ptr %l26, !range !{i32 0, i32 20}
  %t718 = trunc i64 15 to i32
  %t719 = icmp eq i32 %t716, %t718
  %t721 = xor i1 %t719, true
  store i1 %t721, ptr %l309, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb177
bb177:
  %t723 = load i1, ptr %l309, !tbaa !21
  br i1 %t723, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s38
  %t724 = load ptr, ptr %l0, !tbaa !29
  store ptr %t724, ptr %l313, !tbaa !29
  %t725 = load i32, ptr %l26, !range !{i32 0, i32 20}
  store i32 %t725, ptr %l314
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s39
  store ptr %s39room, ptr %s39
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s39, ptr %l314, i64 0)
  br label %bb180
bb179:
  br label %bb183
bb180:
  %t727 = load ptr, ptr %s39
  %t728 = getelementptr %olang.builder, ptr %s39, i32 0, i32 1
  %t729 = load i64, ptr %t728
  %t730 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t729)
  call void @olang_textcopy(ptr %t730, ptr %t727, i64 %t729)
  %t731 = insertvalue { i64, ptr } undef, i64 %t729, 0
  %t732 = insertvalue { i64, ptr } %t731, ptr %t730, 1
  store { i64, ptr } %t732, ptr %l316, !tbaa !27
  %t733 = getelementptr %olang.builder, ptr %s39, i32 0, i32 3
  %t734 = load ptr, ptr %t733
  %t735 = icmp ne ptr %t734, null
  br i1 %t735, label %sbgrew.736, label %sbdone.737
sbgrew.736:
  call void @__olang_sb_done(ptr %s39)
  br label %sbdone.737
sbdone.737:
  %t738 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t740 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s38, ptr %s38, { i64, ptr } %t738)
  store { i64, ptr } %t740, ptr %l318
  br label %bb181
bb181:
  %t741 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t743 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t743, 1
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t746 = add i64 %t742, %t745
  %t747 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t748 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t749 = add i64 %t746, %t748
  %t750 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t749)
  call void @olang_textcopy(ptr %t750, ptr %t741, i64 %t742)
  %t751 = getelementptr i8, ptr %t750, i64 %t742
  call void @olang_textcopy(ptr %t751, ptr %t744, i64 %t745)
  %t752 = getelementptr i8, ptr %t751, i64 %t745
  call void @olang_textcopy(ptr %t752, ptr %t747, i64 %t748)
  %t753 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t750, 1
  %t756 = load ptr, ptr %l313, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s38, ptr %t756, { i64, ptr } %t754)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s38)
  br label %bb183
bb183:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l321, !tbaa !29
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t760 = load { i64, [4 x i64] }, ptr %l27
  %t763 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %t759, { i64, [4 x i64] } %t760)
  store i32 %t763, ptr %l324
  br label %bb184
bb184:
  %t764 = load ptr, ptr %l321, !tbaa !29
  %t765 = load i32, ptr %l324, !tbaa !23
  %t766 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %v2, ptr %t764, i32 %t765)
  store i1 %t766, ptr %l325
  br label %bb185
bb185:
  %t767 = load i1, ptr %l325, !tbaa !21
  %t768 = xor i1 %t767, true
  br i1 %t768, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s41
  %t770 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s41, ptr %t770, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d212, i32 0, i32 1) })
  br label %bb188
bb187:
  br label %bb189
bb188:
  call void @__olang_scope_close(ptr %s41)
  br label %bb189
bb189:
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7)
  unreachable
bb196:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %v1, ptr %t1, { i64, [1 x i64] } %a1)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %v2, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %v2, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l12
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t19, i64 %t20)
  %t26 = getelementptr i8, ptr %t25, i64 %t20
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  %t30 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t30, { i64, ptr } %t28)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t32 = load i32, ptr %l2, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca { i64, [21 x i64] }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  store ptr %t8, ptr %l20, !tbaa !29
  %t9 = load ptr, ptr %l20, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v1, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t14, ptr %t15)
  store i64 %t16, ptr %l22
  br label %bb1
bb1:
  %t17 = load i64, ptr %l22, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l29, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l29, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l7, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:verifier", ptr %t64, i32 0, i32 13
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l48, !tbaa !27
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i1, ptr %t71, i64 %t68
  %t73 = load i1, ptr %t72, !tbaa !31
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb12, label %bb13
bb12:
  br label %bb32
bb13:
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = getelementptr %"compiler/mir:verifier", ptr %t77, i32 0, i32 3
  store i64 %t78, ptr %t81, !tbaa !24
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/mir:Fn", ptr %t82, i32 0, i32 9
  store ptr %t84, ptr %l55, !tbaa !29
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load ptr, ptr %l55, !tbaa !29
  %t87 = call ptr @__olang_scope_or(ptr %v1, ptr %t86)
  %t88 = call ptr @__olang_scope_hold(ptr %t87)
  %t89 = ptrtoint ptr %t88 to i64
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/mir:verifier", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = call ptr @__olang_scope_or(ptr %v1, ptr %t93)
  %t96 = call ptr @__olang_scope_hold(ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t89 to ptr
  %t101 = inttoptr i64 %t97 to ptr
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t99, ptr %t101, ptr %t102, i64 %t85)
  store ptr %t104, ptr %l61
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l61, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/mir:BasicBlock", ptr %t106, i32 0, i32 0
  store ptr %t108, ptr %l63, !tbaa !29
  %t109 = load ptr, ptr %l63, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v1, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %t114, ptr %t115)
  store i64 %t116, ptr %l65
  br label %bb16
bb16:
  %t117 = load i64, ptr %l65, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb17, label %bb18
bb17:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb22
bb19:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l72, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t144 = load i64, ptr %l72, !tbaa !24
  store i64 %t144, ptr %l69, !tbaa !24
  br label %bb22
bb22:
  %t145 = load i64, ptr %l69, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l14, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = getelementptr %"compiler/mir:verifier", ptr %t164, i32 0, i32 4
  store i64 %t165, ptr %t168, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/mir:BasicBlock", ptr %t170, i32 0, i32 0
  store ptr %t172, ptr %l94, !tbaa !29
  %t173 = load i64, ptr %l14, !tbaa !24
  %t174 = load ptr, ptr %l94, !tbaa !29
  %t175 = call ptr @__olang_scope_or(ptr %v1, ptr %t174)
  %t176 = call ptr @__olang_scope_hold(ptr %t175)
  %t177 = ptrtoint ptr %t176 to i64
  %t179 = inttoptr i64 %t177 to ptr
  %t180 = load ptr, ptr %l94, !tbaa !29
  %t182 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t179, ptr %t180, i64 %t173)
  store { i64, [21 x i64] } %t182, ptr %l97
  br label %bb27
bb27:
  %t183 = load { i64, [21 x i64] }, ptr %l97
  %t184 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t183, ptr %t184
  %t185 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %s5, ptr %v1, ptr %v2, ptr %t185, ptr %t184)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t187, 1
  store i64 %t190, ptr %l13, !tbaa !24
  br label %bb23
bb30:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/mir:verifier", ptr %t192, i32 0, i32 4
  store i64 -1, ptr %t194, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l8, !tbaa !29
  %t198 = getelementptr %"compiler/mir:BasicBlock", ptr %t196, i32 0, i32 1
  %t199 = load { i64, [8 x i64] }, ptr %t198
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %v1, ptr %v2, ptr %t195, { i64, [8 x i64] } %t199)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t202 = load i64, ptr %l6, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l6, !tbaa !24
  br label %bb8
bb33:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/mir:verifier", ptr %t207, i32 0, i32 3
  store i64 -1, ptr %t211, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t212, i32 0, i32 4
  store i64 -1, ptr %t216, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i1
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l149 = alloca i64
  %l152 = alloca i64
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l180 = alloca i32
  %l187 = alloca ptr
  %l193 = alloca ptr
  %l195 = alloca ptr
  %l197 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l224 = alloca ptr
  %l226 = alloca ptr
  %l229 = alloca { i64, [21 x i64] }
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  store ptr %t8, ptr %l34, !tbaa !29
  %t9 = load ptr, ptr %l34, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v1, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l34, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t14, ptr %t15)
  store i64 %t16, ptr %l36
  br label %bb1
bb1:
  %t17 = load i64, ptr %l36, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 8
  store ptr %t20, ptr %l38, !tbaa !29
  %t21 = load ptr, ptr %l38, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v1, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l38, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t26, ptr %t27)
  store i64 %t28, ptr %l40
  br label %bb2
bb2:
  %t29 = load i64, ptr %l40, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  %t32 = sext i32 %a1 to i64
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb3, label %bb4
bb3:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb8
bb5:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l50, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb7
bb7:
  %t62 = load i64, ptr %l50, !tbaa !24
  store i64 %t62, ptr %l47, !tbaa !24
  br label %bb8
bb8:
  %t63 = load i64, ptr %l47, !tbaa !24
  store i64 %t63, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = sub i64 %t64, 1
  store i64 %t65, ptr %l59, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp slt i64 %t66, 2147483648
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  %t72 = and i1 %t67, %t69
  store i1 %t72, ptr %l62, !tbaa !21
  br label %bb9
bb9:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l11, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/mir:verifier", ptr %t91, i32 0, i32 14
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l73, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/mir:verifier", ptr %t96, i32 0, i32 7
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l76, !tbaa !27
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i1, ptr %t111, i64 %t108
  %t113 = load i1, ptr %t112, !tbaa !31
  %t116 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i1, ptr %t117, i64 %t95
  store i1 %t113, ptr %t118, !tbaa !31
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/mir:verifier", ptr %t119, i32 0, i32 15
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l84, !tbaa !27
  %t123 = load i64, ptr %l11, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/mir:verifier", ptr %t124, i32 0, i32 8
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l87, !tbaa !27
  %t128 = load i64, ptr %l5, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i1, ptr %t139, i64 %t136
  %t141 = load i1, ptr %t140, !tbaa !31
  %t144 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i1, ptr %t145, i64 %t123
  store i1 %t141, ptr %t146, !tbaa !31
  br label %bb13
bb13:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l10, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l4, !tbaa !24
  store i64 %t152, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = icmp sgt i64 %t154, %t155
  br i1 %t158, label %bb15, label %bb16
bb15:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb20
bb17:
  %t164 = load i64, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = add i64 %t168, %t169
  %t174 = sub i64 %t172, 1
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = sdiv i64 %t174, %t175
  store i64 %t178, ptr %l104, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb19
bb19:
  %t180 = load i64, ptr %l104, !tbaa !24
  store i64 %t180, ptr %l101, !tbaa !24
  br label %bb20
bb20:
  %t181 = load i64, ptr %l101, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t183 = sub i64 %t182, 1
  store i64 %t183, ptr %l113, !tbaa !24
  %t184 = load i64, ptr %l15, !tbaa !24
  %t185 = icmp slt i64 %t184, 2147483648
  %t186 = load i64, ptr %l16, !tbaa !24
  %t187 = icmp sge i64 %t186, 0
  %t190 = and i1 %t185, %t187
  store i1 %t190, ptr %l116, !tbaa !21
  br label %bb21
bb21:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l17, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/mir:verifier", ptr %t209, i32 0, i32 16
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l127, !tbaa !27
  %t213 = load i64, ptr %l17, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t214, i32 0, i32 9
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l130, !tbaa !27
  %t218 = load i64, ptr %l5, !tbaa !24
  %t219 = load i64, ptr %l4, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i1, ptr %t229, i64 %t226
  %t231 = load i1, ptr %t230, !tbaa !31
  %t234 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i1, ptr %t235, i64 %t213
  store i1 %t231, ptr %t236, !tbaa !31
  br label %bb25
bb25:
  %t237 = load i64, ptr %l16, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l16, !tbaa !24
  br label %bb21
bb26:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/mir:verifier", ptr %t242, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t244)
  br label %bb27
bb27:
  store i64 0, ptr %l18, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/mir:verifier", ptr %t246, i32 0, i32 11
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l143, !tbaa !27
  %t250 = load i64, ptr %l5, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i64, ptr %t253, i64 %t250
  %t255 = load i64, ptr %t254, !tbaa !34
  store i64 %t255, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t257 = load i64, ptr %l19, !tbaa !24
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = icmp sgt i64 %t257, %t258
  br i1 %t261, label %bb28, label %bb29
bb28:
  %t263 = load i64, ptr %l20, !tbaa !24
  %t265 = icmp sgt i64 %t263, 0
  br i1 %t265, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb33
bb30:
  %t267 = load i64, ptr %l19, !tbaa !24
  %t268 = load i64, ptr %l18, !tbaa !24
  %t271 = sub i64 %t267, %t268
  %t272 = load i64, ptr %l20, !tbaa !24
  %t275 = add i64 %t271, %t272
  %t277 = sub i64 %t275, 1
  %t278 = load i64, ptr %l20, !tbaa !24
  %t281 = sdiv i64 %t277, %t278
  store i64 %t281, ptr %l152, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb32
bb32:
  %t283 = load i64, ptr %l152, !tbaa !24
  store i64 %t283, ptr %l149, !tbaa !24
  br label %bb33
bb33:
  %t284 = load i64, ptr %l149, !tbaa !24
  store i64 %t284, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb34
bb34:
  %t285 = load i64, ptr %l22, !tbaa !24
  %t286 = load i64, ptr %l21, !tbaa !24
  %t289 = icmp slt i64 %t285, %t286
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load i64, ptr %l22, !tbaa !24
  %t295 = load i64, ptr %l20, !tbaa !24
  %t298 = mul i64 %t294, %t295
  %t301 = add i64 %t293, %t298
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/mir:verifier", ptr %t303, i32 0, i32 17
  store ptr %t305, ptr %l171, !tbaa !29
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/mir:verifier", ptr %t306, i32 0, i32 12
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/mir:verifier", ptr %t309, i32 0, i32 10
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  store { i64, ptr } %t312, ptr %l175, !tbaa !27
  %t313 = load i64, ptr %l5, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i64, ptr %t316, i64 %t313
  %t318 = load i64, ptr %t317, !tbaa !34
  %t322 = add i64 %t318, %t301
  %t325 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t308, i64 %t322)
  store i32 %t325, ptr %l180
  br label %bb38
bb38:
  %t326 = load ptr, ptr %l171, !tbaa !29
  %t327 = load i32, ptr %l180, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t326, i32 %t327)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t328, 1
  store i64 %t331, ptr %l22, !tbaa !24
  br label %bb34
bb41:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i64, ptr %l5, !tbaa !24
  %t337 = getelementptr %"compiler/mir:verifier", ptr %t333, i32 0, i32 3
  store i64 %t334, ptr %t337, !tbaa !24
  %t338 = load ptr, ptr %l2, !tbaa !29
  %t340 = getelementptr %"compiler/mir:Fn", ptr %t338, i32 0, i32 9
  store ptr %t340, ptr %l187, !tbaa !29
  %t341 = load i64, ptr %l5, !tbaa !24
  %t342 = load ptr, ptr %l187, !tbaa !29
  %t343 = call ptr @__olang_scope_or(ptr %v1, ptr %t342)
  %t344 = call ptr @__olang_scope_hold(ptr %t343)
  %t345 = ptrtoint ptr %t344 to i64
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/mir:verifier", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = call ptr @__olang_scope_or(ptr %v1, ptr %t349)
  %t352 = call ptr @__olang_scope_hold(ptr %t351)
  %t353 = ptrtoint ptr %t352 to i64
  %t355 = inttoptr i64 %t345 to ptr
  %t357 = inttoptr i64 %t353 to ptr
  %t358 = load ptr, ptr %l187, !tbaa !29
  %t360 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t355, ptr %t357, ptr %t358, i64 %t341)
  store ptr %t360, ptr %l193
  br label %bb42
bb42:
  %t361 = load ptr, ptr %l193, !tbaa !29
  store ptr %t361, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  %t362 = load ptr, ptr %l24, !tbaa !29
  %t364 = getelementptr %"compiler/mir:BasicBlock", ptr %t362, i32 0, i32 0
  store ptr %t364, ptr %l195, !tbaa !29
  %t365 = load ptr, ptr %l195, !tbaa !29
  %t366 = call ptr @__olang_scope_or(ptr %v1, ptr %t365)
  %t367 = call ptr @__olang_scope_hold(ptr %t366)
  %t368 = ptrtoint ptr %t367 to i64
  %t370 = inttoptr i64 %t368 to ptr
  %t371 = load ptr, ptr %l195, !tbaa !29
  %t372 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %t370, ptr %t371)
  store i64 %t372, ptr %l197
  br label %bb43
bb43:
  %t373 = load i64, ptr %l197, !tbaa !24
  store i64 %t373, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t374 = load i64, ptr %l26, !tbaa !24
  %t375 = load i64, ptr %l25, !tbaa !24
  %t378 = icmp sgt i64 %t374, %t375
  br i1 %t378, label %bb44, label %bb45
bb44:
  %t380 = load i64, ptr %l27, !tbaa !24
  %t382 = icmp sgt i64 %t380, 0
  br i1 %t382, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb49
bb46:
  %t384 = load i64, ptr %l26, !tbaa !24
  %t385 = load i64, ptr %l25, !tbaa !24
  %t388 = sub i64 %t384, %t385
  %t389 = load i64, ptr %l27, !tbaa !24
  %t392 = add i64 %t388, %t389
  %t394 = sub i64 %t392, 1
  %t395 = load i64, ptr %l27, !tbaa !24
  %t398 = sdiv i64 %t394, %t395
  store i64 %t398, ptr %l204, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb48
bb48:
  %t400 = load i64, ptr %l204, !tbaa !24
  store i64 %t400, ptr %l201, !tbaa !24
  br label %bb49
bb49:
  %t401 = load i64, ptr %l201, !tbaa !24
  store i64 %t401, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t402 = load i64, ptr %l29, !tbaa !24
  %t403 = load i64, ptr %l28, !tbaa !24
  %t406 = icmp slt i64 %t402, %t403
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t410 = load i64, ptr %l25, !tbaa !24
  %t411 = load i64, ptr %l29, !tbaa !24
  %t412 = load i64, ptr %l27, !tbaa !24
  %t415 = mul i64 %t411, %t412
  %t418 = add i64 %t410, %t415
  store i64 %t418, ptr %l30, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i64, ptr %l30, !tbaa !24
  %t424 = getelementptr %"compiler/mir:verifier", ptr %t420, i32 0, i32 4
  store i64 %t421, ptr %t424, !tbaa !24
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l224, !tbaa !29
  %t426 = load ptr, ptr %l24, !tbaa !29
  %t428 = getelementptr %"compiler/mir:BasicBlock", ptr %t426, i32 0, i32 0
  store ptr %t428, ptr %l226, !tbaa !29
  %t429 = load i64, ptr %l30, !tbaa !24
  %t430 = load ptr, ptr %l226, !tbaa !29
  %t431 = call ptr @__olang_scope_or(ptr %v1, ptr %t430)
  %t432 = call ptr @__olang_scope_hold(ptr %t431)
  %t433 = ptrtoint ptr %t432 to i64
  %t435 = inttoptr i64 %t433 to ptr
  %t436 = load ptr, ptr %l226, !tbaa !29
  %t438 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t435, ptr %t436, i64 %t429)
  store { i64, [21 x i64] } %t438, ptr %l229
  br label %bb54
bb54:
  %t439 = load { i64, [21 x i64] }, ptr %l229
  %t440 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t439, ptr %t440
  %t441 = load ptr, ptr %l224, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %s11, ptr %v1, ptr %t441, ptr %t440)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb56:
  %t443 = load i64, ptr %l29, !tbaa !24
  %t446 = add i64 %t443, 1
  store i64 %t446, ptr %l29, !tbaa !24
  br label %bb50
bb57:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/mir:verifier", ptr %t448, i32 0, i32 4
  store i64 -1, ptr %t450, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l24, !tbaa !29
  %t454 = getelementptr %"compiler/mir:BasicBlock", ptr %t452, i32 0, i32 1
  %t455 = load { i64, [8 x i64] }, ptr %t454
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %v1, ptr %t451, { i64, [8 x i64] } %t455)
  br label %bb58
bb58:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_scope_or(ptr, ptr)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" err L" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d13 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch#" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C (" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" + " }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"live L" }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"dead L" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"open S" }>, align 8
@.d27 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"close S" }>, align 8
@.d28 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"register dtor " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"release " }>, align 8
@.d32 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"release slot " }>, align 8
@.d33 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"release part " }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"settle L" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"drop L" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 8}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d40 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"copy " }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" from " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d43 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"spawn in S" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raised" }>, align 8
@.d46 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"payload set " }>, align 8
@.d47 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"payload pop" }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"holders " }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"reclaim " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d52 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" keeping (" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d54 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" cleanup bb" }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" runs" }>, align 8
@.d56 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"deferred at S" }>, align 8
@.d57 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"(no terminator)" }>, align 8
@.d58 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"goto bb" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"branch " }>, align 8
@.d60 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d61 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d63 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"] else bb" }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d69 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
@.d70 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
@.d71 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" holding " }>, align 8
@.d72 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" dropped bb" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"dropped" }>, align 8
@.d74 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" failed L" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"wait S" }>, align 8
@.d78 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 20}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
ret:
  ret void
}

@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d81 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d82 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"resume" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d84 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" made of " }>, align 8
@.d85 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d86 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"element " }>, align 8
@.d87 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no case " }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" in a " }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d90 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" made of parts" }>, align 8
@.d91 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"a call of " }>, align 8
@.d92 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" arguments to a function of " }>, align 8
@.d93 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" parameters" }>, align 8
@.d94 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"argument " }>, align 8
@.d95 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a call passing " }>, align 8
@.d96 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" scopes for its callee's " }>, align 8
@.d97 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a call passing the frame for a scope variable" }>, align 8
@.d98 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn: " }>, align 8
@.d99 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d100 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"[term]: " }>, align 8
@.d101 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d103 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"]: " }>, align 8
@.d104 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a function value typed " }>, align 8
@.d105 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"constant " }>, align 8
@.d106 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" holds constant " }>, align 8
@.d107 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", not made before it" }>, align 8
@.d108 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array typed " }>, align 8
@.d109 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a run-time-length array" }>, align 8
@.d110 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a new array's length that is no integer" }>, align 8
@.d111 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array's fill" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 54}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 i64 43, label %bb45 i64 44, label %bb46 i64 45, label %bb47 i64 46, label %bb48 i64 47, label %bb49 i64 48, label %bb50 i64 49, label %bb51 i64 50, label %bb52 i64 51, label %bb53 i64 52, label %bb54 i64 53, label %bb55 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
bb45:
  %t91 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t91, i64 %t92)
  br label %bb1
bb46:
  %t93 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t93, i64 %t94)
  br label %bb1
bb47:
  %t95 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t95, i64 %t96)
  br label %bb1
bb48:
  %t97 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t97, i64 %t98)
  br label %bb1
bb49:
  %t99 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t99, i64 %t100)
  br label %bb1
bb50:
  %t101 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t101, i64 %t102)
  br label %bb1
bb51:
  %t103 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t103, i64 %t104)
  br label %bb1
bb52:
  %t105 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t105, i64 %t106)
  br label %bb1
bb53:
  %t107 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t107, i64 %t108)
  br label %bb1
bb54:
  %t109 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t109, i64 %t110)
  br label %bb1
bb55:
  %t111 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t111, i64 %t112)
  br label %bb1
ret:
  ret void
}

@.d112 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"no overflow test for " }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d114 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" operands" }>, align 8
@.d115 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an overflow test of " }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d117 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", not an integer" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d120 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", but it is not open" }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d123 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" while S" }>, align 8
@.d124 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", opened in it, is open" }>, align 8
@olang_2esole_2ecompiler_2fmir_3averifier_2e13 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_region_release(ptr) noinline
define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"compiler/mir:StmtList"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %t3)
  store %"compiler/mir:StmtList" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:StmtList", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"compiler/mir:StmtList" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

@.d125 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"unreachable: no path from the entry" }>, align 8
@.d126 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a reference typed " }>, align 8
@.d127 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a reference " }>, align 8
@.d128 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d129 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the region of a " }>, align 8
@.d130 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error code" }>, align 8
@.d131 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d132 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d133 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no blocks" }>, align 8
@.d134 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"its type is no function type" }>, align 8
@.d135 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"its type has " }>, align 8
@.d136 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" parameters, its Params " }>, align 8
@.d137 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d138 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" is local L" }>, align 8
@.d139 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not a Param" }>, align 8
@.d140 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d142 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", its type says " }>, align 8
@.d143 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"capture L" }>, align 8
@.d144 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is no Capture local" }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d146 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" has the Unknown type" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d148 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"'s parent S" }>, align 8
@.d149 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" is not opened before it" }>, align 8
@.d150 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a task's copies are not one per target" }>, align 8
@.d151 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a task's handlers are given more than one scope" }>, align 8
@.d152 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"targets" }>, align 8
@.d153 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"clauses" }>, align 8
@.d154 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"items" }>, align 8
@.d155 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"bytes" }>, align 8
@.d156 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"constant items" }>, align 8
@.d157 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no task " }>, align 8
@.d158 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the value stored" }>, align 8
@.d159 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d160 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", not a reference to a " }>, align 8
@.d161 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d162 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", which has none to run" }>, align 8
@.d163 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a release of a " }>, align 8
@.d164 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a reference or an owner" }>, align 8
@.d165 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a part release of a " }>, align 8
@.d166 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", not an array held by value" }>, align 8
@.d167 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a settle of a " }>, align 8
@.d168 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", not an owner" }>, align 8
@.d169 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d170 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" write of a " }>, align 8
@.d171 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"elements copied between places that are not both arrays" }>, align 8
@.d172 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"elements copied between a " }>, align 8
@.d173 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d174 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a count of copied elements that is no integer" }>, align 8
@.d175 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a spawn into S" }>, align 8
@.d176 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d177 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a task with " }>, align 8
@.d178 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" targets for " }>, align 8
@.d179 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" results" }>, align 8
@.d180 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"a task's clauses for a call that cannot fail" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d181 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the case of a " }>, align 8
@.d182 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not an enum" }>, align 8
@.d183 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a task's result " }>, align 8
@.d184 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no terminator" }>, align 8
@.d185 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cases" }>, align 8
@.d186 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no call " }>, align 8
@.d187 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"scope refs" }>, align 8
@.d188 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"a walk's drop ended in a function that is no generator's" }>, align 8
@.d189 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a branch on a " }>, align 8
@.d190 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a switch on a " }>, align 8
@.d191 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a call with no result stores one" }>, align 8
@.d192 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the call's result" }>, align 8
@.d193 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a call that can fail with no error edge" }>, align 8
@.d194 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"an error edge for a call that cannot fail" }>, align 8
@.d195 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the call's error code" }>, align 8
@.d196 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a tail call with somewhere to go after it" }>, align 8
@.d197 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a tail call giving another result than the function's" }>, align 8
@.d198 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a return with no value from a function giving a " }>, align 8
@.d199 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"a return with a value from a function giving none" }>, align 8
@.d200 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"the value returned" }>, align 8
@.d201 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a suspend in a function that is no generator's" }>, align 8
@.d202 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the value yielded" }>, align 8
@.d203 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a raise in a function that cannot fail" }>, align 8
@.d204 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the error raised" }>, align 8
@.d205 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a wait for S" }>, align 8
@.d206 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d207 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a wait for a join that can fail with no failed edge" }>, align 8
@.d208 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a failed edge for a join that cannot fail" }>, align 8
@.d209 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the join's error code" }>, align 8
@.d210 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a message for a " }>, align 8
@.d211 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" exit" }>, align 8
@.d212 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an assert's message that is no text" }>, align 8
@.d213 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"text typed " }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d214 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.WriteKind.Bytes" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d215 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.WriteKind.Quoted" }>, align 8
@.d216 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Char" }>, align 8
@.d217 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.WriteKind.QuotedChar" }>, align 8
@.d218 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.WriteKind.Int" }>, align 8
@.d219 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Uint" }>, align 8
@.d220 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.WriteKind.Float" }>, align 8
@.d221 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Bool" }>, align 8
@.d222 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.ExitKind.Done" }>, align 8
@.d223 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.ExitKind.Fail" }>, align 8
@.d224 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ExitKind.Abort" }>, align 8
@.d225 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.Unreachable" }>, align 8
@.d226 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.NullReached" }>, align 8
@.d227 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.ExitKind.NullError" }>, align 8
@.d228 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.ExitKind.Unhandled" }>, align 8
@.d229 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.ExitKind.Assert" }>, align 8
@.d230 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.SliceBounds" }>, align 8
@.d231 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.ArrayLength" }>, align 8
@.d232 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"mir.ExitKind.As" }>, align 8
@.d233 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.FixedLength" }>, align 8
@.d234 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"mir.ExitKind.LaneLength" }>, align 8
@.d235 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"mir.ExitKind.GenRunning" }>, align 8
@.d236 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ExitKind.Error" }>, align 8
@.d237 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.ExitKind.Escaped" }>, align 8
@.d238 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.IndexBounds" }>, align 8
@.d239 = private unnamed_addr constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"mir.ExitKind.DivideByZero" }>, align 8
@.d240 = private unnamed_addr constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"mir.ExitKind.DivideOverflow" }>, align 8
@.d241 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.ShiftAmount" }>, align 8
@.d242 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Neg" }>, align 8
@.d243 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitNot" }>, align 8
@.d244 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Not" }>, align 8
@.d245 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Add" }>, align 8
@.d246 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Sub" }>, align 8
@.d247 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Mul" }>, align 8
@.d248 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Div" }>, align 8
@.d249 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Rem" }>, align 8
@.d250 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shl" }>, align 8
@.d251 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shr" }>, align 8
@.d252 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitAnd" }>, align 8
@.d253 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.BitOr" }>, align 8
@.d254 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitXor" }>, align 8
@.d255 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Eq" }>, align 8
@.d256 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ne" }>, align 8
@.d257 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Lt" }>, align 8
@.d258 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Le" }>, align 8
@.d259 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Gt" }>, align 8
@.d260 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ge" }>, align 8
@.d261 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Same" }>, align 8
@.d262 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Convert" }>, align 8
@.d263 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Bitcast" }>, align 8
@.d264 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Len" }>, align 8
@.d265 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.IsCase" }>, align 8
@.d266 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicLoad" }>, align 8
@.d267 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AtomicStore" }>, align 8
@.d268 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.AtomicAdd" }>, align 8
@.d269 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicSwap" }>, align 8
@.d270 = private unnamed_addr constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"typed.PrimOp.AtomicCompareSwap" }>, align 8
@.d271 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Retire" }>, align 8
@.d272 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.GrowInPlace" }>, align 8
@.d273 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Drop" }>, align 8
@.d274 = private unnamed_addr constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"typed.PrimOp.LeadingZeros" }>, align 8
@.d275 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.PrimOp.TrailingZeros" }>, align 8
@.d276 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.PopCount" }>, align 8
@.d277 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.RotateLeft" }>, align 8
@.d278 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.RotateRight" }>, align 8
@.d279 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ByteSwap" }>, align 8
@.d280 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.LaneLen" }>, align 8
@.d281 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.NonEmpty" }>, align 8
@.d282 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.LaneDot" }>, align 8
@.d283 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.LaneDots" }>, align 8
@.d284 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Unpack" }>, align 8
@.d285 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Repack" }>, align 8
@.d286 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.AnyMake" }>, align 8
@.d287 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AnyInstance" }>, align 8
@.d288 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.AnyIs" }>, align 8
@.d289 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.ErrPush" }>, align 8
@.d290 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.ErrCaught" }>, align 8
@.d291 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ErrTaken" }>, align 8
@.d292 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatAdd" }>, align 8
@.d293 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatSub" }>, align 8
@.d294 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatMul" }>, align 8
@.d295 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatShl" }>, align 8
define linkonce_odr %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:StmtList"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:StmtList"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:StmtList", ptr %a0
  store %"compiler/mir:StmtList" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/mir:StmtList", ptr %l1
  store %"compiler/mir:StmtList" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:StmtList", ptr %rv
  ret %"compiler/mir:StmtList" %rr
}

declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare void @compiler_2fmir_2eFn_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_f3abe41a98405543_7d26227a2bded35f = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2etarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1, ptr %a2, ptr %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erefMentions(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eopMentions(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eplaceMentions(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ePush_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2ecalleeMentions(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1, ptr %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2erangeMentions(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, ptr %a2)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_769ae05158a21e45_1e3756f4622c6ab9 = external constant [0 x i8]
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_db3046abc31727db_4ab50a6c65a9ddb7 = external constant [0 x i8]
@olang_loc_6ed074f69d52fee5_6027e9a1c2de62d1 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2erunArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2enote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Range" %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [15 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_63d4bc85d5a0ee63_941776bd89ba250f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_8b20d2ead933ce67_842549c98b36ec43 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd = external constant [0 x i8]
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
@olang_loc_2214b4a83e210b00_93c2dace4d13d4cc = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_43daeee16a7347fc_3936ff71893c42a0 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f7be8aa76db69854_ffaa205b85e46cd8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
@olang_loc_525ae97147cf6b9b_c46e40fbd793c77f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
@olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6 = external constant [0 x i8]
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7127dab5ce57c749_b077692428e4994d = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3d9554dfcf1aeb63_1386be72809b2127 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_729af306d1a375bd_3b9d78bce782a851 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
@olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_145fd452f8e36c9b_ff9c6902187c9987 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eGuardOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [7 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22 = external constant [0 x i8]
@olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7 = external constant [0 x i8]
@olang_loc_4f65b4158cb36c84_7aab915b507980 = external constant [0 x i8]
@olang_loc_4fdb0c87eb50ced7_f9856407ece22343 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
