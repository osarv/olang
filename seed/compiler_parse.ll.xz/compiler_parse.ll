; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
@G_2ecompiler_2fparse_2eMaxNesting = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fparse_2eMaxNesting_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 20000, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l17 = alloca ptr
  %l28 = alloca i64
  %l31 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca ptr
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i32
  %l72 = alloca ptr
  %l84 = alloca ptr
  %l91 = alloca i1
  %l96 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t93 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 88)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l12
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l12, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l1, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 15
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 15
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 16
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l2, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 17
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 16
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 17
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 27
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l28
  br label %bb4
bb4:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 89)
  store i1 %t63, ptr %l31
  br label %bb6
bb6:
  %t64 = load i1, ptr %l31, !tbaa !21
  %t65 = xor i1 %t64, true
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb8:
  br label %bb9
bb9:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 44)
  store i1 %t72, ptr %l36
  br label %bb10
bb10:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t74)
  store i32 %t76, ptr %l38
  br label %bb13
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t77)
  %t80 = extractvalue { i32, ptr } %t79, 1
  %t81 = extractvalue { i32, ptr } %t79, 0
  store i32 %t81, ptr %l49
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb17, label %ok.83
ok.83:
  store ptr %t80, ptr %l48
  br label %bb16
bb13:
  %t84 = load i32, ptr %l38, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 27
  store ptr %t87, ptr %l40, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t88, i32 %t84)
  store %"compiler/source:Span" %t92, ptr %l43
  br label %bb14
bb14:
  store { i64, [5 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 0
  store i64 26, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l43
  %t96 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t95, 0
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span" } %t96, ptr %t97
  %t98 = load { i64, [5 x i64] }, ptr %t93
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t101, ptr %t100)
  br label %bb15
bb15:
  br label %bb22
bb16:
  %t103 = load ptr, ptr %l48, !tbaa !29
  store ptr %t103, ptr %l46, !tbaa !29
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 27
  %t107 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t106, i64 %t107)
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l53, !tbaa !29
  %t111 = load ptr, ptr %l53, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 15
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = sub i64 %t113, 1
  %t117 = load ptr, ptr %l53, !tbaa !29
  %t118 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 15
  store i64 %t115, ptr %t118, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l2, !tbaa !21
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t119, i32 0, i32 16
  store i1 %t120, ptr %t123, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i1, ptr %l3, !tbaa !21
  %t128 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 17
  store i1 %t125, ptr %t128, !tbaa !21
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb20:
  %t131 = load ptr, ptr %l46, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/parse:Parser", ptr %t132, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t134, ptr %t131)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t141 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t138, i32 89)
  %t142 = extractvalue { i32, i1 } %t141, 1
  %t143 = extractvalue { i32, i1 } %t141, 0
  store i32 %t143, ptr %l68
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb24, label %ok.145
ok.145:
  store i1 %t142, ptr %l67
  br label %bb23
bb23:
  %t146 = load i1, ptr %l67, !tbaa !21
  store i1 %t146, ptr %l64, !tbaa !21
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/parse:Parser", ptr %t147, i32 0, i32 27
  %t150 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t149, i64 %t150)
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l72, !tbaa !29
  %t154 = load ptr, ptr %l72, !tbaa !29
  %t155 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 15
  %t156 = load i64, ptr %t155, !tbaa !24
  %t158 = sub i64 %t156, 1
  %t160 = load ptr, ptr %l72, !tbaa !29
  %t161 = getelementptr %"compiler/parse:Parser", ptr %t160, i32 0, i32 15
  store i64 %t158, ptr %t161, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i1, ptr %l2, !tbaa !21
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 16
  store i1 %t163, ptr %t166, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i1, ptr %l3, !tbaa !21
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t167, i32 0, i32 17
  store i1 %t168, ptr %t171, !tbaa !21
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb27:
  %t174 = load i1, ptr %l64, !tbaa !21
  %t177 = xor i1 %t174, true
  br i1 %t177, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  br label %bb31
bb31:
  br label %bb5
bb32:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i1, ptr %l2, !tbaa !21
  %t183 = getelementptr %"compiler/parse:Parser", ptr %t179, i32 0, i32 16
  store i1 %t180, ptr %t183, !tbaa !21
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l84, !tbaa !29
  %t185 = load ptr, ptr %l84, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 15
  %t187 = load i64, ptr %t186, !tbaa !24
  %t189 = sub i64 %t187, 1
  %t191 = load ptr, ptr %l84, !tbaa !29
  %t192 = getelementptr %"compiler/parse:Parser", ptr %t191, i32 0, i32 15
  store i64 %t189, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i1, ptr %l1, !tbaa !21
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t193, i32 0, i32 11
  store i1 %t194, ptr %t197, !tbaa !21
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t201 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t198, i32 89)
  store i1 %t201, ptr %l91
  br label %bb33
bb33:
  %t202 = load i1, ptr %l91, !tbaa !21
  %t203 = xor i1 %t202, true
  br i1 %t203, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 27
  %t208 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t207, i64 %t208)
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l96, !tbaa !29
  %t213 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s11, i32 89)
  store { i64, ptr } %t213, ptr %l98
  br label %bb37
bb37:
  %t214 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  %t216 = extractvalue { i64, ptr } %t214, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load ptr, ptr %l96, !tbaa !29
  %t223 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s11, ptr %t221, { i64, ptr } %t220)
  store i32 %t223, ptr %l100
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb39, label %ok.225
ok.225:
  br label %bb38
bb38:
  br label %bb40
bb39:
  %t226 = load i32, ptr %l100, !tbaa !23
  %t227 = lshr i32 %t226, 16
  %t228 = and i32 %t226, 65535
  %t229 = icmp eq i32 %t227, 1
  %t230 = select i1 %t229, i32 1, i32 0
  %t231 = icmp eq i32 %t226, 0
  %t232 = shl i32 %t230, 16
  %t233 = or i32 %t232, %t228
  %t234 = select i1 %t231, i32 0, i32 %t233
  call void @__olang_scope_close(ptr %s11)
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i1, ptr %l3, !tbaa !21
  %t239 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 17
  store i1 %t236, ptr %t239, !tbaa !21
  %t241 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t234, 0
  store { i32, { i64, ptr } } %t241, ptr %rv
  br label %ret
bb40:
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb41:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t242)
  store i32 %t244, ptr %l105
  br label %bb42
bb42:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/parse:Parser", ptr %t245, i32 0, i32 27
  %t248 = load i64, ptr %l4, !tbaa !24
  %t251 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t247, i64 %t248)
  store { i64, ptr } %t251, ptr %l109
  br label %bb43
bb43:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i1, ptr %l3, !tbaa !21
  %t256 = getelementptr %"compiler/parse:Parser", ptr %t252, i32 0, i32 17
  store i1 %t253, ptr %t256, !tbaa !21
  %t257 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t258 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t257, 1
  store { i32, { i64, ptr } } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %t21, ptr %t20, i64 %a1)
  %t28 = extractvalue { i32, ptr } %t27, 1
  %t29 = extractvalue { i32, ptr } %t27, 0
  store i32 %t29, ptr %l13
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store ptr %t28, ptr %l12
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l12, !tbaa !29
  store ptr %t32, ptr %l8, !tbaa !29
  br label %bb6
bb5:
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  %t43 = insertvalue { i32, ptr } zeroinitializer, i32 %t41, 0
  store { i32, ptr } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t45 = insertvalue { i32, ptr } zeroinitializer, ptr %t44, 1
  store { i32, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l23 = alloca i64
  %l26 = alloca i1
  %l31 = alloca ptr
  %l37 = alloca i1
  %l39 = alloca i32
  %l44 = alloca ptr
  %l52 = alloca i1
  %l56 = alloca ptr
  %l61 = alloca i32
  %l65 = alloca i32
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l88 = alloca ptr
  %l98 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca i32
  %l126 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l140 = alloca i32
  %l142 = alloca ptr
  %l148 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca i32
  %l155 = alloca ptr
  %l160 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i32
  %l164 = alloca i1
  %l165 = alloca i1
  %l166 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca i64
  %l171 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l177 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca i1
  %l196 = alloca i1
  %l197 = alloca ptr
  %l199 = alloca i32
  %l200 = alloca i64
  %l203 = alloca ptr
  %l205 = alloca i32
  %l207 = alloca i32
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i32
  %l217 = alloca ptr
  %l222 = alloca i32
  %l224 = alloca ptr
  %l233 = alloca %"compiler/source:Span"
  %l235 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca %"compiler/ast:Chain"
  %l247 = alloca %"compiler/source:Span"
  %l254 = alloca i32
  %l256 = alloca ptr
  %s1 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t160 = alloca { i64, [5 x i64] }, align 8
  %t271 = alloca { i64, [5 x i64] }, align 8
  %t321 = alloca { i64, [5 x i64] }, align 8
  %t602 = alloca { i64, [5 x i64] }, align 8
  %t624 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l20
  br label %bb3
bb3:
  %t12 = load i32, ptr %l20
  store i32 %t12, ptr %l6
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l6
  %t17 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l23
  br label %bb4
bb4:
  %t18 = load i64, ptr %l23, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp slt i64 %t23, %a2
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l31, !tbaa !29
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 18
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 18
  store i64 %t38, ptr %t41, !tbaa !24
  %t43 = insertvalue { i32, ptr } zeroinitializer, ptr %t30, 1
  store { i32, ptr } %t43, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load i32, ptr %l6
  %t46 = trunc i64 48 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t49, i64 1)
  store i32 %t51, ptr %l39
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb14
bb13:
  %t52 = load i32, ptr %l39
  %t54 = trunc i64 26 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  store i1 %t57, ptr %l37, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l37, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l44, !tbaa !29
  %t62 = load ptr, ptr %l44, !tbaa !29
  %t63 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 18
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 18
  store i64 %t68, ptr %t71, !tbaa !24
  %t73 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t73, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 7
  %t77 = load i32, ptr %t76
  %t79 = trunc i64 0 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 81 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l56, !tbaa !29
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 18
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t100 = load ptr, ptr %l56, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 18
  store i64 %t98, ptr %t101, !tbaa !24
  %t103 = insertvalue { i32, ptr } zeroinitializer, ptr %t90, 1
  store { i32, ptr } %t103, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t104)
  store i32 %t106, ptr %l61
  br label %bb24
bb24:
  %t107 = load i32, ptr %l6
  %t109 = trunc i64 48 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l65
  br label %bb27
bb26:
  br label %bb35
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t116, 1
  %t121 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t115, i64 %t118)
  %t122 = extractvalue { i32, ptr } %t121, 1
  %t123 = extractvalue { i32, ptr } %t121, 0
  store i32 %t123, ptr %l71
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb29, label %ok.125
ok.125:
  store ptr %t122, ptr %l70
  br label %bb28
bb28:
  %t126 = load ptr, ptr %l70, !tbaa !29
  store ptr %t126, ptr %l66, !tbaa !29
  br label %bb30
bb29:
  %t127 = load i32, ptr %l71, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s1)
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l73, !tbaa !29
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = getelementptr %"compiler/parse:Parser", ptr %t137, i32 0, i32 18
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr %l5, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = getelementptr %"compiler/parse:Parser", ptr %t145, i32 0, i32 18
  store i64 %t143, ptr %t146, !tbaa !24
  %t148 = insertvalue { i32, ptr } zeroinitializer, i32 %t135, 0
  store { i32, ptr } %t148, ptr %rv
  br label %ret
bb30:
  %t149 = load ptr, ptr %l66, !tbaa !29
  store ptr %t149, ptr %l8, !tbaa !29
  %t150 = load i32, ptr %l4, !tbaa !23
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 10
  %t154 = load i32, ptr %t153, !tbaa !23
  %t157 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t150, i32 %t154)
  store %"compiler/source:Span" %t157, ptr %l80
  br label %bb31
bb31:
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t159 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 0
  store i64 6, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l80
  %t163 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t162, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr, ptr } %t163, ptr %t158, 1
  %t167 = insertvalue { %"compiler/source:Span", ptr, ptr } %t165, ptr %t159, 2
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t167, ptr %t168
  %t169 = load { i64, [5 x i64] }, ptr %t160
  %t171 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t169, ptr %t171
  store ptr %t171, ptr %l3, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t173)
  store i32 %t175, ptr %l86
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb33, label %ok.177
ok.177:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t178 = load i32, ptr %l86, !tbaa !23
  %t179 = lshr i32 %t178, 16
  %t180 = and i32 %t178, 65535
  %t181 = icmp eq i32 %t179, 1
  %t182 = select i1 %t181, i32 1, i32 0
  %t183 = icmp eq i32 %t178, 0
  %t184 = shl i32 %t182, 16
  %t185 = or i32 %t184, %t180
  %t186 = select i1 %t183, i32 0, i32 %t185
  call void @__olang_scope_close(ptr %s1)
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l88, !tbaa !29
  %t188 = load ptr, ptr %l88, !tbaa !29
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t188, i32 0, i32 18
  %t190 = load i64, ptr %t189, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = sub i64 %t190, %t191
  %t196 = load ptr, ptr %l88, !tbaa !29
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t196, i32 0, i32 18
  store i64 %t194, ptr %t197, !tbaa !24
  %t199 = insertvalue { i32, ptr } zeroinitializer, i32 %t186, 0
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb34:
  %t200 = load i64, ptr %l5, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb111
bb35:
  %t204 = load i32, ptr %l6
  %t206 = trunc i64 27 to i32
  %t207 = icmp eq i32 %t204, %t206
  br i1 %t207, label %bb36, label %bb37
bb36:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t212 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t209, i32 48)
  store i1 %t212, ptr %l98
  br label %bb38
bb37:
  br label %bb54
bb38:
  %t213 = load i1, ptr %l98, !tbaa !21
  store i1 %t213, ptr %l9, !tbaa !21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %t214)
  store i1 %t216, ptr %l100
  br label %bb39
bb39:
  %t217 = load i1, ptr %l100, !tbaa !21
  br i1 %t217, label %bb40, label %bb41
bb40:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t218)
  %t221 = extractvalue { i32, ptr } %t220, 1
  %t222 = extractvalue { i32, ptr } %t220, 0
  store i32 %t222, ptr %l104
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb43, label %ok.224
ok.224:
  store ptr %t221, ptr %l103
  br label %bb42
bb41:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i64, ptr %l7, !tbaa !24
  %t228 = add i64 %t226, 1
  %t231 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t225, i64 %t228)
  %t232 = extractvalue { i32, ptr } %t231, 1
  %t233 = extractvalue { i32, ptr } %t231, 0
  store i32 %t233, ptr %l124
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb47, label %ok.235
ok.235:
  store ptr %t232, ptr %l123
  br label %bb46
bb42:
  %t236 = load ptr, ptr %l103, !tbaa !29
  store ptr %t236, ptr %l101, !tbaa !29
  br label %bb44
bb43:
  %t237 = load i32, ptr %l104, !tbaa !23
  %t238 = lshr i32 %t237, 16
  %t239 = and i32 %t237, 65535
  %t240 = icmp eq i32 %t238, 1
  %t241 = select i1 %t240, i32 1, i32 0
  %t242 = icmp eq i32 %t237, 0
  %t243 = shl i32 %t241, 16
  %t244 = or i32 %t243, %t239
  %t245 = select i1 %t242, i32 0, i32 %t244
  call void @__olang_scope_close(ptr %s1)
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l106, !tbaa !29
  %t247 = load ptr, ptr %l106, !tbaa !29
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t247, i32 0, i32 18
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load i64, ptr %l5, !tbaa !24
  %t253 = sub i64 %t249, %t250
  %t255 = load ptr, ptr %l106, !tbaa !29
  %t256 = getelementptr %"compiler/parse:Parser", ptr %t255, i32 0, i32 18
  store i64 %t253, ptr %t256, !tbaa !24
  %t258 = insertvalue { i32, ptr } zeroinitializer, i32 %t245, 0
  store { i32, ptr } %t258, ptr %rv
  br label %ret
bb44:
  %t259 = load ptr, ptr %l101, !tbaa !29
  store ptr %t259, ptr %l10, !tbaa !29
  %t260 = load i32, ptr %l4, !tbaa !23
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t261, i32 0, i32 10
  %t264 = load i32, ptr %t263, !tbaa !23
  %t267 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t260, i32 %t264)
  store %"compiler/source:Span" %t267, ptr %l113
  br label %bb45
bb45:
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t269 = load ptr, ptr %l10, !tbaa !29
  %t270 = load i1, ptr %l9, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 0
  store i64 9, ptr %t272
  %t273 = load %"compiler/source:Span", ptr %l113
  %t274 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t273, 0
  %t276 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t274, ptr %t268, 1
  %t278 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t276, ptr %t269, 2
  %t280 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t278, i1 %t270, 3
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t280, ptr %t281
  %t282 = load { i64, [5 x i64] }, ptr %t271
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t282, ptr %t284
  store ptr %t284, ptr %l3, !tbaa !29
  br label %bb50
bb46:
  %t286 = load ptr, ptr %l123, !tbaa !29
  store ptr %t286, ptr %l119, !tbaa !29
  br label %bb48
bb47:
  %t287 = load i32, ptr %l124, !tbaa !23
  %t288 = lshr i32 %t287, 16
  %t289 = and i32 %t287, 65535
  %t290 = icmp eq i32 %t288, 1
  %t291 = select i1 %t290, i32 1, i32 0
  %t292 = icmp eq i32 %t287, 0
  %t293 = shl i32 %t291, 16
  %t294 = or i32 %t293, %t289
  %t295 = select i1 %t292, i32 0, i32 %t294
  call void @__olang_scope_close(ptr %s1)
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l126, !tbaa !29
  %t297 = load ptr, ptr %l126, !tbaa !29
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t297, i32 0, i32 18
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load i64, ptr %l5, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t305 = load ptr, ptr %l126, !tbaa !29
  %t306 = getelementptr %"compiler/parse:Parser", ptr %t305, i32 0, i32 18
  store i64 %t303, ptr %t306, !tbaa !24
  %t308 = insertvalue { i32, ptr } zeroinitializer, i32 %t295, 0
  store { i32, ptr } %t308, ptr %rv
  br label %ret
bb48:
  %t309 = load ptr, ptr %l119, !tbaa !29
  store ptr %t309, ptr %l11, !tbaa !29
  %t310 = load i32, ptr %l4, !tbaa !23
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/parse:Parser", ptr %t311, i32 0, i32 10
  %t314 = load i32, ptr %t313, !tbaa !23
  %t317 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t310, i32 %t314)
  store %"compiler/source:Span" %t317, ptr %l133
  br label %bb49
bb49:
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t319 = load ptr, ptr %l11, !tbaa !29
  %t320 = load i1, ptr %l9, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 0
  store i64 10, ptr %t322
  %t323 = load %"compiler/source:Span", ptr %l133
  %t324 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t323, 0
  %t326 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t324, ptr %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t328, i1 %t320, 3
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t330, ptr %t331
  %t332 = load { i64, [5 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t332, ptr %t334
  store ptr %t334, ptr %l3, !tbaa !29
  br label %bb50
bb50:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t336)
  store i32 %t338, ptr %l140
  %t339 = icmp ne i32 %t338, 0
  br i1 %t339, label %bb52, label %ok.340
ok.340:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t341 = load i32, ptr %l140, !tbaa !23
  %t342 = lshr i32 %t341, 16
  %t343 = and i32 %t341, 65535
  %t344 = icmp eq i32 %t342, 1
  %t345 = select i1 %t344, i32 1, i32 0
  %t346 = icmp eq i32 %t341, 0
  %t347 = shl i32 %t345, 16
  %t348 = or i32 %t347, %t343
  %t349 = select i1 %t346, i32 0, i32 %t348
  call void @__olang_scope_close(ptr %s1)
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l142, !tbaa !29
  %t351 = load ptr, ptr %l142, !tbaa !29
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t351, i32 0, i32 18
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load i64, ptr %l5, !tbaa !24
  %t357 = sub i64 %t353, %t354
  %t359 = load ptr, ptr %l142, !tbaa !29
  %t360 = getelementptr %"compiler/parse:Parser", ptr %t359, i32 0, i32 18
  store i64 %t357, ptr %t360, !tbaa !24
  %t362 = insertvalue { i32, ptr } zeroinitializer, i32 %t349, 0
  store { i32, ptr } %t362, ptr %rv
  br label %ret
bb53:
  %t363 = load i64, ptr %l5, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb111
bb54:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr %l7, !tbaa !24
  %t370 = add i64 %t368, 1
  %t373 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t367, i64 %t370)
  %t374 = extractvalue { i32, ptr } %t373, 1
  %t375 = extractvalue { i32, ptr } %t373, 0
  store i32 %t375, ptr %l153
  %t376 = icmp ne i32 %t375, 0
  br i1 %t376, label %bb56, label %ok.377
ok.377:
  store ptr %t374, ptr %l152
  br label %bb55
bb55:
  %t378 = load ptr, ptr %l152, !tbaa !29
  store ptr %t378, ptr %l148, !tbaa !29
  br label %bb57
bb56:
  %t379 = load i32, ptr %l153, !tbaa !23
  %t380 = lshr i32 %t379, 16
  %t381 = and i32 %t379, 65535
  %t382 = icmp eq i32 %t380, 1
  %t383 = select i1 %t382, i32 1, i32 0
  %t384 = icmp eq i32 %t379, 0
  %t385 = shl i32 %t383, 16
  %t386 = or i32 %t385, %t381
  %t387 = select i1 %t384, i32 0, i32 %t386
  call void @__olang_scope_close(ptr %s1)
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l155, !tbaa !29
  %t389 = load ptr, ptr %l155, !tbaa !29
  %t390 = getelementptr %"compiler/parse:Parser", ptr %t389, i32 0, i32 18
  %t391 = load i64, ptr %t390, !tbaa !24
  %t392 = load i64, ptr %l5, !tbaa !24
  %t395 = sub i64 %t391, %t392
  %t397 = load ptr, ptr %l155, !tbaa !29
  %t398 = getelementptr %"compiler/parse:Parser", ptr %t397, i32 0, i32 18
  store i64 %t395, ptr %t398, !tbaa !24
  %t400 = insertvalue { i32, ptr } zeroinitializer, i32 %t387, 0
  store { i32, ptr } %t400, ptr %rv
  br label %ret
bb57:
  %t401 = load ptr, ptr %l148, !tbaa !29
  store ptr %t401, ptr %l12, !tbaa !29
  %t402 = load i32, ptr %l6
  %t404 = call i1 @compiler_2fparse_2eisOrdering(i32 %t402)
  store i1 %t404, ptr %l160
  br label %bb58
bb58:
  %t405 = load i1, ptr %l160, !tbaa !21
  br i1 %t405, label %bb59, label %bb60
bb59:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t406)
  store i32 %t408, ptr %l163
  br label %bb61
bb60:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb63
bb61:
  %t409 = load i32, ptr %l163
  %t410 = call i1 @compiler_2fparse_2eisOrdering(i32 %t409)
  store i1 %t410, ptr %l164
  br label %bb62
bb62:
  %t411 = load i1, ptr %l164, !tbaa !21
  store i1 %t411, ptr %l161, !tbaa !21
  br label %bb63
bb63:
  %t412 = load i1, ptr %l161, !tbaa !21
  br i1 %t412, label %bb64, label %bb65
bb64:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l166, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t414)
  store i32 %t416, ptr %l168
  br label %bb66
bb65:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb68
bb66:
  %t417 = load ptr, ptr %l166, !tbaa !29
  %t418 = load i32, ptr %l168
  %t419 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t417, i32 %t418)
  store i64 %t419, ptr %l169
  br label %bb67
bb67:
  %t420 = load i64, ptr %l169, !tbaa !24
  %t421 = icmp sgt i64 %t420, 0
  store i1 %t421, ptr %l165, !tbaa !21
  br label %bb68
bb68:
  %t423 = load i1, ptr %l165, !tbaa !21
  br i1 %t423, label %bb69, label %bb70
bb69:
  %t424 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, ptr %l171
  br label %bb71
bb70:
  br label %bb106
bb71:
  %t425 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t425, ptr %t426
  store ptr %t426, ptr %l13, !tbaa !29
  %t428 = load ptr, ptr %l13, !tbaa !29
  %t429 = load i32, ptr %l6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %t428, i32 %t429)
  br label %bb72
bb72:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/parse:Parser", ptr %t432, i32 0, i32 27
  %t436 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t434)
  store i64 %t436, ptr %l177
  br label %bb73
bb73:
  %t437 = load i64, ptr %l177, !tbaa !24
  store i64 %t437, ptr %l14, !tbaa !24
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/parse:Parser", ptr %t438, i32 0, i32 27
  %t441 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t440, ptr %t441)
  br label %bb74
bb74:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/parse:Parser", ptr %t444, i32 0, i32 27
  %t447 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t446, ptr %t447)
  br label %bb75
bb75:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t450)
  store i32 %t452, ptr %l185
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb77, label %ok.454
ok.454:
  br label %bb76
bb76:
  br label %bb78
bb77:
  %t455 = load i32, ptr %l185, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  call void @__olang_scope_close(ptr %s1)
  %t464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t464, ptr %l187, !tbaa !29
  %t465 = load ptr, ptr %l187, !tbaa !29
  %t466 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 18
  %t467 = load i64, ptr %t466, !tbaa !24
  %t468 = load i64, ptr %l5, !tbaa !24
  %t471 = sub i64 %t467, %t468
  %t473 = load ptr, ptr %l187, !tbaa !29
  %t474 = getelementptr %"compiler/parse:Parser", ptr %t473, i32 0, i32 18
  store i64 %t471, ptr %t474, !tbaa !24
  %t476 = insertvalue { i32, ptr } zeroinitializer, i32 %t463, 0
  store { i32, ptr } %t476, ptr %rv
  br label %ret
bb78:
  %t477 = load i64, ptr %l5, !tbaa !24
  %t479 = add i64 %t477, 1
  store i64 %t479, ptr %l5, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s30
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t481)
  store i32 %t483, ptr %l194
  br label %bb80
bb80:
  %t484 = load i32, ptr %l194
  %t485 = call i1 @compiler_2fparse_2eisOrdering(i32 %t484)
  store i1 %t485, ptr %l195
  br label %bb81
bb81:
  %t486 = load i1, ptr %l195, !tbaa !21
  br i1 %t486, label %bb82, label %bb83
bb82:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l197, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t488)
  store i32 %t490, ptr %l199
  br label %bb84
bb83:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb86
bb84:
  %t491 = load ptr, ptr %l197, !tbaa !29
  %t492 = load i32, ptr %l199
  %t493 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t491, i32 %t492)
  store i64 %t493, ptr %l200
  br label %bb85
bb85:
  %t494 = load i64, ptr %l200, !tbaa !24
  %t495 = icmp sgt i64 %t494, 0
  store i1 %t495, ptr %l196, !tbaa !21
  br label %bb86
bb86:
  %t497 = load i1, ptr %l196, !tbaa !21
  %t498 = xor i1 %t497, true
  br i1 %t498, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s30)
  br label %bb101
bb88:
  br label %bb89
bb89:
  %t500 = load ptr, ptr %l13, !tbaa !29
  store ptr %t500, ptr %l203, !tbaa !29
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t501)
  store i32 %t503, ptr %l205
  br label %bb90
bb90:
  %t504 = load ptr, ptr %l203, !tbaa !29
  %t505 = load i32, ptr %l205
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %t504, i32 %t505)
  br label %bb91
bb91:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t506)
  store i32 %t508, ptr %l207
  br label %bb92
bb92:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/parse:Parser", ptr %t509, i32 0, i32 27
  store ptr %t511, ptr %l209, !tbaa !29
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load i64, ptr %l7, !tbaa !24
  %t515 = add i64 %t513, 1
  %t518 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t512, i64 %t515)
  %t519 = extractvalue { i32, ptr } %t518, 1
  %t520 = extractvalue { i32, ptr } %t518, 0
  store i32 %t520, ptr %l215
  %t521 = icmp ne i32 %t520, 0
  br i1 %t521, label %bb94, label %ok.522
ok.522:
  store ptr %t519, ptr %l214
  br label %bb93
bb93:
  %t523 = load ptr, ptr %l214, !tbaa !29
  store ptr %t523, ptr %l210, !tbaa !29
  br label %bb95
bb94:
  %t524 = load i32, ptr %l215, !tbaa !23
  %t525 = lshr i32 %t524, 16
  %t526 = and i32 %t524, 65535
  %t527 = icmp eq i32 %t525, 1
  %t528 = select i1 %t527, i32 1, i32 0
  %t529 = icmp eq i32 %t524, 0
  %t530 = shl i32 %t528, 16
  %t531 = or i32 %t530, %t526
  %t532 = select i1 %t529, i32 0, i32 %t531
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s1)
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l217, !tbaa !29
  %t534 = load ptr, ptr %l217, !tbaa !29
  %t535 = getelementptr %"compiler/parse:Parser", ptr %t534, i32 0, i32 18
  %t536 = load i64, ptr %t535, !tbaa !24
  %t537 = load i64, ptr %l5, !tbaa !24
  %t540 = sub i64 %t536, %t537
  %t542 = load ptr, ptr %l217, !tbaa !29
  %t543 = getelementptr %"compiler/parse:Parser", ptr %t542, i32 0, i32 18
  store i64 %t540, ptr %t543, !tbaa !24
  %t545 = insertvalue { i32, ptr } zeroinitializer, i32 %t532, 0
  store { i32, ptr } %t545, ptr %rv
  br label %ret
bb95:
  %t546 = load ptr, ptr %l209, !tbaa !29
  %t547 = load ptr, ptr %l210, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t546, ptr %t547)
  br label %bb96
bb96:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t548)
  store i32 %t550, ptr %l222
  %t551 = icmp ne i32 %t550, 0
  br i1 %t551, label %bb98, label %ok.552
ok.552:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t553 = load i32, ptr %l222, !tbaa !23
  %t554 = lshr i32 %t553, 16
  %t555 = and i32 %t553, 65535
  %t556 = icmp eq i32 %t554, 1
  %t557 = select i1 %t556, i32 1, i32 0
  %t558 = icmp eq i32 %t553, 0
  %t559 = shl i32 %t557, 16
  %t560 = or i32 %t559, %t555
  %t561 = select i1 %t558, i32 0, i32 %t560
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s1)
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l224, !tbaa !29
  %t563 = load ptr, ptr %l224, !tbaa !29
  %t564 = getelementptr %"compiler/parse:Parser", ptr %t563, i32 0, i32 18
  %t565 = load i64, ptr %t564, !tbaa !24
  %t566 = load i64, ptr %l5, !tbaa !24
  %t569 = sub i64 %t565, %t566
  %t571 = load ptr, ptr %l224, !tbaa !29
  %t572 = getelementptr %"compiler/parse:Parser", ptr %t571, i32 0, i32 18
  store i64 %t569, ptr %t572, !tbaa !24
  %t574 = insertvalue { i32, ptr } zeroinitializer, i32 %t561, 0
  store { i32, ptr } %t574, ptr %rv
  br label %ret
bb99:
  %t575 = load i64, ptr %l5, !tbaa !24
  %t577 = add i64 %t575, 1
  store i64 %t577, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb100
bb100:
  br label %bb79
bb101:
  %t579 = load i32, ptr %l4, !tbaa !23
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t582 = getelementptr %"compiler/parse:Parser", ptr %t580, i32 0, i32 10
  %t583 = load i32, ptr %t582, !tbaa !23
  %t586 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t579, i32 %t583)
  store %"compiler/source:Span" %t586, ptr %l233
  br label %bb102
bb102:
  %t587 = load ptr, ptr %l13, !tbaa !29
  %t589 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v0, ptr %t587)
  store { i64, ptr } %t589, ptr %l235
  br label %bb103
bb103:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/parse:Parser", ptr %t590, i32 0, i32 27
  %t593 = load i64, ptr %l14, !tbaa !24
  %t596 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t592, i64 %t593)
  store { i64, ptr } %t596, ptr %l239
  br label %bb104
bb104:
  %t597 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t599 = call %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t597, { i64, ptr } %t598)
  store %"compiler/ast:Chain" %t599, ptr %l240
  br label %bb105
bb105:
  %t600 = load %"compiler/ast:Chain", ptr %l240
  %t601 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Chain" %t600, ptr %t601
  store { i64, [5 x i64] } zeroinitializer, ptr %t602
  %t603 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 0
  store i64 7, ptr %t603
  %t604 = load %"compiler/source:Span", ptr %l233
  %t605 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t604, 0
  %t607 = insertvalue { %"compiler/source:Span", ptr } %t605, ptr %t601, 1
  %t608 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t607, ptr %t608
  %t609 = load { i64, [5 x i64] }, ptr %t602
  %t611 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t609, ptr %t611
  store ptr %t611, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb111
bb106:
  %t613 = load i32, ptr %l4, !tbaa !23
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/parse:Parser", ptr %t614, i32 0, i32 10
  %t617 = load i32, ptr %t616, !tbaa !23
  %t620 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t613, i32 %t617)
  store %"compiler/source:Span" %t620, ptr %l247
  br label %bb107
bb107:
  %t621 = load i32, ptr %l6
  %t622 = load ptr, ptr %l3, !tbaa !29
  %t623 = load ptr, ptr %l12, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t624
  %t625 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 0
  store i64 5, ptr %t625
  %t626 = load %"compiler/source:Span", ptr %l247
  %t627 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t626, 0
  %t629 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t627, i32 %t621, 1
  %t631 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t629, ptr %t622, 2
  %t633 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t631, ptr %t623, 3
  %t634 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t633, ptr %t634
  %t635 = load { i64, [5 x i64] }, ptr %t624
  %t637 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t635, ptr %t637
  store ptr %t637, ptr %l3, !tbaa !29
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t639)
  store i32 %t641, ptr %l254
  %t642 = icmp ne i32 %t641, 0
  br i1 %t642, label %bb109, label %ok.643
ok.643:
  br label %bb108
bb108:
  br label %bb110
bb109:
  %t644 = load i32, ptr %l254, !tbaa !23
  %t645 = lshr i32 %t644, 16
  %t646 = and i32 %t644, 65535
  %t647 = icmp eq i32 %t645, 1
  %t648 = select i1 %t647, i32 1, i32 0
  %t649 = icmp eq i32 %t644, 0
  %t650 = shl i32 %t648, 16
  %t651 = or i32 %t650, %t646
  %t652 = select i1 %t649, i32 0, i32 %t651
  call void @__olang_scope_close(ptr %s1)
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l256, !tbaa !29
  %t654 = load ptr, ptr %l256, !tbaa !29
  %t655 = getelementptr %"compiler/parse:Parser", ptr %t654, i32 0, i32 18
  %t656 = load i64, ptr %t655, !tbaa !24
  %t657 = load i64, ptr %l5, !tbaa !24
  %t660 = sub i64 %t656, %t657
  %t662 = load ptr, ptr %l256, !tbaa !29
  %t663 = getelementptr %"compiler/parse:Parser", ptr %t662, i32 0, i32 18
  store i64 %t660, ptr %t663, !tbaa !24
  %t665 = insertvalue { i32, ptr } zeroinitializer, i32 %t652, 0
  store { i32, ptr } %t665, ptr %rv
  br label %ret
bb110:
  %t666 = load i64, ptr %l5, !tbaa !24
  %t668 = add i64 %t666, 1
  store i64 %t668, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb111
bb111:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"compiler/token:Token"
  %l11 = alloca %"compiler/parse:stackMarks"
  %l12 = alloca i64
  %l16 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca %"compiler/token:Token"
  %l30 = alloca i32
  %l51 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l65 = alloca i1
  %l72 = alloca i32
  %l74 = alloca %"compiler/token:Token"
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i64
  %l96 = alloca i32
  %l109 = alloca %"compiler/parse:stackMarks"
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i32
  %l118 = alloca i1
  %l124 = alloca i32
  %l146 = alloca i1
  %l151 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l155 = alloca i32
  %l156 = alloca i32
  %l169 = alloca i32
  %l173 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t169 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 92)
  store i1 %t4, ptr %l16
  br label %bb1
bb1:
  %t5 = load i1, ptr %l16, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l18, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 92)
  store { i64, ptr } %t10, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t11 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = load ptr, ptr %l18, !tbaa !29
  %t20 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t18, { i64, ptr } %t17)
  store i32 %t20, ptr %l22
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22
ok.22:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l22, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s1)
  %t33 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t31, 0
  store { i32, { i64, ptr } } %t33, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l25
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t47, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t50)
  store %"compiler/token:Token" %t52, ptr %l28
  br label %bb12
bb12:
  %t53 = load %"compiler/token:Token", ptr %l28
  store %"compiler/token:Token" %t53, ptr %l1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l30
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 12
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l2, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 14
  %t66 = load i1, ptr %t65, !tbaa !21
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 12
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 14
  store i1 false, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 15
  %t76 = load i64, ptr %t75, !tbaa !24
  store i64 %t76, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t78, i32 0, i32 15
  store i64 0, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 16
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l4, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 16
  store i1 false, ptr %t88, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 17
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l5, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 17
  store i1 false, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 13
  %t100 = load i1, ptr %t99, !tbaa !21
  store i1 %t100, ptr %l6, !tbaa !21
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 13
  store i1 false, ptr %t104, !tbaa !21
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 28
  %t109 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l51
  br label %bb14
bb14:
  %t110 = load i64, ptr %l51, !tbaa !24
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t111 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t111)
  br label %bb16
bb16:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t113, i32 93)
  store i1 %t116, ptr %l55
  br label %bb17
bb17:
  %t117 = load i1, ptr %l55, !tbaa !21
  br i1 %t117, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb21
bb19:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t121 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t118, i32 0)
  store i1 %t121, ptr %l59
  br label %bb20
bb20:
  %t122 = load i1, ptr %l59, !tbaa !21
  store i1 %t122, ptr %l56, !tbaa !21
  br label %bb21
bb21:
  %t123 = load i1, ptr %l56, !tbaa !21
  br i1 %t123, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb23:
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %t124)
  store i1 %t126, ptr %l61
  br label %bb25
bb25:
  %t127 = load i1, ptr %l61, !tbaa !21
  br i1 %t127, label %bb26, label %bb27
bb26:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 19
  %t131 = load i1, ptr %t130, !tbaa !21
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb28, label %bb29
bb27:
  br label %bb41
bb28:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t135, i32 0, i32 21
  %t138 = load i1, ptr %t137, !tbaa !21
  %t140 = xor i1 %t138, true
  store i1 %t140, ptr %l65, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t142 = load i1, ptr %l65, !tbaa !21
  br i1 %t142, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t146, i32 %t148)
  store i32 %t151, ptr %l72
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t152 = load i32, ptr %l72, !tbaa !23
  store i32 %t152, ptr %l8, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t153)
  store %"compiler/token:Token" %t155, ptr %l74
  br label %bb34
bb34:
  %t156 = load %"compiler/token:Token", ptr %l74
  store %"compiler/token:Token" %t156, ptr %l9
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 5
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 2
  %t162 = load i32, ptr %t161, !tbaa !23
  %t164 = sext i32 %t162 to i64
  %t165 = getelementptr %"compiler/token:Token", ptr %l9, i32 0, i32 3
  %t166 = load i32, ptr %t165, !tbaa !23
  %t168 = sext i32 %t166 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t169, i32 0, i32 0
  store i64 3, ptr %t170
  %t172 = insertvalue { i64, i64, i64 } undef, i64 %t160, 0
  %t174 = insertvalue { i64, i64, i64 } %t172, i64 %t164, 1
  %t176 = insertvalue { i64, i64, i64 } %t174, i64 %t168, 2
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t169, i32 0, i32 1
  store { i64, i64, i64 } %t176, ptr %t177
  %t178 = load { i64, [3 x i64] }, ptr %t169
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/parse:Parser", ptr %t180, i32 0, i32 4
  %t183 = load ptr, ptr %t182, !tbaa !29
  store ptr %t183, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } %t178, ptr %l84
  %t185 = load i32, ptr %l8, !tbaa !23
  %t187 = sext i32 %t185 to i64
  store i64 %t187, ptr %l86, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s5, ptr %t188)
  store { i64, ptr } %t190, ptr %l88
  br label %bb35
bb35:
  %t191 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load i64, ptr %l86, !tbaa !24
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %s5, ptr %s5, i64 %t198, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t200, ptr %l90
  br label %bb36
bb36:
  %t201 = load ptr, ptr %l83, !tbaa !29
  %t202 = load { i64, [3 x i64] }, ptr %l84
  %t203 = load %"compiler/msgs:Msg", ptr %l90
  %t204 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s5, ptr %t201, { i64, [3 x i64] } %t202, %"compiler/msgs:Msg" %t203)
  store i64 %t204, ptr %l91
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 28
  %t208 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eTrunc_H7d095616a1c9f3bb0e1e9e6638b5e3ec(ptr %v0, ptr %t207, i64 %t208)
  br label %bb39
bb39:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/parse:Parser", ptr %t211, i32 0, i32 21
  store i1 true, ptr %t213, !tbaa !21
  store i32 65536, ptr %l96, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i1, ptr %l6, !tbaa !21
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 13
  store i1 %t215, ptr %t218, !tbaa !21
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i1, ptr %l5, !tbaa !21
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t219, i32 0, i32 17
  store i1 %t220, ptr %t223, !tbaa !21
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i1, ptr %l4, !tbaa !21
  %t228 = getelementptr %"compiler/parse:Parser", ptr %t224, i32 0, i32 16
  store i1 %t225, ptr %t228, !tbaa !21
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i64, ptr %l3, !tbaa !24
  %t233 = getelementptr %"compiler/parse:Parser", ptr %t229, i32 0, i32 15
  store i64 %t230, ptr %t233, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l2, !tbaa !21
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 12
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t239)
  br label %bb40
bb40:
  %t241 = load i32, ptr %l96, !tbaa !23
  %t242 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t241, 0
  store { i32, { i64, ptr } } %t242, ptr %rv
  br label %ret
bb41:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %t243)
  store %"compiler/parse:stackMarks" %t245, ptr %l109
  br label %bb42
bb42:
  %t246 = load %"compiler/parse:stackMarks", ptr %l109
  store %"compiler/parse:stackMarks" %t246, ptr %l11
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/parse:Parser", ptr %t247, i32 0, i32 6
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, ptr } %t254, 1
  %t256 = extractvalue { i32, ptr } %t254, 0
  store i32 %t256, ptr %l115
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb44, label %ok.258
ok.258:
  store ptr %t255, ptr %l114
  br label %bb43
bb43:
  %t259 = load ptr, ptr %l114, !tbaa !29
  store ptr %t259, ptr %l112, !tbaa !29
  br label %bb56
bb44:
  br label %bb45
bb45:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/parse:Parser", ptr %t260, i32 0, i32 19
  %t263 = load i1, ptr %t262, !tbaa !21
  br i1 %t263, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb48
bb47:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/parse:Parser", ptr %t265, i32 0, i32 21
  %t268 = load i1, ptr %t267, !tbaa !21
  store i1 %t268, ptr %l118, !tbaa !21
  br label %bb48
bb48:
  %t270 = load i1, ptr %l118, !tbaa !21
  br i1 %t270, label %bb49, label %bb50
bb49:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/parse:Parser", ptr %t271, i32 0, i32 28
  %t274 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eTrunc_H7d095616a1c9f3bb0e1e9e6638b5e3ec(ptr %v0, ptr %t273, i64 %t274)
  br label %bb51
bb50:
  br label %bb53
bb51:
  store i32 65536, ptr %l124, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i1, ptr %l6, !tbaa !21
  %t281 = getelementptr %"compiler/parse:Parser", ptr %t277, i32 0, i32 13
  store i1 %t278, ptr %t281, !tbaa !21
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i1, ptr %l5, !tbaa !21
  %t286 = getelementptr %"compiler/parse:Parser", ptr %t282, i32 0, i32 17
  store i1 %t283, ptr %t286, !tbaa !21
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i1, ptr %l4, !tbaa !21
  %t291 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 16
  store i1 %t288, ptr %t291, !tbaa !21
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i64, ptr %l3, !tbaa !24
  %t296 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 15
  store i64 %t293, ptr %t296, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i1, ptr %l2, !tbaa !21
  %t301 = getelementptr %"compiler/parse:Parser", ptr %t297, i32 0, i32 12
  store i1 %t298, ptr %t301, !tbaa !21
  %t302 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t302)
  br label %bb52
bb52:
  %t304 = load i32, ptr %l124, !tbaa !23
  %t305 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t304, 0
  store { i32, { i64, ptr } } %t305, ptr %rv
  br label %ret
bb53:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load %"compiler/parse:stackMarks", ptr %l11
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %t306, %"compiler/parse:stackMarks" %t307)
  br label %bb54
bb54:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 16
  store i1 false, ptr %t312, !tbaa !21
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %t313, i64 %t314)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb56:
  %t317 = load ptr, ptr %l112, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/parse:Parser", ptr %t318, i32 0, i32 28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t320, ptr %t317)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb58:
  br label %bb15
bb59:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t327 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t324, i32 93)
  store i1 %t327, ptr %l146
  br label %bb60
bb60:
  %t328 = load i1, ptr %l146, !tbaa !21
  %t329 = xor i1 %t328, true
  br i1 %t329, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s30
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/parse:Parser", ptr %t331, i32 0, i32 28
  %t334 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eTrunc_H7d095616a1c9f3bb0e1e9e6638b5e3ec(ptr %v0, ptr %t333, i64 %t334)
  br label %bb63
bb62:
  br label %bb69
bb63:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l151, !tbaa !29
  %t339 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s30, i32 93)
  store { i64, ptr } %t339, ptr %l153
  br label %bb64
bb64:
  %t340 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  %t342 = extractvalue { i64, ptr } %t340, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  %t347 = load ptr, ptr %l151, !tbaa !29
  %t349 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s30, ptr %t347, { i64, ptr } %t346)
  store i32 %t349, ptr %l155
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb66, label %ok.351
ok.351:
  br label %bb65
bb65:
  br label %bb68
bb66:
  %t352 = load i32, ptr %l155, !tbaa !23
  %t353 = lshr i32 %t352, 16
  %t354 = and i32 %t352, 65535
  %t355 = icmp eq i32 %t353, 1
  %t356 = select i1 %t355, i32 1, i32 0
  %t357 = icmp eq i32 %t352, 0
  %t358 = shl i32 %t356, 16
  %t359 = or i32 %t358, %t354
  %t360 = select i1 %t357, i32 0, i32 %t359
  store i32 %t360, ptr %l156, !tbaa !23
  call void @__olang_scope_close(ptr %s30)
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i1, ptr %l6, !tbaa !21
  %t365 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 13
  store i1 %t362, ptr %t365, !tbaa !21
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i1, ptr %l5, !tbaa !21
  %t370 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 17
  store i1 %t367, ptr %t370, !tbaa !21
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i1, ptr %l4, !tbaa !21
  %t375 = getelementptr %"compiler/parse:Parser", ptr %t371, i32 0, i32 16
  store i1 %t372, ptr %t375, !tbaa !21
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i64, ptr %l3, !tbaa !24
  %t380 = getelementptr %"compiler/parse:Parser", ptr %t376, i32 0, i32 15
  store i64 %t377, ptr %t380, !tbaa !24
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i1, ptr %l2, !tbaa !21
  %t385 = getelementptr %"compiler/parse:Parser", ptr %t381, i32 0, i32 12
  store i1 %t382, ptr %t385, !tbaa !21
  %t386 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t386)
  br label %bb67
bb67:
  %t388 = load i32, ptr %l156, !tbaa !23
  %t389 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t388, 0
  store { i32, { i64, ptr } } %t389, ptr %rv
  br label %ret
bb68:
  call void @__olang_scope_close(ptr %s30)
  br label %bb69
bb69:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l169
  br label %bb70
bb70:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/parse:Parser", ptr %t393, i32 0, i32 28
  %t396 = load i64, ptr %l7, !tbaa !24
  %t399 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t395, i64 %t396)
  store { i64, ptr } %t399, ptr %l173
  br label %bb71
bb71:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i1, ptr %l6, !tbaa !21
  %t404 = getelementptr %"compiler/parse:Parser", ptr %t400, i32 0, i32 13
  store i1 %t401, ptr %t404, !tbaa !21
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i1, ptr %l5, !tbaa !21
  %t409 = getelementptr %"compiler/parse:Parser", ptr %t405, i32 0, i32 17
  store i1 %t406, ptr %t409, !tbaa !21
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i1, ptr %l4, !tbaa !21
  %t414 = getelementptr %"compiler/parse:Parser", ptr %t410, i32 0, i32 16
  store i1 %t411, ptr %t414, !tbaa !21
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i64, ptr %l3, !tbaa !24
  %t419 = getelementptr %"compiler/parse:Parser", ptr %t415, i32 0, i32 15
  store i64 %t416, ptr %t419, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i1, ptr %l2, !tbaa !21
  %t424 = getelementptr %"compiler/parse:Parser", ptr %t420, i32 0, i32 12
  store i1 %t421, ptr %t424, !tbaa !21
  %t425 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t425)
  br label %bb72
bb72:
  %t427 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t428 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t427, 1
  store { i32, { i64, ptr } } %t428, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l12 = alloca i32
  %l15 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 79)
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t23 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t20)
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s1)
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l15
  br label %bb10
bb10:
  %t39 = load i32, ptr %l15, !tbaa !23
  store i32 %t39, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 38
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 6
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = sub i64 %t46, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t42, i64 %t48)
  br label %bb11
bb11:
  %t51 = load i32, ptr %l1
  %t53 = trunc i64 79 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i32 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l23, !tbaa !29
  %t57 = load i32, ptr %l1
  %t59 = trunc i64 87 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i32 79, ptr %l26
  br label %bb20
bb16:
  %t63 = load i32, ptr %l1
  %t65 = trunc i64 80 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i32 58, ptr %l30
  br label %bb19
bb18:
  store i32 80, ptr %l30
  br label %bb19
bb19:
  %t70 = load i32, ptr %l30
  store i32 %t70, ptr %l26
  br label %bb20
bb20:
  %t71 = load i32, ptr %l26
  %t72 = load ptr, ptr %l23, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 7
  store i32 %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t77 = add i32 %t75, 1
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 8
  store i32 %t77, ptr %t80, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 9
  store i32 79, ptr %t84
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t88 = add i32 %t86, 1
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 10
  store i32 %t88, ptr %t91, !tbaa !23
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclStarts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load i32, ptr %l2
  %t18 = trunc i64 33 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t21 = load i32, ptr %l2
  %t23 = trunc i64 41 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l2
  %t29 = trunc i64 40 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t33 = load i32, ptr %l2
  %t35 = trunc i64 43 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l16, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i32, ptr %l2
  %t42 = trunc i64 37 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/scan:Tokens", ptr %t51, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t47, %t56
  store i1 %t59, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l22, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/scan:Tokens", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l33, !tbaa !27
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = add i64 %t69, 1
  %t73 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/token:Token", ptr %t74, i64 %t71
  %t76 = getelementptr %"compiler/token:Token", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  %t79 = trunc i64 1 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l30, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t149 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 90)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t8)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l10
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14
ok.14:
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l7, !tbaa !29
  %t28 = insertvalue { i32, ptr } zeroinitializer, ptr %t27, 1
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l13
  br label %bb8
bb8:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l1, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 27
  %t37 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l16
  br label %bb9
bb9:
  %t38 = load i64, ptr %l16, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 91)
  store i1 %t42, ptr %l19
  br label %bb11
bb11:
  %t43 = load i1, ptr %l19, !tbaa !21
  %t44 = xor i1 %t43, true
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 27
  store ptr %t50, ptr %l23, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t51)
  %t54 = extractvalue { i32, ptr } %t53, 1
  %t55 = extractvalue { i32, ptr } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57
ok.57:
  store ptr %t54, ptr %l26
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l26, !tbaa !29
  store ptr %t58, ptr %l24, !tbaa !29
  br label %bb17
bb16:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  call void @__olang_scope_close(ptr %s2)
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t67, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t70, ptr %t71)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t72, i32 91)
  %t76 = extractvalue { i32, i1 } %t75, 1
  %t77 = extractvalue { i32, i1 } %t75, 0
  store i32 %t77, ptr %l33
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb20, label %ok.79
ok.79:
  store i1 %t76, ptr %l32
  br label %bb19
bb19:
  %t80 = load i1, ptr %l32, !tbaa !21
  store i1 %t80, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  call void @__olang_scope_close(ptr %s2)
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb21:
  %t92 = load i1, ptr %l29, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  br label %bb10
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t95, i32 91)
  store i1 %t98, ptr %l38
  br label %bb27
bb27:
  %t99 = load i1, ptr %l38, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 27
  %t105 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t104, i64 %t105)
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l43, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 91)
  store { i64, ptr } %t110, ptr %l45
  br label %bb31
bb31:
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l43, !tbaa !29
  %t120 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t118, { i64, ptr } %t117)
  store i32 %t120, ptr %l47
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb33, label %ok.122
ok.122:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t123 = load i32, ptr %l47, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  call void @__olang_scope_close(ptr %s4)
  %t133 = insertvalue { i32, ptr } zeroinitializer, i32 %t131, 0
  store { i32, ptr } %t133, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t134)
  store i32 %t136, ptr %l50
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t137, i32 %t138)
  store %"compiler/source:Span" %t141, ptr %l53
  br label %bb37
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 27
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t144, i64 %t145)
  store { i64, ptr } %t148, ptr %l57
  br label %bb38
bb38:
  store { i64, [5 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 0
  store i64 19, ptr %t150
  %t151 = load %"compiler/source:Span", ptr %l53
  %t152 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t151, 0
  %t153 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t154 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t152, { i64, ptr } %t153, 1
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t149
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  %t160 = insertvalue { i32, ptr } zeroinitializer, ptr %t158, 1
  store { i32, ptr } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t10)
  store i32 %t12, ptr %l8
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb5:
  %t13 = load i32, ptr %l1
  %t15 = trunc i64 93 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb7:
  %t18 = load i32, ptr %l1
  %t20 = trunc i64 0 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 13
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load i32, ptr %l1
  %t31 = trunc i64 10 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb17
bb14:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i32, ptr %l1
  %t36 = trunc i64 13 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l19, !tbaa !21
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l16, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 9
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l2
  %t46 = load i32, ptr %l2
  %t48 = trunc i64 81 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb23
bb22:
  %t51 = load i32, ptr %l2
  %t53 = trunc i64 79 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l26, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb26
bb25:
  %t57 = load i32, ptr %l2
  %t59 = trunc i64 93 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb26
bb26:
  %t62 = load i1, ptr %l29, !tbaa !21
  br i1 %t62, label %bb27, label %bb28
bb27:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t63)
  store i1 %t65, ptr %l34
  br label %bb29
bb28:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb30
bb29:
  %t66 = load i1, ptr %l34, !tbaa !21
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t67 = load i1, ptr %l32, !tbaa !21
  br i1 %t67, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t70 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t70, ptr %l37
  br label %bb34
bb34:
  %t71 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load ptr, ptr %l35, !tbaa !29
  %t80 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s0, ptr %t78, { i64, ptr } %t77)
  store i32 %t80, ptr %l39
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb36, label %ok.82
ok.82:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t83 = load i32, ptr %l39, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  store i32 %t91, ptr %rv
  br label %ret
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 55)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t6)
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t8, i32 8)
  store i1 %t11, ptr %l7
  br label %bb6
bb6:
  %t12 = load i1, ptr %l7, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t15, i32 93)
  store i1 %t18, ptr %l12
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  %t19 = load i1, ptr %l12, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t22 = load i1, ptr %l9, !tbaa !21
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t23, i32 0)
  store i1 %t26, ptr %l17
  br label %bb13
bb12:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb14
bb13:
  %t27 = load i1, ptr %l17, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb14
bb14:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 93)
  store { i64, ptr } %t33, ptr %l21
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l19, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t41, { i64, ptr } %t40)
  store i32 %t43, ptr %l23
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb19, label %ok.45
ok.45:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s2)
  store i32 %t54, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t56)
  store i32 %t58, ptr %l26
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb23, label %ok.60
ok.60:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t61 = load i32, ptr %l26, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  store i32 %t69, ptr %rv
  br label %ret
bb24:
  %t71 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t71)
  br label %bb25
bb25:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t1, i64 1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %t21, ptr %t20)
  %t26 = extractvalue { i32, ptr } %t25, 1
  %t27 = extractvalue { i32, ptr } %t25, 0
  store i32 %t27, ptr %l11
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29
ok.29:
  store ptr %t26, ptr %l10
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l10, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t31 = load i32, ptr %l11, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  %t41 = insertvalue { i32, ptr } zeroinitializer, i32 %t39, 0
  store { i32, ptr } %t41, ptr %rv
  br label %ret
bb6:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = insertvalue { i32, ptr } zeroinitializer, ptr %t42, 1
  store { i32, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t192 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l20, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 32
  %t27 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t26, i32 %t27)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb9:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 15
  store i1 %t37, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l29, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 32
  %t54 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t53, i32 %t54)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb21
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 32
  %t62 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %t61, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t65, { i64, ptr } { i64 44, ptr @.d0 })
  store i32 %t67, ptr %l44
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb19, label %ok.69
ok.69:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 %t78, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 32
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l49
  br label %bb24
bb24:
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = icmp sle i64 %t95, 2305843009213693951
  br i1 %t96, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5d5da79af2b44d73_2d4623f2243944cf)
  unreachable
bb27:
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = mul i64 %t98, 4
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5d5da79af2b44d73_2d4623f2243944cf)
  unreachable
bb29:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb34
bb31:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l63, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb33
bb33:
  %t134 = load i64, ptr %l63, !tbaa !24
  store i64 %t134, ptr %l60, !tbaa !24
  br label %bb34
bb34:
  %t135 = load i64, ptr %l60, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t136 = load i64, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  store i64 %t152, ptr %l14, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t154, ptr %l81, !tbaa !27
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t156, ptr %l83, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t161 = sub i64 %t159, 1
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = sub i64 %t161, %t162
  %t167 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t173 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 %t155
  store i32 %t170, ptr %t175, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l13, !tbaa !24
  br label %bb35
bb40:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t180)
  store %"compiler/source:Span" %t182, ptr %l93
  br label %bb41
bb41:
  %t183 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t183, ptr %l94, !tbaa !27
  %t184 = icmp sge i64 0, 0
  br i1 %t184, label %bb42, label %bb43
bb42:
  %t186 = icmp sle i64 0, 1152921504606846975
  br i1 %t186, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb44:
  %t188 = mul i64 0, 8
  %t189 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 0, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l93
  %t195 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t194, 0
  %t196 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t197 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t195, { i64, ptr } %t196, 1
  %t199 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t197, { i64, ptr } %t191, 2
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  %t205 = insertvalue { i32, ptr } zeroinitializer, ptr %t203, 1
  store { i32, ptr } %t205, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l19 = alloca i1
  %l24 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 27
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t7)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store ptr %t10, ptr %l8
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  br label %bb7
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 27
  %t18 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t17, i64 %t18)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t22 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t26, ptr %t23)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t30, i32 55)
  store i1 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i1, ptr %l19, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  br label %bb2
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 27
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t39, i64 %t40)
  store { i64, ptr } %t43, ptr %l24
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i64
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l89 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/ast:Multi"
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca %"compiler/source:Span"
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l131 = alloca %"compiler/ast:VarDecl"
  %l135 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i32
  %l143 = alloca i32
  %l145 = alloca i1
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca i32
  %l155 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l167 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t217 = alloca { i64, [5 x i64] }, align 8
  %t319 = alloca { i64, [5 x i64] }, align 8
  %t413 = alloca { i64, [5 x i64] }, align 8
  %t453 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l20
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l19
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l19, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l20, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 55)
  store i1 %t28, ptr %l24
  br label %bb5
bb5:
  %t29 = load i1, ptr %l24, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 27
  %t34 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l27
  br label %bb8
bb7:
  br label %bb82
bb8:
  %t35 = load i64, ptr %l27, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 27
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t42, i32 55)
  store i1 %t45, ptr %l33
  br label %bb11
bb11:
  %t46 = load i1, ptr %l33, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 27
  store ptr %t51, ptr %l36, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t52)
  %t55 = extractvalue { i32, ptr } %t54, 1
  %t56 = extractvalue { i32, ptr } %t54, 0
  store i32 %t56, ptr %l40
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb16, label %ok.58
ok.58:
  store ptr %t55, ptr %l39
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l39, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  br label %bb17
bb16:
  %t60 = load i32, ptr %l40, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s2)
  %t70 = insertvalue { i32, ptr } zeroinitializer, i32 %t68, 0
  store { i32, ptr } %t70, ptr %rv
  br label %ret
bb17:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t71, ptr %t72)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb10
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 27
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t75, i64 %t76)
  store { i64, ptr } %t79, ptr %l45
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t81, i32 60)
  store i1 %t84, ptr %l48
  br label %bb22
bb22:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 12
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t96 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v0, ptr %t92, { i64, ptr } %t93)
  %t97 = extractvalue { i32, ptr } %t96, 1
  %t98 = extractvalue { i32, ptr } %t96, 0
  store i32 %t98, ptr %l56
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb29, label %ok.100
ok.100:
  store ptr %t97, ptr %l55
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t101 = load ptr, ptr %l55, !tbaa !29
  store ptr %t101, ptr %l52, !tbaa !29
  br label %bb30
bb29:
  %t102 = load i32, ptr %l56, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  %t112 = insertvalue { i32, ptr } zeroinitializer, i32 %t110, 0
  store { i32, ptr } %t112, ptr %rv
  br label %ret
bb30:
  %t113 = load ptr, ptr %l52, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t114, i32 %t115, ptr %t113)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l63
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb32, label %ok.124
ok.124:
  store ptr %t121, ptr %l62
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l62, !tbaa !29
  store ptr %t125, ptr %l58, !tbaa !29
  br label %bb33
bb32:
  %t126 = load i32, ptr %l63, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb33:
  %t137 = load ptr, ptr %l58, !tbaa !29
  %t138 = insertvalue { i32, ptr } zeroinitializer, ptr %t137, 1
  store { i32, ptr } %t138, ptr %rv
  br label %ret
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t139, i32 60)
  store i1 %t142, ptr %l67
  br label %bb35
bb35:
  %t143 = load i1, ptr %l67, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb39
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t144, i32 58)
  store i1 %t147, ptr %l71
  br label %bb38
bb38:
  %t148 = load i1, ptr %l71, !tbaa !21
  store i1 %t148, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t149 = load i1, ptr %l68, !tbaa !21
  br i1 %t149, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t150, i32 0, i32 9
  %t153 = load i32, ptr %t152
  %t155 = trunc i64 60 to i32
  %t156 = icmp eq i32 %t153, %t155
  store i1 %t156, ptr %l6, !tbaa !21
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t159)
  store i32 %t161, ptr %l77
  br label %bb42
bb41:
  br label %bb51
bb42:
  %t162 = load i32, ptr %l77, !tbaa !23
  %t163 = load ptr, ptr %l75, !tbaa !29
  %t164 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 22
  store i32 %t162, ptr %t164, !tbaa !23
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t165)
  %t168 = extractvalue { i32, { i64, ptr } } %t167, 1
  %t169 = extractvalue { i32, { i64, ptr } } %t167, 0
  store i32 %t169, ptr %l81
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb44, label %ok.171
ok.171:
  store { i64, ptr } %t168, ptr %l80
  br label %bb43
bb43:
  %t172 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t172, ptr %l78, !tbaa !27
  br label %bb45
bb44:
  %t173 = load i32, ptr %l81, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  %t183 = insertvalue { i32, ptr } zeroinitializer, i32 %t181, 0
  store { i32, ptr } %t183, ptr %rv
  br label %ret
bb45:
  %t184 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t184, ptr %l7, !tbaa !27
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t185, i32 %t186)
  store %"compiler/source:Span" %t189, ptr %l85
  br label %bb46
bb46:
  %t190 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t190, ptr %l8
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t191)
  store i32 %t193, ptr %l87
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb48, label %ok.195
ok.195:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t196 = load i32, ptr %l87, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  %t206 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t206, ptr %rv
  br label %ret
bb49:
  %t207 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t207, ptr %l89
  %t208 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t209 = load i1, ptr %l6, !tbaa !21
  %t210 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = call %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t208, i1 %t209, { i64, ptr } %t210)
  store %"compiler/ast:Multi" %t214, ptr %l93
  br label %bb50
bb50:
  %t215 = load %"compiler/ast:Multi", ptr %l93
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:Multi" %t215, ptr %t216
  store { i64, [5 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t219 = load %"compiler/source:Span", ptr %l89
  %t220 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t219, 0
  %t222 = insertvalue { %"compiler/source:Span", ptr } %t220, ptr %t216, 1
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t222, ptr %t223
  %t224 = load { i64, [5 x i64] }, ptr %t217
  %t226 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t224, ptr %t226
  %t228 = insertvalue { i32, ptr } zeroinitializer, ptr %t226, 1
  store { i32, ptr } %t228, ptr %rv
  br label %ret
bb51:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t233 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v0, ptr %t229, { i64, ptr } %t230)
  %t234 = extractvalue { i32, ptr } %t233, 1
  %t235 = extractvalue { i32, ptr } %t233, 0
  store i32 %t235, ptr %l101
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb53, label %ok.237
ok.237:
  store ptr %t234, ptr %l100
  br label %bb52
bb52:
  %t238 = load ptr, ptr %l100, !tbaa !29
  store ptr %t238, ptr %l97, !tbaa !29
  br label %bb54
bb53:
  %t239 = load i32, ptr %l101, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 %t247, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb54:
  %t250 = load ptr, ptr %l97, !tbaa !29
  store ptr %t250, ptr %l9, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t251, i32 0, i32 12
  %t254 = load i1, ptr %t253, !tbaa !21
  br i1 %t254, label %bb55, label %bb56
bb55:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t259 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t256, i32 8)
  store i1 %t259, ptr %l108
  br label %bb57
bb56:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb66
bb57:
  %t260 = load i1, ptr %l108, !tbaa !21
  br i1 %t260, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb61
bb59:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t264 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t261, i32 93)
  store i1 %t264, ptr %l112
  br label %bb60
bb60:
  %t265 = load i1, ptr %l112, !tbaa !21
  store i1 %t265, ptr %l109, !tbaa !21
  br label %bb61
bb61:
  %t266 = load i1, ptr %l109, !tbaa !21
  br i1 %t266, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb65
bb63:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t270 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t267, i32 0)
  store i1 %t270, ptr %l116
  br label %bb64
bb64:
  %t271 = load i1, ptr %l116, !tbaa !21
  store i1 %t271, ptr %l113, !tbaa !21
  br label %bb65
bb65:
  %t272 = load i1, ptr %l113, !tbaa !21
  store i1 %t272, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t273 = load i1, ptr %l105, !tbaa !21
  br i1 %t273, label %bb67, label %bb68
bb67:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l1, !tbaa !23
  %t278 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t274, i32 %t275)
  store %"compiler/source:Span" %t278, ptr %l119
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t279 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t279, ptr %l10
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l121
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb71, label %ok.284
ok.284:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t285 = load i32, ptr %l121, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  %t295 = insertvalue { i32, ptr } zeroinitializer, i32 %t293, 0
  store { i32, ptr } %t295, ptr %rv
  br label %ret
bb72:
  %t296 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t296, ptr %l123
  %t297 = load ptr, ptr %l9, !tbaa !29
  %t299 = getelementptr %"compiler/parse:NameList", ptr %t297, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l125, !tbaa !27
  %t301 = load ptr, ptr %l9, !tbaa !29
  %t303 = getelementptr %"compiler/parse:NameList", ptr %t301, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l127, !tbaa !27
  %t305 = icmp sge i64 0, 0
  br i1 %t305, label %bb73, label %bb74
bb73:
  %t307 = icmp sle i64 0, 1152921504606846975
  br i1 %t307, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb75:
  %t309 = mul i64 0, 8
  %t310 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 0, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t313 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t316 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t313, { i64, ptr } %t314, ptr null, { i64, ptr } %t312, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t316, ptr %l131
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb77:
  %t317 = load %"compiler/ast:VarDecl", ptr %l131
  %t318 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t317, ptr %t318
  store { i64, [5 x i64] } zeroinitializer, ptr %t319
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 0
  store i64 1, ptr %t320
  %t321 = load %"compiler/source:Span", ptr %l123
  %t322 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t321, 0
  %t324 = insertvalue { %"compiler/source:Span", ptr } %t322, ptr %t318, 1
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t324, ptr %t325
  %t326 = load { i64, [5 x i64] }, ptr %t319
  %t328 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t326, ptr %t328
  %t330 = insertvalue { i32, ptr } zeroinitializer, ptr %t328, 1
  store { i32, ptr } %t330, ptr %rv
  br label %ret
bb78:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l1, !tbaa !23
  %t333 = load ptr, ptr %l9, !tbaa !29
  %t337 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t331, i32 %t332, ptr %t333)
  %t338 = extractvalue { i32, ptr } %t337, 1
  %t339 = extractvalue { i32, ptr } %t337, 0
  store i32 %t339, ptr %l140
  %t340 = icmp ne i32 %t339, 0
  br i1 %t340, label %bb80, label %ok.341
ok.341:
  store ptr %t338, ptr %l139
  br label %bb79
bb79:
  %t342 = load ptr, ptr %l139, !tbaa !29
  store ptr %t342, ptr %l135, !tbaa !29
  br label %bb81
bb80:
  %t343 = load i32, ptr %l140, !tbaa !23
  %t344 = lshr i32 %t343, 16
  %t345 = and i32 %t343, 65535
  %t346 = icmp eq i32 %t344, 1
  %t347 = select i1 %t346, i32 1, i32 0
  %t348 = icmp eq i32 %t343, 0
  %t349 = shl i32 %t347, 16
  %t350 = or i32 %t349, %t345
  %t351 = select i1 %t348, i32 0, i32 %t350
  %t353 = insertvalue { i32, ptr } zeroinitializer, i32 %t351, 0
  store { i32, ptr } %t353, ptr %rv
  br label %ret
bb81:
  %t354 = load ptr, ptr %l135, !tbaa !29
  %t355 = insertvalue { i32, ptr } zeroinitializer, ptr %t354, 1
  store { i32, ptr } %t355, ptr %rv
  br label %ret
bb82:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t356)
  store i32 %t358, ptr %l143
  br label %bb83
bb83:
  %t359 = load i32, ptr %l143
  store i32 %t359, ptr %l11
  %t360 = load i32, ptr %l11
  %t362 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t360)
  store i1 %t362, ptr %l145
  br label %bb84
bb84:
  %t363 = load i1, ptr %l145, !tbaa !21
  br i1 %t363, label %bb85, label %bb86
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t364)
  store i32 %t366, ptr %l147
  br label %bb87
bb86:
  br label %bb95
bb87:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t367)
  %t370 = extractvalue { i32, ptr } %t369, 1
  %t371 = extractvalue { i32, ptr } %t369, 0
  store i32 %t371, ptr %l151
  %t372 = icmp ne i32 %t371, 0
  br i1 %t372, label %bb89, label %ok.373
ok.373:
  store ptr %t370, ptr %l150
  br label %bb88
bb88:
  %t374 = load ptr, ptr %l150, !tbaa !29
  store ptr %t374, ptr %l148, !tbaa !29
  br label %bb90
bb89:
  %t375 = load i32, ptr %l151, !tbaa !23
  %t376 = lshr i32 %t375, 16
  %t377 = and i32 %t375, 65535
  %t378 = icmp eq i32 %t376, 1
  %t379 = select i1 %t378, i32 1, i32 0
  %t380 = icmp eq i32 %t375, 0
  %t381 = shl i32 %t379, 16
  %t382 = or i32 %t381, %t377
  %t383 = select i1 %t380, i32 0, i32 %t382
  %t385 = insertvalue { i32, ptr } zeroinitializer, i32 %t383, 0
  store { i32, ptr } %t385, ptr %rv
  br label %ret
bb90:
  %t386 = load ptr, ptr %l148, !tbaa !29
  store ptr %t386, ptr %l12, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l1, !tbaa !23
  %t391 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t387, i32 %t388)
  store %"compiler/source:Span" %t391, ptr %l155
  br label %bb91
bb91:
  %t392 = load %"compiler/source:Span", ptr %l155
  store %"compiler/source:Span" %t392, ptr %l13
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t393)
  store i32 %t395, ptr %l157
  %t396 = icmp ne i32 %t395, 0
  br i1 %t396, label %bb93, label %ok.397
ok.397:
  br label %bb92
bb92:
  br label %bb94
bb93:
  %t398 = load i32, ptr %l157, !tbaa !23
  %t399 = lshr i32 %t398, 16
  %t400 = and i32 %t398, 65535
  %t401 = icmp eq i32 %t399, 1
  %t402 = select i1 %t401, i32 1, i32 0
  %t403 = icmp eq i32 %t398, 0
  %t404 = shl i32 %t402, 16
  %t405 = or i32 %t404, %t400
  %t406 = select i1 %t403, i32 0, i32 %t405
  %t408 = insertvalue { i32, ptr } zeroinitializer, i32 %t406, 0
  store { i32, ptr } %t408, ptr %rv
  br label %ret
bb94:
  %t409 = load %"compiler/source:Span", ptr %l13
  %t410 = load i32, ptr %l11
  %t411 = load ptr, ptr %l2, !tbaa !29
  %t412 = load ptr, ptr %l12, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t413
  %t414 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 0
  store i64 3, ptr %t414
  %t416 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t409, 0
  %t418 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t416, i32 %t410, 1
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t418, ptr %t411, 2
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t420, ptr %t412, 3
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t422, ptr %t423
  %t424 = load { i64, [5 x i64] }, ptr %t413
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t424, ptr %t426
  %t428 = insertvalue { i32, ptr } zeroinitializer, ptr %t426, 1
  store { i32, ptr } %t428, ptr %rv
  br label %ret
bb95:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l1, !tbaa !23
  %t433 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t429, i32 %t430)
  store %"compiler/source:Span" %t433, ptr %l167
  br label %bb96
bb96:
  %t434 = load %"compiler/source:Span", ptr %l167
  store %"compiler/source:Span" %t434, ptr %l14
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t435)
  store i32 %t437, ptr %l169
  %t438 = icmp ne i32 %t437, 0
  br i1 %t438, label %bb98, label %ok.439
ok.439:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t440 = load i32, ptr %l169, !tbaa !23
  %t441 = lshr i32 %t440, 16
  %t442 = and i32 %t440, 65535
  %t443 = icmp eq i32 %t441, 1
  %t444 = select i1 %t443, i32 1, i32 0
  %t445 = icmp eq i32 %t440, 0
  %t446 = shl i32 %t444, 16
  %t447 = or i32 %t446, %t442
  %t448 = select i1 %t445, i32 0, i32 %t447
  %t450 = insertvalue { i32, ptr } zeroinitializer, i32 %t448, 0
  store { i32, ptr } %t450, ptr %rv
  br label %ret
bb99:
  %t451 = load %"compiler/source:Span", ptr %l14
  %t452 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t453
  %t454 = getelementptr { i64, [5 x i64] }, ptr %t453, i32 0, i32 0
  store i64 0, ptr %t454
  %t456 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t451, 0
  %t458 = insertvalue { %"compiler/source:Span", ptr } %t456, ptr %t452, 1
  %t459 = getelementptr { i64, [5 x i64] }, ptr %t453, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t458, ptr %t459
  %t460 = load { i64, [5 x i64] }, ptr %t453
  %t462 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t460, ptr %t462
  %t464 = insertvalue { i32, ptr } zeroinitializer, ptr %t462, 1
  store { i32, ptr } %t464, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l49 = alloca i32
  %l56 = alloca i1
  %l58 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i32
  %l66 = alloca i32
  %l67 = alloca i32
  %l71 = alloca i1
  %l73 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i32
  %l82 = alloca i32
  %l86 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca i1
  %l113 = alloca i32
  %l114 = alloca %"compiler/source:Span"
  %l121 = alloca %"compiler/ast:ForIn"
  %l127 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i32
  %l136 = alloca %"compiler/token:Token"
  %l137 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca i32
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca ptr
  %l150 = alloca i1
  %l151 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %l164 = alloca %"compiler/ast:VarDecl"
  %l166 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca i32
  %l171 = alloca i32
  %l174 = alloca i32
  %l175 = alloca i32
  %l177 = alloca ptr
  %l179 = alloca ptr
  %l180 = alloca i32
  %l192 = alloca %"compiler/ast:VarDecl"
  %l196 = alloca %"compiler/source:Span"
  %l201 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca i32
  %l212 = alloca i32
  %l215 = alloca i32
  %l216 = alloca i32
  %l218 = alloca ptr
  %l220 = alloca ptr
  %l221 = alloca i32
  %l223 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca i32
  %l230 = alloca %"compiler/source:Span"
  %l233 = alloca i1
  %l235 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l242 = alloca %"compiler/ast:For3"
  %l246 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca i32
  %l251 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca i32
  %l258 = alloca %"compiler/source:Span"
  %l261 = alloca i1
  %l263 = alloca i32
  %s8 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t63 = alloca { i64, [5 x i64] }, align 8
  %t268 = alloca { i64, [5 x i64] }, align 8
  %t497 = alloca { i64, [5 x i64] }, align 8
  %t635 = alloca { i64, [5 x i64] }, align 8
  %t704 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 24)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l32
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l31
  br label %bb1
bb1:
  %t9 = load i32, ptr %l31, !tbaa !23
  store i32 %t9, ptr %l28, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l32, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l28, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 92)
  store i1 %t25, ptr %l36
  br label %bb4
bb4:
  %t26 = load i1, ptr %l36, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l40
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l39
  br label %bb7
bb6:
  br label %bb16
bb7:
  %t34 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t34, ptr %l37, !tbaa !27
  br label %bb9
bb8:
  %t35 = load i32, ptr %l40, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t47, i32 %t48)
  store %"compiler/source:Span" %t51, ptr %l44
  br label %bb10
bb10:
  %t52 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t52, ptr %l3
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t53, i32 8)
  store i1 %t56, ptr %l47
  br label %bb11
bb11:
  %t57 = load i1, ptr %l47, !tbaa !21
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l49
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t61 = load %"compiler/source:Span", ptr %l3
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 0
  store i64 6, ptr %t64
  %t66 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t61, 0
  %t68 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t66, { i64, ptr } %t62, 1
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t68, ptr %t69
  %t70 = load { i64, [5 x i64] }, ptr %t63
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t70, ptr %t72
  %t74 = insertvalue { i32, ptr } zeroinitializer, ptr %t72, 1
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t75, i32 1)
  store i1 %t78, ptr %l56
  br label %bb17
bb17:
  %t79 = load i1, ptr %l56, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t80, i64 1)
  store i32 %t82, ptr %l58
  br label %bb20
bb19:
  br label %bb124
bb20:
  %t83 = load i32, ptr %l58
  store i32 %t83, ptr %l4
  %t84 = load i32, ptr %l4
  %t86 = trunc i64 26 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb23
bb22:
  %t89 = load i32, ptr %l4
  %t91 = trunc i64 55 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l61, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l61, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i32 0, ptr %l5, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i32 } %t97, 1
  %t99 = extractvalue { i32, i32 } %t97, 0
  store i32 %t99, ptr %l67
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb27, label %ok.101
ok.101:
  store i32 %t98, ptr %l66
  br label %bb26
bb25:
  br label %bb63
bb26:
  %t102 = load i32, ptr %l66, !tbaa !23
  store i32 %t102, ptr %l64, !tbaa !23
  br label %bb28
bb27:
  %t103 = load i32, ptr %l67, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  %t113 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t113, ptr %rv
  br label %ret
bb28:
  %t114 = load i32, ptr %l64, !tbaa !23
  store i32 %t114, ptr %l6, !tbaa !23
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t115, i32 55)
  store i1 %t118, ptr %l71
  br label %bb29
bb29:
  %t119 = load i1, ptr %l71, !tbaa !21
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t120 = load i32, ptr %l6, !tbaa !23
  store i32 %t120, ptr %l5, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t122)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l76
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb33, label %ok.128
ok.128:
  store i32 %t125, ptr %l75
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t129 = load i32, ptr %l75, !tbaa !23
  store i32 %t129, ptr %l73, !tbaa !23
  br label %bb34
bb33:
  %t130 = load i32, ptr %l76, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  %t140 = insertvalue { i32, ptr } zeroinitializer, i32 %t138, 0
  store { i32, ptr } %t140, ptr %rv
  br label %ret
bb34:
  %t141 = load i32, ptr %l73, !tbaa !23
  store i32 %t141, ptr %l6, !tbaa !23
  br label %bb35
bb35:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t142, i32 26)
  %t146 = extractvalue { i32, i32 } %t145, 1
  %t147 = extractvalue { i32, i32 } %t145, 0
  store i32 %t147, ptr %l82
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb37, label %ok.149
ok.149:
  store i32 %t146, ptr %l81
  br label %bb36
bb36:
  %t150 = load i32, ptr %l81, !tbaa !23
  store i32 %t150, ptr %l78, !tbaa !23
  br label %bb38
bb37:
  %t151 = load i32, ptr %l82, !tbaa !23
  %t152 = lshr i32 %t151, 16
  %t153 = and i32 %t151, 65535
  %t154 = icmp eq i32 %t152, 1
  %t155 = select i1 %t154, i32 1, i32 0
  %t156 = icmp eq i32 %t151, 0
  %t157 = shl i32 %t155, 16
  %t158 = or i32 %t157, %t153
  %t159 = select i1 %t156, i32 0, i32 %t158
  %t161 = insertvalue { i32, ptr } zeroinitializer, i32 %t159, 0
  store { i32, ptr } %t161, ptr %rv
  br label %ret
bb38:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t165 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t162, i32 11)
  store i1 %t165, ptr %l86
  br label %bb39
bb39:
  %t166 = load i1, ptr %l86, !tbaa !21
  store i1 %t166, ptr %l7, !tbaa !21
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %t167)
  %t170 = extractvalue { i32, ptr } %t169, 1
  %t171 = extractvalue { i32, ptr } %t169, 0
  store i32 %t171, ptr %l90
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb41, label %ok.173
ok.173:
  store ptr %t170, ptr %l89
  br label %bb40
bb40:
  %t174 = load ptr, ptr %l89, !tbaa !29
  store ptr %t174, ptr %l87, !tbaa !29
  br label %bb42
bb41:
  %t175 = load i32, ptr %l90, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  %t185 = insertvalue { i32, ptr } zeroinitializer, i32 %t183, 0
  store { i32, ptr } %t185, ptr %rv
  br label %ret
bb42:
  %t186 = load ptr, ptr %l87, !tbaa !29
  store ptr %t186, ptr %l8, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t187)
  %t190 = extractvalue { i32, { i64, ptr } } %t189, 1
  %t191 = extractvalue { i32, { i64, ptr } } %t189, 0
  store i32 %t191, ptr %l95
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb44, label %ok.193
ok.193:
  store { i64, ptr } %t190, ptr %l94
  br label %bb43
bb43:
  %t194 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t194, ptr %l92, !tbaa !27
  br label %bb45
bb44:
  %t195 = load i32, ptr %l95, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  %t205 = insertvalue { i32, ptr } zeroinitializer, i32 %t203, 0
  store { i32, ptr } %t205, ptr %rv
  br label %ret
bb45:
  %t206 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t206, ptr %l9, !tbaa !27
  %t207 = icmp sge i64 0, 0
  br i1 %t207, label %bb46, label %bb47
bb46:
  %t209 = icmp sle i64 0, 1152921504606846975
  br i1 %t209, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb48:
  %t211 = mul i64 0, 8
  %t212 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 0, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  store { i64, ptr } %t214, ptr %l10, !tbaa !27
  %t216 = load i1, ptr %l7, !tbaa !21
  br i1 %t216, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb50:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t218, i1 false)
  %t221 = extractvalue { i32, { i64, ptr } } %t220, 1
  %t222 = extractvalue { i32, { i64, ptr } } %t220, 0
  store i32 %t222, ptr %l104
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb53, label %ok.224
ok.224:
  store { i64, ptr } %t221, ptr %l103
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t225 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t225, ptr %l101, !tbaa !27
  br label %bb54
bb53:
  %t226 = load i32, ptr %l104, !tbaa !23
  %t227 = lshr i32 %t226, 16
  %t228 = and i32 %t226, 65535
  %t229 = icmp eq i32 %t227, 1
  %t230 = select i1 %t229, i32 1, i32 0
  %t231 = icmp eq i32 %t226, 0
  %t232 = shl i32 %t230, 16
  %t233 = or i32 %t232, %t228
  %t234 = select i1 %t231, i32 0, i32 %t233
  %t236 = insertvalue { i32, ptr } zeroinitializer, i32 %t234, 0
  store { i32, ptr } %t236, ptr %rv
  br label %ret
bb54:
  %t237 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t237, ptr %l10, !tbaa !27
  br label %bb55
bb55:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l1, !tbaa !23
  %t242 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t238, i32 %t239)
  store %"compiler/source:Span" %t242, ptr %l108
  br label %bb56
bb56:
  %t243 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t243, ptr %l11
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t247 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t244, i32 8)
  store i1 %t247, ptr %l111
  br label %bb57
bb57:
  %t248 = load i1, ptr %l111, !tbaa !21
  br i1 %t248, label %bb58, label %bb59
bb58:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t249)
  store i32 %t251, ptr %l113
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  %t252 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t252, ptr %l114
  %t253 = load i32, ptr %l5, !tbaa !23
  %t254 = load i32, ptr %l6, !tbaa !23
  %t255 = load ptr, ptr %l8, !tbaa !29
  %t256 = load i1, ptr %l7, !tbaa !21
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t265 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t253, i32 %t254, ptr %t255, i1 %t256, { i64, ptr } %t257, { i64, ptr } %t258)
  store %"compiler/ast:ForIn" %t265, ptr %l121
  br label %bb62
bb62:
  %t266 = load %"compiler/ast:ForIn", ptr %l121
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/ast:ForIn" %t266, ptr %t267
  store { i64, [5 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 0
  store i64 9, ptr %t269
  %t270 = load %"compiler/source:Span", ptr %l114
  %t271 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t270, 0
  %t273 = insertvalue { %"compiler/source:Span", ptr } %t271, ptr %t267, 1
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t273, ptr %t274
  %t275 = load { i64, [5 x i64] }, ptr %t268
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t275, ptr %t277
  %t279 = insertvalue { i32, ptr } zeroinitializer, ptr %t277, 1
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb63:
  %t280 = load i32, ptr %l4
  %t282 = trunc i64 60 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb66
bb65:
  %t285 = load i32, ptr %l4
  %t287 = trunc i64 1 to i32
  %t288 = icmp eq i32 %t285, %t287
  store i1 %t288, ptr %l127, !tbaa !21
  br label %bb66
bb66:
  %t290 = load i1, ptr %l127, !tbaa !21
  br i1 %t290, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb69
bb68:
  %t291 = load i32, ptr %l4
  %t293 = trunc i64 39 to i32
  %t294 = icmp eq i32 %t291, %t293
  store i1 %t294, ptr %l130, !tbaa !21
  br label %bb69
bb69:
  %t296 = load i1, ptr %l130, !tbaa !21
  br i1 %t296, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t297)
  store i32 %t299, ptr %l134
  br label %bb72
bb71:
  br label %bb123
bb72:
  %t300 = load i32, ptr %l134, !tbaa !23
  store i32 %t300, ptr %l12, !tbaa !23
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t301)
  store %"compiler/token:Token" %t303, ptr %l136
  br label %bb73
bb73:
  %t304 = load %"compiler/token:Token", ptr %l136
  store %"compiler/token:Token" %t304, ptr %l13
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t305)
  %t308 = extractvalue { i32, i32 } %t307, 1
  %t309 = extractvalue { i32, i32 } %t307, 0
  store i32 %t309, ptr %l140
  %t310 = icmp ne i32 %t309, 0
  br i1 %t310, label %bb75, label %ok.311
ok.311:
  store i32 %t308, ptr %l139
  br label %bb74
bb74:
  %t312 = load i32, ptr %l139, !tbaa !23
  store i32 %t312, ptr %l137, !tbaa !23
  br label %bb76
bb75:
  %t313 = load i32, ptr %l140, !tbaa !23
  %t314 = lshr i32 %t313, 16
  %t315 = and i32 %t313, 65535
  %t316 = icmp eq i32 %t314, 1
  %t317 = select i1 %t316, i32 1, i32 0
  %t318 = icmp eq i32 %t313, 0
  %t319 = shl i32 %t317, 16
  %t320 = or i32 %t319, %t315
  %t321 = select i1 %t318, i32 0, i32 %t320
  call void @__olang_scope_close(ptr %s8)
  %t323 = insertvalue { i32, ptr } zeroinitializer, i32 %t321, 0
  store { i32, ptr } %t323, ptr %rv
  br label %ret
bb76:
  %t324 = load i32, ptr %l137, !tbaa !23
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l142, !tbaa !29
  store i32 %t324, ptr %l143, !tbaa !23
  %t327 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t328 = load i32, ptr %t327, !tbaa !23
  %t329 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t330 = load i32, ptr %t329, !tbaa !23
  %t333 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t328, i32 %t330)
  store %"compiler/source:Span" %t333, ptr %l146
  br label %bb77
bb77:
  %t334 = load ptr, ptr %l142, !tbaa !29
  %t335 = load i32, ptr %l143, !tbaa !23
  %t336 = load %"compiler/source:Span", ptr %l146
  %t337 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t334, i32 %t335, %"compiler/source:Span" %t336)
  store ptr %t337, ptr %l147
  br label %bb78
bb78:
  %t338 = load ptr, ptr %l147, !tbaa !29
  store ptr %t338, ptr %l15, !tbaa !29
  store ptr null, ptr %l16, !tbaa !29
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t342 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t339, i32 60)
  store i1 %t342, ptr %l150
  br label %bb79
bb79:
  %t343 = load i1, ptr %l150, !tbaa !21
  br i1 %t343, label %bb80, label %bb81
bb80:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t344)
  %t347 = extractvalue { i32, ptr } %t346, 1
  %t348 = extractvalue { i32, ptr } %t346, 0
  store i32 %t348, ptr %l154
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb83, label %ok.350
ok.350:
  store ptr %t347, ptr %l153
  br label %bb82
bb81:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t351)
  %t354 = extractvalue { i32, ptr } %t353, 1
  %t355 = extractvalue { i32, ptr } %t353, 0
  store i32 %t355, ptr %l169
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb87, label %ok.357
ok.357:
  store ptr %t354, ptr %l168
  br label %bb86
bb82:
  %t358 = load ptr, ptr %l153, !tbaa !29
  store ptr %t358, ptr %l151, !tbaa !29
  br label %bb84
bb83:
  %t359 = load i32, ptr %l154, !tbaa !23
  %t360 = lshr i32 %t359, 16
  %t361 = and i32 %t359, 65535
  %t362 = icmp eq i32 %t360, 1
  %t363 = select i1 %t362, i32 1, i32 0
  %t364 = icmp eq i32 %t359, 0
  %t365 = shl i32 %t363, 16
  %t366 = or i32 %t365, %t361
  %t367 = select i1 %t364, i32 0, i32 %t366
  call void @__olang_scope_close(ptr %s8)
  %t369 = insertvalue { i32, ptr } zeroinitializer, i32 %t367, 0
  store { i32, ptr } %t369, ptr %rv
  br label %ret
bb84:
  %t370 = load ptr, ptr %l151, !tbaa !29
  %t371 = load ptr, ptr %l15, !tbaa !29
  %t373 = getelementptr %"compiler/parse:NameList", ptr %t371, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  %t375 = load ptr, ptr %l15, !tbaa !29
  %t377 = getelementptr %"compiler/parse:NameList", ptr %t375, i32 0, i32 1
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  %t381 = insertvalue [1 x ptr] undef, ptr %t370, 0
  %t383 = load ptr, ptr @__olang_prog_scope
  %t384 = call ptr @__olang_scope_alloc(ptr %t383, i64 8)
  store [1 x ptr] %t381, ptr %t384
  %t385 = insertvalue { i64, ptr } undef, i64 1, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = extractvalue { i64, ptr } %t386, 1
  %t390 = mul i64 %t388, 8
  %t391 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  %t397 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t374, { i64, ptr } %t378, ptr null, { i64, ptr } %t393, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t397, ptr %l164
  br label %bb85
bb85:
  %t398 = load %"compiler/ast:VarDecl", ptr %l164
  %t399 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t398, ptr %t399
  store ptr %t399, ptr %l16, !tbaa !29
  br label %bb96
bb86:
  %t401 = load ptr, ptr %l168, !tbaa !29
  store ptr %t401, ptr %l166, !tbaa !29
  br label %bb88
bb87:
  %t402 = load i32, ptr %l169, !tbaa !23
  %t403 = lshr i32 %t402, 16
  %t404 = and i32 %t402, 65535
  %t405 = icmp eq i32 %t403, 1
  %t406 = select i1 %t405, i32 1, i32 0
  %t407 = icmp eq i32 %t402, 0
  %t408 = shl i32 %t406, 16
  %t409 = or i32 %t408, %t404
  %t410 = select i1 %t407, i32 0, i32 %t409
  call void @__olang_scope_close(ptr %s8)
  %t412 = insertvalue { i32, ptr } zeroinitializer, i32 %t410, 0
  store { i32, ptr } %t412, ptr %rv
  br label %ret
bb88:
  %t413 = load ptr, ptr %l166, !tbaa !29
  store ptr %t413, ptr %l18, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t414, i32 58)
  %t418 = extractvalue { i32, i32 } %t417, 1
  %t419 = extractvalue { i32, i32 } %t417, 0
  store i32 %t419, ptr %l175
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb90, label %ok.421
ok.421:
  store i32 %t418, ptr %l174
  br label %bb89
bb89:
  %t422 = load i32, ptr %l174, !tbaa !23
  store i32 %t422, ptr %l171, !tbaa !23
  br label %bb91
bb90:
  %t423 = load i32, ptr %l175, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  call void @__olang_scope_close(ptr %s8)
  %t433 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb91:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t434)
  %t437 = extractvalue { i32, ptr } %t436, 1
  %t438 = extractvalue { i32, ptr } %t436, 0
  store i32 %t438, ptr %l180
  %t439 = icmp ne i32 %t438, 0
  br i1 %t439, label %bb93, label %ok.440
ok.440:
  store ptr %t437, ptr %l179
  br label %bb92
bb92:
  %t441 = load ptr, ptr %l179, !tbaa !29
  store ptr %t441, ptr %l177, !tbaa !29
  br label %bb94
bb93:
  %t442 = load i32, ptr %l180, !tbaa !23
  %t443 = lshr i32 %t442, 16
  %t444 = and i32 %t442, 65535
  %t445 = icmp eq i32 %t443, 1
  %t446 = select i1 %t445, i32 1, i32 0
  %t447 = icmp eq i32 %t442, 0
  %t448 = shl i32 %t446, 16
  %t449 = or i32 %t448, %t444
  %t450 = select i1 %t447, i32 0, i32 %t449
  call void @__olang_scope_close(ptr %s8)
  %t452 = insertvalue { i32, ptr } zeroinitializer, i32 %t450, 0
  store { i32, ptr } %t452, ptr %rv
  br label %ret
bb94:
  %t453 = load ptr, ptr %l177, !tbaa !29
  %t454 = load ptr, ptr %l15, !tbaa !29
  %t456 = getelementptr %"compiler/parse:NameList", ptr %t454, i32 0, i32 0
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  %t458 = load ptr, ptr %l15, !tbaa !29
  %t460 = getelementptr %"compiler/parse:NameList", ptr %t458, i32 0, i32 1
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  %t462 = load ptr, ptr %l18, !tbaa !29
  %t466 = insertvalue [1 x ptr] undef, ptr %t453, 0
  %t468 = load ptr, ptr @__olang_prog_scope
  %t469 = call ptr @__olang_scope_alloc(ptr %t468, i64 8)
  store [1 x ptr] %t466, ptr %t469
  %t470 = insertvalue { i64, ptr } undef, i64 1, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = extractvalue { i64, ptr } %t471, 1
  %t475 = mul i64 %t473, 8
  %t476 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t475)
  call void @llvm.memcpy.p0.p0.i64(ptr %t476, ptr %t474, i64 %t475, i1 false)
  %t477 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  %t483 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t457, { i64, ptr } %t461, ptr %t462, { i64, ptr } %t478, i1 false, i1 false)
  store %"compiler/ast:VarDecl" %t483, ptr %l192
  br label %bb95
bb95:
  %t484 = load %"compiler/ast:VarDecl", ptr %l192
  %t485 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t484, ptr %t485
  store ptr %t485, ptr %l16, !tbaa !29
  br label %bb96
bb96:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load i32, ptr %l12, !tbaa !23
  %t491 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t487, i32 %t488)
  store %"compiler/source:Span" %t491, ptr %l196
  br label %bb97
bb97:
  %t492 = load ptr, ptr %l16, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  br i1 %t494, label %bb98, label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2)
  unreachable
bb99:
  br label %bb100
bb100:
  %t496 = load ptr, ptr %l16, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t497
  %t498 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 0
  store i64 1, ptr %t498
  %t499 = load %"compiler/source:Span", ptr %l196
  %t500 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t499, 0
  %t502 = insertvalue { %"compiler/source:Span", ptr } %t500, ptr %t496, 1
  %t503 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t502, ptr %t503
  %t504 = load { i64, [5 x i64] }, ptr %t497
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t505, ptr %lp20
  %t507 = load ptr, ptr %lp20
  store { i64, [5 x i64] } %t504, ptr %t507
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t511 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t508, i32 55)
  %t512 = extractvalue { i32, i32 } %t511, 1
  %t513 = extractvalue { i32, i32 } %t511, 0
  store i32 %t513, ptr %l205
  %t514 = icmp ne i32 %t513, 0
  br i1 %t514, label %bb102, label %ok.515
ok.515:
  store i32 %t512, ptr %l204
  br label %bb101
bb101:
  %t516 = load i32, ptr %l204, !tbaa !23
  store i32 %t516, ptr %l201, !tbaa !23
  br label %bb103
bb102:
  %t517 = load i32, ptr %l205, !tbaa !23
  %t518 = lshr i32 %t517, 16
  %t519 = and i32 %t517, 65535
  %t520 = icmp eq i32 %t518, 1
  %t521 = select i1 %t520, i32 1, i32 0
  %t522 = icmp eq i32 %t517, 0
  %t523 = shl i32 %t521, 16
  %t524 = or i32 %t523, %t519
  %t525 = select i1 %t522, i32 0, i32 %t524
  call void @__olang_scope_close(ptr %s8)
  %t527 = insertvalue { i32, ptr } zeroinitializer, i32 %t525, 0
  store { i32, ptr } %t527, ptr %rv
  br label %ret
bb103:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t528)
  %t531 = extractvalue { i32, ptr } %t530, 1
  %t532 = extractvalue { i32, ptr } %t530, 0
  store i32 %t532, ptr %l210
  %t533 = icmp ne i32 %t532, 0
  br i1 %t533, label %bb105, label %ok.534
ok.534:
  store ptr %t531, ptr %l209
  br label %bb104
bb104:
  %t535 = load ptr, ptr %l209, !tbaa !29
  store ptr %t535, ptr %l207, !tbaa !29
  br label %bb106
bb105:
  %t536 = load i32, ptr %l210, !tbaa !23
  %t537 = lshr i32 %t536, 16
  %t538 = and i32 %t536, 65535
  %t539 = icmp eq i32 %t537, 1
  %t540 = select i1 %t539, i32 1, i32 0
  %t541 = icmp eq i32 %t536, 0
  %t542 = shl i32 %t540, 16
  %t543 = or i32 %t542, %t538
  %t544 = select i1 %t541, i32 0, i32 %t543
  call void @__olang_scope_close(ptr %s8)
  %t546 = insertvalue { i32, ptr } zeroinitializer, i32 %t544, 0
  store { i32, ptr } %t546, ptr %rv
  br label %ret
bb106:
  %t547 = load ptr, ptr %l207, !tbaa !29
  store ptr %t547, ptr %l21, !tbaa !29
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t551 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t548, i32 55)
  %t552 = extractvalue { i32, i32 } %t551, 1
  %t553 = extractvalue { i32, i32 } %t551, 0
  store i32 %t553, ptr %l216
  %t554 = icmp ne i32 %t553, 0
  br i1 %t554, label %bb108, label %ok.555
ok.555:
  store i32 %t552, ptr %l215
  br label %bb107
bb107:
  %t556 = load i32, ptr %l215, !tbaa !23
  store i32 %t556, ptr %l212, !tbaa !23
  br label %bb109
bb108:
  %t557 = load i32, ptr %l216, !tbaa !23
  %t558 = lshr i32 %t557, 16
  %t559 = and i32 %t557, 65535
  %t560 = icmp eq i32 %t558, 1
  %t561 = select i1 %t560, i32 1, i32 0
  %t562 = icmp eq i32 %t557, 0
  %t563 = shl i32 %t561, 16
  %t564 = or i32 %t563, %t559
  %t565 = select i1 %t562, i32 0, i32 %t564
  call void @__olang_scope_close(ptr %s8)
  %t567 = insertvalue { i32, ptr } zeroinitializer, i32 %t565, 0
  store { i32, ptr } %t567, ptr %rv
  br label %ret
bb109:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %t568)
  %t571 = extractvalue { i32, ptr } %t570, 1
  %t572 = extractvalue { i32, ptr } %t570, 0
  store i32 %t572, ptr %l221
  %t573 = icmp ne i32 %t572, 0
  br i1 %t573, label %bb111, label %ok.574
ok.574:
  store ptr %t571, ptr %l220
  br label %bb110
bb110:
  %t575 = load ptr, ptr %l220, !tbaa !29
  store ptr %t575, ptr %l218, !tbaa !29
  br label %bb112
bb111:
  %t576 = load i32, ptr %l221, !tbaa !23
  %t577 = lshr i32 %t576, 16
  %t578 = and i32 %t576, 65535
  %t579 = icmp eq i32 %t577, 1
  %t580 = select i1 %t579, i32 1, i32 0
  %t581 = icmp eq i32 %t576, 0
  %t582 = shl i32 %t580, 16
  %t583 = or i32 %t582, %t578
  %t584 = select i1 %t581, i32 0, i32 %t583
  call void @__olang_scope_close(ptr %s8)
  %t586 = insertvalue { i32, ptr } zeroinitializer, i32 %t584, 0
  store { i32, ptr } %t586, ptr %rv
  br label %ret
bb112:
  %t587 = load ptr, ptr %l218, !tbaa !29
  store ptr %t587, ptr %l22, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t588)
  %t591 = extractvalue { i32, { i64, ptr } } %t590, 1
  %t592 = extractvalue { i32, { i64, ptr } } %t590, 0
  store i32 %t592, ptr %l226
  %t593 = icmp ne i32 %t592, 0
  br i1 %t593, label %bb114, label %ok.594
ok.594:
  store { i64, ptr } %t591, ptr %l225
  br label %bb113
bb113:
  %t595 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t595, ptr %l223, !tbaa !27
  br label %bb115
bb114:
  %t596 = load i32, ptr %l226, !tbaa !23
  %t597 = lshr i32 %t596, 16
  %t598 = and i32 %t596, 65535
  %t599 = icmp eq i32 %t597, 1
  %t600 = select i1 %t599, i32 1, i32 0
  %t601 = icmp eq i32 %t596, 0
  %t602 = shl i32 %t600, 16
  %t603 = or i32 %t602, %t598
  %t604 = select i1 %t601, i32 0, i32 %t603
  call void @__olang_scope_close(ptr %s8)
  %t606 = insertvalue { i32, ptr } zeroinitializer, i32 %t604, 0
  store { i32, ptr } %t606, ptr %rv
  br label %ret
bb115:
  %t607 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t607, ptr %l23, !tbaa !27
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i32, ptr %l1, !tbaa !23
  %t612 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t608, i32 %t609)
  store %"compiler/source:Span" %t612, ptr %l230
  br label %bb116
bb116:
  %t613 = load %"compiler/source:Span", ptr %l230
  store %"compiler/source:Span" %t613, ptr %l24
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t617 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t614, i32 8)
  store i1 %t617, ptr %l233
  br label %bb117
bb117:
  %t618 = load i1, ptr %l233, !tbaa !21
  br i1 %t618, label %bb118, label %bb119
bb118:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t619)
  store i32 %t621, ptr %l235
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb121
bb121:
  %t622 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t622, ptr %l236
  %t623 = load ptr, ptr %lp20
  %t624 = load ptr, ptr %l21, !tbaa !29
  %t626 = load ptr, ptr %l22, !tbaa !29
  %t627 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t632 = call %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t623, ptr %t624, ptr %t626, { i64, ptr } %t627)
  store %"compiler/ast:For3" %t632, ptr %l242
  br label %bb122
bb122:
  %t633 = load %"compiler/ast:For3", ptr %l242
  %t634 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:For3" %t633, ptr %t634
  store { i64, [5 x i64] } zeroinitializer, ptr %t635
  %t636 = getelementptr { i64, [5 x i64] }, ptr %t635, i32 0, i32 0
  store i64 8, ptr %t636
  %t637 = load %"compiler/source:Span", ptr %l236
  %t638 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t637, 0
  %t640 = insertvalue { %"compiler/source:Span", ptr } %t638, ptr %t634, 1
  %t641 = getelementptr { i64, [5 x i64] }, ptr %t635, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t640, ptr %t641
  %t642 = load { i64, [5 x i64] }, ptr %t635
  %t644 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t642, ptr %t644
  call void @__olang_scope_close(ptr %s8)
  %t646 = insertvalue { i32, ptr } zeroinitializer, ptr %t644, 1
  store { i32, ptr } %t646, ptr %rv
  br label %ret
bb123:
  br label %bb124
bb124:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t647)
  %t650 = extractvalue { i32, ptr } %t649, 1
  %t651 = extractvalue { i32, ptr } %t649, 0
  store i32 %t651, ptr %l249
  %t652 = icmp ne i32 %t651, 0
  br i1 %t652, label %bb126, label %ok.653
ok.653:
  store ptr %t650, ptr %l248
  br label %bb125
bb125:
  %t654 = load ptr, ptr %l248, !tbaa !29
  store ptr %t654, ptr %l246, !tbaa !29
  br label %bb127
bb126:
  %t655 = load i32, ptr %l249, !tbaa !23
  %t656 = lshr i32 %t655, 16
  %t657 = and i32 %t655, 65535
  %t658 = icmp eq i32 %t656, 1
  %t659 = select i1 %t658, i32 1, i32 0
  %t660 = icmp eq i32 %t655, 0
  %t661 = shl i32 %t659, 16
  %t662 = or i32 %t661, %t657
  %t663 = select i1 %t660, i32 0, i32 %t662
  %t665 = insertvalue { i32, ptr } zeroinitializer, i32 %t663, 0
  store { i32, ptr } %t665, ptr %rv
  br label %ret
bb127:
  %t666 = load ptr, ptr %l246, !tbaa !29
  store ptr %t666, ptr %l25, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t669 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t667)
  %t670 = extractvalue { i32, { i64, ptr } } %t669, 1
  %t671 = extractvalue { i32, { i64, ptr } } %t669, 0
  store i32 %t671, ptr %l254
  %t672 = icmp ne i32 %t671, 0
  br i1 %t672, label %bb129, label %ok.673
ok.673:
  store { i64, ptr } %t670, ptr %l253
  br label %bb128
bb128:
  %t674 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t674, ptr %l251, !tbaa !27
  br label %bb130
bb129:
  %t675 = load i32, ptr %l254, !tbaa !23
  %t676 = lshr i32 %t675, 16
  %t677 = and i32 %t675, 65535
  %t678 = icmp eq i32 %t676, 1
  %t679 = select i1 %t678, i32 1, i32 0
  %t680 = icmp eq i32 %t675, 0
  %t681 = shl i32 %t679, 16
  %t682 = or i32 %t681, %t677
  %t683 = select i1 %t680, i32 0, i32 %t682
  %t685 = insertvalue { i32, ptr } zeroinitializer, i32 %t683, 0
  store { i32, ptr } %t685, ptr %rv
  br label %ret
bb130:
  %t686 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t686, ptr %l26, !tbaa !27
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load i32, ptr %l1, !tbaa !23
  %t691 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t687, i32 %t688)
  store %"compiler/source:Span" %t691, ptr %l258
  br label %bb131
bb131:
  %t692 = load %"compiler/source:Span", ptr %l258
  store %"compiler/source:Span" %t692, ptr %l27
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t696 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t693, i32 8)
  store i1 %t696, ptr %l261
  br label %bb132
bb132:
  %t697 = load i1, ptr %l261, !tbaa !21
  br i1 %t697, label %bb133, label %bb134
bb133:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t698)
  store i32 %t700, ptr %l263
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t701 = load %"compiler/source:Span", ptr %l27
  %t702 = load ptr, ptr %l25, !tbaa !29
  %t703 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t704
  %t705 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 0
  store i64 7, ptr %t705
  %t707 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t701, 0
  %t709 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t707, ptr %t702, 1
  %t711 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t709, { i64, ptr } %t703, 2
  %t712 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t711, ptr %t712
  %t713 = load { i64, [5 x i64] }, ptr %t704
  %t715 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t713, ptr %t715
  %t717 = insertvalue { i32, ptr } zeroinitializer, ptr %t715, 1
  store { i32, ptr } %t717, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l19 = alloca i32
  %l22 = alloca i64
  %l27 = alloca i32
  %l30 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i64
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l123 = alloca { i64, ptr }
  %l134 = alloca i1
  %l137 = alloca { i64, ptr }
  %l147 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca i1
  %l158 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i64
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l182 = alloca %"compiler/msgs:Msg"
  %l186 = alloca i1
  %l187 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l198 = alloca i64
  %l201 = alloca i1
  %l205 = alloca i32
  %l208 = alloca i1
  %l212 = alloca i32
  %l215 = alloca i1
  %l219 = alloca i32
  %l222 = alloca ptr
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l228 = alloca %"compiler/msgs:Msg"
  %l232 = alloca i1
  %l236 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l252 = alloca %"compiler/msgs:Msg"
  %l256 = alloca ptr
  %l257 = alloca i64
  %l258 = alloca %"compiler/msgs:Msg"
  %l262 = alloca i1
  %l265 = alloca i1
  %l269 = alloca i1
  %l272 = alloca i1
  %l273 = alloca i1
  %l274 = alloca ptr
  %l277 = alloca i64
  %l279 = alloca i1
  %l283 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i1
  %l291 = alloca i1
  %l293 = alloca i1
  %l294 = alloca i1
  %l297 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l308 = alloca i1
  %l312 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i64
  %l317 = alloca i64
  %l318 = alloca i1
  %l322 = alloca i1
  %l326 = alloca i1
  %l329 = alloca i1
  %l332 = alloca i1
  %l336 = alloca ptr
  %l337 = alloca i64
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/msgs:Msg"
  %l346 = alloca i1
  %l349 = alloca ptr
  %l350 = alloca i64
  %l351 = alloca %"compiler/msgs:Msg"
  %l355 = alloca i1
  %l356 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l360 = alloca i1
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l370 = alloca i1
  %l376 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 6
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load i32, ptr %l19
  store i32 %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l22
  br label %bb5
bb5:
  %t28 = load i64, ptr %l22, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l27
  br label %bb6
bb6:
  %t38 = load i32, ptr %l27
  store i32 %t38, ptr %l6
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l30
  br label %bb7
bb7:
  %t44 = load i64, ptr %l30, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t45 = load i32, ptr %l3
  %t47 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t45)
  store i1 %t47, ptr %l32
  br label %bb8
bb8:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 13, ptr @.d1 })
  store i1 %t51, ptr %l35
  br label %bb11
bb10:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l35, !tbaa !21
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load i32, ptr %l6
  %t56 = trunc i64 74 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l44
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t69 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %s2, ptr %s2, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t77, ptr %l46
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i64, ptr %l41, !tbaa !24
  %t80 = load %"compiler/msgs:Msg", ptr %l46
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t78, i64 %t79, %"compiler/msgs:Msg" %t80)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l50
  br label %bb22
bb22:
  %t87 = load i1, ptr %l50, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %s3)
  store %"compiler/msgs:Msg" %t90, ptr %l53
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = load %"compiler/msgs:Msg", ptr %l53
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s3, ptr %t91, i64 %t92, %"compiler/msgs:Msg" %t93)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l57
  br label %bb28
bb28:
  %t100 = load i1, ptr %l57, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l58, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t114 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t108, i64 %t111)
  store i64 %t114, ptr %l66
  br label %bb34
bb33:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l66, !tbaa !24
  %t118 = icmp slt i64 %t116, %t115
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb36, label %bb37
bb36:
  %t121 = load i32, ptr %l3
  %t123 = trunc i64 39 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb62
bb38:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb40
bb39:
  %t126 = load i32, ptr %l3
  %t128 = trunc i64 60 to i32
  %t129 = icmp eq i32 %t126, %t128
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l72, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb43
bb42:
  %t132 = load i32, ptr %l3
  %t134 = trunc i64 58 to i32
  %t135 = icmp eq i32 %t132, %t134
  store i1 %t135, ptr %l75, !tbaa !21
  br label %bb43
bb43:
  %t137 = load i1, ptr %l75, !tbaa !21
  br i1 %t137, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb46
bb45:
  %t138 = load i32, ptr %l3
  %t140 = trunc i64 55 to i32
  %t141 = icmp eq i32 %t138, %t140
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb46
bb46:
  %t143 = load i1, ptr %l78, !tbaa !21
  br i1 %t143, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb61
bb48:
  %t144 = load i32, ptr %l3
  %t146 = trunc i64 1 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load i32, ptr %l6
  %t151 = trunc i64 18 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb60
bb51:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb53
bb52:
  %t154 = load i32, ptr %l6
  %t156 = trunc i64 19 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t159 = load i1, ptr %l87, !tbaa !21
  br i1 %t159, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb56
bb55:
  %t160 = load i32, ptr %l6
  %t162 = trunc i64 20 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l90, !tbaa !21
  br label %bb56
bb56:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb59
bb58:
  %t166 = load i32, ptr %l6
  %t168 = trunc i64 15 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l93, !tbaa !21
  br label %bb59
bb59:
  %t171 = load i1, ptr %l93, !tbaa !21
  store i1 %t171, ptr %l84, !tbaa !21
  br label %bb60
bb60:
  %t172 = load i1, ptr %l84, !tbaa !21
  store i1 %t172, ptr %l81, !tbaa !21
  br label %bb61
bb61:
  %t173 = load i1, ptr %l81, !tbaa !21
  store i1 %t173, ptr %l69, !tbaa !21
  br label %bb62
bb62:
  %t174 = load i1, ptr %l69, !tbaa !21
  br i1 %t174, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s4
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l96, !tbaa !29
  %t176 = load i64, ptr %l5, !tbaa !24
  store i64 %t176, ptr %l97, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l5, !tbaa !24
  %t181 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s4, ptr %t177, i64 %t178)
  store { i64, ptr } %t181, ptr %l100
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t182 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s4, ptr %s4, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l102
  br label %bb66
bb66:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load i64, ptr %l97, !tbaa !24
  %t193 = load %"compiler/msgs:Msg", ptr %l102
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t191, i64 %t192, %"compiler/msgs:Msg" %t193)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb68:
  %t195 = load i32, ptr %l6
  %t197 = trunc i64 74 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb69, label %bb70
bb69:
  %t200 = load i32, ptr %l3
  %t202 = trunc i64 20 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb83
bb71:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb73
bb72:
  %t205 = load i32, ptr %l3
  %t207 = trunc i64 14 to i32
  %t208 = icmp eq i32 %t205, %t207
  store i1 %t208, ptr %l109, !tbaa !21
  br label %bb73
bb73:
  %t210 = load i1, ptr %l109, !tbaa !21
  br i1 %t210, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb76
bb75:
  %t211 = load i32, ptr %l3
  %t213 = trunc i64 18 to i32
  %t214 = icmp eq i32 %t211, %t213
  store i1 %t214, ptr %l112, !tbaa !21
  br label %bb76
bb76:
  %t216 = load i1, ptr %l112, !tbaa !21
  br i1 %t216, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb79
bb78:
  %t217 = load i32, ptr %l3
  %t219 = trunc i64 19 to i32
  %t220 = icmp eq i32 %t217, %t219
  store i1 %t220, ptr %l115, !tbaa !21
  br label %bb79
bb79:
  %t222 = load i1, ptr %l115, !tbaa !21
  br i1 %t222, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb82
bb81:
  %t223 = load i32, ptr %l3
  %t225 = trunc i64 38 to i32
  %t226 = icmp eq i32 %t223, %t225
  store i1 %t226, ptr %l118, !tbaa !21
  br label %bb82
bb82:
  %t228 = load i1, ptr %l118, !tbaa !21
  store i1 %t228, ptr %l106, !tbaa !21
  br label %bb83
bb83:
  %t229 = load i1, ptr %l106, !tbaa !21
  br i1 %t229, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s5
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = getelementptr %"compiler/scan:Tokens", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l123, !tbaa !27
  %t237 = load i64, ptr %l2, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr %"compiler/token:Token", ptr %t240, i64 %t237
  %t242 = getelementptr %"compiler/token:Token", ptr %t241, i32 0, i32 2
  %t243 = load i32, ptr %t242, !tbaa !23
  %t245 = sext i32 %t243 to i64
  store i64 %t245, ptr %l8, !tbaa !24
  %t247 = load i64, ptr %l8, !tbaa !24
  store i64 %t247, ptr %l9, !tbaa !24
  br label %bb86
bb85:
  br label %bb116
bb86:
  store %olang.scope zeroinitializer, ptr %s6
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/parse:Parser", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/source:Source", ptr %t253, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t261 = icmp slt i64 %t249, %t258
  br i1 %t261, label %bb87, label %bb88
bb87:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/parse:Parser", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/source:Source", ptr %t266, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l137, !tbaa !27
  %t270 = load i64, ptr %l9, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i8, ptr %t273, i64 %t270
  %t275 = load i8, ptr %t274, !tbaa !32
  %t277 = icmp ne i8 %t275, 10
  store i1 %t277, ptr %l134, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb89
bb89:
  %t279 = load i1, ptr %l134, !tbaa !21
  %t280 = xor i1 %t279, true
  br i1 %t280, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s6)
  br label %bb94
bb91:
  br label %bb92
bb92:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t284 = add i64 %t282, 1
  store i64 %t284, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb93
bb93:
  br label %bb86
bb94:
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s7
  %t286 = load i64, ptr %l9, !tbaa !24
  %t287 = load i64, ptr %l8, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb96, label %bb97
bb96:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/source:Source", ptr %t295, i32 0, i32 1
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l150, !tbaa !27
  %t299 = load i64, ptr %l9, !tbaa !24
  %t301 = sub i64 %t299, 1
  %t303 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i8, ptr %t304, i64 %t301
  %t306 = load i8, ptr %t305, !tbaa !32
  %t308 = icmp eq i8 %t306, 32
  br i1 %t308, label %bb98, label %bb99
bb97:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb101
bb98:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb100
bb99:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/source:Source", ptr %t313, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l158, !tbaa !27
  %t317 = load i64, ptr %l9, !tbaa !24
  %t319 = sub i64 %t317, 1
  %t321 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i8, ptr %t322, i64 %t319
  %t324 = load i8, ptr %t323, !tbaa !32
  %t326 = icmp eq i8 %t324, 9
  store i1 %t326, ptr %l155, !tbaa !21
  br label %bb100
bb100:
  %t328 = load i1, ptr %l155, !tbaa !21
  store i1 %t328, ptr %l147, !tbaa !21
  br label %bb101
bb101:
  %t329 = load i1, ptr %l147, !tbaa !21
  %t330 = xor i1 %t329, true
  br i1 %t330, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s7)
  br label %bb106
bb103:
  br label %bb104
bb104:
  %t332 = load i64, ptr %l9, !tbaa !24
  %t334 = sub i64 %t332, 1
  store i64 %t334, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb105
bb105:
  br label %bb95
bb106:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l166, !tbaa !29
  %t337 = load i64, ptr %l2, !tbaa !24
  store i64 %t337, ptr %l167, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l2, !tbaa !24
  %t342 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s5, ptr %t338, i64 %t339)
  store { i64, ptr } %t342, ptr %l170
  br label %bb107
bb107:
  %t343 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l171, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/source:Source", ptr %t353, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  store { i64, ptr } %t356, ptr %l174, !tbaa !27
  %t357 = load i64, ptr %l8, !tbaa !24
  store i64 %t357, ptr %l175, !tbaa !24
  %t358 = load i64, ptr %l9, !tbaa !24
  store i64 %t358, ptr %l176, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l177, !tbaa !24
  %t361 = load i64, ptr %l175, !tbaa !24
  %t362 = icmp sge i64 %t361, 0
  br i1 %t362, label %bb108, label %bb109
bb108:
  %t364 = load i64, ptr %l175, !tbaa !24
  %t365 = load i64, ptr %l176, !tbaa !24
  %t366 = icmp sle i64 %t364, %t365
  br i1 %t366, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb110:
  %t368 = load i64, ptr %l176, !tbaa !24
  %t369 = load i64, ptr %l177, !tbaa !24
  %t370 = icmp sle i64 %t368, %t369
  br i1 %t370, label %bb112, label %bb113
bb111:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb112:
  %t372 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = load i64, ptr %l175, !tbaa !24
  %t375 = load i64, ptr %l176, !tbaa !24
  %t376 = getelementptr i8, ptr %t373, i64 %t374
  %t377 = sub i64 %t375, %t374
  %t378 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t376, 1
  %t380 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t382 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %s5, ptr %v0, ptr %s5, { i64, ptr } %t380, { i64, ptr } %t379)
  store %"compiler/msgs:Msg" %t382, ptr %l182
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb114:
  %t383 = load ptr, ptr %l166, !tbaa !29
  %t384 = load i64, ptr %l167, !tbaa !24
  %t385 = load %"compiler/msgs:Msg", ptr %l182
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t383, i64 %t384, %"compiler/msgs:Msg" %t385)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb116:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i64, ptr %l2, !tbaa !24
  %t391 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t387, i64 %t388)
  store i1 %t391, ptr %l186
  br label %bb117
bb117:
  %t392 = load i1, ptr %l186, !tbaa !21
  br i1 %t392, label %bb118, label %bb119
bb118:
  %t393 = load i32, ptr %l3
  %t395 = trunc i64 39 to i32
  %t396 = icmp eq i32 %t393, %t395
  %t398 = xor i1 %t396, true
  store i1 %t398, ptr %l187, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb120
bb120:
  %t400 = load i1, ptr %l187, !tbaa !21
  br i1 %t400, label %bb121, label %bb122
bb121:
  %t401 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 6, ptr @.d2 })
  store i1 %t403, ptr %l193
  br label %bb123
bb122:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb140
bb123:
  %t404 = load i1, ptr %l193, !tbaa !21
  br i1 %t404, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb139
bb125:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l2, !tbaa !24
  %t408 = add i64 %t406, 1
  %t411 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t405, i64 %t408)
  store i64 %t411, ptr %l198
  br label %bb126
bb126:
  %t412 = load i64, ptr %l4, !tbaa !24
  %t413 = load i64, ptr %l198, !tbaa !24
  %t415 = icmp eq i64 %t413, %t412
  br i1 %t415, label %bb127, label %bb128
bb127:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i64, ptr %l2, !tbaa !24
  %t420 = add i64 %t418, 1
  %t423 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t417, i64 %t420)
  store i32 %t423, ptr %l205
  br label %bb129
bb128:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb138
bb129:
  %t424 = load i32, ptr %l205
  %t426 = trunc i64 1 to i32
  %t427 = icmp eq i32 %t424, %t426
  br i1 %t427, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb133
bb131:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i64, ptr %l2, !tbaa !24
  %t432 = add i64 %t430, 1
  %t435 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t429, i64 %t432)
  store i32 %t435, ptr %l212
  br label %bb132
bb132:
  %t436 = load i32, ptr %l212
  %t438 = trunc i64 39 to i32
  %t439 = icmp eq i32 %t436, %t438
  store i1 %t439, ptr %l208, !tbaa !21
  br label %bb133
bb133:
  %t441 = load i1, ptr %l208, !tbaa !21
  br i1 %t441, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb137
bb135:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l2, !tbaa !24
  %t445 = add i64 %t443, 1
  %t448 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t442, i64 %t445)
  store i32 %t448, ptr %l219
  br label %bb136
bb136:
  %t449 = load i32, ptr %l219
  %t451 = trunc i64 60 to i32
  %t452 = icmp eq i32 %t449, %t451
  store i1 %t452, ptr %l215, !tbaa !21
  br label %bb137
bb137:
  %t454 = load i1, ptr %l215, !tbaa !21
  store i1 %t454, ptr %l201, !tbaa !21
  br label %bb138
bb138:
  %t455 = load i1, ptr %l201, !tbaa !21
  store i1 %t455, ptr %l194, !tbaa !21
  br label %bb139
bb139:
  %t456 = load i1, ptr %l194, !tbaa !21
  store i1 %t456, ptr %l191, !tbaa !21
  br label %bb140
bb140:
  %t457 = load i1, ptr %l191, !tbaa !21
  br i1 %t457, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s8
  %t458 = load ptr, ptr %l0, !tbaa !29
  store ptr %t458, ptr %l222, !tbaa !29
  %t459 = load i64, ptr %l2, !tbaa !24
  store i64 %t459, ptr %l223, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i64, ptr %l2, !tbaa !24
  %t464 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s8, ptr %t460, i64 %t461)
  store { i64, ptr } %t464, ptr %l226
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t465 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t473 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s8, ptr %s8, { i64, ptr } %t471)
  store %"compiler/msgs:Msg" %t473, ptr %l228
  br label %bb144
bb144:
  %t474 = load ptr, ptr %l222, !tbaa !29
  %t475 = load i64, ptr %l223, !tbaa !24
  %t476 = load %"compiler/msgs:Msg", ptr %l228
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s8, ptr %t474, i64 %t475, %"compiler/msgs:Msg" %t476)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb146:
  %t478 = load i32, ptr %l6
  %t480 = trunc i64 8 to i32
  %t481 = icmp eq i32 %t478, %t480
  br i1 %t481, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb149
bb148:
  %t483 = load i64, ptr %l7, !tbaa !24
  %t484 = load i64, ptr %l4, !tbaa !24
  %t487 = icmp slt i64 %t483, %t484
  store i1 %t487, ptr %l232, !tbaa !21
  br label %bb149
bb149:
  %t489 = load i1, ptr %l232, !tbaa !21
  br i1 %t489, label %bb150, label %bb151
bb150:
  %t490 = load i64, ptr %l4, !tbaa !24
  %t492 = icmp sgt i64 %t490, 0
  store i1 %t492, ptr %l236, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb152
bb152:
  %t494 = load i1, ptr %l236, !tbaa !21
  br i1 %t494, label %bb153, label %bb154
bb153:
  %t495 = load i32, ptr %l3
  %t497 = call i1 @compiler_2fparse_2eisJoiningOp(i32 %t495)
  store i1 %t497, ptr %l241
  br label %bb155
bb154:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb156
bb155:
  %t498 = load i1, ptr %l241, !tbaa !21
  store i1 %t498, ptr %l239, !tbaa !21
  br label %bb156
bb156:
  %t499 = load i1, ptr %l239, !tbaa !21
  br i1 %t499, label %bb157, label %bb158
bb157:
  store %olang.scope zeroinitializer, ptr %s9
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %l2, !tbaa !24
  store i64 %t501, ptr %l243, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i64, ptr %l2, !tbaa !24
  %t506 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s9, ptr %t502, i64 %t503)
  store { i64, ptr } %t506, ptr %l246
  br label %bb159
bb158:
  br label %bb163
bb159:
  %t507 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 0
  %t509 = extractvalue { i64, ptr } %t507, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l247, !tbaa !27
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l2, !tbaa !24
  %t518 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s9, ptr %t514, i64 %t515)
  store { i64, ptr } %t518, ptr %l250
  br label %bb160
bb160:
  %t519 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t521 = extractvalue { i64, ptr } %t519, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  %t526 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t528 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t526, { i64, ptr } %t525)
  store %"compiler/msgs:Msg" %t528, ptr %l252
  br label %bb161
bb161:
  %t529 = load ptr, ptr %l242, !tbaa !29
  %t530 = load i64, ptr %l243, !tbaa !24
  %t531 = load %"compiler/msgs:Msg", ptr %l252
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s9, ptr %t529, i64 %t530, %"compiler/msgs:Msg" %t531)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb163:
  %t533 = load i32, ptr %l3
  %t535 = trunc i64 42 to i32
  %t536 = icmp eq i32 %t533, %t535
  br i1 %t536, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s10
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l256, !tbaa !29
  %t539 = load i64, ptr %l2, !tbaa !24
  store i64 %t539, ptr %l257, !tbaa !24
  %t540 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %s10)
  store %"compiler/msgs:Msg" %t540, ptr %l258
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t541 = load ptr, ptr %l256, !tbaa !29
  %t542 = load i64, ptr %l257, !tbaa !24
  %t543 = load %"compiler/msgs:Msg", ptr %l258
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s10, ptr %t541, i64 %t542, %"compiler/msgs:Msg" %t543)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb168:
  %t545 = load i32, ptr %l3
  %t547 = trunc i64 5 to i32
  %t548 = icmp eq i32 %t545, %t547
  br i1 %t548, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l262, !tbaa !21
  br label %bb171
bb170:
  %t550 = load i32, ptr %l3
  %t552 = trunc i64 85 to i32
  %t553 = icmp eq i32 %t550, %t552
  store i1 %t553, ptr %l262, !tbaa !21
  br label %bb171
bb171:
  %t555 = load i1, ptr %l262, !tbaa !21
  br i1 %t555, label %bb172, label %bb173
bb172:
  %t556 = load i64, ptr %l7, !tbaa !24
  %t557 = load i64, ptr %l4, !tbaa !24
  %t560 = icmp eq i64 %t556, %t557
  store i1 %t560, ptr %l265, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb174
bb174:
  %t562 = load i1, ptr %l265, !tbaa !21
  br i1 %t562, label %bb175, label %bb176
bb175:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i64, ptr %l5, !tbaa !24
  %t567 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t563, i64 %t564)
  store i1 %t567, ptr %l272
  br label %bb177
bb176:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb178
bb177:
  %t568 = load i1, ptr %l272, !tbaa !21
  store i1 %t568, ptr %l269, !tbaa !21
  br label %bb178
bb178:
  %t569 = load i1, ptr %l269, !tbaa !21
  br i1 %t569, label %bb179, label %bb180
bb179:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l274, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load i64, ptr %l5, !tbaa !24
  %t575 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %t571, i64 %t572)
  store i64 %t575, ptr %l277
  br label %bb181
bb180:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb183
bb181:
  %t576 = load i64, ptr %l5, !tbaa !24
  %t577 = load ptr, ptr %l274, !tbaa !29
  %t578 = load i64, ptr %l277, !tbaa !24
  %t580 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t577, i64 %t578, i64 %t576)
  store i1 %t580, ptr %l279
  br label %bb182
bb182:
  %t581 = load i1, ptr %l279, !tbaa !21
  store i1 %t581, ptr %l273, !tbaa !21
  br label %bb183
bb183:
  %t582 = load i1, ptr %l273, !tbaa !21
  br i1 %t582, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb185:
  br label %bb186
bb186:
  %t584 = load i32, ptr %l6
  %t586 = trunc i64 5 to i32
  %t587 = icmp eq i32 %t584, %t586
  br i1 %t587, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb190
bb188:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i64, ptr %l5, !tbaa !24
  %t593 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %t589, i64 %t590)
  store i1 %t593, ptr %l286
  br label %bb189
bb189:
  %t594 = load i1, ptr %l286, !tbaa !21
  store i1 %t594, ptr %l283, !tbaa !21
  br label %bb190
bb190:
  %t595 = load i1, ptr %l283, !tbaa !21
  br i1 %t595, label %bb191, label %bb192
bb191:
  %t596 = load i64, ptr %l7, !tbaa !24
  %t597 = load i64, ptr %l4, !tbaa !24
  %t600 = icmp eq i64 %t596, %t597
  store i1 %t600, ptr %l287, !tbaa !21
  br label %bb193
bb192:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb193
bb193:
  %t602 = load i1, ptr %l287, !tbaa !21
  br i1 %t602, label %bb194, label %bb195
bb194:
  %t603 = load i32, ptr %l3
  %t605 = call i1 @compiler_2fparse_2eisOperandEndTok(i32 %t603)
  store i1 %t605, ptr %l293
  br label %bb196
bb195:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb200
bb196:
  %t606 = load i1, ptr %l293, !tbaa !21
  br i1 %t606, label %bb197, label %bb198
bb197:
  store i1 true, ptr %l294, !tbaa !21
  br label %bb199
bb198:
  %t607 = load i32, ptr %l3
  %t609 = trunc i64 88 to i32
  %t610 = icmp eq i32 %t607, %t609
  store i1 %t610, ptr %l294, !tbaa !21
  br label %bb199
bb199:
  %t612 = load i1, ptr %l294, !tbaa !21
  store i1 %t612, ptr %l291, !tbaa !21
  br label %bb200
bb200:
  %t613 = load i1, ptr %l291, !tbaa !21
  br i1 %t613, label %bb201, label %bb202
bb201:
  %t614 = load i32, ptr %l3
  %t616 = trunc i64 89 to i32
  %t617 = icmp eq i32 %t614, %t616
  %t619 = xor i1 %t617, true
  store i1 %t619, ptr %l297, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb203
bb203:
  %t621 = load i1, ptr %l297, !tbaa !21
  br i1 %t621, label %bb204, label %bb205
bb204:
  %t622 = load i32, ptr %l3
  %t624 = trunc i64 91 to i32
  %t625 = icmp eq i32 %t622, %t624
  %t627 = xor i1 %t625, true
  store i1 %t627, ptr %l301, !tbaa !21
  br label %bb206
bb205:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb206
bb206:
  %t629 = load i1, ptr %l301, !tbaa !21
  br i1 %t629, label %bb207, label %bb208
bb207:
  %t630 = load i32, ptr %l6
  %t632 = trunc i64 5 to i32
  %t633 = icmp eq i32 %t630, %t632
  br i1 %t633, label %bb209, label %bb210
bb208:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb212
bb209:
  %t635 = load i32, ptr %l3
  %t637 = trunc i64 88 to i32
  %t638 = icmp eq i32 %t635, %t637
  store i1 %t638, ptr %l308, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l308, !tbaa !21
  br label %bb211
bb211:
  %t640 = load i1, ptr %l308, !tbaa !21
  %t641 = xor i1 %t640, true
  store i1 %t641, ptr %l305, !tbaa !21
  br label %bb212
bb212:
  %t643 = load i1, ptr %l305, !tbaa !21
  br i1 %t643, label %bb213, label %bb214
bb213:
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l313, !tbaa !29
  %t645 = load i64, ptr %l2, !tbaa !24
  store i64 %t645, ptr %l314, !tbaa !24
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load i64, ptr %l2, !tbaa !24
  %t650 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %t646, i64 %t647)
  store i64 %t650, ptr %l317
  br label %bb215
bb214:
  store i1 false, ptr %l312, !tbaa !21
  br label %bb217
bb215:
  %t651 = load ptr, ptr %l313, !tbaa !29
  %t652 = load i64, ptr %l314, !tbaa !24
  %t653 = load i64, ptr %l317, !tbaa !24
  %t654 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t651, i64 %t652, i64 %t653)
  store i1 %t654, ptr %l318
  br label %bb216
bb216:
  %t655 = load i1, ptr %l318, !tbaa !21
  store i1 %t655, ptr %l312, !tbaa !21
  br label %bb217
bb217:
  %t656 = load i1, ptr %l312, !tbaa !21
  br i1 %t656, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb219:
  br label %bb220
bb220:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load i64, ptr %l2, !tbaa !24
  %t662 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %t658, i64 %t659)
  store i1 %t662, ptr %l322
  br label %bb221
bb221:
  %t663 = load i1, ptr %l322, !tbaa !21
  br i1 %t663, label %bb222, label %bb223
bb222:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb223:
  br label %bb224
bb224:
  %t665 = load i32, ptr %l3
  %t667 = trunc i64 89 to i32
  %t668 = icmp eq i32 %t665, %t667
  br i1 %t668, label %bb225, label %bb226
bb225:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb227
bb226:
  %t670 = load i32, ptr %l3
  %t672 = trunc i64 91 to i32
  %t673 = icmp eq i32 %t670, %t672
  store i1 %t673, ptr %l326, !tbaa !21
  br label %bb227
bb227:
  %t675 = load i1, ptr %l326, !tbaa !21
  br i1 %t675, label %bb228, label %bb229
bb228:
  %t676 = load i32, ptr %l6
  %t678 = trunc i64 55 to i32
  %t679 = icmp eq i32 %t676, %t678
  store i1 %t679, ptr %l329, !tbaa !21
  br label %bb230
bb229:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb230
bb230:
  %t681 = load i1, ptr %l329, !tbaa !21
  br i1 %t681, label %bb231, label %bb232
bb231:
  %t682 = load i64, ptr %l7, !tbaa !24
  %t683 = load i64, ptr %l4, !tbaa !24
  %t686 = icmp eq i64 %t682, %t683
  store i1 %t686, ptr %l332, !tbaa !21
  br label %bb233
bb232:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb233
bb233:
  %t688 = load i1, ptr %l332, !tbaa !21
  br i1 %t688, label %bb234, label %bb235
bb234:
  store %olang.scope zeroinitializer, ptr %s14
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l336, !tbaa !29
  %t690 = load i64, ptr %l5, !tbaa !24
  store i64 %t690, ptr %l337, !tbaa !24
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load i64, ptr %l2, !tbaa !24
  %t695 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s14, ptr %t691, i64 %t692)
  store { i64, ptr } %t695, ptr %l340
  br label %bb236
bb235:
  br label %bb239
bb236:
  %t696 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t704 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s14, ptr %s14, { i64, ptr } %t702)
  store %"compiler/msgs:Msg" %t704, ptr %l342
  br label %bb237
bb237:
  %t705 = load ptr, ptr %l336, !tbaa !29
  %t706 = load i64, ptr %l337, !tbaa !24
  %t707 = load %"compiler/msgs:Msg", ptr %l342
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s14, ptr %t705, i64 %t706, %"compiler/msgs:Msg" %t707)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb239:
  %t709 = load i32, ptr %l3
  %t711 = trunc i64 38 to i32
  %t712 = icmp eq i32 %t709, %t711
  br i1 %t712, label %bb240, label %bb241
bb240:
  %t714 = load i32, ptr %l6
  %t716 = trunc i64 57 to i32
  %t717 = icmp eq i32 %t714, %t716
  store i1 %t717, ptr %l346, !tbaa !21
  br label %bb242
bb241:
  store i1 false, ptr %l346, !tbaa !21
  br label %bb242
bb242:
  %t719 = load i1, ptr %l346, !tbaa !21
  br i1 %t719, label %bb243, label %bb244
bb243:
  store %olang.scope zeroinitializer, ptr %s15
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l349, !tbaa !29
  %t721 = load i64, ptr %l2, !tbaa !24
  store i64 %t721, ptr %l350, !tbaa !24
  %t722 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %s15)
  store %"compiler/msgs:Msg" %t722, ptr %l351
  br label %bb245
bb244:
  br label %bb247
bb245:
  %t723 = load ptr, ptr %l349, !tbaa !29
  %t724 = load i64, ptr %l350, !tbaa !24
  %t725 = load %"compiler/msgs:Msg", ptr %l351
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s15, ptr %t723, i64 %t724, %"compiler/msgs:Msg" %t725)
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb247:
  %t727 = load i32, ptr %l3
  %t729 = trunc i64 88 to i32
  %t730 = icmp eq i32 %t727, %t729
  br i1 %t730, label %bb248, label %bb249
bb248:
  %t732 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t732, ptr %l356, !tbaa !27
  %t734 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t734, ptr %l358
  br label %bb250
bb249:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb252
bb250:
  %t735 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 0
  %t737 = extractvalue { i64, ptr } %t735, 1
  %t738 = mul i64 %t736, 1
  %t739 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t738)
  call void @llvm.memcpy.p0.p0.i64(ptr %t739, ptr %t737, i64 %t738, i1 false)
  %t740 = insertvalue { i64, ptr } undef, i64 %t736, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t739, 1
  %t742 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t744 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t742, { i64, ptr } %t741)
  store i1 %t744, ptr %l360
  br label %bb251
bb251:
  %t745 = load i1, ptr %l360, !tbaa !21
  store i1 %t745, ptr %l355, !tbaa !21
  br label %bb252
bb252:
  %t746 = load i1, ptr %l355, !tbaa !21
  br i1 %t746, label %bb253, label %bb254
bb253:
  %t747 = load i32, ptr %l6
  %t749 = trunc i64 79 to i32
  %t750 = icmp eq i32 %t747, %t749
  br i1 %t750, label %bb255, label %bb256
bb254:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb261
bb255:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb257
bb256:
  %t752 = load i32, ptr %l6
  %t754 = trunc i64 87 to i32
  %t755 = icmp eq i32 %t752, %t754
  store i1 %t755, ptr %l364, !tbaa !21
  br label %bb257
bb257:
  %t757 = load i1, ptr %l364, !tbaa !21
  br i1 %t757, label %bb258, label %bb259
bb258:
  store i1 true, ptr %l367, !tbaa !21
  br label %bb260
bb259:
  %t758 = load i32, ptr %l6
  %t760 = trunc i64 1 to i32
  %t761 = icmp eq i32 %t758, %t760
  store i1 %t761, ptr %l367, !tbaa !21
  br label %bb260
bb260:
  %t763 = load i1, ptr %l367, !tbaa !21
  store i1 %t763, ptr %l361, !tbaa !21
  br label %bb261
bb261:
  %t764 = load i1, ptr %l361, !tbaa !21
  br i1 %t764, label %bb262, label %bb263
bb262:
  %t765 = load i64, ptr %l7, !tbaa !24
  %t766 = load i64, ptr %l4, !tbaa !24
  %t769 = icmp eq i64 %t765, %t766
  store i1 %t769, ptr %l370, !tbaa !21
  br label %bb264
bb263:
  store i1 false, ptr %l370, !tbaa !21
  br label %bb264
bb264:
  %t771 = load i1, ptr %l370, !tbaa !21
  br i1 %t771, label %bb265, label %bb266
bb265:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load i64, ptr %l2, !tbaa !24
  %t776 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %t772, i64 %t773)
  store i1 %t776, ptr %l376
  br label %bb267
bb266:
  br label %bb268
bb267:
  call void @__olang_scope_close(ptr %s0)
  %t777 = load i1, ptr %l376, !tbaa !21
  store i1 %t777, ptr %rv
  br label %ret
bb268:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:If"
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/ast:If"
  %rv = alloca { i32, ptr }
  %t123 = alloca { i64, [5 x i64] }, align 8
  %t160 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l7, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28
ok.28:
  store ptr %t25, ptr %l15
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l15, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  br label %bb6
bb5:
  %t30 = load i32, ptr %l16, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = load ptr, ptr %l13, !tbaa !29
  store ptr %t41, ptr %l2, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %t42)
  %t45 = extractvalue { i32, ptr } %t44, 1
  %t46 = extractvalue { i32, ptr } %t44, 0
  store i32 %t46, ptr %l21
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48
ok.48:
  store ptr %t45, ptr %l20
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l20, !tbaa !29
  store ptr %t49, ptr %l18, !tbaa !29
  br label %bb9
bb8:
  %t50 = load i32, ptr %l21, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  %t60 = insertvalue { i32, ptr } zeroinitializer, i32 %t58, 0
  store { i32, ptr } %t60, ptr %rv
  br label %ret
bb9:
  %t61 = load ptr, ptr %l18, !tbaa !29
  store ptr %t61, ptr %l3, !tbaa !29
  store ptr null, ptr %l4, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t62, i32 10)
  store i1 %t65, ptr %l25
  br label %bb10
bb10:
  %t66 = load i1, ptr %l25, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 9)
  store i1 %t70, ptr %l28
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t71 = load i1, ptr %l28, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %t72)
  %t75 = extractvalue { i32, ptr } %t74, 1
  %t76 = extractvalue { i32, ptr } %t74, 0
  store i32 %t76, ptr %l32
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb17, label %ok.78
ok.78:
  store ptr %t75, ptr %l31
  br label %bb16
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %t79)
  %t82 = extractvalue { i32, ptr } %t81, 1
  %t83 = extractvalue { i32, ptr } %t81, 0
  store i32 %t83, ptr %l38
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb20, label %ok.85
ok.85:
  store ptr %t82, ptr %l37
  br label %bb19
bb16:
  %t86 = load ptr, ptr %l31, !tbaa !29
  store ptr %t86, ptr %l29, !tbaa !29
  br label %bb18
bb17:
  %t87 = load i32, ptr %l32, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  %t97 = insertvalue { i32, ptr } zeroinitializer, i32 %t95, 0
  store { i32, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t98 = load ptr, ptr %l29, !tbaa !29
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb23
bb19:
  %t100 = load ptr, ptr %l37, !tbaa !29
  store ptr %t100, ptr %l35, !tbaa !29
  br label %bb21
bb20:
  %t101 = load i32, ptr %l38, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  %t111 = insertvalue { i32, ptr } zeroinitializer, i32 %t109, 0
  store { i32, ptr } %t111, ptr %rv
  br label %ret
bb21:
  %t112 = load ptr, ptr %l35, !tbaa !29
  store ptr %t112, ptr %l5, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Branch", ptr %t113, i32 0, i32 0
  %t116 = load %"compiler/source:Span", ptr %t115
  store %"compiler/source:Span" %t116, ptr %l41
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t120 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr null, ptr %t117, ptr null)
  store %"compiler/ast:If" %t120, ptr %l44
  br label %bb22
bb22:
  %t121 = load %"compiler/ast:If", ptr %l44
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t121, ptr %t122
  store { i64, [5 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 0
  store i64 5, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l41
  %t126 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t125, 0
  %t128 = insertvalue { %"compiler/source:Span", ptr } %t126, ptr %t122, 1
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t128, ptr %t129
  %t130 = load { i64, [5 x i64] }, ptr %t123
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t130, ptr %t132
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t134, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l50
  br label %bb25
bb25:
  %t139 = load %"compiler/source:Span", ptr %l50
  store %"compiler/source:Span" %t139, ptr %l6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t143 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t140, i32 8)
  store i1 %t143, ptr %l53
  br label %bb26
bb26:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t145)
  store i32 %t147, ptr %l55
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t148 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t148, ptr %l56
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t157 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t149, ptr %t151, ptr %t153)
  store %"compiler/ast:If" %t157, ptr %l62
  br label %bb31
bb31:
  %t158 = load %"compiler/ast:If", ptr %l62
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t158, ptr %t159
  store { i64, [5 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 0
  store i64 5, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l56
  %t163 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t162, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t163, ptr %t159, 1
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [5 x i64] }, ptr %t160
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t167, ptr %t169
  %t171 = insertvalue { i32, ptr } zeroinitializer, ptr %t169, 1
  store { i32, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/token:Token"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca %"compiler/token:Token"
  %l53 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Oracle", ptr %t8, i32 0, i32 0
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t16)
  store %"compiler/token:Token" %t18, ptr %l18
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = load %"compiler/token:Token", ptr %l18
  %t21 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t19, %"compiler/token:Token" %t20)
  store { i64, ptr } %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t24 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l20
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l21, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb7:
  %t29 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t29, ptr %l22
  br label %bb8
bb8:
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t30, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store ptr %l2, ptr %l48, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t84 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t80, i64 %t77)
  store %"compiler/token:Token" %t84, ptr %l52
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l49, !tbaa !29
  %t86 = load %"compiler/token:Token", ptr %l52
  %t87 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t85, %"compiler/token:Token" %t86)
  store { i64, ptr } %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t88, { i64, ptr } %t89)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb15
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Oracle", ptr %t97, i32 0, i32 1
  store ptr %t99, ptr %l58, !tbaa !29
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l58, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t104 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } %t103)
  store i1 %t104, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i1, ptr %l61, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i32
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l53 = alloca { i64, ptr }
  %l74 = alloca i32
  %l82 = alloca i32
  %l84 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 24
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 23
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t19 = load i32, ptr %l18, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t18, i32 %t19)
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t22, i1 true)
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %t26, i64 0)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 12
  store i1 false, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 15
  store i64 0, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 16
  store i1 false, ptr %t36, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 18
  store i64 0, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 19
  store i1 false, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 21
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eTrunc_H4f6d6844736ef1cf1f5d4d22c2fa42e3(ptr %v0, ptr %t48, i64 0)
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %t50)
  %t53 = extractvalue { i32, ptr } %t52, 1
  %t54 = extractvalue { i32, ptr } %t52, 0
  store i32 %t54, ptr %l34
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb8, label %ok.56
ok.56:
  store ptr %t53, ptr %l33
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l33, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  br label %bb40
bb8:
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 24
  %t61 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t60, i64 %t61, i1 false)
  br label %bb10
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 35
  store ptr %t66, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eRunFrom_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t68, i64 %t69)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb13, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l43
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t77, ptr %l40, !tbaa !27
  br label %bb17
bb13:
  %t78 = load i32, ptr %l44, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b436918af3dd5ca0_a9a6bacafc138244)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb17:
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t83, ptr %l5, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %l53, !tbaa !27
  %t97 = load i64, ptr %l7, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t106, ptr %t102)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t114, %t115
  store i64 %t118, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb11
bb26:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eTrunc_H4f6d6844736ef1cf1f5d4d22c2fa42e3(ptr %v0, ptr %t122, i64 0)
  br label %bb27
bb27:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 21
  %t127 = load i1, ptr %t126, !tbaa !21
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/parse:Parser", ptr %t129, i32 0, i32 21
  store i1 false, ptr %t131, !tbaa !21
  br label %ret
bb29:
  br label %bb30
bb30:
  %t132 = load i64, ptr %l1, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 6
  %t136 = load i64, ptr %t135, !tbaa !24
  %t139 = icmp eq i64 %t132, %t136
  br i1 %t139, label %bb31, label %bb32
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t141)
  store i32 %t143, ptr %l74
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %t144, i64 %t145)
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 6
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l1, !tbaa !24
  %t155 = icmp eq i64 %t151, %t152
  br i1 %t155, label %bb36, label %bb37
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t157)
  store i32 %t159, ptr %l82
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %ret
bb40:
  %t160 = load ptr, ptr %l31, !tbaa !29
  store ptr %t160, ptr %l9, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t161, i32 0, i32 34
  store ptr %t163, ptr %l84, !tbaa !29
  %t164 = load ptr, ptr %l9, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  br i1 %t166, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e7733d3a928e8482_4650af2d2e5452b6)
  unreachable
bb42:
  br label %bb43
bb43:
  %t168 = load ptr, ptr %l9, !tbaa !29
  %t169 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t169, ptr %t168)
  br label %bb44
bb44:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/msgs:Msg"
  %l55 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l13
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp ne i64 %t20, %t21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/scan:Tokens", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t33
  %t38 = load %"compiler/token:Token", ptr %t37
  store %"compiler/token:Token" %t38, ptr %l3
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/token:Token", ptr %t50, i64 %t47
  %t52 = load %"compiler/token:Token", ptr %t51
  store %"compiler/token:Token" %t52, ptr %l4
  %t54 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = icmp sgt i32 %t55, %t57
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = sub i32 %t63, %t65
  %t70 = icmp sle i32 %t68, 60
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t72 = load i1, ptr %l32, !tbaa !21
  br i1 %t72, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  store i64 %t74, ptr %l38, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/source:Source", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store i64 %t85, ptr %l43, !tbaa !24
  %t86 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  store i64 %t89, ptr %l45, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l46, !tbaa !24
  %t92 = load i64, ptr %l43, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb17, label %bb18
bb16:
  %t95 = load i64, ptr %l1, !tbaa !24
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb25, label %bb26
bb17:
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb19:
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb21:
  %t109 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l43, !tbaa !24
  %t112 = load i64, ptr %l45, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s2, { i64, ptr } %t116)
  store %"compiler/msgs:Msg" %t118, ptr %l51
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb23:
  %t119 = load ptr, ptr %l37, !tbaa !29
  %t120 = load i64, ptr %l38, !tbaa !24
  %t121 = load %"compiler/msgs:Msg", ptr %l51
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t119, i64 %t120, %"compiler/msgs:Msg" %t121)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l55, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  store i64 %t123, ptr %l56, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/token:Token", ptr %l3
  %t128 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t124, %"compiler/token:Token" %t125)
  store { i64, ptr } %t128, ptr %l59
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l61, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l62, !tbaa !24
  %t131 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr @.d3 })
  store %"compiler/msgs:Msg" %t131, ptr %l63
  br label %bb30
bb27:
  %t132 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s4, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t133, ptr %l60
  br label %bb28
bb28:
  %t134 = load ptr, ptr %l55, !tbaa !29
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t134, i64 %t135, %"compiler/msgs:Msg" %t136)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb30:
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = load %"compiler/msgs:Msg", ptr %l63
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t137, i64 %t138, %"compiler/msgs:Msg" %t139)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  br label %bb33
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load %"compiler/token:Token", ptr %l1
  %t6 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t9 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t5, i8 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l2
  %t15 = load i32, ptr %l2
  %t17 = trunc i64 8 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 58 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr %l2
  %t32 = trunc i64 56 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 88 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load i32, ptr %l2
  %t48 = trunc i64 55 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l25, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load i32, ptr %l2
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l29, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = load i32, ptr %l2
  %t64 = trunc i64 93 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l31 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t5)
  store i1 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i1, ptr %l9, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %t11)
  store i1 %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t19, i64 1)
  store i32 %t21, ptr %l17
  br label %bb10
bb10:
  %t22 = load i32, ptr %l17
  store i32 %t22, ptr %l2
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 5 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 37 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t35 = load i32, ptr %l1
  %t37 = trunc i64 33 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t43, i64 %t47)
  store i64 %t50, ptr %l31
  br label %bb20
bb20:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 6
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/scan:Tokens", ptr %t63, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp slt i64 %t59, %t68
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l44, !tbaa !24
  %t81 = icmp eq i64 %t79, %t78
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l41, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l50
  br label %bb29
bb29:
  %t91 = load i32, ptr %l50
  store i32 %t91, ptr %l5
  %t92 = load i32, ptr %l5
  %t94 = trunc i64 34 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb31:
  %t97 = load i32, ptr %l5
  %t99 = trunc i64 35 to i32
  %t100 = icmp eq i32 %t97, %t99
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb35
bb34:
  %t103 = load i32, ptr %l5
  %t105 = trunc i64 36 to i32
  %t106 = icmp eq i32 %t103, %t105
  store i1 %t106, ptr %l56, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb38
bb37:
  %t109 = load i32, ptr %l5
  %t111 = trunc i64 21 to i32
  %t112 = icmp eq i32 %t109, %t111
  store i1 %t112, ptr %l59, !tbaa !21
  br label %bb38
bb38:
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb40:
  %t115 = load i32, ptr %l5
  %t117 = trunc i64 92 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb45:
  br label %bb21
bb46:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l14 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t2, i32 0, i32 18
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 18
  store i64 %t6, ptr %t9, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t24, i32 %t38)
  store i32 %t41, ptr %l19
  br label %bb7
bb7:
  %t42 = load i32, ptr %l19, !tbaa !23
  %t43 = sext i32 %t42 to i64
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t259 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i1, ptr %l23, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t7, i64 2)
  store i32 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i32, ptr %l27
  %t12 = trunc i64 90 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l25, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t18, i32 81)
  store i1 %t21, ptr %l33
  br label %bb8
bb7:
  br label %bb31
bb8:
  %t22 = load i1, ptr %l33, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 90)
  store i1 %t28, ptr %l38
  br label %bb11
bb10:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t29 = load i1, ptr %l38, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t33, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t36, i32 81)
  store i1 %t39, ptr %l43
  br label %bb16
bb16:
  %t40 = load i1, ptr %l43, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t41, i64 1)
  store i32 %t43, ptr %l45
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t44 = load i32, ptr %l45
  store i32 %t44, ptr %l3
  %t45 = load i32, ptr %l3
  %t47 = trunc i64 90 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = load i32, ptr %l3
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t57, i64 2)
  store i32 %t59, ptr %l54
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb25
bb24:
  %t60 = load i32, ptr %l54
  %t62 = trunc i64 90 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l52, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l49, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t69, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t73 = load ptr, ptr %l59, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load ptr, ptr %l59, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 14
  store i1 %t79, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t80 = load i1, ptr %l60, !tbaa !21
  br i1 %t80, label %bb34, label %bb35
bb34:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l4
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t95, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  br label %bb36
bb35:
  br label %bb77
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t99, i32 0, i32 32
  %t103 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l71
  br label %bb37
bb37:
  %t104 = load i64, ptr %l71, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l5, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t108 = load ptr, ptr %l73, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb39, label %bb40
bb39:
  %t111 = load ptr, ptr %l73, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t115 = load i1, ptr %l74, !tbaa !21
  br i1 %t115, label %bb41, label %bb42
bb41:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32 }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 32
  %t125 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t124, i32 %t125)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb45:
  %t128 = load ptr, ptr %l8, !tbaa !29
  store ptr %t128, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t129 = load ptr, ptr %l82, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb46, label %bb47
bb46:
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i64, ptr %t132
  %t135 = icmp eq i64 %t133, 15
  store i1 %t135, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t136 = load i1, ptr %l83, !tbaa !21
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t137 = load ptr, ptr %l8, !tbaa !29
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t139, i32 0, i32 1
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l10, !tbaa !29
  %t143 = load ptr, ptr %l8, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l11, !tbaa !23
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 32
  %t152 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t151, i32 %t152)
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l10, !tbaa !29
  store ptr %t155, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb53:
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  br label %bb38
bb55:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 32
  %t160 = load i64, ptr %l7, !tbaa !24
  %t163 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t159, i64 %t160)
  store { i64, ptr } %t163, ptr %l97
  br label %bb56
bb56:
  %t164 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l99, !tbaa !24
  %t168 = load i64, ptr %l99, !tbaa !24
  %t169 = icmp sge i64 %t168, 0
  br i1 %t169, label %bb57, label %bb58
bb57:
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = icmp sle i64 %t171, 2305843009213693951
  br i1 %t172, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_2d89971a269bae53_cb14c861cebe6e1f)
  unreachable
bb59:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = mul i64 %t174, 4
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l15, !tbaa !24
  %t185 = load i64, ptr %l14, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2d89971a269bae53_cb14c861cebe6e1f)
  unreachable
bb61:
  %t190 = load i64, ptr %l16, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb66
bb63:
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l111, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb65
bb65:
  %t210 = load i64, ptr %l111, !tbaa !24
  store i64 %t210, ptr %l108, !tbaa !24
  br label %bb66
bb66:
  %t211 = load i64, ptr %l108, !tbaa !24
  store i64 %t211, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t212 = load i64, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l17, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb69:
  br label %bb70
bb70:
  %t220 = load i64, ptr %l14, !tbaa !24
  %t221 = load i64, ptr %l18, !tbaa !24
  %t222 = load i64, ptr %l16, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l19, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t230, ptr %l129, !tbaa !27
  %t231 = load i64, ptr %l19, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t232, ptr %l131, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t237 = sub i64 %t235, 1
  %t238 = load i64, ptr %l19, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t243 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  %t249 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t231
  store i32 %t246, ptr %t251, !tbaa !33
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb71:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l18, !tbaa !24
  br label %bb67
bb72:
  %t256 = load %"compiler/source:Span", ptr %l4
  %t257 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t262 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t256, 0
  %t264 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t262, { i64, ptr } %t257, 1
  %t266 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t264, { i64, ptr } %t258, 2
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t266, ptr %t267
  %t268 = load { i64, [5 x i64] }, ptr %t259
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t268, ptr %t270
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l1, !tbaa !23
  %t278 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t272, i32 %t273, ptr %t270)
  store ptr %t278, ptr %l148
  br label %bb73
bb73:
  %t279 = load ptr, ptr %l148, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l1, !tbaa !23
  %t286 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t280, i32 %t281, ptr %t279)
  %t287 = extractvalue { i32, ptr } %t286, 1
  %t288 = extractvalue { i32, ptr } %t286, 0
  store i32 %t288, ptr %l154
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb75, label %ok.290
ok.290:
  store ptr %t287, ptr %l153
  br label %bb74
bb74:
  %t291 = load ptr, ptr %l153, !tbaa !29
  store ptr %t291, ptr %l149, !tbaa !29
  br label %bb76
bb75:
  %t292 = load i32, ptr %l154, !tbaa !23
  %t293 = lshr i32 %t292, 16
  %t294 = and i32 %t292, 65535
  %t295 = icmp eq i32 %t293, 1
  %t296 = select i1 %t295, i32 1, i32 0
  %t297 = icmp eq i32 %t292, 0
  %t298 = shl i32 %t296, 16
  %t299 = or i32 %t298, %t294
  %t300 = select i1 %t297, i32 0, i32 %t299
  %t302 = insertvalue { i32, ptr } zeroinitializer, i32 %t300, 0
  store { i32, ptr } %t302, ptr %rv
  br label %ret
bb76:
  %t303 = load ptr, ptr %l149, !tbaa !29
  %t304 = insertvalue { i32, ptr } zeroinitializer, ptr %t303, 1
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb77:
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = insertvalue { i32, ptr } zeroinitializer, ptr %t305, 1
  store { i32, ptr } %t307, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp sge i64 %t7, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/scan:Tokens", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 %t13, %t14
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t16, i64 %t15)
  store i64 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp sge i64 %t20, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/scan:Tokens", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/scan:Tokens", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = sub i64 %t49, 1
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t51
  %t56 = load %"compiler/token:Token", ptr %t55
  store %"compiler/token:Token" %t56, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/scan:Tokens", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i64 %t65
  %t70 = load %"compiler/token:Token", ptr %t69
  store %"compiler/token:Token" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/token:Token"
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l40 = alloca %"compiler/token:Token"
  %l42 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l51 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t87 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t11, i32 81)
  store i1 %t14, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb4:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l18
  br label %bb7
bb7:
  %t19 = load i1, ptr %l18, !tbaa !21
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l12, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb36
bb11:
  br label %bb12
bb12:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t24, i32 57)
  store i1 %t27, ptr %l22
  br label %bb13
bb13:
  %t28 = load i1, ptr %l22, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  %t29 = load i1, ptr %l4, !tbaa !21
  br i1 %t29, label %bb14, label %bb15
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l25
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l27
  br label %bb18
bb18:
  store i32 0, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t37)
  store i32 %t39, ptr %l29
  br label %bb19
bb19:
  %t40 = load i32, ptr %l29
  store i32 %t40, ptr %l6
  %t41 = load i32, ptr %l6
  %t43 = trunc i64 1 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb22
bb21:
  %t46 = load i32, ptr %l6
  %t48 = trunc i64 14 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb23, label %bb24
bb23:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l37
  br label %bb25
bb24:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb26
bb25:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb26
bb26:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb27, label %bb28
bb27:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t59)
  store %"compiler/token:Token" %t61, ptr %l40
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t62 = load %"compiler/token:Token", ptr %l40
  store %"compiler/token:Token" %t62, ptr %l7
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t63)
  store i32 %t65, ptr %l42
  br label %bb30
bb30:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/parse:Parser", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/token:Token", ptr %l7
  %t74 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t70, %"compiler/token:Token" %t71)
  store { i64, ptr } %t74, ptr %l47
  br label %bb31
bb31:
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t75, { i64, ptr } %t76)
  store i32 %t77, ptr %l48
  br label %bb32
bb32:
  %t78 = load i32, ptr %l48, !tbaa !23
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb33
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t79, i32 %a1)
  store %"compiler/source:Span" %t83, ptr %l51
  br label %bb34
bb34:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i1, ptr %l4, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 0
  store i64 3, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l51
  %t90 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } undef, %"compiler/source:Span" %t89, 0
  %t92 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t90, ptr %t84, 1
  %t94 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t92, i32 %t85, 2
  %t96 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t94, i1 %t86, 3
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, i1 } %t96, ptr %t97
  %t98 = load { i64, [5 x i64] }, ptr %t87
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t98, ptr %t100
  store ptr %t100, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb35
bb35:
  br label %bb1
bb36:
  %t102 = load ptr, ptr %l3, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { { i64, ptr }, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { { i64, ptr }, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l47 = alloca %"compiler/token:Token"
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l66 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i32
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i32
  %l108 = alloca i1
  %l109 = alloca { { i64, ptr }, ptr }
  %l111 = alloca { { i64, ptr }, ptr }
  %l112 = alloca i32
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l127 = alloca %"compiler/ast:Case"
  %l131 = alloca i1
  %l133 = alloca i32
  %l134 = alloca i32
  %l137 = alloca i32
  %l138 = alloca i32
  %l142 = alloca i64
  %l145 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca i32
  %l154 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca i32
  %l160 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca i1
  %l169 = alloca i1
  %l172 = alloca i32
  %l175 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i1
  %l184 = alloca i1
  %l187 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i32
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca i1
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca i32
  %l212 = alloca { { i64, ptr }, ptr }
  %l214 = alloca { { i64, ptr }, ptr }
  %l215 = alloca i32
  %l219 = alloca ptr
  %l222 = alloca %"compiler/source:Span"
  %l228 = alloca %"compiler/ast:Case"
  %l232 = alloca i1
  %l234 = alloca i32
  %l235 = alloca i32
  %l238 = alloca i32
  %l239 = alloca i32
  %l247 = alloca %"compiler/source:Span"
  %l248 = alloca ptr
  %l249 = alloca i1
  %l251 = alloca { i64, ptr }
  %l253 = alloca %"compiler/ast:Match"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 30)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l33
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l32
  br label %bb1
bb1:
  %t9 = load i32, ptr %l32, !tbaa !23
  store i32 %t9, ptr %l29, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l33, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l29, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  store i1 false, ptr %l2, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 1)
  store i1 %t25, ptr %l37
  br label %bb4
bb4:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l40
  br label %bb7
bb6:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i32, ptr %l40
  %t32 = trunc i64 92 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l38, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l38, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l44, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l45, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t41)
  store %"compiler/token:Token" %t43, ptr %l47
  br label %bb11
bb10:
  br label %bb32
bb11:
  %t44 = load ptr, ptr %l45, !tbaa !29
  %t45 = load %"compiler/token:Token", ptr %l47
  %t46 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t44, %"compiler/token:Token" %t45)
  store { i64, ptr } %t46, ptr %l48
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l44, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l49
  br label %bb13
bb13:
  %t50 = load i32, ptr %l49, !tbaa !23
  store i32 %t50, ptr %l3, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 26
  store ptr %t53, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %t55, i64 %t56)
  %t60 = extractvalue { i32, { i64, ptr } } %t59, 1
  %t61 = extractvalue { i32, { i64, ptr } } %t59, 0
  store i32 %t61, ptr %l56
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb16, label %ok.63
ok.63:
  store { i64, ptr } %t60, ptr %l55
  br label %bb15
bb15:
  %t64 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t64, ptr %l52, !tbaa !27
  br label %bb20
bb16:
  %t65 = load i32, ptr %l56, !tbaa !23
  %t66 = ashr i32 %t65, 16
  %t68 = icmp eq i32 %t66, 1
  br i1 %t68, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  %t70 = load i32, ptr %l56, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 0, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s3)
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 %t78, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb20:
  %t81 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t94, ptr %l66, !tbaa !27
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = icmp eq i32 %t100, %t103
  br i1 %t106, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l8, !tbaa !24
  br label %bb21
bb29:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t112, %t113
  store i64 %t116, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  br label %bb14
bb31:
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t118)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l80
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb34, label %ok.124
ok.124:
  store ptr %t121, ptr %l79
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l79, !tbaa !29
  store ptr %t125, ptr %l77, !tbaa !29
  br label %bb35
bb34:
  %t126 = load i32, ptr %l80, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb35:
  %t137 = load ptr, ptr %l77, !tbaa !29
  store ptr %t137, ptr %l10, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t141 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t138, i32 92)
  %t142 = extractvalue { i32, i32 } %t141, 1
  %t143 = extractvalue { i32, i32 } %t141, 0
  store i32 %t143, ptr %l86
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb37, label %ok.145
ok.145:
  store i32 %t142, ptr %l85
  br label %bb36
bb36:
  %t146 = load i32, ptr %l85, !tbaa !23
  store i32 %t146, ptr %l82, !tbaa !23
  br label %bb38
bb37:
  %t147 = load i32, ptr %l86, !tbaa !23
  %t148 = lshr i32 %t147, 16
  %t149 = and i32 %t147, 65535
  %t150 = icmp eq i32 %t148, 1
  %t151 = select i1 %t150, i32 1, i32 0
  %t152 = icmp eq i32 %t147, 0
  %t153 = shl i32 %t151, 16
  %t154 = or i32 %t153, %t149
  %t155 = select i1 %t152, i32 0, i32 %t154
  %t157 = insertvalue { i32, ptr } zeroinitializer, i32 %t155, 0
  store { i32, ptr } %t157, ptr %rv
  br label %ret
bb38:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/parse:Parser", ptr %t158, i32 0, i32 15
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l11, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 15
  store i64 0, ptr %t165, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/parse:Parser", ptr %t166, i32 0, i32 16
  %t169 = load i1, ptr %t168, !tbaa !21
  store i1 %t169, ptr %l12, !tbaa !21
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 16
  store i1 false, ptr %t173, !tbaa !21
  %t174 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %l94
  br label %bb39
bb39:
  %t175 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t175, ptr %t176
  store ptr %t176, ptr %l13, !tbaa !29
  store ptr null, ptr %l14, !tbaa !29
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t178 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t178)
  br label %bb41
bb41:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t180, i32 93)
  store i1 %t183, ptr %l99
  br label %bb42
bb42:
  %t184 = load i1, ptr %l99, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb46
bb44:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t188 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t185, i32 0)
  store i1 %t188, ptr %l103
  br label %bb45
bb45:
  %t189 = load i1, ptr %l103, !tbaa !21
  store i1 %t189, ptr %l100, !tbaa !21
  br label %bb46
bb46:
  %t190 = load i1, ptr %l100, !tbaa !21
  br i1 %t190, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb145
bb48:
  br label %bb49
bb49:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t191)
  store i32 %t193, ptr %l105
  br label %bb50
bb50:
  %t194 = load i32, ptr %l105, !tbaa !23
  store i32 %t194, ptr %l15, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t198 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t195, i32 32)
  store i1 %t198, ptr %l108
  br label %bb51
bb51:
  %t199 = load i1, ptr %l108, !tbaa !21
  br i1 %t199, label %bb52, label %bb53
bb52:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %t200)
  %t203 = extractvalue { i32, { { i64, ptr }, ptr } } %t202, 1
  %t204 = extractvalue { i32, { { i64, ptr }, ptr } } %t202, 0
  store i32 %t204, ptr %l112
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb55, label %ok.206
ok.206:
  store { { i64, ptr }, ptr } %t203, ptr %l111
  br label %bb54
bb53:
  br label %bb72
bb54:
  %t207 = load { { i64, ptr }, ptr }, ptr %l111
  store { { i64, ptr }, ptr } %t207, ptr %l109
  br label %bb56
bb55:
  %t208 = load i32, ptr %l112, !tbaa !23
  %t209 = lshr i32 %t208, 16
  %t210 = and i32 %t208, 65535
  %t211 = icmp eq i32 %t209, 1
  %t212 = select i1 %t211, i32 1, i32 0
  %t213 = icmp eq i32 %t208, 0
  %t214 = shl i32 %t212, 16
  %t215 = or i32 %t214, %t210
  %t216 = select i1 %t213, i32 0, i32 %t215
  call void @__olang_scope_close(ptr %s7)
  %t218 = insertvalue { i32, ptr } zeroinitializer, i32 %t216, 0
  store { i32, ptr } %t218, ptr %rv
  br label %ret
bb56:
  %t219 = load { { i64, ptr }, ptr }, ptr %l109
  store { { i64, ptr }, ptr } %t219, ptr %l16
  %t220 = getelementptr { { i64, ptr }, ptr }, ptr %l16, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l17, !tbaa !27
  %t223 = getelementptr { { i64, ptr }, ptr }, ptr %l16, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  store ptr %t224, ptr %l18, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l15, !tbaa !23
  %t230 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t226, i32 %t227)
  store %"compiler/source:Span" %t230, ptr %l118
  br label %bb57
bb57:
  %t231 = icmp sge i64 0, 0
  br i1 %t231, label %bb58, label %bb59
bb58:
  %t233 = icmp sle i64 0, 1152921504606846975
  br i1 %t233, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb60:
  %t235 = mul i64 0, 8
  %t236 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t235)
  %t237 = insertvalue { i64, ptr } undef, i64 0, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  store { i64, ptr } %t238, ptr %l121, !tbaa !27
  %t239 = icmp sge i64 0, 0
  br i1 %t239, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb62:
  %t241 = icmp sle i64 0, 1152921504606846975
  br i1 %t241, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb64:
  %t243 = mul i64 0, 8
  %t244 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 0, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t248 = load ptr, ptr %l18, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l118
  %t250 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t254 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t249, { i64, ptr } %t250, { i64, ptr } %t246, ptr null, { i64, ptr } %t247, ptr %t248)
  store %"compiler/ast:Case" %t254, ptr %l127
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb66:
  %t255 = load %"compiler/ast:Case", ptr %l127
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Case" %t255, ptr %t256
  store ptr %t256, ptr %l14, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t258, i32 8)
  store i1 %t261, ptr %l131
  br label %bb67
bb67:
  %t262 = load i1, ptr %l131, !tbaa !21
  br i1 %t262, label %bb68, label %bb69
bb68:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l133
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb144
bb72:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t269 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t266, i32 31)
  %t270 = extractvalue { i32, i32 } %t269, 1
  %t271 = extractvalue { i32, i32 } %t269, 0
  store i32 %t271, ptr %l138
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb74, label %ok.273
ok.273:
  store i32 %t270, ptr %l137
  br label %bb73
bb73:
  %t274 = load i32, ptr %l137, !tbaa !23
  store i32 %t274, ptr %l134, !tbaa !23
  br label %bb75
bb74:
  %t275 = load i32, ptr %l138, !tbaa !23
  %t276 = lshr i32 %t275, 16
  %t277 = and i32 %t275, 65535
  %t278 = icmp eq i32 %t276, 1
  %t279 = select i1 %t278, i32 1, i32 0
  %t280 = icmp eq i32 %t275, 0
  %t281 = shl i32 %t279, 16
  %t282 = or i32 %t281, %t277
  %t283 = select i1 %t280, i32 0, i32 %t282
  call void @__olang_scope_close(ptr %s7)
  %t285 = insertvalue { i32, ptr } zeroinitializer, i32 %t283, 0
  store { i32, ptr } %t285, ptr %rv
  br label %ret
bb75:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 31
  %t290 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eLe_Hc3a9f67fd4028c52dcd01e744501edd7(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l142
  br label %bb76
bb76:
  %t291 = load i64, ptr %l142, !tbaa !24
  store i64 %t291, ptr %l19, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 29
  %t296 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l145
  br label %bb77
bb77:
  %t297 = load i64, ptr %l145, !tbaa !24
  store i64 %t297, ptr %l20, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  %t298 = load i1, ptr %l2, !tbaa !21
  br i1 %t298, label %bb79, label %bb80
bb79:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/parse:Parser", ptr %t300, i32 0, i32 29
  store ptr %t302, ptr %l148, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %t303)
  %t306 = extractvalue { i32, ptr } %t305, 1
  %t307 = extractvalue { i32, ptr } %t305, 0
  store i32 %t307, ptr %l152
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb82, label %ok.309
ok.309:
  store ptr %t306, ptr %l151
  br label %bb81
bb80:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t310, i64 1)
  %t313 = extractvalue { i32, ptr } %t312, 1
  %t314 = extractvalue { i32, ptr } %t312, 0
  store i32 %t314, ptr %l157
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb86, label %ok.316
ok.316:
  store ptr %t313, ptr %l156
  br label %bb85
bb81:
  %t317 = load ptr, ptr %l151, !tbaa !29
  store ptr %t317, ptr %l149, !tbaa !29
  br label %bb83
bb82:
  %t318 = load i32, ptr %l152, !tbaa !23
  %t319 = lshr i32 %t318, 16
  %t320 = and i32 %t318, 65535
  %t321 = icmp eq i32 %t319, 1
  %t322 = select i1 %t321, i32 1, i32 0
  %t323 = icmp eq i32 %t318, 0
  %t324 = shl i32 %t322, 16
  %t325 = or i32 %t324, %t320
  %t326 = select i1 %t323, i32 0, i32 %t325
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  %t328 = insertvalue { i32, ptr } zeroinitializer, i32 %t326, 0
  store { i32, ptr } %t328, ptr %rv
  br label %ret
bb83:
  %t329 = load ptr, ptr %l148, !tbaa !29
  %t330 = load ptr, ptr %l149, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v0, ptr %t329, ptr %t330)
  br label %bb84
bb84:
  br label %bb90
bb85:
  %t331 = load ptr, ptr %l156, !tbaa !29
  store ptr %t331, ptr %l154, !tbaa !29
  br label %bb87
bb86:
  %t332 = load i32, ptr %l157, !tbaa !23
  %t333 = lshr i32 %t332, 16
  %t334 = and i32 %t332, 65535
  %t335 = icmp eq i32 %t333, 1
  %t336 = select i1 %t335, i32 1, i32 0
  %t337 = icmp eq i32 %t332, 0
  %t338 = shl i32 %t336, 16
  %t339 = or i32 %t338, %t334
  %t340 = select i1 %t337, i32 0, i32 %t339
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  %t342 = insertvalue { i32, ptr } zeroinitializer, i32 %t340, 0
  store { i32, ptr } %t342, ptr %rv
  br label %ret
bb87:
  %t343 = load ptr, ptr %l154, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/parse:Parser", ptr %t344, i32 0, i32 31
  store ptr %t346, ptr %l160, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t351 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %t347, ptr %t343, i1 true)
  store ptr %t351, ptr %l163
  br label %bb88
bb88:
  %t352 = load ptr, ptr %l160, !tbaa !29
  %t353 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t352, ptr %t353)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t357 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t354, i32 55)
  store i1 %t357, ptr %l166
  br label %bb91
bb91:
  %t358 = load i1, ptr %l166, !tbaa !21
  br i1 %t358, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s11)
  br label %bb122
bb93:
  br label %bb94
bb94:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t362 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t359, i32 8)
  store i1 %t362, ptr %l169
  br label %bb95
bb95:
  %t363 = load i1, ptr %l169, !tbaa !21
  %t364 = xor i1 %t363, true
  br i1 %t364, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s11)
  br label %bb123
bb97:
  br label %bb98
bb98:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t366, i64 1)
  store i32 %t368, ptr %l172
  br label %bb99
bb99:
  %t369 = load i32, ptr %l172
  store i32 %t369, ptr %l22
  %t370 = load i32, ptr %l22
  %t372 = trunc i64 92 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb102
bb101:
  %t375 = load i32, ptr %l22
  %t377 = trunc i64 74 to i32
  %t378 = icmp eq i32 %t375, %t377
  store i1 %t378, ptr %l175, !tbaa !21
  br label %bb102
bb102:
  %t380 = load i1, ptr %l175, !tbaa !21
  br i1 %t380, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb105
bb104:
  %t381 = load i32, ptr %l22
  %t383 = trunc i64 9 to i32
  %t384 = icmp eq i32 %t381, %t383
  store i1 %t384, ptr %l178, !tbaa !21
  br label %bb105
bb105:
  %t386 = load i1, ptr %l178, !tbaa !21
  br i1 %t386, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb108
bb107:
  %t387 = load i32, ptr %l22
  %t389 = trunc i64 93 to i32
  %t390 = icmp eq i32 %t387, %t389
  store i1 %t390, ptr %l181, !tbaa !21
  br label %bb108
bb108:
  %t392 = load i1, ptr %l181, !tbaa !21
  br i1 %t392, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb111
bb110:
  %t393 = load i32, ptr %l22
  %t395 = trunc i64 31 to i32
  %t396 = icmp eq i32 %t393, %t395
  store i1 %t396, ptr %l184, !tbaa !21
  br label %bb111
bb111:
  %t398 = load i1, ptr %l184, !tbaa !21
  br i1 %t398, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb114
bb113:
  %t399 = load i32, ptr %l22
  %t401 = trunc i64 32 to i32
  %t402 = icmp eq i32 %t399, %t401
  store i1 %t402, ptr %l187, !tbaa !21
  br label %bb114
bb114:
  %t404 = load i1, ptr %l187, !tbaa !21
  br i1 %t404, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb117
bb116:
  %t405 = load i32, ptr %l22
  %t407 = trunc i64 0 to i32
  %t408 = icmp eq i32 %t405, %t407
  store i1 %t408, ptr %l190, !tbaa !21
  br label %bb117
bb117:
  %t410 = load i1, ptr %l190, !tbaa !21
  br i1 %t410, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s11)
  br label %bb123
bb119:
  br label %bb120
bb120:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t411)
  store i32 %t413, ptr %l194
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s11)
  br label %bb122
bb122:
  br label %bb78
bb123:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/parse:Parser", ptr %t414, i32 0, i32 31
  %t417 = load i64, ptr %l19, !tbaa !24
  %t420 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t416, i64 %t417)
  store { i64, ptr } %t420, ptr %l198
  br label %bb124
bb124:
  %t421 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t421, ptr %l23, !tbaa !27
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/parse:Parser", ptr %t422, i32 0, i32 29
  %t425 = load i64, ptr %l20, !tbaa !24
  %t428 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t424, i64 %t425)
  store { i64, ptr } %t428, ptr %l202
  br label %bb125
bb125:
  %t429 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t429, ptr %l24, !tbaa !27
  store ptr null, ptr %l25, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t433 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t430, i32 9)
  store i1 %t433, ptr %l205
  br label %bb126
bb126:
  %t434 = load i1, ptr %l205, !tbaa !21
  br i1 %t434, label %bb127, label %bb128
bb127:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t435)
  %t438 = extractvalue { i32, ptr } %t437, 1
  %t439 = extractvalue { i32, ptr } %t437, 0
  store i32 %t439, ptr %l209
  %t440 = icmp ne i32 %t439, 0
  br i1 %t440, label %bb130, label %ok.441
ok.441:
  store ptr %t438, ptr %l208
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t442 = load ptr, ptr %l208, !tbaa !29
  store ptr %t442, ptr %l206, !tbaa !29
  br label %bb131
bb130:
  %t443 = load i32, ptr %l209, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 1, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  call void @__olang_scope_close(ptr %s7)
  %t453 = insertvalue { i32, ptr } zeroinitializer, i32 %t451, 0
  store { i32, ptr } %t453, ptr %rv
  br label %ret
bb131:
  %t454 = load ptr, ptr %l206, !tbaa !29
  store ptr %t454, ptr %l25, !tbaa !29
  br label %bb132
bb132:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %t456)
  %t459 = extractvalue { i32, { { i64, ptr }, ptr } } %t458, 1
  %t460 = extractvalue { i32, { { i64, ptr }, ptr } } %t458, 0
  store i32 %t460, ptr %l215
  %t461 = icmp ne i32 %t460, 0
  br i1 %t461, label %bb134, label %ok.462
ok.462:
  store { { i64, ptr }, ptr } %t459, ptr %l214
  br label %bb133
bb133:
  %t463 = load { { i64, ptr }, ptr }, ptr %l214
  store { { i64, ptr }, ptr } %t463, ptr %l212
  br label %bb135
bb134:
  %t464 = load i32, ptr %l215, !tbaa !23
  %t465 = lshr i32 %t464, 16
  %t466 = and i32 %t464, 65535
  %t467 = icmp eq i32 %t465, 1
  %t468 = select i1 %t467, i32 1, i32 0
  %t469 = icmp eq i32 %t464, 0
  %t470 = shl i32 %t468, 16
  %t471 = or i32 %t470, %t466
  %t472 = select i1 %t469, i32 0, i32 %t471
  call void @__olang_scope_close(ptr %s7)
  %t474 = insertvalue { i32, ptr } zeroinitializer, i32 %t472, 0
  store { i32, ptr } %t474, ptr %rv
  br label %ret
bb135:
  %t475 = load { { i64, ptr }, ptr }, ptr %l212
  store { { i64, ptr }, ptr } %t475, ptr %l26
  %t476 = getelementptr { { i64, ptr }, ptr }, ptr %l26, i32 0, i32 0
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !27
  store { i64, ptr } %t477, ptr %l27, !tbaa !27
  %t479 = getelementptr { { i64, ptr }, ptr }, ptr %l26, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !29
  store ptr %t480, ptr %l28, !tbaa !29
  %t482 = load ptr, ptr %l13, !tbaa !29
  store ptr %t482, ptr %l219, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i32, ptr %l15, !tbaa !23
  %t487 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t483, i32 %t484)
  store %"compiler/source:Span" %t487, ptr %l222
  br label %bb136
bb136:
  %t488 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t490 = load ptr, ptr %l25, !tbaa !29
  %t491 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t492 = load ptr, ptr %l28, !tbaa !29
  %t493 = load %"compiler/source:Span", ptr %l222
  %t499 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t493, { i64, ptr } %t488, { i64, ptr } %t489, ptr %t490, { i64, ptr } %t491, ptr %t492)
  store %"compiler/ast:Case" %t499, ptr %l228
  br label %bb137
bb137:
  %t500 = load %"compiler/ast:Case", ptr %l228
  %t501 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Case" %t500, ptr %t501
  %t502 = load ptr, ptr %l219, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v0, ptr %t502, ptr %t501)
  br label %bb138
bb138:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t507 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t504, i32 8)
  store i1 %t507, ptr %l232
  br label %bb139
bb139:
  %t508 = load i1, ptr %l232, !tbaa !21
  br i1 %t508, label %bb140, label %bb141
bb140:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t509)
  store i32 %t511, ptr %l234
  br label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s7)
  br label %bb144
bb144:
  br label %bb40
bb145:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t515 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t512, i32 93)
  %t516 = extractvalue { i32, i32 } %t515, 1
  %t517 = extractvalue { i32, i32 } %t515, 0
  store i32 %t517, ptr %l239
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb147, label %ok.519
ok.519:
  store i32 %t516, ptr %l238
  br label %bb146
bb146:
  %t520 = load i32, ptr %l238, !tbaa !23
  store i32 %t520, ptr %l235, !tbaa !23
  br label %bb148
bb147:
  %t521 = load i32, ptr %l239, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  %t531 = insertvalue { i32, ptr } zeroinitializer, i32 %t529, 0
  store { i32, ptr } %t531, ptr %rv
  br label %ret
bb148:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i64, ptr %l11, !tbaa !24
  %t536 = getelementptr %"compiler/parse:Parser", ptr %t532, i32 0, i32 15
  store i64 %t533, ptr %t536, !tbaa !24
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load i1, ptr %l12, !tbaa !21
  %t541 = getelementptr %"compiler/parse:Parser", ptr %t537, i32 0, i32 16
  store i1 %t538, ptr %t541, !tbaa !21
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load i32, ptr %l1, !tbaa !23
  %t546 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t542, i32 %t543)
  store %"compiler/source:Span" %t546, ptr %l247
  br label %bb149
bb149:
  %t547 = load ptr, ptr %l10, !tbaa !29
  store ptr %t547, ptr %l248, !tbaa !29
  %t548 = load i1, ptr %l2, !tbaa !21
  store i1 %t548, ptr %l249, !tbaa !21
  %t549 = load ptr, ptr %l13, !tbaa !29
  %t551 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v0, ptr %t549)
  store { i64, ptr } %t551, ptr %l251
  br label %bb150
bb150:
  %t552 = load ptr, ptr %l14, !tbaa !29
  %t553 = load %"compiler/source:Span", ptr %l247
  %t554 = load ptr, ptr %l248, !tbaa !29
  %t555 = load i1, ptr %l249, !tbaa !21
  %t556 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t558 = call %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t553, ptr %t554, i1 %t555, { i64, ptr } %t556, ptr %t552)
  store %"compiler/ast:Match" %t558, ptr %l253
  br label %bb151
bb151:
  %t559 = load %"compiler/ast:Match", ptr %l253
  %t560 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:Match" %t559, ptr %t560
  %t562 = insertvalue { i32, ptr } zeroinitializer, ptr %t560, 1
  store { i32, ptr } %t562, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t1, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/source:Source", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t25 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = sub i32 %t26, %t28
  %t33 = sext i32 %t31 to i64
  %t37 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t20, i64 %t24, i64 %t33)
  store i32 %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load i32, ptr %l18
  store i32 %t38, ptr %l2
  %t39 = load i32, ptr %l2
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i32, ptr %l2
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t57 = load i32, ptr %l2
  %t59 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t57)
  store i1 %t59, ptr %l29
  br label %bb15
bb15:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t61, i64 2)
  store i32 %t63, ptr %l32
  br label %bb18
bb18:
  %t64 = load i32, ptr %l32
  %t66 = trunc i64 88 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l30, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca %"compiler/token:Token"
  %l13 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  %t6 = trunc i64 1 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t11, { i64, ptr } { i64 6, ptr @.d4 })
  store i32 %t13, ptr %l8
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb5, label %ok.15
ok.15:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s1)
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t27)
  store %"compiler/token:Token" %t29, ptr %l11
  br label %bb8
bb8:
  %t30 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t30, ptr %l1
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l13
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l15, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/token:Token", ptr %l1
  %t42 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t38, %"compiler/token:Token" %t39)
  store { i64, ptr } %t42, ptr %l18
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t45 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  store i32 %t45, ptr %l19
  br label %bb11
bb11:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = insertvalue { i32, i32 } zeroinitializer, i32 %t46, 1
  store { i32, i32 } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 8 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 0 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/scan:Tokens", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/token:Token", ptr %t60, i64 %t57
  %t62 = load %"compiler/token:Token", ptr %t61
  %t65 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t49, %"compiler/token:Token" %t62)
  store { i64, ptr } %t65, ptr %l22
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t66)
  store { i64, ptr } %t67, ptr %l23
  br label %bb9
bb9:
  %t68 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %l59 = alloca %"compiler/parse:NameList"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t34 = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l17, !tbaa !24
  store %"compiler/source:Span" zeroinitializer, ptr %l18
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb5:
  %t22 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t22, ptr %l20
  br label %bb7
bb6:
  %t23 = load i64, ptr %l17, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  %t26 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t26, ptr %l18
  br label %bb6
bb8:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sle i64 %t27, 1152921504606846975
  br i1 %t28, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb10:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = load %"compiler/source:Span", ptr %l18
  store i64 0, ptr %t34
  br label %fill.35
fill.35:
  %t38 = load i64, ptr %t34
  %t39 = icmp slt i64 %t38, %t30
  br i1 %t39, label %fillb.36, label %filld.37
fillb.36:
  %t40 = getelementptr %"compiler/source:Span", ptr %t32, i64 %t38
  store %"compiler/source:Span" %t33, ptr %t40
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %t34
  br label %fill.35
filld.37:
  %t42 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t32, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l5, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb16, label %bb17
bb16:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32 }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l9
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l10, !tbaa !23
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l43, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t91
  store i32 %t92, ptr %t97, !tbaa !33
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load %"compiler/source:Span", ptr %l9
  %t103 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i64 %t99
  store %"compiler/source:Span" %t100, ptr %t105
  br label %bb26
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a0, ptr %l49, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 58)
  store { i64, ptr } %t108, ptr %l51
  br label %bb22
bb22:
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } %t115)
  store i32 %t118, ptr %l53
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb24, label %ok.120
ok.120:
  br label %bb23
bb23:
  br label %bb25
bb24:
  %t121 = load i32, ptr %l53, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l5, !tbaa !24
  br label %bb12
bb28:
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t136, { i64, ptr } %t137)
  store %"compiler/parse:NameList" %t140, ptr %l59
  br label %bb29
bb29:
  %t141 = load %"compiler/parse:NameList", ptr %l59
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/parse:NameList" %t141, ptr %t142
  %t144 = insertvalue { i32, ptr } zeroinitializer, ptr %t142, 1
  store { i32, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 77)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l5
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 37
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 6
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t22, i64 %t28)
  br label %bb4
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/ast:Param"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store i32 %t8, ptr %l10
  br label %bb2
bb2:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l8, !tbaa !23
  br label %bb4
bb3:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l8, !tbaa !23
  store i32 %t24, ptr %l3, !tbaa !23
  store ptr null, ptr %l4, !tbaa !29
  br i1 %a1, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t27, i32 55)
  store i1 %t30, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb16
bb7:
  %t31 = load i1, ptr %l17, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t32, i32 89)
  store i1 %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l21, !tbaa !21
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t38, i32 8)
  store i1 %t41, ptr %l25
  br label %bb14
bb14:
  %t42 = load i1, ptr %l25, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %l14, !tbaa !21
  br label %bb16
bb16:
  %t44 = load i1, ptr %l14, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l30
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb20, label %ok.53
ok.53:
  store ptr %t50, ptr %l29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t54 = load ptr, ptr %l29, !tbaa !29
  store ptr %t54, ptr %l27, !tbaa !29
  br label %bb21
bb20:
  %t55 = load i32, ptr %l30, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb21:
  %t66 = load ptr, ptr %l27, !tbaa !29
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb22
bb22:
  store ptr null, ptr %l5, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t68, i32 58)
  store i1 %t71, ptr %l35
  br label %bb23
bb23:
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t73)
  %t76 = extractvalue { i32, ptr } %t75, 1
  %t77 = extractvalue { i32, ptr } %t75, 0
  store i32 %t77, ptr %l39
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb27, label %ok.79
ok.79:
  store ptr %t76, ptr %l38
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t80 = load ptr, ptr %l38, !tbaa !29
  store ptr %t80, ptr %l36, !tbaa !29
  br label %bb28
bb27:
  %t81 = load i32, ptr %l39, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb28:
  %t92 = load ptr, ptr %l36, !tbaa !29
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t94, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l44
  br label %bb30
bb30:
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l44
  %t106 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t102, i32 %t99, ptr %t100, ptr %t101)
  store %"compiler/ast:Param" %t106, ptr %l48
  br label %bb31
bb31:
  %t107 = load %"compiler/ast:Param", ptr %l48
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t107, ptr %t108
  %t110 = insertvalue { i32, ptr } zeroinitializer, ptr %t108, 1
  store { i32, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/ast:Path"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 32
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 32
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t14)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20
ok.20:
  store i32 %t17, ptr %l13
  br label %bb3
bb3:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  br label %bb5
bb4:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb5:
  %t33 = load ptr, ptr %l10, !tbaa !29
  %t34 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t33, i32 %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t35, i32 56)
  store i1 %t38, ptr %l18
  br label %bb8
bb8:
  %t39 = load i1, ptr %l18, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l21
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 32
  store ptr %t47, ptr %l23, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54
ok.54:
  store i32 %t51, ptr %l26
  br label %bb13
bb13:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l24, !tbaa !23
  br label %bb15
bb14:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  call void @__olang_scope_close(ptr %s1)
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb15:
  %t67 = load ptr, ptr %l23, !tbaa !29
  %t68 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t67, i32 %t68)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb7
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t69, i32 0, i32 32
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l32
  br label %bb19
bb19:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l35
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t83 = load %"compiler/source:Span", ptr %l35
  %t85 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t83, { i64, ptr } %t82)
  store %"compiler/ast:Path" %t85, ptr %l37
  br label %bb21
bb21:
  %t86 = load %"compiler/ast:Path", ptr %l37
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:Path" %t86, ptr %t87
  %t89 = insertvalue { i32, ptr } zeroinitializer, ptr %t87, 1
  store { i32, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/scan:Tokens", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t23, i64 %t27)
  store i64 %t30, ptr %l13
  br label %bb4
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i64 %t31
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 %t14, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %t17)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l8
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23
ok.23:
  store ptr %t20, ptr %l7
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l5, !tbaa !29
  br label %bb7
bb5:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  store i32 %t33, ptr %l9, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t34)
  br label %bb6
bb6:
  %t36 = load i32, ptr %l9, !tbaa !23
  %t37 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t37, ptr %rv
  br label %ret
bb7:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %t39, ptr %t38)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l15
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47
ok.47:
  store ptr %t44, ptr %l14
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l14, !tbaa !29
  store ptr %t48, ptr %l11, !tbaa !29
  br label %bb11
bb9:
  %t49 = load i32, ptr %l15, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %l16, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t58)
  br label %bb10
bb10:
  %t60 = load i32, ptr %l16, !tbaa !23
  %t61 = insertvalue { i32, ptr } zeroinitializer, i32 %t60, 0
  store { i32, ptr } %t61, ptr %rv
  br label %ret
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t62)
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l11, !tbaa !29
  %t65 = insertvalue { i32, ptr } zeroinitializer, ptr %t64, 1
  store { i32, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l14 = alloca %"compiler/token:Token"
  %l15 = alloca %"compiler/token:Token"
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l35 = alloca i1
  %l39 = alloca i32
  %l40 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l101 = alloca %"compiler/source:Span"
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l127 = alloca i32
  %l129 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l140 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca i32
  %l148 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l163 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l170 = alloca i1
  %l172 = alloca i32
  %l175 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i32
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca i32
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca i32
  %l196 = alloca %"compiler/token:Token"
  %l198 = alloca %"compiler/token:Token"
  %l200 = alloca %"compiler/token:Token"
  %l203 = alloca i1
  %l204 = alloca i1
  %l208 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l220 = alloca i1
  %l223 = alloca i1
  %l226 = alloca i32
  %l228 = alloca i32
  %l230 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l234 = alloca i32
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l242 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t84 = alloca { i64, [5 x i64] }, align 8
  %t140 = alloca { i64, [5 x i64] }, align 8
  %t231 = alloca { i64, [5 x i64] }, align 8
  %t276 = alloca { i64, [5 x i64] }, align 8
  %t318 = alloca { i64, [5 x i64] }, align 8
  %t366 = alloca { i64, [5 x i64] }, align 8
  %t594 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l23
  br label %bb3
bb3:
  %t12 = load i32, ptr %l23
  store i32 %t12, ptr %l4
  %t13 = load i32, ptr %l4
  %t15 = trunc i64 90 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t22 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %t18, ptr %t19)
  %t23 = extractvalue { i32, ptr } %t22, 1
  %t24 = extractvalue { i32, ptr } %t22, 0
  store i32 %t24, ptr %l30
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb8, label %ok.26
ok.26:
  store ptr %t23, ptr %l29
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l29, !tbaa !29
  store ptr %t27, ptr %l26, !tbaa !29
  br label %bb9
bb8:
  %t28 = load i32, ptr %l30, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  call void @__olang_scope_close(ptr %s1)
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb150
bb10:
  %t40 = load i32, ptr %l4
  %t42 = trunc i64 56 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb56
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l35
  br label %bb14
bb14:
  %t48 = load i1, ptr %l35, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t53 = insertvalue { i32, ptr } zeroinitializer, ptr %t51, 1
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l39
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t57)
  %t60 = extractvalue { i32, i32 } %t59, 1
  %t61 = extractvalue { i32, i32 } %t59, 0
  store i32 %t61, ptr %l43
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb20, label %ok.63
ok.63:
  store i32 %t60, ptr %l42
  br label %bb19
bb19:
  %t64 = load i32, ptr %l42, !tbaa !23
  store i32 %t64, ptr %l40, !tbaa !23
  br label %bb21
bb20:
  %t65 = load i32, ptr %l43, !tbaa !23
  %t66 = lshr i32 %t65, 16
  %t67 = and i32 %t65, 65535
  %t68 = icmp eq i32 %t66, 1
  %t69 = select i1 %t68, i32 1, i32 0
  %t70 = icmp eq i32 %t65, 0
  %t71 = shl i32 %t69, 16
  %t72 = or i32 %t71, %t67
  %t73 = select i1 %t70, i32 0, i32 %t72
  call void @__olang_scope_close(ptr %s1)
  %t75 = insertvalue { i32, ptr } zeroinitializer, i32 %t73, 0
  store { i32, ptr } %t75, ptr %rv
  br label %ret
bb21:
  %t76 = load i32, ptr %l40, !tbaa !23
  store i32 %t76, ptr %l5, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l47
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l5, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 0
  store i64 15, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l47
  %t87 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t86, 0
  %t89 = insertvalue { %"compiler/source:Span", ptr, i32 } %t87, ptr %t82, 1
  %t91 = insertvalue { %"compiler/source:Span", ptr, i32 } %t89, i32 %t83, 2
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t91, ptr %t92
  %t93 = load { i64, [5 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t93, ptr %t95
  store ptr %t95, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t97, i32 77)
  store i1 %t100, ptr %l54
  br label %bb23
bb23:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t106 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v0, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l58
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  %t107 = load i1, ptr %l58, !tbaa !21
  store i1 %t107, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l55, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t109)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l62
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb31, label %ok.115
ok.115:
  store { i64, ptr } %t112, ptr %l61
  br label %bb30
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t119 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t116, i32 77)
  store i1 %t119, ptr %l80
  br label %bb37
bb30:
  %t120 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t120, ptr %l59, !tbaa !27
  br label %bb32
bb31:
  %t121 = load i32, ptr %l62, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  call void @__olang_scope_close(ptr %s1)
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb32:
  %t132 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t132, ptr %l6, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l3, !tbaa !23
  %t137 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t133, i32 %t134)
  store %"compiler/source:Span" %t137, ptr %l66
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 0
  store i64 14, ptr %t141
  %t142 = load %"compiler/source:Span", ptr %l66
  %t143 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t142, 0
  %t145 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t143, ptr %t138, 1
  %t147 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t145, { i64, ptr } %t139, 2
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l3, !tbaa !23
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t159 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %t153, i32 %t154, ptr %t155)
  %t160 = extractvalue { i32, ptr } %t159, 1
  %t161 = extractvalue { i32, ptr } %t159, 0
  store i32 %t161, ptr %l76
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb35, label %ok.163
ok.163:
  store ptr %t160, ptr %l75
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l75, !tbaa !29
  store ptr %t164, ptr %l71, !tbaa !29
  br label %bb36
bb35:
  %t165 = load i32, ptr %l76, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  call void @__olang_scope_close(ptr %s1)
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t173, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb36:
  %t176 = load ptr, ptr %l71, !tbaa !29
  store ptr %t176, ptr %l2, !tbaa !29
  br label %bb55
bb37:
  %t177 = load i1, ptr %l80, !tbaa !21
  br i1 %t177, label %bb38, label %bb39
bb38:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t178)
  store i1 %t180, ptr %l83
  br label %bb40
bb39:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb41
bb40:
  %t181 = load i1, ptr %l83, !tbaa !21
  store i1 %t181, ptr %l81, !tbaa !21
  br label %bb41
bb41:
  %t182 = load i1, ptr %l81, !tbaa !21
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 3
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/parse:Oracle", ptr %t186, i32 0, i32 3
  store ptr %t188, ptr %l87, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  store ptr %t192, ptr %l89, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t193)
  store %"compiler/source:Span" %t195, ptr %l91
  br label %bb44
bb43:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb47
bb44:
  %t196 = load ptr, ptr %l89, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l91
  %t198 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t196, %"compiler/source:Span" %t197)
  store { i64, ptr } %t198, ptr %l92
  br label %bb45
bb45:
  %t199 = load ptr, ptr %l87, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t201 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t199, { i64, ptr } %t200)
  store i1 %t201, ptr %l93
  br label %bb46
bb46:
  %t202 = load i1, ptr %l93, !tbaa !21
  store i1 %t202, ptr %l84, !tbaa !21
  br label %bb47
bb47:
  %t203 = load i1, ptr %l84, !tbaa !21
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t204)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l97
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb51, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l96
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t211 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t211, ptr %l94, !tbaa !27
  br label %bb52
bb51:
  %t212 = load i32, ptr %l97, !tbaa !23
  %t213 = lshr i32 %t212, 16
  %t214 = and i32 %t212, 65535
  %t215 = icmp eq i32 %t213, 1
  %t216 = select i1 %t215, i32 1, i32 0
  %t217 = icmp eq i32 %t212, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t214
  %t220 = select i1 %t217, i32 0, i32 %t219
  call void @__olang_scope_close(ptr %s1)
  %t222 = insertvalue { i32, ptr } zeroinitializer, i32 %t220, 0
  store { i32, ptr } %t222, ptr %rv
  br label %ret
bb52:
  %t223 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t223, ptr %l7, !tbaa !27
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i32, ptr %l3, !tbaa !23
  %t228 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t224, i32 %t225)
  store %"compiler/source:Span" %t228, ptr %l101
  br label %bb53
bb53:
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t231, i32 0, i32 0
  store i64 14, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l101
  %t234 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t233, 0
  %t236 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t234, ptr %t229, 1
  %t238 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t236, { i64, ptr } %t230, 2
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t238, ptr %t239
  %t240 = load { i64, [5 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t240, ptr %t242
  store ptr %t242, ptr %l2, !tbaa !29
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb150
bb56:
  %t244 = load i32, ptr %l4
  %t246 = trunc i64 88 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %t249)
  %t252 = extractvalue { i32, { i64, ptr } } %t251, 1
  %t253 = extractvalue { i32, { i64, ptr } } %t251, 0
  store i32 %t253, ptr %l111
  %t254 = icmp ne i32 %t253, 0
  br i1 %t254, label %bb61, label %ok.255
ok.255:
  store { i64, ptr } %t252, ptr %l110
  br label %bb60
bb60:
  %t256 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t256, ptr %l108, !tbaa !27
  br label %bb62
bb61:
  %t257 = load i32, ptr %l111, !tbaa !23
  %t258 = lshr i32 %t257, 16
  %t259 = and i32 %t257, 65535
  %t260 = icmp eq i32 %t258, 1
  %t261 = select i1 %t260, i32 1, i32 0
  %t262 = icmp eq i32 %t257, 0
  %t263 = shl i32 %t261, 16
  %t264 = or i32 %t263, %t259
  %t265 = select i1 %t262, i32 0, i32 %t264
  call void @__olang_scope_close(ptr %s1)
  %t267 = insertvalue { i32, ptr } zeroinitializer, i32 %t265, 0
  store { i32, ptr } %t267, ptr %rv
  br label %ret
bb62:
  %t268 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t268, ptr %l8, !tbaa !27
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l3, !tbaa !23
  %t273 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t269, i32 %t270)
  store %"compiler/source:Span" %t273, ptr %l115
  br label %bb63
bb63:
  %t274 = load ptr, ptr %l2, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t276
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t276, i32 0, i32 0
  store i64 12, ptr %t277
  %t278 = load %"compiler/source:Span", ptr %l115
  %t279 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t278, 0
  %t281 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t279, ptr %t274, 1
  %t283 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t281, { i64, ptr } %t275, 2
  %t284 = getelementptr { i64, [5 x i64] }, ptr %t276, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t283, ptr %t284
  %t285 = load { i64, [5 x i64] }, ptr %t276
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t285, ptr %t287
  store ptr %t287, ptr %l2, !tbaa !29
  br label %bb150
bb64:
  %t289 = load i32, ptr %l4
  %t291 = trunc i64 71 to i32
  %t292 = icmp eq i32 %t289, %t291
  br i1 %t292, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  %t294 = load i32, ptr %l4
  %t296 = trunc i64 72 to i32
  %t297 = icmp eq i32 %t294, %t296
  br i1 %t297, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t299 = load i32, ptr %l4
  %t301 = trunc i64 76 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t304)
  store i32 %t306, ptr %l127
  br label %bb72
bb72:
  %t307 = load i32, ptr %l127
  store i32 %t307, ptr %l9
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t308)
  store i32 %t310, ptr %l129
  br label %bb73
bb73:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l3, !tbaa !23
  %t315 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t311, i32 %t312)
  store %"compiler/source:Span" %t315, ptr %l132
  br label %bb74
bb74:
  %t316 = load i32, ptr %l9
  %t317 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 0
  store i64 4, ptr %t319
  %t320 = load %"compiler/source:Span", ptr %l132
  %t321 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t320, 0
  %t323 = insertvalue { %"compiler/source:Span", i32, ptr } %t321, i32 %t316, 1
  %t325 = insertvalue { %"compiler/source:Span", i32, ptr } %t323, ptr %t317, 2
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t325, ptr %t326
  %t327 = load { i64, [5 x i64] }, ptr %t318
  %t329 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t327, ptr %t329
  store ptr %t329, ptr %l2, !tbaa !29
  br label %bb150
bb75:
  %t331 = load i32, ptr %l4
  %t333 = trunc i64 28 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb84
bb78:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t336)
  store i32 %t338, ptr %l140
  br label %bb79
bb79:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t339)
  %t342 = extractvalue { i32, ptr } %t341, 1
  %t343 = extractvalue { i32, ptr } %t341, 0
  store i32 %t343, ptr %l144
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb81, label %ok.345
ok.345:
  store ptr %t342, ptr %l143
  br label %bb80
bb80:
  %t346 = load ptr, ptr %l143, !tbaa !29
  store ptr %t346, ptr %l141, !tbaa !29
  br label %bb82
bb81:
  %t347 = load i32, ptr %l144, !tbaa !23
  %t348 = lshr i32 %t347, 16
  %t349 = and i32 %t347, 65535
  %t350 = icmp eq i32 %t348, 1
  %t351 = select i1 %t350, i32 1, i32 0
  %t352 = icmp eq i32 %t347, 0
  %t353 = shl i32 %t351, 16
  %t354 = or i32 %t353, %t349
  %t355 = select i1 %t352, i32 0, i32 %t354
  call void @__olang_scope_close(ptr %s1)
  %t357 = insertvalue { i32, ptr } zeroinitializer, i32 %t355, 0
  store { i32, ptr } %t357, ptr %rv
  br label %ret
bb82:
  %t358 = load ptr, ptr %l141, !tbaa !29
  store ptr %t358, ptr %l10, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l3, !tbaa !23
  %t363 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t359, i32 %t360)
  store %"compiler/source:Span" %t363, ptr %l148
  br label %bb83
bb83:
  %t364 = load ptr, ptr %l2, !tbaa !29
  %t365 = load ptr, ptr %l10, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t366
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 0
  store i64 11, ptr %t367
  %t368 = load %"compiler/source:Span", ptr %l148
  %t369 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t368, 0
  %t371 = insertvalue { %"compiler/source:Span", ptr, ptr } %t369, ptr %t364, 1
  %t373 = insertvalue { %"compiler/source:Span", ptr, ptr } %t371, ptr %t365, 2
  %t374 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t373, ptr %t374
  %t375 = load { i64, [5 x i64] }, ptr %t366
  %t377 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t375, ptr %t377
  store ptr %t377, ptr %l2, !tbaa !29
  br label %bb150
bb84:
  %t379 = load i32, ptr %l4
  %t381 = trunc i64 81 to i32
  %t382 = icmp eq i32 %t379, %t381
  br i1 %t382, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb149
bb87:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/parse:Parser", ptr %t384, i32 0, i32 7
  %t387 = load i32, ptr %t386
  %t389 = trunc i64 0 to i32
  %t390 = icmp eq i32 %t387, %t389
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb88, label %bb89
bb88:
  %t394 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t396 = insertvalue { i32, ptr } zeroinitializer, ptr %t394, 1
  store { i32, ptr } %t396, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t397, i64 1)
  store i32 %t399, ptr %l161
  br label %bb91
bb91:
  %t400 = load i32, ptr %l161
  store i32 %t400, ptr %l11
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t403 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t401)
  store i1 %t403, ptr %l163
  br label %bb92
bb92:
  %t404 = load i1, ptr %l163, !tbaa !21
  br i1 %t404, label %bb93, label %bb94
bb93:
  %t405 = load i32, ptr %l11
  %t407 = trunc i64 90 to i32
  %t408 = icmp eq i32 %t405, %t407
  br i1 %t408, label %bb95, label %bb96
bb94:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb106
bb95:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb105
bb96:
  %t410 = load i32, ptr %l11
  %t412 = trunc i64 1 to i32
  %t413 = icmp eq i32 %t410, %t412
  br i1 %t413, label %bb97, label %bb98
bb97:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t415, i64 2)
  store i32 %t417, ptr %l172
  br label %bb99
bb98:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb100
bb99:
  %t418 = load i32, ptr %l172
  %t420 = trunc i64 90 to i32
  %t421 = icmp eq i32 %t418, %t420
  store i1 %t421, ptr %l170, !tbaa !21
  br label %bb100
bb100:
  %t423 = load i1, ptr %l170, !tbaa !21
  br i1 %t423, label %bb101, label %bb102
bb101:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t428 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v0, ptr %t424, ptr %t425)
  store i1 %t428, ptr %l178
  br label %bb103
bb102:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb104
bb103:
  %t429 = load i1, ptr %l178, !tbaa !21
  store i1 %t429, ptr %l175, !tbaa !21
  br label %bb104
bb104:
  %t430 = load i1, ptr %l175, !tbaa !21
  store i1 %t430, ptr %l167, !tbaa !21
  br label %bb105
bb105:
  %t431 = load i1, ptr %l167, !tbaa !21
  store i1 %t431, ptr %l164, !tbaa !21
  br label %bb106
bb106:
  %t432 = load i1, ptr %l164, !tbaa !21
  br i1 %t432, label %bb107, label %bb108
bb107:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l2, !tbaa !29
  %t437 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %t433, ptr %t434)
  %t438 = extractvalue { i32, ptr } %t437, 1
  %t439 = extractvalue { i32, ptr } %t437, 0
  store i32 %t439, ptr %l183
  %t440 = icmp ne i32 %t439, 0
  br i1 %t440, label %bb110, label %ok.441
ok.441:
  store ptr %t438, ptr %l182
  br label %bb109
bb108:
  br label %bb116
bb109:
  %t442 = load ptr, ptr %l182, !tbaa !29
  store ptr %t442, ptr %l179, !tbaa !29
  br label %bb111
bb110:
  %t443 = load i32, ptr %l183, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 1, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  call void @__olang_scope_close(ptr %s1)
  %t453 = insertvalue { i32, ptr } zeroinitializer, i32 %t451, 0
  store { i32, ptr } %t453, ptr %rv
  br label %ret
bb111:
  %t454 = load ptr, ptr %l179, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t455, ptr %l186, !tbaa !29
  %t456 = load i32, ptr %l3, !tbaa !23
  store i32 %t456, ptr %l187, !tbaa !23
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load i32, ptr %l3, !tbaa !23
  %t463 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t457, i32 %t458, ptr %t454)
  store ptr %t463, ptr %l191
  br label %bb112
bb112:
  %t464 = load ptr, ptr %l186, !tbaa !29
  %t465 = load i32, ptr %l187, !tbaa !23
  %t466 = load ptr, ptr %l191, !tbaa !29
  %t467 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t464, i32 %t465, ptr %t466)
  %t468 = extractvalue { i32, ptr } %t467, 1
  %t469 = extractvalue { i32, ptr } %t467, 0
  store i32 %t469, ptr %l193
  %t470 = icmp ne i32 %t469, 0
  br i1 %t470, label %bb114, label %ok.471
ok.471:
  store ptr %t468, ptr %l192
  br label %bb113
bb113:
  %t472 = load ptr, ptr %l192, !tbaa !29
  store ptr %t472, ptr %l185, !tbaa !29
  br label %bb115
bb114:
  %t473 = load i32, ptr %l193, !tbaa !23
  %t474 = lshr i32 %t473, 16
  %t475 = and i32 %t473, 65535
  %t476 = icmp eq i32 %t474, 1
  %t477 = select i1 %t476, i32 1, i32 0
  %t478 = icmp eq i32 %t473, 0
  %t479 = shl i32 %t477, 16
  %t480 = or i32 %t479, %t475
  %t481 = select i1 %t478, i32 0, i32 %t480
  call void @__olang_scope_close(ptr %s1)
  %t483 = insertvalue { i32, ptr } zeroinitializer, i32 %t481, 0
  store { i32, ptr } %t483, ptr %rv
  br label %ret
bb115:
  %t484 = load ptr, ptr %l185, !tbaa !29
  store ptr %t484, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb151
bb116:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t485)
  store %"compiler/token:Token" %t487, ptr %l196
  br label %bb117
bb117:
  %t488 = load %"compiler/token:Token", ptr %l196
  store %"compiler/token:Token" %t488, ptr %l13
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t489, i64 1)
  store %"compiler/token:Token" %t491, ptr %l198
  br label %bb118
bb118:
  %t492 = load %"compiler/token:Token", ptr %l198
  store %"compiler/token:Token" %t492, ptr %l14
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t495 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t493, i64 2)
  store %"compiler/token:Token" %t495, ptr %l200
  br label %bb119
bb119:
  %t496 = load %"compiler/token:Token", ptr %l200
  store %"compiler/token:Token" %t496, ptr %l15
  %t497 = load %"compiler/token:Token", ptr %l13
  %t498 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t501 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t497, i8 %t498)
  store i1 %t501, ptr %l203
  br label %bb120
bb120:
  %t502 = load i1, ptr %l203, !tbaa !21
  br i1 %t502, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb126
bb122:
  %t503 = getelementptr %"compiler/token:Token", ptr %l14, i32 0, i32 0
  %t504 = load i32, ptr %t503
  %t506 = trunc i64 1 to i32
  %t507 = icmp eq i32 %t504, %t506
  %t509 = xor i1 %t507, true
  br i1 %t509, label %bb123, label %bb124
bb123:
  %t511 = getelementptr %"compiler/token:Token", ptr %l14, i32 0, i32 0
  %t512 = load i32, ptr %t511
  %t514 = trunc i64 14 to i32
  %t515 = icmp eq i32 %t512, %t514
  %t517 = xor i1 %t515, true
  store i1 %t517, ptr %l208, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb125
bb125:
  %t519 = load i1, ptr %l208, !tbaa !21
  store i1 %t519, ptr %l204, !tbaa !21
  br label %bb126
bb126:
  %t520 = load i1, ptr %l204, !tbaa !21
  br i1 %t520, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb130
bb128:
  %t521 = load %"compiler/token:Token", ptr %l14
  %t522 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t525 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t521, i8 %t522)
  store i1 %t525, ptr %l215
  br label %bb129
bb129:
  %t526 = load i1, ptr %l215, !tbaa !21
  store i1 %t526, ptr %l212, !tbaa !21
  br label %bb130
bb130:
  %t527 = load i1, ptr %l212, !tbaa !21
  br i1 %t527, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb133
bb132:
  %t528 = getelementptr %"compiler/token:Token", ptr %l15, i32 0, i32 0
  %t529 = load i32, ptr %t528
  %t531 = trunc i64 88 to i32
  %t532 = icmp eq i32 %t529, %t531
  %t534 = xor i1 %t532, true
  store i1 %t534, ptr %l216, !tbaa !21
  br label %bb133
bb133:
  %t536 = load i1, ptr %l216, !tbaa !21
  br i1 %t536, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb137
bb135:
  %t537 = load %"compiler/token:Token", ptr %l15
  %t538 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t541 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t537, i8 %t538)
  store i1 %t541, ptr %l223
  br label %bb136
bb136:
  %t542 = load i1, ptr %l223, !tbaa !21
  store i1 %t542, ptr %l220, !tbaa !21
  br label %bb137
bb137:
  %t543 = load i1, ptr %l220, !tbaa !21
  br i1 %t543, label %bb138, label %bb139
bb138:
  %t544 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t546 = insertvalue { i32, ptr } zeroinitializer, ptr %t544, 1
  store { i32, ptr } %t546, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t547)
  store i32 %t549, ptr %l226
  br label %bb141
bb141:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t550)
  store i32 %t552, ptr %l228
  br label %bb142
bb142:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/parse:Parser", ptr %t553, i32 0, i32 2
  %t556 = load ptr, ptr %t555, !tbaa !29
  store ptr %t556, ptr %l230, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/token:Token", ptr %l14
  %t561 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t557, %"compiler/token:Token" %t558)
  store { i64, ptr } %t561, ptr %l233
  br label %bb143
bb143:
  %t562 = load ptr, ptr %l230, !tbaa !29
  %t563 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t564 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t562, { i64, ptr } %t563)
  store i32 %t564, ptr %l234
  br label %bb144
bb144:
  %t565 = load i32, ptr %l234, !tbaa !23
  store i32 %t565, ptr %l16, !tbaa !23
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %t566)
  %t569 = extractvalue { i32, { i64, ptr } } %t568, 1
  %t570 = extractvalue { i32, { i64, ptr } } %t568, 0
  store i32 %t570, ptr %l238
  %t571 = icmp ne i32 %t570, 0
  br i1 %t571, label %bb146, label %ok.572
ok.572:
  store { i64, ptr } %t569, ptr %l237
  br label %bb145
bb145:
  %t573 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t573, ptr %l235, !tbaa !27
  br label %bb147
bb146:
  %t574 = load i32, ptr %l238, !tbaa !23
  %t575 = lshr i32 %t574, 16
  %t576 = and i32 %t574, 65535
  %t577 = icmp eq i32 %t575, 1
  %t578 = select i1 %t577, i32 1, i32 0
  %t579 = icmp eq i32 %t574, 0
  %t580 = shl i32 %t578, 16
  %t581 = or i32 %t580, %t576
  %t582 = select i1 %t579, i32 0, i32 %t581
  call void @__olang_scope_close(ptr %s1)
  %t584 = insertvalue { i32, ptr } zeroinitializer, i32 %t582, 0
  store { i32, ptr } %t584, ptr %rv
  br label %ret
bb147:
  %t585 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t585, ptr %l17, !tbaa !27
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load i32, ptr %l3, !tbaa !23
  %t590 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t586, i32 %t587)
  store %"compiler/source:Span" %t590, ptr %l242
  br label %bb148
bb148:
  %t591 = load ptr, ptr %l2, !tbaa !29
  %t592 = load i32, ptr %l16, !tbaa !23
  %t593 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t594
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t594, i32 0, i32 0
  store i64 13, ptr %t595
  %t596 = load %"compiler/source:Span", ptr %l242
  %t597 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } undef, %"compiler/source:Span" %t596, 0
  %t599 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t597, ptr %t591, 1
  %t601 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t599, i32 %t592, 2
  %t603 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t601, { i64, ptr } %t593, 3
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t594, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t603, ptr %t604
  %t605 = load { i64, [5 x i64] }, ptr %t594
  %t607 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t605, ptr %t607
  store ptr %t607, ptr %l2, !tbaa !29
  br label %bb150
bb149:
  %t609 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  %t611 = insertvalue { i32, ptr } zeroinitializer, ptr %t609, 1
  store { i32, ptr } %t611, ptr %rv
  br label %ret
bb150:
  call void @__olang_scope_close(ptr %s1)
  br label %bb151
bb151:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t22 = load i1, ptr %l2, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp eq i64 %t26, 1
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l30, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l35
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Oracle", ptr %t56, i32 0, i32 0
  %t59 = load i32, ptr %l5, !tbaa !23
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l40
  br label %bb15
bb15:
  %t63 = load i1, ptr %l40, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %t66)
  store i1 %t68, ptr %l44
  br label %bb18
bb17:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i1, ptr %l44, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 26
  %t76 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t75, i32 %t76)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %ret
bb24:
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l56, !tbaa !27
  %t94 = load i64, ptr %l8, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t101, ptr %t99, i1 true)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb25
bb31:
  br label %bb50
bb32:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l11, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l11, !tbaa !29
  %t126 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i1 %t126)
  br label %bb38
bb38:
  br label %bb50
bb39:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t131 = load ptr, ptr %l72, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 4
  store i1 %t137, ptr %l73, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l73, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l12, !tbaa !29
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb45, label %bb46
bb45:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l12, !tbaa !29
  %t153 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i1 %t153)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %a0, %"compiler/parse:stackMarks" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  store %"compiler/parse:stackMarks" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 27
  %t4 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %t3, i64 %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 28
  %t11 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eTrunc_H7d095616a1c9f3bb0e1e9e6638b5e3ec(ptr %v0, ptr %t10, i64 %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 29
  %t18 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTr_H11957549f332e3c31ab4361387fc70e9(ptr %v0, ptr %t17, i64 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 30
  %t25 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2eTrun_Ha104aa1b1c21542bf8e6309c0c60649a(ptr %v0, ptr %t24, i64 %t26)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 31
  %t32 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTr_H502888c3fa90c24fa361ddb6e04085c1(ptr %v0, ptr %t31, i64 %t33)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 32
  %t39 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %t38, i64 %t40)
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 33
  %t46 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eTrunc_H01cd91640f0f0f618951303ec62b73dc(ptr %v0, ptr %t45, i64 %t47)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %a1
  %t13 = load %"compiler/token:Token", ptr %t12
  store %"compiler/token:Token" %t13, ptr %l3
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %t15, i32 %t17, i32 %t19, %"compiler/msgs:Msg" %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i64
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l58 = alloca i1
  %l61 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l82 = alloca %"compiler/ast:Sig"
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 17
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l12, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t9, i32 88)
  %t13 = extractvalue { i32, i32 } %t12, 1
  %t14 = extractvalue { i32, i32 } %t12, 0
  store i32 %t14, ptr %l19
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16
ok.16:
  store i32 %t13, ptr %l18
  br label %bb4
bb4:
  %t17 = load i32, ptr %l18, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  br label %bb6
bb5:
  %t18 = load i32, ptr %l19, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t29, i1 %a1)
  %t34 = extractvalue { i32, { i64, ptr } } %t33, 1
  %t35 = extractvalue { i32, { i64, ptr } } %t33, 0
  store i32 %t35, ptr %l25
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb8, label %ok.37
ok.37:
  store { i64, ptr } %t34, ptr %l24
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t38, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  %t49 = insertvalue { i32, ptr } zeroinitializer, i32 %t47, 0
  store { i32, ptr } %t49, ptr %rv
  br label %ret
bb9:
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = icmp sle i64 0, 1152921504606846975
  br i1 %t53, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb12:
  %t55 = mul i64 0, 8
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t60, i32 22)
  store i1 %t63, ptr %l32
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb14:
  %t64 = load i1, ptr %l32, !tbaa !21
  store i1 %t64, ptr %l6, !tbaa !21
  %t65 = load i1, ptr %l6, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l37
  br label %bb17
bb16:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb18
bb17:
  %t72 = load i1, ptr %l37, !tbaa !21
  store i1 %t72, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 29
  %t78 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l40
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 17
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l8, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 17
  store i1 true, ptr %t87, !tbaa !21
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t88)
  %t91 = extractvalue { i32, ptr } %t90, 1
  %t92 = extractvalue { i32, ptr } %t90, 0
  store i32 %t92, ptr %l47
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94
ok.94:
  store ptr %t91, ptr %l46
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l46, !tbaa !29
  store ptr %t95, ptr %l44, !tbaa !29
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i1, ptr %l8, !tbaa !21
  %t100 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 17
  store i1 %t97, ptr %t100, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 29
  %t104 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTr_H11957549f332e3c31ab4361387fc70e9(ptr %v0, ptr %t103, i64 %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  %t108 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t108, ptr %rv
  br label %ret
bb27:
  %t109 = load ptr, ptr %l44, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v0, ptr %t112, ptr %t109)
  br label %bb28
bb28:
  %t116 = load i1, ptr %l3, !tbaa !21
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb32
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t121 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t118, i32 55)
  store i1 %t121, ptr %l61
  br label %bb31
bb31:
  %t122 = load i1, ptr %l61, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t125 = load i1, ptr %l58, !tbaa !21
  br i1 %t125, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  br label %bb22
bb37:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i1, ptr %l8, !tbaa !21
  %t130 = getelementptr %"compiler/parse:Parser", ptr %t126, i32 0, i32 17
  store i1 %t127, ptr %t130, !tbaa !21
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 29
  %t134 = load i64, ptr %l7, !tbaa !24
  %t137 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t133, i64 %t134)
  store { i64, ptr } %t137, ptr %l68
  br label %bb38
bb38:
  %t138 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t138, ptr %l5, !tbaa !27
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i1, ptr %l3, !tbaa !21
  %t143 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t139, i1 %t140)
  %t144 = extractvalue { i32, ptr } %t143, 1
  %t145 = extractvalue { i32, ptr } %t143, 0
  store i32 %t145, ptr %l73
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb41, label %ok.147
ok.147:
  store ptr %t144, ptr %l72
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l72, !tbaa !29
  store ptr %t148, ptr %l69, !tbaa !29
  br label %bb42
bb41:
  %t149 = load i32, ptr %l73, !tbaa !23
  %t150 = lshr i32 %t149, 16
  %t151 = and i32 %t149, 65535
  %t152 = icmp eq i32 %t150, 1
  %t153 = select i1 %t152, i32 1, i32 0
  %t154 = icmp eq i32 %t149, 0
  %t155 = shl i32 %t153, 16
  %t156 = or i32 %t155, %t151
  %t157 = select i1 %t154, i32 0, i32 %t156
  %t159 = insertvalue { i32, ptr } zeroinitializer, i32 %t157, 0
  store { i32, ptr } %t159, ptr %rv
  br label %ret
bb42:
  %t160 = load ptr, ptr %l69, !tbaa !29
  store ptr %t160, ptr %l10, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t163 = load ptr, ptr %l10, !tbaa !29
  %t165 = getelementptr %"compiler/ast:Sig", ptr %t163, i32 0, i32 2
  %t166 = load i1, ptr %t165, !tbaa !21
  %t167 = load ptr, ptr %l10, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Sig", ptr %t167, i32 0, i32 3
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t171 = load i1, ptr %l6, !tbaa !21
  %t177 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t161, { i64, ptr } %t162, i1 %t166, { i64, ptr } %t170, i1 %t171)
  store %"compiler/ast:Sig" %t177, ptr %l82
  br label %bb43
bb43:
  %t178 = load %"compiler/ast:Sig", ptr %l82
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:Sig" %t178, ptr %t179
  %t181 = insertvalue { i32, ptr } zeroinitializer, ptr %t179, 1
  store { i32, ptr } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i32
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 8)
  store i1 %t4, ptr %l3
  br label %bb2
bb2:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l6
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l13 = alloca i1
  %l16 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 16
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb12
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = sub i64 %t17, 1
  %t22 = icmp slt i64 %t8, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i64 %t31
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l13, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb3
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i32
  %l33 = alloca i32
  %l38 = alloca %"compiler/token:Token"
  %l40 = alloca i1
  %l46 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 39 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 37 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1
  %t19 = trunc i64 1 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t29, ptr %l18
  br label %bb12
bb12:
  %t30 = load i32, ptr %l18
  %t32 = trunc i64 56 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t35, i64 %t38)
  store i32 %t41, ptr %l25
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t42 = load i32, ptr %l25
  %t44 = trunc i64 1 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l21, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = add i64 %t50, 2
  store i64 %t52, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb11
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l33
  br label %bb22
bb22:
  %t59 = load i32, ptr %l33
  store i32 %t59, ptr %l3
  %t60 = load i32, ptr %l3
  %t62 = trunc i64 81 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/token:Token" %t69, ptr %l38
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t70 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t71 = load %"compiler/token:Token", ptr %l38
  %t73 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t71, i8 %t70)
  store i1 %t73, ptr %l40
  br label %bb26
bb26:
  %t74 = load i1, ptr %l40, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %rv
  br label %ret
bb27:
  %t77 = load i32, ptr %l3
  %t79 = trunc i64 77 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l46
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 18
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 6
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t10, i64 %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l8 = alloca i32
  %l18 = alloca i32
  %l25 = alloca i32
  %l30 = alloca i1
  %l37 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i32
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  store i32 0, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 11
  store i1 false, ptr %t7, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l8
  store i32 %t11, ptr %l2
  %t12 = load i32, ptr %l2
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load i32, ptr %l2
  %t19 = trunc i64 92 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = trunc i64 %t29 to i32
  %t34 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t25, i32 %t31)
  store i32 %t34, ptr %l18
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t35 = load i32, ptr %l18, !tbaa !23
  store i32 %t35, ptr %l3, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 6
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l25
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb40
bb13:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 93 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb15:
  %t55 = load i32, ptr %l2
  %t57 = trunc i64 88 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 90 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l1, !tbaa !24
  br label %bb37
bb20:
  %t70 = load i32, ptr %l2
  %t72 = trunc i64 89 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb23
bb22:
  %t75 = load i32, ptr %l2
  %t77 = trunc i64 91 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t80 = load i1, ptr %l37, !tbaa !21
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb26, label %bb27
bb25:
  %t85 = load i32, ptr %l2
  %t87 = trunc i64 8 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb29, label %bb30
bb26:
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = sub i64 %t90, 1
  store i64 %t92, ptr %l1, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb36
bb29:
  %t94 = load i64, ptr %l1, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t99)
  store i32 %t101, ptr %l50
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l52
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s1)
  br label %bb40
bb40:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 6
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t11)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 6
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 6
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t27)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %a0, %"compiler/token:Token" %a1) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/token:Token" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Source", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t8 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l8, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb3:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/token:Token", ptr %t18, i64 %t16
  %t20 = load %"compiler/token:Token", ptr %t19
  store %"compiler/token:Token" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, [3 x i64] }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %t39 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 19
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/token:Token", ptr %t19, i64 %a1
  %t21 = load %"compiler/token:Token", ptr %t20
  store %"compiler/token:Token" %t21, ptr %l2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 4
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/parse:Parser", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 0
  store i64 3, ptr %t40
  %t42 = insertvalue { i64, i64, i64 } undef, i64 %t30, 0
  %t44 = insertvalue { i64, i64, i64 } %t42, i64 %t34, 1
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t38, 2
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  store { i64, i64, i64 } %t46, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t39
  store { i64, [3 x i64] } %t48, ptr %l19
  %t49 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %s0, i64 %t49)
  store %"compiler/msgs:Msg" %t51, ptr %l21
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l12, !tbaa !29
  %t53 = load { i64, [3 x i64] }, ptr %l19
  %t54 = load %"compiler/msgs:Msg", ptr %l21
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s0, ptr %t52, { i64, [3 x i64] } %t53, %"compiler/msgs:Msg" %t54)
  store i64 %t55, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/ast:TopBranch"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 92)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l10
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l10, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l6, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 34
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l17
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t35)
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t37, i32 93)
  store i1 %t40, ptr %l21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 0)
  store i1 %t45, ptr %l25
  br label %bb11
bb11:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t48)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb6
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t53)
  br label %bb19
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t55, i32 93)
  %t59 = extractvalue { i32, i32 } %t58, 1
  %t60 = extractvalue { i32, i32 } %t58, 0
  store i32 %t60, ptr %l33
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb21, label %ok.62
ok.62:
  store i32 %t59, ptr %l32
  br label %bb20
bb20:
  %t63 = load i32, ptr %l32, !tbaa !23
  store i32 %t63, ptr %l29, !tbaa !23
  br label %bb22
bb21:
  %t64 = load i32, ptr %l33, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t75, i32 %t76)
  store %"compiler/source:Span" %t79, ptr %l37
  br label %bb23
bb23:
  %t80 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t80, ptr %l4
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 34
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l41
  br label %bb24
bb24:
  %t88 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t89 = load %"compiler/source:Span", ptr %l4
  %t91 = load i64, ptr %l2, !tbaa !24
  %t95 = call %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t89, { i64, ptr } %t88, i64 %t91)
  store %"compiler/ast:TopBranch" %t95, ptr %l45
  br label %bb25
bb25:
  %t96 = load %"compiler/ast:TopBranch", ptr %l45
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopBranch" %t96, ptr %t97
  %t99 = insertvalue { i32, ptr } zeroinitializer, ptr %t97, 1
  store { i32, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %lp16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i1
  %l27 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i32
  %l54 = alloca %"compiler/source:Span"
  %l62 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca i32
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l109 = alloca i32
  %l111 = alloca i1
  %l113 = alloca i32
  %l114 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca i32
  %l122 = alloca %"compiler/source:Span"
  %l126 = alloca %"compiler/source:Span"
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca i32
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l154 = alloca ptr
  %l155 = alloca i1
  %l162 = alloca i1
  %l166 = alloca %"compiler/source:Span"
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i32
  %l178 = alloca %"compiler/source:Span"
  %l180 = alloca i32
  %l194 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l197 = alloca i32
  %l204 = alloca i1
  %l214 = alloca %"compiler/source:Span"
  %l223 = alloca ptr
  %l226 = alloca ptr
  %l227 = alloca i32
  %l231 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca i32
  %l239 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca i32
  %l249 = alloca %"compiler/source:Span"
  %l251 = alloca i32
  %rv = alloca { i32, ptr }
  %t77 = alloca { i64, [5 x i64] }, align 8
  %t134 = alloca { i64, [5 x i64] }, align 8
  %t201 = alloca { i64, [5 x i64] }, align 8
  %t298 = alloca { i64, [5 x i64] }, align 8
  %t369 = alloca { i64, [5 x i64] }, align 8
  %t420 = alloca { i64, [5 x i64] }, align 8
  %t487 = alloca { i64, [5 x i64] }, align 8
  %t568 = alloca { i64, [5 x i64] }, align 8
  %t699 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 12)
  store i1 %t4, ptr %l25
  br label %bb1
bb1:
  %t5 = load i1, ptr %l25, !tbaa !21
  store i1 %t5, ptr %l1, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l27
  br label %bb2
bb2:
  %t9 = load i32, ptr %l27, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 18
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = add i64 %t13, 2
  %t16 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 6
  %t25 = load i64, ptr %t24, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t21, i64 %t25)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 20
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 20
  store i64 -1, ptr %t35, !tbaa !24
  %t36 = load i1, ptr %l1, !tbaa !21
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t40, i32 15)
  store i1 %t43, ptr %l44
  br label %bb9
bb8:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb10
bb9:
  %t44 = load i1, ptr %l44, !tbaa !21
  store i1 %t44, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l41, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %t46, i1 true)
  %t49 = extractvalue { i32, ptr } %t48, 1
  %t50 = extractvalue { i32, ptr } %t48, 0
  store i32 %t50, ptr %l48
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb14, label %ok.52
ok.52:
  store ptr %t49, ptr %l47
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t53 = load ptr, ptr %l47, !tbaa !29
  store ptr %t53, ptr %l45, !tbaa !29
  br label %bb15
bb14:
  %t54 = load i32, ptr %l48, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 20
  store i64 %t64, ptr %t67, !tbaa !24
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t62, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l45, !tbaa !29
  store ptr %t70, ptr %l4, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t71, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l54
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 0
  store i64 17, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l54
  %t80 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t79, 0
  %t82 = insertvalue { %"compiler/source:Span", ptr } %t80, ptr %t76, 1
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t82, ptr %t83
  %t84 = load { i64, [5 x i64] }, ptr %t77
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t84, ptr %t86
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 20
  store i64 %t88, ptr %t91, !tbaa !24
  %t93 = insertvalue { i32, ptr } zeroinitializer, ptr %t86, 1
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb17:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t97 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t94, i32 71)
  store i1 %t97, ptr %l62
  br label %bb18
bb18:
  %t98 = load i1, ptr %l62, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb22
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t102 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t99, i32 72)
  store i1 %t102, ptr %l66
  br label %bb21
bb21:
  %t103 = load i1, ptr %l66, !tbaa !21
  store i1 %t103, ptr %l63, !tbaa !21
  br label %bb22
bb22:
  %t104 = load i1, ptr %l63, !tbaa !21
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t105)
  %t108 = extractvalue { i32, ptr } %t107, 1
  %t109 = extractvalue { i32, ptr } %t107, 0
  store i32 %t109, ptr %l70
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb26, label %ok.111
ok.111:
  store ptr %t108, ptr %l69
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t112 = load ptr, ptr %l69, !tbaa !29
  store ptr %t112, ptr %l67, !tbaa !29
  br label %bb27
bb26:
  %t113 = load i32, ptr %l70, !tbaa !23
  %t114 = lshr i32 %t113, 16
  %t115 = and i32 %t113, 65535
  %t116 = icmp eq i32 %t114, 1
  %t117 = select i1 %t116, i32 1, i32 0
  %t118 = icmp eq i32 %t113, 0
  %t119 = shl i32 %t117, 16
  %t120 = or i32 %t119, %t115
  %t121 = select i1 %t118, i32 0, i32 %t120
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l3, !tbaa !24
  %t126 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 20
  store i64 %t123, ptr %t126, !tbaa !24
  %t128 = insertvalue { i32, ptr } zeroinitializer, i32 %t121, 0
  store { i32, ptr } %t128, ptr %rv
  br label %ret
bb27:
  %t129 = load ptr, ptr %l67, !tbaa !29
  store ptr %t129, ptr %l5, !tbaa !29
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t130)
  store %"compiler/source:Span" %t132, ptr %l75
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t136 = load %"compiler/source:Span", ptr %l75
  %t137 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t136, 0
  %t139 = insertvalue { %"compiler/source:Span", ptr } %t137, ptr %t133, 1
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t139, ptr %t140
  %t141 = load { i64, [5 x i64] }, ptr %t134
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t142, ptr %lp6
  %t144 = load ptr, ptr %lp6
  store { i64, [5 x i64] } %t141, ptr %t144
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t145, i1 false)
  %t148 = extractvalue { i32, { i64, ptr } } %t147, 1
  %t149 = extractvalue { i32, { i64, ptr } } %t147, 0
  store i32 %t149, ptr %l81
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb30, label %ok.151
ok.151:
  store { i64, ptr } %t148, ptr %l80
  br label %bb29
bb29:
  %t152 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t152, ptr %l78, !tbaa !27
  br label %bb31
bb30:
  %t153 = load i32, ptr %l81, !tbaa !23
  %t154 = lshr i32 %t153, 16
  %t155 = and i32 %t153, 65535
  %t156 = icmp eq i32 %t154, 1
  %t157 = select i1 %t156, i32 1, i32 0
  %t158 = icmp eq i32 %t153, 0
  %t159 = shl i32 %t157, 16
  %t160 = or i32 %t159, %t155
  %t161 = select i1 %t158, i32 0, i32 %t160
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 20
  store i64 %t163, ptr %t166, !tbaa !24
  %t168 = insertvalue { i32, ptr } zeroinitializer, i32 %t161, 0
  store { i32, ptr } %t168, ptr %rv
  br label %ret
bb31:
  %t169 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t169, ptr %l7, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l2, !tbaa !23
  %t174 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t170, i32 %t171)
  store %"compiler/source:Span" %t174, ptr %l87
  br label %bb32
bb32:
  %t175 = load %"compiler/source:Span", ptr %l87
  store %"compiler/source:Span" %t175, ptr %l8
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t176)
  store i32 %t178, ptr %l89
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb34, label %ok.180
ok.180:
  br label %bb33
bb33:
  br label %bb35
bb34:
  %t181 = load i32, ptr %l89, !tbaa !23
  %t182 = lshr i32 %t181, 16
  %t183 = and i32 %t181, 65535
  %t184 = icmp eq i32 %t182, 1
  %t185 = select i1 %t184, i32 1, i32 0
  %t186 = icmp eq i32 %t181, 0
  %t187 = shl i32 %t185, 16
  %t188 = or i32 %t187, %t183
  %t189 = select i1 %t186, i32 0, i32 %t188
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i64, ptr %l3, !tbaa !24
  %t194 = getelementptr %"compiler/parse:Parser", ptr %t190, i32 0, i32 20
  store i64 %t191, ptr %t194, !tbaa !24
  %t196 = insertvalue { i32, ptr } zeroinitializer, i32 %t189, 0
  store { i32, ptr } %t196, ptr %rv
  br label %ret
bb35:
  %t197 = load %"compiler/source:Span", ptr %l8
  %t198 = load ptr, ptr %lp6
  %t199 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t200 = load i1, ptr %l1, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 0
  store i64 4, ptr %t202
  %t204 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } undef, %"compiler/source:Span" %t197, 0
  %t206 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t204, ptr %t198, 1
  %t208 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t206, { i64, ptr } %t199, 2
  %t210 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t208, i1 %t200, 3
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t210, ptr %t211
  %t212 = load { i64, [5 x i64] }, ptr %t201
  %t214 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t212, ptr %t214
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l3, !tbaa !24
  %t219 = getelementptr %"compiler/parse:Parser", ptr %t215, i32 0, i32 20
  store i64 %t216, ptr %t219, !tbaa !24
  %t221 = insertvalue { i32, ptr } zeroinitializer, ptr %t214, 1
  store { i32, ptr } %t221, ptr %rv
  br label %ret
bb36:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t222)
  %t225 = extractvalue { i32, ptr } %t224, 1
  %t226 = extractvalue { i32, ptr } %t224, 0
  store i32 %t226, ptr %l104
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb38, label %ok.228
ok.228:
  store ptr %t225, ptr %l103
  br label %bb37
bb37:
  %t229 = load ptr, ptr %l103, !tbaa !29
  store ptr %t229, ptr %l101, !tbaa !29
  br label %bb39
bb38:
  %t230 = load i32, ptr %l104, !tbaa !23
  %t231 = lshr i32 %t230, 16
  %t232 = and i32 %t230, 65535
  %t233 = icmp eq i32 %t231, 1
  %t234 = select i1 %t233, i32 1, i32 0
  %t235 = icmp eq i32 %t230, 0
  %t236 = shl i32 %t234, 16
  %t237 = or i32 %t236, %t232
  %t238 = select i1 %t235, i32 0, i32 %t237
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i64, ptr %l3, !tbaa !24
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t239, i32 0, i32 20
  store i64 %t240, ptr %t243, !tbaa !24
  %t245 = insertvalue { i32, ptr } zeroinitializer, i32 %t238, 0
  store { i32, ptr } %t245, ptr %rv
  br label %ret
bb39:
  %t246 = load ptr, ptr %l101, !tbaa !29
  store ptr %t246, ptr %l9, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t247)
  store i32 %t249, ptr %l109
  br label %bb40
bb40:
  %t250 = load i32, ptr %l109
  store i32 %t250, ptr %l10
  %t251 = load i32, ptr %l10
  %t253 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t251)
  store i1 %t253, ptr %l111
  br label %bb41
bb41:
  %t254 = load i1, ptr %l111, !tbaa !21
  br i1 %t254, label %bb42, label %bb43
bb42:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t255)
  store i32 %t257, ptr %l113
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t258)
  %t261 = extractvalue { i32, ptr } %t260, 1
  %t262 = extractvalue { i32, ptr } %t260, 0
  store i32 %t262, ptr %l117
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb46, label %ok.264
ok.264:
  store ptr %t261, ptr %l116
  br label %bb45
bb45:
  %t265 = load ptr, ptr %l116, !tbaa !29
  store ptr %t265, ptr %l114, !tbaa !29
  br label %bb47
bb46:
  %t266 = load i32, ptr %l117, !tbaa !23
  %t267 = lshr i32 %t266, 16
  %t268 = and i32 %t266, 65535
  %t269 = icmp eq i32 %t267, 1
  %t270 = select i1 %t269, i32 1, i32 0
  %t271 = icmp eq i32 %t266, 0
  %t272 = shl i32 %t270, 16
  %t273 = or i32 %t272, %t268
  %t274 = select i1 %t271, i32 0, i32 %t273
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l3, !tbaa !24
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t275, i32 0, i32 20
  store i64 %t276, ptr %t279, !tbaa !24
  %t281 = insertvalue { i32, ptr } zeroinitializer, i32 %t274, 0
  store { i32, ptr } %t281, ptr %rv
  br label %ret
bb47:
  %t282 = load ptr, ptr %l114, !tbaa !29
  store ptr %t282, ptr %l11, !tbaa !29
  %t283 = load ptr, ptr %l9, !tbaa !29
  %t285 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t283)
  store %"compiler/source:Span" %t285, ptr %l122
  br label %bb48
bb48:
  %t286 = getelementptr %"compiler/source:Span", ptr %l122, i32 0, i32 0
  %t287 = load i32, ptr %t286, !tbaa !23
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/parse:Parser", ptr %t288, i32 0, i32 10
  %t291 = load i32, ptr %t290, !tbaa !23
  %t294 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t287, i32 %t291)
  store %"compiler/source:Span" %t294, ptr %l126
  br label %bb49
bb49:
  %t295 = load i32, ptr %l10
  %t296 = load ptr, ptr %l9, !tbaa !29
  %t297 = load ptr, ptr %l11, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 0
  store i64 3, ptr %t299
  %t300 = load %"compiler/source:Span", ptr %l126
  %t301 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t300, 0
  %t303 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t301, i32 %t295, 1
  %t305 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t303, ptr %t296, 2
  %t307 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t305, ptr %t297, 3
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t307, ptr %t308
  %t309 = load { i64, [5 x i64] }, ptr %t298
  %t310 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t310, ptr %lp12
  %t312 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t309, ptr %t312
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t313, i1 false)
  %t316 = extractvalue { i32, { i64, ptr } } %t315, 1
  %t317 = extractvalue { i32, { i64, ptr } } %t315, 0
  store i32 %t317, ptr %l134
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb51, label %ok.319
ok.319:
  store { i64, ptr } %t316, ptr %l133
  br label %bb50
bb50:
  %t320 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t320, ptr %l131, !tbaa !27
  br label %bb52
bb51:
  %t321 = load i32, ptr %l134, !tbaa !23
  %t322 = lshr i32 %t321, 16
  %t323 = and i32 %t321, 65535
  %t324 = icmp eq i32 %t322, 1
  %t325 = select i1 %t324, i32 1, i32 0
  %t326 = icmp eq i32 %t321, 0
  %t327 = shl i32 %t325, 16
  %t328 = or i32 %t327, %t323
  %t329 = select i1 %t326, i32 0, i32 %t328
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l3, !tbaa !24
  %t334 = getelementptr %"compiler/parse:Parser", ptr %t330, i32 0, i32 20
  store i64 %t331, ptr %t334, !tbaa !24
  %t336 = insertvalue { i32, ptr } zeroinitializer, i32 %t329, 0
  store { i32, ptr } %t336, ptr %rv
  br label %ret
bb52:
  %t337 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t337, ptr %l13, !tbaa !27
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t338, i32 %t339)
  store %"compiler/source:Span" %t342, ptr %l140
  br label %bb53
bb53:
  %t343 = load %"compiler/source:Span", ptr %l140
  store %"compiler/source:Span" %t343, ptr %l14
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t344)
  store i32 %t346, ptr %l142
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb55, label %ok.348
ok.348:
  br label %bb54
bb54:
  br label %bb56
bb55:
  %t349 = load i32, ptr %l142, !tbaa !23
  %t350 = lshr i32 %t349, 16
  %t351 = and i32 %t349, 65535
  %t352 = icmp eq i32 %t350, 1
  %t353 = select i1 %t352, i32 1, i32 0
  %t354 = icmp eq i32 %t349, 0
  %t355 = shl i32 %t353, 16
  %t356 = or i32 %t355, %t351
  %t357 = select i1 %t354, i32 0, i32 %t356
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i64, ptr %l3, !tbaa !24
  %t362 = getelementptr %"compiler/parse:Parser", ptr %t358, i32 0, i32 20
  store i64 %t359, ptr %t362, !tbaa !24
  %t364 = insertvalue { i32, ptr } zeroinitializer, i32 %t357, 0
  store { i32, ptr } %t364, ptr %rv
  br label %ret
bb56:
  %t365 = load %"compiler/source:Span", ptr %l14
  %t366 = load ptr, ptr %lp12
  %t367 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t368 = load i1, ptr %l1, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t369, i32 0, i32 0
  store i64 4, ptr %t370
  %t372 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } undef, %"compiler/source:Span" %t365, 0
  %t374 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t372, ptr %t366, 1
  %t376 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t374, { i64, ptr } %t367, 2
  %t378 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t376, i1 %t368, 3
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t378, ptr %t379
  %t380 = load { i64, [5 x i64] }, ptr %t369
  %t382 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t380, ptr %t382
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l3, !tbaa !24
  %t387 = getelementptr %"compiler/parse:Parser", ptr %t383, i32 0, i32 20
  store i64 %t384, ptr %t387, !tbaa !24
  %t389 = insertvalue { i32, ptr } zeroinitializer, ptr %t382, 1
  store { i32, ptr } %t389, ptr %rv
  br label %ret
bb57:
  %t390 = load ptr, ptr %l9, !tbaa !29
  store ptr %t390, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t391 = load ptr, ptr %l154, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %bb58, label %bb59
bb58:
  %t394 = load ptr, ptr %l154, !tbaa !29
  %t395 = load i64, ptr %t394
  %t397 = icmp eq i64 %t395, 4
  store i1 %t397, ptr %l155, !tbaa !21
  br label %bb59
bb59:
  %t398 = load i1, ptr %l155, !tbaa !21
  br i1 %t398, label %bb60, label %bb61
bb60:
  %t399 = load ptr, ptr %l9, !tbaa !29
  %t401 = getelementptr { i64, [5 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t401, i32 0, i32 1
  %t403 = load i32, ptr %t402
  store i32 %t403, ptr %l15
  br label %bb62
bb61:
  br label %bb77
bb62:
  %t405 = load i32, ptr %l15
  %t407 = trunc i64 71 to i32
  %t408 = icmp eq i32 %t405, %t407
  br i1 %t408, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb65
bb64:
  %t410 = load i32, ptr %l15
  %t412 = trunc i64 72 to i32
  %t413 = icmp eq i32 %t410, %t412
  store i1 %t413, ptr %l162, !tbaa !21
  br label %bb65
bb65:
  %t415 = load i1, ptr %l162, !tbaa !21
  br i1 %t415, label %bb66, label %bb67
bb66:
  %t416 = load ptr, ptr %l9, !tbaa !29
  %t418 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t416)
  store %"compiler/source:Span" %t418, ptr %l166
  br label %bb68
bb67:
  br label %bb76
bb68:
  %t419 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 0
  store i64 0, ptr %t421
  %t422 = load %"compiler/source:Span", ptr %l166
  %t423 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t422, 0
  %t425 = insertvalue { %"compiler/source:Span", ptr } %t423, ptr %t419, 1
  %t426 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t425, ptr %t426
  %t427 = load { i64, [5 x i64] }, ptr %t420
  %t428 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t428, ptr %lp16
  %t430 = load ptr, ptr %lp16
  store { i64, [5 x i64] } %t427, ptr %t430
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t431, i1 false)
  %t434 = extractvalue { i32, { i64, ptr } } %t433, 1
  %t435 = extractvalue { i32, { i64, ptr } } %t433, 0
  store i32 %t435, ptr %l172
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb70, label %ok.437
ok.437:
  store { i64, ptr } %t434, ptr %l171
  br label %bb69
bb69:
  %t438 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t438, ptr %l169, !tbaa !27
  br label %bb71
bb70:
  %t439 = load i32, ptr %l172, !tbaa !23
  %t440 = lshr i32 %t439, 16
  %t441 = and i32 %t439, 65535
  %t442 = icmp eq i32 %t440, 1
  %t443 = select i1 %t442, i32 1, i32 0
  %t444 = icmp eq i32 %t439, 0
  %t445 = shl i32 %t443, 16
  %t446 = or i32 %t445, %t441
  %t447 = select i1 %t444, i32 0, i32 %t446
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i64, ptr %l3, !tbaa !24
  %t452 = getelementptr %"compiler/parse:Parser", ptr %t448, i32 0, i32 20
  store i64 %t449, ptr %t452, !tbaa !24
  %t454 = insertvalue { i32, ptr } zeroinitializer, i32 %t447, 0
  store { i32, ptr } %t454, ptr %rv
  br label %ret
bb71:
  %t455 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t455, ptr %l17, !tbaa !27
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l2, !tbaa !23
  %t460 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t456, i32 %t457)
  store %"compiler/source:Span" %t460, ptr %l178
  br label %bb72
bb72:
  %t461 = load %"compiler/source:Span", ptr %l178
  store %"compiler/source:Span" %t461, ptr %l18
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t462)
  store i32 %t464, ptr %l180
  %t465 = icmp ne i32 %t464, 0
  br i1 %t465, label %bb74, label %ok.466
ok.466:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t467 = load i32, ptr %l180, !tbaa !23
  %t468 = lshr i32 %t467, 16
  %t469 = and i32 %t467, 65535
  %t470 = icmp eq i32 %t468, 1
  %t471 = select i1 %t470, i32 1, i32 0
  %t472 = icmp eq i32 %t467, 0
  %t473 = shl i32 %t471, 16
  %t474 = or i32 %t473, %t469
  %t475 = select i1 %t472, i32 0, i32 %t474
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load i64, ptr %l3, !tbaa !24
  %t480 = getelementptr %"compiler/parse:Parser", ptr %t476, i32 0, i32 20
  store i64 %t477, ptr %t480, !tbaa !24
  %t482 = insertvalue { i32, ptr } zeroinitializer, i32 %t475, 0
  store { i32, ptr } %t482, ptr %rv
  br label %ret
bb75:
  %t483 = load %"compiler/source:Span", ptr %l18
  %t484 = load ptr, ptr %lp16
  %t485 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t486 = load i1, ptr %l1, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t487
  %t488 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 0
  store i64 4, ptr %t488
  %t490 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } undef, %"compiler/source:Span" %t483, 0
  %t492 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t490, ptr %t484, 1
  %t494 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t492, { i64, ptr } %t485, 2
  %t496 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t494, i1 %t486, 3
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t496, ptr %t497
  %t498 = load { i64, [5 x i64] }, ptr %t487
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t498, ptr %t500
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i64, ptr %l3, !tbaa !24
  %t505 = getelementptr %"compiler/parse:Parser", ptr %t501, i32 0, i32 20
  store i64 %t502, ptr %t505, !tbaa !24
  %t507 = insertvalue { i32, ptr } zeroinitializer, ptr %t500, 1
  store { i32, ptr } %t507, ptr %rv
  br label %ret
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/parse:Parser", ptr %t508, i32 0, i32 20
  %t511 = load i64, ptr %t510, !tbaa !24
  store i64 %t511, ptr %l19, !tbaa !24
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t513, i1 false)
  %t516 = extractvalue { i32, { i64, ptr } } %t515, 1
  %t517 = extractvalue { i32, { i64, ptr } } %t515, 0
  store i32 %t517, ptr %l197
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb80, label %ok.519
ok.519:
  store { i64, ptr } %t516, ptr %l196
  br label %bb79
bb79:
  %t520 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t520, ptr %l194, !tbaa !27
  br label %bb81
bb80:
  %t521 = load i32, ptr %l197, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i64, ptr %l3, !tbaa !24
  %t534 = getelementptr %"compiler/parse:Parser", ptr %t530, i32 0, i32 20
  store i64 %t531, ptr %t534, !tbaa !24
  %t536 = insertvalue { i32, ptr } zeroinitializer, i32 %t529, 0
  store { i32, ptr } %t536, ptr %rv
  br label %ret
bb81:
  %t537 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t537, ptr %l20, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t542 = icmp eq i64 %t540, 0
  br i1 %t542, label %bb82, label %bb83
bb82:
  %t544 = load i64, ptr %l19, !tbaa !24
  %t546 = icmp sge i64 %t544, 0
  store i1 %t546, ptr %l204, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb84
bb84:
  %t548 = load i1, ptr %l204, !tbaa !21
  br i1 %t548, label %bb85, label %bb86
bb85:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t549, i64 %t550)
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load i64, ptr %l3, !tbaa !24
  %t557 = getelementptr %"compiler/parse:Parser", ptr %t553, i32 0, i32 20
  store i64 %t554, ptr %t557, !tbaa !24
  %t559 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t559, ptr %rv
  br label %ret
bb88:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load i32, ptr %l2, !tbaa !23
  %t564 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t560, i32 %t561)
  store %"compiler/source:Span" %t564, ptr %l214
  br label %bb89
bb89:
  %t565 = load ptr, ptr %l9, !tbaa !29
  %t566 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t567 = load i1, ptr %l1, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t568
  %t569 = getelementptr { i64, [5 x i64] }, ptr %t568, i32 0, i32 0
  store i64 22, ptr %t569
  %t570 = load %"compiler/source:Span", ptr %l214
  %t571 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } undef, %"compiler/source:Span" %t570, 0
  %t573 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t571, ptr %t565, 1
  %t575 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t573, { i64, ptr } %t566, 2
  %t577 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t575, i1 %t567, 3
  %t578 = getelementptr { i64, [5 x i64] }, ptr %t568, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr }, i1 } %t577, ptr %t578
  %t579 = load { i64, [5 x i64] }, ptr %t568
  %t581 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t579, ptr %t581
  store ptr %t581, ptr %l21, !tbaa !29
  %t583 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t583, 0
  %t587 = icmp eq i64 %t585, 0
  br i1 %t587, label %bb90, label %bb91
bb90:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load ptr, ptr %l21, !tbaa !29
  %t593 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %t589, ptr %t590)
  %t594 = extractvalue { i32, ptr } %t593, 1
  %t595 = extractvalue { i32, ptr } %t593, 0
  store i32 %t595, ptr %l227
  %t596 = icmp ne i32 %t595, 0
  br i1 %t596, label %bb93, label %ok.597
ok.597:
  store ptr %t594, ptr %l226
  br label %bb92
bb91:
  br label %bb101
bb92:
  %t598 = load ptr, ptr %l226, !tbaa !29
  store ptr %t598, ptr %l223, !tbaa !29
  br label %bb94
bb93:
  %t599 = load i32, ptr %l227, !tbaa !23
  %t600 = lshr i32 %t599, 16
  %t601 = and i32 %t599, 65535
  %t602 = icmp eq i32 %t600, 1
  %t603 = select i1 %t602, i32 1, i32 0
  %t604 = icmp eq i32 %t599, 0
  %t605 = shl i32 %t603, 16
  %t606 = or i32 %t605, %t601
  %t607 = select i1 %t604, i32 0, i32 %t606
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i64, ptr %l3, !tbaa !24
  %t612 = getelementptr %"compiler/parse:Parser", ptr %t608, i32 0, i32 20
  store i64 %t609, ptr %t612, !tbaa !24
  %t614 = insertvalue { i32, ptr } zeroinitializer, i32 %t607, 0
  store { i32, ptr } %t614, ptr %rv
  br label %ret
bb94:
  %t615 = load ptr, ptr %l223, !tbaa !29
  store ptr %t615, ptr %l21, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l21, !tbaa !29
  %t620 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %t616, ptr %t617, i64 1)
  %t621 = extractvalue { i32, ptr } %t620, 1
  %t622 = extractvalue { i32, ptr } %t620, 0
  store i32 %t622, ptr %l235
  %t623 = icmp ne i32 %t622, 0
  br i1 %t623, label %bb96, label %ok.624
ok.624:
  store ptr %t621, ptr %l234
  br label %bb95
bb95:
  %t625 = load ptr, ptr %l234, !tbaa !29
  store ptr %t625, ptr %l231, !tbaa !29
  br label %bb97
bb96:
  %t626 = load i32, ptr %l235, !tbaa !23
  %t627 = lshr i32 %t626, 16
  %t628 = and i32 %t626, 65535
  %t629 = icmp eq i32 %t627, 1
  %t630 = select i1 %t629, i32 1, i32 0
  %t631 = icmp eq i32 %t626, 0
  %t632 = shl i32 %t630, 16
  %t633 = or i32 %t632, %t628
  %t634 = select i1 %t631, i32 0, i32 %t633
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load i64, ptr %l3, !tbaa !24
  %t639 = getelementptr %"compiler/parse:Parser", ptr %t635, i32 0, i32 20
  store i64 %t636, ptr %t639, !tbaa !24
  %t641 = insertvalue { i32, ptr } zeroinitializer, i32 %t634, 0
  store { i32, ptr } %t641, ptr %rv
  br label %ret
bb97:
  %t642 = load ptr, ptr %l231, !tbaa !29
  store ptr %t642, ptr %l21, !tbaa !29
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load ptr, ptr %l21, !tbaa !29
  %t647 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %t643, ptr %t644)
  %t648 = extractvalue { i32, ptr } %t647, 1
  %t649 = extractvalue { i32, ptr } %t647, 0
  store i32 %t649, ptr %l243
  %t650 = icmp ne i32 %t649, 0
  br i1 %t650, label %bb99, label %ok.651
ok.651:
  store ptr %t648, ptr %l242
  br label %bb98
bb98:
  %t652 = load ptr, ptr %l242, !tbaa !29
  store ptr %t652, ptr %l239, !tbaa !29
  br label %bb100
bb99:
  %t653 = load i32, ptr %l243, !tbaa !23
  %t654 = lshr i32 %t653, 16
  %t655 = and i32 %t653, 65535
  %t656 = icmp eq i32 %t654, 1
  %t657 = select i1 %t656, i32 1, i32 0
  %t658 = icmp eq i32 %t653, 0
  %t659 = shl i32 %t657, 16
  %t660 = or i32 %t659, %t655
  %t661 = select i1 %t658, i32 0, i32 %t660
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load i64, ptr %l3, !tbaa !24
  %t666 = getelementptr %"compiler/parse:Parser", ptr %t662, i32 0, i32 20
  store i64 %t663, ptr %t666, !tbaa !24
  %t668 = insertvalue { i32, ptr } zeroinitializer, i32 %t661, 0
  store { i32, ptr } %t668, ptr %rv
  br label %ret
bb100:
  %t669 = load ptr, ptr %l239, !tbaa !29
  store ptr %t669, ptr %l21, !tbaa !29
  br label %bb101
bb101:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i32, ptr %l2, !tbaa !23
  %t674 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t670, i32 %t671)
  store %"compiler/source:Span" %t674, ptr %l249
  br label %bb102
bb102:
  %t675 = load %"compiler/source:Span", ptr %l249
  store %"compiler/source:Span" %t675, ptr %l22
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t678 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t676)
  store i32 %t678, ptr %l251
  %t679 = icmp ne i32 %t678, 0
  br i1 %t679, label %bb104, label %ok.680
ok.680:
  br label %bb103
bb103:
  br label %bb105
bb104:
  %t681 = load i32, ptr %l251, !tbaa !23
  %t682 = lshr i32 %t681, 16
  %t683 = and i32 %t681, 65535
  %t684 = icmp eq i32 %t682, 1
  %t685 = select i1 %t684, i32 1, i32 0
  %t686 = icmp eq i32 %t681, 0
  %t687 = shl i32 %t685, 16
  %t688 = or i32 %t687, %t683
  %t689 = select i1 %t686, i32 0, i32 %t688
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load i64, ptr %l3, !tbaa !24
  %t694 = getelementptr %"compiler/parse:Parser", ptr %t690, i32 0, i32 20
  store i64 %t691, ptr %t694, !tbaa !24
  %t696 = insertvalue { i32, ptr } zeroinitializer, i32 %t689, 0
  store { i32, ptr } %t696, ptr %rv
  br label %ret
bb105:
  %t697 = load %"compiler/source:Span", ptr %l22
  %t698 = load ptr, ptr %l21, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t699
  %t700 = getelementptr { i64, [5 x i64] }, ptr %t699, i32 0, i32 0
  store i64 0, ptr %t700
  %t702 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t697, 0
  %t704 = insertvalue { %"compiler/source:Span", ptr } %t702, ptr %t698, 1
  %t705 = getelementptr { i64, [5 x i64] }, ptr %t699, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t704, ptr %t705
  %t706 = load { i64, [5 x i64] }, ptr %t699
  %t708 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t706, ptr %t708
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load i64, ptr %l3, !tbaa !24
  %t713 = getelementptr %"compiler/parse:Parser", ptr %t709, i32 0, i32 20
  store i64 %t710, ptr %t713, !tbaa !24
  %t715 = insertvalue { i32, ptr } zeroinitializer, ptr %t708, 1
  store { i32, ptr } %t715, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l43 = alloca i32
  %l50 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 11
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 11
  store i1 true, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 16
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 17
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l3, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 16
  store i1 false, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 17
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 29
  %t45 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l19
  br label %bb4
bb4:
  %t46 = load i64, ptr %l19, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 29
  store ptr %t49, ptr %l21, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %t50)
  %t53 = extractvalue { i32, ptr } %t52, 1
  %t54 = extractvalue { i32, ptr } %t52, 0
  store i32 %t54, ptr %l25
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb7, label %ok.56
ok.56:
  store ptr %t53, ptr %l24
  br label %bb6
bb6:
  %t57 = load ptr, ptr %l24, !tbaa !29
  store ptr %t57, ptr %l22, !tbaa !29
  br label %bb8
bb7:
  %t58 = load i32, ptr %l25, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s1)
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i1, ptr %l3, !tbaa !21
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 17
  store i1 %t68, ptr %t71, !tbaa !21
  %t73 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t66, 0
  store { i32, { i64, ptr } } %t73, ptr %rv
  br label %ret
bb8:
  %t74 = load ptr, ptr %l21, !tbaa !29
  %t75 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v0, ptr %t74, ptr %t75)
  br label %bb9
bb9:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t79 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t76, i32 79)
  %t80 = extractvalue { i32, i1 } %t79, 1
  %t81 = extractvalue { i32, i1 } %t79, 0
  store i32 %t81, ptr %l33
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb11, label %ok.83
ok.83:
  store i1 %t80, ptr %l32
  br label %bb10
bb10:
  %t84 = load i1, ptr %l32, !tbaa !21
  store i1 %t84, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t85 = load i32, ptr %l33, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 1, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  call void @__olang_scope_close(ptr %s1)
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i1, ptr %l3, !tbaa !21
  %t98 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 17
  store i1 %t95, ptr %t98, !tbaa !21
  %t100 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t93, 0
  store { i32, { i64, ptr } } %t100, ptr %rv
  br label %ret
bb12:
  %t101 = load i1, ptr %l29, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb5
bb17:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i1, ptr %l2, !tbaa !21
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 16
  store i1 %t105, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i1, ptr %l1, !tbaa !21
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t109, i32 0, i32 11
  store i1 %t110, ptr %t113, !tbaa !21
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t114)
  store i32 %t116, ptr %l43
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb19, label %ok.118
ok.118:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t119 = load i32, ptr %l43, !tbaa !23
  %t120 = lshr i32 %t119, 16
  %t121 = and i32 %t119, 65535
  %t122 = icmp eq i32 %t120, 1
  %t123 = select i1 %t122, i32 1, i32 0
  %t124 = icmp eq i32 %t119, 0
  %t125 = shl i32 %t123, 16
  %t126 = or i32 %t125, %t121
  %t127 = select i1 %t124, i32 0, i32 %t126
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i1, ptr %l3, !tbaa !21
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t128, i32 0, i32 17
  store i1 %t129, ptr %t132, !tbaa !21
  %t134 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t127, 0
  store { i32, { i64, ptr } } %t134, ptr %rv
  br label %ret
bb20:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t135, i32 0, i32 29
  %t138 = load i64, ptr %l4, !tbaa !24
  %t141 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t137, i64 %t138)
  store { i64, ptr } %t141, ptr %l50
  br label %bb21
bb21:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i1, ptr %l3, !tbaa !21
  %t146 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 17
  store i1 %t143, ptr %t146, !tbaa !21
  %t147 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t148 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t147, 1
  store { i32, { i64, ptr } } %t148, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l26 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l63 = alloca i1
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i32
  %l77 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l91 = alloca %"compiler/source:Span"
  %l99 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca i32
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i32
  %l127 = alloca i1
  %l129 = alloca i1
  %l131 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i32
  %l136 = alloca i32
  %l137 = alloca %"compiler/msgs:Msg"
  %l139 = alloca i32
  %l142 = alloca i32
  %l143 = alloca i32
  %l147 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i32
  %l153 = alloca %"compiler/msgs:Msg"
  %l159 = alloca i32
  %l162 = alloca i32
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t43 = alloca { i64, [5 x i64] }, align 8
  %t100 = alloca { i64, [5 x i64] }, align 8
  %t230 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i32, ptr %l12, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load i32, ptr %l14
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 37 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l18
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t17, i1 false, i1 true)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l22
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23
ok.23:
  store ptr %t20, ptr %l21
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l21, !tbaa !29
  store ptr %t24, ptr %l19, !tbaa !29
  br label %bb9
bb8:
  %t25 = load i32, ptr %l22, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  %t35 = insertvalue { i32, ptr } zeroinitializer, i32 %t33, 0
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %l3, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t37, i32 %t38)
  store %"compiler/source:Span" %t41, ptr %l26
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 0
  store i64 1, ptr %t44
  %t45 = load %"compiler/source:Span", ptr %l26
  %t46 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t45, 0
  %t48 = insertvalue { %"compiler/source:Span", ptr } %t46, ptr %t42, 1
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t48, ptr %t49
  %t50 = load { i64, [5 x i64] }, ptr %t43
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t50, ptr %t52
  %t54 = insertvalue { i32, ptr } zeroinitializer, ptr %t52, 1
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb11:
  %t55 = load i32, ptr %l2
  %t57 = trunc i64 35 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 34 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t65 = load i32, ptr %l2
  %t67 = trunc i64 36 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %t70)
  %t73 = extractvalue { i32, ptr } %t72, 1
  %t74 = extractvalue { i32, ptr } %t72, 0
  store i32 %t74, ptr %l39
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76
ok.76:
  store ptr %t73, ptr %l38
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l38, !tbaa !29
  store ptr %t77, ptr %l36, !tbaa !29
  br label %bb21
bb20:
  %t78 = load i32, ptr %l39, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  %t88 = insertvalue { i32, ptr } zeroinitializer, i32 %t86, 0
  store { i32, ptr } %t88, ptr %rv
  br label %ret
bb21:
  %t89 = load ptr, ptr %l36, !tbaa !29
  store ptr %t89, ptr %l4, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t90, i32 %t91)
  store %"compiler/source:Span" %t94, ptr %l43
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  br i1 %t97, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_47198c3f9d8413cf_be7184982b6f0763)
  unreachable
bb24:
  br label %bb25
bb25:
  %t99 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 0
  store i64 2, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l43
  %t103 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t102, 0
  %t105 = insertvalue { %"compiler/source:Span", ptr } %t103, ptr %t99, 1
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t105, ptr %t106
  %t107 = load { i64, [5 x i64] }, ptr %t100
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t107, ptr %t109
  %t111 = insertvalue { i32, ptr } zeroinitializer, ptr %t109, 1
  store { i32, ptr } %t111, ptr %rv
  br label %ret
bb26:
  %t112 = load i32, ptr %l2
  %t114 = trunc i64 1 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb60
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 32
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l53
  br label %bb30
bb30:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l5, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 32
  store ptr %t125, ptr %l55, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t126)
  %t129 = extractvalue { i32, i32 } %t128, 1
  %t130 = extractvalue { i32, i32 } %t128, 0
  store i32 %t130, ptr %l59
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb32, label %ok.132
ok.132:
  store i32 %t129, ptr %l58
  br label %bb31
bb31:
  %t133 = load i32, ptr %l58, !tbaa !23
  store i32 %t133, ptr %l56, !tbaa !23
  br label %bb33
bb32:
  %t134 = load i32, ptr %l59, !tbaa !23
  %t135 = lshr i32 %t134, 16
  %t136 = and i32 %t134, 65535
  %t137 = icmp eq i32 %t135, 1
  %t138 = select i1 %t137, i32 1, i32 0
  %t139 = icmp eq i32 %t134, 0
  %t140 = shl i32 %t138, 16
  %t141 = or i32 %t140, %t136
  %t142 = select i1 %t139, i32 0, i32 %t141
  %t144 = insertvalue { i32, ptr } zeroinitializer, i32 %t142, 0
  store { i32, ptr } %t144, ptr %rv
  br label %ret
bb33:
  %t145 = load ptr, ptr %l55, !tbaa !29
  %t146 = load i32, ptr %l56, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t145, i32 %t146)
  br label %bb34
bb34:
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s4
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t150 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t147, i32 56)
  store i1 %t150, ptr %l63
  br label %bb36
bb36:
  %t151 = load i1, ptr %l63, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb38:
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t154)
  store i32 %t156, ptr %l66
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 32
  store ptr %t159, ptr %l68, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t160)
  %t163 = extractvalue { i32, i32 } %t162, 1
  %t164 = extractvalue { i32, i32 } %t162, 0
  store i32 %t164, ptr %l72
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb42, label %ok.166
ok.166:
  store i32 %t163, ptr %l71
  br label %bb41
bb41:
  %t167 = load i32, ptr %l71, !tbaa !23
  store i32 %t167, ptr %l69, !tbaa !23
  br label %bb43
bb42:
  %t168 = load i32, ptr %l72, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  call void @__olang_scope_close(ptr %s4)
  %t178 = insertvalue { i32, ptr } zeroinitializer, i32 %t176, 0
  store { i32, ptr } %t178, ptr %rv
  br label %ret
bb43:
  %t179 = load ptr, ptr %l68, !tbaa !29
  %t180 = load i32, ptr %l69, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t179, i32 %t180)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb45:
  br label %bb35
bb46:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 32
  %t184 = load i64, ptr %l5, !tbaa !24
  %t187 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t183, i64 %t184)
  store { i64, ptr } %t187, ptr %l77
  br label %bb47
bb47:
  %t188 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t188, ptr %l6, !tbaa !27
  %t189 = icmp sge i64 0, 0
  br i1 %t189, label %bb48, label %bb49
bb48:
  %t191 = icmp sle i64 0, 1152921504606846975
  br i1 %t191, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb50:
  %t193 = mul i64 0, 8
  %t194 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 0, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l7, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t201 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t198, i32 77)
  store i1 %t201, ptr %l83
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb52:
  %t202 = load i1, ptr %l83, !tbaa !21
  br i1 %t202, label %bb53, label %bb54
bb53:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t203)
  %t206 = extractvalue { i32, { i64, ptr } } %t205, 1
  %t207 = extractvalue { i32, { i64, ptr } } %t205, 0
  store i32 %t207, ptr %l87
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb56, label %ok.209
ok.209:
  store { i64, ptr } %t206, ptr %l86
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t210 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t210, ptr %l84, !tbaa !27
  br label %bb57
bb56:
  %t211 = load i32, ptr %l87, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  %t221 = insertvalue { i32, ptr } zeroinitializer, i32 %t219, 0
  store { i32, ptr } %t221, ptr %rv
  br label %ret
bb57:
  %t222 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t222, ptr %l7, !tbaa !27
  br label %bb58
bb58:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l1, !tbaa !23
  %t227 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t223, i32 %t224)
  store %"compiler/source:Span" %t227, ptr %l91
  br label %bb59
bb59:
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 0
  store i64 0, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l91
  %t233 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t232, 0
  %t235 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t233, { i64, ptr } %t228, 1
  %t237 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t235, { i64, ptr } %t229, 2
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t237, ptr %t238
  %t239 = load { i64, [5 x i64] }, ptr %t230
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t239, ptr %t241
  %t243 = insertvalue { i32, ptr } zeroinitializer, ptr %t241, 1
  store { i32, ptr } %t243, ptr %rv
  br label %ret
bb60:
  %t244 = load i32, ptr %l2
  %t246 = trunc i64 88 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb90
bb63:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/parse:Parser", ptr %t249, i32 0, i32 39
  store ptr %t251, ptr %l99, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/parse:Parser", ptr %t253, i32 0, i32 6
  %t256 = load i64, ptr %t255, !tbaa !24
  %t259 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t252, i64 %t256)
  store i64 %t259, ptr %l103
  br label %bb64
bb64:
  %t260 = load ptr, ptr %l99, !tbaa !29
  %t261 = load i64, ptr %l103, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t260, i64 %t261)
  br label %bb65
bb65:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t262)
  store i32 %t264, ptr %l105
  br label %bb66
bb66:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/parse:Parser", ptr %t265, i32 0, i32 17
  %t268 = load i1, ptr %t267, !tbaa !21
  store i1 %t268, ptr %l8, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/parse:Parser", ptr %t270, i32 0, i32 16
  %t273 = load i1, ptr %t272, !tbaa !21
  store i1 %t273, ptr %l9, !tbaa !21
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/parse:Parser", ptr %t275, i32 0, i32 17
  store i1 false, ptr %t277, !tbaa !21
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 16
  store i1 false, ptr %t280, !tbaa !21
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t281)
  %t284 = extractvalue { i32, ptr } %t283, 1
  %t285 = extractvalue { i32, ptr } %t283, 0
  store i32 %t285, ptr %l115
  %t286 = icmp ne i32 %t285, 0
  br i1 %t286, label %bb68, label %ok.287
ok.287:
  store ptr %t284, ptr %l114
  br label %bb67
bb67:
  %t288 = load ptr, ptr %l114, !tbaa !29
  store ptr %t288, ptr %l112, !tbaa !29
  br label %bb70
bb68:
  br label %bb69
bb69:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i1, ptr %l8, !tbaa !21
  %t293 = getelementptr %"compiler/parse:Parser", ptr %t289, i32 0, i32 17
  store i1 %t290, ptr %t293, !tbaa !21
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i1, ptr %l9, !tbaa !21
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t294, i32 0, i32 16
  store i1 %t295, ptr %t298, !tbaa !21
  %t300 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb70:
  %t301 = load ptr, ptr %l112, !tbaa !29
  store ptr %t301, ptr %l10, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i1, ptr %l8, !tbaa !21
  %t306 = getelementptr %"compiler/parse:Parser", ptr %t302, i32 0, i32 17
  store i1 %t303, ptr %t306, !tbaa !21
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i1, ptr %l9, !tbaa !21
  %t311 = getelementptr %"compiler/parse:Parser", ptr %t307, i32 0, i32 16
  store i1 %t308, ptr %t311, !tbaa !21
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t315 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t312, i32 89)
  store i1 %t315, ptr %l127
  br label %bb71
bb71:
  %t316 = load i1, ptr %l127, !tbaa !21
  %t317 = xor i1 %t316, true
  br i1 %t317, label %bb72, label %bb73
bb72:
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t321 = call i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %t319)
  store i1 %t321, ptr %l131
  br label %bb74
bb73:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb75
bb74:
  %t322 = load i1, ptr %l131, !tbaa !21
  %t323 = xor i1 %t322, true
  store i1 %t323, ptr %l129, !tbaa !21
  br label %bb75
bb75:
  %t325 = load i1, ptr %l129, !tbaa !21
  br i1 %t325, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l133, !tbaa !29
  %t327 = load i32, ptr %l1, !tbaa !23
  store i32 %t327, ptr %l134, !tbaa !23
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/parse:Parser", ptr %t328, i32 0, i32 10
  %t331 = load i32, ptr %t330, !tbaa !23
  store i32 %t331, ptr %l136, !tbaa !23
  %t332 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s8)
  store %"compiler/msgs:Msg" %t332, ptr %l137
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t333 = load ptr, ptr %l133, !tbaa !29
  %t334 = load i32, ptr %l134, !tbaa !23
  %t335 = load i32, ptr %l136, !tbaa !23
  %t336 = load %"compiler/msgs:Msg", ptr %l137
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s8, ptr %t333, i32 %t334, i32 %t335, %"compiler/msgs:Msg" %t336)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s8)
  %t338 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t338, ptr %rv
  br label %ret
bb80:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t342 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t339, i32 89)
  %t343 = extractvalue { i32, i32 } %t342, 1
  %t344 = extractvalue { i32, i32 } %t342, 0
  store i32 %t344, ptr %l143
  %t345 = icmp ne i32 %t344, 0
  br i1 %t345, label %bb82, label %ok.346
ok.346:
  store i32 %t343, ptr %l142
  br label %bb81
bb81:
  %t347 = load i32, ptr %l142, !tbaa !23
  store i32 %t347, ptr %l139, !tbaa !23
  br label %bb83
bb82:
  %t348 = load i32, ptr %l143, !tbaa !23
  %t349 = lshr i32 %t348, 16
  %t350 = and i32 %t348, 65535
  %t351 = icmp eq i32 %t349, 1
  %t352 = select i1 %t351, i32 1, i32 0
  %t353 = icmp eq i32 %t348, 0
  %t354 = shl i32 %t352, 16
  %t355 = or i32 %t354, %t350
  %t356 = select i1 %t353, i32 0, i32 %t355
  %t358 = insertvalue { i32, ptr } zeroinitializer, i32 %t356, 0
  store { i32, ptr } %t358, ptr %rv
  br label %ret
bb83:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l10, !tbaa !29
  %t363 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v0, ptr %t359, ptr %t360)
  store i1 %t363, ptr %l147
  br label %bb84
bb84:
  %t364 = load i1, ptr %l147, !tbaa !21
  %t365 = xor i1 %t364, true
  br i1 %t365, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s9
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l149, !tbaa !29
  %t368 = load i32, ptr %l1, !tbaa !23
  store i32 %t368, ptr %l150, !tbaa !23
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/parse:Parser", ptr %t369, i32 0, i32 10
  %t372 = load i32, ptr %t371, !tbaa !23
  store i32 %t372, ptr %l152, !tbaa !23
  %t373 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s9)
  store %"compiler/msgs:Msg" %t373, ptr %l153
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t374 = load ptr, ptr %l149, !tbaa !29
  %t375 = load i32, ptr %l150, !tbaa !23
  %t376 = load i32, ptr %l152, !tbaa !23
  %t377 = load %"compiler/msgs:Msg", ptr %l153
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s9, ptr %t374, i32 %t375, i32 %t376, %"compiler/msgs:Msg" %t377)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  %t379 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t379, ptr %rv
  br label %ret
bb89:
  %t380 = load ptr, ptr %l10, !tbaa !29
  %t382 = insertvalue { i32, ptr } zeroinitializer, ptr %t380, 1
  store { i32, ptr } %t382, ptr %rv
  br label %ret
bb90:
  %t383 = load i32, ptr %l2
  %t385 = trunc i64 77 to i32
  %t386 = icmp eq i32 %t383, %t385
  br i1 %t386, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb97
bb93:
  store %olang.scope zeroinitializer, ptr %s10
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s10, ptr %t388, { i64, ptr } { i64 6, ptr @.d5 })
  store i32 %t390, ptr %l159
  %t391 = icmp ne i32 %t390, 0
  br i1 %t391, label %bb95, label %ok.392
ok.392:
  br label %bb94
bb94:
  br label %bb96
bb95:
  %t393 = load i32, ptr %l159, !tbaa !23
  %t394 = lshr i32 %t393, 16
  %t395 = and i32 %t393, 65535
  %t396 = icmp eq i32 %t394, 1
  %t397 = select i1 %t396, i32 1, i32 0
  %t398 = icmp eq i32 %t393, 0
  %t399 = shl i32 %t397, 16
  %t400 = or i32 %t399, %t395
  %t401 = select i1 %t398, i32 0, i32 %t400
  call void @__olang_scope_close(ptr %s10)
  %t403 = insertvalue { i32, ptr } zeroinitializer, i32 %t401, 0
  store { i32, ptr } %t403, ptr %rv
  br label %ret
bb96:
  call void @__olang_scope_close(ptr %s10)
  br label %bb101
bb97:
  store %olang.scope zeroinitializer, ptr %s11
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s11, ptr %t404, { i64, ptr } { i64 6, ptr @.d6 })
  store i32 %t406, ptr %l162
  %t407 = icmp ne i32 %t406, 0
  br i1 %t407, label %bb99, label %ok.408
ok.408:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t409 = load i32, ptr %l162, !tbaa !23
  %t410 = lshr i32 %t409, 16
  %t411 = and i32 %t409, 65535
  %t412 = icmp eq i32 %t410, 1
  %t413 = select i1 %t412, i32 1, i32 0
  %t414 = icmp eq i32 %t409, 0
  %t415 = shl i32 %t413, 16
  %t416 = or i32 %t415, %t411
  %t417 = select i1 %t414, i32 0, i32 %t416
  call void @__olang_scope_close(ptr %s11)
  %t419 = insertvalue { i32, ptr } zeroinitializer, i32 %t417, 0
  store { i32, ptr } %t419, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s11)
  br label %bb101
bb101:
  call void @__olang_check_failed(ptr @olang_loc_31e39d55c126667c_eaaf5fcb81f21700)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t48 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t5, i32 39)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %t10)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l12
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb4, label %ok.16
ok.16:
  store ptr %t13, ptr %l11
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l11, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  br label %bb5
bb4:
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb5:
  %t29 = load ptr, ptr %l9, !tbaa !29
  store ptr %t29, ptr %l3, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t36 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t30, i32 %t31, ptr %t32)
  store ptr %t36, ptr %l17
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l17, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t40, i32 %t41)
  store %"compiler/source:Span" %t44, ptr %l21
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = load i1, ptr %l2, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 0
  store i64 4, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l21
  %t51 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t50, 0
  %t53 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t51, ptr %t45, 1
  %t55 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t53, i1 %t47, 2
  %t56 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t55, i1 false, 3
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t56, ptr %t57
  %t58 = load { i64, [5 x i64] }, ptr %t48
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t58, ptr %t60
  %t62 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t62, ptr %rv
  br label %ret
bb10:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = insertvalue { i32, ptr } zeroinitializer, ptr %t63, 1
  store { i32, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l64 = alloca i1
  %l66 = alloca i32
  %l70 = alloca i1
  %l74 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l86 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca i32
  %s9 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t61 = alloca { i64, [5 x i64] }, align 8
  %t131 = alloca { i64, [5 x i64] }, align 8
  %t299 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i32, ptr %l12
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 48 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l16
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t17)
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb8, label %ok.21
ok.21:
  br label %bb7
bb7:
  br label %bb9
bb8:
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t33, i64 4)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l23
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb11, label %ok.39
ok.39:
  store ptr %t36, ptr %l22
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l22, !tbaa !29
  store ptr %t40, ptr %l20, !tbaa !29
  br label %bb13
bb11:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  store i32 %t49, ptr %l24, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t50)
  br label %bb12
bb12:
  %t52 = load i32, ptr %l24, !tbaa !23
  %t53 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb13:
  %t54 = load ptr, ptr %l20, !tbaa !29
  store ptr %t54, ptr %l3, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t55, i32 %t56)
  store %"compiler/source:Span" %t59, ptr %l28
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 0
  store i64 3, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l28
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t63, 0
  %t66 = insertvalue { %"compiler/source:Span", i32, ptr } %t64, i32 48, 1
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } %t66, ptr %t60, 2
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t68, ptr %t69
  %t70 = load { i64, [5 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t70, ptr %t72
  store ptr %t72, ptr %l32, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t73)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l32, !tbaa !29
  %t76 = insertvalue { i32, ptr } zeroinitializer, ptr %t75, 1
  store { i32, ptr } %t76, ptr %rv
  br label %ret
bb16:
  %t77 = load i32, ptr %l2
  %t79 = trunc i64 50 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  %t82 = load i32, ptr %l2
  %t84 = trunc i64 84 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb25
bb20:
  %t87 = load i32, ptr %l2
  %t89 = trunc i64 71 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t92 = load i32, ptr %l2
  %t94 = trunc i64 72 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t97)
  store i32 %t99, ptr %l43
  br label %bb26
bb26:
  %t100 = load i32, ptr %l43
  store i32 %t100, ptr %l4
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l45
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t104)
  %t107 = extractvalue { i32, ptr } %t106, 1
  %t108 = extractvalue { i32, ptr } %t106, 0
  store i32 %t108, ptr %l49
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb29, label %ok.110
ok.110:
  store ptr %t107, ptr %l48
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l48, !tbaa !29
  store ptr %t111, ptr %l46, !tbaa !29
  br label %bb30
bb29:
  %t112 = load i32, ptr %l49, !tbaa !23
  %t113 = lshr i32 %t112, 16
  %t114 = and i32 %t112, 65535
  %t115 = icmp eq i32 %t113, 1
  %t116 = select i1 %t115, i32 1, i32 0
  %t117 = icmp eq i32 %t112, 0
  %t118 = shl i32 %t116, 16
  %t119 = or i32 %t118, %t114
  %t120 = select i1 %t117, i32 0, i32 %t119
  %t122 = insertvalue { i32, ptr } zeroinitializer, i32 %t120, 0
  store { i32, ptr } %t122, ptr %rv
  br label %ret
bb30:
  %t123 = load ptr, ptr %l46, !tbaa !29
  store ptr %t123, ptr %l5, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t124, i32 %t125)
  store %"compiler/source:Span" %t128, ptr %l53
  br label %bb31
bb31:
  %t129 = load i32, ptr %l4
  %t130 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 0
  store i64 3, ptr %t132
  %t133 = load %"compiler/source:Span", ptr %l53
  %t134 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t133, 0
  %t136 = insertvalue { %"compiler/source:Span", i32, ptr } %t134, i32 %t129, 1
  %t138 = insertvalue { %"compiler/source:Span", i32, ptr } %t136, ptr %t130, 2
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t138, ptr %t139
  %t140 = load { i64, [5 x i64] }, ptr %t131
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t140, ptr %t142
  %t144 = insertvalue { i32, ptr } zeroinitializer, ptr %t142, 1
  store { i32, ptr } %t144, ptr %rv
  br label %ret
bb32:
  %t145 = load i32, ptr %l2
  %t147 = trunc i64 5 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t150 = load i32, ptr %l2
  %t152 = trunc i64 85 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb82
bb37:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t158 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t155, i32 5)
  store i1 %t158, ptr %l64
  br label %bb38
bb38:
  %t159 = load i1, ptr %l64, !tbaa !21
  br i1 %t159, label %bb39, label %bb40
bb39:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t160, i64 1)
  store i32 %t162, ptr %l66
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t163 = load i32, ptr %l66
  store i32 %t163, ptr %l6
  %t164 = load i32, ptr %l6
  %t166 = trunc i64 5 to i32
  %t167 = icmp eq i32 %t164, %t166
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb42, label %bb43
bb42:
  %t171 = load i32, ptr %l6
  %t173 = trunc i64 85 to i32
  %t174 = icmp eq i32 %t171, %t173
  %t176 = xor i1 %t174, true
  store i1 %t176, ptr %l70, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb44
bb44:
  %t178 = load i1, ptr %l70, !tbaa !21
  br i1 %t178, label %bb45, label %bb46
bb45:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t179)
  %t182 = extractvalue { i32, ptr } %t181, 1
  %t183 = extractvalue { i32, ptr } %t181, 0
  store i32 %t183, ptr %l77
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb48, label %ok.185
ok.185:
  store ptr %t182, ptr %l76
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t186 = load ptr, ptr %l76, !tbaa !29
  store ptr %t186, ptr %l74, !tbaa !29
  br label %bb49
bb48:
  %t187 = load i32, ptr %l77, !tbaa !23
  %t188 = lshr i32 %t187, 16
  %t189 = and i32 %t187, 65535
  %t190 = icmp eq i32 %t188, 1
  %t191 = select i1 %t190, i32 1, i32 0
  %t192 = icmp eq i32 %t187, 0
  %t193 = shl i32 %t191, 16
  %t194 = or i32 %t193, %t189
  %t195 = select i1 %t192, i32 0, i32 %t194
  %t197 = insertvalue { i32, ptr } zeroinitializer, i32 %t195, 0
  store { i32, ptr } %t197, ptr %rv
  br label %ret
bb49:
  %t198 = load ptr, ptr %l74, !tbaa !29
  %t199 = insertvalue { i32, ptr } zeroinitializer, ptr %t198, 1
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %t200)
  %t203 = extractvalue { i32, ptr } %t202, 1
  %t204 = extractvalue { i32, ptr } %t202, 0
  store i32 %t204, ptr %l82
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb53, label %ok.206
ok.206:
  store ptr %t203, ptr %l81
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l81, !tbaa !29
  store ptr %t207, ptr %l79, !tbaa !29
  br label %bb54
bb53:
  %t208 = load i32, ptr %l82, !tbaa !23
  %t209 = lshr i32 %t208, 16
  %t210 = and i32 %t208, 65535
  %t211 = icmp eq i32 %t209, 1
  %t212 = select i1 %t211, i32 1, i32 0
  %t213 = icmp eq i32 %t208, 0
  %t214 = shl i32 %t212, 16
  %t215 = or i32 %t214, %t210
  %t216 = select i1 %t213, i32 0, i32 %t215
  %t218 = insertvalue { i32, ptr } zeroinitializer, i32 %t216, 0
  store { i32, ptr } %t218, ptr %rv
  br label %ret
bb54:
  %t219 = load ptr, ptr %l79, !tbaa !29
  store ptr %t219, ptr %l7, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t223 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t220, i32 5)
  store i1 %t223, ptr %l86
  br label %bb55
bb55:
  %t224 = load i1, ptr %l86, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb56, label %bb57
bb56:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t227, i32 85)
  store i1 %t230, ptr %l91
  br label %bb58
bb57:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb59
bb58:
  %t231 = load i1, ptr %l91, !tbaa !21
  %t232 = xor i1 %t231, true
  store i1 %t232, ptr %l88, !tbaa !21
  br label %bb59
bb59:
  %t234 = load i1, ptr %l88, !tbaa !21
  br i1 %t234, label %bb60, label %bb61
bb60:
  %t235 = load ptr, ptr %l7, !tbaa !29
  %t237 = insertvalue { i32, ptr } zeroinitializer, ptr %t235, 1
  store { i32, ptr } %t237, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 27
  %t242 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t240)
  store i64 %t242, ptr %l96
  br label %bb63
bb63:
  %t243 = load i64, ptr %l96, !tbaa !24
  store i64 %t243, ptr %l8, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 27
  %t247 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t246, ptr %t247)
  br label %bb64
bb64:
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s9
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t250, i32 5)
  store i1 %t253, ptr %l102
  br label %bb66
bb66:
  %t254 = load i1, ptr %l102, !tbaa !21
  br i1 %t254, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb70
bb68:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t258 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t255, i32 85)
  store i1 %t258, ptr %l106
  br label %bb69
bb69:
  %t259 = load i1, ptr %l106, !tbaa !21
  store i1 %t259, ptr %l103, !tbaa !21
  br label %bb70
bb70:
  %t260 = load i1, ptr %l103, !tbaa !21
  %t261 = xor i1 %t260, true
  br i1 %t261, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb72:
  br label %bb73
bb73:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/parse:Parser", ptr %t263, i32 0, i32 27
  store ptr %t265, ptr %l109, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %t266)
  %t269 = extractvalue { i32, ptr } %t268, 1
  %t270 = extractvalue { i32, ptr } %t268, 0
  store i32 %t270, ptr %l113
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb75, label %ok.272
ok.272:
  store ptr %t269, ptr %l112
  br label %bb74
bb74:
  %t273 = load ptr, ptr %l112, !tbaa !29
  store ptr %t273, ptr %l110, !tbaa !29
  br label %bb76
bb75:
  %t274 = load i32, ptr %l113, !tbaa !23
  %t275 = lshr i32 %t274, 16
  %t276 = and i32 %t274, 65535
  %t277 = icmp eq i32 %t275, 1
  %t278 = select i1 %t277, i32 1, i32 0
  %t279 = icmp eq i32 %t274, 0
  %t280 = shl i32 %t278, 16
  %t281 = or i32 %t280, %t276
  %t282 = select i1 %t279, i32 0, i32 %t281
  call void @__olang_scope_close(ptr %s9)
  %t284 = insertvalue { i32, ptr } zeroinitializer, i32 %t282, 0
  store { i32, ptr } %t284, ptr %rv
  br label %ret
bb76:
  %t285 = load ptr, ptr %l109, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t285, ptr %t286)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  br label %bb78
bb78:
  br label %bb65
bb79:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i32, ptr %l1, !tbaa !23
  %t291 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t287, i32 %t288)
  store %"compiler/source:Span" %t291, ptr %l117
  br label %bb80
bb80:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 27
  %t295 = load i64, ptr %l8, !tbaa !24
  %t298 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t294, i64 %t295)
  store { i64, ptr } %t298, ptr %l121
  br label %bb81
bb81:
  store { i64, [5 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 0
  store i64 21, ptr %t300
  %t301 = load %"compiler/source:Span", ptr %l117
  %t302 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t301, 0
  %t303 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t304 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t302, { i64, ptr } %t303, 1
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t304, ptr %t305
  %t306 = load { i64, [5 x i64] }, ptr %t299
  %t308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t306, ptr %t308
  %t310 = insertvalue { i32, ptr } zeroinitializer, ptr %t308, 1
  store { i32, ptr } %t310, ptr %rv
  br label %ret
bb82:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t311)
  %t314 = extractvalue { i32, ptr } %t313, 1
  %t315 = extractvalue { i32, ptr } %t313, 0
  store i32 %t315, ptr %l127
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb84, label %ok.317
ok.317:
  store ptr %t314, ptr %l126
  br label %bb83
bb83:
  %t318 = load ptr, ptr %l126, !tbaa !29
  store ptr %t318, ptr %l124, !tbaa !29
  br label %bb85
bb84:
  %t319 = load i32, ptr %l127, !tbaa !23
  %t320 = lshr i32 %t319, 16
  %t321 = and i32 %t319, 65535
  %t322 = icmp eq i32 %t320, 1
  %t323 = select i1 %t322, i32 1, i32 0
  %t324 = icmp eq i32 %t319, 0
  %t325 = shl i32 %t323, 16
  %t326 = or i32 %t325, %t321
  %t327 = select i1 %t324, i32 0, i32 %t326
  %t329 = insertvalue { i32, ptr } zeroinitializer, i32 %t327, 0
  store { i32, ptr } %t329, ptr %rv
  br label %ret
bb85:
  %t330 = load ptr, ptr %l124, !tbaa !29
  %t331 = insertvalue { i32, ptr } zeroinitializer, ptr %t330, 1
  store { i32, ptr } %t331, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l135 = alloca i1
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l166 = alloca i1
  %l176 = alloca i64
  %l179 = alloca i64
  %l197 = alloca { i64, ptr }
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l206 = alloca i1
  %l207 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l250 = alloca i64
  %l251 = alloca i64
  %l257 = alloca ptr
  %l258 = alloca i64
  %l259 = alloca { i64, ptr }
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca i64
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l277 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l24, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  store i64 %t16, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/parse:Parser", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l29, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l32
  br label %bb1
bb1:
  %t27 = load i64, ptr %l32, !tbaa !24
  %t28 = trunc i64 %t27 to i32
  %t29 = load ptr, ptr %l29, !tbaa !29
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t31, ptr %l34
  br label %bb2
bb2:
  %t32 = load i32, ptr %l34, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp slt i64 %t37, %t46
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/source:Source", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  %t58 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp ne i8 %t63, 10
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb6
bb6:
  %t67 = load i1, ptr %l43, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/source:Source", ptr %t77, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l55, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  store i64 %t81, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  store i64 %t82, ptr %l57, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l58, !tbaa !24
  %t85 = load i64, ptr %l56, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb12, label %bb13
bb12:
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb14:
  %t92 = load i64, ptr %l57, !tbaa !24
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb16:
  %t96 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = sub i64 %t109, %t110
  store i64 %t113, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp sle i64 %t115, 0
  br i1 %t117, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb18:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb20
bb19:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = icmp sge i64 %t119, %t120
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb20
bb20:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  br i1 %t131, label %bb25, label %bb26
bb25:
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = icmp eq i8 %t139, 32
  br i1 %t141, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb29
bb28:
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t143, ptr %l84, !tbaa !27
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 9
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb29
bb29:
  %t153 = load i1, ptr %l83, !tbaa !21
  store i1 %t153, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t154 = load i1, ptr %l78, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t161 = load i64, ptr %l8, !tbaa !24
  store i64 %t161, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t163 = load i64, ptr %l8, !tbaa !24
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l96, !tbaa !27
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp ne i8 %t175, 32
  store i1 %t177, ptr %l95, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l95, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l8, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i8, ptr %t184, i64 %t181
  %t186 = load i8, ptr %t185, !tbaa !32
  %t188 = icmp ne i8 %t186, 9
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t190 = load i1, ptr %l100, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t193 = load i64, ptr %l8, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  br label %bb36
bb47:
  %t197 = load i64, ptr %l8, !tbaa !24
  store i64 %t197, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s5
  %t199 = load i64, ptr %l8, !tbaa !24
  %t200 = load i64, ptr %l7, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t205, ptr %l113, !tbaa !27
  %t206 = load i64, ptr %l8, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i8, ptr %t209, i64 %t206
  %t211 = load i8, ptr %t210, !tbaa !32
  %t213 = icmp eq i8 %t211, 32
  br i1 %t213, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb54
bb51:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb53
bb52:
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t215, ptr %l118, !tbaa !27
  %t216 = load i64, ptr %l8, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t216
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = icmp eq i8 %t221, 9
  store i1 %t223, ptr %l117, !tbaa !21
  br label %bb53
bb53:
  %t225 = load i1, ptr %l117, !tbaa !21
  store i1 %t225, ptr %l112, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l112, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t229 = load i64, ptr %l8, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb58:
  br label %bb48
bb59:
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t233, ptr %l125, !tbaa !27
  %t234 = load i64, ptr %l8, !tbaa !24
  store i64 %t234, ptr %l126, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t235, 0
  store i64 %t238, ptr %l129, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l130, !tbaa !24
  %t241 = load i64, ptr %l126, !tbaa !24
  %t242 = icmp sge i64 %t241, 0
  br i1 %t242, label %bb60, label %bb61
bb60:
  %t244 = load i64, ptr %l126, !tbaa !24
  %t245 = load i64, ptr %l129, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb62:
  %t248 = load i64, ptr %l129, !tbaa !24
  %t249 = load i64, ptr %l130, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb64:
  %t252 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = load i64, ptr %l126, !tbaa !24
  %t255 = load i64, ptr %l129, !tbaa !24
  %t256 = getelementptr i8, ptr %t253, i64 %t254
  %t257 = sub i64 %t255, %t254
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 4, ptr @.d7 })
  store i1 %t261, ptr %l135
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb66:
  %t262 = load i1, ptr %l135, !tbaa !21
  br i1 %t262, label %bb67, label %bb68
bb67:
  %t263 = load i64, ptr %l8, !tbaa !24
  %t265 = add i64 %t263, 4
  store i64 %t265, ptr %l8, !tbaa !24
  br label %bb69
bb68:
  br label %bb78
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t267 = load i64, ptr %l8, !tbaa !24
  %t268 = load i64, ptr %l7, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  br i1 %t271, label %bb70, label %bb71
bb70:
  %t273 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t273, ptr %l142, !tbaa !27
  %t274 = load i64, ptr %l8, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i8, ptr %t277, i64 %t274
  %t279 = load i8, ptr %t278, !tbaa !32
  %t281 = icmp eq i8 %t279, 32
  store i1 %t281, ptr %l141, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb72
bb72:
  %t283 = load i1, ptr %l141, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s7)
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t286 = load i64, ptr %l8, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb76:
  br label %bb69
bb77:
  br label %bb78
bb78:
  %t290 = load i64, ptr %l8, !tbaa !24
  store i64 %t290, ptr %l11, !tbaa !24
  %t292 = load i64, ptr %l7, !tbaa !24
  store i64 %t292, ptr %l12, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s8
  %t294 = load i64, ptr %l12, !tbaa !24
  %t295 = load i64, ptr %l11, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb80, label %bb81
bb80:
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t300, ptr %l155, !tbaa !27
  %t301 = load i64, ptr %l12, !tbaa !24
  %t303 = sub i64 %t301, 1
  %t305 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i8, ptr %t306, i64 %t303
  %t308 = load i8, ptr %t307, !tbaa !32
  %t310 = icmp eq i8 %t308, 32
  store i1 %t310, ptr %l154, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb82
bb82:
  %t312 = load i1, ptr %l154, !tbaa !21
  %t313 = xor i1 %t312, true
  br i1 %t313, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s8)
  br label %bb87
bb84:
  br label %bb85
bb85:
  %t315 = load i64, ptr %l12, !tbaa !24
  %t317 = sub i64 %t315, 1
  store i64 %t317, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb86
bb86:
  br label %bb79
bb87:
  %t319 = load i64, ptr %l10, !tbaa !24
  %t320 = load i64, ptr %l9, !tbaa !24
  %t323 = icmp eq i64 %t319, %t320
  br i1 %t323, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb90
bb89:
  %t325 = load i64, ptr %l12, !tbaa !24
  %t326 = load i64, ptr %l11, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  store i1 %t329, ptr %l166, !tbaa !21
  br label %bb90
bb90:
  %t331 = load i1, ptr %l166, !tbaa !21
  br i1 %t331, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t333 = load i64, ptr %l9, !tbaa !24
  store i64 %t333, ptr %l13, !tbaa !24
  %t335 = load i64, ptr %l7, !tbaa !24
  store i64 %t335, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l14, !tbaa !24
  %t338 = load i64, ptr %l13, !tbaa !24
  %t341 = icmp sgt i64 %t337, %t338
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = load i64, ptr %l15, !tbaa !24
  %t345 = icmp sgt i64 %t343, 0
  br i1 %t345, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb99
bb96:
  %t347 = load i64, ptr %l14, !tbaa !24
  %t348 = load i64, ptr %l13, !tbaa !24
  %t351 = sub i64 %t347, %t348
  %t352 = load i64, ptr %l15, !tbaa !24
  %t355 = add i64 %t351, %t352
  %t357 = sub i64 %t355, 1
  %t358 = load i64, ptr %l15, !tbaa !24
  %t361 = sdiv i64 %t357, %t358
  store i64 %t361, ptr %l179, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb98
bb98:
  %t363 = load i64, ptr %l179, !tbaa !24
  store i64 %t363, ptr %l176, !tbaa !24
  br label %bb99
bb99:
  %t364 = load i64, ptr %l176, !tbaa !24
  store i64 %t364, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s11
  %t365 = load i64, ptr %l17, !tbaa !24
  %t366 = load i64, ptr %l16, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s11)
  br label %bb114
bb102:
  br label %bb103
bb103:
  %t373 = load i64, ptr %l13, !tbaa !24
  %t374 = load i64, ptr %l17, !tbaa !24
  %t375 = load i64, ptr %l15, !tbaa !24
  %t378 = mul i64 %t374, %t375
  %t381 = add i64 %t373, %t378
  store i64 %t381, ptr %l18, !tbaa !24
  %t383 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t383, ptr %l197, !tbaa !27
  %t384 = load i64, ptr %l18, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i8, ptr %t387, i64 %t384
  %t389 = load i8, ptr %t388, !tbaa !32
  %t391 = icmp eq i8 %t389, 61
  br i1 %t391, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb106
bb105:
  %t393 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t393, ptr %l202, !tbaa !27
  %t394 = load i64, ptr %l18, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i8, ptr %t397, i64 %t394
  %t399 = load i8, ptr %t398, !tbaa !32
  %t401 = icmp eq i8 %t399, 58
  store i1 %t401, ptr %l201, !tbaa !21
  br label %bb106
bb106:
  %t403 = load i1, ptr %l201, !tbaa !21
  br i1 %t403, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb109
bb108:
  %t404 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t404, ptr %l207, !tbaa !27
  %t405 = load i64, ptr %l18, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i8, ptr %t408, i64 %t405
  %t410 = load i8, ptr %t409, !tbaa !32
  %t412 = icmp eq i8 %t410, 40
  store i1 %t412, ptr %l206, !tbaa !21
  br label %bb109
bb109:
  %t414 = load i1, ptr %l206, !tbaa !21
  br i1 %t414, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s11)
  br label %bb113
bb113:
  %t416 = load i64, ptr %l17, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l17, !tbaa !24
  br label %bb100
bb114:
  store i64 0, ptr %l19, !tbaa !24
  %t420 = load i64, ptr %l7, !tbaa !24
  store i64 %t420, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s14
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l6, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s14)
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t430 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t430, ptr %l219, !tbaa !27
  %t431 = load i64, ptr %l20, !tbaa !24
  %t433 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr i8, ptr %t434, i64 %t431
  %t436 = load i8, ptr %t435, !tbaa !32
  %t438 = icmp eq i8 %t436, 40
  br i1 %t438, label %bb119, label %bb120
bb119:
  %t440 = load i64, ptr %l19, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l19, !tbaa !24
  br label %bb127
bb120:
  %t444 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t444, ptr %l225, !tbaa !27
  %t445 = load i64, ptr %l20, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr i8, ptr %t448, i64 %t445
  %t450 = load i8, ptr %t449, !tbaa !32
  %t452 = icmp eq i8 %t450, 41
  br i1 %t452, label %bb121, label %bb122
bb121:
  %t454 = load i64, ptr %l19, !tbaa !24
  %t456 = sub i64 %t454, 1
  store i64 %t456, ptr %l19, !tbaa !24
  %t458 = load i64, ptr %l19, !tbaa !24
  %t460 = icmp eq i64 %t458, 0
  br i1 %t460, label %bb123, label %bb124
bb122:
  br label %bb126
bb123:
  call void @__olang_scope_close(ptr %s14)
  br label %bb129
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t462 = load i64, ptr %l20, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb128
bb128:
  br label %bb115
bb129:
  %t466 = load i64, ptr %l20, !tbaa !24
  %t467 = load i64, ptr %l6, !tbaa !24
  %t470 = icmp sge i64 %t466, %t467
  br i1 %t470, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t473 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t473, ptr %l239, !tbaa !27
  %t474 = load i64, ptr %l11, !tbaa !24
  store i64 %t474, ptr %l240, !tbaa !24
  %t475 = load i64, ptr %l12, !tbaa !24
  store i64 %t475, ptr %l241, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  store i64 %t477, ptr %l242, !tbaa !24
  %t478 = load i64, ptr %l240, !tbaa !24
  %t479 = icmp sge i64 %t478, 0
  br i1 %t479, label %bb133, label %bb134
bb133:
  %t481 = load i64, ptr %l240, !tbaa !24
  %t482 = load i64, ptr %l241, !tbaa !24
  %t483 = icmp sle i64 %t481, %t482
  br i1 %t483, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb135:
  %t485 = load i64, ptr %l241, !tbaa !24
  %t486 = load i64, ptr %l242, !tbaa !24
  %t487 = icmp sle i64 %t485, %t486
  br i1 %t487, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb137:
  %t489 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l240, !tbaa !24
  %t492 = load i64, ptr %l241, !tbaa !24
  %t493 = getelementptr i8, ptr %t490, i64 %t491
  %t494 = sub i64 %t492, %t491
  %t495 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t493, 1
  store { i64, ptr } %t496, ptr %l246, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t497, ptr %l247, !tbaa !27
  %t498 = load i64, ptr %l7, !tbaa !24
  store i64 %t498, ptr %l248, !tbaa !24
  %t499 = load i64, ptr %l20, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l250, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l251, !tbaa !24
  %t504 = load i64, ptr %l248, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb139:
  %t507 = load i64, ptr %l248, !tbaa !24
  %t508 = load i64, ptr %l250, !tbaa !24
  %t509 = icmp sle i64 %t507, %t508
  br i1 %t509, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb141:
  %t511 = load i64, ptr %l250, !tbaa !24
  %t512 = load i64, ptr %l251, !tbaa !24
  %t513 = icmp sle i64 %t511, %t512
  br i1 %t513, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb143:
  %t515 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = load i64, ptr %l248, !tbaa !24
  %t518 = load i64, ptr %l250, !tbaa !24
  %t519 = getelementptr i8, ptr %t516, i64 %t517
  %t520 = sub i64 %t518, %t517
  %t521 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t519, 1
  %t523 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 1
  %t525 = extractvalue { i64, ptr } %t523, 0
  %t527 = extractvalue { i64, ptr } %t522, 1
  %t528 = extractvalue { i64, ptr } %t522, 0
  %t529 = add i64 %t525, %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t524, i64 %t525)
  %t531 = getelementptr i8, ptr %t530, i64 %t525
  call void @olang_textcopy(ptr %t531, ptr %t527, i64 %t528)
  %t532 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  store { i64, ptr } %t533, ptr %l21, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l257, !tbaa !29
  %t536 = load i64, ptr %l1, !tbaa !24
  store i64 %t536, ptr %l258, !tbaa !24
  %t537 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t537, ptr %l259, !tbaa !27
  %t538 = load i64, ptr %l9, !tbaa !24
  store i64 %t538, ptr %l260, !tbaa !24
  %t539 = load i64, ptr %l12, !tbaa !24
  store i64 %t539, ptr %l261, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 0
  store i64 %t541, ptr %l262, !tbaa !24
  %t542 = load i64, ptr %l260, !tbaa !24
  %t543 = icmp sge i64 %t542, 0
  br i1 %t543, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb145:
  %t545 = load i64, ptr %l260, !tbaa !24
  %t546 = load i64, ptr %l261, !tbaa !24
  %t547 = icmp sle i64 %t545, %t546
  br i1 %t547, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb147:
  %t549 = load i64, ptr %l261, !tbaa !24
  %t550 = load i64, ptr %l262, !tbaa !24
  %t551 = icmp sle i64 %t549, %t550
  br i1 %t551, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb149:
  %t553 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = load i64, ptr %l260, !tbaa !24
  %t556 = load i64, ptr %l261, !tbaa !24
  %t557 = getelementptr i8, ptr %t554, i64 %t555
  %t558 = sub i64 %t556, %t555
  %t559 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t557, 1
  store { i64, ptr } %t560, ptr %l266, !tbaa !27
  %t561 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t561, ptr %l267, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t562, ptr %l268, !tbaa !27
  %t563 = load i64, ptr %l9, !tbaa !24
  store i64 %t563, ptr %l269, !tbaa !24
  %t564 = load i64, ptr %l10, !tbaa !24
  store i64 %t564, ptr %l270, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  store i64 %t566, ptr %l271, !tbaa !24
  %t567 = load i64, ptr %l269, !tbaa !24
  %t568 = icmp sge i64 %t567, 0
  br i1 %t568, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb151:
  %t570 = load i64, ptr %l269, !tbaa !24
  %t571 = load i64, ptr %l270, !tbaa !24
  %t572 = icmp sle i64 %t570, %t571
  br i1 %t572, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb153:
  %t574 = load i64, ptr %l270, !tbaa !24
  %t575 = load i64, ptr %l271, !tbaa !24
  %t576 = icmp sle i64 %t574, %t575
  br i1 %t576, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb155:
  %t578 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = load i64, ptr %l269, !tbaa !24
  %t581 = load i64, ptr %l270, !tbaa !24
  %t582 = getelementptr i8, ptr %t579, i64 %t580
  %t583 = sub i64 %t581, %t580
  %t584 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t582, 1
  %t586 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t587 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t591 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t587, { i64, ptr } %t588, { i64, ptr } %t585, { i64, ptr } %t586)
  store %"compiler/msgs:Msg" %t591, ptr %l277
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb157:
  %t592 = load ptr, ptr %l257, !tbaa !29
  %t593 = load i64, ptr %l258, !tbaa !24
  %t594 = load %"compiler/msgs:Msg", ptr %l277
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s0, ptr %t592, i64 %t593, %"compiler/msgs:Msg" %t594)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %lp13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l31 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l86 = alloca %"compiler/ast:VarDecl"
  %l96 = alloca { i64, ptr }
  %l101 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l108 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l117 = alloca i32
  %l123 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t144 = alloca i64
  %t162 = alloca i64
  %t192 = alloca { i64, [5 x i64] }, align 8
  %t251 = alloca { i64, [5 x i64] }, align 8
  %t268 = alloca { i64, [5 x i64] }, align 8
  %t298 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 12
  %t6 = load i1, ptr %t5, !tbaa !21
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i1 %t6)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l21
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14
ok.14:
  store ptr %t11, ptr %l20
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l20, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb3:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t28, i32 %a1)
  store %"compiler/source:Span" %t32, ptr %l25
  br label %bb4
bb4:
  %t33 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 12
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 55)
  store i1 %t42, ptr %l31
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i1, ptr %l31, !tbaa !21
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/parse:NameList", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 1
  br i1 %t54, label %bb11, label %bb12
bb10:
  br label %bb47
bb11:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/ast:VarDecl", ptr %t56, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l37, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb15:
  br label %bb45
bb16:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb18:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l50, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l50, !tbaa !24
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l47, !tbaa !24
  store i64 %t97, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/parse:NameList", ptr %t116, i32 0, i32 1
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l69, !tbaa !27
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i64 %t120
  %t125 = load %"compiler/source:Span", ptr %t124
  store %"compiler/source:Span" %t125, ptr %l12
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/parse:NameList", ptr %t127, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l73, !tbaa !27
  %t131 = load i64, ptr %l11, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  store i32 %t136, ptr %l75, !tbaa !23
  %t137 = icmp sge i64 1, 0
  br i1 %t137, label %bb26, label %bb27
bb26:
  %t139 = icmp sle i64 1, 2305843009213693951
  br i1 %t139, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb28:
  %t141 = mul i64 1, 4
  %t142 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t141)
  %t143 = load i32, ptr %l75, !tbaa !23
  store i64 0, ptr %t144
  br label %fill.145
fill.145:
  %t148 = load i64, ptr %t144
  %t149 = icmp slt i64 %t148, 1
  br i1 %t149, label %fillb.146, label %filld.147
fillb.146:
  %t150 = getelementptr i32, ptr %t142, i64 %t148
  store i32 %t143, ptr %t150
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %t144
  br label %fill.145
filld.147:
  %t152 = insertvalue { i64, ptr } undef, i64 1, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t142, 1
  store { i64, ptr } %t153, ptr %l78, !tbaa !27
  %t154 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t154, ptr %l79
  %t155 = icmp sge i64 1, 0
  br i1 %t155, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb30:
  %t157 = icmp sle i64 1, 1152921504606846975
  br i1 %t157, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb32:
  %t159 = mul i64 1, 8
  %t160 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t159)
  %t161 = load %"compiler/source:Span", ptr %l79
  store i64 0, ptr %t162
  br label %fill.163
fill.163:
  %t166 = load i64, ptr %t162
  %t167 = icmp slt i64 %t166, 1
  br i1 %t167, label %fillb.164, label %filld.165
fillb.164:
  %t168 = getelementptr %"compiler/source:Span", ptr %t160, i64 %t166
  store %"compiler/source:Span" %t161, ptr %t168
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %t162
  br label %fill.163
filld.165:
  %t170 = insertvalue { i64, ptr } undef, i64 1, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t160, 1
  store { i64, ptr } %t171, ptr %l82, !tbaa !27
  %t172 = icmp sge i64 0, 0
  br i1 %t172, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb34:
  %t174 = icmp sle i64 0, 1152921504606846975
  br i1 %t174, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb36:
  %t176 = mul i64 0, 8
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 0, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t180 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t183 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t180, { i64, ptr } %t181, ptr null, { i64, ptr } %t179, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t183, ptr %l86
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb38:
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t184, ptr %lp13
  %t185 = load %"compiler/ast:VarDecl", ptr %l86
  %t186 = load ptr, ptr %lp13
  store %"compiler/ast:VarDecl" %t185, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 28
  %t190 = load %"compiler/source:Span", ptr %l12
  %t191 = load ptr, ptr %lp13
  store { i64, [5 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 0
  store i64 1, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t197 = insertvalue { %"compiler/source:Span", ptr } %t195, ptr %t191, 1
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t197, ptr %t198
  %t199 = load { i64, [5 x i64] }, ptr %t192
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t199, ptr %t201
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t189, ptr %t201)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb40:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l10, !tbaa !24
  br label %bb22
bb41:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr %"compiler/parse:NameList", ptr %t208, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l96, !tbaa !27
  %t212 = load i64, ptr %l5, !tbaa !24
  %t214 = sub i64 %t212, 1
  %t216 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/source:Span", ptr %t217, i64 %t214
  %t219 = load %"compiler/source:Span", ptr %t218
  store %"compiler/source:Span" %t219, ptr %l14
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t221)
  store i32 %t223, ptr %l101
  br label %bb42
bb42:
  %t224 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t225 = load i32, ptr %t224, !tbaa !23
  %t226 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t227 = load i32, ptr %t226, !tbaa !23
  %t230 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t225, i32 %t227)
  store %"compiler/source:Span" %t230, ptr %l104
  br label %bb43
bb43:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t235 = getelementptr %"compiler/parse:NameList", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l108, !tbaa !27
  %t237 = load i64, ptr %l5, !tbaa !24
  %t239 = sub i64 %t237, 1
  %t241 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  %t245 = load %"compiler/source:Span", ptr %l14
  %t250 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %t231, ptr %t232, i32 %t244, %"compiler/source:Span" %t245)
  store ptr %t250, ptr %l113
  br label %bb44
bb44:
  store { i64, [5 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 0
  store i64 1, ptr %t252
  %t253 = load %"compiler/source:Span", ptr %l104
  %t254 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t253, 0
  %t255 = load ptr, ptr %l113, !tbaa !29
  %t256 = insertvalue { %"compiler/source:Span", ptr } %t254, ptr %t255, 1
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t256, ptr %t257
  %t258 = load { i64, [5 x i64] }, ptr %t251
  %t260 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t258, ptr %t260
  %t262 = insertvalue { i32, ptr } zeroinitializer, ptr %t260, 1
  store { i32, ptr } %t262, ptr %rv
  br label %ret
bb45:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l117
  br label %bb46
bb46:
  %t266 = load %"compiler/source:Span", ptr %l4
  %t267 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 0
  store i64 1, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t266, 0
  %t273 = insertvalue { %"compiler/source:Span", ptr } %t271, ptr %t267, 1
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t273, ptr %t274
  %t275 = load { i64, [5 x i64] }, ptr %t268
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t275, ptr %t277
  %t279 = insertvalue { i32, ptr } zeroinitializer, ptr %t277, 1
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb47:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l123
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb49, label %ok.284
ok.284:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t285 = load i32, ptr %l123, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  %t295 = insertvalue { i32, ptr } zeroinitializer, i32 %t293, 0
  store { i32, ptr } %t295, ptr %rv
  br label %ret
bb50:
  %t296 = load %"compiler/source:Span", ptr %l4
  %t297 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 0
  store i64 1, ptr %t299
  %t301 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t296, 0
  %t303 = insertvalue { %"compiler/source:Span", ptr } %t301, ptr %t297, 1
  %t304 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t303, ptr %t304
  %t305 = load { i64, [5 x i64] }, ptr %t298
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t305, ptr %t307
  %t309 = insertvalue { i32, ptr } zeroinitializer, ptr %t307, 1
  store { i32, ptr } %t309, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2eisAssignOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 58 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 61 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 62 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 63 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 64 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb12:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 65 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 66 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 67 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 68 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 69 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb24:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 70 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb29
bb29:
  %t56 = load i1, ptr %l1, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94ee529efe0ddf52_d9208d758fca575e)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOperandEndTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 89 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 91 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 2 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 3 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 6 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0
  %t44 = trunc i64 7 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOrdering(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 77 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 78 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 79 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 80 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 9 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr @.d8 }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb31
bb4:
  %t8 = load i32, ptr %l0
  %t10 = trunc i64 24 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l0
  %t15 = trunc i64 25 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 6, ptr @.d9 }, ptr %l10, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  br label %bb31
bb10:
  %t20 = load i32, ptr %l0
  %t22 = trunc i64 30 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr @.d10 }, ptr %l14, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %l1, !tbaa !27
  br label %bb31
bb14:
  %t27 = load i32, ptr %l0
  %t29 = trunc i64 92 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 30, ptr @.d11 }, ptr %l18, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb31
bb18:
  %t34 = load i32, ptr %l0
  %t36 = trunc i64 15 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 6, ptr @.d12 }, ptr %l22, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l1, !tbaa !27
  br label %bb31
bb22:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 17 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 7, ptr @.d13 }, ptr %l26, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr @.d14 }, ptr %l28, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t48, ptr %l1, !tbaa !27
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6)
  unreachable
bb31:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l30, !tbaa !24
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t63, ptr %l1, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l28
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  br label %bb73
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t29 = load ptr, ptr %l30, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32 }, ptr %t39, i32 0, i32 0
  %t41 = load %"compiler/source:Span", ptr %t40
  store %"compiler/source:Span" %t41, ptr %l4
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %l36, !tbaa !27
  %t44 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l40, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l41, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb15:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l41, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb17:
  %t65 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = getelementptr i8, ptr %t66, i64 %t67
  %t70 = sub i64 %t68, %t67
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = extractvalue { i64, ptr } %t72, 0
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t74, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l19, !tbaa !27
  br label %bb73
bb18:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t96, { i64, ptr } %t97)
  store { i64, ptr } %t101, ptr %l56
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t102, ptr %l19, !tbaa !27
  br label %bb73
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load i32, ptr %l6
  %t126 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t124)
  store { i64, ptr } %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s6, ptr %t127, ptr %t128, { i64, ptr } %t129)
  store { i64, ptr } %t133, ptr %l70
  br label %bb33
bb33:
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  store { i64, ptr } %t156, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t159 = load ptr, ptr %l72, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l72, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 5
  store i1 %t165, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l73, !tbaa !21
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l8
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t181, i32 0, i32 3
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load i32, ptr %l8
  %t187 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t185)
  store { i64, ptr } %t187, ptr %l83
  br label %bb40
bb40:
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t188, ptr %t189, { i64, ptr } %t190)
  store { i64, ptr } %t194, ptr %l87
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t195, ptr %t196, { i64, ptr } %t197)
  store { i64, ptr } %t201, ptr %l91
  br label %bb42
bb42:
  %t202 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t204 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t202, i64 %t203)
  %t226 = getelementptr i8, ptr %t225, i64 %t203
  call void @olang_textcopy(ptr %t226, ptr %t205, i64 %t206)
  %t227 = getelementptr i8, ptr %t226, i64 %t206
  call void @olang_textcopy(ptr %t227, ptr %t208, i64 %t209)
  %t228 = getelementptr i8, ptr %t227, i64 %t209
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t215, i64 %t216)
  %t230 = getelementptr i8, ptr %t229, i64 %t216
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t225, 1
  store { i64, ptr } %t233, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb43:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t236 = load ptr, ptr %l93, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l93, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 7
  store i1 %t242, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t243 = load i1, ptr %l94, !tbaa !21
  br i1 %t243, label %bb46, label %bb47
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/ast:Chain", ptr %t250, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } { i64 7, ptr @.d22 }, 1
  %t257 = extractvalue { i64, ptr } { i64 7, ptr @.d22 }, 0
  %t259 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t260 = add i64 %t257, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t256, i64 %t257)
  %t265 = getelementptr i8, ptr %t264, i64 %t257
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t255)
  %t267 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t267, ptr %t261, i64 %t262)
  %t268 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t264, 1
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  br label %bb73
bb49:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t272 = load ptr, ptr %l103, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb50, label %bb51
bb50:
  %t275 = load ptr, ptr %l103, !tbaa !29
  %t276 = load i64, ptr %t275
  %t278 = icmp eq i64 %t276, 8
  store i1 %t278, ptr %l104, !tbaa !21
  br label %bb51
bb51:
  %t279 = load i1, ptr %l104, !tbaa !21
  br i1 %t279, label %bb52, label %bb53
bb52:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l12, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l13, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t294, i32 0, i32 3
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l14, !tbaa !29
  br label %bb54
bb53:
  br label %bb58
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t298, ptr %t299, { i64, ptr } %t300)
  store { i64, ptr } %t304, ptr %l116
  br label %bb55
bb55:
  %t305 = load ptr, ptr %l12, !tbaa !29
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t305, ptr %t306, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l120
  br label %bb56
bb56:
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t318 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t312, ptr %t313, { i64, ptr } %t314)
  store { i64, ptr } %t318, ptr %l124
  br label %bb57
bb57:
  %t319 = extractvalue { i64, ptr } { i64 4, ptr @.d24 }, 1
  %t320 = extractvalue { i64, ptr } { i64 4, ptr @.d24 }, 0
  %t321 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t334 = add i64 %t331, %t333
  %t335 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t319, i64 %t320)
  %t343 = getelementptr i8, ptr %t342, i64 %t320
  call void @olang_textcopy(ptr %t343, ptr %t322, i64 %t323)
  %t344 = getelementptr i8, ptr %t343, i64 %t323
  call void @olang_textcopy(ptr %t344, ptr %t325, i64 %t326)
  %t345 = getelementptr i8, ptr %t344, i64 %t326
  call void @olang_textcopy(ptr %t345, ptr %t329, i64 %t330)
  %t346 = getelementptr i8, ptr %t345, i64 %t330
  call void @olang_textcopy(ptr %t346, ptr %t332, i64 %t333)
  %t347 = getelementptr i8, ptr %t346, i64 %t333
  call void @olang_textcopy(ptr %t347, ptr %t336, i64 %t337)
  %t348 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t348, ptr %t339, i64 %t340)
  %t349 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t342, 1
  store { i64, ptr } %t350, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb73
bb58:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t353 = load ptr, ptr %l126, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb59, label %bb60
bb59:
  %t356 = load ptr, ptr %l126, !tbaa !29
  %t357 = load i64, ptr %t356
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l127, !tbaa !21
  br label %bb60
bb60:
  %t360 = load i1, ptr %l127, !tbaa !21
  br i1 %t360, label %bb61, label %bb62
bb61:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l15, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370
  store { i64, ptr } %t371, ptr %l16, !tbaa !27
  br label %bb63
bb62:
  br label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t373 = load ptr, ptr %l15, !tbaa !29
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t373, ptr %t374, { i64, ptr } %t375)
  store { i64, ptr } %t379, ptr %l137
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } { i64 6, ptr @.d28 }, 1
  %t384 = extractvalue { i64, ptr } { i64 6, ptr @.d28 }, 0
  %t385 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 0
  %t391 = add i64 %t388, %t390
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t394 = add i64 %t391, %t393
  %t395 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t397 = add i64 %t394, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t383, i64 %t384)
  %t399 = getelementptr i8, ptr %t398, i64 %t384
  call void @olang_textcopy(ptr %t399, ptr %t386, i64 %t387)
  %t400 = getelementptr i8, ptr %t399, i64 %t387
  call void @olang_textcopy(ptr %t400, ptr %t389, i64 %t390)
  %t401 = getelementptr i8, ptr %t400, i64 %t390
  %t402 = call i64 @__olang_fmt_i64(ptr %t401, i64 %t382)
  %t403 = getelementptr i8, ptr %t401, i64 %t393
  call void @olang_textcopy(ptr %t403, ptr %t395, i64 %t396)
  %t404 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t398, 1
  store { i64, ptr } %t405, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb65:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t408 = load ptr, ptr %l141, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb66, label %bb67
bb66:
  %t411 = load ptr, ptr %l141, !tbaa !29
  %t412 = load i64, ptr %t411
  %t414 = icmp eq i64 %t412, 14
  store i1 %t414, ptr %l142, !tbaa !21
  br label %bb67
bb67:
  %t415 = load i1, ptr %l142, !tbaa !21
  br i1 %t415, label %bb68, label %bb69
bb68:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t418, i32 0, i32 1
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l17, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t424, i32 0, i32 2
  %t426 = load { i64, ptr }, ptr %t425
  store { i64, ptr } %t426, ptr %l18, !tbaa !27
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t428 = load ptr, ptr %l17, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t434 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s16, ptr %t428, ptr %t429, { i64, ptr } %t430)
  store { i64, ptr } %t434, ptr %l152
  br label %bb71
bb71:
  %t435 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } { i64 9, ptr @.d31 }, 1
  %t439 = extractvalue { i64, ptr } { i64 9, ptr @.d31 }, 0
  %t440 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t445 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t446 = add i64 %t443, %t445
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t437)
  %t449 = add i64 %t446, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t438, i64 %t439)
  %t454 = getelementptr i8, ptr %t453, i64 %t439
  call void @olang_textcopy(ptr %t454, ptr %t441, i64 %t442)
  %t455 = getelementptr i8, ptr %t454, i64 %t442
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  %t457 = call i64 @__olang_fmt_i64(ptr %t456, i64 %t437)
  %t458 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t458, ptr %t450, i64 %t451)
  %t459 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t453, 1
  store { i64, ptr } %t460, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb73
bb72:
  store { i64, ptr } { i64 4, ptr @.d34 }, ptr %l156, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t462, ptr %l19, !tbaa !27
  br label %bb73
bb73:
  %t464 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l158, !tbaa !24
  %t466 = load i64, ptr %l158, !tbaa !24
  %t467 = mul i64 %t466, 1
  %t468 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l159, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = load i64, ptr %l158, !tbaa !24
  %t476 = mul i64 %t475, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t472, ptr %t474, i64 %t476, i1 false)
  %t477 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t477, ptr %l19, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca %"compiler/source:Source"
  %l4 = alloca %"compiler/source:Names"
  %l5 = alloca %"compiler/parse:Oracle"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca i64
  %l12 = alloca %"compiler/scan:Tokens"
  %l13 = alloca %"compiler/parse:Parser"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca %"compiler/diag:Said"
  %l39 = alloca %"compiler/source:Source"
  %l40 = alloca %"compiler/source:Names"
  %l41 = alloca %"compiler/parse:Oracle"
  %l43 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l61 = alloca %"compiler/diag:Diagnostics"
  %l65 = alloca i64
  %l67 = alloca %"compiler/scan:Tokens"
  %l74 = alloca %"compiler/parse:Parser"
  %l76 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/text:StringBuilder"
  %l87 = alloca { i64, ptr }
  %l91 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca i1
  %l137 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca i1
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l167 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l180 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l182 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l195 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t47 = alloca %"compiler/diag:Diagnostics", align 8
  %t63 = alloca %"compiler/parse:Parser", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 7, ptr @.d35 }, { i64, ptr } %a0)
  store %"compiler/source:Source" %t3, ptr %l39
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Source", ptr %l39
  store %"compiler/source:Source" %t4, ptr %l3
  %t5 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t5, ptr %l40
  br label %bb2
bb2:
  %t6 = load %"compiler/source:Names", ptr %l40
  store %"compiler/source:Names" %t6, ptr %l4
  %t7 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %s0)
  store %"compiler/parse:Oracle" %t7, ptr %l41
  br label %bb3
bb3:
  %t8 = load %"compiler/parse:Oracle", ptr %l41
  store %"compiler/parse:Oracle" %t8, ptr %l5
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s1, { i64, ptr } %a1, { i64, ptr } { i64 1, ptr @.d36 })
  store { i64, ptr } %t11, ptr %l43
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l50, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %t29, i64 %t26
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %s0, ptr %s0, ptr %s3, ptr %v1, ptr %l5, ptr %l4, { i64, ptr } { i64 0, ptr @.d37 }, { i64, ptr } %t39)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb5
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t47, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t47, i64 200, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l61, i64 200, i1 false)
  %t48 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t49, { i64, ptr } %t51, i1 false)
  store i64 %t55, ptr %l65
  br label %bb16
bb16:
  %t56 = load i64, ptr %l65, !tbaa !24
  store i64 %t56, ptr %l11, !tbaa !24
  %t57 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t58)
  store %"compiler/scan:Tokens" %t60, ptr %l67
  br label %bb17
bb17:
  %t61 = load %"compiler/scan:Tokens", ptr %l67
  store %"compiler/scan:Tokens" %t61, ptr %l12
  %t62 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t63, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l3, ptr %l12, ptr %l4, ptr %l5, ptr %l10, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t63, i64 272, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l74, i64 272, i1 false)
  %t71 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %l13)
  store { i64, ptr } %t71, ptr %l76
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  br i1 %a2, label %bb20, label %bb21
bb20:
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %s0, ptr %l10)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t76 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t76, ptr %l79
  br label %bb24
bb24:
  %t77 = load %"std/prelude/text:StringBuilder", ptr %l79
  store %"std/prelude/text:StringBuilder" %t77, ptr %l15
  %t78 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t78, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t84 = load i64, ptr %l17, !tbaa !24
  %t85 = load i64, ptr %l18, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb83
bb27:
  br label %bb28
bb28:
  %t92 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t92, ptr %l87, !tbaa !27
  %t93 = load i64, ptr %l17, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l19, !tbaa !29
  %t101 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l15)
  store i64 %t101, ptr %l91
  br label %bb29
bb29:
  %t102 = load i64, ptr %l91, !tbaa !24
  %t103 = icmp sgt i64 %t102, 0
  br i1 %t103, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l15, { i64, ptr } { i64 2, ptr @.d38 })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l19, !tbaa !29
  store ptr %t106, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t107 = load ptr, ptr %l94, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l94, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l95, !tbaa !21
  br label %bb35
bb35:
  %t114 = load i1, ptr %l95, !tbaa !21
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t115 = load ptr, ptr %l19, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { ptr }, ptr %t117, i32 0, i32 0
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l20, !tbaa !29
  br label %bb38
bb37:
  br label %bb53
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l15, ptr %l100, !tbaa !29
  %t121 = load ptr, ptr %l20, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t124)
  store { i64, ptr } %t127, ptr %l104
  br label %bb39
bb39:
  %t128 = extractvalue { i64, ptr } { i64 3, ptr @.d39 }, 1
  %t129 = extractvalue { i64, ptr } { i64 3, ptr @.d39 }, 0
  %t130 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = getelementptr i8, ptr %t138, i64 %t132
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t137, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t149, { i64, ptr } %t148)
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l20, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Func", ptr %t151, i32 0, i32 6
  %t154 = load i1, ptr %t153, !tbaa !21
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l15, { i64, ptr } { i64 2, ptr @.d41 })
  br label %bb43
bb42:
  %t159 = load ptr, ptr %l20, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Func", ptr %t159, i32 0, i32 4
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l23, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb44:
  store %olang.scope zeroinitializer, ptr %s14
  %t168 = load i64, ptr %l22, !tbaa !24
  %t169 = load i64, ptr %l23, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s14)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t176 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t176, ptr %l119, !tbaa !27
  %t177 = load i64, ptr %l22, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr ptr, ptr %t180, i64 %t177
  %t182 = load ptr, ptr %t181, !tbaa !39
  store ptr %l15, ptr %l122, !tbaa !29
  %t185 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t190 = call { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %s0, ptr %s0, ptr %s0, ptr %s14, ptr %t182, ptr %l4, { i64, ptr } %t186)
  store { i64, ptr } %t190, ptr %l126
  br label %bb48
bb48:
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t193 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t191, i64 %t192)
  %t198 = getelementptr i8, ptr %t197, i64 %t192
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = extractvalue { i64, ptr } %t200, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t208 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t208, { i64, ptr } %t207)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s14)
  br label %bb50
bb50:
  %t210 = load i64, ptr %l22, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l22, !tbaa !24
  br label %bb44
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb81
bb53:
  %t214 = load ptr, ptr %l19, !tbaa !29
  store ptr %t214, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t215 = load ptr, ptr %l131, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb54, label %bb55
bb54:
  %t218 = load ptr, ptr %l131, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 2
  store i1 %t221, ptr %l132, !tbaa !21
  br label %bb55
bb55:
  %t222 = load i1, ptr %l132, !tbaa !21
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t223 = load ptr, ptr %l19, !tbaa !29
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l25, !tbaa !29
  br label %bb58
bb57:
  br label %bb79
bb58:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l15, ptr %l137, !tbaa !29
  %t229 = load ptr, ptr %l25, !tbaa !29
  %t231 = getelementptr %"compiler/ast:TypeDecl", ptr %t229, i32 0, i32 0
  %t232 = load i32, ptr %t231, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t232)
  store { i64, ptr } %t235, ptr %l141
  br label %bb59
bb59:
  %t236 = extractvalue { i64, ptr } { i64 5, ptr @.d43 }, 1
  %t237 = extractvalue { i64, ptr } { i64 5, ptr @.d43 }, 0
  %t238 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = add i64 %t237, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t236, i64 %t237)
  %t243 = getelementptr i8, ptr %t242, i64 %t237
  call void @olang_textcopy(ptr %t243, ptr %t239, i64 %t240)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t242, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = extractvalue { i64, ptr } %t245, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t253 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t253, { i64, ptr } %t252)
  br label %bb60
bb60:
  %t255 = load ptr, ptr %l25, !tbaa !29
  %t257 = getelementptr %"compiler/ast:TypeDecl", ptr %t255, i32 0, i32 3
  %t258 = load ptr, ptr %t257, !tbaa !29
  store ptr %t258, ptr %l26, !tbaa !29
  %t260 = load ptr, ptr %l26, !tbaa !29
  store ptr %t260, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t261 = load ptr, ptr %l146, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb61, label %bb62
bb61:
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = load i64, ptr %t264
  %t267 = icmp eq i64 %t265, 2
  store i1 %t267, ptr %l147, !tbaa !21
  br label %bb62
bb62:
  %t268 = load i1, ptr %l147, !tbaa !21
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t269 = load ptr, ptr %l26, !tbaa !29
  %t271 = getelementptr { i64, [6 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t271, i32 0, i32 0
  %t273 = load { i64, ptr }, ptr %t272
  store { i64, ptr } %t273, ptr %l27, !tbaa !27
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t275 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t275, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  store i64 %t279, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s21
  %t281 = load i64, ptr %l29, !tbaa !24
  %t282 = load i64, ptr %l30, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s21)
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t289 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t289, ptr %l159, !tbaa !27
  %t290 = load i64, ptr %l29, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr ptr, ptr %t293, i64 %t290
  %t295 = load ptr, ptr %t294, !tbaa !39
  store ptr %t295, ptr %l31, !tbaa !29
  store ptr %l15, ptr %l162, !tbaa !29
  %t297 = load ptr, ptr %l31, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Func", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 4, ptr @.d44 }, ptr %l167, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr @.d45 }, ptr %l167, !tbaa !27
  br label %bb72
bb72:
  %t306 = load ptr, ptr %l31, !tbaa !29
  %t308 = getelementptr %"compiler/ast:Func", ptr %t306, i32 0, i32 2
  %t309 = load i32, ptr %t308, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t309)
  store { i64, ptr } %t312, ptr %l171
  br label %bb73
bb73:
  %t313 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t315 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t313, i64 %t314)
  %t324 = getelementptr i8, ptr %t323, i64 %t314
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = getelementptr i8, ptr %t324, i64 %t317
  call void @olang_textcopy(ptr %t325, ptr %t320, i64 %t321)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t323, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = extractvalue { i64, ptr } %t327, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  %t335 = load ptr, ptr %l162, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t335, { i64, ptr } %t334)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s21)
  br label %bb75
bb75:
  %t337 = load i64, ptr %l29, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l29, !tbaa !24
  br label %bb66
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb81
bb79:
  store %olang.scope zeroinitializer, ptr %s25
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %l15, { i64, ptr } { i64 4, ptr @.d47 })
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s25)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s7)
  br label %bb82
bb82:
  %t342 = load i64, ptr %l17, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l17, !tbaa !24
  br label %bb25
bb83:
  store %olang.scope zeroinitializer, ptr %s27
  %t347 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s27, ptr %l10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t347, ptr %l180
  br label %bb84
bb84:
  %t348 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  %t349 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t349
  store ptr %t349, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s28
  %t351 = load ptr, ptr %l32, !tbaa !29
  %t352 = load i64, ptr %l33, !tbaa !24
  %t355 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %s27, ptr %t351, i64 %t352)
  %t356 = extractvalue { i32, { i64, ptr } } %t355, 1
  %t357 = extractvalue { i32, { i64, ptr } } %t355, 0
  store i32 %t357, ptr %l186
  %t358 = icmp ne i32 %t357, 0
  br i1 %t358, label %bb87, label %ok.359
ok.359:
  store { i64, ptr } %t356, ptr %l185
  br label %bb86
bb86:
  %t360 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t360, ptr %l182, !tbaa !27
  br label %bb91
bb87:
  %t361 = load i32, ptr %l186, !tbaa !23
  %t362 = ashr i32 %t361, 16
  %t364 = icmp eq i32 %t362, 1
  br i1 %t364, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_eccdd3ba5e570728_ba1962c6d7fecaac)
  unreachable
bb90:
  call void @__olang_scope_close(ptr %s28)
  br label %bb100
bb91:
  %t366 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t366, ptr %l34, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t367, 0
  store i64 %t369, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s29
  %t371 = load i64, ptr %l36, !tbaa !24
  %t372 = load i64, ptr %l35, !tbaa !24
  %t375 = icmp slt i64 %t371, %t372
  %t377 = xor i1 %t375, true
  br i1 %t377, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s29)
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t379 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t379, ptr %l195, !tbaa !27
  %t380 = load i64, ptr %l36, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr %"compiler/diag:Said", ptr %t383, i64 %t380
  %t385 = load %"compiler/diag:Said", ptr %t384
  store %"compiler/diag:Said" %t385, ptr %l37
  %t387 = getelementptr %"compiler/diag:Said", ptr %l37, i32 0, i32 0
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  %t389 = extractvalue { i64, ptr } { i64 2, ptr @.d48 }, 1
  %t390 = extractvalue { i64, ptr } { i64 2, ptr @.d48 }, 0
  %t392 = extractvalue { i64, ptr } %t388, 1
  %t393 = extractvalue { i64, ptr } %t388, 0
  %t394 = add i64 %t390, %t393
  %t395 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t394)
  call void @olang_textcopy(ptr %t395, ptr %t389, i64 %t390)
  %t396 = getelementptr i8, ptr %t395, i64 %t390
  call void @olang_textcopy(ptr %t396, ptr %t392, i64 %t393)
  %t397 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t395, 1
  %t400 = extractvalue { i64, ptr } %t398, 0
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = mul i64 %t400, 1
  %t403 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s29, ptr %l15, { i64, ptr } %t405)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s29)
  br label %bb97
bb97:
  %t408 = load i64, ptr %l36, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l36, !tbaa !24
  br label %bb92
bb98:
  %t412 = load i64, ptr %l33, !tbaa !24
  %t413 = load i64, ptr %l35, !tbaa !24
  %t416 = add i64 %t412, %t413
  store i64 %t416, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb99
bb99:
  br label %bb85
bb100:
  call void @__olang_scope_close(ptr %s27)
  %t419 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l15)
  store { i64, ptr } %t419, ptr %l208
  br label %bb101
bb101:
  %t420 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t420, ptr %l209, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l210, !tbaa !24
  %t423 = load i64, ptr %l210, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l211, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l210, !tbaa !24
  %t433 = mul i64 %t432, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t434, ptr %l209, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t435 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t435, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/parse:NameList"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/parse:NameList" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/parse:NameList" %t6, { i64, ptr } %a1, 1
  store %"compiler/parse:NameList" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:NameList", ptr %rv
  ret %"compiler/parse:NameList" %rr
}

define dso_local void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"compiler/parse:Parser"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l6, !tbaa !29
  store ptr %a1, ptr %l7, !tbaa !29
  store ptr %a2, ptr %l8, !tbaa !29
  store ptr %a3, ptr %l9, !tbaa !29
  store ptr %a4, ptr %l10, !tbaa !29
  store i64 %a5, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i32 0, ptr %l13
  store i32 0, ptr %l14, !tbaa !23
  store i32 0, ptr %l15
  store i32 0, ptr %l16, !tbaa !23
  store i1 false, ptr %l17, !tbaa !21
  store i1 false, ptr %l18, !tbaa !21
  store i1 false, ptr %l19, !tbaa !21
  store i1 false, ptr %l20, !tbaa !21
  store i64 0, ptr %l21, !tbaa !24
  store i1 false, ptr %l22, !tbaa !21
  store i1 false, ptr %l23, !tbaa !21
  store i64 0, ptr %l24, !tbaa !24
  store i1 false, ptr %l25, !tbaa !21
  store i64 -1, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i32 -1, ptr %l28, !tbaa !23
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t15)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l54
  br label %bb1
bb1:
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l29
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l55
  br label %bb2
bb2:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l30
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %t21)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l56
  br label %bb3
bb3:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l31
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l57
  br label %bb4
bb4:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l32
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l58
  br label %bb5
bb5:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l33
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l59
  br label %bb6
bb6:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l34
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l60
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l35
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l61
  br label %bb8
bb8:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l36
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l62
  br label %bb9
bb9:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l37
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t42)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l63
  br label %bb10
bb10:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l38
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l64
  br label %bb11
bb11:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l39
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e(ptr %t48)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l65
  br label %bb12
bb12:
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l40
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l66
  br label %bb13
bb13:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l41
  %t54 = icmp sge i64 0, 0
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = icmp sle i64 0, 1152921504606846975
  br i1 %t56, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb16:
  %t58 = mul i64 0, 8
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v5, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l42, !tbaa !27
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t63)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l70
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb18:
  %t65 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l43
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t66)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l71
  br label %bb19
bb19:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l44
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t69)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l72
  br label %bb20
bb20:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  %t72 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 0
  %t73 = load ptr, ptr %l6, !tbaa !29
  store ptr %t73, ptr %t72, !tbaa !29
  %t74 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 1
  %t75 = load ptr, ptr %l7, !tbaa !29
  store ptr %t75, ptr %t74, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 2
  %t77 = load ptr, ptr %l8, !tbaa !29
  store ptr %t77, ptr %t76, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 3
  %t79 = load ptr, ptr %l9, !tbaa !29
  store ptr %t79, ptr %t78, !tbaa !29
  %t80 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 4
  %t81 = load ptr, ptr %l10, !tbaa !29
  store ptr %t81, ptr %t80, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 5
  %t83 = load i64, ptr %l11, !tbaa !24
  store i64 %t83, ptr %t82, !tbaa !24
  %t84 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 6
  %t85 = load i64, ptr %l12, !tbaa !24
  store i64 %t85, ptr %t84, !tbaa !24
  %t86 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 7
  %t87 = load i32, ptr %l13
  store i32 %t87, ptr %t86
  %t88 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 8
  %t89 = load i32, ptr %l14, !tbaa !23
  store i32 %t89, ptr %t88, !tbaa !23
  %t90 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 9
  %t91 = load i32, ptr %l15
  store i32 %t91, ptr %t90
  %t92 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 10
  %t93 = load i32, ptr %l16, !tbaa !23
  store i32 %t93, ptr %t92, !tbaa !23
  %t94 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 11
  %t95 = load i1, ptr %l17, !tbaa !21
  store i1 %t95, ptr %t94, !tbaa !21
  %t96 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 12
  %t97 = load i1, ptr %l18, !tbaa !21
  store i1 %t97, ptr %t96, !tbaa !21
  %t98 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 13
  %t99 = load i1, ptr %l19, !tbaa !21
  store i1 %t99, ptr %t98, !tbaa !21
  %t100 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 14
  %t101 = load i1, ptr %l20, !tbaa !21
  store i1 %t101, ptr %t100, !tbaa !21
  %t102 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 15
  %t103 = load i64, ptr %l21, !tbaa !24
  store i64 %t103, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 16
  %t105 = load i1, ptr %l22, !tbaa !21
  store i1 %t105, ptr %t104, !tbaa !21
  %t106 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 17
  %t107 = load i1, ptr %l23, !tbaa !21
  store i1 %t107, ptr %t106, !tbaa !21
  %t108 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 18
  %t109 = load i64, ptr %l24, !tbaa !24
  store i64 %t109, ptr %t108, !tbaa !24
  %t110 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 19
  %t111 = load i1, ptr %l25, !tbaa !21
  store i1 %t111, ptr %t110, !tbaa !21
  %t112 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 20
  %t113 = load i64, ptr %l26, !tbaa !24
  store i64 %t113, ptr %t112, !tbaa !24
  %t114 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 21
  %t115 = load i1, ptr %l27, !tbaa !21
  store i1 %t115, ptr %t114, !tbaa !21
  %t116 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 22
  %t117 = load i32, ptr %l28, !tbaa !23
  store i32 %t117, ptr %t116, !tbaa !23
  %t118 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 23
  %t119 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %t118
  %t120 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 24
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %t120
  %t122 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 25
  %t123 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %t122
  %t124 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 26
  %t125 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %t124
  %t126 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 27
  %t127 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %t126
  %t128 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 28
  %t129 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t128
  %t130 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 29
  %t131 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %t130
  %t132 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 30
  %t133 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %t132
  %t134 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 31
  %t135 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %t134
  %t136 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 32
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %t136
  %t138 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 33
  %t139 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %t138
  %t140 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 34
  %t141 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %t140
  %t142 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 35
  %t143 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %t142
  %t144 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 36
  %t145 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t145, ptr %t144, !tbaa !27
  %t146 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 37
  %t147 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %t146
  %t148 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 38
  %t149 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %t148
  %t150 = getelementptr %"compiler/parse:Parser", ptr %l73, i32 0, i32 39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t150
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l73, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [44 x i8] c"an element type before the [, as in I32[...]"
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d1 = private constant [13 x i8] c"an expression"
@.d2 = private constant [6 x i8] c"a name"
@.d3 = private constant [5 x i8] c"(...)"
@.d4 = private constant [6 x i8] c"a name"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant [6 x i8] c"a name"
@.d6 = private constant [6 x i8] c"a type"
@.d7 = private constant [4 x i8] c"mut "
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant [5 x i8] c"an if"
@.d9 = private constant [6 x i8] c"a loop"
@.d10 = private constant [7 x i8] c"a match"
@.d11 = private constant [30 x i8] c"a block (a block takes no ':')"
@.d12 = private constant [6 x i8] c"a join"
@.d13 = private constant [7 x i8] c"a defer"
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [1 x i8] c"("
@.d16 = private constant [1 x i8] c" "
@.d17 = private constant [1 x i8] c")"
@.d18 = private constant [1 x i8] c"("
@.d19 = private constant [1 x i8] c" "
@.d20 = private constant [1 x i8] c" "
@.d21 = private constant [1 x i8] c")"
@.d22 = private constant [7 x i8] c"(chain "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d23 = private constant [1 x i8] c")"
@.d24 = private constant [4 x i8] c"(if "
@.d25 = private constant [1 x i8] c" "
@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [1 x i8] c")"
@.d28 = private constant [6 x i8] c"(call "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [1 x i8] c")"
@.d31 = private constant [9 x i8] c"(generic "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [1 x i8] c")"
@.d34 = private constant [4 x i8] c"expr"
@.d35 = private constant [7 x i8] c"t.olang"
@.d36 = private constant [1 x i8] c" "
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [2 x i8] c"; "
@.d39 = private constant [3 x i8] c"fn "
@.d40 = private constant [1 x i8] c":"
@.d41 = private constant [2 x i8] c" -"
@.d42 = private constant [1 x i8] c" "
@.d43 = private constant [5 x i8] c"type "
@.d44 = private constant [4 x i8] c"mut "
@.d45 = private constant [0 x i8] c""
@.d46 = private constant [1 x i8] c" "
@.d47 = private constant [4 x i8] c"decl"
@.d48 = private constant [2 x i8] c" !"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eTrunc_Hfb712b28811cab79b22ab4ac00d80504(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2eTrunc_H7d095616a1c9f3bb0e1e9e6638b5e3ec(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eTru_He4c1b4b0580574c1753e0fdf1e83e9c5(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5d5da79af2b44d73_2d4623f2243944cf = external constant [0 x i8]
@olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a = external constant [0 x i8]
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0)
declare %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2)
@olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9 = external constant [0 x i8]
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %a0)
@olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %a0)
declare %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
declare i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2eisJoiningOp(i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %a0)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eTrunc_H4f6d6844736ef1cf1f5d4d22c2fa42e3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eRunFrom_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b436918af3dd5ca0_a9a6bacafc138244 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e7733d3a928e8482_4650af2d2e5452b6 = external constant [0 x i8]
@olang_loc_cbae392aecd52e99_b08c2106788b334d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0)
@olang_loc_2d89971a269bae53_cb14c861cebe6e1f = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0)
declare { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %a0)
@olang_loc_1c373b81de794f63_6badee9759230def = external constant [0 x i8]
declare %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eLe_Hc3a9f67fd4028c52dcd01e744501edd7(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eLe_H079a49ca86fbf0542fec862c08432034(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ePu_H3ee2e85b2a4851b98bd769b1572633fb(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %a0, ptr %a1, i1 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_97d42995c5706fd7_20b731538cf045b = external constant [0 x i8]
@olang_loc_787ae3c3318fe322_f2232752b79280c6 = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0)
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2eTr_H11957549f332e3c31ab4361387fc70e9(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2eTrun_Ha104aa1b1c21542bf8e6309c0c60649a(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTr_H502888c3fa90c24fa361ddb6e04085c1(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eTrunc_H01cd91640f0f0f618951303ec62b73dc(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/msgs:Msg" %a3)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_682b81c4be20c47_acb581c54a6720db = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b08fe5a62583e117_e5b5edd841fa1acb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %a0, i1 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %a0)
@olang_loc_47198c3f9d8413cf_be7184982b6f0763 = external constant [0 x i8]
@olang_loc_4b26d93c159ce468_272ef8e9c938d194 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_31e39d55c126667c_eaaf5fcb81f21700 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4582cd3e20803687_2be8b05c8d066113 = external constant [0 x i8]
@olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e37d10a9f86ee49_f510a1627c721295 = external constant [0 x i8]
@olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53 = external constant [0 x i8]
@olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_94ee529efe0ddf52_d9208d758fca575e = external constant [0 x i8]
@olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6 = external constant [0 x i8]
@olang_loc_95becaa34f722781_c104ec8a8e14f09d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eccdd3ba5e570728_ba1962c6d7fecaac = external constant [0 x i8]
@olang_loc_936bfbc19493319b_da93a9696e3b504f = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
