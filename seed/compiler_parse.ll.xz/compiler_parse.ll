; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Attr" = type { %"compiler/source:Span", ptr, i32 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
@G_2ecompiler_2fparse_2eMaxNesting = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l52 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i32
  %l59 = alloca %"compiler/token:Token"
  %l61 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %l68 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l85 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i32
  %l109 = alloca ptr
  %l118 = alloca i1
  %l120 = alloca %"compiler/source:Span"
  %l122 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i32
  %l132 = alloca ptr
  %l143 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i32
  %l151 = alloca ptr
  %l163 = alloca ptr
  %l170 = alloca i1
  %l175 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l179 = alloca i32
  %l184 = alloca i32
  %l188 = alloca { i64, ptr }
  %s23 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t208 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 92)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l16
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l15
  br label %bb1
bb1:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l12, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l16, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l1, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 17
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 18
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l2, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 19
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 18
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 19
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 30
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l32
  br label %bb4
bb4:
  %t59 = load i64, ptr %l32, !tbaa !24
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 93)
  store i1 %t63, ptr %l35
  br label %bb6
bb6:
  %t64 = load i1, ptr %l35, !tbaa !21
  %t65 = xor i1 %t64, true
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb7, label %bb8
bb7:
  br label %bb64
bb8:
  br label %bb9
bb9:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 44)
  store i1 %t72, ptr %l40
  br label %bb10
bb10:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t74)
  store i32 %t76, ptr %l42
  br label %bb13
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t77, i32 1)
  store i1 %t80, ptr %l52
  br label %bb16
bb13:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t82, i32 0, i32 30
  store ptr %t84, ptr %l44, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t85, i32 %t81)
  store %"compiler/source:Span" %t89, ptr %l47
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 25, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l47
  %t93 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t92, 0
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span" } %t93, ptr %t94
  %t95 = load { i64, [4 x i64] }, ptr %t90
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t95, ptr %t97
  %t98 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t98, ptr %t97)
  br label %bb15
bb15:
  br label %bb54
bb16:
  %t100 = load i1, ptr %l52, !tbaa !21
  br i1 %t100, label %bb17, label %bb18
bb17:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t101, i64 1)
  store i32 %t103, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t104 = load i32, ptr %l55, !range !{i32 0, i32 98}
  %t106 = trunc i64 62 to i32
  %t107 = icmp eq i32 %t104, %t106
  store i1 %t107, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i1, ptr %l53, !tbaa !21
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t110)
  store %"compiler/token:Token" %t112, ptr %l59
  br label %bb23
bb22:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t113)
  %t116 = extractvalue { i32, ptr } %t115, 1
  %t117 = extractvalue { i32, ptr } %t115, 0
  store i32 %t117, ptr %l105
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb38, label %ok.119, !prof !99
ok.119:
  store ptr %t116, ptr %l104
  br label %bb37
bb23:
  %t120 = getelementptr %"compiler/token:Token", ptr %l59, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  store i32 %t121, ptr %l6, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t123)
  %t126 = extractvalue { i32, i32 } %t125, 1
  %t127 = extractvalue { i32, i32 } %t125, 0
  store i32 %t127, ptr %l64
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb25, label %ok.129, !prof !99
ok.129:
  store i32 %t126, ptr %l63
  br label %bb24
bb24:
  %t130 = load i32, ptr %l63, !tbaa !23
  store i32 %t130, ptr %l61, !tbaa !23
  br label %bb28
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 30
  %t134 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t133, i64 %t134)
  br label %bb27
bb27:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l68, !tbaa !29
  %t138 = load ptr, ptr %l68, !tbaa !29
  %t139 = getelementptr %"compiler/parse:Parser", ptr %t138, i32 0, i32 17
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = sub i64 %t140, 1
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = getelementptr %"compiler/parse:Parser", ptr %t144, i32 0, i32 17
  store i64 %t142, ptr %t145, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i1, ptr %l2, !tbaa !21
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 18
  store i1 %t147, ptr %t150, !tbaa !21
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i1, ptr %l3, !tbaa !21
  %t155 = getelementptr %"compiler/parse:Parser", ptr %t151, i32 0, i32 19
  store i1 %t152, ptr %t155, !tbaa !21
  %t157 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t157, ptr %rv
  br label %ret
bb28:
  %t158 = load i32, ptr %l61, !tbaa !23
  store i32 %t158, ptr %l7, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t159)
  store i32 %t161, ptr %l77
  br label %bb29
bb29:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t162)
  %t165 = extractvalue { i32, ptr } %t164, 1
  %t166 = extractvalue { i32, ptr } %t164, 0
  store i32 %t166, ptr %l81
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb31, label %ok.168, !prof !99
ok.168:
  store ptr %t165, ptr %l80
  br label %bb30
bb30:
  %t169 = load ptr, ptr %l80, !tbaa !29
  store ptr %t169, ptr %l78, !tbaa !29
  br label %bb34
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/parse:Parser", ptr %t170, i32 0, i32 30
  %t173 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t172, i64 %t173)
  br label %bb33
bb33:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l85, !tbaa !29
  %t177 = load ptr, ptr %l85, !tbaa !29
  %t178 = getelementptr %"compiler/parse:Parser", ptr %t177, i32 0, i32 17
  %t179 = load i64, ptr %t178, !tbaa !24
  %t181 = sub i64 %t179, 1
  %t183 = load ptr, ptr %l85, !tbaa !29
  %t184 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 17
  store i64 %t181, ptr %t184, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i1, ptr %l2, !tbaa !21
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 18
  store i1 %t186, ptr %t189, !tbaa !21
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i1, ptr %l3, !tbaa !21
  %t194 = getelementptr %"compiler/parse:Parser", ptr %t190, i32 0, i32 19
  store i1 %t191, ptr %t194, !tbaa !21
  %t196 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t196, ptr %rv
  br label %ret
bb34:
  %t197 = load ptr, ptr %l78, !tbaa !29
  store ptr %t197, ptr %l8, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t198, i32 0, i32 30
  store ptr %t200, ptr %l94, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l6, !tbaa !23
  %t205 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t201, i32 %t202)
  store %"compiler/source:Span" %t205, ptr %l97
  br label %bb35
bb35:
  %t206 = load i32, ptr %l7, !tbaa !23
  %t207 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 26, ptr %t209
  %t210 = load %"compiler/source:Span", ptr %l97
  %t211 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t210, 0
  %t213 = insertvalue { %"compiler/source:Span", i32, ptr } %t211, i32 %t206, 1
  %t215 = insertvalue { %"compiler/source:Span", i32, ptr } %t213, ptr %t207, 2
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t215, ptr %t216
  %t217 = load { i64, [4 x i64] }, ptr %t208
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t217, ptr %t219
  %t220 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t220, ptr %t219)
  br label %bb36
bb36:
  br label %bb53
bb37:
  %t222 = load ptr, ptr %l104, !tbaa !29
  store ptr %t222, ptr %l102, !tbaa !29
  br label %bb41
bb38:
  br label %bb39
bb39:
  call void @__olang_ert_req_clear()
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/parse:Parser", ptr %t223, i32 0, i32 30
  %t226 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t225, i64 %t226)
  br label %bb40
bb40:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l109, !tbaa !29
  %t230 = load ptr, ptr %l109, !tbaa !29
  %t231 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 17
  %t232 = load i64, ptr %t231, !tbaa !24
  %t234 = sub i64 %t232, 1
  %t236 = load ptr, ptr %l109, !tbaa !29
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 17
  store i64 %t234, ptr %t237, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i1, ptr %l2, !tbaa !21
  %t242 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 18
  store i1 %t239, ptr %t242, !tbaa !21
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i1, ptr %l3, !tbaa !21
  %t247 = getelementptr %"compiler/parse:Parser", ptr %t243, i32 0, i32 19
  store i1 %t244, ptr %t247, !tbaa !21
  %t249 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t249, ptr %rv
  br label %ret
bb41:
  %t250 = load ptr, ptr %l102, !tbaa !29
  store ptr %t250, ptr %l9, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t251)
  store i1 %t253, ptr %l118
  br label %bb42
bb42:
  %t254 = load i1, ptr %l118, !tbaa !21
  br i1 %t254, label %bb43, label %bb44
bb43:
  %t255 = load ptr, ptr %l9, !tbaa !29
  %t257 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t255)
  store %"compiler/source:Span" %t257, ptr %l120
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t258 = getelementptr %"compiler/source:Span", ptr %l120, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l9, !tbaa !29
  %t268 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t261, i32 %t259, ptr null, ptr %t263, i32 93)
  %t269 = extractvalue { i32, ptr } %t268, 1
  %t270 = extractvalue { i32, ptr } %t268, 0
  store i32 %t270, ptr %l128
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb47, label %ok.272, !prof !99
ok.272:
  store ptr %t269, ptr %l127
  br label %bb46
bb46:
  %t273 = load ptr, ptr %l127, !tbaa !29
  store ptr %t273, ptr %l122, !tbaa !29
  br label %bb50
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 30
  %t277 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t276, i64 %t277)
  br label %bb49
bb49:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l132, !tbaa !29
  %t281 = load ptr, ptr %l132, !tbaa !29
  %t282 = getelementptr %"compiler/parse:Parser", ptr %t281, i32 0, i32 17
  %t283 = load i64, ptr %t282, !tbaa !24
  %t285 = sub i64 %t283, 1
  %t287 = load ptr, ptr %l132, !tbaa !29
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 17
  store i64 %t285, ptr %t288, !tbaa !24
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i1, ptr %l2, !tbaa !21
  %t293 = getelementptr %"compiler/parse:Parser", ptr %t289, i32 0, i32 18
  store i1 %t290, ptr %t293, !tbaa !21
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i1, ptr %l3, !tbaa !21
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t294, i32 0, i32 19
  store i1 %t295, ptr %t298, !tbaa !21
  %t300 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t300, ptr %rv
  br label %ret
bb50:
  %t301 = load ptr, ptr %l122, !tbaa !29
  store ptr %t301, ptr %l9, !tbaa !29
  br label %bb51
bb51:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/parse:Parser", ptr %t302, i32 0, i32 30
  %t305 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t304, ptr %t305)
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t311 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t308, i32 93)
  %t312 = extractvalue { i32, i1 } %t311, 1
  %t313 = extractvalue { i32, i1 } %t311, 0
  store i32 %t313, ptr %l147
  %t314 = icmp ne i32 %t313, 0
  br i1 %t314, label %bb56, label %ok.315, !prof !99
ok.315:
  store i1 %t312, ptr %l146
  br label %bb55
bb55:
  %t316 = load i1, ptr %l146, !tbaa !21
  store i1 %t316, ptr %l143, !tbaa !21
  br label %bb59
bb56:
  br label %bb57
bb57:
  call void @__olang_ert_req_clear()
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/parse:Parser", ptr %t317, i32 0, i32 30
  %t320 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t319, i64 %t320)
  br label %bb58
bb58:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l151, !tbaa !29
  %t324 = load ptr, ptr %l151, !tbaa !29
  %t325 = getelementptr %"compiler/parse:Parser", ptr %t324, i32 0, i32 17
  %t326 = load i64, ptr %t325, !tbaa !24
  %t328 = sub i64 %t326, 1
  %t330 = load ptr, ptr %l151, !tbaa !29
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t330, i32 0, i32 17
  store i64 %t328, ptr %t331, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i1, ptr %l2, !tbaa !21
  %t336 = getelementptr %"compiler/parse:Parser", ptr %t332, i32 0, i32 18
  store i1 %t333, ptr %t336, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i1, ptr %l3, !tbaa !21
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t337, i32 0, i32 19
  store i1 %t338, ptr %t341, !tbaa !21
  %t343 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t343, ptr %rv
  br label %ret
bb59:
  %t344 = load i1, ptr %l143, !tbaa !21
  %t347 = xor i1 %t344, true
  br i1 %t347, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb5
bb64:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i1, ptr %l2, !tbaa !21
  %t353 = getelementptr %"compiler/parse:Parser", ptr %t349, i32 0, i32 18
  store i1 %t350, ptr %t353, !tbaa !21
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l163, !tbaa !29
  %t355 = load ptr, ptr %l163, !tbaa !29
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t355, i32 0, i32 17
  %t357 = load i64, ptr %t356, !tbaa !24
  %t359 = sub i64 %t357, 1
  %t361 = load ptr, ptr %l163, !tbaa !29
  %t362 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 17
  store i64 %t359, ptr %t362, !tbaa !24
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i1, ptr %l1, !tbaa !21
  %t367 = getelementptr %"compiler/parse:Parser", ptr %t363, i32 0, i32 11
  store i1 %t364, ptr %t367, !tbaa !21
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t371 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t368, i32 93)
  store i1 %t371, ptr %l170
  br label %bb65
bb65:
  %t372 = load i1, ptr %l170, !tbaa !21
  %t373 = xor i1 %t372, true
  br i1 %t373, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s23
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/parse:Parser", ptr %t375, i32 0, i32 30
  %t378 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t377, i64 %t378)
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l175, !tbaa !29
  %t383 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s23, i32 93)
  store { i64, ptr } %t383, ptr %l177
  br label %bb69
bb69:
  %t384 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t384, 0
  %t386 = extractvalue { i64, ptr } %t384, 1
  %t387 = mul i64 %t385, 1
  %t388 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t388, ptr %t386, i64 %t387, i1 false)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  %t391 = load ptr, ptr %l175, !tbaa !29
  %t393 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s23, ptr %t391, { i64, ptr } %t390)
  store i32 %t393, ptr %l179
  %t394 = icmp ne i32 %t393, 0
  br i1 %t394, label %bb71, label %ok.395, !prof !99
ok.395:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t396 = load i32, ptr %l179, !tbaa !23
  %t397 = lshr i32 %t396, 16
  %t398 = and i32 %t396, 65535
  %t399 = icmp eq i32 %t397, 1
  %t400 = select i1 %t399, i32 1, i32 0
  %t401 = icmp eq i32 %t396, 0
  %t402 = shl i32 %t400, 16
  %t403 = or i32 %t402, %t398
  %t404 = select i1 %t401, i32 0, i32 %t403
  call void @__olang_scope_close(ptr %s23)
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i1, ptr %l3, !tbaa !21
  %t409 = getelementptr %"compiler/parse:Parser", ptr %t405, i32 0, i32 19
  store i1 %t406, ptr %t409, !tbaa !21
  %t411 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t404, 0
  store { i32, { i64, ptr } } %t411, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s23)
  br label %bb73
bb73:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t412)
  store i32 %t414, ptr %l184
  br label %bb74
bb74:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/parse:Parser", ptr %t415, i32 0, i32 30
  %t418 = load i64, ptr %l4, !tbaa !24
  %t421 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t417, i64 %t418)
  store { i64, ptr } %t421, ptr %l188
  br label %bb75
bb75:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i1, ptr %l3, !tbaa !21
  %t426 = getelementptr %"compiler/parse:Parser", ptr %t422, i32 0, i32 19
  store i1 %t423, ptr %t426, !tbaa !21
  %t427 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t428 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t427, 1
  store { i32, { i64, ptr } } %t428, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrRefused(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = getelementptr %"compiler/ast:Attr", ptr %t11, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  store ptr %a0, ptr %l9, !tbaa !29
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l10, !tbaa !23
  %t19 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  store i32 %t20, ptr %l11, !tbaa !23
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrPlace(ptr %s0)
  store %"compiler/msgs:Msg" %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = load i32, ptr %l10, !tbaa !23
  %t24 = load i32, ptr %l11, !tbaa !23
  %t25 = load %"compiler/msgs:Msg", ptr %l12
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s0, ptr %t22, i32 %t23, i32 %t24, %"compiler/msgs:Msg" %t25)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t20, ptr %lp2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %lp2
  store ptr %t21, ptr %t22, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %lp2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t30 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t23, ptr %t25, i64 %a1)
  %t31 = extractvalue { i32, ptr } %t30, 1
  %t32 = extractvalue { i32, ptr } %t30, 0
  store i32 %t32, ptr %l13
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34, !prof !99
ok.34:
  store ptr %t31, ptr %l12
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l12, !tbaa !29
  store ptr %t35, ptr %l8, !tbaa !29
  br label %bb6
bb5:
  %t36 = load i32, ptr %l13, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  %t46 = insertvalue { i32, ptr } zeroinitializer, i32 %t44, 0
  store { i32, ptr } %t46, ptr %rv
  br label %ret
bb6:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t48 = insertvalue { i32, ptr } zeroinitializer, ptr %t47, 1
  store { i32, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l21 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca ptr
  %l46 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l54 = alloca ptr
  %l60 = alloca i1
  %l62 = alloca i32
  %l67 = alloca ptr
  %l75 = alloca i1
  %l79 = alloca ptr
  %l84 = alloca i32
  %l88 = alloca i32
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l111 = alloca ptr
  %l121 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca i32
  %l129 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca i32
  %l149 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l163 = alloca i32
  %l165 = alloca ptr
  %l171 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca i32
  %l178 = alloca ptr
  %l183 = alloca i1
  %l184 = alloca i1
  %l186 = alloca i32
  %l187 = alloca i1
  %l188 = alloca i1
  %l189 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i64
  %l194 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l200 = alloca i64
  %l208 = alloca i32
  %l210 = alloca ptr
  %l217 = alloca i32
  %l218 = alloca i1
  %l219 = alloca i1
  %l220 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca i64
  %l226 = alloca ptr
  %l228 = alloca i32
  %l230 = alloca i32
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca i32
  %l240 = alloca ptr
  %l245 = alloca i32
  %l247 = alloca ptr
  %l256 = alloca %"compiler/source:Span"
  %l258 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca %"compiler/ast:Chain"
  %l269 = alloca i1
  %l272 = alloca i1
  %l276 = alloca i1
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l282 = alloca i1
  %l284 = alloca ptr
  %l286 = alloca %"compiler/source:Span"
  %l290 = alloca %"compiler/source:Span"
  %l297 = alloca i32
  %l299 = alloca ptr
  %s31 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t210 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t371 = alloca { i64, [4 x i64] }, align 8
  %t652 = alloca { i64, [4 x i64] }, align 8
  %t715 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 45
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  store i1 %t16, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l21, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 46
  store ptr %t21, ptr %l25, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t22)
  store %"compiler/source:Span" %t24, ptr %l27
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l29
  br label %bb11
bb11:
  %t30 = load i32, ptr %l29, !range !{i32 0, i32 98}
  store i32 %t30, ptr %l6
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t35 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l32
  br label %bb12
bb12:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp eq i64 %t37, 0
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %a2
  store i1 %t45, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l40, !tbaa !29
  %t50 = load ptr, ptr %l40, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 20
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 20
  store i64 %t56, ptr %t59, !tbaa !24
  %t61 = insertvalue { i32, ptr } zeroinitializer, ptr %t48, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t62 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t64 = trunc i64 58 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 18
  %t70 = load i1, ptr %t69, !tbaa !21
  %t72 = xor i1 %t70, true
  store i1 %t72, ptr %l46, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l46, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t75)
  store i1 %t77, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  %t78 = load i1, ptr %l52, !tbaa !21
  store i1 %t78, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l50, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l54, !tbaa !29
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t82, i32 0, i32 20
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t90, i32 0, i32 20
  store i64 %t88, ptr %t91, !tbaa !24
  %t93 = insertvalue { i32, ptr } zeroinitializer, ptr %t80, 1
  store { i32, ptr } %t93, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t94 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t96 = trunc i64 48 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t99, i64 1)
  store i32 %t101, ptr %l62
  br label %bb31
bb30:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb32
bb31:
  %t102 = load i32, ptr %l62, !range !{i32 0, i32 98}
  %t104 = trunc i64 27 to i32
  %t105 = icmp eq i32 %t102, %t104
  %t107 = xor i1 %t105, true
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load ptr, ptr %l67, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 20
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t120 = load ptr, ptr %l67, !tbaa !29
  %t121 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 20
  store i64 %t118, ptr %t121, !tbaa !24
  %t123 = insertvalue { i32, ptr } zeroinitializer, ptr %t110, 1
  store { i32, ptr } %t123, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 7
  %t127 = load i32, ptr %t126, !range !{i32 0, i32 98}
  %t129 = trunc i64 0 to i32
  %t130 = icmp eq i32 %t127, %t129
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb36, label %bb37
bb36:
  %t134 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t136 = trunc i64 85 to i32
  %t137 = icmp eq i32 %t134, %t136
  store i1 %t137, ptr %l75, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb38
bb38:
  %t139 = load i1, ptr %l75, !tbaa !21
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l79, !tbaa !29
  %t142 = load ptr, ptr %l79, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 20
  %t144 = load i64, ptr %t143, !tbaa !24
  %t145 = load i64, ptr %l5, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t150 = load ptr, ptr %l79, !tbaa !29
  %t151 = getelementptr %"compiler/parse:Parser", ptr %t150, i32 0, i32 20
  store i64 %t148, ptr %t151, !tbaa !24
  %t153 = insertvalue { i32, ptr } zeroinitializer, ptr %t140, 1
  store { i32, ptr } %t153, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t154)
  store i32 %t156, ptr %l84
  br label %bb42
bb42:
  %t157 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t159 = trunc i64 48 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t162)
  store i32 %t164, ptr %l88
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l7, !tbaa !24
  %t168 = add i64 %t166, 1
  %t171 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t165, i64 %t168)
  %t172 = extractvalue { i32, ptr } %t171, 1
  %t173 = extractvalue { i32, ptr } %t171, 0
  store i32 %t173, ptr %l94
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb47, label %ok.175, !prof !99
ok.175:
  store ptr %t172, ptr %l93
  br label %bb46
bb46:
  %t176 = load ptr, ptr %l93, !tbaa !29
  store ptr %t176, ptr %l89, !tbaa !29
  br label %bb48
bb47:
  %t177 = load i32, ptr %l94, !tbaa !23
  %t178 = lshr i32 %t177, 16
  %t179 = and i32 %t177, 65535
  %t180 = icmp eq i32 %t178, 1
  %t181 = select i1 %t180, i32 1, i32 0
  %t182 = icmp eq i32 %t177, 0
  %t183 = shl i32 %t181, 16
  %t184 = or i32 %t183, %t179
  %t185 = select i1 %t182, i32 0, i32 %t184
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l96, !tbaa !29
  %t187 = load ptr, ptr %l96, !tbaa !29
  %t188 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 20
  %t189 = load i64, ptr %t188, !tbaa !24
  %t190 = load i64, ptr %l5, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t195 = load ptr, ptr %l96, !tbaa !29
  %t196 = getelementptr %"compiler/parse:Parser", ptr %t195, i32 0, i32 20
  store i64 %t193, ptr %t196, !tbaa !24
  %t198 = insertvalue { i32, ptr } zeroinitializer, i32 %t185, 0
  store { i32, ptr } %t198, ptr %rv
  br label %ret
bb48:
  %t199 = load ptr, ptr %l89, !tbaa !29
  store ptr %t199, ptr %l8, !tbaa !29
  %t200 = load i32, ptr %l4, !tbaa !23
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/parse:Parser", ptr %t201, i32 0, i32 10
  %t204 = load i32, ptr %t203, !tbaa !23
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t200, i32 %t204)
  store %"compiler/source:Span" %t207, ptr %l103
  br label %bb49
bb49:
  %t208 = load ptr, ptr %l3, !tbaa !29
  %t209 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t210
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t210, i32 0, i32 0
  store i64 6, ptr %t211
  %t212 = load %"compiler/source:Span", ptr %l103
  %t213 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t212, 0
  %t215 = insertvalue { %"compiler/source:Span", ptr, ptr } %t213, ptr %t208, 1
  %t217 = insertvalue { %"compiler/source:Span", ptr, ptr } %t215, ptr %t209, 2
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t210, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t217, ptr %t218
  %t219 = load { i64, [4 x i64] }, ptr %t210
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t219, ptr %t221
  store ptr %t221, ptr %l3, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t223)
  store i32 %t225, ptr %l109
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb51, label %ok.227, !prof !99
ok.227:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t228 = load i32, ptr %l109, !tbaa !23
  %t229 = lshr i32 %t228, 16
  %t230 = and i32 %t228, 65535
  %t231 = icmp eq i32 %t229, 1
  %t232 = select i1 %t231, i32 1, i32 0
  %t233 = icmp eq i32 %t228, 0
  %t234 = shl i32 %t232, 16
  %t235 = or i32 %t234, %t230
  %t236 = select i1 %t233, i32 0, i32 %t235
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l111, !tbaa !29
  %t238 = load ptr, ptr %l111, !tbaa !29
  %t239 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 20
  %t240 = load i64, ptr %t239, !tbaa !24
  %t241 = load i64, ptr %l5, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t246 = load ptr, ptr %l111, !tbaa !29
  %t247 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 20
  store i64 %t244, ptr %t247, !tbaa !24
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 %t236, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb52:
  %t250 = load i64, ptr %l5, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l5, !tbaa !24
  br label %bb150
bb53:
  %t254 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t256 = trunc i64 28 to i32
  %t257 = icmp eq i32 %t254, %t256
  br i1 %t257, label %bb54, label %bb55
bb54:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t262 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t259, i32 48)
  store i1 %t262, ptr %l121
  br label %bb56
bb55:
  br label %bb72
bb56:
  %t263 = load i1, ptr %l121, !tbaa !21
  store i1 %t263, ptr %l9, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %t264)
  store i1 %t266, ptr %l123
  br label %bb57
bb57:
  %t267 = load i1, ptr %l123, !tbaa !21
  br i1 %t267, label %bb58, label %bb59
bb58:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t268)
  %t271 = extractvalue { i32, ptr } %t270, 1
  %t272 = extractvalue { i32, ptr } %t270, 0
  store i32 %t272, ptr %l127
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb61, label %ok.274, !prof !99
ok.274:
  store ptr %t271, ptr %l126
  br label %bb60
bb59:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l7, !tbaa !24
  %t278 = add i64 %t276, 1
  %t281 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t275, i64 %t278)
  %t282 = extractvalue { i32, ptr } %t281, 1
  %t283 = extractvalue { i32, ptr } %t281, 0
  store i32 %t283, ptr %l147
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb65, label %ok.285, !prof !99
ok.285:
  store ptr %t282, ptr %l146
  br label %bb64
bb60:
  %t286 = load ptr, ptr %l126, !tbaa !29
  store ptr %t286, ptr %l124, !tbaa !29
  br label %bb62
bb61:
  %t287 = load i32, ptr %l127, !tbaa !23
  %t288 = lshr i32 %t287, 16
  %t289 = and i32 %t287, 65535
  %t290 = icmp eq i32 %t288, 1
  %t291 = select i1 %t290, i32 1, i32 0
  %t292 = icmp eq i32 %t287, 0
  %t293 = shl i32 %t291, 16
  %t294 = or i32 %t293, %t289
  %t295 = select i1 %t292, i32 0, i32 %t294
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l129, !tbaa !29
  %t297 = load ptr, ptr %l129, !tbaa !29
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t297, i32 0, i32 20
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load i64, ptr %l5, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t305 = load ptr, ptr %l129, !tbaa !29
  %t306 = getelementptr %"compiler/parse:Parser", ptr %t305, i32 0, i32 20
  store i64 %t303, ptr %t306, !tbaa !24
  %t308 = insertvalue { i32, ptr } zeroinitializer, i32 %t295, 0
  store { i32, ptr } %t308, ptr %rv
  br label %ret
bb62:
  %t309 = load ptr, ptr %l124, !tbaa !29
  store ptr %t309, ptr %l10, !tbaa !29
  %t310 = load i32, ptr %l4, !tbaa !23
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/parse:Parser", ptr %t311, i32 0, i32 10
  %t314 = load i32, ptr %t313, !tbaa !23
  %t317 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t310, i32 %t314)
  store %"compiler/source:Span" %t317, ptr %l136
  br label %bb63
bb63:
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t320 = load i1, ptr %l9, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 9, ptr %t322
  %t323 = load %"compiler/source:Span", ptr %l136
  %t324 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t323, 0
  %t326 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t324, ptr %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t328, i1 %t320, 3
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t330, ptr %t331
  %t332 = load { i64, [4 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t332, ptr %t334
  store ptr %t334, ptr %l3, !tbaa !29
  br label %bb68
bb64:
  %t336 = load ptr, ptr %l146, !tbaa !29
  store ptr %t336, ptr %l142, !tbaa !29
  br label %bb66
bb65:
  %t337 = load i32, ptr %l147, !tbaa !23
  %t338 = lshr i32 %t337, 16
  %t339 = and i32 %t337, 65535
  %t340 = icmp eq i32 %t338, 1
  %t341 = select i1 %t340, i32 1, i32 0
  %t342 = icmp eq i32 %t337, 0
  %t343 = shl i32 %t341, 16
  %t344 = or i32 %t343, %t339
  %t345 = select i1 %t342, i32 0, i32 %t344
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l149, !tbaa !29
  %t347 = load ptr, ptr %l149, !tbaa !29
  %t348 = getelementptr %"compiler/parse:Parser", ptr %t347, i32 0, i32 20
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load i64, ptr %l5, !tbaa !24
  %t353 = sub i64 %t349, %t350
  %t355 = load ptr, ptr %l149, !tbaa !29
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t355, i32 0, i32 20
  store i64 %t353, ptr %t356, !tbaa !24
  %t358 = insertvalue { i32, ptr } zeroinitializer, i32 %t345, 0
  store { i32, ptr } %t358, ptr %rv
  br label %ret
bb66:
  %t359 = load ptr, ptr %l142, !tbaa !29
  store ptr %t359, ptr %l11, !tbaa !29
  %t360 = load i32, ptr %l4, !tbaa !23
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 10
  %t364 = load i32, ptr %t363, !tbaa !23
  %t367 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t360, i32 %t364)
  store %"compiler/source:Span" %t367, ptr %l156
  br label %bb67
bb67:
  %t368 = load ptr, ptr %l3, !tbaa !29
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t370 = load i1, ptr %l9, !tbaa !21
  store { i64, [4 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 0
  store i64 10, ptr %t372
  %t373 = load %"compiler/source:Span", ptr %l156
  %t374 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t373, 0
  %t376 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t374, ptr %t368, 1
  %t378 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t376, ptr %t369, 2
  %t380 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t378, i1 %t370, 3
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t380, ptr %t381
  %t382 = load { i64, [4 x i64] }, ptr %t371
  %t384 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t382, ptr %t384
  store ptr %t384, ptr %l3, !tbaa !29
  br label %bb68
bb68:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t386)
  store i32 %t388, ptr %l163
  %t389 = icmp ne i32 %t388, 0
  br i1 %t389, label %bb70, label %ok.390, !prof !99
ok.390:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t391 = load i32, ptr %l163, !tbaa !23
  %t392 = lshr i32 %t391, 16
  %t393 = and i32 %t391, 65535
  %t394 = icmp eq i32 %t392, 1
  %t395 = select i1 %t394, i32 1, i32 0
  %t396 = icmp eq i32 %t391, 0
  %t397 = shl i32 %t395, 16
  %t398 = or i32 %t397, %t393
  %t399 = select i1 %t396, i32 0, i32 %t398
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l165, !tbaa !29
  %t401 = load ptr, ptr %l165, !tbaa !29
  %t402 = getelementptr %"compiler/parse:Parser", ptr %t401, i32 0, i32 20
  %t403 = load i64, ptr %t402, !tbaa !24
  %t404 = load i64, ptr %l5, !tbaa !24
  %t407 = sub i64 %t403, %t404
  %t409 = load ptr, ptr %l165, !tbaa !29
  %t410 = getelementptr %"compiler/parse:Parser", ptr %t409, i32 0, i32 20
  store i64 %t407, ptr %t410, !tbaa !24
  %t412 = insertvalue { i32, ptr } zeroinitializer, i32 %t399, 0
  store { i32, ptr } %t412, ptr %rv
  br label %ret
bb71:
  %t413 = load i64, ptr %l5, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l5, !tbaa !24
  br label %bb150
bb72:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i64, ptr %l7, !tbaa !24
  %t420 = add i64 %t418, 1
  %t423 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t417, i64 %t420)
  %t424 = extractvalue { i32, ptr } %t423, 1
  %t425 = extractvalue { i32, ptr } %t423, 0
  store i32 %t425, ptr %l176
  %t426 = icmp ne i32 %t425, 0
  br i1 %t426, label %bb74, label %ok.427, !prof !99
ok.427:
  store ptr %t424, ptr %l175
  br label %bb73
bb73:
  %t428 = load ptr, ptr %l175, !tbaa !29
  store ptr %t428, ptr %l171, !tbaa !29
  br label %bb75
bb74:
  %t429 = load i32, ptr %l176, !tbaa !23
  %t430 = lshr i32 %t429, 16
  %t431 = and i32 %t429, 65535
  %t432 = icmp eq i32 %t430, 1
  %t433 = select i1 %t432, i32 1, i32 0
  %t434 = icmp eq i32 %t429, 0
  %t435 = shl i32 %t433, 16
  %t436 = or i32 %t435, %t431
  %t437 = select i1 %t434, i32 0, i32 %t436
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l178, !tbaa !29
  %t439 = load ptr, ptr %l178, !tbaa !29
  %t440 = getelementptr %"compiler/parse:Parser", ptr %t439, i32 0, i32 20
  %t441 = load i64, ptr %t440, !tbaa !24
  %t442 = load i64, ptr %l5, !tbaa !24
  %t445 = sub i64 %t441, %t442
  %t447 = load ptr, ptr %l178, !tbaa !29
  %t448 = getelementptr %"compiler/parse:Parser", ptr %t447, i32 0, i32 20
  store i64 %t445, ptr %t448, !tbaa !24
  %t450 = insertvalue { i32, ptr } zeroinitializer, i32 %t437, 0
  store { i32, ptr } %t450, ptr %rv
  br label %ret
bb75:
  %t451 = load ptr, ptr %l171, !tbaa !29
  store ptr %t451, ptr %l12, !tbaa !29
  %t452 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t454 = call i1 @compiler_2fparse_2eisOrdering(i32 %t452)
  store i1 %t454, ptr %l183
  br label %bb76
bb76:
  %t455 = load i1, ptr %l183, !tbaa !21
  br i1 %t455, label %bb77, label %bb78
bb77:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t456)
  store i32 %t458, ptr %l186
  br label %bb79
bb78:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb81
bb79:
  %t459 = load i32, ptr %l186, !range !{i32 0, i32 98}
  %t460 = call i1 @compiler_2fparse_2eisOrdering(i32 %t459)
  store i1 %t460, ptr %l187
  br label %bb80
bb80:
  %t461 = load i1, ptr %l187, !tbaa !21
  store i1 %t461, ptr %l184, !tbaa !21
  br label %bb81
bb81:
  %t462 = load i1, ptr %l184, !tbaa !21
  br i1 %t462, label %bb82, label %bb83
bb82:
  %t463 = load ptr, ptr %l0, !tbaa !29
  store ptr %t463, ptr %l189, !tbaa !29
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t464)
  store i32 %t466, ptr %l191
  br label %bb84
bb83:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb86
bb84:
  %t467 = load ptr, ptr %l189, !tbaa !29
  %t468 = load i32, ptr %l191, !range !{i32 0, i32 98}
  %t469 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t467, i32 %t468)
  store i64 %t469, ptr %l192
  br label %bb85
bb85:
  %t470 = load i64, ptr %l192, !tbaa !24
  %t471 = icmp sgt i64 %t470, 0
  store i1 %t471, ptr %l188, !tbaa !21
  br label %bb86
bb86:
  %t473 = load i1, ptr %l188, !tbaa !21
  br i1 %t473, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s31
  %t474 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %s31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l194
  br label %bb89
bb88:
  br label %bb124
bb89:
  %t475 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l194
  %t476 = call ptr @__olang_scope_alloc_a(ptr %s31, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t475, ptr %t476
  store ptr %t476, ptr %l13, !tbaa !29
  %t478 = load ptr, ptr %l13, !tbaa !29
  %t479 = load i32, ptr %l6, !range !{i32 0, i32 98}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s31, ptr %t478, i32 %t479)
  br label %bb90
bb90:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/parse:Parser", ptr %t482, i32 0, i32 30
  %t486 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t484)
  store i64 %t486, ptr %l200
  br label %bb91
bb91:
  %t487 = load i64, ptr %l200, !tbaa !24
  store i64 %t487, ptr %l14, !tbaa !24
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/parse:Parser", ptr %t488, i32 0, i32 30
  %t491 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t490, ptr %t491)
  br label %bb92
bb92:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/parse:Parser", ptr %t494, i32 0, i32 30
  %t497 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t496, ptr %t497)
  br label %bb93
bb93:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t500)
  store i32 %t502, ptr %l208
  %t503 = icmp ne i32 %t502, 0
  br i1 %t503, label %bb95, label %ok.504, !prof !99
ok.504:
  br label %bb94
bb94:
  br label %bb96
bb95:
  %t505 = load i32, ptr %l208, !tbaa !23
  %t506 = lshr i32 %t505, 16
  %t507 = and i32 %t505, 65535
  %t508 = icmp eq i32 %t506, 1
  %t509 = select i1 %t508, i32 1, i32 0
  %t510 = icmp eq i32 %t505, 0
  %t511 = shl i32 %t509, 16
  %t512 = or i32 %t511, %t507
  %t513 = select i1 %t510, i32 0, i32 %t512
  call void @__olang_scope_close(ptr %s31)
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l210, !tbaa !29
  %t515 = load ptr, ptr %l210, !tbaa !29
  %t516 = getelementptr %"compiler/parse:Parser", ptr %t515, i32 0, i32 20
  %t517 = load i64, ptr %t516, !tbaa !24
  %t518 = load i64, ptr %l5, !tbaa !24
  %t521 = sub i64 %t517, %t518
  %t523 = load ptr, ptr %l210, !tbaa !29
  %t524 = getelementptr %"compiler/parse:Parser", ptr %t523, i32 0, i32 20
  store i64 %t521, ptr %t524, !tbaa !24
  %t526 = insertvalue { i32, ptr } zeroinitializer, i32 %t513, 0
  store { i32, ptr } %t526, ptr %rv
  br label %ret
bb96:
  %t527 = load i64, ptr %l5, !tbaa !24
  %t529 = add i64 %t527, 1
  store i64 %t529, ptr %l5, !tbaa !24
  br label %bb97
bb97:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t531)
  store i32 %t533, ptr %l217
  br label %bb98
bb98:
  %t534 = load i32, ptr %l217, !range !{i32 0, i32 98}
  %t535 = call i1 @compiler_2fparse_2eisOrdering(i32 %t534)
  store i1 %t535, ptr %l218
  br label %bb99
bb99:
  %t536 = load i1, ptr %l218, !tbaa !21
  br i1 %t536, label %bb100, label %bb101
bb100:
  %t537 = load ptr, ptr %l0, !tbaa !29
  store ptr %t537, ptr %l220, !tbaa !29
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t538)
  store i32 %t540, ptr %l222
  br label %bb102
bb101:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb104
bb102:
  %t541 = load ptr, ptr %l220, !tbaa !29
  %t542 = load i32, ptr %l222, !range !{i32 0, i32 98}
  %t543 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t541, i32 %t542)
  store i64 %t543, ptr %l223
  br label %bb103
bb103:
  %t544 = load i64, ptr %l223, !tbaa !24
  %t545 = icmp sgt i64 %t544, 0
  store i1 %t545, ptr %l219, !tbaa !21
  br label %bb104
bb104:
  %t547 = load i1, ptr %l219, !tbaa !21
  %t548 = xor i1 %t547, true
  br i1 %t548, label %bb105, label %bb106
bb105:
  br label %bb119
bb106:
  br label %bb107
bb107:
  %t550 = load ptr, ptr %l13, !tbaa !29
  store ptr %t550, ptr %l226, !tbaa !29
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t551)
  store i32 %t553, ptr %l228
  br label %bb108
bb108:
  %t554 = load ptr, ptr %l226, !tbaa !29
  %t555 = load i32, ptr %l228, !range !{i32 0, i32 98}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s31, ptr %t554, i32 %t555)
  br label %bb109
bb109:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t556)
  store i32 %t558, ptr %l230
  br label %bb110
bb110:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/parse:Parser", ptr %t559, i32 0, i32 30
  store ptr %t561, ptr %l232, !tbaa !29
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load i64, ptr %l7, !tbaa !24
  %t565 = add i64 %t563, 1
  %t568 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t562, i64 %t565)
  %t569 = extractvalue { i32, ptr } %t568, 1
  %t570 = extractvalue { i32, ptr } %t568, 0
  store i32 %t570, ptr %l238
  %t571 = icmp ne i32 %t570, 0
  br i1 %t571, label %bb112, label %ok.572, !prof !99
ok.572:
  store ptr %t569, ptr %l237
  br label %bb111
bb111:
  %t573 = load ptr, ptr %l237, !tbaa !29
  store ptr %t573, ptr %l233, !tbaa !29
  br label %bb113
bb112:
  %t574 = load i32, ptr %l238, !tbaa !23
  %t575 = lshr i32 %t574, 16
  %t576 = and i32 %t574, 65535
  %t577 = icmp eq i32 %t575, 1
  %t578 = select i1 %t577, i32 1, i32 0
  %t579 = icmp eq i32 %t574, 0
  %t580 = shl i32 %t578, 16
  %t581 = or i32 %t580, %t576
  %t582 = select i1 %t579, i32 0, i32 %t581
  call void @__olang_scope_close(ptr %s31)
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l240, !tbaa !29
  %t584 = load ptr, ptr %l240, !tbaa !29
  %t585 = getelementptr %"compiler/parse:Parser", ptr %t584, i32 0, i32 20
  %t586 = load i64, ptr %t585, !tbaa !24
  %t587 = load i64, ptr %l5, !tbaa !24
  %t590 = sub i64 %t586, %t587
  %t592 = load ptr, ptr %l240, !tbaa !29
  %t593 = getelementptr %"compiler/parse:Parser", ptr %t592, i32 0, i32 20
  store i64 %t590, ptr %t593, !tbaa !24
  %t595 = insertvalue { i32, ptr } zeroinitializer, i32 %t582, 0
  store { i32, ptr } %t595, ptr %rv
  br label %ret
bb113:
  %t596 = load ptr, ptr %l232, !tbaa !29
  %t597 = load ptr, ptr %l233, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t596, ptr %t597)
  br label %bb114
bb114:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t598)
  store i32 %t600, ptr %l245
  %t601 = icmp ne i32 %t600, 0
  br i1 %t601, label %bb116, label %ok.602, !prof !99
ok.602:
  br label %bb115
bb115:
  br label %bb117
bb116:
  %t603 = load i32, ptr %l245, !tbaa !23
  %t604 = lshr i32 %t603, 16
  %t605 = and i32 %t603, 65535
  %t606 = icmp eq i32 %t604, 1
  %t607 = select i1 %t606, i32 1, i32 0
  %t608 = icmp eq i32 %t603, 0
  %t609 = shl i32 %t607, 16
  %t610 = or i32 %t609, %t605
  %t611 = select i1 %t608, i32 0, i32 %t610
  call void @__olang_scope_close(ptr %s31)
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l247, !tbaa !29
  %t613 = load ptr, ptr %l247, !tbaa !29
  %t614 = getelementptr %"compiler/parse:Parser", ptr %t613, i32 0, i32 20
  %t615 = load i64, ptr %t614, !tbaa !24
  %t616 = load i64, ptr %l5, !tbaa !24
  %t619 = sub i64 %t615, %t616
  %t621 = load ptr, ptr %l247, !tbaa !29
  %t622 = getelementptr %"compiler/parse:Parser", ptr %t621, i32 0, i32 20
  store i64 %t619, ptr %t622, !tbaa !24
  %t624 = insertvalue { i32, ptr } zeroinitializer, i32 %t611, 0
  store { i32, ptr } %t624, ptr %rv
  br label %ret
bb117:
  %t625 = load i64, ptr %l5, !tbaa !24
  %t627 = add i64 %t625, 1
  store i64 %t627, ptr %l5, !tbaa !24
  br label %bb118
bb118:
  br label %bb97
bb119:
  %t629 = load i32, ptr %l4, !tbaa !23
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/parse:Parser", ptr %t630, i32 0, i32 10
  %t633 = load i32, ptr %t632, !tbaa !23
  %t636 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t629, i32 %t633)
  store %"compiler/source:Span" %t636, ptr %l256
  br label %bb120
bb120:
  %t637 = load ptr, ptr %l13, !tbaa !29
  %t639 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %s31, ptr %v1, ptr %t637)
  store { i64, ptr } %t639, ptr %l258
  br label %bb121
bb121:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/parse:Parser", ptr %t640, i32 0, i32 30
  %t643 = load i64, ptr %l14, !tbaa !24
  %t646 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t642, i64 %t643)
  store { i64, ptr } %t646, ptr %l262
  br label %bb122
bb122:
  %t647 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t648 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t649 = call %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } %t647, { i64, ptr } %t648)
  store %"compiler/ast:Chain" %t649, ptr %l263
  br label %bb123
bb123:
  %t650 = load %"compiler/ast:Chain", ptr %l263
  %t651 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Chain" %t650, ptr %t651
  store { i64, [4 x i64] } zeroinitializer, ptr %t652
  %t653 = getelementptr { i64, [4 x i64] }, ptr %t652, i32 0, i32 0
  store i64 7, ptr %t653
  %t654 = load %"compiler/source:Span", ptr %l256
  %t655 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t654, 0
  %t657 = insertvalue { %"compiler/source:Span", ptr } %t655, ptr %t651, 1
  %t658 = getelementptr { i64, [4 x i64] }, ptr %t652, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t657, ptr %t658
  %t659 = load { i64, [4 x i64] }, ptr %t652
  %t661 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t659, ptr %t661
  store ptr %t661, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s31)
  br label %bb150
bb124:
  %t663 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t665 = trunc i64 85 to i32
  %t666 = icmp eq i32 %t663, %t665
  br i1 %t666, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l269, !tbaa !21
  br label %bb127
bb126:
  %t668 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t670 = trunc i64 86 to i32
  %t671 = icmp eq i32 %t668, %t670
  store i1 %t671, ptr %l269, !tbaa !21
  br label %bb127
bb127:
  %t673 = load i1, ptr %l269, !tbaa !21
  br i1 %t673, label %bb128, label %bb129
bb128:
  store i1 true, ptr %l272, !tbaa !21
  br label %bb130
bb129:
  %t674 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t676 = trunc i64 87 to i32
  %t677 = icmp eq i32 %t674, %t676
  store i1 %t677, ptr %l272, !tbaa !21
  br label %bb130
bb130:
  %t679 = load i1, ptr %l272, !tbaa !21
  br i1 %t679, label %bb131, label %bb132
bb131:
  %t680 = load ptr, ptr %l3, !tbaa !29
  %t682 = call i1 @compiler_2fparse_2ecomparison(ptr %v1, ptr %t680)
  store i1 %t682, ptr %l276
  br label %bb133
bb132:
  br label %bb145
bb133:
  %t683 = load i1, ptr %l276, !tbaa !21
  br i1 %t683, label %bb134, label %bb135
bb134:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t686 = getelementptr %"compiler/parse:Parser", ptr %t684, i32 0, i32 43
  store ptr %t686, ptr %l278, !tbaa !29
  %t687 = load ptr, ptr %l3, !tbaa !29
  %t689 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t687)
  store %"compiler/source:Span" %t689, ptr %l280
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t690 = load ptr, ptr %l278, !tbaa !29
  %t691 = load %"compiler/source:Span", ptr %l280
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t690, %"compiler/source:Span" %t691)
  br label %bb137
bb137:
  br label %bb138
bb138:
  %t692 = load ptr, ptr %l12, !tbaa !29
  %t694 = call i1 @compiler_2fparse_2ecomparison(ptr %v1, ptr %t692)
  store i1 %t694, ptr %l282
  br label %bb139
bb139:
  %t695 = load i1, ptr %l282, !tbaa !21
  br i1 %t695, label %bb140, label %bb141
bb140:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/parse:Parser", ptr %t696, i32 0, i32 43
  store ptr %t698, ptr %l284, !tbaa !29
  %t699 = load ptr, ptr %l12, !tbaa !29
  %t701 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t699)
  store %"compiler/source:Span" %t701, ptr %l286
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t702 = load ptr, ptr %l284, !tbaa !29
  %t703 = load %"compiler/source:Span", ptr %l286
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t702, %"compiler/source:Span" %t703)
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t704 = load i32, ptr %l4, !tbaa !23
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t707 = getelementptr %"compiler/parse:Parser", ptr %t705, i32 0, i32 10
  %t708 = load i32, ptr %t707, !tbaa !23
  %t711 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t704, i32 %t708)
  store %"compiler/source:Span" %t711, ptr %l290
  br label %bb146
bb146:
  %t712 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t713 = load ptr, ptr %l3, !tbaa !29
  %t714 = load ptr, ptr %l12, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t715
  %t716 = getelementptr { i64, [4 x i64] }, ptr %t715, i32 0, i32 0
  store i64 5, ptr %t716
  %t717 = load %"compiler/source:Span", ptr %l290
  %t718 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t717, 0
  %t720 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t718, i32 %t712, 1
  %t722 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t720, ptr %t713, 2
  %t724 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t722, ptr %t714, 3
  %t725 = getelementptr { i64, [4 x i64] }, ptr %t715, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t724, ptr %t725
  %t726 = load { i64, [4 x i64] }, ptr %t715
  %t728 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t726, ptr %t728
  store ptr %t728, ptr %l3, !tbaa !29
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t732 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t730)
  store i32 %t732, ptr %l297
  %t733 = icmp ne i32 %t732, 0
  br i1 %t733, label %bb148, label %ok.734, !prof !99
ok.734:
  br label %bb147
bb147:
  br label %bb149
bb148:
  %t735 = load i32, ptr %l297, !tbaa !23
  %t736 = lshr i32 %t735, 16
  %t737 = and i32 %t735, 65535
  %t738 = icmp eq i32 %t736, 1
  %t739 = select i1 %t738, i32 1, i32 0
  %t740 = icmp eq i32 %t735, 0
  %t741 = shl i32 %t739, 16
  %t742 = or i32 %t741, %t737
  %t743 = select i1 %t740, i32 0, i32 %t742
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l299, !tbaa !29
  %t745 = load ptr, ptr %l299, !tbaa !29
  %t746 = getelementptr %"compiler/parse:Parser", ptr %t745, i32 0, i32 20
  %t747 = load i64, ptr %t746, !tbaa !24
  %t748 = load i64, ptr %l5, !tbaa !24
  %t751 = sub i64 %t747, %t748
  %t753 = load ptr, ptr %l299, !tbaa !29
  %t754 = getelementptr %"compiler/parse:Parser", ptr %t753, i32 0, i32 20
  store i64 %t751, ptr %t754, !tbaa !24
  %t756 = insertvalue { i32, ptr } zeroinitializer, i32 %t743, 0
  store { i32, ptr } %t756, ptr %rv
  br label %ret
bb149:
  %t757 = load i64, ptr %l5, !tbaa !24
  %t759 = add i64 %t757, 1
  store i64 %t759, ptr %l5, !tbaa !24
  br label %bb150
bb150:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca %"compiler/parse:stackMarks"
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l33 = alloca %"compiler/token:Token"
  %l35 = alloca i32
  %l64 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l85 = alloca i32
  %l87 = alloca %"compiler/token:Token"
  %l96 = alloca ptr
  %l97 = alloca { i64, [3 x i64] }
  %l99 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i64
  %l109 = alloca i32
  %l126 = alloca %"compiler/parse:stackMarks"
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l151 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %l157 = alloca i1
  %l163 = alloca i32
  %l190 = alloca ptr
  %l196 = alloca i1
  %l201 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l205 = alloca i32
  %l206 = alloca i32
  %l223 = alloca i32
  %l227 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t189 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 96)
  store i1 %t4, ptr %l21
  br label %bb1
bb1:
  %t5 = load i1, ptr %l21, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l23, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 96)
  store { i64, ptr } %t10, ptr %l25
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t11 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = load ptr, ptr %l23, !tbaa !29
  %t20 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t18, { i64, ptr } %t17)
  store i32 %t20, ptr %l27
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l27, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s1)
  %t33 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t31, 0
  store { i32, { i64, ptr } } %t33, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l30
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38, !prof !99
ok.38:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l30, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t47, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t50)
  store %"compiler/token:Token" %t52, ptr %l33
  br label %bb12
bb12:
  %t53 = load %"compiler/token:Token", ptr %l33
  store %"compiler/token:Token" %t53, ptr %l1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l35
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 12
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l2, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 16
  %t66 = load i1, ptr %t65, !tbaa !21
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 12
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 16
  store i1 false, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 17
  %t76 = load i64, ptr %t75, !tbaa !24
  store i64 %t76, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t78, i32 0, i32 17
  store i64 0, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 18
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l4, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 18
  store i1 false, ptr %t88, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 19
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l5, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 19
  store i1 false, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 13
  %t100 = load i1, ptr %t99, !tbaa !21
  store i1 %t100, ptr %l6, !tbaa !21
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 13
  store i1 false, ptr %t104, !tbaa !21
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 15
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l7, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 14
  %t113 = load i1, ptr %t112, !tbaa !21
  store i1 %t113, ptr %l8, !tbaa !21
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t115, i32 0, i32 15
  store i1 false, ptr %t119, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 14
  store i1 false, ptr %t124, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t125, i32 0, i32 31
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t127)
  store i64 %t129, ptr %l64
  br label %bb14
bb14:
  %t130 = load i64, ptr %l64, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t131)
  br label %bb16
bb16:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t133, i32 97)
  store i1 %t136, ptr %l68
  br label %bb17
bb17:
  %t137 = load i1, ptr %l68, !tbaa !21
  br i1 %t137, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb21
bb19:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t138, i32 0)
  store i1 %t141, ptr %l72
  br label %bb20
bb20:
  %t142 = load i1, ptr %l72, !tbaa !21
  store i1 %t142, ptr %l69, !tbaa !21
  br label %bb21
bb21:
  %t143 = load i1, ptr %l69, !tbaa !21
  br i1 %t143, label %bb22, label %bb23
bb22:
  br label %bb85
bb23:
  br label %bb24
bb24:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l74
  br label %bb25
bb25:
  %t147 = load i1, ptr %l74, !tbaa !21
  br i1 %t147, label %bb26, label %bb27
bb26:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 21
  %t151 = load i1, ptr %t150, !tbaa !21
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb28, label %bb29
bb27:
  br label %bb41
bb28:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t155, i32 0, i32 23
  %t158 = load i1, ptr %t157, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l78, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t162 = load i1, ptr %l78, !tbaa !21
  br i1 %t162, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t166, i32 %t168)
  store i32 %t171, ptr %l85
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t172 = load i32, ptr %l85, !tbaa !23
  store i32 %t172, ptr %l12, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t173)
  store %"compiler/token:Token" %t175, ptr %l87
  br label %bb34
bb34:
  %t176 = load %"compiler/token:Token", ptr %l87
  store %"compiler/token:Token" %t176, ptr %l13
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t177, i32 0, i32 5
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t182 = load i32, ptr %t181, !tbaa !23
  %t184 = sext i32 %t182 to i64
  %t185 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t186 = load i32, ptr %t185, !tbaa !23
  %t188 = sext i32 %t186 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 0
  store i64 3, ptr %t190
  %t192 = insertvalue { i64, i64, i64 } undef, i64 %t180, 0
  %t194 = insertvalue { i64, i64, i64 } %t192, i64 %t184, 1
  %t196 = insertvalue { i64, i64, i64 } %t194, i64 %t188, 2
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 1
  store { i64, i64, i64 } %t196, ptr %t197
  %t198 = load { i64, [3 x i64] }, ptr %t189
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t200, i32 0, i32 4
  %t203 = load ptr, ptr %t202, !tbaa !29
  store ptr %t203, ptr %l96, !tbaa !29
  store { i64, [3 x i64] } %t198, ptr %l97
  %t205 = load i32, ptr %l12, !tbaa !23
  %t207 = sext i32 %t205 to i64
  store i64 %t207, ptr %l99, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s5, ptr %t208)
  store { i64, ptr } %t210, ptr %l101
  br label %bb35
bb35:
  %t211 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load i64, ptr %l99, !tbaa !24
  %t220 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %s5, ptr %s5, i64 %t218, { i64, ptr } %t217)
  store %"compiler/msgs:Msg" %t220, ptr %l103
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l96, !tbaa !29
  %t222 = load { i64, [3 x i64] }, ptr %l97
  %t223 = load %"compiler/msgs:Msg", ptr %l103
  %t224 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s5, ptr %t221, { i64, [3 x i64] } %t222, %"compiler/msgs:Msg" %t223)
  store i64 %t224, ptr %l104
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/parse:Parser", ptr %t225, i32 0, i32 31
  %t228 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t227, i64 %t228)
  br label %bb39
bb39:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/parse:Parser", ptr %t231, i32 0, i32 23
  store i1 true, ptr %t233, !tbaa !21
  store i32 65536, ptr %l109, !tbaa !23
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l7, !tbaa !21
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 15
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i1, ptr %l8, !tbaa !21
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t239, i32 0, i32 14
  store i1 %t240, ptr %t243, !tbaa !21
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i1, ptr %l6, !tbaa !21
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 13
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i1, ptr %l5, !tbaa !21
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t249, i32 0, i32 19
  store i1 %t250, ptr %t253, !tbaa !21
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i1, ptr %l4, !tbaa !21
  %t258 = getelementptr %"compiler/parse:Parser", ptr %t254, i32 0, i32 18
  store i1 %t255, ptr %t258, !tbaa !21
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l3, !tbaa !24
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 17
  store i64 %t260, ptr %t263, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i1, ptr %l2, !tbaa !21
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t264, i32 0, i32 12
  store i1 %t265, ptr %t268, !tbaa !21
  %t269 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t269)
  br label %bb40
bb40:
  %t271 = load i32, ptr %l109, !tbaa !23
  %t272 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t271, 0
  store { i32, { i64, ptr } } %t272, ptr %rv
  br label %ret
bb41:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %t273)
  store %"compiler/parse:stackMarks" %t275, ptr %l126
  br label %bb42
bb42:
  %t276 = load %"compiler/parse:stackMarks", ptr %l126
  store %"compiler/parse:stackMarks" %t276, ptr %l15
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t277, i32 0, i32 6
  %t280 = load i64, ptr %t279, !tbaa !24
  store i64 %t280, ptr %l16, !tbaa !24
  %t282 = icmp sge i64 0, 0
  br i1 %t282, label %bb43, label %bb44
bb43:
  %t284 = icmp sle i64 0, 1152921504606846975
  br i1 %t284, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_3a8ad8017031eccf_6f47b3cce535c81b)
  unreachable
bb45:
  %t286 = mul i64 0, 8
  %t287 = insertvalue { i64, ptr } undef, i64 0, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t288, ptr %l17, !tbaa !27
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t293 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t290, i32 58)
  store i1 %t293, ptr %l134
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_3a8ad8017031eccf_6f47b3cce535c81b)
  unreachable
bb47:
  %t294 = load i1, ptr %l134, !tbaa !21
  br i1 %t294, label %bb48, label %bb49
bb48:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrs(ptr %v0, ptr %v0, ptr %t295)
  %t298 = extractvalue { i32, { i64, ptr } } %t297, 1
  %t299 = extractvalue { i32, { i64, ptr } } %t297, 0
  store i32 %t299, ptr %l138
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb51, label %ok.301, !prof !99
ok.301:
  store { i64, ptr } %t298, ptr %l137
  br label %bb50
bb49:
  br label %bb64
bb50:
  %t302 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t302, ptr %l135, !tbaa !27
  br label %bb55
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/parse:stackMarks", ptr %l15
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %t303, %"compiler/parse:stackMarks" %t304)
  br label %bb53
bb53:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %t307, i64 %t308)
  br label %bb54
bb54:
  br label %bb84
bb55:
  %t311 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t311, ptr %l17, !tbaa !27
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/parse:Parser", ptr %t312, i32 0, i32 12
  %t315 = load i1, ptr %t314, !tbaa !21
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb56, label %bb57
bb56:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrRefused(ptr %v0, ptr %v0, ptr %t319, { i64, ptr } %t320)
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t323 = icmp sge i64 0, 0
  br i1 %t323, label %bb59, label %bb60
bb59:
  %t325 = icmp sle i64 0, 1152921504606846975
  br i1 %t325, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_9090e2f728d8157a_2317b9fcceb6fe86)
  unreachable
bb61:
  %t327 = mul i64 0, 8
  %t328 = insertvalue { i64, ptr } undef, i64 0, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t329, ptr %l17, !tbaa !27
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_9090e2f728d8157a_2317b9fcceb6fe86)
  unreachable
bb63:
  br label %bb64
bb64:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v0, ptr %t331)
  %t334 = extractvalue { i32, ptr } %t333, 1
  %t335 = extractvalue { i32, ptr } %t333, 0
  store i32 %t335, ptr %l154
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb66, label %ok.337, !prof !99
ok.337:
  store ptr %t334, ptr %l153
  br label %bb65
bb65:
  %t338 = load ptr, ptr %l153, !tbaa !29
  store ptr %t338, ptr %l151, !tbaa !29
  br label %bb78
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t339, i32 0, i32 21
  %t342 = load i1, ptr %t341, !tbaa !21
  br i1 %t342, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb70
bb69:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/parse:Parser", ptr %t344, i32 0, i32 23
  %t347 = load i1, ptr %t346, !tbaa !21
  store i1 %t347, ptr %l157, !tbaa !21
  br label %bb70
bb70:
  %t349 = load i1, ptr %l157, !tbaa !21
  br i1 %t349, label %bb71, label %bb72
bb71:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t350, i32 0, i32 31
  %t353 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t352, i64 %t353)
  br label %bb73
bb72:
  br label %bb75
bb73:
  store i32 65536, ptr %l163, !tbaa !23
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i1, ptr %l7, !tbaa !21
  %t360 = getelementptr %"compiler/parse:Parser", ptr %t356, i32 0, i32 15
  store i1 %t357, ptr %t360, !tbaa !21
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i1, ptr %l8, !tbaa !21
  %t365 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 14
  store i1 %t362, ptr %t365, !tbaa !21
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i1, ptr %l6, !tbaa !21
  %t370 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 13
  store i1 %t367, ptr %t370, !tbaa !21
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i1, ptr %l5, !tbaa !21
  %t375 = getelementptr %"compiler/parse:Parser", ptr %t371, i32 0, i32 19
  store i1 %t372, ptr %t375, !tbaa !21
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i1, ptr %l4, !tbaa !21
  %t380 = getelementptr %"compiler/parse:Parser", ptr %t376, i32 0, i32 18
  store i1 %t377, ptr %t380, !tbaa !21
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i64, ptr %l3, !tbaa !24
  %t385 = getelementptr %"compiler/parse:Parser", ptr %t381, i32 0, i32 17
  store i64 %t382, ptr %t385, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i1, ptr %l2, !tbaa !21
  %t390 = getelementptr %"compiler/parse:Parser", ptr %t386, i32 0, i32 12
  store i1 %t387, ptr %t390, !tbaa !21
  %t391 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t391)
  br label %bb74
bb74:
  %t393 = load i32, ptr %l163, !tbaa !23
  %t394 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t393, 0
  store { i32, { i64, ptr } } %t394, ptr %rv
  br label %ret
bb75:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/parse:stackMarks", ptr %l15
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %t395, %"compiler/parse:stackMarks" %t396)
  br label %bb76
bb76:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/parse:Parser", ptr %t399, i32 0, i32 18
  store i1 false, ptr %t401, !tbaa !21
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %t402, i64 %t403)
  br label %bb77
bb77:
  br label %bb84
bb78:
  %t406 = load ptr, ptr %l151, !tbaa !29
  store ptr %t406, ptr %l18, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t411 = icmp sgt i64 %t409, 0
  br i1 %t411, label %bb79, label %bb80
bb79:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l18, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t419 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldAttrs(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t413, ptr %t414, { i64, ptr } %t415)
  store ptr %t419, ptr %l190
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t420 = load ptr, ptr %l190, !tbaa !29
  store ptr %t420, ptr %l18, !tbaa !29
  br label %bb82
bb82:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/parse:Parser", ptr %t421, i32 0, i32 31
  %t424 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t423, ptr %t424)
  br label %bb83
bb83:
  br label %bb84
bb84:
  br label %bb15
bb85:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t430 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t427, i32 97)
  store i1 %t430, ptr %l196
  br label %bb86
bb86:
  %t431 = load i1, ptr %l196, !tbaa !21
  %t432 = xor i1 %t431, true
  br i1 %t432, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s38
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t434, i32 0, i32 31
  %t437 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t436, i64 %t437)
  br label %bb89
bb88:
  br label %bb95
bb89:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l201, !tbaa !29
  %t442 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s38, i32 97)
  store { i64, ptr } %t442, ptr %l203
  br label %bb90
bb90:
  %t443 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 0
  %t445 = extractvalue { i64, ptr } %t443, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t450 = load ptr, ptr %l201, !tbaa !29
  %t452 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s38, ptr %t450, { i64, ptr } %t449)
  store i32 %t452, ptr %l205
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb92, label %ok.454, !prof !99
ok.454:
  br label %bb91
bb91:
  br label %bb94
bb92:
  %t455 = load i32, ptr %l205, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  store i32 %t463, ptr %l206, !tbaa !23
  call void @__olang_scope_close(ptr %s38)
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i1, ptr %l7, !tbaa !21
  %t468 = getelementptr %"compiler/parse:Parser", ptr %t464, i32 0, i32 15
  store i1 %t465, ptr %t468, !tbaa !21
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load i1, ptr %l8, !tbaa !21
  %t473 = getelementptr %"compiler/parse:Parser", ptr %t469, i32 0, i32 14
  store i1 %t470, ptr %t473, !tbaa !21
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load i1, ptr %l6, !tbaa !21
  %t478 = getelementptr %"compiler/parse:Parser", ptr %t474, i32 0, i32 13
  store i1 %t475, ptr %t478, !tbaa !21
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i1, ptr %l5, !tbaa !21
  %t483 = getelementptr %"compiler/parse:Parser", ptr %t479, i32 0, i32 19
  store i1 %t480, ptr %t483, !tbaa !21
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i1, ptr %l4, !tbaa !21
  %t488 = getelementptr %"compiler/parse:Parser", ptr %t484, i32 0, i32 18
  store i1 %t485, ptr %t488, !tbaa !21
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i64, ptr %l3, !tbaa !24
  %t493 = getelementptr %"compiler/parse:Parser", ptr %t489, i32 0, i32 17
  store i64 %t490, ptr %t493, !tbaa !24
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load i1, ptr %l2, !tbaa !21
  %t498 = getelementptr %"compiler/parse:Parser", ptr %t494, i32 0, i32 12
  store i1 %t495, ptr %t498, !tbaa !21
  %t499 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t499)
  br label %bb93
bb93:
  %t501 = load i32, ptr %l206, !tbaa !23
  %t502 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t501, 0
  store { i32, { i64, ptr } } %t502, ptr %rv
  br label %ret
bb94:
  call void @__olang_scope_close(ptr %s38)
  br label %bb95
bb95:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t503)
  store i32 %t505, ptr %l223
  br label %bb96
bb96:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/parse:Parser", ptr %t506, i32 0, i32 31
  %t509 = load i64, ptr %l11, !tbaa !24
  %t512 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t508, i64 %t509)
  store { i64, ptr } %t512, ptr %l227
  br label %bb97
bb97:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load i1, ptr %l7, !tbaa !21
  %t517 = getelementptr %"compiler/parse:Parser", ptr %t513, i32 0, i32 15
  store i1 %t514, ptr %t517, !tbaa !21
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load i1, ptr %l8, !tbaa !21
  %t522 = getelementptr %"compiler/parse:Parser", ptr %t518, i32 0, i32 14
  store i1 %t519, ptr %t522, !tbaa !21
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load i1, ptr %l6, !tbaa !21
  %t527 = getelementptr %"compiler/parse:Parser", ptr %t523, i32 0, i32 13
  store i1 %t524, ptr %t527, !tbaa !21
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load i1, ptr %l5, !tbaa !21
  %t532 = getelementptr %"compiler/parse:Parser", ptr %t528, i32 0, i32 19
  store i1 %t529, ptr %t532, !tbaa !21
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i1, ptr %l4, !tbaa !21
  %t537 = getelementptr %"compiler/parse:Parser", ptr %t533, i32 0, i32 18
  store i1 %t534, ptr %t537, !tbaa !21
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i64, ptr %l3, !tbaa !24
  %t542 = getelementptr %"compiler/parse:Parser", ptr %t538, i32 0, i32 17
  store i64 %t539, ptr %t542, !tbaa !24
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i1, ptr %l2, !tbaa !21
  %t547 = getelementptr %"compiler/parse:Parser", ptr %t543, i32 0, i32 12
  store i1 %t544, ptr %t547, !tbaa !21
  %t548 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t548)
  br label %bb98
bb98:
  %t550 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t551 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t550, 1
  store { i32, { i64, ptr } } %t551, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l12 = alloca i32
  %l15 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !range !{i32 0, i32 98}
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 83)
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t23 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t20)
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25, !prof !99
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s1)
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l15
  br label %bb10
bb10:
  %t39 = load i32, ptr %l15, !tbaa !23
  store i32 %t39, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 41
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 6
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = sub i64 %t46, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t42, i64 %t48)
  br label %bb11
bb11:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t53 = trunc i64 83 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i32 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l23, !tbaa !29
  %t57 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t59 = trunc i64 91 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i32 83, ptr %l26
  br label %bb20
bb16:
  %t63 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t65 = trunc i64 84 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i32 62, ptr %l30
  br label %bb19
bb18:
  store i32 84, ptr %l30
  br label %bb19
bb19:
  %t70 = load i32, ptr %l30, !range !{i32 0, i32 98}
  store i32 %t70, ptr %l26
  br label %bb20
bb20:
  %t71 = load i32, ptr %l26, !range !{i32 0, i32 98}
  %t72 = load ptr, ptr %l23, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 7
  store i32 %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t77 = add i32 %t75, 1
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 8
  store i32 %t77, ptr %t80, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 9
  store i32 83, ptr %t84
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t88 = add i32 %t86, 1
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 10
  store i32 %t88, ptr %t91, !tbaa !23
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclStarts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l30 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l50 = alloca i1
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 98}
  store i32 %t14, ptr %l2
  %t16 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t18 = trunc i64 33 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t21 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t23 = trunc i64 41 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t29 = trunc i64 40 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t33 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t35 = trunc i64 43 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l16, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/scan:Tokens", ptr %t51, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t47, %t56
  store i1 %t59, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l22, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/scan:Tokens", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = load i64, ptr %l1, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/token:Token", ptr %t73, i64 %t70
  %t75 = load %"compiler/token:Token", ptr %t74
  %t78 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t62, %"compiler/token:Token" %t75)
  store { i64, ptr } %t78, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb20
bb18:
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t80, ptr %l38
  br label %bb19
bb19:
  %t81 = load i1, ptr %l38, !tbaa !21
  store i1 %t81, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l30, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/scan:Tokens", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l42, !tbaa !27
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = getelementptr %"compiler/token:Token", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97, !range !{i32 0, i32 98}
  %t100 = trunc i64 37 to i32
  %t101 = icmp eq i32 %t98, %t100
  store i1 %t101, ptr %l39, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t103 = load i1, ptr %l39, !tbaa !21
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t105 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t107 = trunc i64 37 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t110 = load i64, ptr %l1, !tbaa !24
  %t112 = add i64 %t110, 1
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/scan:Tokens", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t112, %t121
  store i1 %t124, ptr %l50, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t126 = load i1, ptr %l50, !tbaa !21
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/scan:Tokens", ptr %t130, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l61, !tbaa !27
  %t134 = load i64, ptr %l1, !tbaa !24
  %t136 = add i64 %t134, 1
  %t138 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/token:Token", ptr %t139, i64 %t136
  %t141 = getelementptr %"compiler/token:Token", ptr %t140, i32 0, i32 0
  %t142 = load i32, ptr %t141, !range !{i32 0, i32 98}
  %t144 = trunc i64 1 to i32
  %t145 = icmp eq i32 %t142, %t144
  store i1 %t145, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load i1, ptr %l58, !tbaa !21
  store i1 %t147, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t149 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 94)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l10
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l7, !tbaa !29
  %t28 = insertvalue { i32, ptr } zeroinitializer, ptr %t27, 1
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l13
  br label %bb8
bb8:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l1, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 30
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l16
  br label %bb9
bb9:
  %t38 = load i64, ptr %l16, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 95)
  store i1 %t42, ptr %l19
  br label %bb11
bb11:
  %t43 = load i1, ptr %l19, !tbaa !21
  %t44 = xor i1 %t43, true
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 30
  store ptr %t50, ptr %l23, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v0, ptr %t51)
  %t54 = extractvalue { i32, ptr } %t53, 1
  %t55 = extractvalue { i32, ptr } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57, !prof !99
ok.57:
  store ptr %t54, ptr %l26
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l26, !tbaa !29
  store ptr %t58, ptr %l24, !tbaa !29
  br label %bb17
bb16:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t67, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t70, ptr %t71)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t72, i32 95)
  %t76 = extractvalue { i32, i1 } %t75, 1
  %t77 = extractvalue { i32, i1 } %t75, 0
  store i32 %t77, ptr %l33
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb20, label %ok.79, !prof !99
ok.79:
  store i1 %t76, ptr %l32
  br label %bb19
bb19:
  %t80 = load i1, ptr %l32, !tbaa !21
  store i1 %t80, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb21:
  %t92 = load i1, ptr %l29, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb10
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t95, i32 95)
  store i1 %t98, ptr %l38
  br label %bb27
bb27:
  %t99 = load i1, ptr %l38, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 30
  %t105 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t104, i64 %t105)
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l43, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 95)
  store { i64, ptr } %t110, ptr %l45
  br label %bb31
bb31:
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l43, !tbaa !29
  %t120 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t118, { i64, ptr } %t117)
  store i32 %t120, ptr %l47
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb33, label %ok.122, !prof !99
ok.122:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t123 = load i32, ptr %l47, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  call void @__olang_scope_close(ptr %s4)
  %t133 = insertvalue { i32, ptr } zeroinitializer, i32 %t131, 0
  store { i32, ptr } %t133, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t134)
  store i32 %t136, ptr %l50
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t137, i32 %t138)
  store %"compiler/source:Span" %t141, ptr %l53
  br label %bb37
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 30
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t144, i64 %t145)
  store { i64, ptr } %t148, ptr %l57
  br label %bb38
bb38:
  store { i64, [4 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 0
  store i64 18, ptr %t150
  %t151 = load %"compiler/source:Span", ptr %l53
  %t152 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t151, 0
  %t153 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t154 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t152, { i64, ptr } %t153, 1
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t154, ptr %t155
  %t156 = load { i64, [4 x i64] }, ptr %t149
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t156, ptr %t158
  %t160 = insertvalue { i32, ptr } zeroinitializer, ptr %t158, 1
  store { i32, ptr } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca i32
  %l19 = alloca %"compiler/token:Token"
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca %"compiler/token:Token"
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 60)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t8, i64 1)
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7, !range !{i32 0, i32 98}
  %t13 = trunc i64 60 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t19, i64 2)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13, !range !{i32 0, i32 98}
  %t24 = trunc i64 60 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t31, i64 1)
  store %"compiler/token:Token" %t33, ptr %l19
  br label %bb13
bb13:
  %t34 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t35 = load %"compiler/token:Token", ptr %l19
  %t37 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t35, i8 %t34)
  store i1 %t37, ptr %l21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l21, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t41, i64 2)
  store %"compiler/token:Token" %t43, ptr %l25
  br label %bb17
bb16:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb19
bb17:
  %t44 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t45 = load %"compiler/token:Token", ptr %l25
  %t47 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t45, i8 %t44)
  store i1 %t47, ptr %l27
  br label %bb18
bb18:
  %t48 = load i1, ptr %l27, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l23, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l23, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !range !{i32 0, i32 98}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 15
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t17)
  store i32 %t19, ptr %l11
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb8:
  %t20 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t22 = trunc i64 97 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb10:
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 13
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t38 = trunc i64 10 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb20
bb17:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb19
bb18:
  %t41 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t43 = trunc i64 12 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l22, !tbaa !21
  store i1 %t46, ptr %l19, !tbaa !21
  br label %bb20
bb20:
  %t47 = load i1, ptr %l19, !tbaa !21
  br i1 %t47, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 15
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t53 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t55 = trunc i64 93 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb32
bb26:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb28
bb27:
  %t58 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t60 = trunc i64 95 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb30:
  %t64 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t66 = trunc i64 59 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %l27, !tbaa !21
  br label %bb32
bb32:
  %t70 = load i1, ptr %l27, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t71, i32 0, i32 9
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 98}
  store i32 %t74, ptr %l2
  %t76 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t78 = trunc i64 85 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb38
bb37:
  %t81 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t83 = trunc i64 83 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb38
bb38:
  %t86 = load i1, ptr %l40, !tbaa !21
  br i1 %t86, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb41
bb40:
  %t87 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t89 = trunc i64 97 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb41
bb41:
  %t92 = load i1, ptr %l43, !tbaa !21
  br i1 %t92, label %bb42, label %bb43
bb42:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t93)
  store i1 %t95, ptr %l48
  br label %bb44
bb43:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb45
bb44:
  %t96 = load i1, ptr %l48, !tbaa !21
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb45
bb45:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t100, ptr %l51
  br label %bb49
bb49:
  %t101 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t110 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s0, ptr %t108, { i64, ptr } %t107)
  store i32 %t110, ptr %l53
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb51, label %ok.112, !prof !99
ok.112:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t113 = load i32, ptr %l53, !tbaa !23
  %t114 = lshr i32 %t113, 16
  %t115 = and i32 %t113, 65535
  %t116 = icmp eq i32 %t114, 1
  %t117 = select i1 %t116, i32 1, i32 0
  %t118 = icmp eq i32 %t113, 0
  %t119 = shl i32 %t117, 16
  %t120 = or i32 %t119, %t115
  %t121 = select i1 %t118, i32 0, i32 %t120
  call void @__olang_scope_close(ptr %s0)
  store i32 %t121, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca i32
  %l41 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 59)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t6)
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 9
  %t11 = load i32, ptr %t10, !range !{i32 0, i32 98}
  store i32 %t11, ptr %l1
  %t13 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t15 = trunc i64 97 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t18 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t20 = trunc i64 83 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t24 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t26 = trunc i64 85 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t30)
  store i1 %t32, ptr %l18
  br label %bb14
bb13:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb15
bb14:
  %t33 = load i1, ptr %l18, !tbaa !21
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb15
bb15:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb16, label %bb17
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t35)
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i32 0, ptr %rv
  br label %ret
bb19:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t37, i32 8)
  store i1 %t40, ptr %l22
  br label %bb20
bb20:
  %t41 = load i1, ptr %l22, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb21, label %bb22
bb21:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t44, i32 97)
  store i1 %t47, ptr %l27
  br label %bb23
bb22:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i1, ptr %l27, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb25, label %bb26
bb25:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t52, i32 0)
  store i1 %t55, ptr %l32
  br label %bb27
bb26:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb28
bb27:
  %t56 = load i1, ptr %l32, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb28
bb28:
  %t59 = load i1, ptr %l29, !tbaa !21
  br i1 %t59, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t62 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s3, i32 97)
  store { i64, ptr } %t62, ptr %l36
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l34, !tbaa !29
  %t72 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s3, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l38
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb33, label %ok.74, !prof !99
ok.74:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t75 = load i32, ptr %l38, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s3)
  store i32 %t83, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t85)
  store i32 %t87, ptr %l41
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb37, label %ok.89, !prof !99
ok.89:
  br label %bb36
bb36:
  br label %bb38
bb37:
  %t90 = load i32, ptr %l41, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  store i32 %t98, ptr %rv
  br label %ret
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t100)
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i64
  %l15 = alloca i1
  %l17 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 96)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l7
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 35
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l11
  br label %bb4
bb4:
  %t26 = load i64, ptr %l11, !tbaa !24
  store i64 %t26, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t27)
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t29, i32 97)
  store i1 %t32, ptr %l15
  br label %bb6
bb6:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t34, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t36, ptr %l17
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38, !prof !99
ok.38:
  br label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l17, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  call void @__olang_scope_close(ptr %s1)
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t47, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t50, i32 97)
  store i1 %t53, ptr %l21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l21, !tbaa !21
  %t55 = xor i1 %t54, true
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, i32 } %t61, 1
  %t63 = extractvalue { i32, i32 } %t61, 0
  store i32 %t63, ptr %l27
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65, !prof !99
ok.65:
  store i32 %t62, ptr %l26
  br label %bb18
bb18:
  %t66 = load i32, ptr %l26, !tbaa !23
  store i32 %t66, ptr %l24, !tbaa !23
  br label %bb20
bb19:
  %t67 = load i32, ptr %l27, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t75, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb20:
  %t78 = load i32, ptr %l24, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t81, i32 %t78)
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t85)
  store i32 %t87, ptr %l33
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb23, label %ok.89, !prof !99
ok.89:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t90 = load i32, ptr %l33, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  %t100 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t98, 0
  store { i32, { i64, ptr } } %t100, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb13
bb26:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l36
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 35
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l40
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t112 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t111, 1
  store { i32, { i64, ptr } } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t1, i64 1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t20, ptr %lp1
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %lp1
  store ptr %t21, ptr %t22, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %lp1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t23, ptr %t25)
  %t29 = extractvalue { i32, ptr } %t28, 1
  %t30 = extractvalue { i32, ptr } %t28, 0
  store i32 %t30, ptr %l11
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb5, label %ok.32, !prof !99
ok.32:
  store ptr %t29, ptr %l10
  br label %bb4
bb4:
  %t33 = load ptr, ptr %l10, !tbaa !29
  store ptr %t33, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t34 = load i32, ptr %l11, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  %t44 = insertvalue { i32, ptr } zeroinitializer, i32 %t42, 0
  store { i32, ptr } %t44, ptr %rv
  br label %ret
bb6:
  %t45 = load ptr, ptr %l7, !tbaa !29
  %t46 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t195 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 35
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 30}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l20, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 35
  %t27 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t26, i32 %t27)
  br label %bb8
bb8:
  br label %bb27
bb9:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 30}
  %t37 = icmp eq i64 %t35, 14
  store i1 %t37, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l29, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 35
  %t54 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t53, i32 %t54)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb25
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 35
  %t62 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t61, i64 %t62)
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t65, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t67, ptr %l44
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb22, label %ok.69, !prof !99
ok.69:
  br label %bb21
bb21:
  br label %bb23
bb22:
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 %t78, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7f479cc541fc1ad4_6e65e2fdc3321828)
  unreachable
bb25:
  br label %bb26
bb26:
  br label %bb2
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 35
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %s0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l49
  br label %bb28
bb28:
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = icmp sle i64 %t95, 2305843009213693951
  br i1 %t96, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb31:
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = mul i64 %t98, 4
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t103, ptr %lp8
  %t105 = load ptr, ptr %lp8
  store { i64, ptr } %t102, ptr %t105, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb33:
  %t116 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb38
bb35:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l63, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb37
bb37:
  %t136 = load i64, ptr %l63, !tbaa !24
  store i64 %t136, ptr %l60, !tbaa !24
  br label %bb38
bb38:
  %t137 = load i64, ptr %l60, !tbaa !24
  store i64 %t137, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l14, !tbaa !24
  %t156 = load ptr, ptr %lp8
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l81, !tbaa !27
  %t158 = load i64, ptr %l14, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t159, ptr %l83, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t170 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 %t168
  %t173 = load i32, ptr %t172, !tbaa !33
  %t176 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t158
  store i32 %t173, ptr %t178, !tbaa !33
  br label %bb43
bb43:
  %t179 = load i64, ptr %l13, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l13, !tbaa !24
  br label %bb39
bb44:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t183)
  store %"compiler/source:Span" %t185, ptr %l93
  br label %bb45
bb45:
  %t186 = load ptr, ptr %lp8
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l94, !tbaa !27
  %t188 = icmp sge i64 0, 0
  br i1 %t188, label %bb46, label %bb47
bb46:
  %t190 = icmp sle i64 0, 1152921504606846975
  br i1 %t190, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9)
  unreachable
bb48:
  %t192 = mul i64 0, 8
  %t193 = insertvalue { i64, ptr } undef, i64 0, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t195
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 0
  store i64 0, ptr %t196
  %t197 = load %"compiler/source:Span", ptr %l93
  %t198 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t197, 0
  %t199 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t200 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t198, { i64, ptr } %t199, 1
  %t202 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t200, { i64, ptr } %t194, 2
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t202, ptr %t203
  %t204 = load { i64, [5 x i64] }, ptr %t195
  %t206 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t204, ptr %t206
  call void @__olang_scope_close(ptr %s0)
  %t208 = insertvalue { i32, ptr } zeroinitializer, ptr %t206, 1
  store { i32, ptr } %t208, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l19 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 30
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t7)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store ptr %t10, ptr %l8
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  br label %bb7
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 30
  %t18 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb6
bb6:
  %t22 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t26, ptr %t23)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t30, i32 59)
  store i1 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i1, ptr %l19, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb2
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 30
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t39, i64 %t40)
  store { i64, ptr } %t43, ptr %l24
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i64
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i1
  %lp7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %lp9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %lp12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i64
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l89 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/ast:Multi"
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca %"compiler/source:Span"
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l134 = alloca %"compiler/ast:VarDecl"
  %l138 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l150 = alloca i32
  %l151 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %l158 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l170 = alloca %"compiler/source:Span"
  %l172 = alloca i32
  %rv = alloca { i32, ptr }
  %t230 = alloca { i64, [4 x i64] }, align 8
  %t344 = alloca { i64, [4 x i64] }, align 8
  %t443 = alloca { i64, [4 x i64] }, align 8
  %t484 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l20
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l19
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l19, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l20, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t24, ptr %lp2
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %lp2
  store ptr %t25, ptr %t26, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t27, i32 59)
  store i1 %t30, ptr %l24
  br label %bb5
bb5:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 30
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l27
  br label %bb8
bb7:
  br label %bb86
bb8:
  %t37 = load i64, ptr %l27, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 30
  %t41 = load ptr, ptr %lp2
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t40, ptr %t42)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t45, i32 59)
  store i1 %t48, ptr %l33
  br label %bb11
bb11:
  %t49 = load i1, ptr %l33, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 30
  store ptr %t54, ptr %l36, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t55)
  %t58 = extractvalue { i32, ptr } %t57, 1
  %t59 = extractvalue { i32, ptr } %t57, 0
  store i32 %t59, ptr %l40
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb16, label %ok.61, !prof !99
ok.61:
  store ptr %t58, ptr %l39
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l39, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  br label %bb17
bb16:
  %t63 = load i32, ptr %l40, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, ptr } zeroinitializer, i32 %t71, 0
  store { i32, ptr } %t73, ptr %rv
  br label %ret
bb17:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t74, ptr %t75)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb10
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/parse:Parser", ptr %t76, i32 0, i32 30
  %t79 = load i64, ptr %l3, !tbaa !24
  %t82 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l45
  br label %bb21
bb21:
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t83, ptr %lp4
  %t84 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t85 = load ptr, ptr %lp4
  store { i64, ptr } %t84, ptr %t85, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t86, i32 64)
  store i1 %t89, ptr %l48
  br label %bb22
bb22:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/parse:Parser", ptr %t91, i32 0, i32 12
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %lp4
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t102 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v1, ptr %t97, { i64, ptr } %t99)
  %t103 = extractvalue { i32, ptr } %t102, 1
  %t104 = extractvalue { i32, ptr } %t102, 0
  store i32 %t104, ptr %l56
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  store ptr %t103, ptr %l55
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t107 = load ptr, ptr %l55, !tbaa !29
  store ptr %t107, ptr %l52, !tbaa !29
  br label %bb30
bb29:
  %t108 = load i32, ptr %l56, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t118 = insertvalue { i32, ptr } zeroinitializer, i32 %t116, 0
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb30:
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t119, ptr %lp5
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load ptr, ptr %lp5
  store ptr %t120, ptr %t121, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l1, !tbaa !23
  %t124 = load ptr, ptr %lp5
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t129 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t122, i32 %t123, ptr %t125)
  %t130 = extractvalue { i32, ptr } %t129, 1
  %t131 = extractvalue { i32, ptr } %t129, 0
  store i32 %t131, ptr %l63
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb32, label %ok.133, !prof !99
ok.133:
  store ptr %t130, ptr %l62
  br label %bb31
bb31:
  %t134 = load ptr, ptr %l62, !tbaa !29
  store ptr %t134, ptr %l58, !tbaa !29
  br label %bb33
bb32:
  %t135 = load i32, ptr %l63, !tbaa !23
  %t136 = lshr i32 %t135, 16
  %t137 = and i32 %t135, 65535
  %t138 = icmp eq i32 %t136, 1
  %t139 = select i1 %t138, i32 1, i32 0
  %t140 = icmp eq i32 %t135, 0
  %t141 = shl i32 %t139, 16
  %t142 = or i32 %t141, %t137
  %t143 = select i1 %t140, i32 0, i32 %t142
  %t145 = insertvalue { i32, ptr } zeroinitializer, i32 %t143, 0
  store { i32, ptr } %t145, ptr %rv
  br label %ret
bb33:
  %t146 = load ptr, ptr %l58, !tbaa !29
  %t147 = insertvalue { i32, ptr } zeroinitializer, ptr %t146, 1
  store { i32, ptr } %t147, ptr %rv
  br label %ret
bb34:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t148, i32 64)
  store i1 %t151, ptr %l67
  br label %bb35
bb35:
  %t152 = load i1, ptr %l67, !tbaa !21
  br i1 %t152, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb39
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t156 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t153, i32 62)
  store i1 %t156, ptr %l71
  br label %bb38
bb38:
  %t157 = load i1, ptr %l71, !tbaa !21
  store i1 %t157, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t158 = load i1, ptr %l68, !tbaa !21
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 9
  %t162 = load i32, ptr %t161, !range !{i32 0, i32 98}
  %t164 = trunc i64 64 to i32
  %t165 = icmp eq i32 %t162, %t164
  store i1 %t165, ptr %l6, !tbaa !21
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l75, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t168)
  store i32 %t170, ptr %l77
  br label %bb42
bb41:
  br label %bb51
bb42:
  %t171 = load i32, ptr %l77, !tbaa !23
  %t172 = load ptr, ptr %l75, !tbaa !29
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t172, i32 0, i32 24
  store i32 %t171, ptr %t173, !tbaa !23
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %t174)
  %t177 = extractvalue { i32, { i64, ptr } } %t176, 1
  %t178 = extractvalue { i32, { i64, ptr } } %t176, 0
  store i32 %t178, ptr %l81
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb44, label %ok.180, !prof !99
ok.180:
  store { i64, ptr } %t177, ptr %l80
  br label %bb43
bb43:
  %t181 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t181, ptr %l78, !tbaa !27
  br label %bb45
bb44:
  %t182 = load i32, ptr %l81, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb45:
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t193, ptr %lp7
  %t194 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t195 = load ptr, ptr %lp7
  store { i64, ptr } %t194, ptr %t195, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l1, !tbaa !23
  %t200 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t196, i32 %t197)
  store %"compiler/source:Span" %t200, ptr %l85
  br label %bb46
bb46:
  %t201 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t201, ptr %l8
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t202)
  store i32 %t204, ptr %l87
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb48, label %ok.206, !prof !99
ok.206:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t207 = load i32, ptr %l87, !tbaa !23
  %t208 = lshr i32 %t207, 16
  %t209 = and i32 %t207, 65535
  %t210 = icmp eq i32 %t208, 1
  %t211 = select i1 %t210, i32 1, i32 0
  %t212 = icmp eq i32 %t207, 0
  %t213 = shl i32 %t211, 16
  %t214 = or i32 %t213, %t209
  %t215 = select i1 %t212, i32 0, i32 %t214
  %t217 = insertvalue { i32, ptr } zeroinitializer, i32 %t215, 0
  store { i32, ptr } %t217, ptr %rv
  br label %ret
bb49:
  %t218 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t218, ptr %l89
  %t219 = load ptr, ptr %lp4
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = load i1, ptr %l6, !tbaa !21
  %t222 = load ptr, ptr %lp7
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  %t227 = call %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t220, i1 %t221, { i64, ptr } %t223)
  store %"compiler/ast:Multi" %t227, ptr %l93
  br label %bb50
bb50:
  %t228 = load %"compiler/ast:Multi", ptr %l93
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:Multi" %t228, ptr %t229
  store { i64, [4 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t230, i32 0, i32 0
  store i64 2, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l89
  %t233 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t232, 0
  %t235 = insertvalue { %"compiler/source:Span", ptr } %t233, ptr %t229, 1
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t230, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t235, ptr %t236
  %t237 = load { i64, [4 x i64] }, ptr %t230
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t237, ptr %t239
  %t241 = insertvalue { i32, ptr } zeroinitializer, ptr %t239, 1
  store { i32, ptr } %t241, ptr %rv
  br label %ret
bb51:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %lp4
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t247 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v1, ptr %t242, { i64, ptr } %t244)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l101
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb53, label %ok.251, !prof !99
ok.251:
  store ptr %t248, ptr %l100
  br label %bb52
bb52:
  %t252 = load ptr, ptr %l100, !tbaa !29
  store ptr %t252, ptr %l97, !tbaa !29
  br label %bb54
bb53:
  %t253 = load i32, ptr %l101, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t263 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t263, ptr %rv
  br label %ret
bb54:
  %t264 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t264, ptr %lp9
  %t265 = load ptr, ptr %l97, !tbaa !29
  %t266 = load ptr, ptr %lp9
  store ptr %t265, ptr %t266, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/parse:Parser", ptr %t267, i32 0, i32 12
  %t270 = load i1, ptr %t269, !tbaa !21
  br i1 %t270, label %bb55, label %bb56
bb55:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t272, i32 8)
  store i1 %t275, ptr %l108
  br label %bb57
bb56:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb66
bb57:
  %t276 = load i1, ptr %l108, !tbaa !21
  br i1 %t276, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb61
bb59:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t280 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t277, i32 97)
  store i1 %t280, ptr %l112
  br label %bb60
bb60:
  %t281 = load i1, ptr %l112, !tbaa !21
  store i1 %t281, ptr %l109, !tbaa !21
  br label %bb61
bb61:
  %t282 = load i1, ptr %l109, !tbaa !21
  br i1 %t282, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb65
bb63:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t286 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t283, i32 0)
  store i1 %t286, ptr %l116
  br label %bb64
bb64:
  %t287 = load i1, ptr %l116, !tbaa !21
  store i1 %t287, ptr %l113, !tbaa !21
  br label %bb65
bb65:
  %t288 = load i1, ptr %l113, !tbaa !21
  store i1 %t288, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t289 = load i1, ptr %l105, !tbaa !21
  br i1 %t289, label %bb67, label %bb68
bb67:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l1, !tbaa !23
  %t294 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t290, i32 %t291)
  store %"compiler/source:Span" %t294, ptr %l119
  br label %bb69
bb68:
  br label %bb82
bb69:
  %t295 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t295, ptr %l10
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t296)
  store i32 %t298, ptr %l121
  %t299 = icmp ne i32 %t298, 0
  br i1 %t299, label %bb71, label %ok.300, !prof !99
ok.300:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t301 = load i32, ptr %l121, !tbaa !23
  %t302 = lshr i32 %t301, 16
  %t303 = and i32 %t301, 65535
  %t304 = icmp eq i32 %t302, 1
  %t305 = select i1 %t304, i32 1, i32 0
  %t306 = icmp eq i32 %t301, 0
  %t307 = shl i32 %t305, 16
  %t308 = or i32 %t307, %t303
  %t309 = select i1 %t306, i32 0, i32 %t308
  %t311 = insertvalue { i32, ptr } zeroinitializer, i32 %t309, 0
  store { i32, ptr } %t311, ptr %rv
  br label %ret
bb72:
  %t312 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t312, ptr %l123
  %t313 = load ptr, ptr %lp9
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/parse:NameList", ptr %t314, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  store { i64, ptr } %t317, ptr %l125, !tbaa !27
  %t318 = load ptr, ptr %lp9
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = getelementptr %"compiler/parse:NameList", ptr %t319, i32 0, i32 1
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l127, !tbaa !27
  %t323 = icmp sge i64 0, 0
  br i1 %t323, label %bb73, label %bb74
bb73:
  %t325 = icmp sle i64 0, 1152921504606846975
  br i1 %t325, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb75:
  %t327 = mul i64 0, 8
  %t328 = insertvalue { i64, ptr } undef, i64 0, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t329, ptr %l130, !tbaa !27
  %t330 = icmp sge i64 0, 0
  br i1 %t330, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb77:
  %t332 = icmp sle i64 0, 1152921504606846975
  br i1 %t332, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_bce5f5de212629d8_a497bbae1a0b61c)
  unreachable
bb79:
  %t334 = mul i64 0, 8
  %t335 = insertvalue { i64, ptr } undef, i64 0, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t337 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t341 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t337, { i64, ptr } %t338, ptr null, { i64, ptr } %t339, i1 false, i1 true, { i64, ptr } %t336, i1 false)
  store %"compiler/ast:VarDecl" %t341, ptr %l134
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_bce5f5de212629d8_a497bbae1a0b61c)
  unreachable
bb81:
  %t342 = load %"compiler/ast:VarDecl", ptr %l134
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:VarDecl" %t342, ptr %t343
  store { i64, [4 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t344, i32 0, i32 0
  store i64 1, ptr %t345
  %t346 = load %"compiler/source:Span", ptr %l123
  %t347 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t346, 0
  %t349 = insertvalue { %"compiler/source:Span", ptr } %t347, ptr %t343, 1
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t344, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t349, ptr %t350
  %t351 = load { i64, [4 x i64] }, ptr %t344
  %t353 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t351, ptr %t353
  %t355 = insertvalue { i32, ptr } zeroinitializer, ptr %t353, 1
  store { i32, ptr } %t355, ptr %rv
  br label %ret
bb82:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t358 = load ptr, ptr %lp9
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t363 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t356, i32 %t357, ptr %t359)
  %t364 = extractvalue { i32, ptr } %t363, 1
  %t365 = extractvalue { i32, ptr } %t363, 0
  store i32 %t365, ptr %l143
  %t366 = icmp ne i32 %t365, 0
  br i1 %t366, label %bb84, label %ok.367, !prof !99
ok.367:
  store ptr %t364, ptr %l142
  br label %bb83
bb83:
  %t368 = load ptr, ptr %l142, !tbaa !29
  store ptr %t368, ptr %l138, !tbaa !29
  br label %bb85
bb84:
  %t369 = load i32, ptr %l143, !tbaa !23
  %t370 = lshr i32 %t369, 16
  %t371 = and i32 %t369, 65535
  %t372 = icmp eq i32 %t370, 1
  %t373 = select i1 %t372, i32 1, i32 0
  %t374 = icmp eq i32 %t369, 0
  %t375 = shl i32 %t373, 16
  %t376 = or i32 %t375, %t371
  %t377 = select i1 %t374, i32 0, i32 %t376
  %t379 = insertvalue { i32, ptr } zeroinitializer, i32 %t377, 0
  store { i32, ptr } %t379, ptr %rv
  br label %ret
bb85:
  %t380 = load ptr, ptr %l138, !tbaa !29
  %t381 = insertvalue { i32, ptr } zeroinitializer, ptr %t380, 1
  store { i32, ptr } %t381, ptr %rv
  br label %ret
bb86:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t382)
  store i32 %t384, ptr %l146
  br label %bb87
bb87:
  %t385 = load i32, ptr %l146, !range !{i32 0, i32 98}
  store i32 %t385, ptr %l11
  %t386 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t388 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t386)
  store i1 %t388, ptr %l148
  br label %bb88
bb88:
  %t389 = load i1, ptr %l148, !tbaa !21
  br i1 %t389, label %bb89, label %bb90
bb89:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l150
  br label %bb91
bb90:
  br label %bb99
bb91:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t393)
  %t396 = extractvalue { i32, ptr } %t395, 1
  %t397 = extractvalue { i32, ptr } %t395, 0
  store i32 %t397, ptr %l154
  %t398 = icmp ne i32 %t397, 0
  br i1 %t398, label %bb93, label %ok.399, !prof !99
ok.399:
  store ptr %t396, ptr %l153
  br label %bb92
bb92:
  %t400 = load ptr, ptr %l153, !tbaa !29
  store ptr %t400, ptr %l151, !tbaa !29
  br label %bb94
bb93:
  %t401 = load i32, ptr %l154, !tbaa !23
  %t402 = lshr i32 %t401, 16
  %t403 = and i32 %t401, 65535
  %t404 = icmp eq i32 %t402, 1
  %t405 = select i1 %t404, i32 1, i32 0
  %t406 = icmp eq i32 %t401, 0
  %t407 = shl i32 %t405, 16
  %t408 = or i32 %t407, %t403
  %t409 = select i1 %t406, i32 0, i32 %t408
  %t411 = insertvalue { i32, ptr } zeroinitializer, i32 %t409, 0
  store { i32, ptr } %t411, ptr %rv
  br label %ret
bb94:
  %t412 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t412, ptr %lp12
  %t413 = load ptr, ptr %l151, !tbaa !29
  %t414 = load ptr, ptr %lp12
  store ptr %t413, ptr %t414, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i32, ptr %l1, !tbaa !23
  %t419 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t415, i32 %t416)
  store %"compiler/source:Span" %t419, ptr %l158
  br label %bb95
bb95:
  %t420 = load %"compiler/source:Span", ptr %l158
  store %"compiler/source:Span" %t420, ptr %l13
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t421)
  store i32 %t423, ptr %l160
  %t424 = icmp ne i32 %t423, 0
  br i1 %t424, label %bb97, label %ok.425, !prof !99
ok.425:
  br label %bb96
bb96:
  br label %bb98
bb97:
  %t426 = load i32, ptr %l160, !tbaa !23
  %t427 = lshr i32 %t426, 16
  %t428 = and i32 %t426, 65535
  %t429 = icmp eq i32 %t427, 1
  %t430 = select i1 %t429, i32 1, i32 0
  %t431 = icmp eq i32 %t426, 0
  %t432 = shl i32 %t430, 16
  %t433 = or i32 %t432, %t428
  %t434 = select i1 %t431, i32 0, i32 %t433
  %t436 = insertvalue { i32, ptr } zeroinitializer, i32 %t434, 0
  store { i32, ptr } %t436, ptr %rv
  br label %ret
bb98:
  %t437 = load %"compiler/source:Span", ptr %l13
  %t438 = load i32, ptr %l11, !range !{i32 0, i32 98}
  %t439 = load ptr, ptr %lp2
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t441 = load ptr, ptr %lp12
  %t442 = load ptr, ptr %t441, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t443
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 0
  store i64 3, ptr %t444
  %t446 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t437, 0
  %t448 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t446, i32 %t438, 1
  %t450 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t448, ptr %t440, 2
  %t452 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t450, ptr %t442, 3
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t452, ptr %t453
  %t454 = load { i64, [4 x i64] }, ptr %t443
  %t456 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t454, ptr %t456
  %t458 = insertvalue { i32, ptr } zeroinitializer, ptr %t456, 1
  store { i32, ptr } %t458, ptr %rv
  br label %ret
bb99:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l1, !tbaa !23
  %t463 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t459, i32 %t460)
  store %"compiler/source:Span" %t463, ptr %l170
  br label %bb100
bb100:
  %t464 = load %"compiler/source:Span", ptr %l170
  store %"compiler/source:Span" %t464, ptr %l14
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t465)
  store i32 %t467, ptr %l172
  %t468 = icmp ne i32 %t467, 0
  br i1 %t468, label %bb102, label %ok.469, !prof !99
ok.469:
  br label %bb101
bb101:
  br label %bb103
bb102:
  %t470 = load i32, ptr %l172, !tbaa !23
  %t471 = lshr i32 %t470, 16
  %t472 = and i32 %t470, 65535
  %t473 = icmp eq i32 %t471, 1
  %t474 = select i1 %t473, i32 1, i32 0
  %t475 = icmp eq i32 %t470, 0
  %t476 = shl i32 %t474, 16
  %t477 = or i32 %t476, %t472
  %t478 = select i1 %t475, i32 0, i32 %t477
  %t480 = insertvalue { i32, ptr } zeroinitializer, i32 %t478, 0
  store { i32, ptr } %t480, ptr %rv
  br label %ret
bb103:
  %t481 = load %"compiler/source:Span", ptr %l14
  %t482 = load ptr, ptr %lp2
  %t483 = load ptr, ptr %t482, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t484
  %t485 = getelementptr { i64, [4 x i64] }, ptr %t484, i32 0, i32 0
  store i64 0, ptr %t485
  %t487 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t481, 0
  %t489 = insertvalue { %"compiler/source:Span", ptr } %t487, ptr %t483, 1
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t484, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t489, ptr %t490
  %t491 = load { i64, [4 x i64] }, ptr %t484
  %t493 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t491, ptr %t493
  %t495 = insertvalue { i32, ptr } zeroinitializer, ptr %t493, 1
  store { i32, ptr } %t495, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca %"compiler/ast:TypeDecl"
  %l61 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l73 = alloca i32
  %l76 = alloca i32
  %l80 = alloca i32
  %l84 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t118 = alloca { i64, [6 x i64] }, align 8
  %t137 = alloca { i64, [6 x i64] }, align 8
  %t179 = alloca { i64, [6 x i64] }, align 8
  %t239 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 96)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 37
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t27)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t29, i32 97)
  store i1 %t32, ptr %l19
  br label %bb7
bb7:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  br label %bb54
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t38, i32 0)
  store i1 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 97)
  store { i64, ptr } %t45, ptr %l27
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t55 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } %t52)
  store i32 %t55, ptr %l29
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57, !prof !99
ok.57:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t58 = load i32, ptr %l29, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s2)
  %t68 = insertvalue { i32, ptr } zeroinitializer, i32 %t66, 0
  store { i32, ptr } %t68, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t69)
  store i32 %t71, ptr %l32
  br label %bb19
bb19:
  %t72 = load i32, ptr %l32, !tbaa !23
  store i32 %t72, ptr %l4, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t73, i32 33)
  store i1 %t76, ptr %l35
  br label %bb20
bb20:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t78)
  %t81 = extractvalue { i32, i32 } %t80, 1
  %t82 = extractvalue { i32, i32 } %t80, 0
  store i32 %t82, ptr %l39
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb24, label %ok.84, !prof !99
ok.84:
  store i32 %t81, ptr %l38
  br label %bb23
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 37)
  store i1 %t88, ptr %l61
  br label %bb37
bb23:
  %t89 = load i32, ptr %l38, !tbaa !23
  store i32 %t89, ptr %l36, !tbaa !23
  br label %bb25
bb24:
  %t90 = load i32, ptr %l39, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  %t100 = insertvalue { i32, ptr } zeroinitializer, i32 %t98, 0
  store { i32, ptr } %t100, ptr %rv
  br label %ret
bb25:
  %t101 = load i32, ptr %l36, !tbaa !23
  store i32 %t101, ptr %l5, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 37
  store ptr %t104, ptr %l42, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l4, !tbaa !23
  %t109 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t105, i32 %t106)
  store %"compiler/source:Span" %t109, ptr %l45
  br label %bb26
bb26:
  %t110 = load i32, ptr %l5, !tbaa !23
  store i32 %t110, ptr %l46, !tbaa !23
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t113 = icmp sle i64 0, 1152921504606846975
  br i1 %t113, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb29:
  %t115 = mul i64 0, 8
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t117, ptr %l49, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [6 x i64] }, ptr %t118, i32 0, i32 0
  store i64 4, ptr %t119
  %t120 = load { i64, [6 x i64] }, ptr %t118
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t120, ptr %t122
  store ptr %t122, ptr %l51, !tbaa !29
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb31:
  %t125 = icmp sle i64 0, 1152921504606846975
  br i1 %t125, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_34506b7f0a96de24_ffbbf03839f4b990)
  unreachable
bb33:
  %t127 = mul i64 0, 8
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t130 = load i32, ptr %l46, !tbaa !23
  %t131 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t132 = load ptr, ptr %l51, !tbaa !29
  %t134 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t130, { i64, ptr } %t131, i1 false, ptr %t132, { i64, ptr } %t129)
  store %"compiler/ast:TypeDecl" %t134, ptr %l55
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_34506b7f0a96de24_ffbbf03839f4b990)
  unreachable
bb35:
  %t135 = load %"compiler/ast:TypeDecl", ptr %l55
  %t136 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/ast:TypeDecl" %t135, ptr %t136
  store { i64, [6 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [6 x i64] }, ptr %t137, i32 0, i32 0
  store i64 2, ptr %t138
  %t139 = load %"compiler/source:Span", ptr %l45
  %t140 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t139, 0
  %t142 = insertvalue { %"compiler/source:Span", ptr } %t140, ptr %t136, 1
  %t143 = getelementptr { i64, [6 x i64] }, ptr %t137, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t142, ptr %t143
  %t144 = load { i64, [6 x i64] }, ptr %t137
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t144, ptr %t146
  %t147 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t147, ptr %t146)
  br label %bb36
bb36:
  br label %bb48
bb37:
  %t149 = load i1, ptr %l61, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t150, i32 0, i32 37
  store ptr %t152, ptr %l63, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l4, !tbaa !23
  %t157 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v0, ptr %t153, i32 %t154)
  %t158 = extractvalue { i32, ptr } %t157, 1
  %t159 = extractvalue { i32, ptr } %t157, 0
  store i32 %t159, ptr %l68
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb41, label %ok.161, !prof !99
ok.161:
  store ptr %t158, ptr %l67
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s6, ptr %t162, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t164, ptr %l73
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb45, label %ok.166, !prof !99
ok.166:
  br label %bb44
bb40:
  %t167 = load ptr, ptr %l67, !tbaa !29
  store ptr %t167, ptr %l64, !tbaa !29
  br label %bb42
bb41:
  %t168 = load i32, ptr %l68, !tbaa !23
  %t169 = lshr i32 %t168, 16
  %t170 = and i32 %t168, 65535
  %t171 = icmp eq i32 %t169, 1
  %t172 = select i1 %t171, i32 1, i32 0
  %t173 = icmp eq i32 %t168, 0
  %t174 = shl i32 %t172, 16
  %t175 = or i32 %t174, %t170
  %t176 = select i1 %t173, i32 0, i32 %t175
  %t178 = insertvalue { i32, ptr } zeroinitializer, i32 %t176, 0
  store { i32, ptr } %t178, ptr %rv
  br label %ret
bb42:
  store { i64, [6 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [6 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load ptr, ptr %l64, !tbaa !29
  %t182 = insertvalue { ptr } undef, ptr %t181, 0
  %t183 = getelementptr { i64, [6 x i64] }, ptr %t179, i32 0, i32 1
  store { ptr } %t182, ptr %t183
  %t184 = load { i64, [6 x i64] }, ptr %t179
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t184, ptr %t186
  %t187 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t187, ptr %t186)
  br label %bb43
bb43:
  br label %bb47
bb44:
  br label %bb46
bb45:
  %t189 = load i32, ptr %l73, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  call void @__olang_scope_close(ptr %s6)
  %t199 = insertvalue { i32, ptr } zeroinitializer, i32 %t197, 0
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t200)
  store i32 %t202, ptr %l76
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb50, label %ok.204, !prof !99
ok.204:
  br label %bb49
bb49:
  br label %bb51
bb50:
  %t205 = load i32, ptr %l76, !tbaa !23
  %t206 = lshr i32 %t205, 16
  %t207 = and i32 %t205, 65535
  %t208 = icmp eq i32 %t206, 1
  %t209 = select i1 %t208, i32 1, i32 0
  %t210 = icmp eq i32 %t205, 0
  %t211 = shl i32 %t209, 16
  %t212 = or i32 %t211, %t207
  %t213 = select i1 %t210, i32 0, i32 %t212
  %t215 = insertvalue { i32, ptr } zeroinitializer, i32 %t213, 0
  store { i32, ptr } %t215, ptr %rv
  br label %ret
bb51:
  %t216 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t216)
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb6
bb54:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t218)
  store i32 %t220, ptr %l80
  br label %bb55
bb55:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t221, i32 0, i32 37
  %t224 = load i64, ptr %l3, !tbaa !24
  %t227 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %t223, i64 %t224)
  store { i64, ptr } %t227, ptr %l84
  br label %bb56
bb56:
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t228, ptr %lp6
  %t229 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t230 = load ptr, ptr %lp6
  store { i64, ptr } %t229, ptr %t230, !tbaa !27
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t235 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t231, i32 %a1)
  store %"compiler/source:Span" %t235, ptr %l87
  br label %bb57
bb57:
  %t237 = load ptr, ptr %lp6
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [6 x i64] }, ptr %t239, i32 0, i32 0
  store i64 10, ptr %t240
  %t241 = load %"compiler/source:Span", ptr %l87
  %t242 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t241, 0
  %t244 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t242, %"compiler/source:Span" %a2, 1
  %t246 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t244, { i64, ptr } %t238, 2
  %t247 = getelementptr { i64, [6 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t246, ptr %t247
  %t248 = load { i64, [6 x i64] }, ptr %t239
  %t250 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store { i64, [6 x i64] } %t248, ptr %t250
  %t252 = insertvalue { i32, ptr } zeroinitializer, ptr %t250, 1
  store { i32, ptr } %t252, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %lp4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i1
  %lp10 = alloca ptr
  %l11 = alloca i64
  %lp12 = alloca ptr
  %lp13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %lp18 = alloca ptr
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %lp21 = alloca ptr
  %lp22 = alloca ptr
  %lp23 = alloca ptr
  %lp24 = alloca ptr
  %lp25 = alloca ptr
  %lp26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %lp28 = alloca ptr
  %lp29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l51 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l56 = alloca i32
  %l63 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i32
  %l73 = alloca i32
  %l74 = alloca i32
  %l78 = alloca i1
  %l80 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i32
  %l85 = alloca i32
  %l88 = alloca i32
  %l89 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i32
  %l101 = alloca i64
  %l104 = alloca i1
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l130 = alloca %"compiler/source:Span"
  %l133 = alloca i1
  %l135 = alloca i32
  %l136 = alloca %"compiler/source:Span"
  %l144 = alloca %"compiler/ast:ForIn"
  %l150 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i32
  %l159 = alloca %"compiler/token:Token"
  %l160 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca i32
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca ptr
  %l173 = alloca i1
  %l174 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca i32
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l188 = alloca %"compiler/ast:VarDecl"
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca i32
  %l195 = alloca i32
  %l198 = alloca i32
  %l199 = alloca i32
  %l201 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca i32
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l217 = alloca %"compiler/ast:VarDecl"
  %l221 = alloca %"compiler/source:Span"
  %l226 = alloca i32
  %l229 = alloca i32
  %l230 = alloca i32
  %l232 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca i32
  %l237 = alloca i32
  %l240 = alloca i32
  %l241 = alloca i32
  %l243 = alloca ptr
  %l245 = alloca ptr
  %l246 = alloca i32
  %l248 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l251 = alloca i32
  %l255 = alloca %"compiler/source:Span"
  %l258 = alloca i1
  %l260 = alloca i32
  %l261 = alloca %"compiler/source:Span"
  %l267 = alloca %"compiler/ast:For3"
  %l273 = alloca i32
  %l275 = alloca ptr
  %l277 = alloca ptr
  %l278 = alloca i32
  %l280 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l283 = alloca i32
  %l287 = alloca %"compiler/source:Span"
  %l290 = alloca i1
  %l292 = alloca i32
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t74 = alloca { i64, [4 x i64] }, align 8
  %t312 = alloca { i64, [4 x i64] }, align 8
  %t566 = alloca { i64, [4 x i64] }, align 8
  %t713 = alloca { i64, [4 x i64] }, align 8
  %t806 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 25)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l35
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l34
  br label %bb1
bb1:
  %t9 = load i32, ptr %l34, !tbaa !23
  store i32 %t9, ptr %l31, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l35, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l31, !tbaa !23
  store i32 %t21, ptr %l2, !tbaa !23
  %t22 = load i32, ptr %l1, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  store i1 %t24, ptr %l3, !tbaa !21
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load i32, ptr %l1, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t30, i32 96)
  store i1 %t33, ptr %l43
  br label %bb7
bb7:
  %t34 = load i1, ptr %l43, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t35)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l47
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41, !prof !99
ok.41:
  store { i64, ptr } %t38, ptr %l46
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t42 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t42, ptr %l44, !tbaa !27
  br label %bb12
bb11:
  %t43 = load i32, ptr %l47, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  %t53 = insertvalue { i32, ptr } zeroinitializer, i32 %t51, 0
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb12:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t54, ptr %lp4
  %t55 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t56 = load ptr, ptr %lp4
  store { i64, ptr } %t55, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t57, i32 %t58)
  store %"compiler/source:Span" %t61, ptr %l51
  br label %bb13
bb13:
  %t62 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t62, ptr %l5
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t63, i32 8)
  store i1 %t66, ptr %l54
  br label %bb14
bb14:
  %t67 = load i1, ptr %l54, !tbaa !21
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t68)
  store i32 %t70, ptr %l56
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t71 = load %"compiler/source:Span", ptr %l5
  %t72 = load ptr, ptr %lp4
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 0
  store i64 6, ptr %t75
  %t77 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t71, 0
  %t79 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t77, { i64, ptr } %t73, 1
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t79, ptr %t80
  %t81 = load { i64, [4 x i64] }, ptr %t74
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t81, ptr %t83
  %t85 = insertvalue { i32, ptr } zeroinitializer, ptr %t83, 1
  store { i32, ptr } %t85, ptr %rv
  br label %ret
bb19:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t86, i32 1)
  store i1 %t89, ptr %l63
  br label %bb20
bb20:
  %t90 = load i1, ptr %l63, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t91, i64 1)
  store i32 %t93, ptr %l65
  br label %bb23
bb22:
  br label %bb144
bb23:
  %t94 = load i32, ptr %l65, !range !{i32 0, i32 98}
  store i32 %t94, ptr %l6
  %t95 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t97 = trunc i64 27 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb26
bb25:
  %t100 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t102 = trunc i64 59 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t105 = load i1, ptr %l68, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i32 0, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t106)
  %t109 = extractvalue { i32, i32 } %t108, 1
  %t110 = extractvalue { i32, i32 } %t108, 0
  store i32 %t110, ptr %l74
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb30, label %ok.112, !prof !99
ok.112:
  store i32 %t109, ptr %l73
  br label %bb29
bb28:
  br label %bb75
bb29:
  %t113 = load i32, ptr %l73, !tbaa !23
  store i32 %t113, ptr %l71, !tbaa !23
  br label %bb31
bb30:
  %t114 = load i32, ptr %l74, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  %t124 = insertvalue { i32, ptr } zeroinitializer, i32 %t122, 0
  store { i32, ptr } %t124, ptr %rv
  br label %ret
bb31:
  %t125 = load i32, ptr %l71, !tbaa !23
  store i32 %t125, ptr %l8, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t126, i32 59)
  store i1 %t129, ptr %l78
  br label %bb32
bb32:
  %t130 = load i1, ptr %l78, !tbaa !21
  br i1 %t130, label %bb33, label %bb34
bb33:
  %t131 = load i32, ptr %l8, !tbaa !23
  store i32 %t131, ptr %l7, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t133)
  %t136 = extractvalue { i32, i32 } %t135, 1
  %t137 = extractvalue { i32, i32 } %t135, 0
  store i32 %t137, ptr %l83
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb36, label %ok.139, !prof !99
ok.139:
  store i32 %t136, ptr %l82
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t140 = load i32, ptr %l82, !tbaa !23
  store i32 %t140, ptr %l80, !tbaa !23
  br label %bb37
bb36:
  %t141 = load i32, ptr %l83, !tbaa !23
  %t142 = lshr i32 %t141, 16
  %t143 = and i32 %t141, 65535
  %t144 = icmp eq i32 %t142, 1
  %t145 = select i1 %t144, i32 1, i32 0
  %t146 = icmp eq i32 %t141, 0
  %t147 = shl i32 %t145, 16
  %t148 = or i32 %t147, %t143
  %t149 = select i1 %t146, i32 0, i32 %t148
  %t151 = insertvalue { i32, ptr } zeroinitializer, i32 %t149, 0
  store { i32, ptr } %t151, ptr %rv
  br label %ret
bb37:
  %t152 = load i32, ptr %l80, !tbaa !23
  store i32 %t152, ptr %l8, !tbaa !23
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t156 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t153, i32 27)
  %t157 = extractvalue { i32, i32 } %t156, 1
  %t158 = extractvalue { i32, i32 } %t156, 0
  store i32 %t158, ptr %l89
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb40, label %ok.160, !prof !99
ok.160:
  store i32 %t157, ptr %l88
  br label %bb39
bb39:
  %t161 = load i32, ptr %l88, !tbaa !23
  store i32 %t161, ptr %l85, !tbaa !23
  br label %bb41
bb40:
  %t162 = load i32, ptr %l89, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  %t172 = insertvalue { i32, ptr } zeroinitializer, i32 %t170, 0
  store { i32, ptr } %t172, ptr %rv
  br label %ret
bb41:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t176 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t173, i32 11)
  store i1 %t176, ptr %l93
  br label %bb42
bb42:
  %t177 = load i1, ptr %l93, !tbaa !21
  store i1 %t177, ptr %l9, !tbaa !21
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %v1, ptr %t178)
  %t181 = extractvalue { i32, ptr } %t180, 1
  %t182 = extractvalue { i32, ptr } %t180, 0
  store i32 %t182, ptr %l97
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb44, label %ok.184, !prof !99
ok.184:
  store ptr %t181, ptr %l96
  br label %bb43
bb43:
  %t185 = load ptr, ptr %l96, !tbaa !29
  store ptr %t185, ptr %l94, !tbaa !29
  br label %bb45
bb44:
  %t186 = load i32, ptr %l97, !tbaa !23
  %t187 = lshr i32 %t186, 16
  %t188 = and i32 %t186, 65535
  %t189 = icmp eq i32 %t187, 1
  %t190 = select i1 %t189, i32 1, i32 0
  %t191 = icmp eq i32 %t186, 0
  %t192 = shl i32 %t190, 16
  %t193 = or i32 %t192, %t188
  %t194 = select i1 %t191, i32 0, i32 %t193
  %t196 = insertvalue { i32, ptr } zeroinitializer, i32 %t194, 0
  store { i32, ptr } %t196, ptr %rv
  br label %ret
bb45:
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t197, ptr %lp10
  %t198 = load ptr, ptr %l94, !tbaa !29
  %t199 = load ptr, ptr %lp10
  store ptr %t198, ptr %t199, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t200, i32 0, i32 29
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t202)
  store i64 %t204, ptr %l101
  br label %bb46
bb46:
  %t205 = load i64, ptr %l101, !tbaa !24
  store i64 %t205, ptr %l11, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %lp10
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t211 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %t206, ptr %t208)
  store i1 %t211, ptr %l104
  br label %bb47
bb47:
  %t212 = load i1, ptr %l104, !tbaa !21
  br i1 %t212, label %bb48, label %bb49
bb48:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 29
  %t216 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t215, i32 %t216)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t219)
  %t222 = extractvalue { i32, { i64, ptr } } %t221, 1
  %t223 = extractvalue { i32, { i64, ptr } } %t221, 0
  store i32 %t223, ptr %l111
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb53, label %ok.225, !prof !99
ok.225:
  store { i64, ptr } %t222, ptr %l110
  br label %bb52
bb52:
  %t226 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t226, ptr %l108, !tbaa !27
  br label %bb56
bb53:
  br label %bb54
bb54:
  call void @__olang_ert_req_clear()
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 29
  %t230 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t229, i64 %t230)
  br label %bb55
bb55:
  %t234 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t234, ptr %rv
  br label %ret
bb56:
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t235, ptr %lp12
  %t236 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t237 = load ptr, ptr %lp12
  store { i64, ptr } %t236, ptr %t237, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 29
  %t241 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t240, i64 %t241)
  br label %bb57
bb57:
  %t244 = icmp sge i64 0, 0
  br i1 %t244, label %bb58, label %bb59
bb58:
  %t246 = icmp sle i64 0, 1152921504606846975
  br i1 %t246, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb60:
  %t248 = mul i64 0, 8
  %t249 = insertvalue { i64, ptr } undef, i64 0, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t251, ptr %lp13
  %t253 = load ptr, ptr %lp13
  store { i64, ptr } %t250, ptr %t253, !tbaa !27
  %t254 = load i1, ptr %l9, !tbaa !21
  br i1 %t254, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb62:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t256, i1 false)
  %t259 = extractvalue { i32, { i64, ptr } } %t258, 1
  %t260 = extractvalue { i32, { i64, ptr } } %t258, 0
  store i32 %t260, ptr %l126
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb65, label %ok.262, !prof !99
ok.262:
  store { i64, ptr } %t259, ptr %l125
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t263 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t263, ptr %l123, !tbaa !27
  br label %bb66
bb65:
  %t264 = load i32, ptr %l126, !tbaa !23
  %t265 = lshr i32 %t264, 16
  %t266 = and i32 %t264, 65535
  %t267 = icmp eq i32 %t265, 1
  %t268 = select i1 %t267, i32 1, i32 0
  %t269 = icmp eq i32 %t264, 0
  %t270 = shl i32 %t268, 16
  %t271 = or i32 %t270, %t266
  %t272 = select i1 %t269, i32 0, i32 %t271
  %t274 = insertvalue { i32, ptr } zeroinitializer, i32 %t272, 0
  store { i32, ptr } %t274, ptr %rv
  br label %ret
bb66:
  %t275 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t276 = load ptr, ptr %lp13
  store { i64, ptr } %t275, ptr %t276, !tbaa !27
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i32, ptr %l2, !tbaa !23
  %t281 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t277, i32 %t278)
  store %"compiler/source:Span" %t281, ptr %l130
  br label %bb68
bb68:
  %t282 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t282, ptr %l14
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t286 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t283, i32 8)
  store i1 %t286, ptr %l133
  br label %bb69
bb69:
  %t287 = load i1, ptr %l133, !tbaa !21
  br i1 %t287, label %bb70, label %bb71
bb70:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t288)
  store i32 %t290, ptr %l135
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t291 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t291, ptr %l136
  %t292 = load i32, ptr %l7, !tbaa !23
  %t293 = load i32, ptr %l8, !tbaa !23
  %t294 = load ptr, ptr %lp10
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = load i1, ptr %l9, !tbaa !21
  %t297 = load ptr, ptr %lp12
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  %t299 = load ptr, ptr %lp13
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  %t301 = load i1, ptr %l3, !tbaa !21
  %t309 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t292, i32 %t293, ptr %t295, i1 %t296, { i64, ptr } %t298, { i64, ptr } %t300, i1 %t301)
  store %"compiler/ast:ForIn" %t309, ptr %l144
  br label %bb74
bb74:
  %t310 = load %"compiler/ast:ForIn", ptr %l144
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:ForIn" %t310, ptr %t311
  store { i64, [4 x i64] } zeroinitializer, ptr %t312
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t312, i32 0, i32 0
  store i64 9, ptr %t313
  %t314 = load %"compiler/source:Span", ptr %l136
  %t315 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t314, 0
  %t317 = insertvalue { %"compiler/source:Span", ptr } %t315, ptr %t311, 1
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t312, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t317, ptr %t318
  %t319 = load { i64, [4 x i64] }, ptr %t312
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t319, ptr %t321
  %t323 = insertvalue { i32, ptr } zeroinitializer, ptr %t321, 1
  store { i32, ptr } %t323, ptr %rv
  br label %ret
bb75:
  %t324 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t326 = trunc i64 64 to i32
  %t327 = icmp eq i32 %t324, %t326
  br i1 %t327, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb78
bb77:
  %t329 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t331 = trunc i64 1 to i32
  %t332 = icmp eq i32 %t329, %t331
  store i1 %t332, ptr %l150, !tbaa !21
  br label %bb78
bb78:
  %t334 = load i1, ptr %l150, !tbaa !21
  br i1 %t334, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb81
bb80:
  %t335 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t337 = trunc i64 39 to i32
  %t338 = icmp eq i32 %t335, %t337
  store i1 %t338, ptr %l153, !tbaa !21
  br label %bb81
bb81:
  %t340 = load i1, ptr %l153, !tbaa !21
  br i1 %t340, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t341)
  store i32 %t343, ptr %l157
  br label %bb84
bb83:
  br label %bb143
bb84:
  %t344 = load i32, ptr %l157, !tbaa !23
  store i32 %t344, ptr %l15, !tbaa !23
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t345)
  store %"compiler/token:Token" %t347, ptr %l159
  br label %bb85
bb85:
  %t348 = load %"compiler/token:Token", ptr %l159
  store %"compiler/token:Token" %t348, ptr %l16
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t349)
  %t352 = extractvalue { i32, i32 } %t351, 1
  %t353 = extractvalue { i32, i32 } %t351, 0
  store i32 %t353, ptr %l163
  %t354 = icmp ne i32 %t353, 0
  br i1 %t354, label %bb87, label %ok.355, !prof !99
ok.355:
  store i32 %t352, ptr %l162
  br label %bb86
bb86:
  %t356 = load i32, ptr %l162, !tbaa !23
  store i32 %t356, ptr %l160, !tbaa !23
  br label %bb88
bb87:
  %t357 = load i32, ptr %l163, !tbaa !23
  %t358 = lshr i32 %t357, 16
  %t359 = and i32 %t357, 65535
  %t360 = icmp eq i32 %t358, 1
  %t361 = select i1 %t360, i32 1, i32 0
  %t362 = icmp eq i32 %t357, 0
  %t363 = shl i32 %t361, 16
  %t364 = or i32 %t363, %t359
  %t365 = select i1 %t362, i32 0, i32 %t364
  call void @__olang_scope_close(ptr %s11)
  %t367 = insertvalue { i32, ptr } zeroinitializer, i32 %t365, 0
  store { i32, ptr } %t367, ptr %rv
  br label %ret
bb88:
  %t368 = load i32, ptr %l160, !tbaa !23
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l165, !tbaa !29
  store i32 %t368, ptr %l166, !tbaa !23
  %t371 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t372 = load i32, ptr %t371, !tbaa !23
  %t373 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t374 = load i32, ptr %t373, !tbaa !23
  %t377 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t372, i32 %t374)
  store %"compiler/source:Span" %t377, ptr %l169
  br label %bb89
bb89:
  %t378 = load ptr, ptr %l165, !tbaa !29
  %t379 = load i32, ptr %l166, !tbaa !23
  %t380 = load %"compiler/source:Span", ptr %l169
  %t381 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %t378, i32 %t379, %"compiler/source:Span" %t380)
  store ptr %t381, ptr %l170
  br label %bb90
bb90:
  %t382 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t382, ptr %lp18
  %t383 = load ptr, ptr %l170, !tbaa !29
  %t384 = load ptr, ptr %lp18
  store ptr %t383, ptr %t384, !tbaa !29
  %t385 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t385, ptr %lp19
  %t386 = load ptr, ptr %lp19
  store ptr null, ptr %t386, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t387, i32 64)
  store i1 %t390, ptr %l173
  br label %bb91
bb91:
  %t391 = load i1, ptr %l173, !tbaa !21
  br i1 %t391, label %bb92, label %bb93
bb92:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t392)
  %t395 = extractvalue { i32, ptr } %t394, 1
  %t396 = extractvalue { i32, ptr } %t394, 0
  store i32 %t396, ptr %l177
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb95, label %ok.398, !prof !99
ok.398:
  store ptr %t395, ptr %l176
  br label %bb94
bb93:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t399)
  %t402 = extractvalue { i32, ptr } %t401, 1
  %t403 = extractvalue { i32, ptr } %t401, 0
  store i32 %t403, ptr %l193
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb103, label %ok.405, !prof !99
ok.405:
  store ptr %t402, ptr %l192
  br label %bb102
bb94:
  %t406 = load ptr, ptr %l176, !tbaa !29
  store ptr %t406, ptr %l174, !tbaa !29
  br label %bb96
bb95:
  %t407 = load i32, ptr %l177, !tbaa !23
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 1, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  call void @__olang_scope_close(ptr %s11)
  %t417 = insertvalue { i32, ptr } zeroinitializer, i32 %t415, 0
  store { i32, ptr } %t417, ptr %rv
  br label %ret
bb96:
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t418, ptr %lp20
  %t419 = load ptr, ptr %l174, !tbaa !29
  %t420 = load ptr, ptr %lp20
  store ptr %t419, ptr %t420, !tbaa !29
  %t421 = load ptr, ptr %lp18
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = getelementptr %"compiler/parse:NameList", ptr %t422, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  store { i64, ptr } %t425, ptr %l180, !tbaa !27
  %t426 = load ptr, ptr %lp18
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t429 = getelementptr %"compiler/parse:NameList", ptr %t427, i32 0, i32 1
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l182, !tbaa !27
  %t431 = load ptr, ptr %lp20
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t433 = mul i64 1, 8
  %t434 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t433)
  %t435 = insertvalue { i64, ptr } undef, i64 1, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t434, 1
  store { i64, ptr } %t436, ptr %l184, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr ptr, ptr %t439, i64 0
  store ptr %t432, ptr %t440, !tbaa !39
  %t441 = icmp sge i64 0, 0
  br i1 %t441, label %bb97, label %bb98
bb97:
  %t443 = icmp sle i64 0, 1152921504606846975
  br i1 %t443, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_f716ec0be1acdc8e_190b3cb13895b492)
  unreachable
bb99:
  %t445 = mul i64 0, 8
  %t446 = insertvalue { i64, ptr } undef, i64 0, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t448 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t450 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t452 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t448, { i64, ptr } %t449, ptr null, { i64, ptr } %t450, i1 true, i1 false, { i64, ptr } %t447, i1 false)
  store %"compiler/ast:VarDecl" %t452, ptr %l188
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_f716ec0be1acdc8e_190b3cb13895b492)
  unreachable
bb101:
  %t453 = load %"compiler/ast:VarDecl", ptr %l188
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:VarDecl" %t453, ptr %t454
  %t456 = load ptr, ptr %lp19
  store ptr %t454, ptr %t456, !tbaa !29
  br label %bb116
bb102:
  %t457 = load ptr, ptr %l192, !tbaa !29
  store ptr %t457, ptr %l190, !tbaa !29
  br label %bb104
bb103:
  %t458 = load i32, ptr %l193, !tbaa !23
  %t459 = lshr i32 %t458, 16
  %t460 = and i32 %t458, 65535
  %t461 = icmp eq i32 %t459, 1
  %t462 = select i1 %t461, i32 1, i32 0
  %t463 = icmp eq i32 %t458, 0
  %t464 = shl i32 %t462, 16
  %t465 = or i32 %t464, %t460
  %t466 = select i1 %t463, i32 0, i32 %t465
  call void @__olang_scope_close(ptr %s11)
  %t468 = insertvalue { i32, ptr } zeroinitializer, i32 %t466, 0
  store { i32, ptr } %t468, ptr %rv
  br label %ret
bb104:
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t469, ptr %lp21
  %t470 = load ptr, ptr %l190, !tbaa !29
  %t471 = load ptr, ptr %lp21
  store ptr %t470, ptr %t471, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t475 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t472, i32 62)
  %t476 = extractvalue { i32, i32 } %t475, 1
  %t477 = extractvalue { i32, i32 } %t475, 0
  store i32 %t477, ptr %l199
  %t478 = icmp ne i32 %t477, 0
  br i1 %t478, label %bb106, label %ok.479, !prof !99
ok.479:
  store i32 %t476, ptr %l198
  br label %bb105
bb105:
  %t480 = load i32, ptr %l198, !tbaa !23
  store i32 %t480, ptr %l195, !tbaa !23
  br label %bb107
bb106:
  %t481 = load i32, ptr %l199, !tbaa !23
  %t482 = lshr i32 %t481, 16
  %t483 = and i32 %t481, 65535
  %t484 = icmp eq i32 %t482, 1
  %t485 = select i1 %t484, i32 1, i32 0
  %t486 = icmp eq i32 %t481, 0
  %t487 = shl i32 %t485, 16
  %t488 = or i32 %t487, %t483
  %t489 = select i1 %t486, i32 0, i32 %t488
  call void @__olang_scope_close(ptr %s11)
  %t491 = insertvalue { i32, ptr } zeroinitializer, i32 %t489, 0
  store { i32, ptr } %t491, ptr %rv
  br label %ret
bb107:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t492)
  %t495 = extractvalue { i32, ptr } %t494, 1
  %t496 = extractvalue { i32, ptr } %t494, 0
  store i32 %t496, ptr %l204
  %t497 = icmp ne i32 %t496, 0
  br i1 %t497, label %bb109, label %ok.498, !prof !99
ok.498:
  store ptr %t495, ptr %l203
  br label %bb108
bb108:
  %t499 = load ptr, ptr %l203, !tbaa !29
  store ptr %t499, ptr %l201, !tbaa !29
  br label %bb110
bb109:
  %t500 = load i32, ptr %l204, !tbaa !23
  %t501 = lshr i32 %t500, 16
  %t502 = and i32 %t500, 65535
  %t503 = icmp eq i32 %t501, 1
  %t504 = select i1 %t503, i32 1, i32 0
  %t505 = icmp eq i32 %t500, 0
  %t506 = shl i32 %t504, 16
  %t507 = or i32 %t506, %t502
  %t508 = select i1 %t505, i32 0, i32 %t507
  call void @__olang_scope_close(ptr %s11)
  %t510 = insertvalue { i32, ptr } zeroinitializer, i32 %t508, 0
  store { i32, ptr } %t510, ptr %rv
  br label %ret
bb110:
  %t511 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t511, ptr %lp22
  %t512 = load ptr, ptr %l201, !tbaa !29
  %t513 = load ptr, ptr %lp22
  store ptr %t512, ptr %t513, !tbaa !29
  %t514 = load ptr, ptr %lp18
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = getelementptr %"compiler/parse:NameList", ptr %t515, i32 0, i32 0
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l207, !tbaa !27
  %t519 = load ptr, ptr %lp18
  %t520 = load ptr, ptr %t519, !tbaa !29
  %t522 = getelementptr %"compiler/parse:NameList", ptr %t520, i32 0, i32 1
  %t523 = load { i64, ptr }, ptr %t522, !tbaa !27
  store { i64, ptr } %t523, ptr %l209, !tbaa !27
  %t524 = load ptr, ptr %lp21
  %t525 = load ptr, ptr %t524, !tbaa !29
  store ptr %t525, ptr %l211, !tbaa !29
  %t527 = load ptr, ptr %lp22
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = mul i64 1, 8
  %t530 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t529)
  %t531 = insertvalue { i64, ptr } undef, i64 1, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t530, 1
  store { i64, ptr } %t532, ptr %l213, !tbaa !27
  %t534 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = getelementptr ptr, ptr %t535, i64 0
  store ptr %t528, ptr %t536, !tbaa !39
  %t537 = icmp sge i64 0, 0
  br i1 %t537, label %bb111, label %bb112
bb111:
  %t539 = icmp sle i64 0, 1152921504606846975
  br i1 %t539, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_f716ec0be1acdc8e_190b3cb13895b492)
  unreachable
bb113:
  %t541 = mul i64 0, 8
  %t542 = insertvalue { i64, ptr } undef, i64 0, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t544 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t545 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t546 = load ptr, ptr %l211, !tbaa !29
  %t547 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t549 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t544, { i64, ptr } %t545, ptr %t546, { i64, ptr } %t547, i1 false, i1 false, { i64, ptr } %t543, i1 false)
  store %"compiler/ast:VarDecl" %t549, ptr %l217
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_f716ec0be1acdc8e_190b3cb13895b492)
  unreachable
bb115:
  %t550 = load %"compiler/ast:VarDecl", ptr %l217
  %t551 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:VarDecl" %t550, ptr %t551
  %t553 = load ptr, ptr %lp19
  store ptr %t551, ptr %t553, !tbaa !29
  br label %bb116
bb116:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load i32, ptr %l15, !tbaa !23
  %t558 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t554, i32 %t555)
  store %"compiler/source:Span" %t558, ptr %l221
  br label %bb117
bb117:
  %t559 = load ptr, ptr %lp19
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t562 = icmp eq ptr %t560, null
  br i1 %t562, label %bb118, label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_de9eff954e569147_2ba8982dfff1933)
  unreachable
bb119:
  br label %bb120
bb120:
  %t564 = load ptr, ptr %lp19
  %t565 = load ptr, ptr %t564, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t566
  %t567 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 0
  store i64 1, ptr %t567
  %t568 = load %"compiler/source:Span", ptr %l221
  %t569 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t568, 0
  %t571 = insertvalue { %"compiler/source:Span", ptr } %t569, ptr %t565, 1
  %t572 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t571, ptr %t572
  %t573 = load { i64, [4 x i64] }, ptr %t566
  %t574 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t574, ptr %lp23
  %t576 = load ptr, ptr %lp23
  store { i64, [4 x i64] } %t573, ptr %t576
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t580 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t577, i32 59)
  %t581 = extractvalue { i32, i32 } %t580, 1
  %t582 = extractvalue { i32, i32 } %t580, 0
  store i32 %t582, ptr %l230
  %t583 = icmp ne i32 %t582, 0
  br i1 %t583, label %bb122, label %ok.584, !prof !99
ok.584:
  store i32 %t581, ptr %l229
  br label %bb121
bb121:
  %t585 = load i32, ptr %l229, !tbaa !23
  store i32 %t585, ptr %l226, !tbaa !23
  br label %bb123
bb122:
  %t586 = load i32, ptr %l230, !tbaa !23
  %t587 = lshr i32 %t586, 16
  %t588 = and i32 %t586, 65535
  %t589 = icmp eq i32 %t587, 1
  %t590 = select i1 %t589, i32 1, i32 0
  %t591 = icmp eq i32 %t586, 0
  %t592 = shl i32 %t590, 16
  %t593 = or i32 %t592, %t588
  %t594 = select i1 %t591, i32 0, i32 %t593
  call void @__olang_scope_close(ptr %s11)
  %t596 = insertvalue { i32, ptr } zeroinitializer, i32 %t594, 0
  store { i32, ptr } %t596, ptr %rv
  br label %ret
bb123:
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t597)
  %t600 = extractvalue { i32, ptr } %t599, 1
  %t601 = extractvalue { i32, ptr } %t599, 0
  store i32 %t601, ptr %l235
  %t602 = icmp ne i32 %t601, 0
  br i1 %t602, label %bb125, label %ok.603, !prof !99
ok.603:
  store ptr %t600, ptr %l234
  br label %bb124
bb124:
  %t604 = load ptr, ptr %l234, !tbaa !29
  store ptr %t604, ptr %l232, !tbaa !29
  br label %bb126
bb125:
  %t605 = load i32, ptr %l235, !tbaa !23
  %t606 = lshr i32 %t605, 16
  %t607 = and i32 %t605, 65535
  %t608 = icmp eq i32 %t606, 1
  %t609 = select i1 %t608, i32 1, i32 0
  %t610 = icmp eq i32 %t605, 0
  %t611 = shl i32 %t609, 16
  %t612 = or i32 %t611, %t607
  %t613 = select i1 %t610, i32 0, i32 %t612
  call void @__olang_scope_close(ptr %s11)
  %t615 = insertvalue { i32, ptr } zeroinitializer, i32 %t613, 0
  store { i32, ptr } %t615, ptr %rv
  br label %ret
bb126:
  %t616 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t616, ptr %lp24
  %t617 = load ptr, ptr %l232, !tbaa !29
  %t618 = load ptr, ptr %lp24
  store ptr %t617, ptr %t618, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t622 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t619, i32 59)
  %t623 = extractvalue { i32, i32 } %t622, 1
  %t624 = extractvalue { i32, i32 } %t622, 0
  store i32 %t624, ptr %l241
  %t625 = icmp ne i32 %t624, 0
  br i1 %t625, label %bb128, label %ok.626, !prof !99
ok.626:
  store i32 %t623, ptr %l240
  br label %bb127
bb127:
  %t627 = load i32, ptr %l240, !tbaa !23
  store i32 %t627, ptr %l237, !tbaa !23
  br label %bb129
bb128:
  %t628 = load i32, ptr %l241, !tbaa !23
  %t629 = lshr i32 %t628, 16
  %t630 = and i32 %t628, 65535
  %t631 = icmp eq i32 %t629, 1
  %t632 = select i1 %t631, i32 1, i32 0
  %t633 = icmp eq i32 %t628, 0
  %t634 = shl i32 %t632, 16
  %t635 = or i32 %t634, %t630
  %t636 = select i1 %t633, i32 0, i32 %t635
  call void @__olang_scope_close(ptr %s11)
  %t638 = insertvalue { i32, ptr } zeroinitializer, i32 %t636, 0
  store { i32, ptr } %t638, ptr %rv
  br label %ret
bb129:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %v1, ptr %t639)
  %t642 = extractvalue { i32, ptr } %t641, 1
  %t643 = extractvalue { i32, ptr } %t641, 0
  store i32 %t643, ptr %l246
  %t644 = icmp ne i32 %t643, 0
  br i1 %t644, label %bb131, label %ok.645, !prof !99
ok.645:
  store ptr %t642, ptr %l245
  br label %bb130
bb130:
  %t646 = load ptr, ptr %l245, !tbaa !29
  store ptr %t646, ptr %l243, !tbaa !29
  br label %bb132
bb131:
  %t647 = load i32, ptr %l246, !tbaa !23
  %t648 = lshr i32 %t647, 16
  %t649 = and i32 %t647, 65535
  %t650 = icmp eq i32 %t648, 1
  %t651 = select i1 %t650, i32 1, i32 0
  %t652 = icmp eq i32 %t647, 0
  %t653 = shl i32 %t651, 16
  %t654 = or i32 %t653, %t649
  %t655 = select i1 %t652, i32 0, i32 %t654
  call void @__olang_scope_close(ptr %s11)
  %t657 = insertvalue { i32, ptr } zeroinitializer, i32 %t655, 0
  store { i32, ptr } %t657, ptr %rv
  br label %ret
bb132:
  %t658 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t658, ptr %lp25
  %t659 = load ptr, ptr %l243, !tbaa !29
  %t660 = load ptr, ptr %lp25
  store ptr %t659, ptr %t660, !tbaa !29
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t661)
  %t664 = extractvalue { i32, { i64, ptr } } %t663, 1
  %t665 = extractvalue { i32, { i64, ptr } } %t663, 0
  store i32 %t665, ptr %l251
  %t666 = icmp ne i32 %t665, 0
  br i1 %t666, label %bb134, label %ok.667, !prof !99
ok.667:
  store { i64, ptr } %t664, ptr %l250
  br label %bb133
bb133:
  %t668 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t668, ptr %l248, !tbaa !27
  br label %bb135
bb134:
  %t669 = load i32, ptr %l251, !tbaa !23
  %t670 = lshr i32 %t669, 16
  %t671 = and i32 %t669, 65535
  %t672 = icmp eq i32 %t670, 1
  %t673 = select i1 %t672, i32 1, i32 0
  %t674 = icmp eq i32 %t669, 0
  %t675 = shl i32 %t673, 16
  %t676 = or i32 %t675, %t671
  %t677 = select i1 %t674, i32 0, i32 %t676
  call void @__olang_scope_close(ptr %s11)
  %t679 = insertvalue { i32, ptr } zeroinitializer, i32 %t677, 0
  store { i32, ptr } %t679, ptr %rv
  br label %ret
bb135:
  %t680 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t680, ptr %lp26
  %t681 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t682 = load ptr, ptr %lp26
  store { i64, ptr } %t681, ptr %t682, !tbaa !27
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t684 = load i32, ptr %l2, !tbaa !23
  %t687 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t683, i32 %t684)
  store %"compiler/source:Span" %t687, ptr %l255
  br label %bb136
bb136:
  %t688 = load %"compiler/source:Span", ptr %l255
  store %"compiler/source:Span" %t688, ptr %l27
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t692 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t689, i32 8)
  store i1 %t692, ptr %l258
  br label %bb137
bb137:
  %t693 = load i1, ptr %l258, !tbaa !21
  br i1 %t693, label %bb138, label %bb139
bb138:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t694)
  store i32 %t696, ptr %l260
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  %t697 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t697, ptr %l261
  %t698 = load ptr, ptr %lp23
  %t699 = load ptr, ptr %lp24
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = load ptr, ptr %lp25
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t704 = load ptr, ptr %lp26
  %t705 = load { i64, ptr }, ptr %t704, !tbaa !27
  %t710 = call %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t698, ptr %t700, ptr %t703, { i64, ptr } %t705)
  store %"compiler/ast:For3" %t710, ptr %l267
  br label %bb142
bb142:
  %t711 = load %"compiler/ast:For3", ptr %l267
  %t712 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:For3" %t711, ptr %t712
  store { i64, [4 x i64] } zeroinitializer, ptr %t713
  %t714 = getelementptr { i64, [4 x i64] }, ptr %t713, i32 0, i32 0
  store i64 8, ptr %t714
  %t715 = load %"compiler/source:Span", ptr %l261
  %t716 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t715, 0
  %t718 = insertvalue { %"compiler/source:Span", ptr } %t716, ptr %t712, 1
  %t719 = getelementptr { i64, [4 x i64] }, ptr %t713, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t718, ptr %t719
  %t720 = load { i64, [4 x i64] }, ptr %t713
  %t722 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t720, ptr %t722
  call void @__olang_scope_close(ptr %s11)
  %t724 = insertvalue { i32, ptr } zeroinitializer, ptr %t722, 1
  store { i32, ptr } %t724, ptr %rv
  br label %ret
bb143:
  br label %bb144
bb144:
  %t725 = load i1, ptr %l3, !tbaa !21
  br i1 %t725, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s15
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t729 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s15, ptr %t727, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i32 %t729, ptr %l273
  %t730 = icmp ne i32 %t729, 0
  br i1 %t730, label %bb148, label %ok.731, !prof !99
ok.731:
  br label %bb147
bb146:
  br label %bb150
bb147:
  br label %bb149
bb148:
  %t732 = load i32, ptr %l273, !tbaa !23
  %t733 = lshr i32 %t732, 16
  %t734 = and i32 %t732, 65535
  %t735 = icmp eq i32 %t733, 1
  %t736 = select i1 %t735, i32 1, i32 0
  %t737 = icmp eq i32 %t732, 0
  %t738 = shl i32 %t736, 16
  %t739 = or i32 %t738, %t734
  %t740 = select i1 %t737, i32 0, i32 %t739
  call void @__olang_scope_close(ptr %s15)
  %t742 = insertvalue { i32, ptr } zeroinitializer, i32 %t740, 0
  store { i32, ptr } %t742, ptr %rv
  br label %ret
bb149:
  call void @__olang_scope_close(ptr %s15)
  br label %bb150
bb150:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t743)
  %t746 = extractvalue { i32, ptr } %t745, 1
  %t747 = extractvalue { i32, ptr } %t745, 0
  store i32 %t747, ptr %l278
  %t748 = icmp ne i32 %t747, 0
  br i1 %t748, label %bb152, label %ok.749, !prof !99
ok.749:
  store ptr %t746, ptr %l277
  br label %bb151
bb151:
  %t750 = load ptr, ptr %l277, !tbaa !29
  store ptr %t750, ptr %l275, !tbaa !29
  br label %bb153
bb152:
  %t751 = load i32, ptr %l278, !tbaa !23
  %t752 = lshr i32 %t751, 16
  %t753 = and i32 %t751, 65535
  %t754 = icmp eq i32 %t752, 1
  %t755 = select i1 %t754, i32 1, i32 0
  %t756 = icmp eq i32 %t751, 0
  %t757 = shl i32 %t755, 16
  %t758 = or i32 %t757, %t753
  %t759 = select i1 %t756, i32 0, i32 %t758
  %t761 = insertvalue { i32, ptr } zeroinitializer, i32 %t759, 0
  store { i32, ptr } %t761, ptr %rv
  br label %ret
bb153:
  %t762 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t762, ptr %lp28
  %t763 = load ptr, ptr %l275, !tbaa !29
  %t764 = load ptr, ptr %lp28
  store ptr %t763, ptr %t764, !tbaa !29
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t765)
  %t768 = extractvalue { i32, { i64, ptr } } %t767, 1
  %t769 = extractvalue { i32, { i64, ptr } } %t767, 0
  store i32 %t769, ptr %l283
  %t770 = icmp ne i32 %t769, 0
  br i1 %t770, label %bb155, label %ok.771, !prof !99
ok.771:
  store { i64, ptr } %t768, ptr %l282
  br label %bb154
bb154:
  %t772 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t772, ptr %l280, !tbaa !27
  br label %bb156
bb155:
  %t773 = load i32, ptr %l283, !tbaa !23
  %t774 = lshr i32 %t773, 16
  %t775 = and i32 %t773, 65535
  %t776 = icmp eq i32 %t774, 1
  %t777 = select i1 %t776, i32 1, i32 0
  %t778 = icmp eq i32 %t773, 0
  %t779 = shl i32 %t777, 16
  %t780 = or i32 %t779, %t775
  %t781 = select i1 %t778, i32 0, i32 %t780
  %t783 = insertvalue { i32, ptr } zeroinitializer, i32 %t781, 0
  store { i32, ptr } %t783, ptr %rv
  br label %ret
bb156:
  %t784 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t784, ptr %lp29
  %t785 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t786 = load ptr, ptr %lp29
  store { i64, ptr } %t785, ptr %t786, !tbaa !27
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load i32, ptr %l2, !tbaa !23
  %t791 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t787, i32 %t788)
  store %"compiler/source:Span" %t791, ptr %l287
  br label %bb157
bb157:
  %t792 = load %"compiler/source:Span", ptr %l287
  store %"compiler/source:Span" %t792, ptr %l30
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t796 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t793, i32 8)
  store i1 %t796, ptr %l290
  br label %bb158
bb158:
  %t797 = load i1, ptr %l290, !tbaa !21
  br i1 %t797, label %bb159, label %bb160
bb159:
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t798)
  store i32 %t800, ptr %l292
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  %t801 = load %"compiler/source:Span", ptr %l30
  %t802 = load ptr, ptr %lp28
  %t803 = load ptr, ptr %t802, !tbaa !29
  %t804 = load ptr, ptr %lp29
  %t805 = load { i64, ptr }, ptr %t804, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t806
  %t807 = getelementptr { i64, [4 x i64] }, ptr %t806, i32 0, i32 0
  store i64 7, ptr %t807
  %t809 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t801, 0
  %t811 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t809, ptr %t803, 1
  %t813 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t811, { i64, ptr } %t805, 2
  %t814 = getelementptr { i64, [4 x i64] }, ptr %t806, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t813, ptr %t814
  %t815 = load { i64, [4 x i64] }, ptr %t806
  %t817 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t815, ptr %t817
  %t819 = insertvalue { i32, ptr } zeroinitializer, ptr %t817, 1
  store { i32, ptr } %t819, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l67 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i1
  %l105 = alloca i1
  %l109 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l123 = alloca i32
  %l126 = alloca i1
  %l130 = alloca i32
  %l133 = alloca i1
  %l137 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l146 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i1
  %l154 = alloca i1
  %l157 = alloca i1
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i64
  %l164 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/msgs:Msg"
  %l174 = alloca ptr
  %l175 = alloca i64
  %l176 = alloca %"compiler/msgs:Msg"
  %l180 = alloca i1
  %l183 = alloca i1
  %l187 = alloca i1
  %l190 = alloca i1
  %l191 = alloca i1
  %l192 = alloca ptr
  %l195 = alloca i64
  %l197 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l219 = alloca i1
  %l223 = alloca i1
  %l226 = alloca i1
  %l230 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i1
  %l240 = alloca i1
  %l244 = alloca i1
  %l247 = alloca i1
  %l250 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i64
  %l258 = alloca { i64, ptr }
  %l260 = alloca %"compiler/msgs:Msg"
  %l264 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i64
  %l269 = alloca %"compiler/msgs:Msg"
  %l273 = alloca i1
  %l274 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l278 = alloca i1
  %l279 = alloca i1
  %l282 = alloca i1
  %l285 = alloca i1
  %l288 = alloca i1
  %l294 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 98}
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 6
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l17
  br label %bb4
bb4:
  %t22 = load i32, ptr %l17, !range !{i32 0, i32 98}
  store i32 %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l20
  br label %bb5
bb5:
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l25
  br label %bb6
bb6:
  %t38 = load i32, ptr %l25, !range !{i32 0, i32 98}
  store i32 %t38, ptr %l6
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l28
  br label %bb7
bb7:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t47 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t45)
  store i1 %t47, ptr %l30
  br label %bb8
bb8:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t51, ptr %l33
  br label %bb11
bb10:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t56 = trunc i64 63 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l42
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %s2, ptr %s2, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t77, ptr %l44
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l38, !tbaa !29
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load %"compiler/msgs:Msg", ptr %l44
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t78, i64 %t79, %"compiler/msgs:Msg" %t80)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l48
  br label %bb22
bb22:
  %t87 = load i1, ptr %l48, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l49, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l50, !tbaa !24
  %t90 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %s3)
  store %"compiler/msgs:Msg" %t90, ptr %l51
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i64, ptr %l50, !tbaa !24
  %t93 = load %"compiler/msgs:Msg", ptr %l51
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s3, ptr %t91, i64 %t92, %"compiler/msgs:Msg" %t93)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l55
  br label %bb28
bb28:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t114 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t108, i64 %t111)
  store i64 %t114, ptr %l64
  br label %bb34
bb33:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb35
bb34:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l64, !tbaa !24
  %t118 = icmp slt i64 %t116, %t115
  store i1 %t118, ptr %l60, !tbaa !21
  br label %bb35
bb35:
  %t120 = load i1, ptr %l60, !tbaa !21
  br i1 %t120, label %bb36, label %bb37
bb36:
  %t121 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t123 = trunc i64 39 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb62
bb38:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb40
bb39:
  %t126 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t128 = trunc i64 64 to i32
  %t129 = icmp eq i32 %t126, %t128
  store i1 %t129, ptr %l70, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l70, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb43
bb42:
  %t132 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t134 = trunc i64 62 to i32
  %t135 = icmp eq i32 %t132, %t134
  store i1 %t135, ptr %l73, !tbaa !21
  br label %bb43
bb43:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb46
bb45:
  %t138 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t140 = trunc i64 59 to i32
  %t141 = icmp eq i32 %t138, %t140
  store i1 %t141, ptr %l76, !tbaa !21
  br label %bb46
bb46:
  %t143 = load i1, ptr %l76, !tbaa !21
  br i1 %t143, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb61
bb48:
  %t144 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t146 = trunc i64 1 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t151 = trunc i64 19 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb60
bb51:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb53
bb52:
  %t154 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t156 = trunc i64 20 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l85, !tbaa !21
  br label %bb53
bb53:
  %t159 = load i1, ptr %l85, !tbaa !21
  br i1 %t159, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb56
bb55:
  %t160 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t162 = trunc i64 21 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l88, !tbaa !21
  br label %bb56
bb56:
  %t165 = load i1, ptr %l88, !tbaa !21
  br i1 %t165, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb59
bb58:
  %t166 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t168 = trunc i64 14 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t171 = load i1, ptr %l91, !tbaa !21
  store i1 %t171, ptr %l82, !tbaa !21
  br label %bb60
bb60:
  %t172 = load i1, ptr %l82, !tbaa !21
  store i1 %t172, ptr %l79, !tbaa !21
  br label %bb61
bb61:
  %t173 = load i1, ptr %l79, !tbaa !21
  store i1 %t173, ptr %l67, !tbaa !21
  br label %bb62
bb62:
  %t174 = load i1, ptr %l67, !tbaa !21
  br i1 %t174, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s4
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l94, !tbaa !29
  %t176 = load i64, ptr %l5, !tbaa !24
  store i64 %t176, ptr %l95, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l5, !tbaa !24
  %t181 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s4, ptr %t177, i64 %t178)
  store { i64, ptr } %t181, ptr %l98
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t182 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s4, ptr %s4, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l100
  br label %bb66
bb66:
  %t191 = load ptr, ptr %l94, !tbaa !29
  %t192 = load i64, ptr %l95, !tbaa !24
  %t193 = load %"compiler/msgs:Msg", ptr %l100
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t191, i64 %t192, %"compiler/msgs:Msg" %t193)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb68:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t195, i64 %t196)
  store i1 %t199, ptr %l104
  br label %bb69
bb69:
  %t200 = load i1, ptr %l104, !tbaa !21
  br i1 %t200, label %bb70, label %bb71
bb70:
  %t201 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t203 = trunc i64 39 to i32
  %t204 = icmp eq i32 %t201, %t203
  %t206 = xor i1 %t204, true
  store i1 %t206, ptr %l105, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb72
bb72:
  %t208 = load i1, ptr %l105, !tbaa !21
  br i1 %t208, label %bb73, label %bb74
bb73:
  %t209 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t209, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t211, ptr %l111
  br label %bb75
bb74:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb92
bb75:
  %t212 = load i1, ptr %l111, !tbaa !21
  br i1 %t212, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb91
bb77:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i64, ptr %l2, !tbaa !24
  %t216 = add i64 %t214, 1
  %t219 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t213, i64 %t216)
  store i64 %t219, ptr %l116
  br label %bb78
bb78:
  %t220 = load i64, ptr %l4, !tbaa !24
  %t221 = load i64, ptr %l116, !tbaa !24
  %t223 = icmp eq i64 %t221, %t220
  br i1 %t223, label %bb79, label %bb80
bb79:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i64, ptr %l2, !tbaa !24
  %t228 = add i64 %t226, 1
  %t231 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t225, i64 %t228)
  store i32 %t231, ptr %l123
  br label %bb81
bb80:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb90
bb81:
  %t232 = load i32, ptr %l123, !range !{i32 0, i32 98}
  %t234 = trunc i64 1 to i32
  %t235 = icmp eq i32 %t232, %t234
  br i1 %t235, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb85
bb83:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l2, !tbaa !24
  %t240 = add i64 %t238, 1
  %t243 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t237, i64 %t240)
  store i32 %t243, ptr %l130
  br label %bb84
bb84:
  %t244 = load i32, ptr %l130, !range !{i32 0, i32 98}
  %t246 = trunc i64 39 to i32
  %t247 = icmp eq i32 %t244, %t246
  store i1 %t247, ptr %l126, !tbaa !21
  br label %bb85
bb85:
  %t249 = load i1, ptr %l126, !tbaa !21
  br i1 %t249, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb89
bb87:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l2, !tbaa !24
  %t253 = add i64 %t251, 1
  %t256 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t250, i64 %t253)
  store i32 %t256, ptr %l137
  br label %bb88
bb88:
  %t257 = load i32, ptr %l137, !range !{i32 0, i32 98}
  %t259 = trunc i64 64 to i32
  %t260 = icmp eq i32 %t257, %t259
  store i1 %t260, ptr %l133, !tbaa !21
  br label %bb89
bb89:
  %t262 = load i1, ptr %l133, !tbaa !21
  store i1 %t262, ptr %l119, !tbaa !21
  br label %bb90
bb90:
  %t263 = load i1, ptr %l119, !tbaa !21
  store i1 %t263, ptr %l112, !tbaa !21
  br label %bb91
bb91:
  %t264 = load i1, ptr %l112, !tbaa !21
  store i1 %t264, ptr %l109, !tbaa !21
  br label %bb92
bb92:
  %t265 = load i1, ptr %l109, !tbaa !21
  br i1 %t265, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s5
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l140, !tbaa !29
  %t267 = load i64, ptr %l2, !tbaa !24
  store i64 %t267, ptr %l141, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i64, ptr %l2, !tbaa !24
  %t272 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s5, ptr %t268, i64 %t269)
  store { i64, ptr } %t272, ptr %l144
  br label %bb95
bb94:
  br label %bb98
bb95:
  %t273 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  %t281 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s5, ptr %s5, { i64, ptr } %t279)
  store %"compiler/msgs:Msg" %t281, ptr %l146
  br label %bb96
bb96:
  %t282 = load ptr, ptr %l140, !tbaa !29
  %t283 = load i64, ptr %l141, !tbaa !24
  %t284 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t282, i64 %t283, %"compiler/msgs:Msg" %t284)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb98:
  %t286 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t288 = trunc i64 8 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb101
bb100:
  %t291 = load i64, ptr %l7, !tbaa !24
  %t292 = load i64, ptr %l4, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  store i1 %t295, ptr %l150, !tbaa !21
  br label %bb101
bb101:
  %t297 = load i1, ptr %l150, !tbaa !21
  br i1 %t297, label %bb102, label %bb103
bb102:
  %t298 = load i64, ptr %l4, !tbaa !24
  %t300 = icmp sgt i64 %t298, 0
  store i1 %t300, ptr %l154, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb104
bb104:
  %t302 = load i1, ptr %l154, !tbaa !21
  br i1 %t302, label %bb105, label %bb106
bb105:
  %t303 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t305 = call i1 @compiler_2fparse_2eisJoiningOp(i32 %t303)
  store i1 %t305, ptr %l159
  br label %bb107
bb106:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb108
bb107:
  %t306 = load i1, ptr %l159, !tbaa !21
  store i1 %t306, ptr %l157, !tbaa !21
  br label %bb108
bb108:
  %t307 = load i1, ptr %l157, !tbaa !21
  br i1 %t307, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s6
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l160, !tbaa !29
  %t309 = load i64, ptr %l2, !tbaa !24
  store i64 %t309, ptr %l161, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i64, ptr %l2, !tbaa !24
  %t314 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s6, ptr %t310, i64 %t311)
  store { i64, ptr } %t314, ptr %l164
  br label %bb111
bb110:
  br label %bb115
bb111:
  %t315 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l165, !tbaa !27
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i64, ptr %l2, !tbaa !24
  %t326 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s6, ptr %t322, i64 %t323)
  store { i64, ptr } %t326, ptr %l168
  br label %bb112
bb112:
  %t327 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 0
  %t329 = extractvalue { i64, ptr } %t327, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t336 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %s6, ptr %s6, ptr %s6, { i64, ptr } %t334, { i64, ptr } %t333)
  store %"compiler/msgs:Msg" %t336, ptr %l170
  br label %bb113
bb113:
  %t337 = load ptr, ptr %l160, !tbaa !29
  %t338 = load i64, ptr %l161, !tbaa !24
  %t339 = load %"compiler/msgs:Msg", ptr %l170
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s6, ptr %t337, i64 %t338, %"compiler/msgs:Msg" %t339)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb115:
  %t341 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t343 = trunc i64 42 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s7
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l174, !tbaa !29
  %t347 = load i64, ptr %l2, !tbaa !24
  store i64 %t347, ptr %l175, !tbaa !24
  %t348 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %s7)
  store %"compiler/msgs:Msg" %t348, ptr %l176
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t349 = load ptr, ptr %l174, !tbaa !29
  %t350 = load i64, ptr %l175, !tbaa !24
  %t351 = load %"compiler/msgs:Msg", ptr %l176
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s7, ptr %t349, i64 %t350, %"compiler/msgs:Msg" %t351)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb120:
  %t353 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t355 = trunc i64 5 to i32
  %t356 = icmp eq i32 %t353, %t355
  br i1 %t356, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb123
bb122:
  %t358 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t360 = trunc i64 89 to i32
  %t361 = icmp eq i32 %t358, %t360
  store i1 %t361, ptr %l180, !tbaa !21
  br label %bb123
bb123:
  %t363 = load i1, ptr %l180, !tbaa !21
  br i1 %t363, label %bb124, label %bb125
bb124:
  %t364 = load i64, ptr %l7, !tbaa !24
  %t365 = load i64, ptr %l4, !tbaa !24
  %t368 = icmp eq i64 %t364, %t365
  store i1 %t368, ptr %l183, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb126
bb126:
  %t370 = load i1, ptr %l183, !tbaa !21
  br i1 %t370, label %bb127, label %bb128
bb127:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i64, ptr %l5, !tbaa !24
  %t375 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t371, i64 %t372)
  store i1 %t375, ptr %l190
  br label %bb129
bb128:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb130
bb129:
  %t376 = load i1, ptr %l190, !tbaa !21
  store i1 %t376, ptr %l187, !tbaa !21
  br label %bb130
bb130:
  %t377 = load i1, ptr %l187, !tbaa !21
  br i1 %t377, label %bb131, label %bb132
bb131:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l192, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i64, ptr %l5, !tbaa !24
  %t383 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %t379, i64 %t380)
  store i64 %t383, ptr %l195
  br label %bb133
bb132:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb135
bb133:
  %t384 = load i64, ptr %l5, !tbaa !24
  %t385 = load ptr, ptr %l192, !tbaa !29
  %t386 = load i64, ptr %l195, !tbaa !24
  %t388 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t385, i64 %t386, i64 %t384)
  store i1 %t388, ptr %l197
  br label %bb134
bb134:
  %t389 = load i1, ptr %l197, !tbaa !21
  store i1 %t389, ptr %l191, !tbaa !21
  br label %bb135
bb135:
  %t390 = load i1, ptr %l191, !tbaa !21
  br i1 %t390, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  %t392 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t394 = trunc i64 5 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb139, label %bb140
bb139:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb142
bb140:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i64, ptr %l5, !tbaa !24
  %t401 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %t397, i64 %t398)
  store i1 %t401, ptr %l204
  br label %bb141
bb141:
  %t402 = load i1, ptr %l204, !tbaa !21
  store i1 %t402, ptr %l201, !tbaa !21
  br label %bb142
bb142:
  %t403 = load i1, ptr %l201, !tbaa !21
  br i1 %t403, label %bb143, label %bb144
bb143:
  %t404 = load i64, ptr %l7, !tbaa !24
  %t405 = load i64, ptr %l4, !tbaa !24
  %t408 = icmp eq i64 %t404, %t405
  store i1 %t408, ptr %l205, !tbaa !21
  br label %bb145
bb144:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb145
bb145:
  %t410 = load i1, ptr %l205, !tbaa !21
  br i1 %t410, label %bb146, label %bb147
bb146:
  %t411 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t413 = call i1 @compiler_2fparse_2eisOperandEndTok(i32 %t411)
  store i1 %t413, ptr %l211
  br label %bb148
bb147:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb152
bb148:
  %t414 = load i1, ptr %l211, !tbaa !21
  br i1 %t414, label %bb149, label %bb150
bb149:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb151
bb150:
  %t415 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t417 = trunc i64 92 to i32
  %t418 = icmp eq i32 %t415, %t417
  store i1 %t418, ptr %l212, !tbaa !21
  br label %bb151
bb151:
  %t420 = load i1, ptr %l212, !tbaa !21
  store i1 %t420, ptr %l209, !tbaa !21
  br label %bb152
bb152:
  %t421 = load i1, ptr %l209, !tbaa !21
  br i1 %t421, label %bb153, label %bb154
bb153:
  %t422 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t424 = trunc i64 93 to i32
  %t425 = icmp eq i32 %t422, %t424
  %t427 = xor i1 %t425, true
  store i1 %t427, ptr %l215, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb155
bb155:
  %t429 = load i1, ptr %l215, !tbaa !21
  br i1 %t429, label %bb156, label %bb157
bb156:
  %t430 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t432 = trunc i64 95 to i32
  %t433 = icmp eq i32 %t430, %t432
  %t435 = xor i1 %t433, true
  store i1 %t435, ptr %l219, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb158
bb158:
  %t437 = load i1, ptr %l219, !tbaa !21
  br i1 %t437, label %bb159, label %bb160
bb159:
  %t438 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t440 = trunc i64 5 to i32
  %t441 = icmp eq i32 %t438, %t440
  br i1 %t441, label %bb161, label %bb162
bb160:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb164
bb161:
  %t443 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t445 = trunc i64 92 to i32
  %t446 = icmp eq i32 %t443, %t445
  store i1 %t446, ptr %l226, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb163
bb163:
  %t448 = load i1, ptr %l226, !tbaa !21
  %t449 = xor i1 %t448, true
  store i1 %t449, ptr %l223, !tbaa !21
  br label %bb164
bb164:
  %t451 = load i1, ptr %l223, !tbaa !21
  br i1 %t451, label %bb165, label %bb166
bb165:
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l231, !tbaa !29
  %t453 = load i64, ptr %l2, !tbaa !24
  store i64 %t453, ptr %l232, !tbaa !24
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load i64, ptr %l2, !tbaa !24
  %t458 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %t454, i64 %t455)
  store i64 %t458, ptr %l235
  br label %bb167
bb166:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb169
bb167:
  %t459 = load ptr, ptr %l231, !tbaa !29
  %t460 = load i64, ptr %l232, !tbaa !24
  %t461 = load i64, ptr %l235, !tbaa !24
  %t462 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t459, i64 %t460, i64 %t461)
  store i1 %t462, ptr %l236
  br label %bb168
bb168:
  %t463 = load i1, ptr %l236, !tbaa !21
  store i1 %t463, ptr %l230, !tbaa !21
  br label %bb169
bb169:
  %t464 = load i1, ptr %l230, !tbaa !21
  br i1 %t464, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb171:
  br label %bb172
bb172:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i64, ptr %l2, !tbaa !24
  %t470 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %t466, i64 %t467)
  store i1 %t470, ptr %l240
  br label %bb173
bb173:
  %t471 = load i1, ptr %l240, !tbaa !21
  br i1 %t471, label %bb174, label %bb175
bb174:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb175:
  br label %bb176
bb176:
  %t473 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t475 = trunc i64 93 to i32
  %t476 = icmp eq i32 %t473, %t475
  br i1 %t476, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l244, !tbaa !21
  br label %bb179
bb178:
  %t478 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t480 = trunc i64 95 to i32
  %t481 = icmp eq i32 %t478, %t480
  store i1 %t481, ptr %l244, !tbaa !21
  br label %bb179
bb179:
  %t483 = load i1, ptr %l244, !tbaa !21
  br i1 %t483, label %bb180, label %bb181
bb180:
  %t484 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t486 = trunc i64 59 to i32
  %t487 = icmp eq i32 %t484, %t486
  store i1 %t487, ptr %l247, !tbaa !21
  br label %bb182
bb181:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb182
bb182:
  %t489 = load i1, ptr %l247, !tbaa !21
  br i1 %t489, label %bb183, label %bb184
bb183:
  %t490 = load i64, ptr %l7, !tbaa !24
  %t491 = load i64, ptr %l4, !tbaa !24
  %t494 = icmp eq i64 %t490, %t491
  store i1 %t494, ptr %l250, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb185
bb185:
  %t496 = load i1, ptr %l250, !tbaa !21
  br i1 %t496, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s11
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l254, !tbaa !29
  %t498 = load i64, ptr %l5, !tbaa !24
  store i64 %t498, ptr %l255, !tbaa !24
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load i64, ptr %l2, !tbaa !24
  %t503 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s11, ptr %t499, i64 %t500)
  store { i64, ptr } %t503, ptr %l258
  br label %bb188
bb187:
  br label %bb191
bb188:
  %t504 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t505 = extractvalue { i64, ptr } %t504, 0
  %t506 = extractvalue { i64, ptr } %t504, 1
  %t507 = mul i64 %t505, 1
  %t508 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t507)
  call void @llvm.memcpy.p0.p0.i64(ptr %t508, ptr %t506, i64 %t507, i1 false)
  %t509 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  %t512 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s11, ptr %s11, { i64, ptr } %t510)
  store %"compiler/msgs:Msg" %t512, ptr %l260
  br label %bb189
bb189:
  %t513 = load ptr, ptr %l254, !tbaa !29
  %t514 = load i64, ptr %l255, !tbaa !24
  %t515 = load %"compiler/msgs:Msg", ptr %l260
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s11, ptr %t513, i64 %t514, %"compiler/msgs:Msg" %t515)
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb191:
  %t517 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t519 = trunc i64 38 to i32
  %t520 = icmp eq i32 %t517, %t519
  br i1 %t520, label %bb192, label %bb193
bb192:
  %t522 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t524 = trunc i64 61 to i32
  %t525 = icmp eq i32 %t522, %t524
  store i1 %t525, ptr %l264, !tbaa !21
  br label %bb194
bb193:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb194
bb194:
  %t527 = load i1, ptr %l264, !tbaa !21
  br i1 %t527, label %bb195, label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s12
  %t528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t528, ptr %l267, !tbaa !29
  %t529 = load i64, ptr %l2, !tbaa !24
  store i64 %t529, ptr %l268, !tbaa !24
  %t530 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %s12)
  store %"compiler/msgs:Msg" %t530, ptr %l269
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t531 = load ptr, ptr %l267, !tbaa !29
  %t532 = load i64, ptr %l268, !tbaa !24
  %t533 = load %"compiler/msgs:Msg", ptr %l269
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s12, ptr %t531, i64 %t532, %"compiler/msgs:Msg" %t533)
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb199:
  %t535 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t537 = trunc i64 92 to i32
  %t538 = icmp eq i32 %t535, %t537
  br i1 %t538, label %bb200, label %bb201
bb200:
  %t540 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t540, ptr %l274, !tbaa !27
  %t542 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t542, ptr %l276
  br label %bb202
bb201:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb204
bb202:
  %t543 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t543, 0
  %t545 = extractvalue { i64, ptr } %t543, 1
  %t546 = mul i64 %t544, 1
  %t547 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t546)
  call void @llvm.memcpy.p0.p0.i64(ptr %t547, ptr %t545, i64 %t546, i1 false)
  %t548 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t547, 1
  %t550 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t552 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t550, { i64, ptr } %t549)
  store i1 %t552, ptr %l278
  br label %bb203
bb203:
  %t553 = load i1, ptr %l278, !tbaa !21
  store i1 %t553, ptr %l273, !tbaa !21
  br label %bb204
bb204:
  %t554 = load i1, ptr %l273, !tbaa !21
  br i1 %t554, label %bb205, label %bb206
bb205:
  %t555 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t557 = trunc i64 83 to i32
  %t558 = icmp eq i32 %t555, %t557
  br i1 %t558, label %bb207, label %bb208
bb206:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb213
bb207:
  store i1 true, ptr %l282, !tbaa !21
  br label %bb209
bb208:
  %t560 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t562 = trunc i64 91 to i32
  %t563 = icmp eq i32 %t560, %t562
  store i1 %t563, ptr %l282, !tbaa !21
  br label %bb209
bb209:
  %t565 = load i1, ptr %l282, !tbaa !21
  br i1 %t565, label %bb210, label %bb211
bb210:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb212
bb211:
  %t566 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t568 = trunc i64 1 to i32
  %t569 = icmp eq i32 %t566, %t568
  store i1 %t569, ptr %l285, !tbaa !21
  br label %bb212
bb212:
  %t571 = load i1, ptr %l285, !tbaa !21
  store i1 %t571, ptr %l279, !tbaa !21
  br label %bb213
bb213:
  %t572 = load i1, ptr %l279, !tbaa !21
  br i1 %t572, label %bb214, label %bb215
bb214:
  %t573 = load i64, ptr %l7, !tbaa !24
  %t574 = load i64, ptr %l4, !tbaa !24
  %t577 = icmp eq i64 %t573, %t574
  store i1 %t577, ptr %l288, !tbaa !21
  br label %bb216
bb215:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb216
bb216:
  %t579 = load i1, ptr %l288, !tbaa !21
  br i1 %t579, label %bb217, label %bb218
bb217:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load i64, ptr %l2, !tbaa !24
  %t584 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %t580, i64 %t581)
  store i1 %t584, ptr %l294
  br label %bb219
bb218:
  br label %bb220
bb219:
  call void @__olang_scope_close(ptr %s0)
  %t585 = load i1, ptr %l294, !tbaa !21
  store i1 %t585, ptr %rv
  br label %ret
bb220:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:If"
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/ast:If"
  %rv = alloca { i32, ptr }
  %t134 = alloca { i64, [4 x i64] }, align 8
  %t175 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l7, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28, !prof !99
ok.28:
  store ptr %t25, ptr %l15
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l15, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  br label %bb6
bb5:
  %t30 = load i32, ptr %l16, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t41, ptr %lp2
  %t42 = load ptr, ptr %l13, !tbaa !29
  %t43 = load ptr, ptr %lp2
  store ptr %t42, ptr %t43, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %t44)
  %t47 = extractvalue { i32, ptr } %t46, 1
  %t48 = extractvalue { i32, ptr } %t46, 0
  store i32 %t48, ptr %l21
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb8, label %ok.50, !prof !99
ok.50:
  store ptr %t47, ptr %l20
  br label %bb7
bb7:
  %t51 = load ptr, ptr %l20, !tbaa !29
  store ptr %t51, ptr %l18, !tbaa !29
  br label %bb9
bb8:
  %t52 = load i32, ptr %l21, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  %t62 = insertvalue { i32, ptr } zeroinitializer, i32 %t60, 0
  store { i32, ptr } %t62, ptr %rv
  br label %ret
bb9:
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t63, ptr %lp3
  %t64 = load ptr, ptr %l18, !tbaa !29
  %t65 = load ptr, ptr %lp3
  store ptr %t64, ptr %t65, !tbaa !29
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t66, ptr %lp4
  %t67 = load ptr, ptr %lp4
  store ptr null, ptr %t67, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t68, i32 10)
  store i1 %t71, ptr %l25
  br label %bb10
bb10:
  %t72 = load i1, ptr %l25, !tbaa !21
  br i1 %t72, label %bb11, label %bb12
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t73, i32 9)
  store i1 %t76, ptr %l28
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t77 = load i1, ptr %l28, !tbaa !21
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %t78)
  %t81 = extractvalue { i32, ptr } %t80, 1
  %t82 = extractvalue { i32, ptr } %t80, 0
  store i32 %t82, ptr %l32
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb17, label %ok.84, !prof !99
ok.84:
  store ptr %t81, ptr %l31
  br label %bb16
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %t85)
  %t88 = extractvalue { i32, ptr } %t87, 1
  %t89 = extractvalue { i32, ptr } %t87, 0
  store i32 %t89, ptr %l38
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb20, label %ok.91, !prof !99
ok.91:
  store ptr %t88, ptr %l37
  br label %bb19
bb16:
  %t92 = load ptr, ptr %l31, !tbaa !29
  store ptr %t92, ptr %l29, !tbaa !29
  br label %bb18
bb17:
  %t93 = load i32, ptr %l32, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  %t103 = insertvalue { i32, ptr } zeroinitializer, i32 %t101, 0
  store { i32, ptr } %t103, ptr %rv
  br label %ret
bb18:
  %t104 = load ptr, ptr %l29, !tbaa !29
  %t106 = load ptr, ptr %lp4
  store ptr %t104, ptr %t106, !tbaa !29
  br label %bb23
bb19:
  %t107 = load ptr, ptr %l37, !tbaa !29
  store ptr %t107, ptr %l35, !tbaa !29
  br label %bb21
bb20:
  %t108 = load i32, ptr %l38, !tbaa !23
  %t109 = lshr i32 %t108, 16
  %t110 = and i32 %t108, 65535
  %t111 = icmp eq i32 %t109, 1
  %t112 = select i1 %t111, i32 1, i32 0
  %t113 = icmp eq i32 %t108, 0
  %t114 = shl i32 %t112, 16
  %t115 = or i32 %t114, %t110
  %t116 = select i1 %t113, i32 0, i32 %t115
  %t118 = insertvalue { i32, ptr } zeroinitializer, i32 %t116, 0
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t119, ptr %lp5
  %t120 = load ptr, ptr %l35, !tbaa !29
  %t121 = load ptr, ptr %lp5
  store ptr %t120, ptr %t121, !tbaa !29
  %t122 = load ptr, ptr %lp5
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Branch", ptr %t123, i32 0, i32 0
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l41
  %t127 = load ptr, ptr %lp5
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t131 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t128, ptr null)
  store %"compiler/ast:If" %t131, ptr %l44
  br label %bb22
bb22:
  %t132 = load %"compiler/ast:If", ptr %l44
  %t133 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t132, ptr %t133
  store { i64, [4 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 0
  store i64 5, ptr %t135
  %t136 = load %"compiler/source:Span", ptr %l41
  %t137 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t136, 0
  %t139 = insertvalue { %"compiler/source:Span", ptr } %t137, ptr %t133, 1
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t139, ptr %t140
  %t141 = load { i64, [4 x i64] }, ptr %t134
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t141, ptr %t143
  %t145 = load ptr, ptr %lp4
  store ptr %t143, ptr %t145, !tbaa !29
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t146, i32 %t147)
  store %"compiler/source:Span" %t150, ptr %l50
  br label %bb25
bb25:
  %t151 = load %"compiler/source:Span", ptr %l50
  store %"compiler/source:Span" %t151, ptr %l6
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t155 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t152, i32 8)
  store i1 %t155, ptr %l53
  br label %bb26
bb26:
  %t156 = load i1, ptr %l53, !tbaa !21
  br i1 %t156, label %bb27, label %bb28
bb27:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t157)
  store i32 %t159, ptr %l55
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t160 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t160, ptr %l56
  %t161 = load ptr, ptr %lp2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = load ptr, ptr %lp3
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = load ptr, ptr %lp4
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t172 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t162, ptr %t165, ptr %t168)
  store %"compiler/ast:If" %t172, ptr %l62
  br label %bb31
bb31:
  %t173 = load %"compiler/ast:If", ptr %l62
  %t174 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t173, ptr %t174
  store { i64, [4 x i64] } zeroinitializer, ptr %t175
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t175, i32 0, i32 0
  store i64 5, ptr %t176
  %t177 = load %"compiler/source:Span", ptr %l56
  %t178 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t177, 0
  %t180 = insertvalue { %"compiler/source:Span", ptr } %t178, ptr %t174, 1
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t175, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t180, ptr %t181
  %t182 = load { i64, [4 x i64] }, ptr %t175
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t182, ptr %t184
  %t186 = insertvalue { i32, ptr } zeroinitializer, ptr %t184, 1
  store { i32, ptr } %t186, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/token:Token"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca %"compiler/token:Token"
  %l53 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Oracle", ptr %t8, i32 0, i32 0
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t16)
  store %"compiler/token:Token" %t18, ptr %l18
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = load %"compiler/token:Token", ptr %l18
  %t21 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t19, %"compiler/token:Token" %t20)
  store { i64, ptr } %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t24 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l20
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l21, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb7:
  %t29 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t29, ptr %l22
  br label %bb8
bb8:
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t30, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store ptr %l2, ptr %l48, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t84 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t80, i64 %t77)
  store %"compiler/token:Token" %t84, ptr %l52
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l49, !tbaa !29
  %t86 = load %"compiler/token:Token", ptr %l52
  %t87 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t85, %"compiler/token:Token" %t86)
  store { i64, ptr } %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t88, { i64, ptr } %t89)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb15
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Oracle", ptr %t97, i32 0, i32 1
  store ptr %t99, ptr %l58, !tbaa !29
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l58, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t104 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } %t103)
  store i1 %t104, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i1, ptr %l61, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i32
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i32
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca ptr
  %l67 = alloca i32
  %l75 = alloca i32
  %l77 = alloca ptr
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 26
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 25
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t19 = load i32, ptr %l18, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t18, i32 %t19)
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t22, i1 true)
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t26, i64 0)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 12
  store i1 false, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 17
  store i64 0, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 18
  store i1 false, ptr %t36, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 20
  store i64 0, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 21
  store i1 false, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 23
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t48, i64 0)
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t52, i64 0)
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %v0, ptr %t54)
  %t57 = extractvalue { i32, ptr } %t56, 1
  %t58 = extractvalue { i32, ptr } %t56, 0
  store i32 %t58, ptr %l36
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb9, label %ok.60, !prof !99
ok.60:
  store ptr %t57, ptr %l35
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l35, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  br label %bb35
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 26
  %t65 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t64, i64 %t65, i1 false)
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t70, i64 0)
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 38
  store ptr %t74, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l46
  br label %bb14
bb14:
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb15, label %bb16
bb15:
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eAt_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l51
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t94, ptr %t91)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb13
bb21:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t104, i64 0)
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 23
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 23
  store i1 false, ptr %t113, !tbaa !21
  br label %ret
bb24:
  br label %bb25
bb25:
  %t114 = load i64, ptr %l1, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/parse:Parser", ptr %t115, i32 0, i32 6
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = icmp eq i64 %t114, %t118
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t123)
  store i32 %t125, ptr %l67
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %t126, i64 %t127)
  br label %bb30
bb30:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t130, i32 0, i32 6
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load i64, ptr %l1, !tbaa !24
  %t137 = icmp eq i64 %t133, %t134
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l75
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %ret
bb35:
  %t142 = load ptr, ptr %l33, !tbaa !29
  store ptr %t142, ptr %l6, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 37
  store ptr %t145, ptr %l77, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb36, label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_3f74969944d00b69_b8e7e882b42021d)
  unreachable
bb37:
  br label %bb38
bb38:
  %t150 = load ptr, ptr %l6, !tbaa !29
  %t151 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t151, ptr %t150)
  br label %bb39
bb39:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/parse:Parser", ptr %t153, i32 0, i32 50
  store ptr %t155, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb40
bb40:
  %t157 = load i64, ptr %l8, !tbaa !24
  store i64 %t157, ptr %l83, !tbaa !24
  %t158 = load ptr, ptr %l7, !tbaa !29
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t158)
  store i64 %t160, ptr %l85
  br label %bb41
bb41:
  %t161 = load i64, ptr %l83, !tbaa !24
  %t162 = load i64, ptr %l85, !tbaa !24
  %t163 = icmp slt i64 %t161, %t162
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t167 = load ptr, ptr %l7, !tbaa !29
  %t168 = load i64, ptr %l8, !tbaa !24
  %t171 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eAt_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t167, i64 %t168)
  store ptr %t171, ptr %l90
  br label %bb45
bb45:
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/parse:Parser", ptr %t173, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t175, ptr %t172)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t179 = load i64, ptr %l8, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l8, !tbaa !24
  br label %bb40
bb48:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t185, i64 0)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/msgs:Msg"
  %l55 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l13
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp ne i64 %t20, %t21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/scan:Tokens", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t33
  %t38 = load %"compiler/token:Token", ptr %t37
  store %"compiler/token:Token" %t38, ptr %l3
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/token:Token", ptr %t50, i64 %t47
  %t52 = load %"compiler/token:Token", ptr %t51
  store %"compiler/token:Token" %t52, ptr %l4
  %t54 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = icmp sgt i32 %t55, %t57
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = sub i32 %t63, %t65
  %t70 = icmp sle i32 %t68, 60
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t72 = load i1, ptr %l32, !tbaa !21
  br i1 %t72, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  store i64 %t74, ptr %l38, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/source:Source", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store i64 %t85, ptr %l43, !tbaa !24
  %t86 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  store i64 %t89, ptr %l45, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l46, !tbaa !24
  %t92 = load i64, ptr %l43, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb17, label %bb18
bb16:
  %t95 = load i64, ptr %l1, !tbaa !24
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb25, label %bb26
bb17:
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb19:
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb21:
  %t109 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l43, !tbaa !24
  %t112 = load i64, ptr %l45, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s2, { i64, ptr } %t116)
  store %"compiler/msgs:Msg" %t118, ptr %l51
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb23:
  %t119 = load ptr, ptr %l37, !tbaa !29
  %t120 = load i64, ptr %l38, !tbaa !24
  %t121 = load %"compiler/msgs:Msg", ptr %l51
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t119, i64 %t120, %"compiler/msgs:Msg" %t121)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l55, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  store i64 %t123, ptr %l56, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/token:Token", ptr %l3
  %t128 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t124, %"compiler/token:Token" %t125)
  store { i64, ptr } %t128, ptr %l59
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l61, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l62, !tbaa !24
  %t131 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t131, ptr %l63
  br label %bb30
bb27:
  %t132 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s4, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t133, ptr %l60
  br label %bb28
bb28:
  %t134 = load ptr, ptr %l55, !tbaa !29
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t134, i64 %t135, %"compiler/msgs:Msg" %t136)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb30:
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = load %"compiler/msgs:Msg", ptr %l63
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t137, i64 %t138, %"compiler/msgs:Msg" %t139)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  br label %bb33
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load %"compiler/token:Token", ptr %l1
  %t6 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t9 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t5, i8 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 98}
  store i32 %t13, ptr %l2
  %t15 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t17 = trunc i64 8 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t24 = trunc i64 62 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t32 = trunc i64 60 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t40 = trunc i64 92 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t48 = trunc i64 59 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l25, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l29, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t64 = trunc i64 97 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l31 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !range !{i32 0, i32 98}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t7 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t5)
  store i1 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i1, ptr %l9, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %t11)
  store i1 %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t19, i64 1)
  store i32 %t21, ptr %l17
  br label %bb10
bb10:
  %t22 = load i32, ptr %l17, !range !{i32 0, i32 98}
  store i32 %t22, ptr %l2
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t25 = trunc i64 5 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t30 = trunc i64 37 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t37 = trunc i64 33 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t43, i64 %t47)
  store i64 %t50, ptr %l31
  br label %bb20
bb20:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 6
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/scan:Tokens", ptr %t63, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp slt i64 %t59, %t68
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l44, !tbaa !24
  %t81 = icmp eq i64 %t79, %t78
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l41, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l50
  br label %bb29
bb29:
  %t91 = load i32, ptr %l50, !range !{i32 0, i32 98}
  store i32 %t91, ptr %l5
  %t92 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t94 = trunc i64 34 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb31:
  %t97 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t99 = trunc i64 35 to i32
  %t100 = icmp eq i32 %t97, %t99
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb35
bb34:
  %t103 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t105 = trunc i64 36 to i32
  %t106 = icmp eq i32 %t103, %t105
  store i1 %t106, ptr %l56, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb38
bb37:
  %t109 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t111 = trunc i64 22 to i32
  %t112 = icmp eq i32 %t109, %t111
  store i1 %t112, ptr %l59, !tbaa !21
  br label %bb38
bb38:
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb40:
  %t115 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t117 = trunc i64 96 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l4, !tbaa !24
  br label %bb45
bb45:
  br label %bb21
bb46:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l14 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 98}
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 63)
  store i1 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i1, ptr %l8, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l13
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t27, 1
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 15
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l2, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 14
  %t37 = load i1, ptr %t36, !tbaa !21
  store i1 %t37, ptr %l3, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 15
  store i1 true, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 14
  store i1 %a1, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %t51)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb9, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l24, !tbaa !27
  br label %bb10
bb9:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l2, !tbaa !21
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 15
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 14
  store i1 %t74, ptr %t77, !tbaa !21
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t67, 0
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
bb10:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i1, ptr %l2, !tbaa !21
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 15
  store i1 %t81, ptr %t84, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i1, ptr %l3, !tbaa !21
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 14
  store i1 %t86, ptr %t89, !tbaa !21
  %t90 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t2, i32 0, i32 20
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 20
  store i64 %t6, ptr %t9, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t24, i32 %t38)
  store i32 %t41, ptr %l19
  br label %bb7
bb7:
  %t42 = load i32, ptr %l19, !tbaa !23
  %t43 = sext i32 %t42 to i64
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineStartsCase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l22 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp eq i64 %t21, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l10, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l22
  br label %bb12
bb12:
  %t37 = load i32, ptr %l22, !range !{i32 0, i32 98}
  %t39 = trunc i64 32 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/token:Token"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l21 = alloca %"compiler/token:Token"
  %l23 = alloca i32
  %l26 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 1)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t7)
  store %"compiler/token:Token" %t9, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb7
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load %"compiler/token:Token", ptr %l8
  %t12 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t10, %"compiler/token:Token" %t11)
  store { i64, ptr } %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb7
bb7:
  %t16 = load i1, ptr %l5, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t17, i64 1)
  store i32 %t19, ptr %l13
  br label %bb10
bb9:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb11
bb10:
  %t20 = load i32, ptr %l13, !range !{i32 0, i32 98}
  %t22 = trunc i64 5 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb11
bb11:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t28, ptr %l17
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l17
  %t30 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t29, 1
  store { i32, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l19
  br label %bb16
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t34)
  store %"compiler/token:Token" %t36, ptr %l21
  br label %bb17
bb17:
  %t37 = load %"compiler/token:Token", ptr %l21
  store %"compiler/token:Token" %t37, ptr %l1
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l23
  br label %bb18
bb18:
  %t41 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t44 = load i32, ptr %t43, !tbaa !23
  %t47 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t42, i32 %t44)
  store %"compiler/source:Span" %t47, ptr %l26
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load %"compiler/source:Span", ptr %l26
  %t49 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t48, 1
  store { i32, %"compiler/source:Span" } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %lp20 = alloca ptr
  %lp21 = alloca ptr
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t263 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i1, ptr %l23, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t7, i64 2)
  store i32 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i32, ptr %l27, !range !{i32 0, i32 98}
  %t12 = trunc i64 94 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l25, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t18, i32 85)
  store i1 %t21, ptr %l33
  br label %bb8
bb7:
  br label %bb31
bb8:
  %t22 = load i1, ptr %l33, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 94)
  store i1 %t28, ptr %l38
  br label %bb11
bb10:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t29 = load i1, ptr %l38, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t33, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t36, i32 85)
  store i1 %t39, ptr %l43
  br label %bb16
bb16:
  %t40 = load i1, ptr %l43, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t41, i64 1)
  store i32 %t43, ptr %l45
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t44 = load i32, ptr %l45, !range !{i32 0, i32 98}
  store i32 %t44, ptr %l3
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t47 = trunc i64 94 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t57, i64 2)
  store i32 %t59, ptr %l54
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb25
bb24:
  %t60 = load i32, ptr %l54, !range !{i32 0, i32 98}
  %t62 = trunc i64 94 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l52, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l49, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t69, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t73 = load ptr, ptr %l59, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load ptr, ptr %l59, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 30}
  %t79 = icmp eq i64 %t77, 13
  store i1 %t79, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t80 = load i1, ptr %l60, !tbaa !21
  br i1 %t80, label %bb34, label %bb35
bb34:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l4
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t95, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  br label %bb36
bb35:
  br label %bb81
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t99, i32 0, i32 35
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l71
  br label %bb37
bb37:
  %t104 = load i64, ptr %l71, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l5, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t108 = load ptr, ptr %l73, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb39, label %bb40
bb39:
  %t111 = load ptr, ptr %l73, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 30}
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t115 = load i1, ptr %l74, !tbaa !21
  br i1 %t115, label %bb41, label %bb42
bb41:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32 }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 35
  %t125 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t124, i32 %t125)
  br label %bb44
bb44:
  br label %bb59
bb45:
  %t128 = load ptr, ptr %l8, !tbaa !29
  store ptr %t128, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t129 = load ptr, ptr %l82, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb46, label %bb47
bb46:
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i64, ptr %t132, !range !{i64 0, i64 30}
  %t135 = icmp eq i64 %t133, 14
  store i1 %t135, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t136 = load i1, ptr %l83, !tbaa !21
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t137 = load ptr, ptr %l8, !tbaa !29
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t139, i32 0, i32 1
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l10, !tbaa !29
  %t143 = load ptr, ptr %l8, !tbaa !29
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l11, !tbaa !23
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 35
  %t152 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t151, i32 %t152)
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l10, !tbaa !29
  store ptr %t155, ptr %l8, !tbaa !29
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb59
bb56:
  call void @__olang_check_failed(ptr @olang_loc_824bfdca782f89b4_8a051d8e1bdc5e78)
  unreachable
bb57:
  br label %bb58
bb58:
  br label %bb38
bb59:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 35
  %t160 = load i64, ptr %l7, !tbaa !24
  %t163 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %s5, ptr %t159, i64 %t160)
  store { i64, ptr } %t163, ptr %l97
  br label %bb60
bb60:
  %t164 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l99, !tbaa !24
  %t168 = load i64, ptr %l99, !tbaa !24
  %t169 = icmp sge i64 %t168, 0
  br i1 %t169, label %bb61, label %bb62
bb61:
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = icmp sle i64 %t171, 2305843009213693951
  br i1 %t172, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_c92b08434e34de1e_b2c231b9ab335d4a)
  unreachable
bb63:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = mul i64 %t174, 4
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t179, ptr %lp13
  %t181 = load ptr, ptr %lp13
  store { i64, ptr } %t178, ptr %t181, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_c92b08434e34de1e_b2c231b9ab335d4a)
  unreachable
bb65:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb70
bb67:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i64, ptr %l14, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l111, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb69
bb69:
  %t212 = load i64, ptr %l111, !tbaa !24
  store i64 %t212, ptr %l108, !tbaa !24
  br label %bb70
bb70:
  %t213 = load i64, ptr %l108, !tbaa !24
  store i64 %t213, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb71
bb71:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb72, label %bb73
bb72:
  br label %bb76
bb73:
  br label %bb74
bb74:
  %t222 = load i64, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l18, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l19, !tbaa !24
  %t232 = load ptr, ptr %lp13
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l129, !tbaa !27
  %t234 = load i64, ptr %l19, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t235, ptr %l131, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t240 = sub i64 %t238, 1
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t246 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i32, ptr %t247, i64 %t244
  %t249 = load i32, ptr %t248, !tbaa !33
  %t252 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i32, ptr %t253, i64 %t234
  store i32 %t249, ptr %t254, !tbaa !33
  br label %bb75
bb75:
  %t255 = load i64, ptr %l18, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l18, !tbaa !24
  br label %bb71
bb76:
  %t259 = load %"compiler/source:Span", ptr %l4
  %t260 = load ptr, ptr %lp13
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 0
  store i64 0, ptr %t264
  %t266 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t259, 0
  %t268 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t266, { i64, ptr } %t261, 1
  %t270 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t268, { i64, ptr } %t262, 2
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t270, ptr %t271
  %t272 = load { i64, [5 x i64] }, ptr %t263
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t272, ptr %t274
  %t275 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t275, ptr %lp20
  %t277 = load ptr, ptr %lp20
  store ptr %t274, ptr %t277, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i32, ptr %l1, !tbaa !23
  %t280 = load ptr, ptr %lp20
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t285 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v2, ptr %v2, ptr %t278, i32 %t279, ptr %t281)
  store ptr %t285, ptr %l148
  br label %bb77
bb77:
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t286, ptr %lp21
  %t287 = load ptr, ptr %l148, !tbaa !29
  %t288 = load ptr, ptr %lp21
  store ptr %t287, ptr %t288, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l1, !tbaa !23
  %t291 = load ptr, ptr %lp21
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t296 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v2, ptr %v2, ptr %t289, i32 %t290, ptr %t292)
  %t297 = extractvalue { i32, ptr } %t296, 1
  %t298 = extractvalue { i32, ptr } %t296, 0
  store i32 %t298, ptr %l154
  %t299 = icmp ne i32 %t298, 0
  br i1 %t299, label %bb79, label %ok.300, !prof !99
ok.300:
  store ptr %t297, ptr %l153
  br label %bb78
bb78:
  %t301 = load ptr, ptr %l153, !tbaa !29
  store ptr %t301, ptr %l149, !tbaa !29
  br label %bb80
bb79:
  %t302 = load i32, ptr %l154, !tbaa !23
  %t303 = lshr i32 %t302, 16
  %t304 = and i32 %t302, 65535
  %t305 = icmp eq i32 %t303, 1
  %t306 = select i1 %t305, i32 1, i32 0
  %t307 = icmp eq i32 %t302, 0
  %t308 = shl i32 %t306, 16
  %t309 = or i32 %t308, %t304
  %t310 = select i1 %t307, i32 0, i32 %t309
  call void @__olang_scope_close(ptr %s5)
  %t312 = insertvalue { i32, ptr } zeroinitializer, i32 %t310, 0
  store { i32, ptr } %t312, ptr %rv
  br label %ret
bb80:
  call void @__olang_scope_close(ptr %s5)
  %t313 = load ptr, ptr %l149, !tbaa !29
  %t314 = insertvalue { i32, ptr } zeroinitializer, ptr %t313, 1
  store { i32, ptr } %t314, ptr %rv
  br label %ret
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t317 = insertvalue { i32, ptr } zeroinitializer, ptr %t315, 1
  store { i32, ptr } %t317, ptr %rv
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_7df95d039a20ef2e_354875480560b892)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp sge i64 %t7, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/scan:Tokens", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 98}
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5, !range !{i32 0, i32 98}
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 %t13, %t14
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t16, i64 %t15)
  store i64 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp sge i64 %t20, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/scan:Tokens", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/scan:Tokens", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = sub i64 %t49, 1
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t51
  %t56 = load %"compiler/token:Token", ptr %t55
  store %"compiler/token:Token" %t56, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/scan:Tokens", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i64 %t65
  %t70 = load %"compiler/token:Token", ptr %t69
  store %"compiler/token:Token" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l31 = alloca %"compiler/source:Span"
  %rv = alloca ptr
  %t51 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5, !range !{i32 0, i32 98}
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t11, i32 85)
  store i1 %t14, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb13
bb4:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eampOperator(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l15
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t19 = load i1, ptr %l15, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t23)
  store i1 %t25, ptr %l19
  br label %bb11
bb11:
  %t26 = load i1, ptr %l19, !tbaa !21
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t28 = load i1, ptr %l9, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t31, i32 61)
  store i1 %t34, ptr %l23
  br label %bb17
bb17:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l26
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l28
  br label %bb22
bb22:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t44, i32 %a1)
  store %"compiler/source:Span" %t48, ptr %l31
  br label %bb23
bb23:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load i1, ptr %l4, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 0
  store i64 3, ptr %t52
  %t53 = load %"compiler/source:Span", ptr %l31
  %t54 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t53, 0
  %t56 = insertvalue { %"compiler/source:Span", ptr, i1 } %t54, ptr %t49, 1
  %t58 = insertvalue { %"compiler/source:Span", ptr, i1 } %t56, i1 %t50, 2
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t58, ptr %t59
  %t60 = load { i64, [5 x i64] }, ptr %t51
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t60, ptr %t62
  store ptr %t62, ptr %l3, !tbaa !29
  br label %bb24
bb24:
  br label %bb1
bb25:
  %t64 = load ptr, ptr %l3, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %lp20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i1
  %lp23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i64
  %lp31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %lp34 = alloca ptr
  %l35 = alloca i32
  %lp36 = alloca ptr
  %lp37 = alloca ptr
  %lp38 = alloca ptr
  %l39 = alloca { { i64, ptr }, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca %"compiler/token:Token"
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l65 = alloca i64
  %l67 = alloca i64
  %l72 = alloca i32
  %l80 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i32
  %l92 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i64
  %l105 = alloca i64
  %l110 = alloca i32
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i32
  %l135 = alloca i1
  %l138 = alloca { i64, ptr }
  %l142 = alloca i1
  %l145 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca i1
  %l162 = alloca i1
  %l164 = alloca i1
  %l166 = alloca i1
  %l168 = alloca i1
  %l170 = alloca i1
  %l172 = alloca i1
  %l179 = alloca i1
  %l182 = alloca i1
  %l185 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca i32
  %l194 = alloca i32
  %l197 = alloca i32
  %l198 = alloca i32
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l211 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l217 = alloca i32
  %l218 = alloca i32
  %l221 = alloca i32
  %l222 = alloca i32
  %l226 = alloca i64
  %l229 = alloca i64
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l235 = alloca ptr
  %l236 = alloca i32
  %l238 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca i32
  %l244 = alloca i1
  %l245 = alloca i1
  %l248 = alloca i1
  %l249 = alloca i1
  %l251 = alloca %"compiler/token:Token"
  %l253 = alloca i1
  %l256 = alloca i32
  %l257 = alloca i32
  %l259 = alloca i32
  %l260 = alloca i32
  %l264 = alloca i64
  %l265 = alloca [0 x ptr]
  %l266 = alloca { i64, ptr }
  %l267 = alloca ptr
  %l268 = alloca i1
  %l279 = alloca { i64, ptr }
  %l281 = alloca i64
  %l283 = alloca i64
  %l284 = alloca { i64, ptr }
  %l289 = alloca %"compiler/source:Span"
  %l293 = alloca { i64, ptr }
  %l297 = alloca ptr
  %l299 = alloca %"compiler/source:Span"
  %l303 = alloca %"compiler/source:Span"
  %l304 = alloca ptr
  %l305 = alloca i32
  %l308 = alloca %"compiler/source:Span"
  %l312 = alloca ptr
  %l315 = alloca ptr
  %l318 = alloca i1
  %l321 = alloca i1
  %l324 = alloca i32
  %l327 = alloca i1
  %l330 = alloca i1
  %l333 = alloca i1
  %l336 = alloca i1
  %l339 = alloca i1
  %l343 = alloca i32
  %l347 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l354 = alloca i1
  %l355 = alloca ptr
  %l357 = alloca ptr
  %l358 = alloca i32
  %l361 = alloca { { i64, ptr }, ptr }
  %l364 = alloca { { i64, ptr }, ptr }
  %l365 = alloca i32
  %l369 = alloca ptr
  %l372 = alloca %"compiler/source:Span"
  %l378 = alloca %"compiler/ast:Case"
  %l382 = alloca i1
  %l384 = alloca i32
  %l385 = alloca i32
  %l388 = alloca i32
  %l389 = alloca i32
  %l397 = alloca %"compiler/source:Span"
  %l398 = alloca ptr
  %l399 = alloca i1
  %l401 = alloca { i64, ptr }
  %l402 = alloca %"compiler/ast:Match"
  %s15 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t626 = alloca { i64, [5 x i64] }, align 8
  %t661 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 31)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l46
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l45
  br label %bb1
bb1:
  %t9 = load i32, ptr %l45, !tbaa !23
  store i32 %t9, ptr %l42, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l46, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l42, !tbaa !23
  store i32 %t21, ptr %l2, !tbaa !23
  store i1 false, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 1)
  store i1 %t25, ptr %l50
  br label %bb4
bb4:
  %t26 = load i1, ptr %l50, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l53
  br label %bb7
bb6:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i32, ptr %l53, !range !{i32 0, i32 98}
  %t32 = trunc i64 96 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l51, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l51, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l57, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l58, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t41)
  store %"compiler/token:Token" %t43, ptr %l60
  br label %bb11
bb10:
  br label %bb25
bb11:
  %t44 = load ptr, ptr %l58, !tbaa !29
  %t45 = load %"compiler/token:Token", ptr %l60
  %t46 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t44, %"compiler/token:Token" %t45)
  store { i64, ptr } %t46, ptr %l61
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l57, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l62
  br label %bb13
bb13:
  %t50 = load i32, ptr %l62, !tbaa !23
  store i32 %t50, ptr %l4, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 28
  store ptr %t53, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l6, !tbaa !24
  store i64 %t55, ptr %l65, !tbaa !24
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l67
  br label %bb15
bb15:
  %t59 = load i64, ptr %l65, !tbaa !24
  %t60 = load i64, ptr %l67, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t69, ptr %l72
  br label %bb19
bb19:
  %t70 = load i32, ptr %l72, !tbaa !23
  %t72 = load i32, ptr %l4, !tbaa !23
  %t75 = icmp eq i32 %t70, %t72
  br i1 %t75, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb14
bb24:
  br label %bb25
bb25:
  %t81 = load i1, ptr %l3, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 1)
  store i1 %t88, ptr %l83
  br label %bb28
bb27:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb29
bb28:
  %t89 = load i1, ptr %l83, !tbaa !21
  store i1 %t89, ptr %l80, !tbaa !21
  br label %bb29
bb29:
  %t90 = load i1, ptr %l80, !tbaa !21
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t91, i64 1)
  store i32 %t93, ptr %l86
  br label %bb32
bb31:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb33
bb32:
  %t94 = load i32, ptr %l86, !range !{i32 0, i32 98}
  %t96 = trunc i64 60 to i32
  %t97 = icmp eq i32 %t94, %t96
  store i1 %t97, ptr %l84, !tbaa !21
  br label %bb33
bb33:
  %t99 = load i1, ptr %l84, !tbaa !21
  br i1 %t99, label %bb34, label %bb35
bb34:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l92, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/scan:Tokens", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l96, !tbaa !27
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/token:Token", ptr %t120, i64 %t117
  %t122 = load %"compiler/token:Token", ptr %t121
  %t125 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t109, %"compiler/token:Token" %t122)
  store { i64, ptr } %t125, ptr %l99
  br label %bb36
bb35:
  br label %bb98
bb36:
  %t126 = load ptr, ptr %l92, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t128 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t126, { i64, ptr } %t127)
  store i32 %t128, ptr %l100
  br label %bb37
bb37:
  %t129 = load i32, ptr %l100, !tbaa !23
  store i32 %t129, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t130, i32 0, i32 28
  store ptr %t132, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t134 = load i64, ptr %l12, !tbaa !24
  store i64 %t134, ptr %l103, !tbaa !24
  %t135 = load ptr, ptr %l11, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l105
  br label %bb39
bb39:
  %t138 = load i64, ptr %l103, !tbaa !24
  %t139 = load i64, ptr %l105, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t144, i64 %t145)
  store i32 %t148, ptr %l110
  br label %bb43
bb43:
  %t149 = load i32, ptr %l110, !tbaa !23
  %t151 = load i32, ptr %l9, !tbaa !23
  %t154 = icmp eq i32 %t149, %t151
  br i1 %t154, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l12, !tbaa !24
  br label %bb38
bb48:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/parse:Parser", ptr %t160, i32 0, i32 29
  store ptr %t162, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb49
bb49:
  %t164 = load i64, ptr %l15, !tbaa !24
  store i64 %t164, ptr %l118, !tbaa !24
  %t165 = load ptr, ptr %l14, !tbaa !29
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t165)
  store i64 %t167, ptr %l120
  br label %bb50
bb50:
  %t168 = load i64, ptr %l118, !tbaa !24
  %t169 = load i64, ptr %l120, !tbaa !24
  %t170 = icmp slt i64 %t168, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t174 = load ptr, ptr %l14, !tbaa !29
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t174, i64 %t175)
  store i32 %t178, ptr %l125
  br label %bb54
bb54:
  %t179 = load i32, ptr %l125, !tbaa !23
  %t181 = load i32, ptr %l9, !tbaa !23
  %t184 = icmp eq i32 %t179, %t181
  br i1 %t184, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t186 = load i64, ptr %l15, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l15, !tbaa !24
  br label %bb49
bb59:
  %t190 = load i64, ptr %l8, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l8, !tbaa !24
  %t194 = load i1, ptr %l10, !tbaa !21
  store i1 %t194, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t196 = load i1, ptr %l17, !tbaa !21
  br i1 %t196, label %bb61, label %bb62
bb61:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/scan:Tokens", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l138, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr %"compiler/token:Token", ptr %t208, i64 %t205
  %t210 = getelementptr %"compiler/token:Token", ptr %t209, i32 0, i32 0
  %t211 = load i32, ptr %t210, !range !{i32 0, i32 98}
  %t213 = trunc i64 60 to i32
  %t214 = icmp eq i32 %t211, %t213
  store i1 %t214, ptr %l135, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb63
bb63:
  %t216 = load i1, ptr %l135, !tbaa !21
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/parse:Parser", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/scan:Tokens", ptr %t220, i32 0, i32 0
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l145, !tbaa !27
  %t224 = load i64, ptr %l8, !tbaa !24
  %t226 = add i64 %t224, 1
  %t228 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr %"compiler/token:Token", ptr %t229, i64 %t226
  %t231 = getelementptr %"compiler/token:Token", ptr %t230, i32 0, i32 0
  %t232 = load i32, ptr %t231, !range !{i32 0, i32 98}
  %t234 = trunc i64 1 to i32
  %t235 = icmp eq i32 %t232, %t234
  store i1 %t235, ptr %l142, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb66
bb66:
  %t237 = load i1, ptr %l142, !tbaa !21
  %t238 = xor i1 %t237, true
  br i1 %t238, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb68:
  br label %bb69
bb69:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/scan:Tokens", ptr %t244, i32 0, i32 0
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l154, !tbaa !27
  %t248 = load i64, ptr %l8, !tbaa !24
  %t250 = add i64 %t248, 1
  %t252 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/token:Token", ptr %t253, i64 %t250
  %t255 = load %"compiler/token:Token", ptr %t254
  %t258 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t240, %"compiler/token:Token" %t255)
  store { i64, ptr } %t258, ptr %l158
  br label %bb70
bb70:
  %t259 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t259, ptr %l19, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t260, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t262, ptr %l160
  br label %bb71
bb71:
  %t263 = load i1, ptr %l160, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb72, label %bb73
bb72:
  %t266 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t266, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t268, ptr %l164
  br label %bb74
bb73:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb75
bb74:
  %t269 = load i1, ptr %l164, !tbaa !21
  %t270 = xor i1 %t269, true
  store i1 %t270, ptr %l162, !tbaa !21
  br label %bb75
bb75:
  %t272 = load i1, ptr %l162, !tbaa !21
  br i1 %t272, label %bb76, label %bb77
bb76:
  %t273 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t275 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t273, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t275, ptr %l168
  br label %bb78
bb77:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb79
bb78:
  %t276 = load i1, ptr %l168, !tbaa !21
  %t277 = xor i1 %t276, true
  store i1 %t277, ptr %l166, !tbaa !21
  br label %bb79
bb79:
  %t279 = load i1, ptr %l166, !tbaa !21
  br i1 %t279, label %bb80, label %bb81
bb80:
  %t280 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t282 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t280, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t282, ptr %l172
  br label %bb82
bb81:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb83
bb82:
  %t283 = load i1, ptr %l172, !tbaa !21
  %t284 = xor i1 %t283, true
  store i1 %t284, ptr %l170, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l170, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t287 = load i64, ptr %l8, !tbaa !24
  %t289 = add i64 %t287, 2
  store i64 %t289, ptr %l8, !tbaa !24
  %t291 = load i64, ptr %l18, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb87:
  br label %bb60
bb88:
  %t295 = load i1, ptr %l17, !tbaa !21
  br i1 %t295, label %bb89, label %bb90
bb89:
  %t297 = load i64, ptr %l18, !tbaa !24
  %t299 = icmp sgt i64 %t297, 0
  store i1 %t299, ptr %l179, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb91
bb91:
  %t301 = load i1, ptr %l179, !tbaa !21
  br i1 %t301, label %bb92, label %bb93
bb92:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/parse:Parser", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = getelementptr %"compiler/scan:Tokens", ptr %t305, i32 0, i32 0
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l185, !tbaa !27
  %t309 = load i64, ptr %l8, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr %"compiler/token:Token", ptr %t312, i64 %t309
  %t314 = getelementptr %"compiler/token:Token", ptr %t313, i32 0, i32 0
  %t315 = load i32, ptr %t314, !range !{i32 0, i32 98}
  %t317 = trunc i64 96 to i32
  %t318 = icmp eq i32 %t315, %t317
  store i1 %t318, ptr %l182, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb94
bb94:
  %t320 = load i1, ptr %l182, !tbaa !21
  br i1 %t320, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb97
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t321)
  %t324 = extractvalue { i32, ptr } %t323, 1
  %t325 = extractvalue { i32, ptr } %t323, 0
  store i32 %t325, ptr %l192
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb100, label %ok.327, !prof !99
ok.327:
  store ptr %t324, ptr %l191
  br label %bb99
bb99:
  %t328 = load ptr, ptr %l191, !tbaa !29
  store ptr %t328, ptr %l189, !tbaa !29
  br label %bb101
bb100:
  %t329 = load i32, ptr %l192, !tbaa !23
  %t330 = lshr i32 %t329, 16
  %t331 = and i32 %t329, 65535
  %t332 = icmp eq i32 %t330, 1
  %t333 = select i1 %t332, i32 1, i32 0
  %t334 = icmp eq i32 %t329, 0
  %t335 = shl i32 %t333, 16
  %t336 = or i32 %t335, %t331
  %t337 = select i1 %t334, i32 0, i32 %t336
  %t339 = insertvalue { i32, ptr } zeroinitializer, i32 %t337, 0
  store { i32, ptr } %t339, ptr %rv
  br label %ret
bb101:
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t340, ptr %lp20
  %t341 = load ptr, ptr %l189, !tbaa !29
  %t342 = load ptr, ptr %lp20
  store ptr %t341, ptr %t342, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t346 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t343, i32 96)
  %t347 = extractvalue { i32, i32 } %t346, 1
  %t348 = extractvalue { i32, i32 } %t346, 0
  store i32 %t348, ptr %l198
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb103, label %ok.350, !prof !99
ok.350:
  store i32 %t347, ptr %l197
  br label %bb102
bb102:
  %t351 = load i32, ptr %l197, !tbaa !23
  store i32 %t351, ptr %l194, !tbaa !23
  br label %bb104
bb103:
  %t352 = load i32, ptr %l198, !tbaa !23
  %t353 = lshr i32 %t352, 16
  %t354 = and i32 %t352, 65535
  %t355 = icmp eq i32 %t353, 1
  %t356 = select i1 %t355, i32 1, i32 0
  %t357 = icmp eq i32 %t352, 0
  %t358 = shl i32 %t356, 16
  %t359 = or i32 %t358, %t354
  %t360 = select i1 %t357, i32 0, i32 %t359
  %t362 = insertvalue { i32, ptr } zeroinitializer, i32 %t360, 0
  store { i32, ptr } %t362, ptr %rv
  br label %ret
bb104:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/parse:Parser", ptr %t363, i32 0, i32 17
  %t366 = load i64, ptr %t365, !tbaa !24
  store i64 %t366, ptr %l21, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/parse:Parser", ptr %t368, i32 0, i32 17
  store i64 0, ptr %t370, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/parse:Parser", ptr %t371, i32 0, i32 18
  %t374 = load i1, ptr %t373, !tbaa !21
  store i1 %t374, ptr %l22, !tbaa !21
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/parse:Parser", ptr %t376, i32 0, i32 18
  store i1 false, ptr %t378, !tbaa !21
  %t379 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t379, ptr %l206
  br label %bb105
bb105:
  %t380 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l206
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %t381
  %t382 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t382, ptr %lp23
  %t384 = load ptr, ptr %lp23
  store ptr %t381, ptr %t384, !tbaa !29
  br label %bb106
bb106:
  %t385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t385)
  br label %bb107
bb107:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t387, i32 97)
  store i1 %t390, ptr %l211
  br label %bb108
bb108:
  %t391 = load i1, ptr %l211, !tbaa !21
  br i1 %t391, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb112
bb110:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t395 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t392, i32 0)
  store i1 %t395, ptr %l215
  br label %bb111
bb111:
  %t396 = load i1, ptr %l215, !tbaa !21
  store i1 %t396, ptr %l212, !tbaa !21
  br label %bb112
bb112:
  %t397 = load i1, ptr %l212, !tbaa !21
  br i1 %t397, label %bb113, label %bb114
bb113:
  br label %bb226
bb114:
  br label %bb115
bb115:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t398)
  store i32 %t400, ptr %l217
  br label %bb116
bb116:
  %t401 = load i32, ptr %l217, !tbaa !23
  store i32 %t401, ptr %l24, !tbaa !23
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t405 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t402, i32 32)
  %t406 = extractvalue { i32, i32 } %t405, 1
  %t407 = extractvalue { i32, i32 } %t405, 0
  store i32 %t407, ptr %l222
  %t408 = icmp ne i32 %t407, 0
  br i1 %t408, label %bb118, label %ok.409, !prof !99
ok.409:
  store i32 %t406, ptr %l221
  br label %bb117
bb117:
  %t410 = load i32, ptr %l221, !tbaa !23
  store i32 %t410, ptr %l218, !tbaa !23
  br label %bb119
bb118:
  %t411 = load i32, ptr %l222, !tbaa !23
  %t412 = lshr i32 %t411, 16
  %t413 = and i32 %t411, 65535
  %t414 = icmp eq i32 %t412, 1
  %t415 = select i1 %t414, i32 1, i32 0
  %t416 = icmp eq i32 %t411, 0
  %t417 = shl i32 %t415, 16
  %t418 = or i32 %t417, %t413
  %t419 = select i1 %t416, i32 0, i32 %t418
  %t421 = insertvalue { i32, ptr } zeroinitializer, i32 %t419, 0
  store { i32, ptr } %t421, ptr %rv
  br label %ret
bb119:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/parse:Parser", ptr %t422, i32 0, i32 34
  %t426 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t424)
  store i64 %t426, ptr %l226
  br label %bb120
bb120:
  %t427 = load i64, ptr %l226, !tbaa !24
  store i64 %t427, ptr %l25, !tbaa !24
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/parse:Parser", ptr %t428, i32 0, i32 32
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t430)
  store i64 %t432, ptr %l229
  br label %bb121
bb121:
  %t433 = load i64, ptr %l229, !tbaa !24
  store i64 %t433, ptr %l26, !tbaa !24
  br label %bb122
bb122:
  %t434 = load i1, ptr %l3, !tbaa !21
  br i1 %t434, label %bb123, label %bb124
bb123:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/parse:Parser", ptr %t436, i32 0, i32 32
  store ptr %t438, ptr %l232, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %v0, ptr %t439)
  %t442 = extractvalue { i32, ptr } %t441, 1
  %t443 = extractvalue { i32, ptr } %t441, 0
  store i32 %t443, ptr %l236
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb126, label %ok.445, !prof !99
ok.445:
  store ptr %t442, ptr %l235
  br label %bb125
bb124:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t446, i64 1)
  %t449 = extractvalue { i32, ptr } %t448, 1
  %t450 = extractvalue { i32, ptr } %t448, 0
  store i32 %t450, ptr %l241
  %t451 = icmp ne i32 %t450, 0
  br i1 %t451, label %bb130, label %ok.452, !prof !99
ok.452:
  store ptr %t449, ptr %l240
  br label %bb129
bb125:
  %t453 = load ptr, ptr %l235, !tbaa !29
  store ptr %t453, ptr %l233, !tbaa !29
  br label %bb127
bb126:
  %t454 = load i32, ptr %l236, !tbaa !23
  %t455 = lshr i32 %t454, 16
  %t456 = and i32 %t454, 65535
  %t457 = icmp eq i32 %t455, 1
  %t458 = select i1 %t457, i32 1, i32 0
  %t459 = icmp eq i32 %t454, 0
  %t460 = shl i32 %t458, 16
  %t461 = or i32 %t460, %t456
  %t462 = select i1 %t459, i32 0, i32 %t461
  %t464 = insertvalue { i32, ptr } zeroinitializer, i32 %t462, 0
  store { i32, ptr } %t464, ptr %rv
  br label %ret
bb127:
  %t465 = load ptr, ptr %l232, !tbaa !29
  %t466 = load ptr, ptr %l233, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t465, ptr %t466)
  br label %bb128
bb128:
  br label %bb174
bb129:
  %t467 = load ptr, ptr %l240, !tbaa !29
  store ptr %t467, ptr %l238, !tbaa !29
  br label %bb131
bb130:
  %t468 = load i32, ptr %l241, !tbaa !23
  %t469 = lshr i32 %t468, 16
  %t470 = and i32 %t468, 65535
  %t471 = icmp eq i32 %t469, 1
  %t472 = select i1 %t471, i32 1, i32 0
  %t473 = icmp eq i32 %t468, 0
  %t474 = shl i32 %t472, 16
  %t475 = or i32 %t474, %t470
  %t476 = select i1 %t473, i32 0, i32 %t475
  %t478 = insertvalue { i32, ptr } zeroinitializer, i32 %t476, 0
  store { i32, ptr } %t478, ptr %rv
  br label %ret
bb131:
  %t479 = load ptr, ptr %l238, !tbaa !29
  store ptr %t479, ptr %l27, !tbaa !29
  %t480 = load ptr, ptr %l27, !tbaa !29
  %t482 = call i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %t480)
  store i1 %t482, ptr %l244
  br label %bb132
bb132:
  %t483 = load i1, ptr %l244, !tbaa !21
  br i1 %t483, label %bb133, label %bb134
bb133:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t487 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t484, i32 1)
  store i1 %t487, ptr %l248
  br label %bb135
bb134:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb136
bb135:
  %t488 = load i1, ptr %l248, !tbaa !21
  store i1 %t488, ptr %l245, !tbaa !21
  br label %bb136
bb136:
  %t489 = load i1, ptr %l245, !tbaa !21
  br i1 %t489, label %bb137, label %bb138
bb137:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t490)
  store %"compiler/token:Token" %t492, ptr %l251
  br label %bb139
bb138:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb141
bb139:
  %t493 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t494 = load %"compiler/token:Token", ptr %l251
  %t496 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t494, i8 %t493)
  store i1 %t496, ptr %l253
  br label %bb140
bb140:
  %t497 = load i1, ptr %l253, !tbaa !21
  %t498 = xor i1 %t497, true
  store i1 %t498, ptr %l249, !tbaa !21
  br label %bb141
bb141:
  %t500 = load i1, ptr %l249, !tbaa !21
  br i1 %t500, label %bb142, label %bb143
bb142:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t501)
  store i32 %t503, ptr %l256
  br label %bb144
bb143:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/parse:Parser", ptr %t504, i32 0, i32 34
  store ptr %t506, ptr %l312, !tbaa !29
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l27, !tbaa !29
  %t511 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v0, ptr %v0, ptr %t507, ptr %t508, i1 true)
  store ptr %t511, ptr %l315
  br label %bb171
bb144:
  %t512 = load i32, ptr %l256, !tbaa !23
  store i32 %t512, ptr %l28, !tbaa !23
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t513)
  %t516 = extractvalue { i32, i32 } %t515, 1
  %t517 = extractvalue { i32, i32 } %t515, 0
  store i32 %t517, ptr %l260
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb146, label %ok.519, !prof !99
ok.519:
  store i32 %t516, ptr %l259
  br label %bb145
bb145:
  %t520 = load i32, ptr %l259, !tbaa !23
  store i32 %t520, ptr %l257, !tbaa !23
  br label %bb147
bb146:
  %t521 = load i32, ptr %l260, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  %t531 = insertvalue { i32, ptr } zeroinitializer, i32 %t529, 0
  store { i32, ptr } %t531, ptr %rv
  br label %ret
bb147:
  %t532 = load i32, ptr %l257, !tbaa !23
  store i32 %t532, ptr %l29, !tbaa !23
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/parse:Parser", ptr %t533, i32 0, i32 35
  %t537 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t535)
  store i64 %t537, ptr %l264
  br label %bb148
bb148:
  %t538 = load i64, ptr %l264, !tbaa !24
  store i64 %t538, ptr %l30, !tbaa !24
  store [0 x ptr] zeroinitializer, ptr %l265
  %t539 = mul i64 0, 8
  %t540 = insertvalue { i64, ptr } undef, i64 0, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t541, ptr %l266, !tbaa !27
  %t542 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t543, ptr %l265, i64 %t544, i1 false)
  %t545 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t545, ptr %lp31
  %t546 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t547 = load ptr, ptr %lp31
  store { i64, ptr } %t546, ptr %t547, !tbaa !27
  %t548 = load ptr, ptr %l27, !tbaa !29
  store ptr %t548, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t549 = load ptr, ptr %l267, !tbaa !29
  %t550 = icmp ne ptr %t549, null
  br i1 %t550, label %bb149, label %bb150
bb149:
  %t552 = load ptr, ptr %l267, !tbaa !29
  %t553 = load i64, ptr %t552, !range !{i64 0, i64 30}
  %t555 = icmp eq i64 %t553, 13
  store i1 %t555, ptr %l268, !tbaa !21
  br label %bb150
bb150:
  %t556 = load i1, ptr %l268, !tbaa !21
  br i1 %t556, label %bb151, label %bb152
bb151:
  %t557 = load ptr, ptr %l27, !tbaa !29
  %t559 = getelementptr { i64, [4 x i64] }, ptr %t557, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t559, i32 0, i32 1
  %t561 = load ptr, ptr %t560
  store ptr %t561, ptr %l32, !tbaa !29
  %t563 = load ptr, ptr %l27, !tbaa !29
  %t565 = getelementptr { i64, [4 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t565, i32 0, i32 2
  %t567 = load { i64, ptr }, ptr %t566
  store { i64, ptr } %t567, ptr %l33, !tbaa !27
  br label %bb153
bb152:
  br label %bb158
bb153:
  %t569 = load ptr, ptr %l32, !tbaa !29
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/parse:Parser", ptr %t570, i32 0, i32 35
  call void @compiler_2fparse_2epathIds(ptr %v0, ptr %v0, ptr %t569, ptr %t572)
  br label %bb154
bb154:
  %t575 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t575, ptr %l279, !tbaa !27
  %t577 = load ptr, ptr %lp31
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 0
  %t580 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t581 = extractvalue { i64, ptr } %t580, 0
  store i64 %t581, ptr %l281, !tbaa !24
  %t583 = load i64, ptr %l281, !tbaa !24
  %t584 = icmp eq i64 %t579, %t583
  br i1 %t584, label %bb155, label %bb156
bb155:
  %t586 = load ptr, ptr %lp31
  %t587 = getelementptr { i64, ptr }, ptr %t586, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = load i64, ptr %l281, !tbaa !24
  %t592 = mul i64 %t591, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t588, ptr %t590, i64 %t592, i1 false)
  br label %bb157
bb156:
  %t593 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t593, 0
  store i64 %t594, ptr %l283, !tbaa !24
  %t595 = load i64, ptr %l283, !tbaa !24
  %t596 = mul i64 %t595, 8
  %t597 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t596)
  %t598 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l284, !tbaa !27
  %t600 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = load i64, ptr %l283, !tbaa !24
  %t605 = mul i64 %t604, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t601, ptr %t603, i64 %t605, i1 false)
  %t606 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t607 = load ptr, ptr %lp31
  store { i64, ptr } %t606, ptr %t607, !tbaa !27
  br label %bb157
bb157:
  br label %bb164
bb158:
  br i1 true, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t608 = load ptr, ptr %l27, !tbaa !29
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/parse:Parser", ptr %t609, i32 0, i32 35
  call void @compiler_2fparse_2epathIds(ptr %v0, ptr %v0, ptr %t608, ptr %t611)
  br label %bb162
bb162:
  br label %bb164
bb163:
  call void @__olang_check_failed(ptr @olang_loc_db61fb5d51a81784_d7c7d8e6a8f1b2c8)
  unreachable
bb164:
  %t614 = load ptr, ptr %l27, !tbaa !29
  %t616 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t614)
  store %"compiler/source:Span" %t616, ptr %l289
  br label %bb165
bb165:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t619 = getelementptr %"compiler/parse:Parser", ptr %t617, i32 0, i32 35
  %t620 = load i64, ptr %l30, !tbaa !24
  %t623 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v0, ptr %t619, i64 %t620)
  store { i64, ptr } %t623, ptr %l293
  br label %bb166
bb166:
  %t624 = load ptr, ptr %lp31
  %t625 = load { i64, ptr }, ptr %t624, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t626
  %t627 = getelementptr { i64, [5 x i64] }, ptr %t626, i32 0, i32 0
  store i64 0, ptr %t627
  %t628 = load %"compiler/source:Span", ptr %l289
  %t629 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t628, 0
  %t630 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t631 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t629, { i64, ptr } %t630, 1
  %t633 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t631, { i64, ptr } %t625, 2
  %t634 = getelementptr { i64, [5 x i64] }, ptr %t626, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t633, ptr %t634
  %t635 = load { i64, [5 x i64] }, ptr %t626
  %t636 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t636, ptr %lp34
  %t638 = load ptr, ptr %lp34
  store { i64, [5 x i64] } %t635, ptr %t638
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/parse:Parser", ptr %t639, i32 0, i32 34
  store ptr %t641, ptr %l297, !tbaa !29
  %t642 = load ptr, ptr %l27, !tbaa !29
  %t644 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t642)
  store %"compiler/source:Span" %t644, ptr %l299
  br label %bb167
bb167:
  %t645 = getelementptr %"compiler/source:Span", ptr %l299, i32 0, i32 0
  %t646 = load i32, ptr %t645, !tbaa !23
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/parse:Parser", ptr %t647, i32 0, i32 10
  %t650 = load i32, ptr %t649, !tbaa !23
  %t653 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t646, i32 %t650)
  store %"compiler/source:Span" %t653, ptr %l303
  br label %bb168
bb168:
  %t654 = load ptr, ptr %lp34
  store ptr %t654, ptr %l304, !tbaa !29
  %t655 = load i32, ptr %l29, !tbaa !23
  store i32 %t655, ptr %l305, !tbaa !23
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load i32, ptr %l28, !tbaa !23
  %t660 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t656, i32 %t657)
  store %"compiler/source:Span" %t660, ptr %l308
  br label %bb169
bb169:
  store { i64, [4 x i64] } zeroinitializer, ptr %t661
  %t662 = getelementptr { i64, [4 x i64] }, ptr %t661, i32 0, i32 0
  store i64 5, ptr %t662
  %t663 = load %"compiler/source:Span", ptr %l303
  %t664 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } undef, %"compiler/source:Span" %t663, 0
  %t665 = load ptr, ptr %l304, !tbaa !29
  %t666 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t664, ptr %t665, 1
  %t667 = load i32, ptr %l305, !tbaa !23
  %t668 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t666, i32 %t667, 2
  %t669 = load %"compiler/source:Span", ptr %l308
  %t670 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t668, %"compiler/source:Span" %t669, 3
  %t671 = getelementptr { i64, [4 x i64] }, ptr %t661, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t670, ptr %t671
  %t672 = load { i64, [4 x i64] }, ptr %t661
  %t674 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t672, ptr %t674
  %t675 = load ptr, ptr %l297, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t675, ptr %t674)
  br label %bb170
bb170:
  br label %bb173
bb171:
  %t677 = load ptr, ptr %l312, !tbaa !29
  %t678 = load ptr, ptr %l315, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t677, ptr %t678)
  br label %bb172
bb172:
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t682 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t679, i32 59)
  store i1 %t682, ptr %l318
  br label %bb175
bb175:
  %t683 = load i1, ptr %l318, !tbaa !21
  br i1 %t683, label %bb176, label %bb177
bb176:
  br label %bb203
bb177:
  br label %bb178
bb178:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t687 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t684, i32 8)
  store i1 %t687, ptr %l321
  br label %bb179
bb179:
  %t688 = load i1, ptr %l321, !tbaa !21
  %t689 = xor i1 %t688, true
  br i1 %t689, label %bb180, label %bb181
bb180:
  br label %bb204
bb181:
  br label %bb182
bb182:
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t693 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t691, i64 1)
  store i32 %t693, ptr %l324
  br label %bb183
bb183:
  %t694 = load i32, ptr %l324, !range !{i32 0, i32 98}
  store i32 %t694, ptr %l35
  %t695 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t697 = trunc i64 96 to i32
  %t698 = icmp eq i32 %t695, %t697
  br i1 %t698, label %bb184, label %bb185
bb184:
  store i1 true, ptr %l327, !tbaa !21
  br label %bb186
bb185:
  %t700 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t702 = trunc i64 63 to i32
  %t703 = icmp eq i32 %t700, %t702
  store i1 %t703, ptr %l327, !tbaa !21
  br label %bb186
bb186:
  %t705 = load i1, ptr %l327, !tbaa !21
  br i1 %t705, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l330, !tbaa !21
  br label %bb189
bb188:
  %t706 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t708 = trunc i64 9 to i32
  %t709 = icmp eq i32 %t706, %t708
  store i1 %t709, ptr %l330, !tbaa !21
  br label %bb189
bb189:
  %t711 = load i1, ptr %l330, !tbaa !21
  br i1 %t711, label %bb190, label %bb191
bb190:
  store i1 true, ptr %l333, !tbaa !21
  br label %bb192
bb191:
  %t712 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t714 = trunc i64 97 to i32
  %t715 = icmp eq i32 %t712, %t714
  store i1 %t715, ptr %l333, !tbaa !21
  br label %bb192
bb192:
  %t717 = load i1, ptr %l333, !tbaa !21
  br i1 %t717, label %bb193, label %bb194
bb193:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb195
bb194:
  %t718 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t720 = trunc i64 32 to i32
  %t721 = icmp eq i32 %t718, %t720
  store i1 %t721, ptr %l336, !tbaa !21
  br label %bb195
bb195:
  %t723 = load i1, ptr %l336, !tbaa !21
  br i1 %t723, label %bb196, label %bb197
bb196:
  store i1 true, ptr %l339, !tbaa !21
  br label %bb198
bb197:
  %t724 = load i32, ptr %l35, !range !{i32 0, i32 98}
  %t726 = trunc i64 0 to i32
  %t727 = icmp eq i32 %t724, %t726
  store i1 %t727, ptr %l339, !tbaa !21
  br label %bb198
bb198:
  %t729 = load i1, ptr %l339, !tbaa !21
  br i1 %t729, label %bb199, label %bb200
bb199:
  br label %bb204
bb200:
  br label %bb201
bb201:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t732 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t730)
  store i32 %t732, ptr %l343
  br label %bb202
bb202:
  br label %bb203
bb203:
  br label %bb122
bb204:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t735 = getelementptr %"compiler/parse:Parser", ptr %t733, i32 0, i32 34
  %t736 = load i64, ptr %l25, !tbaa !24
  %t739 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %t735, i64 %t736)
  store { i64, ptr } %t739, ptr %l347
  br label %bb205
bb205:
  %t740 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t740, ptr %lp36
  %t741 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t742 = load ptr, ptr %lp36
  store { i64, ptr } %t741, ptr %t742, !tbaa !27
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/parse:Parser", ptr %t743, i32 0, i32 32
  %t746 = load i64, ptr %l26, !tbaa !24
  %t749 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t745, i64 %t746)
  store { i64, ptr } %t749, ptr %l351
  br label %bb206
bb206:
  %t750 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t750, ptr %lp37
  %t751 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t752 = load ptr, ptr %lp37
  store { i64, ptr } %t751, ptr %t752, !tbaa !27
  %t753 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t753, ptr %lp38
  %t754 = load ptr, ptr %lp38
  store ptr null, ptr %t754, !tbaa !29
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t758 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t755, i32 9)
  store i1 %t758, ptr %l354
  br label %bb207
bb207:
  %t759 = load i1, ptr %l354, !tbaa !21
  br i1 %t759, label %bb208, label %bb209
bb208:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t762 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t760)
  %t763 = extractvalue { i32, ptr } %t762, 1
  %t764 = extractvalue { i32, ptr } %t762, 0
  store i32 %t764, ptr %l358
  %t765 = icmp ne i32 %t764, 0
  br i1 %t765, label %bb211, label %ok.766, !prof !99
ok.766:
  store ptr %t763, ptr %l357
  br label %bb210
bb209:
  br label %bb213
bb210:
  %t767 = load ptr, ptr %l357, !tbaa !29
  store ptr %t767, ptr %l355, !tbaa !29
  br label %bb212
bb211:
  %t768 = load i32, ptr %l358, !tbaa !23
  %t769 = lshr i32 %t768, 16
  %t770 = and i32 %t768, 65535
  %t771 = icmp eq i32 %t769, 1
  %t772 = select i1 %t771, i32 1, i32 0
  %t773 = icmp eq i32 %t768, 0
  %t774 = shl i32 %t772, 16
  %t775 = or i32 %t774, %t770
  %t776 = select i1 %t773, i32 0, i32 %t775
  %t778 = insertvalue { i32, ptr } zeroinitializer, i32 %t776, 0
  store { i32, ptr } %t778, ptr %rv
  br label %ret
bb212:
  %t779 = load ptr, ptr %l355, !tbaa !29
  %t781 = load ptr, ptr %lp38
  store ptr %t779, ptr %t781, !tbaa !29
  br label %bb213
bb213:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t786 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %v1, ptr %t782, i1 %a1)
  %t787 = extractvalue { i32, { { i64, ptr }, ptr } } %t786, 1
  %t788 = extractvalue { i32, { { i64, ptr }, ptr } } %t786, 0
  store i32 %t788, ptr %l365
  %t789 = icmp ne i32 %t788, 0
  br i1 %t789, label %bb215, label %ok.790, !prof !99
ok.790:
  store { { i64, ptr }, ptr } %t787, ptr %l364
  br label %bb214
bb214:
  %t791 = load { { i64, ptr }, ptr }, ptr %l364
  store { { i64, ptr }, ptr } %t791, ptr %l361
  br label %bb216
bb215:
  %t792 = load i32, ptr %l365, !tbaa !23
  %t793 = lshr i32 %t792, 16
  %t794 = and i32 %t792, 65535
  %t795 = icmp eq i32 %t793, 1
  %t796 = select i1 %t795, i32 1, i32 0
  %t797 = icmp eq i32 %t792, 0
  %t798 = shl i32 %t796, 16
  %t799 = or i32 %t798, %t794
  %t800 = select i1 %t797, i32 0, i32 %t799
  %t802 = insertvalue { i32, ptr } zeroinitializer, i32 %t800, 0
  store { i32, ptr } %t802, ptr %rv
  br label %ret
bb216:
  %t803 = load { { i64, ptr }, ptr }, ptr %l361
  store { { i64, ptr }, ptr } %t803, ptr %l39
  %t804 = getelementptr { { i64, ptr }, ptr }, ptr %l39, i32 0, i32 0
  %t805 = load { i64, ptr }, ptr %t804, !tbaa !27
  store { i64, ptr } %t805, ptr %l40, !tbaa !27
  %t807 = getelementptr { { i64, ptr }, ptr }, ptr %l39, i32 0, i32 1
  %t808 = load ptr, ptr %t807, !tbaa !29
  store ptr %t808, ptr %l41, !tbaa !29
  %t810 = load ptr, ptr %lp23
  %t811 = load ptr, ptr %t810, !tbaa !29
  store ptr %t811, ptr %l369, !tbaa !29
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l24, !tbaa !23
  %t816 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t812, i32 %t813)
  store %"compiler/source:Span" %t816, ptr %l372
  br label %bb217
bb217:
  %t817 = load ptr, ptr %lp36
  %t818 = load { i64, ptr }, ptr %t817, !tbaa !27
  %t819 = load ptr, ptr %lp37
  %t820 = load { i64, ptr }, ptr %t819, !tbaa !27
  %t821 = load ptr, ptr %lp38
  %t822 = load ptr, ptr %t821, !tbaa !29
  %t823 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t824 = load ptr, ptr %l41, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l372
  %t831 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t825, { i64, ptr } %t818, { i64, ptr } %t820, ptr %t822, { i64, ptr } %t823, ptr %t824)
  store %"compiler/ast:Case" %t831, ptr %l378
  br label %bb218
bb218:
  %t832 = load %"compiler/ast:Case", ptr %l378
  %t833 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"compiler/ast:Case" %t832, ptr %t833
  %t834 = load ptr, ptr %l369, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v1, ptr %v1, ptr %t834, ptr %t833)
  br label %bb219
bb219:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t839 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t836, i32 8)
  store i1 %t839, ptr %l382
  br label %bb220
bb220:
  %t840 = load i1, ptr %l382, !tbaa !21
  br i1 %t840, label %bb221, label %bb222
bb221:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t843 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t841)
  store i32 %t843, ptr %l384
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  br label %bb225
bb225:
  br label %bb106
bb226:
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t847 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t844, i32 97)
  %t848 = extractvalue { i32, i32 } %t847, 1
  %t849 = extractvalue { i32, i32 } %t847, 0
  store i32 %t849, ptr %l389
  %t850 = icmp ne i32 %t849, 0
  br i1 %t850, label %bb228, label %ok.851, !prof !99
ok.851:
  store i32 %t848, ptr %l388
  br label %bb227
bb227:
  %t852 = load i32, ptr %l388, !tbaa !23
  store i32 %t852, ptr %l385, !tbaa !23
  br label %bb229
bb228:
  %t853 = load i32, ptr %l389, !tbaa !23
  %t854 = lshr i32 %t853, 16
  %t855 = and i32 %t853, 65535
  %t856 = icmp eq i32 %t854, 1
  %t857 = select i1 %t856, i32 1, i32 0
  %t858 = icmp eq i32 %t853, 0
  %t859 = shl i32 %t857, 16
  %t860 = or i32 %t859, %t855
  %t861 = select i1 %t858, i32 0, i32 %t860
  %t863 = insertvalue { i32, ptr } zeroinitializer, i32 %t861, 0
  store { i32, ptr } %t863, ptr %rv
  br label %ret
bb229:
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t865 = load i64, ptr %l21, !tbaa !24
  %t868 = getelementptr %"compiler/parse:Parser", ptr %t864, i32 0, i32 17
  store i64 %t865, ptr %t868, !tbaa !24
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t870 = load i1, ptr %l22, !tbaa !21
  %t873 = getelementptr %"compiler/parse:Parser", ptr %t869, i32 0, i32 18
  store i1 %t870, ptr %t873, !tbaa !21
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = load i32, ptr %l2, !tbaa !23
  %t878 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t874, i32 %t875)
  store %"compiler/source:Span" %t878, ptr %l397
  br label %bb230
bb230:
  %t879 = load ptr, ptr %lp20
  %t880 = load ptr, ptr %t879, !tbaa !29
  store ptr %t880, ptr %l398, !tbaa !29
  %t881 = load i1, ptr %l3, !tbaa !21
  store i1 %t881, ptr %l399, !tbaa !21
  %t882 = load ptr, ptr %lp23
  %t883 = load ptr, ptr %t882, !tbaa !29
  %t885 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v1, ptr %v1, ptr %t883)
  store { i64, ptr } %t885, ptr %l401
  br label %bb231
bb231:
  %t886 = load %"compiler/source:Span", ptr %l397
  %t887 = load ptr, ptr %l398, !tbaa !29
  %t888 = load i1, ptr %l399, !tbaa !21
  %t889 = load { i64, ptr }, ptr %l401, !tbaa !27
  %t890 = call %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t886, ptr %t887, i1 %t888, { i64, ptr } %t889)
  store %"compiler/ast:Match" %t890, ptr %l402
  br label %bb232
bb232:
  %t891 = load %"compiler/ast:Match", ptr %l402
  %t892 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:Match" %t891, ptr %t892
  %t894 = insertvalue { i32, ptr } zeroinitializer, ptr %t892, 1
  store { i32, ptr } %t894, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t1, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !range !{i32 0, i32 98}
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/source:Source", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t25 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = sub i32 %t26, %t28
  %t33 = sext i32 %t31 to i64
  %t37 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t20, i64 %t24, i64 %t33)
  store i32 %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load i32, ptr %l18, !range !{i32 0, i32 98}
  store i32 %t38, ptr %l2
  %t39 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t50 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t57 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t59 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t57)
  store i1 %t59, ptr %l29
  br label %bb15
bb15:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t61, i64 2)
  store i32 %t63, ptr %l32
  br label %bb18
bb18:
  %t64 = load i32, ptr %l32, !range !{i32 0, i32 98}
  %t66 = trunc i64 92 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l30, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2emessageHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l6
  br label %bb5
bb5:
  %t9 = load i32, ptr %l6, !range !{i32 0, i32 98}
  store i32 %t9, ptr %l1
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t12 = trunc i64 5 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t17 = trunc i64 89 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  %t20 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t27 = trunc i64 92 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t32 = trunc i64 2 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb32
bb17:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t37 = trunc i64 3 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t42 = trunc i64 4 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  %t45 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t50 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2c371f21e588b068_13da37aea4ea5bc)
  unreachable
bb32:
  %t55 = load i1, ptr %l7, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca %"compiler/token:Token"
  %l13 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t6 = trunc i64 1 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t11, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t13, ptr %l8
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb5, label %ok.15, !prof !99
ok.15:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s1)
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t27)
  store %"compiler/token:Token" %t29, ptr %l11
  br label %bb8
bb8:
  %t30 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t30, ptr %l1
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l13
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l15, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/token:Token", ptr %l1
  %t42 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t38, %"compiler/token:Token" %t39)
  store { i64, ptr } %t42, ptr %l18
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t45 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  store i32 %t45, ptr %l19
  br label %bb11
bb11:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = insertvalue { i32, i32 } zeroinitializer, i32 %t46, 1
  store { i32, i32 } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 98}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t9 = trunc i64 8 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t30 = trunc i64 0 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/scan:Tokens", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/token:Token", ptr %t60, i64 %t57
  %t62 = load %"compiler/token:Token", ptr %t61
  %t65 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t49, %"compiler/token:Token" %t62)
  store { i64, ptr } %t65, ptr %l22
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t66)
  store { i64, ptr } %t67, ptr %l23
  br label %bb9
bb9:
  %t68 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %l59 = alloca %"compiler/parse:NameList"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t36 = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l17, !tbaa !24
  store %"compiler/source:Span" zeroinitializer, ptr %l18
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb5:
  %t24 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t24, ptr %l20
  br label %bb7
bb6:
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t28, ptr %l18
  br label %bb6
bb8:
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = icmp sle i64 %t29, 1152921504606846975
  br i1 %t30, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb10:
  %t32 = load i64, ptr %l17, !tbaa !24
  %t33 = mul i64 %t32, 8
  %t34 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t33)
  %t35 = load %"compiler/source:Span", ptr %l18
  store i64 0, ptr %t36
  br label %fill.37
fill.37:
  %t40 = load i64, ptr %t36
  %t41 = icmp slt i64 %t40, %t32
  br i1 %t41, label %fillb.38, label %filld.39
fillb.38:
  %t42 = getelementptr %"compiler/source:Span", ptr %t34, i64 %t40
  store %"compiler/source:Span" %t35, ptr %t42
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %t36
  br label %fill.37
filld.39:
  %t44 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t34, 1
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t45, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb12:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  br label %bb32
bb14:
  br label %bb15
bb15:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t65, ptr %l32, !tbaa !27
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  store ptr %t71, ptr %l8, !tbaa !29
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb16, label %bb17
bb16:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 30}
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t81 = load i1, ptr %l36, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t82 = load ptr, ptr %l8, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32 }, ptr %t84, i32 0, i32 0
  %t86 = load %"compiler/source:Span", ptr %t85
  store %"compiler/source:Span" %t86, ptr %l9
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32 }, ptr %t90, i32 0, i32 1
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l10, !tbaa !23
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t94 = load ptr, ptr %lp2
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l43, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i32, ptr %l10, !tbaa !23
  %t100 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t96
  store i32 %t97, ptr %t102, !tbaa !33
  %t103 = load ptr, ptr %lp3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l46, !tbaa !27
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load %"compiler/source:Span", ptr %l9
  %t109 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/source:Span", ptr %t110, i64 %t105
  store %"compiler/source:Span" %t106, ptr %t111
  br label %bb30
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a0, ptr %l49, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 62)
  store { i64, ptr } %t114, ptr %l51
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l49, !tbaa !29
  %t124 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t122, { i64, ptr } %t121)
  store i32 %t124, ptr %l53
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb27, label %ok.126, !prof !99
ok.126:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t127 = load i32, ptr %l53, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s4)
  %t137 = insertvalue { i32, ptr } zeroinitializer, i32 %t135, 0
  store { i32, ptr } %t137, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_afe07cd3f11f5e9a_d335478c7d935166)
  unreachable
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l5, !tbaa !24
  br label %bb12
bb32:
  %t142 = load ptr, ptr %lp2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t144 = load ptr, ptr %lp3
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t148 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t143, { i64, ptr } %t145)
  store %"compiler/parse:NameList" %t148, ptr %l59
  br label %bb33
bb33:
  %t149 = load %"compiler/parse:NameList", ptr %l59
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/parse:NameList" %t149, ptr %t150
  %t152 = insertvalue { i32, ptr } zeroinitializer, ptr %t150, 1
  store { i32, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 81)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l5
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 40
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 6
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t22, i64 %t28)
  br label %bb4
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i32
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l75 = alloca %"compiler/source:Span"
  %l80 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i32
  %l112 = alloca %"compiler/source:Span"
  %l117 = alloca %"compiler/ast:Param"
  %rv = alloca { i32, ptr }
  %t163 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrsHere(ptr %v0, ptr %v1, ptr %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l18
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l17
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t8, ptr %l15, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l18, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp2
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t22 = load ptr, ptr %lp2
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  %t23 = load i1, ptr %l1, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 49
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %lp2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrRefused(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t33)
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = icmp sle i64 0, 1152921504606846975
  br i1 %t38, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f0055d05bbcc9e33_2e682d4d4b5dbed7)
  unreachable
bb12:
  %t40 = mul i64 0, 8
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t44 = load ptr, ptr %lp2
  store { i64, ptr } %t42, ptr %t44, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f0055d05bbcc9e33_2e682d4d4b5dbed7)
  unreachable
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l30
  br label %bb15
bb15:
  %t48 = load i32, ptr %l30, !tbaa !23
  store i32 %t48, ptr %l3, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l34
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb17, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l33
  br label %bb16
bb16:
  %t56 = load i32, ptr %l33, !tbaa !23
  store i32 %t56, ptr %l31, !tbaa !23
  br label %bb18
bb17:
  %t57 = load i32, ptr %l34, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  %t67 = insertvalue { i32, ptr } zeroinitializer, i32 %t65, 0
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb18:
  %t68 = load i32, ptr %l31, !tbaa !23
  store i32 %t68, ptr %l4, !tbaa !23
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t69, ptr %lp5
  %t70 = load ptr, ptr %lp5
  store ptr null, ptr %t70, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t71)
  store i1 %t73, ptr %l37
  br label %bb19
bb19:
  %t74 = load i1, ptr %l37, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l39
  br label %bb22
bb21:
  %t78 = load i1, ptr %l1, !tbaa !21
  br i1 %t78, label %bb40, label %bb41
bb22:
  %t80 = load i32, ptr %l39, !tbaa !23
  store i32 %t80, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb28
bb25:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l46, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb27
bb27:
  %t107 = load i64, ptr %l46, !tbaa !24
  store i64 %t107, ptr %l43, !tbaa !24
  br label %bb28
bb28:
  %t108 = load i64, ptr %l43, !tbaa !24
  store i64 %t108, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t109 = load i64, ptr %l11, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l12, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t127)
  store i32 %t129, ptr %l65
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb29
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t134)
  %t137 = extractvalue { i32, ptr } %t136, 1
  %t138 = extractvalue { i32, ptr } %t136, 0
  store i32 %t138, ptr %l71
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb37, label %ok.140, !prof !99
ok.140:
  store ptr %t137, ptr %l70
  br label %bb36
bb36:
  %t141 = load ptr, ptr %l70, !tbaa !29
  store ptr %t141, ptr %l68, !tbaa !29
  br label %bb38
bb37:
  %t142 = load i32, ptr %l71, !tbaa !23
  %t143 = lshr i32 %t142, 16
  %t144 = and i32 %t142, 65535
  %t145 = icmp eq i32 %t143, 1
  %t146 = select i1 %t145, i32 1, i32 0
  %t147 = icmp eq i32 %t142, 0
  %t148 = shl i32 %t146, 16
  %t149 = or i32 %t148, %t144
  %t150 = select i1 %t147, i32 0, i32 %t149
  %t152 = insertvalue { i32, ptr } zeroinitializer, i32 %t150, 0
  store { i32, ptr } %t152, ptr %rv
  br label %ret
bb38:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t153, ptr %lp13
  %t154 = load ptr, ptr %l68, !tbaa !29
  %t155 = load ptr, ptr %lp13
  store ptr %t154, ptr %t155, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l6, !tbaa !23
  %t160 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t156, i32 %t157)
  store %"compiler/source:Span" %t160, ptr %l75
  br label %bb39
bb39:
  %t161 = load ptr, ptr %lp13
  %t162 = load ptr, ptr %t161, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 0
  store i64 7, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l75
  %t166 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t165, 0
  %t168 = insertvalue { %"compiler/source:Span", ptr } %t166, ptr %t162, 1
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t168, ptr %t169
  %t170 = load { i64, [5 x i64] }, ptr %t163
  %t172 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t170, ptr %t172
  %t174 = load ptr, ptr %lp5
  store ptr %t172, ptr %t174, !tbaa !29
  br label %bb58
bb40:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t178 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t175, i32 59)
  store i1 %t178, ptr %l83
  br label %bb42
bb41:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb51
bb42:
  %t179 = load i1, ptr %l83, !tbaa !21
  br i1 %t179, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb46
bb44:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t180, i32 93)
  store i1 %t183, ptr %l87
  br label %bb45
bb45:
  %t184 = load i1, ptr %l87, !tbaa !21
  store i1 %t184, ptr %l84, !tbaa !21
  br label %bb46
bb46:
  %t185 = load i1, ptr %l84, !tbaa !21
  br i1 %t185, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t189 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t186, i32 8)
  store i1 %t189, ptr %l91
  br label %bb49
bb49:
  %t190 = load i1, ptr %l91, !tbaa !21
  store i1 %t190, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t191 = load i1, ptr %l88, !tbaa !21
  store i1 %t191, ptr %l80, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l80, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb52, label %bb53
bb52:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t195)
  %t198 = extractvalue { i32, ptr } %t197, 1
  %t199 = extractvalue { i32, ptr } %t197, 0
  store i32 %t199, ptr %l96
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb55, label %ok.201, !prof !99
ok.201:
  store ptr %t198, ptr %l95
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t202 = load ptr, ptr %l95, !tbaa !29
  store ptr %t202, ptr %l93, !tbaa !29
  br label %bb56
bb55:
  %t203 = load i32, ptr %l96, !tbaa !23
  %t204 = lshr i32 %t203, 16
  %t205 = and i32 %t203, 65535
  %t206 = icmp eq i32 %t204, 1
  %t207 = select i1 %t206, i32 1, i32 0
  %t208 = icmp eq i32 %t203, 0
  %t209 = shl i32 %t207, 16
  %t210 = or i32 %t209, %t205
  %t211 = select i1 %t208, i32 0, i32 %t210
  %t213 = insertvalue { i32, ptr } zeroinitializer, i32 %t211, 0
  store { i32, ptr } %t213, ptr %rv
  br label %ret
bb56:
  %t214 = load ptr, ptr %l93, !tbaa !29
  %t216 = load ptr, ptr %lp5
  store ptr %t214, ptr %t216, !tbaa !29
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t217, ptr %lp14
  %t218 = load ptr, ptr %lp14
  store ptr null, ptr %t218, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t222 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t219, i32 62)
  store i1 %t222, ptr %l101
  br label %bb59
bb59:
  %t223 = load i1, ptr %l101, !tbaa !21
  br i1 %t223, label %bb60, label %bb61
bb60:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t224)
  %t227 = extractvalue { i32, ptr } %t226, 1
  %t228 = extractvalue { i32, ptr } %t226, 0
  store i32 %t228, ptr %l105
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb63, label %ok.230, !prof !99
ok.230:
  store ptr %t227, ptr %l104
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t231 = load ptr, ptr %l104, !tbaa !29
  store ptr %t231, ptr %l102, !tbaa !29
  br label %bb64
bb63:
  %t232 = load i32, ptr %l105, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  %t242 = insertvalue { i32, ptr } zeroinitializer, i32 %t240, 0
  store { i32, ptr } %t242, ptr %rv
  br label %ret
bb64:
  %t243 = load ptr, ptr %l102, !tbaa !29
  %t245 = load ptr, ptr %lp14
  store ptr %t243, ptr %t245, !tbaa !29
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %lp2
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclareAttrs(ptr %v0, ptr %v1, ptr %t246, { i64, ptr } %t248)
  br label %bb66
bb66:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i32, ptr %l3, !tbaa !23
  %t255 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t251, i32 %t252)
  store %"compiler/source:Span" %t255, ptr %l112
  br label %bb67
bb67:
  %t256 = load i32, ptr %l4, !tbaa !23
  %t257 = load ptr, ptr %lp5
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t259 = load ptr, ptr %lp14
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load ptr, ptr %lp2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = load %"compiler/source:Span", ptr %l112
  %t268 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t263, i32 %t256, ptr %t258, ptr %t260, { i64, ptr } %t262)
  store %"compiler/ast:Param" %t268, ptr %l117
  br label %bb68
bb68:
  %t269 = load %"compiler/ast:Param", ptr %l117
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:Param" %t269, ptr %t270
  %t272 = insertvalue { i32, ptr } zeroinitializer, ptr %t270, 1
  store { i32, ptr } %t272, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/ast:Path"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 35
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 35
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t14)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store i32 %t17, ptr %l13
  br label %bb3
bb3:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  br label %bb5
bb4:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb5:
  %t33 = load ptr, ptr %l10, !tbaa !29
  %t34 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t33, i32 %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t35, i32 60)
  store i1 %t38, ptr %l18
  br label %bb8
bb8:
  %t39 = load i1, ptr %l18, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l21
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 35
  store ptr %t47, ptr %l23, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54, !prof !99
ok.54:
  store i32 %t51, ptr %l26
  br label %bb13
bb13:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l24, !tbaa !23
  br label %bb15
bb14:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb15:
  %t67 = load ptr, ptr %l23, !tbaa !29
  %t68 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t67, i32 %t68)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb7
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t69, i32 0, i32 35
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l32
  br label %bb19
bb19:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t76, ptr %lp3
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t78 = load ptr, ptr %lp3
  store { i64, ptr } %t77, ptr %t78, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t79, i32 %t80)
  store %"compiler/source:Span" %t83, ptr %l35
  br label %bb20
bb20:
  %t84 = load ptr, ptr %lp3
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t86 = load %"compiler/source:Span", ptr %l35
  %t88 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t86, { i64, ptr } %t85)
  store %"compiler/ast:Path" %t88, ptr %l37
  br label %bb21
bb21:
  %t89 = load %"compiler/ast:Path", ptr %l37
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:Path" %t89, ptr %t90
  %t92 = insertvalue { i32, ptr } zeroinitializer, ptr %t90, 1
  store { i32, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 98}
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 98}
  store i32 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/scan:Tokens", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t23, i64 %t27)
  store i64 %t30, ptr %l13
  br label %bb4
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i64 %t31
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 98}
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 %t14, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %v1, ptr %t17)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l8
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23, !prof !99
ok.23:
  store ptr %t20, ptr %l7
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l5, !tbaa !29
  br label %bb7
bb5:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  store i32 %t33, ptr %l9, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t34)
  br label %bb6
bb6:
  %t36 = load i32, ptr %l9, !tbaa !23
  %t37 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t37, ptr %rv
  br label %ret
bb7:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t38, ptr %lp1
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %lp1
  store ptr %t39, ptr %t40, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %lp1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t46 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t41, ptr %t43)
  %t47 = extractvalue { i32, ptr } %t46, 1
  %t48 = extractvalue { i32, ptr } %t46, 0
  store i32 %t48, ptr %l15
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb9, label %ok.50, !prof !99
ok.50:
  store ptr %t47, ptr %l14
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l14, !tbaa !29
  store ptr %t51, ptr %l11, !tbaa !29
  br label %bb11
bb9:
  %t52 = load i32, ptr %l15, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  store i32 %t60, ptr %l16, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t61)
  br label %bb10
bb10:
  %t63 = load i32, ptr %l16, !tbaa !23
  %t64 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t64, ptr %rv
  br label %ret
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t65)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l11, !tbaa !29
  %t68 = insertvalue { i32, ptr } zeroinitializer, ptr %t67, 1
  store { i32, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l42 = alloca %"compiler/source:Span"
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l102 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l108 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca %"compiler/token:Token"
  %l113 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l126 = alloca %"compiler/source:Span"
  %l133 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l140 = alloca %"compiler/source:Span"
  %l152 = alloca i32
  %l154 = alloca i32
  %l157 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca i32
  %l173 = alloca %"compiler/source:Span"
  %l186 = alloca i1
  %l188 = alloca i1
  %l190 = alloca i32
  %l195 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca i32
  %l201 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca i32
  %s10 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t84 = alloca { i64, [4 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  %t234 = alloca { i64, [4 x i64] }, align 8
  %t307 = alloca { i64, [4 x i64] }, align 8
  %t352 = alloca { i64, [4 x i64] }, align 8
  %t394 = alloca { i64, [4 x i64] }, align 8
  %t442 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l18
  br label %bb3
bb3:
  %t12 = load i32, ptr %l18, !range !{i32 0, i32 98}
  store i32 %t12, ptr %l4
  %t13 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t15 = trunc i64 94 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t22 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %v1, ptr %v1, ptr %t18, ptr %t19)
  %t23 = extractvalue { i32, ptr } %t22, 1
  %t24 = extractvalue { i32, ptr } %t22, 0
  store i32 %t24, ptr %l25
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb8, label %ok.26, !prof !99
ok.26:
  store ptr %t23, ptr %l24
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l24, !tbaa !29
  store ptr %t27, ptr %l21, !tbaa !29
  br label %bb9
bb8:
  %t28 = load i32, ptr %l25, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l21, !tbaa !29
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb132
bb10:
  %t40 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t42 = trunc i64 60 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb77
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l30
  br label %bb14
bb14:
  %t48 = load i1, ptr %l30, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = insertvalue { i32, ptr } zeroinitializer, ptr %t51, 1
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l34
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t57)
  %t60 = extractvalue { i32, i32 } %t59, 1
  %t61 = extractvalue { i32, i32 } %t59, 0
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb20, label %ok.63, !prof !99
ok.63:
  store i32 %t60, ptr %l37
  br label %bb19
bb19:
  %t64 = load i32, ptr %l37, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  br label %bb21
bb20:
  %t65 = load i32, ptr %l38, !tbaa !23
  %t66 = lshr i32 %t65, 16
  %t67 = and i32 %t65, 65535
  %t68 = icmp eq i32 %t66, 1
  %t69 = select i1 %t68, i32 1, i32 0
  %t70 = icmp eq i32 %t65, 0
  %t71 = shl i32 %t69, 16
  %t72 = or i32 %t71, %t67
  %t73 = select i1 %t70, i32 0, i32 %t72
  %t75 = insertvalue { i32, ptr } zeroinitializer, i32 %t73, 0
  store { i32, ptr } %t75, ptr %rv
  br label %ret
bb21:
  %t76 = load i32, ptr %l35, !tbaa !23
  store i32 %t76, ptr %l5, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l42
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 0
  store i64 14, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l42
  %t87 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t86, 0
  %t89 = insertvalue { %"compiler/source:Span", ptr, i32 } %t87, ptr %t82, 1
  %t91 = insertvalue { %"compiler/source:Span", ptr, i32 } %t89, i32 %t83, 2
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t91, ptr %t92
  %t93 = load { i64, [4 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t93, ptr %t95
  store ptr %t95, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t97, i32 81)
  store i1 %t100, ptr %l49
  br label %bb23
bb23:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t106 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l53
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb26:
  %t107 = load i1, ptr %l53, !tbaa !21
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t109)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l57
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb31, label %ok.115, !prof !99
ok.115:
  store { i64, ptr } %t112, ptr %l56
  br label %bb30
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t119 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t116, i32 81)
  store i1 %t119, ptr %l75
  br label %bb37
bb30:
  %t120 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t120, ptr %l54, !tbaa !27
  br label %bb32
bb31:
  %t121 = load i32, ptr %l57, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb32:
  %t132 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t132, ptr %l6, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l3, !tbaa !23
  %t137 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t133, i32 %t134)
  store %"compiler/source:Span" %t137, ptr %l61
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 13, ptr %t141
  %t142 = load %"compiler/source:Span", ptr %l61
  %t143 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t142, 0
  %t145 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t143, ptr %t138, 1
  %t147 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t145, { i64, ptr } %t139, 2
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t147, ptr %t148
  %t149 = load { i64, [4 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l3, !tbaa !23
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t159 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v1, ptr %v1, ptr %t153, i32 %t154, ptr %t155)
  %t160 = extractvalue { i32, ptr } %t159, 1
  %t161 = extractvalue { i32, ptr } %t159, 0
  store i32 %t161, ptr %l71
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb35, label %ok.163, !prof !99
ok.163:
  store ptr %t160, ptr %l70
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l70, !tbaa !29
  store ptr %t164, ptr %l66, !tbaa !29
  br label %bb36
bb35:
  %t165 = load i32, ptr %l71, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t173, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb36:
  %t176 = load ptr, ptr %l66, !tbaa !29
  store ptr %t176, ptr %l2, !tbaa !29
  br label %bb76
bb37:
  %t177 = load i1, ptr %l75, !tbaa !21
  br i1 %t177, label %bb38, label %bb39
bb38:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = call i1 @compiler_2fparse_2eisPath(ptr %v1, ptr %t178)
  store i1 %t180, ptr %l78
  br label %bb40
bb39:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb41
bb40:
  %t181 = load i1, ptr %l78, !tbaa !21
  store i1 %t181, ptr %l76, !tbaa !21
  br label %bb41
bb41:
  %t182 = load i1, ptr %l76, !tbaa !21
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 3
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/parse:Oracle", ptr %t186, i32 0, i32 3
  store ptr %t188, ptr %l82, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  store ptr %t192, ptr %l84, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t193)
  store %"compiler/source:Span" %t195, ptr %l86
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb47
bb44:
  %t196 = load ptr, ptr %l84, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l86
  %t198 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197)
  store { i64, ptr } %t198, ptr %l87
  br label %bb45
bb45:
  %t199 = load ptr, ptr %l82, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t201 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t199, { i64, ptr } %t200)
  store i1 %t201, ptr %l88
  br label %bb46
bb46:
  %t202 = load i1, ptr %l88, !tbaa !21
  store i1 %t202, ptr %l79, !tbaa !21
  br label %bb47
bb47:
  %t203 = load i1, ptr %l79, !tbaa !21
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t204)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l92
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb51, label %ok.210, !prof !99
ok.210:
  store { i64, ptr } %t207, ptr %l91
  br label %bb50
bb49:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %t211, i64 0)
  store i1 %t213, ptr %l102
  br label %bb54
bb50:
  %t214 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t214, ptr %l89, !tbaa !27
  br label %bb52
bb51:
  %t215 = load i32, ptr %l92, !tbaa !23
  %t216 = lshr i32 %t215, 16
  %t217 = and i32 %t215, 65535
  %t218 = icmp eq i32 %t216, 1
  %t219 = select i1 %t218, i32 1, i32 0
  %t220 = icmp eq i32 %t215, 0
  %t221 = shl i32 %t219, 16
  %t222 = or i32 %t221, %t217
  %t223 = select i1 %t220, i32 0, i32 %t222
  %t225 = insertvalue { i32, ptr } zeroinitializer, i32 %t223, 0
  store { i32, ptr } %t225, ptr %rv
  br label %ret
bb52:
  %t226 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t226, ptr %l7, !tbaa !27
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l3, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t227, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l96
  br label %bb53
bb53:
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 0
  store i64 13, ptr %t235
  %t236 = load %"compiler/source:Span", ptr %l96
  %t237 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t236, 0
  %t239 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t237, ptr %t232, 1
  %t241 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t239, { i64, ptr } %t233, 2
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t241, ptr %t242
  %t243 = load { i64, [4 x i64] }, ptr %t234
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t243, ptr %t245
  store ptr %t245, ptr %l2, !tbaa !29
  br label %bb75
bb54:
  %t247 = load i1, ptr %l102, !tbaa !21
  br i1 %t247, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb58
bb56:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t248, i64 0)
  store i1 %t250, ptr %l105
  br label %bb57
bb57:
  %t251 = load i1, ptr %l105, !tbaa !21
  store i1 %t251, ptr %l103, !tbaa !21
  br label %bb58
bb58:
  %t252 = load i1, ptr %l103, !tbaa !21
  br i1 %t252, label %bb59, label %bb60
bb59:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t253, i64 0)
  store i1 %t255, ptr %l107
  br label %bb61
bb60:
  br label %bb74
bb61:
  %t256 = load i1, ptr %l107, !tbaa !21
  br i1 %t256, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l108, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t258)
  store i32 %t260, ptr %l110
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t261, i64 0)
  store %"compiler/token:Token" %t263, ptr %l112
  br label %bb65
bb65:
  %t264 = getelementptr %"compiler/token:Token", ptr %l112, i32 0, i32 3
  %t265 = load i32, ptr %t264, !tbaa !23
  store i32 %t265, ptr %l113, !tbaa !23
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t266, i32 0, i32 2
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t270 = load i32, ptr %l5, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t269, i32 %t270)
  store { i64, ptr } %t273, ptr %l117
  br label %bb66
bb66:
  %t274 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t275 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %s10, { i64, ptr } %t274)
  store %"compiler/msgs:Msg" %t275, ptr %l118
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l108, !tbaa !29
  %t277 = load i32, ptr %l110, !tbaa !23
  %t278 = load i32, ptr %l113, !tbaa !23
  %t279 = load %"compiler/msgs:Msg", ptr %l118
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s10, ptr %t276, i32 %t277, i32 %t278, %"compiler/msgs:Msg" %t279)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb69:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t280)
  %t283 = extractvalue { i32, { i64, ptr } } %t282, 1
  %t284 = extractvalue { i32, { i64, ptr } } %t282, 0
  store i32 %t284, ptr %l122
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb71, label %ok.286, !prof !99
ok.286:
  store { i64, ptr } %t283, ptr %l121
  br label %bb70
bb70:
  %t287 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t287, ptr %l119, !tbaa !27
  br label %bb72
bb71:
  %t288 = load i32, ptr %l122, !tbaa !23
  %t289 = lshr i32 %t288, 16
  %t290 = and i32 %t288, 65535
  %t291 = icmp eq i32 %t289, 1
  %t292 = select i1 %t291, i32 1, i32 0
  %t293 = icmp eq i32 %t288, 0
  %t294 = shl i32 %t292, 16
  %t295 = or i32 %t294, %t290
  %t296 = select i1 %t293, i32 0, i32 %t295
  %t298 = insertvalue { i32, ptr } zeroinitializer, i32 %t296, 0
  store { i32, ptr } %t298, ptr %rv
  br label %ret
bb72:
  %t299 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t299, ptr %l8, !tbaa !27
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l3, !tbaa !23
  %t304 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t300, i32 %t301)
  store %"compiler/source:Span" %t304, ptr %l126
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 0
  store i64 13, ptr %t308
  %t309 = load %"compiler/source:Span", ptr %l126
  %t310 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t309, 0
  %t312 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t310, ptr %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [4 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t316, ptr %t318
  store ptr %t318, ptr %l2, !tbaa !29
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb132
bb77:
  %t320 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t322 = trunc i64 92 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb85
bb80:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v1, ptr %t325)
  %t328 = extractvalue { i32, { i64, ptr } } %t327, 1
  %t329 = extractvalue { i32, { i64, ptr } } %t327, 0
  store i32 %t329, ptr %l136
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb82, label %ok.331, !prof !99
ok.331:
  store { i64, ptr } %t328, ptr %l135
  br label %bb81
bb81:
  %t332 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t332, ptr %l133, !tbaa !27
  br label %bb83
bb82:
  %t333 = load i32, ptr %l136, !tbaa !23
  %t334 = lshr i32 %t333, 16
  %t335 = and i32 %t333, 65535
  %t336 = icmp eq i32 %t334, 1
  %t337 = select i1 %t336, i32 1, i32 0
  %t338 = icmp eq i32 %t333, 0
  %t339 = shl i32 %t337, 16
  %t340 = or i32 %t339, %t335
  %t341 = select i1 %t338, i32 0, i32 %t340
  %t343 = insertvalue { i32, ptr } zeroinitializer, i32 %t341, 0
  store { i32, ptr } %t343, ptr %rv
  br label %ret
bb83:
  %t344 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t344, ptr %l9, !tbaa !27
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l3, !tbaa !23
  %t349 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t345, i32 %t346)
  store %"compiler/source:Span" %t349, ptr %l140
  br label %bb84
bb84:
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 0
  store i64 12, ptr %t353
  %t354 = load %"compiler/source:Span", ptr %l140
  %t355 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t354, 0
  %t357 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t355, ptr %t350, 1
  %t359 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t357, { i64, ptr } %t351, 2
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t359, ptr %t360
  %t361 = load { i64, [4 x i64] }, ptr %t352
  %t363 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t361, ptr %t363
  store ptr %t363, ptr %l2, !tbaa !29
  br label %bb132
bb85:
  %t365 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t367 = trunc i64 76 to i32
  %t368 = icmp eq i32 %t365, %t367
  br i1 %t368, label %bb86, label %bb87
bb86:
  br label %bb92
bb87:
  %t370 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t372 = trunc i64 77 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb88, label %bb89
bb88:
  br label %bb92
bb89:
  %t375 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t377 = trunc i64 80 to i32
  %t378 = icmp eq i32 %t375, %t377
  br i1 %t378, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t380)
  store i32 %t382, ptr %l152
  br label %bb93
bb93:
  %t383 = load i32, ptr %l152, !range !{i32 0, i32 98}
  store i32 %t383, ptr %l10
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t384)
  store i32 %t386, ptr %l154
  br label %bb94
bb94:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l3, !tbaa !23
  %t391 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t387, i32 %t388)
  store %"compiler/source:Span" %t391, ptr %l157
  br label %bb95
bb95:
  %t392 = load i32, ptr %l10, !range !{i32 0, i32 98}
  %t393 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [4 x i64] }, ptr %t394, i32 0, i32 0
  store i64 4, ptr %t395
  %t396 = load %"compiler/source:Span", ptr %l157
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t396, 0
  %t399 = insertvalue { %"compiler/source:Span", i32, ptr } %t397, i32 %t392, 1
  %t401 = insertvalue { %"compiler/source:Span", i32, ptr } %t399, ptr %t393, 2
  %t402 = getelementptr { i64, [4 x i64] }, ptr %t394, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t401, ptr %t402
  %t403 = load { i64, [4 x i64] }, ptr %t394
  %t405 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t403, ptr %t405
  store ptr %t405, ptr %l2, !tbaa !29
  br label %bb132
bb96:
  %t407 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t409 = trunc i64 29 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb105
bb99:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t412)
  store i32 %t414, ptr %l165
  br label %bb100
bb100:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t415)
  %t418 = extractvalue { i32, ptr } %t417, 1
  %t419 = extractvalue { i32, ptr } %t417, 0
  store i32 %t419, ptr %l169
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb102, label %ok.421, !prof !99
ok.421:
  store ptr %t418, ptr %l168
  br label %bb101
bb101:
  %t422 = load ptr, ptr %l168, !tbaa !29
  store ptr %t422, ptr %l166, !tbaa !29
  br label %bb103
bb102:
  %t423 = load i32, ptr %l169, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  %t433 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb103:
  %t434 = load ptr, ptr %l166, !tbaa !29
  store ptr %t434, ptr %l11, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i32, ptr %l3, !tbaa !23
  %t439 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t435, i32 %t436)
  store %"compiler/source:Span" %t439, ptr %l173
  br label %bb104
bb104:
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t441 = load ptr, ptr %l11, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t442
  %t443 = getelementptr { i64, [4 x i64] }, ptr %t442, i32 0, i32 0
  store i64 11, ptr %t443
  %t444 = load %"compiler/source:Span", ptr %l173
  %t445 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t444, 0
  %t447 = insertvalue { %"compiler/source:Span", ptr, ptr } %t445, ptr %t440, 1
  %t449 = insertvalue { %"compiler/source:Span", ptr, ptr } %t447, ptr %t441, 2
  %t450 = getelementptr { i64, [4 x i64] }, ptr %t442, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t449, ptr %t450
  %t451 = load { i64, [4 x i64] }, ptr %t442
  %t453 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t451, ptr %t453
  store ptr %t453, ptr %l2, !tbaa !29
  br label %bb132
bb105:
  %t455 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t457 = trunc i64 85 to i32
  %t458 = icmp eq i32 %t455, %t457
  br i1 %t458, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb127
bb108:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 7
  %t463 = load i32, ptr %t462, !range !{i32 0, i32 98}
  %t465 = trunc i64 0 to i32
  %t466 = icmp eq i32 %t463, %t465
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb109, label %bb110
bb109:
  %t470 = load ptr, ptr %l2, !tbaa !29
  %t472 = insertvalue { i32, ptr } zeroinitializer, ptr %t470, 1
  store { i32, ptr } %t472, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t473 = load ptr, ptr %l2, !tbaa !29
  %t475 = call i1 @compiler_2fparse_2eisPath(ptr %v1, ptr %t473)
  store i1 %t475, ptr %l186
  br label %bb112
bb112:
  %t476 = load i1, ptr %l186, !tbaa !21
  %t477 = xor i1 %t476, true
  br i1 %t477, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb116
bb114:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t479, i64 1)
  store i32 %t481, ptr %l190
  br label %bb115
bb115:
  %t482 = load i32, ptr %l190, !range !{i32 0, i32 98}
  %t484 = trunc i64 94 to i32
  %t485 = icmp eq i32 %t482, %t484
  %t487 = xor i1 %t485, true
  store i1 %t487, ptr %l188, !tbaa !21
  br label %bb116
bb116:
  %t489 = load i1, ptr %l188, !tbaa !21
  br i1 %t489, label %bb117, label %bb118
bb117:
  %t490 = load ptr, ptr %l2, !tbaa !29
  %t492 = insertvalue { i32, ptr } zeroinitializer, ptr %t490, 1
  store { i32, ptr } %t492, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l2, !tbaa !29
  %t497 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v1, ptr %t493, ptr %t494)
  %t498 = extractvalue { i32, ptr } %t497, 1
  %t499 = extractvalue { i32, ptr } %t497, 0
  store i32 %t499, ptr %l199
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb121, label %ok.501, !prof !99
ok.501:
  store ptr %t498, ptr %l198
  br label %bb120
bb120:
  %t502 = load ptr, ptr %l198, !tbaa !29
  store ptr %t502, ptr %l195, !tbaa !29
  br label %bb122
bb121:
  %t503 = load i32, ptr %l199, !tbaa !23
  %t504 = lshr i32 %t503, 16
  %t505 = and i32 %t503, 65535
  %t506 = icmp eq i32 %t504, 1
  %t507 = select i1 %t506, i32 1, i32 0
  %t508 = icmp eq i32 %t503, 0
  %t509 = shl i32 %t507, 16
  %t510 = or i32 %t509, %t505
  %t511 = select i1 %t508, i32 0, i32 %t510
  %t513 = insertvalue { i32, ptr } zeroinitializer, i32 %t511, 0
  store { i32, ptr } %t513, ptr %rv
  br label %ret
bb122:
  %t514 = load ptr, ptr %l195, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  store ptr %t515, ptr %l202, !tbaa !29
  %t516 = load i32, ptr %l3, !tbaa !23
  store i32 %t516, ptr %l203, !tbaa !23
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load i32, ptr %l3, !tbaa !23
  %t523 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v1, ptr %t517, i32 %t518, ptr %t514)
  store ptr %t523, ptr %l207
  br label %bb123
bb123:
  %t524 = load ptr, ptr %l202, !tbaa !29
  %t525 = load i32, ptr %l203, !tbaa !23
  %t526 = load ptr, ptr %l207, !tbaa !29
  %t527 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v1, ptr %t524, i32 %t525, ptr %t526)
  %t528 = extractvalue { i32, ptr } %t527, 1
  %t529 = extractvalue { i32, ptr } %t527, 0
  store i32 %t529, ptr %l209
  %t530 = icmp ne i32 %t529, 0
  br i1 %t530, label %bb125, label %ok.531, !prof !99
ok.531:
  store ptr %t528, ptr %l208
  br label %bb124
bb124:
  %t532 = load ptr, ptr %l208, !tbaa !29
  store ptr %t532, ptr %l201, !tbaa !29
  br label %bb126
bb125:
  %t533 = load i32, ptr %l209, !tbaa !23
  %t534 = lshr i32 %t533, 16
  %t535 = and i32 %t533, 65535
  %t536 = icmp eq i32 %t534, 1
  %t537 = select i1 %t536, i32 1, i32 0
  %t538 = icmp eq i32 %t533, 0
  %t539 = shl i32 %t537, 16
  %t540 = or i32 %t539, %t535
  %t541 = select i1 %t538, i32 0, i32 %t540
  %t543 = insertvalue { i32, ptr } zeroinitializer, i32 %t541, 0
  store { i32, ptr } %t543, ptr %rv
  br label %ret
bb126:
  %t544 = load ptr, ptr %l201, !tbaa !29
  store ptr %t544, ptr %l2, !tbaa !29
  br label %bb132
bb127:
  br i1 true, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  %t545 = load ptr, ptr %l2, !tbaa !29
  %t547 = insertvalue { i32, ptr } zeroinitializer, ptr %t545, 1
  store { i32, ptr } %t547, ptr %rv
  br label %ret
bb131:
  call void @__olang_check_failed(ptr @olang_loc_148080230b4c6cc_b965c2d4ca1d1020)
  unreachable
bb132:
  br label %bb133
bb133:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epower(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t96 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t20, ptr %lp1
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %lp1
  store ptr %t21, ptr %t22, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t23, i32 55)
  store i1 %t26, ptr %l11
  br label %bb4
bb4:
  %t27 = load i1, ptr %l11, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %lp1
  %t31 = load ptr, ptr %t30, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  %t33 = insertvalue { i32, ptr } zeroinitializer, ptr %t31, 1
  store { i32, ptr } %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l15
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t37)
  %t40 = extractvalue { i32, ptr } %t39, 1
  %t41 = extractvalue { i32, ptr } %t39, 0
  store i32 %t41, ptr %l19
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43, !prof !99
ok.43:
  store ptr %t40, ptr %l18
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l18, !tbaa !29
  store ptr %t44, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t45 = load i32, ptr %l19, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, ptr } zeroinitializer, i32 %t53, 0
  store { i32, ptr } %t55, ptr %rv
  br label %ret
bb11:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t56, ptr %lp2
  %t57 = load ptr, ptr %l16, !tbaa !29
  %t58 = load ptr, ptr %lp2
  store ptr %t57, ptr %t58, !tbaa !29
  %t59 = load ptr, ptr %lp1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l22
  br label %bb12
bb12:
  %t63 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/parse:Parser", ptr %t65, i32 0, i32 10
  %t68 = load i32, ptr %t67, !tbaa !23
  %t71 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t64, i32 %t68)
  store %"compiler/source:Span" %t71, ptr %l26
  br label %bb13
bb13:
  %t72 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t72, ptr %l3
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l28
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb15, label %ok.77, !prof !99
ok.77:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t78 = load i32, ptr %l28, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  call void @__olang_scope_close(ptr %s0)
  %t88 = insertvalue { i32, ptr } zeroinitializer, i32 %t86, 0
  store { i32, ptr } %t88, ptr %rv
  br label %ret
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t89)
  br label %bb17
bb17:
  %t91 = load %"compiler/source:Span", ptr %l3
  %t92 = load ptr, ptr %lp1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %lp2
  %t95 = load ptr, ptr %t94, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 0
  store i64 5, ptr %t97
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t91, 0
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t99, i32 55, 1
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t101, ptr %t93, 2
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t103, ptr %t95, 3
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t105, ptr %t106
  %t107 = load { i64, [4 x i64] }, ptr %t96
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t107, ptr %t109
  call void @__olang_scope_close(ptr %s0)
  %t111 = insertvalue { i32, ptr } zeroinitializer, ptr %t109, 1
  store { i32, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t22 = load i1, ptr %l2, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp eq i64 %t26, 1
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l30, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l35
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Oracle", ptr %t56, i32 0, i32 0
  %t59 = load i32, ptr %l5, !tbaa !23
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l40
  br label %bb15
bb15:
  %t63 = load i1, ptr %l40, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %t66)
  store i1 %t68, ptr %l44
  br label %bb18
bb17:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i1, ptr %l44, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 28
  %t76 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t75, i32 %t76)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %ret
bb24:
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l56, !tbaa !27
  %t94 = load i64, ptr %l8, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t101, ptr %t99, i1 true)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb25
bb31:
  br label %bb54
bb32:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 8}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l11, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l11, !tbaa !29
  %t126 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i1 %t126)
  br label %bb38
bb38:
  br label %bb54
bb39:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t131 = load ptr, ptr %l72, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 4
  store i1 %t137, ptr %l73, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l73, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l12, !tbaa !29
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb45, label %bb46
bb45:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l12, !tbaa !29
  %t153 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i1 %t153)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_b7d265f950b1c844_fc5ee8d7b150faf8)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %a0, %"compiler/parse:stackMarks" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  store %"compiler/parse:stackMarks" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 30
  %t4 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3, i64 %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 31
  %t11 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t10, i64 %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 32
  %t18 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t17, i64 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 33
  %t25 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t24, i64 %t26)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 34
  %t32 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %t31, i64 %t33)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 35
  %t39 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t38, i64 %t40)
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 36
  %t46 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t45, i64 %t47)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %a1
  %t13 = load %"compiler/token:Token", ptr %t12
  store %"compiler/token:Token" %t13, ptr %l3
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %t15, i32 %t17, i32 %t19, %"compiler/msgs:Msg" %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %lp6 = alloca ptr
  %l7 = alloca i1
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i1
  %l14 = alloca i1
  %lp15 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l82 = alloca i1
  %l85 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca ptr
  %l105 = alloca %"compiler/token:Token"
  %l106 = alloca { i64, ptr }
  %l107 = alloca i1
  %l109 = alloca i32
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i32
  %l126 = alloca %"compiler/ast:Sig"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 19
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l17, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t9, i32 92)
  %t13 = extractvalue { i32, i32 } %t12, 1
  %t14 = extractvalue { i32, i32 } %t12, 0
  store i32 %t14, ptr %l24
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store i32 %t13, ptr %l23
  br label %bb4
bb4:
  %t17 = load i32, ptr %l23, !tbaa !23
  store i32 %t17, ptr %l20, !tbaa !23
  br label %bb6
bb5:
  %t18 = load i32, ptr %l24, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 51
  store i1 false, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 49
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l5, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 49
  store i1 %t38, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/parse:Parser", ptr %t42, i32 0, i32 52
  store i1 true, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t45, i1 %a1)
  %t50 = extractvalue { i32, { i64, ptr } } %t49, 1
  %t51 = extractvalue { i32, { i64, ptr } } %t49, 0
  store i32 %t51, ptr %l36
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb8, label %ok.53, !prof !99
ok.53:
  store { i64, ptr } %t50, ptr %l35
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t54, ptr %l32, !tbaa !27
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i1, ptr %l5, !tbaa !21
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t55, i32 0, i32 49
  store i1 %t56, ptr %t59, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t61 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t61, ptr %rv
  br label %ret
bb10:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t62, ptr %lp6
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t64 = load ptr, ptr %lp6
  store { i64, ptr } %t63, ptr %t64, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i1, ptr %l5, !tbaa !21
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t65, i32 0, i32 49
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 51
  %t73 = load i1, ptr %t72, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 51
  store i1 false, ptr %t77, !tbaa !21
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t78, ptr %lp8
  %t79 = load ptr, ptr %lp8
  store ptr null, ptr %t79, !tbaa !29
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb11, label %bb12
bb11:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %v1, ptr %t82)
  %t85 = extractvalue { i32, ptr } %t84, 1
  %t86 = extractvalue { i32, ptr } %t84, 0
  store i32 %t86, ptr %l49
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb14, label %ok.88, !prof !99
ok.88:
  store ptr %t85, ptr %l48
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t89 = load ptr, ptr %l48, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  br label %bb15
bb14:
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, ptr } zeroinitializer, i32 %t98, 0
  store { i32, ptr } %t100, ptr %rv
  br label %ret
bb15:
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t102 = load ptr, ptr %lp8
  store ptr %t101, ptr %t102, !tbaa !29
  br label %bb16
bb16:
  %t103 = icmp sge i64 0, 0
  br i1 %t103, label %bb17, label %bb18
bb17:
  %t105 = icmp sle i64 0, 1152921504606846975
  br i1 %t105, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb19:
  %t107 = mul i64 0, 8
  %t108 = insertvalue { i64, ptr } undef, i64 0, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t110, ptr %lp9
  %t112 = load ptr, ptr %lp9
  store { i64, ptr } %t109, ptr %t112, !tbaa !27
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t113, i32 23)
  store i1 %t116, ptr %l56
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb21:
  %t117 = load i1, ptr %l56, !tbaa !21
  store i1 %t117, ptr %l10, !tbaa !21
  %t118 = load i1, ptr %l10, !tbaa !21
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb22, label %bb23
bb22:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %t122)
  store i1 %t124, ptr %l61
  br label %bb24
bb23:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb25
bb24:
  %t125 = load i1, ptr %l61, !tbaa !21
  store i1 %t125, ptr %l59, !tbaa !21
  br label %bb25
bb25:
  %t126 = load i1, ptr %l59, !tbaa !21
  br i1 %t126, label %bb26, label %bb27
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t127, i32 0, i32 32
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l64
  br label %bb28
bb27:
  br label %bb46
bb28:
  %t132 = load i64, ptr %l64, !tbaa !24
  store i64 %t132, ptr %l11, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 19
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l12, !tbaa !21
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/parse:Parser", ptr %t138, i32 0, i32 19
  store i1 true, ptr %t140, !tbaa !21
  br label %bb29
bb29:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v0, ptr %t141)
  %t144 = extractvalue { i32, ptr } %t143, 1
  %t145 = extractvalue { i32, ptr } %t143, 0
  store i32 %t145, ptr %l71
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb31, label %ok.147, !prof !99
ok.147:
  store ptr %t144, ptr %l70
  br label %bb30
bb30:
  %t148 = load ptr, ptr %l70, !tbaa !29
  store ptr %t148, ptr %l68, !tbaa !29
  br label %bb34
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i1, ptr %l12, !tbaa !21
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 19
  store i1 %t150, ptr %t153, !tbaa !21
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 32
  %t157 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t156, i64 %t157)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t161 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t161, ptr %rv
  br label %ret
bb34:
  %t162 = load ptr, ptr %l68, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t165, ptr %t162)
  br label %bb35
bb35:
  %t169 = load i1, ptr %l4, !tbaa !21
  br i1 %t169, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb39
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t171, i32 59)
  store i1 %t174, ptr %l85
  br label %bb38
bb38:
  %t175 = load i1, ptr %l85, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l82, !tbaa !21
  br label %bb39
bb39:
  %t178 = load i1, ptr %l82, !tbaa !21
  br i1 %t178, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb29
bb44:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i1, ptr %l12, !tbaa !21
  %t183 = getelementptr %"compiler/parse:Parser", ptr %t179, i32 0, i32 19
  store i1 %t180, ptr %t183, !tbaa !21
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t184, i32 0, i32 32
  %t187 = load i64, ptr %l11, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t186, i64 %t187)
  store { i64, ptr } %t190, ptr %l92
  br label %bb45
bb45:
  %t191 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t192 = load ptr, ptr %lp9
  store { i64, ptr } %t191, ptr %t192, !tbaa !27
  br label %bb46
bb46:
  store i1 false, ptr %l14, !tbaa !21
  %t193 = load i1, ptr %l3, !tbaa !21
  br i1 %t193, label %bb47, label %bb48
bb47:
  %t195 = load ptr, ptr %lp9
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t200 = icmp sgt i64 %t198, 0
  store i1 %t200, ptr %l94, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t202 = load i1, ptr %l94, !tbaa !21
  br i1 %t202, label %bb50, label %bb51
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t206 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t203, i32 1)
  store i1 %t206, ptr %l101
  br label %bb52
bb51:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb53
bb52:
  %t207 = load i1, ptr %l101, !tbaa !21
  store i1 %t207, ptr %l98, !tbaa !21
  br label %bb53
bb53:
  %t208 = load i1, ptr %l98, !tbaa !21
  br i1 %t208, label %bb54, label %bb55
bb54:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l103, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t210)
  store %"compiler/token:Token" %t212, ptr %l105
  br label %bb56
bb55:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb59
bb56:
  %t213 = load ptr, ptr %l103, !tbaa !29
  %t214 = load %"compiler/token:Token", ptr %l105
  %t215 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t213, %"compiler/token:Token" %t214)
  store { i64, ptr } %t215, ptr %l106
  br label %bb57
bb57:
  %t216 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t216, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t217, ptr %l107
  br label %bb58
bb58:
  %t218 = load i1, ptr %l107, !tbaa !21
  store i1 %t218, ptr %l102, !tbaa !21
  br label %bb59
bb59:
  %t219 = load i1, ptr %l102, !tbaa !21
  br i1 %t219, label %bb60, label %bb61
bb60:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t220)
  store i32 %t222, ptr %l109
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb63
bb63:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i1, ptr %l4, !tbaa !21
  %t227 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %t223, i1 %t224)
  %t228 = extractvalue { i32, ptr } %t227, 1
  %t229 = extractvalue { i32, ptr } %t227, 0
  store i32 %t229, ptr %l114
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb65, label %ok.231, !prof !99
ok.231:
  store ptr %t228, ptr %l113
  br label %bb64
bb64:
  %t232 = load ptr, ptr %l113, !tbaa !29
  store ptr %t232, ptr %l110, !tbaa !29
  br label %bb66
bb65:
  %t233 = load i32, ptr %l114, !tbaa !23
  %t234 = lshr i32 %t233, 16
  %t235 = and i32 %t233, 65535
  %t236 = icmp eq i32 %t234, 1
  %t237 = select i1 %t236, i32 1, i32 0
  %t238 = icmp eq i32 %t233, 0
  %t239 = shl i32 %t237, 16
  %t240 = or i32 %t239, %t235
  %t241 = select i1 %t238, i32 0, i32 %t240
  call void @__olang_scope_close(ptr %s0)
  %t243 = insertvalue { i32, ptr } zeroinitializer, i32 %t241, 0
  store { i32, ptr } %t243, ptr %rv
  br label %ret
bb66:
  %t244 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t244, ptr %lp15
  %t245 = load ptr, ptr %l110, !tbaa !29
  %t246 = load ptr, ptr %lp15
  store ptr %t245, ptr %t246, !tbaa !29
  %t247 = load ptr, ptr %lp6
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  %t249 = load ptr, ptr %lp9
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t251 = load ptr, ptr %lp15
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/ast:Sig", ptr %t252, i32 0, i32 2
  %t255 = load i1, ptr %t254, !tbaa !21
  %t256 = load ptr, ptr %lp15
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Sig", ptr %t257, i32 0, i32 3
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t261 = load i1, ptr %l10, !tbaa !21
  %t262 = load ptr, ptr %lp8
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = load i1, ptr %l14, !tbaa !21
  %t265 = load i1, ptr %l7, !tbaa !21
  %t274 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t248, { i64, ptr } %t250, i1 %t255, { i64, ptr } %t260, i1 %t261, ptr %t263, i1 %t264, i1 %t265)
  store %"compiler/ast:Sig" %t274, ptr %l126
  br label %bb67
bb67:
  %t275 = load %"compiler/ast:Sig", ptr %l126
  %t276 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store %"compiler/ast:Sig" %t275, ptr %t276
  call void @__olang_scope_close(ptr %s0)
  %t278 = insertvalue { i32, ptr } zeroinitializer, ptr %t276, 1
  store { i32, ptr } %t278, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 8)
  store i1 %t4, ptr %l3
  br label %bb2
bb2:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l6
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l13 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 18
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = sub i64 %t17, 1
  %t22 = icmp slt i64 %t8, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i64 %t31
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36, !range !{i32 0, i32 98}
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l13, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2espread(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %lp9 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l41 = alloca i32
  %l44 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l66 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i32
  %l73 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t101 = alloca { i64, [4 x i64] }, align 8
  %t111 = alloca { i64, [4 x i64] }, align 8
  %t152 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  store i64 0, ptr %l2, !tbaa !24
  store i64 3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l37
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l41
  br label %bb15
bb15:
  %t61 = load i32, ptr %l41, !range !{i32 0, i32 98}
  store i32 %t61, ptr %l8
  %t62 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t64 = trunc i64 59 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  %t67 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t69 = trunc i64 95 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb21
bb20:
  %t73 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t75 = trunc i64 93 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb24
bb23:
  %t79 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t81 = trunc i64 8 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t85, i32 %t86)
  store %"compiler/source:Span" %t89, ptr %l55
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t90, i32 %t91)
  store %"compiler/source:Span" %t94, ptr %l58
  br label %bb28
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/parse:Parser", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s4, ptr %t98, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i32 %t100, ptr %l61
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 0
  store i64 0, ptr %t102
  %t103 = load %"compiler/source:Span", ptr %l58
  %t104 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t103, 0
  %t105 = load i32, ptr %l61, !tbaa !23
  %t106 = insertvalue { %"compiler/source:Span", i32 } %t104, i32 %t105, 1
  %t107 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t106, ptr %t107
  %t108 = load { i64, [4 x i64] }, ptr %t101
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t108, ptr %t110
  store { i64, [4 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 0
  store i64 28, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l55
  %t114 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t113, 0
  %t116 = insertvalue { %"compiler/source:Span", ptr } %t114, ptr %t110, 1
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t111
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t118, ptr %t120
  call void @__olang_scope_close(ptr %s4)
  %t122 = insertvalue { i32, ptr } zeroinitializer, ptr %t120, 1
  store { i32, ptr } %t122, ptr %rv
  br label %ret
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t123)
  %t126 = extractvalue { i32, ptr } %t125, 1
  %t127 = extractvalue { i32, ptr } %t125, 0
  store i32 %t127, ptr %l69
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb32, label %ok.129, !prof !99
ok.129:
  store ptr %t126, ptr %l68
  br label %bb31
bb31:
  %t130 = load ptr, ptr %l68, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  br label %bb33
bb32:
  %t131 = load i32, ptr %l69, !tbaa !23
  %t132 = lshr i32 %t131, 16
  %t133 = and i32 %t131, 65535
  %t134 = icmp eq i32 %t132, 1
  %t135 = select i1 %t134, i32 1, i32 0
  %t136 = icmp eq i32 %t131, 0
  %t137 = shl i32 %t135, 16
  %t138 = or i32 %t137, %t133
  %t139 = select i1 %t136, i32 0, i32 %t138
  %t141 = insertvalue { i32, ptr } zeroinitializer, i32 %t139, 0
  store { i32, ptr } %t141, ptr %rv
  br label %ret
bb33:
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t142, ptr %lp9
  %t143 = load ptr, ptr %l66, !tbaa !29
  %t144 = load ptr, ptr %lp9
  store ptr %t143, ptr %t144, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  %t149 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t145, i32 %t146)
  store %"compiler/source:Span" %t149, ptr %l73
  br label %bb34
bb34:
  %t150 = load ptr, ptr %lp9
  %t151 = load ptr, ptr %t150, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 28, ptr %t153
  %t154 = load %"compiler/source:Span", ptr %l73
  %t155 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t154, 0
  %t157 = insertvalue { %"compiler/source:Span", ptr } %t155, ptr %t151, 1
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t157, ptr %t158
  %t159 = load { i64, [4 x i64] }, ptr %t152
  %t161 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t159, ptr %t161
  %t163 = insertvalue { i32, ptr } zeroinitializer, ptr %t161, 1
  store { i32, ptr } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i32
  %l33 = alloca i32
  %l38 = alloca %"compiler/token:Token"
  %l40 = alloca i1
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !range !{i32 0, i32 98}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t7 = trunc i64 39 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t12 = trunc i64 37 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t19 = trunc i64 1 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t29, ptr %l18
  br label %bb12
bb12:
  %t30 = load i32, ptr %l18, !range !{i32 0, i32 98}
  %t32 = trunc i64 60 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t35, i64 %t38)
  store i32 %t41, ptr %l25
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t42 = load i32, ptr %l25, !range !{i32 0, i32 98}
  %t44 = trunc i64 1 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l21, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = add i64 %t50, 2
  store i64 %t52, ptr %l2, !tbaa !24
  br label %bb20
bb20:
  br label %bb11
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l33
  br label %bb22
bb22:
  %t59 = load i32, ptr %l33, !range !{i32 0, i32 98}
  store i32 %t59, ptr %l3
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t62 = trunc i64 85 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/token:Token" %t69, ptr %l38
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t70 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t71 = load %"compiler/token:Token", ptr %l38
  %t73 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t71, i8 %t70)
  store i1 %t73, ptr %l40
  br label %bb26
bb26:
  %t74 = load i1, ptr %l40, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %rv
  br label %ret
bb27:
  %t77 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t79 = trunc i64 81 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l46
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 6
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t10, i64 %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l8 = alloca i32
  %l18 = alloca i32
  %l25 = alloca i32
  %l30 = alloca i1
  %l37 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  store i32 0, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 11
  store i1 false, ptr %t7, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t11, ptr %l2
  %t12 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t19 = trunc i64 96 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = trunc i64 %t29 to i32
  %t34 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t25, i32 %t31)
  store i32 %t34, ptr %l18
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t35 = load i32, ptr %l18, !tbaa !23
  store i32 %t35, ptr %l3, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 6
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l25
  br label %bb12
bb12:
  br label %bb40
bb13:
  %t50 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t52 = trunc i64 97 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t57 = trunc i64 92 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t60 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t62 = trunc i64 94 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l1, !tbaa !24
  br label %bb37
bb20:
  %t70 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t72 = trunc i64 93 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb23
bb22:
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t77 = trunc i64 95 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t80 = load i1, ptr %l37, !tbaa !21
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb26, label %bb27
bb25:
  %t85 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t87 = trunc i64 8 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb29, label %bb30
bb26:
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = sub i64 %t90, 1
  store i64 %t92, ptr %l1, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb36
bb29:
  %t94 = load i64, ptr %l1, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t99)
  store i32 %t101, ptr %l50
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l52
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 6
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t11)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 6
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 6
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t27)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/token:Token" %a1) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/token:Token" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Source", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t8 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l8, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb3:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/token:Token", ptr %t18, i64 %t16
  %t20 = load %"compiler/token:Token", ptr %t19
  store %"compiler/token:Token" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, [3 x i64] }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %t39 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 21
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/token:Token", ptr %t19, i64 %a1
  %t21 = load %"compiler/token:Token", ptr %t20
  store %"compiler/token:Token" %t21, ptr %l2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 4
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/parse:Parser", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 0
  store i64 3, ptr %t40
  %t42 = insertvalue { i64, i64, i64 } undef, i64 %t30, 0
  %t44 = insertvalue { i64, i64, i64 } %t42, i64 %t34, 1
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t38, 2
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  store { i64, i64, i64 } %t46, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t39
  store { i64, [3 x i64] } %t48, ptr %l19
  %t49 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %s0, i64 %t49)
  store %"compiler/msgs:Msg" %t51, ptr %l21
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l12, !tbaa !29
  %t53 = load { i64, [3 x i64] }, ptr %l19
  %t54 = load %"compiler/msgs:Msg", ptr %l21
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s0, ptr %t52, { i64, [3 x i64] } %t53, %"compiler/msgs:Msg" %t54)
  store i64 %t55, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %lp5 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/ast:TopBranch"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 96)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l10
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l10, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l6, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 37
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l17
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t35)
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t37, i32 97)
  store i1 %t40, ptr %l21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 0)
  store i1 %t45, ptr %l25
  br label %bb11
bb11:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t48)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb6
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t53)
  br label %bb19
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t55, i32 97)
  %t59 = extractvalue { i32, i32 } %t58, 1
  %t60 = extractvalue { i32, i32 } %t58, 0
  store i32 %t60, ptr %l33
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb21, label %ok.62, !prof !99
ok.62:
  store i32 %t59, ptr %l32
  br label %bb20
bb20:
  %t63 = load i32, ptr %l32, !tbaa !23
  store i32 %t63, ptr %l29, !tbaa !23
  br label %bb22
bb21:
  %t64 = load i32, ptr %l33, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t75, i32 %t76)
  store %"compiler/source:Span" %t79, ptr %l37
  br label %bb23
bb23:
  %t80 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t80, ptr %l4
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 37
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l41
  br label %bb24
bb24:
  %t88 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t88, ptr %lp5
  %t89 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t90 = load ptr, ptr %lp5
  store { i64, ptr } %t89, ptr %t90, !tbaa !27
  %t91 = load %"compiler/source:Span", ptr %l4
  %t92 = load ptr, ptr %lp5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l2, !tbaa !24
  %t98 = call %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t91, { i64, ptr } %t93, i64 %t94)
  store %"compiler/ast:TopBranch" %t98, ptr %l45
  br label %bb25
bb25:
  %t99 = load %"compiler/ast:TopBranch", ptr %l45
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopBranch" %t99, ptr %t100
  %t102 = insertvalue { i32, ptr } zeroinitializer, ptr %t100, 1
  store { i32, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %lp8 = alloca ptr
  %l9 = alloca i32
  %lp10 = alloca ptr
  %lp11 = alloca ptr
  %lp12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %lp15 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca i32
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i32
  %l114 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca i1
  %l157 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i32
  %l169 = alloca %"compiler/source:Span"
  %l171 = alloca i32
  %l182 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l210 = alloca i1
  %l220 = alloca %"compiler/source:Span"
  %l227 = alloca %"compiler/source:Span"
  %l229 = alloca i32
  %rv = alloca { i32, ptr }
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t131 = alloca { i64, [4 x i64] }, align 8
  %t200 = alloca { i64, [4 x i64] }, align 8
  %t302 = alloca { i64, [4 x i64] }, align 8
  %t375 = alloca { i64, [4 x i64] }, align 8
  %t428 = alloca { i64, [4 x i64] }, align 8
  %t497 = alloca { i64, [4 x i64] }, align 8
  %t638 = alloca { i64, [4 x i64] }, align 8
  %t683 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i32, ptr %l23, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 20
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 2
  %t11 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 6
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t16, i64 %t20)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 22
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 22
  store i64 -1, ptr %t30, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t31, i32 14)
  store i1 %t34, ptr %l37
  br label %bb6
bb6:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %t36, i1 true)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l41
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb10, label %ok.42, !prof !99
ok.42:
  store ptr %t39, ptr %l40
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t43 = load ptr, ptr %l40, !tbaa !29
  store ptr %t43, ptr %l38, !tbaa !29
  br label %bb11
bb10:
  %t44 = load i32, ptr %l41, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 22
  store i64 %t54, ptr %t57, !tbaa !24
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb11:
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t60, ptr %lp3
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t62 = load ptr, ptr %lp3
  store ptr %t61, ptr %t62, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t63, i32 %t64)
  store %"compiler/source:Span" %t67, ptr %l47
  br label %bb12
bb12:
  %t68 = load ptr, ptr %lp3
  %t69 = load ptr, ptr %t68, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 18, ptr %t71
  %t72 = load %"compiler/source:Span", ptr %l47
  %t73 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t72, 0
  %t75 = insertvalue { %"compiler/source:Span", ptr } %t73, ptr %t69, 1
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t75, ptr %t76
  %t77 = load { i64, [4 x i64] }, ptr %t70
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t77, ptr %t79
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 22
  store i64 %t81, ptr %t84, !tbaa !24
  %t86 = insertvalue { i32, ptr } zeroinitializer, ptr %t79, 1
  store { i32, ptr } %t86, ptr %rv
  br label %ret
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t87, i32 76)
  store i1 %t90, ptr %l55
  br label %bb14
bb14:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t92, i32 77)
  store i1 %t95, ptr %l59
  br label %bb17
bb17:
  %t96 = load i1, ptr %l59, !tbaa !21
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t98)
  %t101 = extractvalue { i32, ptr } %t100, 1
  %t102 = extractvalue { i32, ptr } %t100, 0
  store i32 %t102, ptr %l63
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb22, label %ok.104, !prof !99
ok.104:
  store ptr %t101, ptr %l62
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t105 = load ptr, ptr %l62, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  br label %bb23
bb22:
  %t106 = load i32, ptr %l63, !tbaa !23
  %t107 = lshr i32 %t106, 16
  %t108 = and i32 %t106, 65535
  %t109 = icmp eq i32 %t107, 1
  %t110 = select i1 %t109, i32 1, i32 0
  %t111 = icmp eq i32 %t106, 0
  %t112 = shl i32 %t110, 16
  %t113 = or i32 %t112, %t108
  %t114 = select i1 %t111, i32 0, i32 %t113
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l2, !tbaa !24
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t115, i32 0, i32 22
  store i64 %t116, ptr %t119, !tbaa !24
  %t121 = insertvalue { i32, ptr } zeroinitializer, i32 %t114, 0
  store { i32, ptr } %t121, ptr %rv
  br label %ret
bb23:
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t122, ptr %lp4
  %t123 = load ptr, ptr %l60, !tbaa !29
  %t124 = load ptr, ptr %lp4
  store ptr %t123, ptr %t124, !tbaa !29
  %t125 = load ptr, ptr %lp4
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t126)
  store %"compiler/source:Span" %t128, ptr %l68
  br label %bb24
bb24:
  %t129 = load ptr, ptr %lp4
  %t130 = load ptr, ptr %t129, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 0, ptr %t132
  %t133 = load %"compiler/source:Span", ptr %l68
  %t134 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t133, 0
  %t136 = insertvalue { %"compiler/source:Span", ptr } %t134, ptr %t130, 1
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t131
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t139, ptr %lp5
  %t141 = load ptr, ptr %lp5
  store { i64, [4 x i64] } %t138, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t142, i1 false)
  %t145 = extractvalue { i32, { i64, ptr } } %t144, 1
  %t146 = extractvalue { i32, { i64, ptr } } %t144, 0
  store i32 %t146, ptr %l74
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb26, label %ok.148, !prof !99
ok.148:
  store { i64, ptr } %t145, ptr %l73
  br label %bb25
bb25:
  %t149 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t149, ptr %l71, !tbaa !27
  br label %bb27
bb26:
  %t150 = load i32, ptr %l74, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i64, ptr %l2, !tbaa !24
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 22
  store i64 %t160, ptr %t163, !tbaa !24
  %t165 = insertvalue { i32, ptr } zeroinitializer, i32 %t158, 0
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb27:
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t166, ptr %lp6
  %t167 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t168 = load ptr, ptr %lp6
  store { i64, ptr } %t167, ptr %t168, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l1, !tbaa !23
  %t173 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t169, i32 %t170)
  store %"compiler/source:Span" %t173, ptr %l80
  br label %bb28
bb28:
  %t174 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t174, ptr %l7
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t175)
  store i32 %t177, ptr %l82
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb30, label %ok.179, !prof !99
ok.179:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t180 = load i32, ptr %l82, !tbaa !23
  %t181 = lshr i32 %t180, 16
  %t182 = and i32 %t180, 65535
  %t183 = icmp eq i32 %t181, 1
  %t184 = select i1 %t183, i32 1, i32 0
  %t185 = icmp eq i32 %t180, 0
  %t186 = shl i32 %t184, 16
  %t187 = or i32 %t186, %t182
  %t188 = select i1 %t185, i32 0, i32 %t187
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l2, !tbaa !24
  %t193 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 22
  store i64 %t190, ptr %t193, !tbaa !24
  %t195 = insertvalue { i32, ptr } zeroinitializer, i32 %t188, 0
  store { i32, ptr } %t195, ptr %rv
  br label %ret
bb31:
  %t196 = load %"compiler/source:Span", ptr %l7
  %t197 = load ptr, ptr %lp5
  %t198 = load ptr, ptr %lp6
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 0
  store i64 4, ptr %t201
  %t203 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t196, 0
  %t205 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t203, ptr %t197, 1
  %t207 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t205, { i64, ptr } %t199, 2
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t207, ptr %t208
  %t209 = load { i64, [4 x i64] }, ptr %t200
  %t211 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t209, ptr %t211
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l2, !tbaa !24
  %t216 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 22
  store i64 %t213, ptr %t216, !tbaa !24
  %t218 = insertvalue { i32, ptr } zeroinitializer, ptr %t211, 1
  store { i32, ptr } %t218, ptr %rv
  br label %ret
bb32:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t219)
  %t222 = extractvalue { i32, ptr } %t221, 1
  %t223 = extractvalue { i32, ptr } %t221, 0
  store i32 %t223, ptr %l96
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb34, label %ok.225, !prof !99
ok.225:
  store ptr %t222, ptr %l95
  br label %bb33
bb33:
  %t226 = load ptr, ptr %l95, !tbaa !29
  store ptr %t226, ptr %l93, !tbaa !29
  br label %bb35
bb34:
  %t227 = load i32, ptr %l96, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i64, ptr %l2, !tbaa !24
  %t240 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 22
  store i64 %t237, ptr %t240, !tbaa !24
  %t242 = insertvalue { i32, ptr } zeroinitializer, i32 %t235, 0
  store { i32, ptr } %t242, ptr %rv
  br label %ret
bb35:
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t243, ptr %lp8
  %t244 = load ptr, ptr %l93, !tbaa !29
  %t245 = load ptr, ptr %lp8
  store ptr %t244, ptr %t245, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t246)
  store i32 %t248, ptr %l101
  br label %bb36
bb36:
  %t249 = load i32, ptr %l101, !range !{i32 0, i32 98}
  store i32 %t249, ptr %l9
  %t250 = load i32, ptr %l9, !range !{i32 0, i32 98}
  %t252 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t250)
  store i1 %t252, ptr %l103
  br label %bb37
bb37:
  %t253 = load i1, ptr %l103, !tbaa !21
  br i1 %t253, label %bb38, label %bb39
bb38:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l105
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t257)
  %t260 = extractvalue { i32, ptr } %t259, 1
  %t261 = extractvalue { i32, ptr } %t259, 0
  store i32 %t261, ptr %l109
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb42, label %ok.263, !prof !99
ok.263:
  store ptr %t260, ptr %l108
  br label %bb41
bb41:
  %t264 = load ptr, ptr %l108, !tbaa !29
  store ptr %t264, ptr %l106, !tbaa !29
  br label %bb43
bb42:
  %t265 = load i32, ptr %l109, !tbaa !23
  %t266 = lshr i32 %t265, 16
  %t267 = and i32 %t265, 65535
  %t268 = icmp eq i32 %t266, 1
  %t269 = select i1 %t268, i32 1, i32 0
  %t270 = icmp eq i32 %t265, 0
  %t271 = shl i32 %t269, 16
  %t272 = or i32 %t271, %t267
  %t273 = select i1 %t270, i32 0, i32 %t272
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i64, ptr %l2, !tbaa !24
  %t278 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 22
  store i64 %t275, ptr %t278, !tbaa !24
  %t280 = insertvalue { i32, ptr } zeroinitializer, i32 %t273, 0
  store { i32, ptr } %t280, ptr %rv
  br label %ret
bb43:
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t281, ptr %lp10
  %t282 = load ptr, ptr %l106, !tbaa !29
  %t283 = load ptr, ptr %lp10
  store ptr %t282, ptr %t283, !tbaa !29
  %t284 = load ptr, ptr %lp8
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t285)
  store %"compiler/source:Span" %t287, ptr %l114
  br label %bb44
bb44:
  %t288 = getelementptr %"compiler/source:Span", ptr %l114, i32 0, i32 0
  %t289 = load i32, ptr %t288, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/parse:Parser", ptr %t290, i32 0, i32 10
  %t293 = load i32, ptr %t292, !tbaa !23
  %t296 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t289, i32 %t293)
  store %"compiler/source:Span" %t296, ptr %l118
  br label %bb45
bb45:
  %t297 = load i32, ptr %l9, !range !{i32 0, i32 98}
  %t298 = load ptr, ptr %lp8
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load ptr, ptr %lp10
  %t301 = load ptr, ptr %t300, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t302, i32 0, i32 0
  store i64 3, ptr %t303
  %t304 = load %"compiler/source:Span", ptr %l118
  %t305 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t304, 0
  %t307 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t305, i32 %t297, 1
  %t309 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t307, ptr %t299, 2
  %t311 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t309, ptr %t301, 3
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t302, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t311, ptr %t312
  %t313 = load { i64, [4 x i64] }, ptr %t302
  %t314 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t314, ptr %lp11
  %t316 = load ptr, ptr %lp11
  store { i64, [4 x i64] } %t313, ptr %t316
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t317, i1 false)
  %t320 = extractvalue { i32, { i64, ptr } } %t319, 1
  %t321 = extractvalue { i32, { i64, ptr } } %t319, 0
  store i32 %t321, ptr %l126
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb47, label %ok.323, !prof !99
ok.323:
  store { i64, ptr } %t320, ptr %l125
  br label %bb46
bb46:
  %t324 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t324, ptr %l123, !tbaa !27
  br label %bb48
bb47:
  %t325 = load i32, ptr %l126, !tbaa !23
  %t326 = lshr i32 %t325, 16
  %t327 = and i32 %t325, 65535
  %t328 = icmp eq i32 %t326, 1
  %t329 = select i1 %t328, i32 1, i32 0
  %t330 = icmp eq i32 %t325, 0
  %t331 = shl i32 %t329, 16
  %t332 = or i32 %t331, %t327
  %t333 = select i1 %t330, i32 0, i32 %t332
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l2, !tbaa !24
  %t338 = getelementptr %"compiler/parse:Parser", ptr %t334, i32 0, i32 22
  store i64 %t335, ptr %t338, !tbaa !24
  %t340 = insertvalue { i32, ptr } zeroinitializer, i32 %t333, 0
  store { i32, ptr } %t340, ptr %rv
  br label %ret
bb48:
  %t341 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t341, ptr %lp12
  %t342 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t343 = load ptr, ptr %lp12
  store { i64, ptr } %t342, ptr %t343, !tbaa !27
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i32, ptr %l1, !tbaa !23
  %t348 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t344, i32 %t345)
  store %"compiler/source:Span" %t348, ptr %l132
  br label %bb49
bb49:
  %t349 = load %"compiler/source:Span", ptr %l132
  store %"compiler/source:Span" %t349, ptr %l13
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t350)
  store i32 %t352, ptr %l134
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb51, label %ok.354, !prof !99
ok.354:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t355 = load i32, ptr %l134, !tbaa !23
  %t356 = lshr i32 %t355, 16
  %t357 = and i32 %t355, 65535
  %t358 = icmp eq i32 %t356, 1
  %t359 = select i1 %t358, i32 1, i32 0
  %t360 = icmp eq i32 %t355, 0
  %t361 = shl i32 %t359, 16
  %t362 = or i32 %t361, %t357
  %t363 = select i1 %t360, i32 0, i32 %t362
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i64, ptr %l2, !tbaa !24
  %t368 = getelementptr %"compiler/parse:Parser", ptr %t364, i32 0, i32 22
  store i64 %t365, ptr %t368, !tbaa !24
  %t370 = insertvalue { i32, ptr } zeroinitializer, i32 %t363, 0
  store { i32, ptr } %t370, ptr %rv
  br label %ret
bb52:
  %t371 = load %"compiler/source:Span", ptr %l13
  %t372 = load ptr, ptr %lp11
  %t373 = load ptr, ptr %lp12
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t375
  %t376 = getelementptr { i64, [4 x i64] }, ptr %t375, i32 0, i32 0
  store i64 4, ptr %t376
  %t378 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t371, 0
  %t380 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t378, ptr %t372, 1
  %t382 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t380, { i64, ptr } %t374, 2
  %t383 = getelementptr { i64, [4 x i64] }, ptr %t375, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t382, ptr %t383
  %t384 = load { i64, [4 x i64] }, ptr %t375
  %t386 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t384, ptr %t386
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i64, ptr %l2, !tbaa !24
  %t391 = getelementptr %"compiler/parse:Parser", ptr %t387, i32 0, i32 22
  store i64 %t388, ptr %t391, !tbaa !24
  %t393 = insertvalue { i32, ptr } zeroinitializer, ptr %t386, 1
  store { i32, ptr } %t393, ptr %rv
  br label %ret
bb53:
  %t394 = load ptr, ptr %lp8
  %t395 = load ptr, ptr %t394, !tbaa !29
  store ptr %t395, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t396 = load ptr, ptr %l145, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb54, label %bb55
bb54:
  %t399 = load ptr, ptr %l145, !tbaa !29
  %t400 = load i64, ptr %t399, !range !{i64 0, i64 30}
  %t402 = icmp eq i64 %t400, 4
  store i1 %t402, ptr %l146, !tbaa !21
  br label %bb55
bb55:
  %t403 = load i1, ptr %l146, !tbaa !21
  br i1 %t403, label %bb56, label %bb57
bb56:
  %t404 = load ptr, ptr %lp8
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t407 = getelementptr { i64, [4 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t407, i32 0, i32 1
  %t409 = load i32, ptr %t408, !range !{i32 0, i32 98}
  store i32 %t409, ptr %l14
  br label %bb58
bb57:
  br label %bb73
bb58:
  %t411 = load i32, ptr %l14, !range !{i32 0, i32 98}
  %t413 = trunc i64 76 to i32
  %t414 = icmp eq i32 %t411, %t413
  br i1 %t414, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb61
bb60:
  %t416 = load i32, ptr %l14, !range !{i32 0, i32 98}
  %t418 = trunc i64 77 to i32
  %t419 = icmp eq i32 %t416, %t418
  store i1 %t419, ptr %l153, !tbaa !21
  br label %bb61
bb61:
  %t421 = load i1, ptr %l153, !tbaa !21
  br i1 %t421, label %bb62, label %bb63
bb62:
  %t422 = load ptr, ptr %lp8
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t423)
  store %"compiler/source:Span" %t425, ptr %l157
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t426 = load ptr, ptr %lp8
  %t427 = load ptr, ptr %t426, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 0
  store i64 0, ptr %t429
  %t430 = load %"compiler/source:Span", ptr %l157
  %t431 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t430, 0
  %t433 = insertvalue { %"compiler/source:Span", ptr } %t431, ptr %t427, 1
  %t434 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t433, ptr %t434
  %t435 = load { i64, [4 x i64] }, ptr %t428
  %t436 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t436, ptr %lp15
  %t438 = load ptr, ptr %lp15
  store { i64, [4 x i64] } %t435, ptr %t438
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t439, i1 false)
  %t442 = extractvalue { i32, { i64, ptr } } %t441, 1
  %t443 = extractvalue { i32, { i64, ptr } } %t441, 0
  store i32 %t443, ptr %l163
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb66, label %ok.445, !prof !99
ok.445:
  store { i64, ptr } %t442, ptr %l162
  br label %bb65
bb65:
  %t446 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t446, ptr %l160, !tbaa !27
  br label %bb67
bb66:
  %t447 = load i32, ptr %l163, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 1, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i64, ptr %l2, !tbaa !24
  %t460 = getelementptr %"compiler/parse:Parser", ptr %t456, i32 0, i32 22
  store i64 %t457, ptr %t460, !tbaa !24
  %t462 = insertvalue { i32, ptr } zeroinitializer, i32 %t455, 0
  store { i32, ptr } %t462, ptr %rv
  br label %ret
bb67:
  %t463 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t463, ptr %lp16
  %t464 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t465 = load ptr, ptr %lp16
  store { i64, ptr } %t464, ptr %t465, !tbaa !27
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i32, ptr %l1, !tbaa !23
  %t470 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t466, i32 %t467)
  store %"compiler/source:Span" %t470, ptr %l169
  br label %bb68
bb68:
  %t471 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t471, ptr %l17
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t472)
  store i32 %t474, ptr %l171
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb70, label %ok.476, !prof !99
ok.476:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t477 = load i32, ptr %l171, !tbaa !23
  %t478 = lshr i32 %t477, 16
  %t479 = and i32 %t477, 65535
  %t480 = icmp eq i32 %t478, 1
  %t481 = select i1 %t480, i32 1, i32 0
  %t482 = icmp eq i32 %t477, 0
  %t483 = shl i32 %t481, 16
  %t484 = or i32 %t483, %t479
  %t485 = select i1 %t482, i32 0, i32 %t484
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i64, ptr %l2, !tbaa !24
  %t490 = getelementptr %"compiler/parse:Parser", ptr %t486, i32 0, i32 22
  store i64 %t487, ptr %t490, !tbaa !24
  %t492 = insertvalue { i32, ptr } zeroinitializer, i32 %t485, 0
  store { i32, ptr } %t492, ptr %rv
  br label %ret
bb71:
  %t493 = load %"compiler/source:Span", ptr %l17
  %t494 = load ptr, ptr %lp15
  %t495 = load ptr, ptr %lp16
  %t496 = load { i64, ptr }, ptr %t495, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t497
  %t498 = getelementptr { i64, [4 x i64] }, ptr %t497, i32 0, i32 0
  store i64 4, ptr %t498
  %t500 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t493, 0
  %t502 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t500, ptr %t494, 1
  %t504 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t502, { i64, ptr } %t496, 2
  %t505 = getelementptr { i64, [4 x i64] }, ptr %t497, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t504, ptr %t505
  %t506 = load { i64, [4 x i64] }, ptr %t497
  %t508 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t506, ptr %t508
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load i64, ptr %l2, !tbaa !24
  %t513 = getelementptr %"compiler/parse:Parser", ptr %t509, i32 0, i32 22
  store i64 %t510, ptr %t513, !tbaa !24
  %t515 = insertvalue { i32, ptr } zeroinitializer, ptr %t508, 1
  store { i32, ptr } %t515, ptr %rv
  br label %ret
bb72:
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e98eee410cc159b2_377f58609bf35bd6)
  unreachable
bb78:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %lp8
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t521 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t516, ptr %t518, i64 1)
  %t522 = extractvalue { i32, ptr } %t521, 1
  %t523 = extractvalue { i32, ptr } %t521, 0
  store i32 %t523, ptr %l186
  %t524 = icmp ne i32 %t523, 0
  br i1 %t524, label %bb80, label %ok.525, !prof !99
ok.525:
  store ptr %t522, ptr %l185
  br label %bb79
bb79:
  %t526 = load ptr, ptr %l185, !tbaa !29
  store ptr %t526, ptr %l182, !tbaa !29
  br label %bb81
bb80:
  %t527 = load i32, ptr %l186, !tbaa !23
  %t528 = lshr i32 %t527, 16
  %t529 = and i32 %t527, 65535
  %t530 = icmp eq i32 %t528, 1
  %t531 = select i1 %t530, i32 1, i32 0
  %t532 = icmp eq i32 %t527, 0
  %t533 = shl i32 %t531, 16
  %t534 = or i32 %t533, %t529
  %t535 = select i1 %t532, i32 0, i32 %t534
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i64, ptr %l2, !tbaa !24
  %t540 = getelementptr %"compiler/parse:Parser", ptr %t536, i32 0, i32 22
  store i64 %t537, ptr %t540, !tbaa !24
  %t542 = insertvalue { i32, ptr } zeroinitializer, i32 %t535, 0
  store { i32, ptr } %t542, ptr %rv
  br label %ret
bb81:
  %t543 = load ptr, ptr %l182, !tbaa !29
  %t544 = load ptr, ptr %lp8
  store ptr %t543, ptr %t544, !tbaa !29
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %lp8
  %t547 = load ptr, ptr %t546, !tbaa !29
  %t550 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t545, ptr %t547)
  %t551 = extractvalue { i32, ptr } %t550, 1
  %t552 = extractvalue { i32, ptr } %t550, 0
  store i32 %t552, ptr %l194
  %t553 = icmp ne i32 %t552, 0
  br i1 %t553, label %bb83, label %ok.554, !prof !99
ok.554:
  store ptr %t551, ptr %l193
  br label %bb82
bb82:
  %t555 = load ptr, ptr %l193, !tbaa !29
  store ptr %t555, ptr %l190, !tbaa !29
  br label %bb84
bb83:
  %t556 = load i32, ptr %l194, !tbaa !23
  %t557 = lshr i32 %t556, 16
  %t558 = and i32 %t556, 65535
  %t559 = icmp eq i32 %t557, 1
  %t560 = select i1 %t559, i32 1, i32 0
  %t561 = icmp eq i32 %t556, 0
  %t562 = shl i32 %t560, 16
  %t563 = or i32 %t562, %t558
  %t564 = select i1 %t561, i32 0, i32 %t563
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i64, ptr %l2, !tbaa !24
  %t569 = getelementptr %"compiler/parse:Parser", ptr %t565, i32 0, i32 22
  store i64 %t566, ptr %t569, !tbaa !24
  %t571 = insertvalue { i32, ptr } zeroinitializer, i32 %t564, 0
  store { i32, ptr } %t571, ptr %rv
  br label %ret
bb84:
  %t572 = load ptr, ptr %l190, !tbaa !29
  %t573 = load ptr, ptr %lp8
  store ptr %t572, ptr %t573, !tbaa !29
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/parse:Parser", ptr %t574, i32 0, i32 22
  %t577 = load i64, ptr %t576, !tbaa !24
  store i64 %t577, ptr %l18, !tbaa !24
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t579, i1 false)
  %t582 = extractvalue { i32, { i64, ptr } } %t581, 1
  %t583 = extractvalue { i32, { i64, ptr } } %t581, 0
  store i32 %t583, ptr %l203
  %t584 = icmp ne i32 %t583, 0
  br i1 %t584, label %bb86, label %ok.585, !prof !99
ok.585:
  store { i64, ptr } %t582, ptr %l202
  br label %bb85
bb85:
  %t586 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t586, ptr %l200, !tbaa !27
  br label %bb87
bb86:
  %t587 = load i32, ptr %l203, !tbaa !23
  %t588 = lshr i32 %t587, 16
  %t589 = and i32 %t587, 65535
  %t590 = icmp eq i32 %t588, 1
  %t591 = select i1 %t590, i32 1, i32 0
  %t592 = icmp eq i32 %t587, 0
  %t593 = shl i32 %t591, 16
  %t594 = or i32 %t593, %t589
  %t595 = select i1 %t592, i32 0, i32 %t594
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load i64, ptr %l2, !tbaa !24
  %t600 = getelementptr %"compiler/parse:Parser", ptr %t596, i32 0, i32 22
  store i64 %t597, ptr %t600, !tbaa !24
  %t602 = insertvalue { i32, ptr } zeroinitializer, i32 %t595, 0
  store { i32, ptr } %t602, ptr %rv
  br label %ret
bb87:
  %t603 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t603, ptr %lp19
  %t604 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t605 = load ptr, ptr %lp19
  store { i64, ptr } %t604, ptr %t605, !tbaa !27
  %t606 = load ptr, ptr %lp19
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  %t609 = extractvalue { i64, ptr } %t607, 0
  %t611 = icmp eq i64 %t609, 0
  br i1 %t611, label %bb88, label %bb89
bb88:
  %t613 = load i64, ptr %l18, !tbaa !24
  %t615 = icmp sge i64 %t613, 0
  store i1 %t615, ptr %l210, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb90
bb90:
  %t617 = load i1, ptr %l210, !tbaa !21
  br i1 %t617, label %bb91, label %bb92
bb91:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t618, i64 %t619)
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i64, ptr %l2, !tbaa !24
  %t626 = getelementptr %"compiler/parse:Parser", ptr %t622, i32 0, i32 22
  store i64 %t623, ptr %t626, !tbaa !24
  %t628 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t628, ptr %rv
  br label %ret
bb94:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i32, ptr %l1, !tbaa !23
  %t633 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t629, i32 %t630)
  store %"compiler/source:Span" %t633, ptr %l220
  br label %bb95
bb95:
  %t634 = load ptr, ptr %lp8
  %t635 = load ptr, ptr %t634, !tbaa !29
  %t636 = load ptr, ptr %lp19
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t638
  %t639 = getelementptr { i64, [4 x i64] }, ptr %t638, i32 0, i32 0
  store i64 21, ptr %t639
  %t640 = load %"compiler/source:Span", ptr %l220
  %t641 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t640, 0
  %t643 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t641, ptr %t635, 1
  %t645 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t643, { i64, ptr } %t637, 2
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t638, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t645, ptr %t646
  %t647 = load { i64, [4 x i64] }, ptr %t638
  %t649 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t647, ptr %t649
  %t650 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t650, ptr %lp20
  %t652 = load ptr, ptr %lp20
  store ptr %t649, ptr %t652, !tbaa !29
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load i32, ptr %l1, !tbaa !23
  %t657 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t653, i32 %t654)
  store %"compiler/source:Span" %t657, ptr %l227
  br label %bb96
bb96:
  %t658 = load %"compiler/source:Span", ptr %l227
  store %"compiler/source:Span" %t658, ptr %l21
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t659)
  store i32 %t661, ptr %l229
  %t662 = icmp ne i32 %t661, 0
  br i1 %t662, label %bb98, label %ok.663, !prof !99
ok.663:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t664 = load i32, ptr %l229, !tbaa !23
  %t665 = lshr i32 %t664, 16
  %t666 = and i32 %t664, 65535
  %t667 = icmp eq i32 %t665, 1
  %t668 = select i1 %t667, i32 1, i32 0
  %t669 = icmp eq i32 %t664, 0
  %t670 = shl i32 %t668, 16
  %t671 = or i32 %t670, %t666
  %t672 = select i1 %t669, i32 0, i32 %t671
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load i64, ptr %l2, !tbaa !24
  %t677 = getelementptr %"compiler/parse:Parser", ptr %t673, i32 0, i32 22
  store i64 %t674, ptr %t677, !tbaa !24
  %t679 = insertvalue { i32, ptr } zeroinitializer, i32 %t672, 0
  store { i32, ptr } %t679, ptr %rv
  br label %ret
bb99:
  %t680 = load %"compiler/source:Span", ptr %l21
  %t681 = load ptr, ptr %lp20
  %t682 = load ptr, ptr %t681, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t683
  %t684 = getelementptr { i64, [4 x i64] }, ptr %t683, i32 0, i32 0
  store i64 0, ptr %t684
  %t686 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t680, 0
  %t688 = insertvalue { %"compiler/source:Span", ptr } %t686, ptr %t682, 1
  %t689 = getelementptr { i64, [4 x i64] }, ptr %t683, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t688, ptr %t689
  %t690 = load { i64, [4 x i64] }, ptr %t683
  %t692 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t690, ptr %t692
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i64, ptr %l2, !tbaa !24
  %t697 = getelementptr %"compiler/parse:Parser", ptr %t693, i32 0, i32 22
  store i64 %t694, ptr %t697, !tbaa !24
  %t699 = insertvalue { i32, ptr } zeroinitializer, ptr %t692, 1
  store { i32, ptr } %t699, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i32
  %l58 = alloca i32
  %l65 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 11
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 11
  store i1 true, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 18
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 19
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l3, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 18
  store i1 false, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 19
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 32
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l19
  br label %bb4
bb4:
  %t46 = load i64, ptr %l19, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t47, i32 61)
  store i1 %t50, ptr %l22
  br label %bb6
bb6:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb7, label %bb8
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 32
  store ptr %t54, ptr %l24, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %v0, ptr %t55)
  %t58 = extractvalue { i32, ptr } %t57, 1
  %t59 = extractvalue { i32, ptr } %t57, 0
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb10, label %ok.61, !prof !99
ok.61:
  store ptr %t58, ptr %l27
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t62 = load ptr, ptr %l27, !tbaa !29
  store ptr %t62, ptr %l25, !tbaa !29
  br label %bb11
bb10:
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i1, ptr %l3, !tbaa !21
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 19
  store i1 %t73, ptr %t76, !tbaa !21
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb11:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t79, ptr %t80)
  br label %bb12
bb12:
  br label %bb29
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 32
  store ptr %t83, ptr %l33, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %v0, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb15, label %ok.90, !prof !99
ok.90:
  store ptr %t87, ptr %l36
  br label %bb14
bb14:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb16
bb15:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i1, ptr %l3, !tbaa !21
  %t105 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 19
  store i1 %t102, ptr %t105, !tbaa !21
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t100, 0
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb16:
  %t108 = load ptr, ptr %l33, !tbaa !29
  %t109 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t108, ptr %t109)
  br label %bb17
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t113 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t110, i32 61)
  store i1 %t113, ptr %l43
  br label %bb18
bb18:
  %t114 = load i1, ptr %l43, !tbaa !21
  br i1 %t114, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t115, i32 83)
  %t119 = extractvalue { i32, i1 } %t118, 1
  %t120 = extractvalue { i32, i1 } %t118, 0
  store i32 %t120, ptr %l48
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb23, label %ok.122, !prof !99
ok.122:
  store i1 %t119, ptr %l47
  br label %bb22
bb22:
  %t123 = load i1, ptr %l47, !tbaa !21
  store i1 %t123, ptr %l44, !tbaa !21
  br label %bb24
bb23:
  %t124 = load i32, ptr %l48, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l3, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 19
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t132, 0
  store { i32, { i64, ptr } } %t139, ptr %rv
  br label %ret
bb24:
  %t140 = load i1, ptr %l44, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb5
bb29:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i1, ptr %l2, !tbaa !21
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 18
  store i1 %t144, ptr %t147, !tbaa !21
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l1, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 11
  store i1 %t149, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t153)
  store i32 %t155, ptr %l58
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb31, label %ok.157, !prof !99
ok.157:
  br label %bb30
bb30:
  br label %bb32
bb31:
  %t158 = load i32, ptr %l58, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i1, ptr %l3, !tbaa !21
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t167, i32 0, i32 19
  store i1 %t168, ptr %t171, !tbaa !21
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t166, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/parse:Parser", ptr %t174, i32 0, i32 32
  %t177 = load i64, ptr %l4, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l65
  br label %bb33
bb33:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i1, ptr %l3, !tbaa !21
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 19
  store i1 %t182, ptr %t185, !tbaa !21
  %t186 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t187 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t186, 1
  store { i32, { i64, ptr } } %t187, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 2
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %lp11 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l69 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l79 = alloca i1
  %l82 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l93 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l107 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca i32
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i32
  %l143 = alloca i1
  %l145 = alloca i1
  %l147 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i32
  %l153 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i32
  %l158 = alloca i32
  %l159 = alloca i32
  %l163 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i32
  %l168 = alloca i32
  %l169 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i32
  %l178 = alloca i32
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t46 = alloca { i64, [5 x i64] }, align 8
  %t107 = alloca { i64, [5 x i64] }, align 8
  %t160 = alloca { i64, [5 x i64] }, align 8
  %t291 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i32, ptr %l13, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i32, ptr %l15, !range !{i32 0, i32 98}
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t11 = trunc i64 37 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l19
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t17, i1 false, i1 true, i1 false)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l23
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23, !prof !99
ok.23:
  store ptr %t20, ptr %l22
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l22, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  br label %bb9
bb8:
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  %t35 = insertvalue { i32, ptr } zeroinitializer, i32 %t33, 0
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb9:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t36, ptr %lp3
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load ptr, ptr %lp3
  store ptr %t37, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t39, i32 %t40)
  store %"compiler/source:Span" %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load ptr, ptr %lp3
  %t45 = load ptr, ptr %t44, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 0
  store i64 1, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l27
  %t49 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t48, 0
  %t51 = insertvalue { %"compiler/source:Span", ptr } %t49, ptr %t45, 1
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t51, ptr %t52
  %t53 = load { i64, [5 x i64] }, ptr %t46
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t53, ptr %t55
  %t57 = insertvalue { i32, ptr } zeroinitializer, ptr %t55, 1
  store { i32, ptr } %t57, ptr %rv
  br label %ret
bb11:
  %t58 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t60 = trunc i64 35 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t63 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t65 = trunc i64 34 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t70 = trunc i64 36 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %t73)
  %t76 = extractvalue { i32, ptr } %t75, 1
  %t77 = extractvalue { i32, ptr } %t75, 0
  store i32 %t77, ptr %l40
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb20, label %ok.79, !prof !99
ok.79:
  store ptr %t76, ptr %l39
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l39, !tbaa !29
  store ptr %t80, ptr %l37, !tbaa !29
  br label %bb21
bb20:
  %t81 = load i32, ptr %l40, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb21:
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t92, ptr %lp4
  %t93 = load ptr, ptr %l37, !tbaa !29
  %t94 = load ptr, ptr %lp4
  store ptr %t93, ptr %t94, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t95, i32 %t96)
  store %"compiler/source:Span" %t99, ptr %l44
  br label %bb22
bb22:
  %t100 = load ptr, ptr %lp4
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_47198c3f9d8413cf_be7184982b6f0763)
  unreachable
bb24:
  br label %bb25
bb25:
  %t105 = load ptr, ptr %lp4
  %t106 = load ptr, ptr %t105, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 0
  store i64 2, ptr %t108
  %t109 = load %"compiler/source:Span", ptr %l44
  %t110 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t109, 0
  %t112 = insertvalue { %"compiler/source:Span", ptr } %t110, ptr %t106, 1
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t112, ptr %t113
  %t114 = load { i64, [5 x i64] }, ptr %t107
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t114, ptr %t116
  %t118 = insertvalue { i32, ptr } zeroinitializer, ptr %t116, 1
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb26:
  %t119 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb69
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %t124)
  store i1 %t126, ptr %l53
  br label %bb30
bb30:
  %t127 = load i1, ptr %l53, !tbaa !21
  br i1 %t127, label %bb31, label %bb32
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t128)
  store i32 %t130, ptr %l55
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %t131)
  %t134 = extractvalue { i32, ptr } %t133, 1
  %t135 = extractvalue { i32, ptr } %t133, 0
  store i32 %t135, ptr %l59
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb35, label %ok.137, !prof !99
ok.137:
  store ptr %t134, ptr %l58
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l58, !tbaa !29
  store ptr %t138, ptr %l56, !tbaa !29
  br label %bb36
bb35:
  %t139 = load i32, ptr %l59, !tbaa !23
  %t140 = lshr i32 %t139, 16
  %t141 = and i32 %t139, 65535
  %t142 = icmp eq i32 %t140, 1
  %t143 = select i1 %t142, i32 1, i32 0
  %t144 = icmp eq i32 %t139, 0
  %t145 = shl i32 %t143, 16
  %t146 = or i32 %t145, %t141
  %t147 = select i1 %t144, i32 0, i32 %t146
  %t149 = insertvalue { i32, ptr } zeroinitializer, i32 %t147, 0
  store { i32, ptr } %t149, ptr %rv
  br label %ret
bb36:
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t150, ptr %lp5
  %t151 = load ptr, ptr %l56, !tbaa !29
  %t152 = load ptr, ptr %lp5
  store ptr %t151, ptr %t152, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l1, !tbaa !23
  %t157 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t153, i32 %t154)
  store %"compiler/source:Span" %t157, ptr %l63
  br label %bb37
bb37:
  %t158 = load ptr, ptr %lp5
  %t159 = load ptr, ptr %t158, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 0
  store i64 5, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l63
  %t163 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t162, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t163, ptr %t159, 1
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [5 x i64] }, ptr %t160
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t167, ptr %t169
  %t171 = insertvalue { i32, ptr } zeroinitializer, ptr %t169, 1
  store { i32, ptr } %t171, ptr %rv
  br label %ret
bb38:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/parse:Parser", ptr %t172, i32 0, i32 35
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l69
  br label %bb39
bb39:
  %t177 = load i64, ptr %l69, !tbaa !24
  store i64 %t177, ptr %l6, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/parse:Parser", ptr %t178, i32 0, i32 35
  store ptr %t180, ptr %l71, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t181)
  %t184 = extractvalue { i32, i32 } %t183, 1
  %t185 = extractvalue { i32, i32 } %t183, 0
  store i32 %t185, ptr %l75
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb41, label %ok.187, !prof !99
ok.187:
  store i32 %t184, ptr %l74
  br label %bb40
bb40:
  %t188 = load i32, ptr %l74, !tbaa !23
  store i32 %t188, ptr %l72, !tbaa !23
  br label %bb42
bb41:
  %t189 = load i32, ptr %l75, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  %t199 = insertvalue { i32, ptr } zeroinitializer, i32 %t197, 0
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb42:
  %t200 = load ptr, ptr %l71, !tbaa !29
  %t201 = load i32, ptr %l72, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t200, i32 %t201)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t205 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t202, i32 60)
  store i1 %t205, ptr %l79
  br label %bb45
bb45:
  %t206 = load i1, ptr %l79, !tbaa !21
  %t207 = xor i1 %t206, true
  br i1 %t207, label %bb46, label %bb47
bb46:
  br label %bb55
bb47:
  br label %bb48
bb48:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t209)
  store i32 %t211, ptr %l82
  br label %bb49
bb49:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 35
  store ptr %t214, ptr %l84, !tbaa !29
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t215)
  %t218 = extractvalue { i32, i32 } %t217, 1
  %t219 = extractvalue { i32, i32 } %t217, 0
  store i32 %t219, ptr %l88
  %t220 = icmp ne i32 %t219, 0
  br i1 %t220, label %bb51, label %ok.221, !prof !99
ok.221:
  store i32 %t218, ptr %l87
  br label %bb50
bb50:
  %t222 = load i32, ptr %l87, !tbaa !23
  store i32 %t222, ptr %l85, !tbaa !23
  br label %bb52
bb51:
  %t223 = load i32, ptr %l88, !tbaa !23
  %t224 = lshr i32 %t223, 16
  %t225 = and i32 %t223, 65535
  %t226 = icmp eq i32 %t224, 1
  %t227 = select i1 %t226, i32 1, i32 0
  %t228 = icmp eq i32 %t223, 0
  %t229 = shl i32 %t227, 16
  %t230 = or i32 %t229, %t225
  %t231 = select i1 %t228, i32 0, i32 %t230
  %t233 = insertvalue { i32, ptr } zeroinitializer, i32 %t231, 0
  store { i32, ptr } %t233, ptr %rv
  br label %ret
bb52:
  %t234 = load ptr, ptr %l84, !tbaa !29
  %t235 = load i32, ptr %l85, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t234, i32 %t235)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb44
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 35
  %t239 = load i64, ptr %l6, !tbaa !24
  %t242 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %t238, i64 %t239)
  store { i64, ptr } %t242, ptr %l93
  br label %bb56
bb56:
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t243, ptr %lp7
  %t244 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t245 = load ptr, ptr %lp7
  store { i64, ptr } %t244, ptr %t245, !tbaa !27
  %t246 = icmp sge i64 0, 0
  br i1 %t246, label %bb57, label %bb58
bb57:
  %t248 = icmp sle i64 0, 1152921504606846975
  br i1 %t248, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb59:
  %t250 = mul i64 0, 8
  %t251 = insertvalue { i64, ptr } undef, i64 0, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t253 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t253, ptr %lp8
  %t255 = load ptr, ptr %lp8
  store { i64, ptr } %t252, ptr %t255, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t259 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t256, i32 81)
  store i1 %t259, ptr %l99
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb61:
  %t260 = load i1, ptr %l99, !tbaa !21
  br i1 %t260, label %bb62, label %bb63
bb62:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t261)
  %t264 = extractvalue { i32, { i64, ptr } } %t263, 1
  %t265 = extractvalue { i32, { i64, ptr } } %t263, 0
  store i32 %t265, ptr %l103
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb65, label %ok.267, !prof !99
ok.267:
  store { i64, ptr } %t264, ptr %l102
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t268 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t268, ptr %l100, !tbaa !27
  br label %bb66
bb65:
  %t269 = load i32, ptr %l103, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t279 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb66:
  %t280 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t281 = load ptr, ptr %lp8
  store { i64, ptr } %t280, ptr %t281, !tbaa !27
  br label %bb67
bb67:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l1, !tbaa !23
  %t286 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t282, i32 %t283)
  store %"compiler/source:Span" %t286, ptr %l107
  br label %bb68
bb68:
  %t287 = load ptr, ptr %lp7
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t289 = load ptr, ptr %lp8
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 0
  store i64 0, ptr %t292
  %t293 = load %"compiler/source:Span", ptr %l107
  %t294 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t293, 0
  %t296 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t294, { i64, ptr } %t288, 1
  %t298 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t296, { i64, ptr } %t290, 2
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t298, ptr %t299
  %t300 = load { i64, [5 x i64] }, ptr %t291
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t300, ptr %t302
  %t304 = insertvalue { i32, ptr } zeroinitializer, ptr %t302, 1
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb69:
  %t305 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t307 = trunc i64 92 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb99
bb72:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 42
  store ptr %t312, ptr %l115, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/parse:Parser", ptr %t314, i32 0, i32 6
  %t317 = load i64, ptr %t316, !tbaa !24
  %t320 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t313, i64 %t317)
  store i64 %t320, ptr %l119
  br label %bb73
bb73:
  %t321 = load ptr, ptr %l115, !tbaa !29
  %t322 = load i64, ptr %l119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t321, i64 %t322)
  br label %bb74
bb74:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t323)
  store i32 %t325, ptr %l121
  br label %bb75
bb75:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/parse:Parser", ptr %t326, i32 0, i32 19
  %t329 = load i1, ptr %t328, !tbaa !21
  store i1 %t329, ptr %l9, !tbaa !21
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/parse:Parser", ptr %t331, i32 0, i32 18
  %t334 = load i1, ptr %t333, !tbaa !21
  store i1 %t334, ptr %l10, !tbaa !21
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/parse:Parser", ptr %t336, i32 0, i32 19
  store i1 false, ptr %t338, !tbaa !21
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t339, i32 0, i32 18
  store i1 false, ptr %t341, !tbaa !21
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t342)
  %t345 = extractvalue { i32, ptr } %t344, 1
  %t346 = extractvalue { i32, ptr } %t344, 0
  store i32 %t346, ptr %l131
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb77, label %ok.348, !prof !99
ok.348:
  store ptr %t345, ptr %l130
  br label %bb76
bb76:
  %t349 = load ptr, ptr %l130, !tbaa !29
  store ptr %t349, ptr %l128, !tbaa !29
  br label %bb79
bb77:
  br label %bb78
bb78:
  call void @__olang_ert_req_clear()
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i1, ptr %l9, !tbaa !21
  %t354 = getelementptr %"compiler/parse:Parser", ptr %t350, i32 0, i32 19
  store i1 %t351, ptr %t354, !tbaa !21
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i1, ptr %l10, !tbaa !21
  %t359 = getelementptr %"compiler/parse:Parser", ptr %t355, i32 0, i32 18
  store i1 %t356, ptr %t359, !tbaa !21
  %t361 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t361, ptr %rv
  br label %ret
bb79:
  %t362 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t362, ptr %lp11
  %t363 = load ptr, ptr %l128, !tbaa !29
  %t364 = load ptr, ptr %lp11
  store ptr %t363, ptr %t364, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i1, ptr %l9, !tbaa !21
  %t369 = getelementptr %"compiler/parse:Parser", ptr %t365, i32 0, i32 19
  store i1 %t366, ptr %t369, !tbaa !21
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i1, ptr %l10, !tbaa !21
  %t374 = getelementptr %"compiler/parse:Parser", ptr %t370, i32 0, i32 18
  store i1 %t371, ptr %t374, !tbaa !21
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t378 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t375, i32 93)
  store i1 %t378, ptr %l143
  br label %bb80
bb80:
  %t379 = load i1, ptr %l143, !tbaa !21
  %t380 = xor i1 %t379, true
  br i1 %t380, label %bb81, label %bb82
bb81:
  %t382 = load ptr, ptr %lp11
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = call i1 @compiler_2fparse_2eisFuncType(ptr %v1, ptr %t383)
  store i1 %t385, ptr %l147
  br label %bb83
bb82:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb84
bb83:
  %t386 = load i1, ptr %l147, !tbaa !21
  %t387 = xor i1 %t386, true
  store i1 %t387, ptr %l145, !tbaa !21
  br label %bb84
bb84:
  %t389 = load i1, ptr %l145, !tbaa !21
  br i1 %t389, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s9
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l149, !tbaa !29
  %t391 = load i32, ptr %l1, !tbaa !23
  store i32 %t391, ptr %l150, !tbaa !23
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/parse:Parser", ptr %t392, i32 0, i32 10
  %t395 = load i32, ptr %t394, !tbaa !23
  store i32 %t395, ptr %l152, !tbaa !23
  %t396 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s9)
  store %"compiler/msgs:Msg" %t396, ptr %l153
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t397 = load ptr, ptr %l149, !tbaa !29
  %t398 = load i32, ptr %l150, !tbaa !23
  %t399 = load i32, ptr %l152, !tbaa !23
  %t400 = load %"compiler/msgs:Msg", ptr %l153
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s9, ptr %t397, i32 %t398, i32 %t399, %"compiler/msgs:Msg" %t400)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  %t402 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t402, ptr %rv
  br label %ret
bb89:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t406 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t403, i32 93)
  %t407 = extractvalue { i32, i32 } %t406, 1
  %t408 = extractvalue { i32, i32 } %t406, 0
  store i32 %t408, ptr %l159
  %t409 = icmp ne i32 %t408, 0
  br i1 %t409, label %bb91, label %ok.410, !prof !99
ok.410:
  store i32 %t407, ptr %l158
  br label %bb90
bb90:
  %t411 = load i32, ptr %l158, !tbaa !23
  store i32 %t411, ptr %l155, !tbaa !23
  br label %bb92
bb91:
  %t412 = load i32, ptr %l159, !tbaa !23
  %t413 = lshr i32 %t412, 16
  %t414 = and i32 %t412, 65535
  %t415 = icmp eq i32 %t413, 1
  %t416 = select i1 %t415, i32 1, i32 0
  %t417 = icmp eq i32 %t412, 0
  %t418 = shl i32 %t416, 16
  %t419 = or i32 %t418, %t414
  %t420 = select i1 %t417, i32 0, i32 %t419
  %t422 = insertvalue { i32, ptr } zeroinitializer, i32 %t420, 0
  store { i32, ptr } %t422, ptr %rv
  br label %ret
bb92:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %lp11
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t428 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %t423, ptr %t425)
  store i1 %t428, ptr %l163
  br label %bb93
bb93:
  %t429 = load i1, ptr %l163, !tbaa !21
  %t430 = xor i1 %t429, true
  br i1 %t430, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s10
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l165, !tbaa !29
  %t433 = load i32, ptr %l1, !tbaa !23
  store i32 %t433, ptr %l166, !tbaa !23
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t434, i32 0, i32 10
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l168, !tbaa !23
  %t438 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s10)
  store %"compiler/msgs:Msg" %t438, ptr %l169
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t439 = load ptr, ptr %l165, !tbaa !29
  %t440 = load i32, ptr %l166, !tbaa !23
  %t441 = load i32, ptr %l168, !tbaa !23
  %t442 = load %"compiler/msgs:Msg", ptr %l169
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s10, ptr %t439, i32 %t440, i32 %t441, %"compiler/msgs:Msg" %t442)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s10)
  %t444 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t444, ptr %rv
  br label %ret
bb98:
  %t445 = load ptr, ptr %lp11
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = insertvalue { i32, ptr } zeroinitializer, ptr %t446, 1
  store { i32, ptr } %t448, ptr %rv
  br label %ret
bb99:
  %t449 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t451 = trunc i64 81 to i32
  %t452 = icmp eq i32 %t449, %t451
  br i1 %t452, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb106
bb102:
  store %olang.scope zeroinitializer, ptr %s11
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s11, ptr %t454, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i32 %t456, ptr %l175
  %t457 = icmp ne i32 %t456, 0
  br i1 %t457, label %bb104, label %ok.458, !prof !99
ok.458:
  br label %bb103
bb103:
  br label %bb105
bb104:
  %t459 = load i32, ptr %l175, !tbaa !23
  %t460 = lshr i32 %t459, 16
  %t461 = and i32 %t459, 65535
  %t462 = icmp eq i32 %t460, 1
  %t463 = select i1 %t462, i32 1, i32 0
  %t464 = icmp eq i32 %t459, 0
  %t465 = shl i32 %t463, 16
  %t466 = or i32 %t465, %t461
  %t467 = select i1 %t464, i32 0, i32 %t466
  call void @__olang_scope_close(ptr %s11)
  %t469 = insertvalue { i32, ptr } zeroinitializer, i32 %t467, 0
  store { i32, ptr } %t469, ptr %rv
  br label %ret
bb105:
  call void @__olang_scope_close(ptr %s11)
  br label %bb114
bb106:
  br i1 true, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb113
bb109:
  store %olang.scope zeroinitializer, ptr %s12
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s12, ptr %t470, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i32 %t472, ptr %l178
  %t473 = icmp ne i32 %t472, 0
  br i1 %t473, label %bb111, label %ok.474, !prof !99
ok.474:
  br label %bb110
bb110:
  br label %bb112
bb111:
  %t475 = load i32, ptr %l178, !tbaa !23
  %t476 = lshr i32 %t475, 16
  %t477 = and i32 %t475, 65535
  %t478 = icmp eq i32 %t476, 1
  %t479 = select i1 %t478, i32 1, i32 0
  %t480 = icmp eq i32 %t475, 0
  %t481 = shl i32 %t479, 16
  %t482 = or i32 %t481, %t477
  %t483 = select i1 %t480, i32 0, i32 %t482
  call void @__olang_scope_close(ptr %s12)
  %t485 = insertvalue { i32, ptr } zeroinitializer, i32 %t483, 0
  store { i32, ptr } %t485, ptr %rv
  br label %ret
bb112:
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_31e39d55c126667c_eaaf5fcb81f21700)
  unreachable
bb114:
  call void @__olang_check_failed(ptr @olang_loc_c7048dff8864462d_6ca6baed1a8cf791)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t53 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t5, i32 39)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %t10)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l12
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb4, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l11
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l11, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  br label %bb5
bb4:
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb5:
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t29, ptr %lp3
  %t30 = load ptr, ptr %l9, !tbaa !29
  %t31 = load ptr, ptr %lp3
  store ptr %t30, ptr %t31, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t34 = load ptr, ptr %lp3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t39 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v1, ptr %t32, i32 %t33, ptr %t35)
  store ptr %t39, ptr %l17
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load ptr, ptr %lp3
  store ptr %t40, ptr %t41, !tbaa !29
  %t42 = load i1, ptr %l2, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t44, i32 %t45)
  store %"compiler/source:Span" %t48, ptr %l21
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t49 = load ptr, ptr %lp3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = load i1, ptr %l2, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 0
  store i64 4, ptr %t54
  %t55 = load %"compiler/source:Span", ptr %l21
  %t56 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t55, 0
  %t58 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t56, ptr %t50, 1
  %t60 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t58, i1 %t52, 2
  %t61 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t60, i1 false, 3
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t61, ptr %t62
  %t63 = load { i64, [5 x i64] }, ptr %t53
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t63, ptr %t65
  %t67 = insertvalue { i32, ptr } zeroinitializer, ptr %t65, 1
  store { i32, ptr } %t67, ptr %rv
  br label %ret
bb10:
  %t68 = load ptr, ptr %lp3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t69, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l69 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca %"compiler/source:Span"
  %l88 = alloca i1
  %l90 = alloca i32
  %l94 = alloca i1
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i32
  %l110 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l120 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i32
  %l141 = alloca %"compiler/source:Span"
  %l145 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca i32
  %rv = alloca { i32, ptr }
  %t89 = alloca { i64, [4 x i64] }, align 8
  %t142 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [4 x i64] }, align 8
  %t385 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load i1, ptr %l13, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2espread(ptr %v0, ptr %v1, ptr %t9)
  %t12 = extractvalue { i32, ptr } %t11, 1
  %t13 = extractvalue { i32, ptr } %t11, 0
  store i32 %t13, ptr %l17
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15, !prof !99
ok.15:
  store ptr %t12, ptr %l16
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l16, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  br label %bb7
bb6:
  %t17 = load i32, ptr %l17, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t27 = insertvalue { i32, ptr } zeroinitializer, i32 %t25, 0
  store { i32, ptr } %t27, ptr %rv
  br label %ret
bb7:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = insertvalue { i32, ptr } zeroinitializer, ptr %t28, 1
  store { i32, ptr } %t29, ptr %rv
  br label %ret
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l20
  br label %bb9
bb9:
  %t33 = load i32, ptr %l20, !range !{i32 0, i32 98}
  store i32 %t33, ptr %l2
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t36 = trunc i64 48 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l26
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb15, label %ok.46, !prof !99
ok.46:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t47 = load i32, ptr %l26, !tbaa !23
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 1, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  %t57 = insertvalue { i32, ptr } zeroinitializer, i32 %t55, 0
  store { i32, ptr } %t57, ptr %rv
  br label %ret
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t58, i64 4)
  %t61 = extractvalue { i32, ptr } %t60, 1
  %t62 = extractvalue { i32, ptr } %t60, 0
  store i32 %t62, ptr %l31
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb18, label %ok.64, !prof !99
ok.64:
  store ptr %t61, ptr %l30
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l30, !tbaa !29
  store ptr %t65, ptr %l28, !tbaa !29
  br label %bb20
bb18:
  %t66 = load i32, ptr %l31, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  store i32 %t74, ptr %l32, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t75)
  br label %bb19
bb19:
  %t77 = load i32, ptr %l32, !tbaa !23
  %t78 = insertvalue { i32, ptr } zeroinitializer, i32 %t77, 0
  store { i32, ptr } %t78, ptr %rv
  br label %ret
bb20:
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t79, ptr %lp3
  %t80 = load ptr, ptr %l28, !tbaa !29
  %t81 = load ptr, ptr %lp3
  store ptr %t80, ptr %t81, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t82, i32 %t83)
  store %"compiler/source:Span" %t86, ptr %l36
  br label %bb21
bb21:
  %t87 = load ptr, ptr %lp3
  %t88 = load ptr, ptr %t87, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 0
  store i64 3, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l36
  %t92 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t91, 0
  %t94 = insertvalue { %"compiler/source:Span", i32, ptr } %t92, i32 48, 1
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } %t94, ptr %t88, 2
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t96, ptr %t97
  %t98 = load { i64, [4 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t98, ptr %t100
  store ptr %t100, ptr %l40, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t101)
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l40, !tbaa !29
  %t104 = insertvalue { i32, ptr } zeroinitializer, ptr %t103, 1
  store { i32, ptr } %t104, ptr %rv
  br label %ret
bb23:
  %t105 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t107 = trunc i64 18 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t110)
  store i32 %t112, ptr %l45
  br label %bb27
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t113)
  %t116 = extractvalue { i32, ptr } %t115, 1
  %t117 = extractvalue { i32, ptr } %t115, 0
  store i32 %t117, ptr %l49
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb29, label %ok.119, !prof !99
ok.119:
  store ptr %t116, ptr %l48
  br label %bb28
bb28:
  %t120 = load ptr, ptr %l48, !tbaa !29
  store ptr %t120, ptr %l46, !tbaa !29
  br label %bb30
bb29:
  %t121 = load i32, ptr %l49, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb30:
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t132, ptr %lp4
  %t133 = load ptr, ptr %l46, !tbaa !29
  %t134 = load ptr, ptr %lp4
  store ptr %t133, ptr %t134, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l1, !tbaa !23
  %t139 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t135, i32 %t136)
  store %"compiler/source:Span" %t139, ptr %l53
  br label %bb31
bb31:
  %t140 = load ptr, ptr %lp4
  %t141 = load ptr, ptr %t140, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 0
  store i64 3, ptr %t143
  %t144 = load %"compiler/source:Span", ptr %l53
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t144, 0
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, i32 18, 1
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, ptr %t141, 2
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t149, ptr %t150
  %t151 = load { i64, [4 x i64] }, ptr %t142
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t151, ptr %t153
  %t155 = insertvalue { i32, ptr } zeroinitializer, ptr %t153, 1
  store { i32, ptr } %t155, ptr %rv
  br label %ret
bb32:
  %t156 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t158 = trunc i64 53 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t161 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t163 = trunc i64 88 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t166 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t168 = trunc i64 76 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t171 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t173 = trunc i64 77 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t176)
  store i32 %t178, ptr %l67
  br label %bb42
bb42:
  %t179 = load i32, ptr %l67, !range !{i32 0, i32 98}
  store i32 %t179, ptr %l5
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t180)
  store i32 %t182, ptr %l69
  br label %bb43
bb43:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t183)
  %t186 = extractvalue { i32, ptr } %t185, 1
  %t187 = extractvalue { i32, ptr } %t185, 0
  store i32 %t187, ptr %l73
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb45, label %ok.189, !prof !99
ok.189:
  store ptr %t186, ptr %l72
  br label %bb44
bb44:
  %t190 = load ptr, ptr %l72, !tbaa !29
  store ptr %t190, ptr %l70, !tbaa !29
  br label %bb46
bb45:
  %t191 = load i32, ptr %l73, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 1, i32 0
  %t196 = icmp eq i32 %t191, 0
  %t197 = shl i32 %t195, 16
  %t198 = or i32 %t197, %t193
  %t199 = select i1 %t196, i32 0, i32 %t198
  %t201 = insertvalue { i32, ptr } zeroinitializer, i32 %t199, 0
  store { i32, ptr } %t201, ptr %rv
  br label %ret
bb46:
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t202, ptr %lp6
  %t203 = load ptr, ptr %l70, !tbaa !29
  %t204 = load ptr, ptr %lp6
  store ptr %t203, ptr %t204, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l1, !tbaa !23
  %t209 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t205, i32 %t206)
  store %"compiler/source:Span" %t209, ptr %l77
  br label %bb47
bb47:
  %t210 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t211 = load ptr, ptr %lp6
  %t212 = load ptr, ptr %t211, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l77
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t215, 0
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, i32 %t210, 1
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, ptr %t212, 2
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t213
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t226 = insertvalue { i32, ptr } zeroinitializer, ptr %t224, 1
  store { i32, ptr } %t226, ptr %rv
  br label %ret
bb48:
  %t227 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t229 = trunc i64 5 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t232 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t234 = trunc i64 89 to i32
  %t235 = icmp eq i32 %t232, %t234
  br i1 %t235, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb98
bb53:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t240 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t237, i32 5)
  store i1 %t240, ptr %l88
  br label %bb54
bb54:
  %t241 = load i1, ptr %l88, !tbaa !21
  br i1 %t241, label %bb55, label %bb56
bb55:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t242, i64 1)
  store i32 %t244, ptr %l90
  br label %bb57
bb56:
  br label %bb67
bb57:
  %t245 = load i32, ptr %l90, !range !{i32 0, i32 98}
  store i32 %t245, ptr %l7
  %t246 = load i32, ptr %l7, !range !{i32 0, i32 98}
  %t248 = trunc i64 5 to i32
  %t249 = icmp eq i32 %t246, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb58, label %bb59
bb58:
  %t253 = load i32, ptr %l7, !range !{i32 0, i32 98}
  %t255 = trunc i64 89 to i32
  %t256 = icmp eq i32 %t253, %t255
  %t258 = xor i1 %t256, true
  store i1 %t258, ptr %l94, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb60
bb60:
  %t260 = load i1, ptr %l94, !tbaa !21
  br i1 %t260, label %bb61, label %bb62
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t261)
  %t264 = extractvalue { i32, ptr } %t263, 1
  %t265 = extractvalue { i32, ptr } %t263, 0
  store i32 %t265, ptr %l101
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb64, label %ok.267, !prof !99
ok.267:
  store ptr %t264, ptr %l100
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t268 = load ptr, ptr %l100, !tbaa !29
  store ptr %t268, ptr %l98, !tbaa !29
  br label %bb65
bb64:
  %t269 = load i32, ptr %l101, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t279 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb65:
  %t280 = load ptr, ptr %l98, !tbaa !29
  %t281 = insertvalue { i32, ptr } zeroinitializer, ptr %t280, 1
  store { i32, ptr } %t281, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %v1, ptr %t282)
  %t285 = extractvalue { i32, ptr } %t284, 1
  %t286 = extractvalue { i32, ptr } %t284, 0
  store i32 %t286, ptr %l106
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb69, label %ok.288, !prof !99
ok.288:
  store ptr %t285, ptr %l105
  br label %bb68
bb68:
  %t289 = load ptr, ptr %l105, !tbaa !29
  store ptr %t289, ptr %l103, !tbaa !29
  br label %bb70
bb69:
  %t290 = load i32, ptr %l106, !tbaa !23
  %t291 = lshr i32 %t290, 16
  %t292 = and i32 %t290, 65535
  %t293 = icmp eq i32 %t291, 1
  %t294 = select i1 %t293, i32 1, i32 0
  %t295 = icmp eq i32 %t290, 0
  %t296 = shl i32 %t294, 16
  %t297 = or i32 %t296, %t292
  %t298 = select i1 %t295, i32 0, i32 %t297
  %t300 = insertvalue { i32, ptr } zeroinitializer, i32 %t298, 0
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb70:
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t301, ptr %lp8
  %t302 = load ptr, ptr %l103, !tbaa !29
  %t303 = load ptr, ptr %lp8
  store ptr %t302, ptr %t303, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t307 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t304, i32 5)
  store i1 %t307, ptr %l110
  br label %bb71
bb71:
  %t308 = load i1, ptr %l110, !tbaa !21
  %t309 = xor i1 %t308, true
  br i1 %t309, label %bb72, label %bb73
bb72:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t314 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t311, i32 89)
  store i1 %t314, ptr %l115
  br label %bb74
bb73:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb75
bb74:
  %t315 = load i1, ptr %l115, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l112, !tbaa !21
  br label %bb75
bb75:
  %t318 = load i1, ptr %l112, !tbaa !21
  br i1 %t318, label %bb76, label %bb77
bb76:
  %t319 = load ptr, ptr %lp8
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = insertvalue { i32, ptr } zeroinitializer, ptr %t320, 1
  store { i32, ptr } %t322, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/parse:Parser", ptr %t323, i32 0, i32 30
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t325)
  store i64 %t327, ptr %l120
  br label %bb79
bb79:
  %t328 = load i64, ptr %l120, !tbaa !24
  store i64 %t328, ptr %l9, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t329, i32 0, i32 30
  %t332 = load ptr, ptr %lp8
  %t333 = load ptr, ptr %t332, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t331, ptr %t333)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t339 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t336, i32 5)
  store i1 %t339, ptr %l126
  br label %bb82
bb82:
  %t340 = load i1, ptr %l126, !tbaa !21
  br i1 %t340, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb86
bb84:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t344 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t341, i32 89)
  store i1 %t344, ptr %l130
  br label %bb85
bb85:
  %t345 = load i1, ptr %l130, !tbaa !21
  store i1 %t345, ptr %l127, !tbaa !21
  br label %bb86
bb86:
  %t346 = load i1, ptr %l127, !tbaa !21
  %t347 = xor i1 %t346, true
  br i1 %t347, label %bb87, label %bb88
bb87:
  br label %bb95
bb88:
  br label %bb89
bb89:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/parse:Parser", ptr %t349, i32 0, i32 30
  store ptr %t351, ptr %l133, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %v0, ptr %t352)
  %t355 = extractvalue { i32, ptr } %t354, 1
  %t356 = extractvalue { i32, ptr } %t354, 0
  store i32 %t356, ptr %l137
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb91, label %ok.358, !prof !99
ok.358:
  store ptr %t355, ptr %l136
  br label %bb90
bb90:
  %t359 = load ptr, ptr %l136, !tbaa !29
  store ptr %t359, ptr %l134, !tbaa !29
  br label %bb92
bb91:
  %t360 = load i32, ptr %l137, !tbaa !23
  %t361 = lshr i32 %t360, 16
  %t362 = and i32 %t360, 65535
  %t363 = icmp eq i32 %t361, 1
  %t364 = select i1 %t363, i32 1, i32 0
  %t365 = icmp eq i32 %t360, 0
  %t366 = shl i32 %t364, 16
  %t367 = or i32 %t366, %t362
  %t368 = select i1 %t365, i32 0, i32 %t367
  %t370 = insertvalue { i32, ptr } zeroinitializer, i32 %t368, 0
  store { i32, ptr } %t370, ptr %rv
  br label %ret
bb92:
  %t371 = load ptr, ptr %l133, !tbaa !29
  %t372 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t371, ptr %t372)
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb81
bb95:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l1, !tbaa !23
  %t377 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t373, i32 %t374)
  store %"compiler/source:Span" %t377, ptr %l141
  br label %bb96
bb96:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/parse:Parser", ptr %t378, i32 0, i32 30
  %t381 = load i64, ptr %l9, !tbaa !24
  %t384 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t380, i64 %t381)
  store { i64, ptr } %t384, ptr %l145
  br label %bb97
bb97:
  store { i64, [4 x i64] } zeroinitializer, ptr %t385
  %t386 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 0
  store i64 20, ptr %t386
  %t387 = load %"compiler/source:Span", ptr %l141
  %t388 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t387, 0
  %t389 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t390 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t388, { i64, ptr } %t389, 1
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t390, ptr %t391
  %t392 = load { i64, [4 x i64] }, ptr %t385
  %t394 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t392, ptr %t394
  %t396 = insertvalue { i32, ptr } zeroinitializer, ptr %t394, 1
  store { i32, ptr } %t396, ptr %rv
  br label %ret
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb105
bb101:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epower(ptr %v0, ptr %v1, ptr %t397)
  %t400 = extractvalue { i32, ptr } %t399, 1
  %t401 = extractvalue { i32, ptr } %t399, 0
  store i32 %t401, ptr %l151
  %t402 = icmp ne i32 %t401, 0
  br i1 %t402, label %bb103, label %ok.403, !prof !99
ok.403:
  store ptr %t400, ptr %l150
  br label %bb102
bb102:
  %t404 = load ptr, ptr %l150, !tbaa !29
  store ptr %t404, ptr %l148, !tbaa !29
  br label %bb104
bb103:
  %t405 = load i32, ptr %l151, !tbaa !23
  %t406 = lshr i32 %t405, 16
  %t407 = and i32 %t405, 65535
  %t408 = icmp eq i32 %t406, 1
  %t409 = select i1 %t408, i32 1, i32 0
  %t410 = icmp eq i32 %t405, 0
  %t411 = shl i32 %t409, 16
  %t412 = or i32 %t411, %t407
  %t413 = select i1 %t410, i32 0, i32 %t412
  %t415 = insertvalue { i32, ptr } zeroinitializer, i32 %t413, 0
  store { i32, ptr } %t415, ptr %rv
  br label %ret
bb104:
  %t416 = load ptr, ptr %l148, !tbaa !29
  %t417 = insertvalue { i32, ptr } zeroinitializer, ptr %t416, 1
  store { i32, ptr } %t417, ptr %rv
  br label %ret
bb105:
  call void @__olang_check_failed(ptr @olang_loc_5787450c8afeca22_493a6afca2796a86)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l135 = alloca i1
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l166 = alloca i1
  %l176 = alloca i64
  %l179 = alloca i64
  %l197 = alloca { i64, ptr }
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l206 = alloca i1
  %l207 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l250 = alloca i64
  %l251 = alloca i64
  %l257 = alloca ptr
  %l258 = alloca i64
  %l259 = alloca { i64, ptr }
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca i64
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l277 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l24, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  store i64 %t16, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/parse:Parser", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l29, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l32
  br label %bb1
bb1:
  %t27 = load i64, ptr %l32, !tbaa !24
  %t28 = trunc i64 %t27 to i32
  %t29 = load ptr, ptr %l29, !tbaa !29
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t31, ptr %l34
  br label %bb2
bb2:
  %t32 = load i32, ptr %l34, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp slt i64 %t37, %t46
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/source:Source", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  %t58 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp ne i8 %t63, 10
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb6
bb6:
  %t67 = load i1, ptr %l43, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/source:Source", ptr %t77, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l55, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  store i64 %t81, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  store i64 %t82, ptr %l57, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l58, !tbaa !24
  %t85 = load i64, ptr %l56, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb12, label %bb13
bb12:
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb14:
  %t92 = load i64, ptr %l57, !tbaa !24
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb16:
  %t96 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = sub i64 %t109, %t110
  store i64 %t113, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp sle i64 %t115, 0
  br i1 %t117, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb18:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb20
bb19:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = icmp sge i64 %t119, %t120
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb20
bb20:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  br i1 %t131, label %bb25, label %bb26
bb25:
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = icmp eq i8 %t139, 32
  br i1 %t141, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb29
bb28:
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t143, ptr %l84, !tbaa !27
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 9
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb29
bb29:
  %t153 = load i1, ptr %l83, !tbaa !21
  store i1 %t153, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t154 = load i1, ptr %l78, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t161 = load i64, ptr %l8, !tbaa !24
  store i64 %t161, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l96, !tbaa !27
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp ne i8 %t175, 32
  store i1 %t177, ptr %l95, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l95, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l8, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i8, ptr %t184, i64 %t181
  %t186 = load i8, ptr %t185, !tbaa !32
  %t188 = icmp ne i8 %t186, 9
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t190 = load i1, ptr %l100, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t193 = load i64, ptr %l8, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l8, !tbaa !24
  br label %bb46
bb46:
  br label %bb36
bb47:
  %t197 = load i64, ptr %l8, !tbaa !24
  store i64 %t197, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  %t199 = load i64, ptr %l8, !tbaa !24
  %t200 = load i64, ptr %l7, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t205, ptr %l113, !tbaa !27
  %t206 = load i64, ptr %l8, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i8, ptr %t209, i64 %t206
  %t211 = load i8, ptr %t210, !tbaa !32
  %t213 = icmp eq i8 %t211, 32
  br i1 %t213, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb54
bb51:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb53
bb52:
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t215, ptr %l118, !tbaa !27
  %t216 = load i64, ptr %l8, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t216
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = icmp eq i8 %t221, 9
  store i1 %t223, ptr %l117, !tbaa !21
  br label %bb53
bb53:
  %t225 = load i1, ptr %l117, !tbaa !21
  store i1 %t225, ptr %l112, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l112, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t229 = load i64, ptr %l8, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l8, !tbaa !24
  br label %bb58
bb58:
  br label %bb48
bb59:
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t233, ptr %l125, !tbaa !27
  %t234 = load i64, ptr %l8, !tbaa !24
  store i64 %t234, ptr %l126, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t235, 0
  store i64 %t238, ptr %l129, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l130, !tbaa !24
  %t241 = load i64, ptr %l126, !tbaa !24
  %t242 = icmp sge i64 %t241, 0
  br i1 %t242, label %bb60, label %bb61
bb60:
  %t244 = load i64, ptr %l126, !tbaa !24
  %t245 = load i64, ptr %l129, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb62:
  %t248 = load i64, ptr %l129, !tbaa !24
  %t249 = load i64, ptr %l130, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb64:
  %t252 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = load i64, ptr %l126, !tbaa !24
  %t255 = load i64, ptr %l129, !tbaa !24
  %t256 = getelementptr i8, ptr %t253, i64 %t254
  %t257 = sub i64 %t255, %t254
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t261, ptr %l135
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb66:
  %t262 = load i1, ptr %l135, !tbaa !21
  br i1 %t262, label %bb67, label %bb68
bb67:
  %t263 = load i64, ptr %l8, !tbaa !24
  %t265 = add i64 %t263, 4
  store i64 %t265, ptr %l8, !tbaa !24
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t267 = load i64, ptr %l8, !tbaa !24
  %t268 = load i64, ptr %l7, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  br i1 %t271, label %bb70, label %bb71
bb70:
  %t273 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t273, ptr %l142, !tbaa !27
  %t274 = load i64, ptr %l8, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i8, ptr %t277, i64 %t274
  %t279 = load i8, ptr %t278, !tbaa !32
  %t281 = icmp eq i8 %t279, 32
  store i1 %t281, ptr %l141, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb72
bb72:
  %t283 = load i1, ptr %l141, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t286 = load i64, ptr %l8, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l8, !tbaa !24
  br label %bb76
bb76:
  br label %bb69
bb77:
  br label %bb78
bb78:
  %t290 = load i64, ptr %l8, !tbaa !24
  store i64 %t290, ptr %l11, !tbaa !24
  %t292 = load i64, ptr %l7, !tbaa !24
  store i64 %t292, ptr %l12, !tbaa !24
  br label %bb79
bb79:
  %t294 = load i64, ptr %l12, !tbaa !24
  %t295 = load i64, ptr %l11, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb80, label %bb81
bb80:
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t300, ptr %l155, !tbaa !27
  %t301 = load i64, ptr %l12, !tbaa !24
  %t303 = sub i64 %t301, 1
  %t305 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i8, ptr %t306, i64 %t303
  %t308 = load i8, ptr %t307, !tbaa !32
  %t310 = icmp eq i8 %t308, 32
  store i1 %t310, ptr %l154, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb82
bb82:
  %t312 = load i1, ptr %l154, !tbaa !21
  %t313 = xor i1 %t312, true
  br i1 %t313, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  br label %bb85
bb85:
  %t315 = load i64, ptr %l12, !tbaa !24
  %t317 = sub i64 %t315, 1
  store i64 %t317, ptr %l12, !tbaa !24
  br label %bb86
bb86:
  br label %bb79
bb87:
  %t319 = load i64, ptr %l10, !tbaa !24
  %t320 = load i64, ptr %l9, !tbaa !24
  %t323 = icmp eq i64 %t319, %t320
  br i1 %t323, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb90
bb89:
  %t325 = load i64, ptr %l12, !tbaa !24
  %t326 = load i64, ptr %l11, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  store i1 %t329, ptr %l166, !tbaa !21
  br label %bb90
bb90:
  %t331 = load i1, ptr %l166, !tbaa !21
  br i1 %t331, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t333 = load i64, ptr %l9, !tbaa !24
  store i64 %t333, ptr %l13, !tbaa !24
  %t335 = load i64, ptr %l7, !tbaa !24
  store i64 %t335, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l14, !tbaa !24
  %t338 = load i64, ptr %l13, !tbaa !24
  %t341 = icmp sgt i64 %t337, %t338
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = load i64, ptr %l15, !tbaa !24
  %t345 = icmp sgt i64 %t343, 0
  br i1 %t345, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb99
bb96:
  %t347 = load i64, ptr %l14, !tbaa !24
  %t348 = load i64, ptr %l13, !tbaa !24
  %t351 = sub i64 %t347, %t348
  %t352 = load i64, ptr %l15, !tbaa !24
  %t355 = add i64 %t351, %t352
  %t357 = sub i64 %t355, 1
  %t358 = load i64, ptr %l15, !tbaa !24
  %t361 = sdiv i64 %t357, %t358
  store i64 %t361, ptr %l179, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb98
bb98:
  %t363 = load i64, ptr %l179, !tbaa !24
  store i64 %t363, ptr %l176, !tbaa !24
  br label %bb99
bb99:
  %t364 = load i64, ptr %l176, !tbaa !24
  store i64 %t364, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb100
bb100:
  %t365 = load i64, ptr %l17, !tbaa !24
  %t366 = load i64, ptr %l16, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb101, label %bb102
bb101:
  br label %bb114
bb102:
  br label %bb103
bb103:
  %t373 = load i64, ptr %l13, !tbaa !24
  %t374 = load i64, ptr %l17, !tbaa !24
  %t375 = load i64, ptr %l15, !tbaa !24
  %t378 = mul i64 %t374, %t375
  %t381 = add i64 %t373, %t378
  store i64 %t381, ptr %l18, !tbaa !24
  %t383 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t383, ptr %l197, !tbaa !27
  %t384 = load i64, ptr %l18, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i8, ptr %t387, i64 %t384
  %t389 = load i8, ptr %t388, !tbaa !32
  %t391 = icmp eq i8 %t389, 61
  br i1 %t391, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb106
bb105:
  %t393 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t393, ptr %l202, !tbaa !27
  %t394 = load i64, ptr %l18, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i8, ptr %t397, i64 %t394
  %t399 = load i8, ptr %t398, !tbaa !32
  %t401 = icmp eq i8 %t399, 58
  store i1 %t401, ptr %l201, !tbaa !21
  br label %bb106
bb106:
  %t403 = load i1, ptr %l201, !tbaa !21
  br i1 %t403, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb109
bb108:
  %t404 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t404, ptr %l207, !tbaa !27
  %t405 = load i64, ptr %l18, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i8, ptr %t408, i64 %t405
  %t410 = load i8, ptr %t409, !tbaa !32
  %t412 = icmp eq i8 %t410, 40
  store i1 %t412, ptr %l206, !tbaa !21
  br label %bb109
bb109:
  %t414 = load i1, ptr %l206, !tbaa !21
  br i1 %t414, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t416 = load i64, ptr %l17, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l17, !tbaa !24
  br label %bb100
bb114:
  store i64 0, ptr %l19, !tbaa !24
  %t420 = load i64, ptr %l7, !tbaa !24
  store i64 %t420, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l6, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb116, label %bb117
bb116:
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t430 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t430, ptr %l219, !tbaa !27
  %t431 = load i64, ptr %l20, !tbaa !24
  %t433 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr i8, ptr %t434, i64 %t431
  %t436 = load i8, ptr %t435, !tbaa !32
  %t438 = icmp eq i8 %t436, 40
  br i1 %t438, label %bb119, label %bb120
bb119:
  %t440 = load i64, ptr %l19, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l19, !tbaa !24
  br label %bb127
bb120:
  %t444 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t444, ptr %l225, !tbaa !27
  %t445 = load i64, ptr %l20, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr i8, ptr %t448, i64 %t445
  %t450 = load i8, ptr %t449, !tbaa !32
  %t452 = icmp eq i8 %t450, 41
  br i1 %t452, label %bb121, label %bb122
bb121:
  %t454 = load i64, ptr %l19, !tbaa !24
  %t456 = sub i64 %t454, 1
  store i64 %t456, ptr %l19, !tbaa !24
  %t458 = load i64, ptr %l19, !tbaa !24
  %t460 = icmp eq i64 %t458, 0
  br i1 %t460, label %bb123, label %bb124
bb122:
  br label %bb126
bb123:
  br label %bb129
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t462 = load i64, ptr %l20, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l20, !tbaa !24
  br label %bb128
bb128:
  br label %bb115
bb129:
  %t466 = load i64, ptr %l20, !tbaa !24
  %t467 = load i64, ptr %l6, !tbaa !24
  %t470 = icmp sge i64 %t466, %t467
  br i1 %t470, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t473 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t473, ptr %l239, !tbaa !27
  %t474 = load i64, ptr %l11, !tbaa !24
  store i64 %t474, ptr %l240, !tbaa !24
  %t475 = load i64, ptr %l12, !tbaa !24
  store i64 %t475, ptr %l241, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  store i64 %t477, ptr %l242, !tbaa !24
  %t478 = load i64, ptr %l240, !tbaa !24
  %t479 = icmp sge i64 %t478, 0
  br i1 %t479, label %bb133, label %bb134
bb133:
  %t481 = load i64, ptr %l240, !tbaa !24
  %t482 = load i64, ptr %l241, !tbaa !24
  %t483 = icmp sle i64 %t481, %t482
  br i1 %t483, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb135:
  %t485 = load i64, ptr %l241, !tbaa !24
  %t486 = load i64, ptr %l242, !tbaa !24
  %t487 = icmp sle i64 %t485, %t486
  br i1 %t487, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb137:
  %t489 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l240, !tbaa !24
  %t492 = load i64, ptr %l241, !tbaa !24
  %t493 = getelementptr i8, ptr %t490, i64 %t491
  %t494 = sub i64 %t492, %t491
  %t495 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t493, 1
  store { i64, ptr } %t496, ptr %l246, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t497, ptr %l247, !tbaa !27
  %t498 = load i64, ptr %l7, !tbaa !24
  store i64 %t498, ptr %l248, !tbaa !24
  %t499 = load i64, ptr %l20, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l250, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l251, !tbaa !24
  %t504 = load i64, ptr %l248, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb139:
  %t507 = load i64, ptr %l248, !tbaa !24
  %t508 = load i64, ptr %l250, !tbaa !24
  %t509 = icmp sle i64 %t507, %t508
  br i1 %t509, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb141:
  %t511 = load i64, ptr %l250, !tbaa !24
  %t512 = load i64, ptr %l251, !tbaa !24
  %t513 = icmp sle i64 %t511, %t512
  br i1 %t513, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb143:
  %t515 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = load i64, ptr %l248, !tbaa !24
  %t518 = load i64, ptr %l250, !tbaa !24
  %t519 = getelementptr i8, ptr %t516, i64 %t517
  %t520 = sub i64 %t518, %t517
  %t521 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t519, 1
  %t523 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 1
  %t525 = extractvalue { i64, ptr } %t523, 0
  %t527 = extractvalue { i64, ptr } %t522, 1
  %t528 = extractvalue { i64, ptr } %t522, 0
  %t529 = add i64 %t525, %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t524, i64 %t525)
  %t531 = getelementptr i8, ptr %t530, i64 %t525
  call void @olang_textcopy(ptr %t531, ptr %t527, i64 %t528)
  %t532 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  store { i64, ptr } %t533, ptr %l21, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l257, !tbaa !29
  %t536 = load i64, ptr %l1, !tbaa !24
  store i64 %t536, ptr %l258, !tbaa !24
  %t537 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t537, ptr %l259, !tbaa !27
  %t538 = load i64, ptr %l9, !tbaa !24
  store i64 %t538, ptr %l260, !tbaa !24
  %t539 = load i64, ptr %l12, !tbaa !24
  store i64 %t539, ptr %l261, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 0
  store i64 %t541, ptr %l262, !tbaa !24
  %t542 = load i64, ptr %l260, !tbaa !24
  %t543 = icmp sge i64 %t542, 0
  br i1 %t543, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb145:
  %t545 = load i64, ptr %l260, !tbaa !24
  %t546 = load i64, ptr %l261, !tbaa !24
  %t547 = icmp sle i64 %t545, %t546
  br i1 %t547, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb147:
  %t549 = load i64, ptr %l261, !tbaa !24
  %t550 = load i64, ptr %l262, !tbaa !24
  %t551 = icmp sle i64 %t549, %t550
  br i1 %t551, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb149:
  %t553 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = load i64, ptr %l260, !tbaa !24
  %t556 = load i64, ptr %l261, !tbaa !24
  %t557 = getelementptr i8, ptr %t554, i64 %t555
  %t558 = sub i64 %t556, %t555
  %t559 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t557, 1
  store { i64, ptr } %t560, ptr %l266, !tbaa !27
  %t561 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t561, ptr %l267, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t562, ptr %l268, !tbaa !27
  %t563 = load i64, ptr %l9, !tbaa !24
  store i64 %t563, ptr %l269, !tbaa !24
  %t564 = load i64, ptr %l10, !tbaa !24
  store i64 %t564, ptr %l270, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  store i64 %t566, ptr %l271, !tbaa !24
  %t567 = load i64, ptr %l269, !tbaa !24
  %t568 = icmp sge i64 %t567, 0
  br i1 %t568, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb151:
  %t570 = load i64, ptr %l269, !tbaa !24
  %t571 = load i64, ptr %l270, !tbaa !24
  %t572 = icmp sle i64 %t570, %t571
  br i1 %t572, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb153:
  %t574 = load i64, ptr %l270, !tbaa !24
  %t575 = load i64, ptr %l271, !tbaa !24
  %t576 = icmp sle i64 %t574, %t575
  br i1 %t576, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb155:
  %t578 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = load i64, ptr %l269, !tbaa !24
  %t581 = load i64, ptr %l270, !tbaa !24
  %t582 = getelementptr i8, ptr %t579, i64 %t580
  %t583 = sub i64 %t581, %t580
  %t584 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t582, 1
  %t586 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t587 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t591 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t587, { i64, ptr } %t588, { i64, ptr } %t585, { i64, ptr } %t586)
  store %"compiler/msgs:Msg" %t591, ptr %l277
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb157:
  %t592 = load ptr, ptr %l257, !tbaa !29
  %t593 = load i64, ptr %l258, !tbaa !24
  %t594 = load %"compiler/msgs:Msg", ptr %l277
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s0, ptr %t592, i64 %t593, %"compiler/msgs:Msg" %t594)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %lp13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l31 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca %"compiler/ast:VarDecl"
  %l99 = alloca { i64, ptr }
  %l104 = alloca i32
  %l107 = alloca %"compiler/source:Span"
  %l111 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l120 = alloca i32
  %l126 = alloca i32
  %rv = alloca { i32, ptr }
  %t147 = alloca i64
  %t165 = alloca i64
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t262 = alloca { i64, [4 x i64] }, align 8
  %t280 = alloca { i64, [4 x i64] }, align 8
  %t311 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 12
  %t6 = load i1, ptr %t5, !tbaa !21
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i1 %t6)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l21
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  store ptr %t11, ptr %l20
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l20, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb3:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t27, ptr %lp3
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %lp3
  store ptr %t28, ptr %t29, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t30, i32 %a1)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb4
bb4:
  %t35 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t35, ptr %l4
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 12
  %t39 = load i1, ptr %t38, !tbaa !21
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t41, i32 59)
  store i1 %t44, ptr %l31
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  %t45 = load i1, ptr %l31, !tbaa !21
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l28, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/parse:NameList", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp sgt i64 %t54, 1
  br i1 %t56, label %bb11, label %bb12
bb10:
  br label %bb51
bb11:
  %t58 = load ptr, ptr %lp3
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/ast:VarDecl", ptr %t59, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp eq i64 %t64, 0
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = sub i64 %t69, 1
  store i64 %t71, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb16, label %bb17
bb15:
  br label %bb49
bb16:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb18:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l50, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l47, !tbaa !24
  store i64 %t100, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  br label %bb45
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l11, !tbaa !24
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/parse:NameList", ptr %t119, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l69, !tbaa !27
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i64 %t123
  %t128 = load %"compiler/source:Span", ptr %t127
  store %"compiler/source:Span" %t128, ptr %l12
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/parse:NameList", ptr %t130, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l73, !tbaa !27
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 %t134
  %t139 = load i32, ptr %t138, !tbaa !33
  store i32 %t139, ptr %l75, !tbaa !23
  %t140 = icmp sge i64 1, 0
  br i1 %t140, label %bb26, label %bb27
bb26:
  %t142 = icmp sle i64 1, 2305843009213693951
  br i1 %t142, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb28:
  %t144 = mul i64 1, 4
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = load i32, ptr %l75, !tbaa !23
  store i64 0, ptr %t147
  br label %fill.148
fill.148:
  %t151 = load i64, ptr %t147
  %t152 = icmp slt i64 %t151, 1
  br i1 %t152, label %fillb.149, label %filld.150
fillb.149:
  %t153 = getelementptr i32, ptr %t145, i64 %t151
  store i32 %t146, ptr %t153
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %t147
  br label %fill.148
filld.150:
  %t155 = insertvalue { i64, ptr } undef, i64 1, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t145, 1
  store { i64, ptr } %t156, ptr %l78, !tbaa !27
  %t157 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t157, ptr %l79
  %t158 = icmp sge i64 1, 0
  br i1 %t158, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb30:
  %t160 = icmp sle i64 1, 1152921504606846975
  br i1 %t160, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb32:
  %t162 = mul i64 1, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = load %"compiler/source:Span", ptr %l79
  store i64 0, ptr %t165
  br label %fill.166
fill.166:
  %t169 = load i64, ptr %t165
  %t170 = icmp slt i64 %t169, 1
  br i1 %t170, label %fillb.167, label %filld.168
fillb.167:
  %t171 = getelementptr %"compiler/source:Span", ptr %t163, i64 %t169
  store %"compiler/source:Span" %t164, ptr %t171
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %t165
  br label %fill.166
filld.168:
  %t173 = insertvalue { i64, ptr } undef, i64 1, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t163, 1
  store { i64, ptr } %t174, ptr %l82, !tbaa !27
  %t175 = icmp sge i64 0, 0
  br i1 %t175, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb34:
  %t177 = icmp sle i64 0, 1152921504606846975
  br i1 %t177, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb36:
  %t179 = mul i64 0, 8
  %t180 = insertvalue { i64, ptr } undef, i64 0, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t181, ptr %l85, !tbaa !27
  %t182 = icmp sge i64 0, 0
  br i1 %t182, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb38:
  %t184 = icmp sle i64 0, 1152921504606846975
  br i1 %t184, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3fc06d3a68dac511_cf4e4a3339a21d5d)
  unreachable
bb40:
  %t186 = mul i64 0, 8
  %t187 = insertvalue { i64, ptr } undef, i64 0, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t189 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t193 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t189, { i64, ptr } %t190, ptr null, { i64, ptr } %t191, i1 false, i1 true, { i64, ptr } %t188, i1 false)
  store %"compiler/ast:VarDecl" %t193, ptr %l89
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_3fc06d3a68dac511_cf4e4a3339a21d5d)
  unreachable
bb42:
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store ptr %t194, ptr %lp13
  %t195 = load %"compiler/ast:VarDecl", ptr %l89
  %t196 = load ptr, ptr %lp13
  store %"compiler/ast:VarDecl" %t195, ptr %t196
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/parse:Parser", ptr %t197, i32 0, i32 31
  %t200 = load %"compiler/source:Span", ptr %l12
  %t201 = load ptr, ptr %lp13
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 1, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t200, 0
  %t207 = insertvalue { %"compiler/source:Span", ptr } %t205, ptr %t201, 1
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t207, ptr %t208
  %t209 = load { i64, [4 x i64] }, ptr %t202
  %t211 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t209, ptr %t211
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t199, ptr %t211)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t214 = load i64, ptr %l10, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb22
bb45:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/parse:NameList", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l99, !tbaa !27
  %t222 = load i64, ptr %l5, !tbaa !24
  %t224 = sub i64 %t222, 1
  %t226 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr %"compiler/source:Span", ptr %t227, i64 %t224
  %t229 = load %"compiler/source:Span", ptr %t228
  store %"compiler/source:Span" %t229, ptr %l14
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t231)
  store i32 %t233, ptr %l104
  br label %bb46
bb46:
  %t234 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t237 = load i32, ptr %t236, !tbaa !23
  %t240 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t235, i32 %t237)
  store %"compiler/source:Span" %t240, ptr %l107
  br label %bb47
bb47:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %lp3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"compiler/parse:NameList", ptr %t244, i32 0, i32 0
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l111, !tbaa !27
  %t248 = load i64, ptr %l5, !tbaa !24
  %t250 = sub i64 %t248, 1
  %t252 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i32, ptr %t253, i64 %t250
  %t255 = load i32, ptr %t254, !tbaa !33
  %t256 = load %"compiler/source:Span", ptr %l14
  %t261 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %v2, ptr %v2, ptr %t241, ptr %t243, i32 %t255, %"compiler/source:Span" %t256)
  store ptr %t261, ptr %l116
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t262, i32 0, i32 0
  store i64 1, ptr %t263
  %t264 = load %"compiler/source:Span", ptr %l107
  %t265 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t264, 0
  %t266 = load ptr, ptr %l116, !tbaa !29
  %t267 = insertvalue { %"compiler/source:Span", ptr } %t265, ptr %t266, 1
  %t268 = getelementptr { i64, [4 x i64] }, ptr %t262, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t267, ptr %t268
  %t269 = load { i64, [4 x i64] }, ptr %t262
  %t271 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t269, ptr %t271
  %t273 = insertvalue { i32, ptr } zeroinitializer, ptr %t271, 1
  store { i32, ptr } %t273, ptr %rv
  br label %ret
bb49:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t274)
  store i32 %t276, ptr %l120
  br label %bb50
bb50:
  %t277 = load %"compiler/source:Span", ptr %l4
  %t278 = load ptr, ptr %lp3
  %t279 = load ptr, ptr %t278, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t280
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 0
  store i64 1, ptr %t281
  %t283 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t277, 0
  %t285 = insertvalue { %"compiler/source:Span", ptr } %t283, ptr %t279, 1
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t285, ptr %t286
  %t287 = load { i64, [4 x i64] }, ptr %t280
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t287, ptr %t289
  %t291 = insertvalue { i32, ptr } zeroinitializer, ptr %t289, 1
  store { i32, ptr } %t291, ptr %rv
  br label %ret
bb51:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t292)
  store i32 %t294, ptr %l126
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb53, label %ok.296, !prof !99
ok.296:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t297 = load i32, ptr %l126, !tbaa !23
  %t298 = lshr i32 %t297, 16
  %t299 = and i32 %t297, 65535
  %t300 = icmp eq i32 %t298, 1
  %t301 = select i1 %t300, i32 1, i32 0
  %t302 = icmp eq i32 %t297, 0
  %t303 = shl i32 %t301, 16
  %t304 = or i32 %t303, %t299
  %t305 = select i1 %t302, i32 0, i32 %t304
  %t307 = insertvalue { i32, ptr } zeroinitializer, i32 %t305, 0
  store { i32, ptr } %t307, ptr %rv
  br label %ret
bb54:
  %t308 = load %"compiler/source:Span", ptr %l4
  %t309 = load ptr, ptr %lp3
  %t310 = load ptr, ptr %t309, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 0
  store i64 1, ptr %t312
  %t314 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t308, 0
  %t316 = insertvalue { %"compiler/source:Span", ptr } %t314, ptr %t310, 1
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t316, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t311
  %t320 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t318, ptr %t320
  %t322 = insertvalue { i32, ptr } zeroinitializer, ptr %t320, 1
  store { i32, ptr } %t322, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2eisAssignOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 62 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 65 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t13 = trunc i64 66 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t18 = trunc i64 67 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t23 = trunc i64 69 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb37
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t28 = trunc i64 68 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb37
bb16:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t33 = trunc i64 70 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t38 = trunc i64 71 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t43 = trunc i64 72 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t48 = trunc i64 73 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t53 = trunc i64 74 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb37
bb28:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t58 = trunc i64 75 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_6ff476a4e2a6097a_2b56ab96df058916)
  unreachable
bb37:
  %t61 = load i1, ptr %l1, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94ee529efe0ddf52_d9208d758fca575e)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOperandEndTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 93 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 95 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 2 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t26 = trunc i64 3 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t38 = trunc i64 6 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t44 = trunc i64 7 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOrdering(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 81 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 82 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 83 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 84 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eleavingWord(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 13 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 19 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 38 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 9 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb35
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t10 = trunc i64 25 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t15 = trunc i64 26 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  br label %bb35
bb10:
  %t20 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t22 = trunc i64 31 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %l1, !tbaa !27
  br label %bb35
bb14:
  %t27 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t29 = trunc i64 96 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb35
bb18:
  %t34 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t36 = trunc i64 14 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l1, !tbaa !27
  br label %bb35
bb22:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t43 = trunc i64 16 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  br label %bb35
bb26:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t50 = trunc i64 17 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l1, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6)
  unreachable
bb35:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l34, !tbaa !24
  %t59 = load i64, ptr %l34, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l35, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = mul i64 %t68, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t70, ptr %l1, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l28
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb77
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t29 = load ptr, ptr %l30, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32 }, ptr %t39, i32 0, i32 0
  %t41 = load %"compiler/source:Span", ptr %t40
  store %"compiler/source:Span" %t41, ptr %l4
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %l36, !tbaa !27
  %t44 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l40, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l41, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb15:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l41, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb17:
  %t65 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = getelementptr i8, ptr %t66, i64 %t67
  %t70 = sub i64 %t68, %t67
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = extractvalue { i64, ptr } %t72, 0
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t74, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l19, !tbaa !27
  br label %bb77
bb18:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 30}
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t96, { i64, ptr } %t97)
  store { i64, ptr } %t101, ptr %l56
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t102, ptr %l19, !tbaa !27
  br label %bb77
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 30}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 98}
  store i32 %t116, ptr %l6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t126 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t124)
  store { i64, ptr } %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s6, ptr %t127, ptr %t128, { i64, ptr } %t129)
  store { i64, ptr } %t133, ptr %l70
  br label %bb33
bb33:
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  store { i64, ptr } %t156, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb77
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t159 = load ptr, ptr %l72, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l72, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 30}
  %t165 = icmp eq i64 %t163, 5
  store i1 %t165, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l73, !tbaa !21
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load i32, ptr %t170, !range !{i32 0, i32 98}
  store i32 %t171, ptr %l8
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t181, i32 0, i32 3
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t187 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t185)
  store { i64, ptr } %t187, ptr %l83
  br label %bb40
bb40:
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t188, ptr %t189, { i64, ptr } %t190)
  store { i64, ptr } %t194, ptr %l87
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t195, ptr %t196, { i64, ptr } %t197)
  store { i64, ptr } %t201, ptr %l91
  br label %bb42
bb42:
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t204 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t202, i64 %t203)
  %t226 = getelementptr i8, ptr %t225, i64 %t203
  call void @olang_textcopy(ptr %t226, ptr %t205, i64 %t206)
  %t227 = getelementptr i8, ptr %t226, i64 %t206
  call void @olang_textcopy(ptr %t227, ptr %t208, i64 %t209)
  %t228 = getelementptr i8, ptr %t227, i64 %t209
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t215, i64 %t216)
  %t230 = getelementptr i8, ptr %t229, i64 %t216
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t225, 1
  store { i64, ptr } %t233, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb77
bb43:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t236 = load ptr, ptr %l93, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l93, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 30}
  %t242 = icmp eq i64 %t240, 7
  store i1 %t242, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t243 = load i1, ptr %l94, !tbaa !21
  br i1 %t243, label %bb46, label %bb47
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/ast:Chain", ptr %t250, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t259 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t260 = add i64 %t257, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t256, i64 %t257)
  %t265 = getelementptr i8, ptr %t264, i64 %t257
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t255)
  %t267 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t267, ptr %t261, i64 %t262)
  %t268 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t264, 1
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  br label %bb77
bb49:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t272 = load ptr, ptr %l103, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb50, label %bb51
bb50:
  %t275 = load ptr, ptr %l103, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 30}
  %t278 = icmp eq i64 %t276, 8
  store i1 %t278, ptr %l104, !tbaa !21
  br label %bb51
bb51:
  %t279 = load i1, ptr %l104, !tbaa !21
  br i1 %t279, label %bb52, label %bb53
bb52:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l12, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l13, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t294, i32 0, i32 3
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l14, !tbaa !29
  br label %bb54
bb53:
  br label %bb58
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t298, ptr %t299, { i64, ptr } %t300)
  store { i64, ptr } %t304, ptr %l116
  br label %bb55
bb55:
  %t305 = load ptr, ptr %l12, !tbaa !29
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t305, ptr %t306, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l120
  br label %bb56
bb56:
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t318 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t312, ptr %t313, { i64, ptr } %t314)
  store { i64, ptr } %t318, ptr %l124
  br label %bb57
bb57:
  %t319 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t321 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t319, i64 %t320)
  %t343 = getelementptr i8, ptr %t342, i64 %t320
  call void @olang_textcopy(ptr %t343, ptr %t322, i64 %t323)
  %t344 = getelementptr i8, ptr %t343, i64 %t323
  call void @olang_textcopy(ptr %t344, ptr %t325, i64 %t326)
  %t345 = getelementptr i8, ptr %t344, i64 %t326
  call void @olang_textcopy(ptr %t345, ptr %t329, i64 %t330)
  %t346 = getelementptr i8, ptr %t345, i64 %t330
  call void @olang_textcopy(ptr %t346, ptr %t332, i64 %t333)
  %t347 = getelementptr i8, ptr %t346, i64 %t333
  call void @olang_textcopy(ptr %t347, ptr %t336, i64 %t337)
  %t348 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t348, ptr %t339, i64 %t340)
  %t349 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t342, 1
  store { i64, ptr } %t350, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb58:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t353 = load ptr, ptr %l126, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb59, label %bb60
bb59:
  %t356 = load ptr, ptr %l126, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 30}
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l127, !tbaa !21
  br label %bb60
bb60:
  %t360 = load i1, ptr %l127, !tbaa !21
  br i1 %t360, label %bb61, label %bb62
bb61:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l15, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370
  store { i64, ptr } %t371, ptr %l16, !tbaa !27
  br label %bb63
bb62:
  br label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t373 = load ptr, ptr %l15, !tbaa !29
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t373, ptr %t374, { i64, ptr } %t375)
  store { i64, ptr } %t379, ptr %l137
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t385 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t394 = add i64 %t391, %t393
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t397 = add i64 %t394, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t383, i64 %t384)
  %t399 = getelementptr i8, ptr %t398, i64 %t384
  call void @olang_textcopy(ptr %t399, ptr %t386, i64 %t387)
  %t400 = getelementptr i8, ptr %t399, i64 %t387
  call void @olang_textcopy(ptr %t400, ptr %t389, i64 %t390)
  %t401 = getelementptr i8, ptr %t400, i64 %t390
  %t402 = call i64 @__olang_fmt_i64(ptr %t401, i64 %t382)
  %t403 = getelementptr i8, ptr %t401, i64 %t393
  call void @olang_textcopy(ptr %t403, ptr %t395, i64 %t396)
  %t404 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t398, 1
  store { i64, ptr } %t405, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb65:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t408 = load ptr, ptr %l141, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb66, label %bb67
bb66:
  %t411 = load ptr, ptr %l141, !tbaa !29
  %t412 = load i64, ptr %t411, !range !{i64 0, i64 30}
  %t414 = icmp eq i64 %t412, 13
  store i1 %t414, ptr %l142, !tbaa !21
  br label %bb67
bb67:
  %t415 = load i1, ptr %l142, !tbaa !21
  br i1 %t415, label %bb68, label %bb69
bb68:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t418, i32 0, i32 1
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l17, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t424, i32 0, i32 2
  %t426 = load { i64, ptr }, ptr %t425
  store { i64, ptr } %t426, ptr %l18, !tbaa !27
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t428 = load ptr, ptr %l17, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t434 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s16, ptr %t428, ptr %t429, { i64, ptr } %t430)
  store { i64, ptr } %t434, ptr %l152
  br label %bb71
bb71:
  %t435 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t440 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t437)
  %t449 = add i64 %t446, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t438, i64 %t439)
  %t454 = getelementptr i8, ptr %t453, i64 %t439
  call void @olang_textcopy(ptr %t454, ptr %t441, i64 %t442)
  %t455 = getelementptr i8, ptr %t454, i64 %t442
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  %t457 = call i64 @__olang_fmt_i64(ptr %t456, i64 %t437)
  %t458 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t458, ptr %t450, i64 %t451)
  %t459 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t453, 1
  store { i64, ptr } %t460, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l156, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t462, ptr %l19, !tbaa !27
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_a6e4b06ca3f2f7b3_b26c102023f13b6f)
  unreachable
bb77:
  %t464 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l158, !tbaa !24
  %t466 = load i64, ptr %l158, !tbaa !24
  %t467 = mul i64 %t466, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l159, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = load i64, ptr %l158, !tbaa !24
  %t476 = mul i64 %t475, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t472, ptr %t474, i64 %t476, i1 false)
  %t477 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t477, ptr %l19, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca %"compiler/source:Source"
  %l4 = alloca %"compiler/source:Names"
  %l5 = alloca %"compiler/parse:Oracle"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca i64
  %l12 = alloca %"compiler/scan:Tokens"
  %l13 = alloca %"compiler/parse:Parser"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/diag:Said"
  %l36 = alloca %"compiler/source:Source"
  %l37 = alloca %"compiler/source:Names"
  %l38 = alloca %"compiler/parse:Oracle"
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diag:Diagnostics"
  %l62 = alloca i64
  %l64 = alloca %"compiler/scan:Tokens"
  %l71 = alloca %"compiler/parse:Parser"
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"std/prelude/text:StringBuilder"
  %l84 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i1
  %l97 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i1
  %l134 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i1
  %l156 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l177 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l179 = alloca i64
  %l181 = alloca i64
  %l186 = alloca %"compiler/diag:Said"
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t7 = alloca %"compiler/parse:Oracle", align 8
  %t46 = alloca %"compiler/diag:Diagnostics", align 8
  %t62 = alloca %"compiler/parse:Parser", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } %a0)
  store %"compiler/source:Source" %t3, ptr %l36
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Source", ptr %l36
  store %"compiler/source:Source" %t4, ptr %l3
  %t5 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t5, ptr %l37
  br label %bb2
bb2:
  %t6 = load %"compiler/source:Names", ptr %l37
  store %"compiler/source:Names" %t6, ptr %l4
  call void @compiler_2fparse_3aOracle_2ector(ptr %t7, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t7, i64 288, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l38, i64 288, i1 false)
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s1, ptr %s1, { i64, ptr } %a1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t10, ptr %l40
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t24, ptr %l47, !tbaa !27
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %s0, ptr %s0, ptr %s3, ptr %s1, ptr %l5, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, { i64, ptr } %t38)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb5
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t46, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t46, i64 512, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l58, i64 512, i1 false)
  %t47 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t54 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t48, { i64, ptr } %t50, i1 false)
  store i64 %t54, ptr %l62
  br label %bb16
bb16:
  %t55 = load i64, ptr %l62, !tbaa !24
  store i64 %t55, ptr %l11, !tbaa !24
  %t56 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t57)
  store %"compiler/scan:Tokens" %t59, ptr %l64
  br label %bb17
bb17:
  %t60 = load %"compiler/scan:Tokens", ptr %l64
  store %"compiler/scan:Tokens" %t60, ptr %l12
  %t61 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t62, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l3, ptr %l12, ptr %l4, ptr %l5, ptr %l10, i64 %t61)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t62, i64 880, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l71, i64 880, i1 false)
  %t70 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t70, ptr %l73
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t71, ptr %l14, !tbaa !27
  br i1 %a2, label %bb20, label %bb21
bb20:
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %s0, ptr %l10)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t75 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t75, ptr %l76
  br label %bb24
bb24:
  %t76 = load %"std/prelude/text:StringBuilder", ptr %l76
  store %"std/prelude/text:StringBuilder" %t76, ptr %l15
  %t77 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t77, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l17, !tbaa !24
  %t84 = load i64, ptr %l18, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb91
bb27:
  br label %bb28
bb28:
  %t91 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t91, ptr %l84, !tbaa !27
  %t92 = load i64, ptr %l17, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l19, !tbaa !29
  %t100 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l15)
  store i64 %t100, ptr %l88
  br label %bb29
bb29:
  %t101 = load i64, ptr %l88, !tbaa !24
  %t102 = icmp sgt i64 %t101, 0
  br i1 %t102, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  %t105 = load ptr, ptr %l19, !tbaa !29
  store ptr %t105, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t106 = load ptr, ptr %l91, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb34, label %bb35
bb34:
  %t109 = load ptr, ptr %l91, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 11}
  %t112 = icmp eq i64 %t110, 0
  store i1 %t112, ptr %l92, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l92, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l19, !tbaa !29
  %t116 = getelementptr { i64, [6 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { ptr }, ptr %t116, i32 0, i32 0
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l20, !tbaa !29
  br label %bb38
bb37:
  br label %bb53
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l15, ptr %l97, !tbaa !29
  %t120 = load ptr, ptr %l20, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Func", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %t122, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %s9, ptr %l4, i32 %t123)
  store { i64, ptr } %t126, ptr %l101
  br label %bb39
bb39:
  %t127 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t129 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = add i64 %t128, %t131
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = getelementptr i8, ptr %t136, i64 %t128
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = getelementptr i8, ptr %t137, i64 %t131
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t136, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t148, { i64, ptr } %t147)
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l20, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Func", ptr %t150, i32 0, i32 6
  %t153 = load i1, ptr %t152, !tbaa !21
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb43
bb42:
  %t158 = load ptr, ptr %l20, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Func", ptr %t158, i32 0, i32 4
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l23, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb44:
  store %olang.scope zeroinitializer, ptr %s14
  %t167 = load i64, ptr %l22, !tbaa !24
  %t168 = load i64, ptr %l23, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s14)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t175 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t175, ptr %l116, !tbaa !27
  %t176 = load i64, ptr %l22, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr ptr, ptr %t179, i64 %t176
  %t181 = load ptr, ptr %t180, !tbaa !39
  store ptr %l15, ptr %l119, !tbaa !29
  %t184 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t189 = call { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %s0, ptr %s0, ptr %s0, ptr %s14, ptr %t181, ptr %l4, { i64, ptr } %t185)
  store { i64, ptr } %t189, ptr %l123
  br label %bb48
bb48:
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t192 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = add i64 %t191, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = getelementptr i8, ptr %t196, i64 %t191
  call void @olang_textcopy(ptr %t197, ptr %t193, i64 %t194)
  %t198 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t207, { i64, ptr } %t206)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s14)
  br label %bb50
bb50:
  %t209 = load i64, ptr %l22, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l22, !tbaa !24
  br label %bb44
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb53:
  %t213 = load ptr, ptr %l19, !tbaa !29
  store ptr %t213, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t214 = load ptr, ptr %l128, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb54, label %bb55
bb54:
  %t217 = load ptr, ptr %l128, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 11}
  %t220 = icmp eq i64 %t218, 2
  store i1 %t220, ptr %l129, !tbaa !21
  br label %bb55
bb55:
  %t221 = load i1, ptr %l129, !tbaa !21
  br i1 %t221, label %bb56, label %bb57
bb56:
  %t222 = load ptr, ptr %l19, !tbaa !29
  %t224 = getelementptr { i64, [6 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr }, ptr %t224, i32 0, i32 1
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l25, !tbaa !29
  br label %bb58
bb57:
  br label %bb83
bb58:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l15, ptr %l134, !tbaa !29
  %t228 = load ptr, ptr %l25, !tbaa !29
  %t230 = getelementptr %"compiler/ast:TypeDecl", ptr %t228, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %s17, ptr %l4, i32 %t231)
  store { i64, ptr } %t234, ptr %l138
  br label %bb59
bb59:
  %t235 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t237 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = getelementptr i8, ptr %t241, i64 %t236
  call void @olang_textcopy(ptr %t242, ptr %t238, i64 %t239)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t252, { i64, ptr } %t251)
  br label %bb60
bb60:
  %t254 = load ptr, ptr %l25, !tbaa !29
  %t256 = getelementptr %"compiler/ast:TypeDecl", ptr %t254, i32 0, i32 3
  %t257 = load ptr, ptr %t256, !tbaa !29
  store ptr %t257, ptr %l26, !tbaa !29
  %t259 = load ptr, ptr %l26, !tbaa !29
  store ptr %t259, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t260 = load ptr, ptr %l143, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb61, label %bb62
bb61:
  %t263 = load ptr, ptr %l143, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 5}
  %t266 = icmp eq i64 %t264, 2
  store i1 %t266, ptr %l144, !tbaa !21
  br label %bb62
bb62:
  %t267 = load i1, ptr %l144, !tbaa !21
  br i1 %t267, label %bb63, label %bb64
bb63:
  %t268 = load ptr, ptr %l26, !tbaa !29
  %t270 = getelementptr { i64, [6 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t270, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271
  store { i64, ptr } %t272, ptr %l27, !tbaa !27
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t274 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t274, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s21
  %t280 = load i64, ptr %l29, !tbaa !24
  %t281 = load i64, ptr %l30, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s21)
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t288 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t288, ptr %l156, !tbaa !27
  %t289 = load i64, ptr %l29, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t289
  %t294 = load ptr, ptr %t293, !tbaa !39
  store ptr %t294, ptr %l31, !tbaa !29
  store ptr %l15, ptr %l159, !tbaa !29
  %t296 = load ptr, ptr %l31, !tbaa !29
  %t298 = getelementptr %"compiler/ast:Func", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb72
bb72:
  %t305 = load ptr, ptr %l31, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Func", ptr %t305, i32 0, i32 2
  %t308 = load i32, ptr %t307, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %s21, ptr %l4, i32 %t308)
  store { i64, ptr } %t311, ptr %l168
  br label %bb73
bb73:
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t314 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = add i64 %t313, %t316
  %t318 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = add i64 %t317, %t320
  %t322 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t321)
  call void @olang_textcopy(ptr %t322, ptr %t312, i64 %t313)
  %t323 = getelementptr i8, ptr %t322, i64 %t313
  call void @olang_textcopy(ptr %t323, ptr %t315, i64 %t316)
  %t324 = getelementptr i8, ptr %t323, i64 %t316
  call void @olang_textcopy(ptr %t324, ptr %t319, i64 %t320)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t322, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t334, { i64, ptr } %t333)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s21)
  br label %bb75
bb75:
  %t336 = load i64, ptr %l29, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l29, !tbaa !24
  br label %bb66
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_eccdd3ba5e570728_ba1962c6d7fecaac)
  unreachable
bb82:
  call void @__olang_scope_close(ptr %s17)
  br label %bb89
bb83:
  br i1 true, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb88
bb86:
  store %olang.scope zeroinitializer, ptr %s25
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %l15, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s25)
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_e598cf6f5d58c5f9_c6e191fe7fda4d5d)
  unreachable
bb89:
  br label %bb90
bb90:
  %t341 = load i64, ptr %l17, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l17, !tbaa !24
  br label %bb25
bb91:
  store %olang.scope zeroinitializer, ptr %s27
  %t346 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s27, ptr %l10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, ptr %l177
  br label %bb92
bb92:
  %t347 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l177
  %t348 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t347, ptr %t348
  store ptr %t348, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s28
  %t350 = load i64, ptr %l33, !tbaa !24
  store i64 %t350, ptr %l179, !tbaa !24
  %t351 = load ptr, ptr %l32, !tbaa !29
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s27, ptr %t351)
  store i64 %t353, ptr %l181
  br label %bb94
bb94:
  %t354 = load i64, ptr %l179, !tbaa !24
  %t355 = load i64, ptr %l181, !tbaa !24
  %t356 = icmp slt i64 %t354, %t355
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s28)
  br label %bb101
bb96:
  br label %bb97
bb97:
  %t360 = load ptr, ptr %l32, !tbaa !29
  %t361 = load i64, ptr %l33, !tbaa !24
  %t364 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s27, ptr %s27, ptr %t360, i64 %t361)
  store %"compiler/diag:Said" %t364, ptr %l186
  br label %bb98
bb98:
  %t365 = load %"compiler/diag:Said", ptr %l186
  store %"compiler/diag:Said" %t365, ptr %l34
  %t366 = getelementptr %"compiler/diag:Said", ptr %l34, i32 0, i32 0
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  %t368 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t371 = extractvalue { i64, ptr } %t367, 1
  %t372 = extractvalue { i64, ptr } %t367, 0
  %t373 = add i64 %t369, %t372
  %t374 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t373)
  call void @olang_textcopy(ptr %t374, ptr %t368, i64 %t369)
  %t375 = getelementptr i8, ptr %t374, i64 %t369
  call void @olang_textcopy(ptr %t375, ptr %t371, i64 %t372)
  %t376 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t374, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = extractvalue { i64, ptr } %t377, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l15, { i64, ptr } %t384)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s28)
  br label %bb100
bb100:
  %t387 = load i64, ptr %l33, !tbaa !24
  %t389 = add i64 %t387, 1
  store i64 %t389, ptr %l33, !tbaa !24
  br label %bb93
bb101:
  call void @__olang_scope_close(ptr %s27)
  %t392 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l15)
  store { i64, ptr } %t392, ptr %l194
  br label %bb102
bb102:
  %t393 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t393, ptr %l195, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 0
  store i64 %t395, ptr %l196, !tbaa !24
  %t396 = load i64, ptr %l196, !tbaa !24
  %t397 = mul i64 %t396, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t397)
  %t399 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  store { i64, ptr } %t400, ptr %l197, !tbaa !27
  %t401 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = load i64, ptr %l196, !tbaa !24
  %t406 = mul i64 %t405, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t402, ptr %t404, i64 %t406, i1 false)
  %t407 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t407, ptr %l195, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t408 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t408, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/parse:NameList"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/parse:NameList" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/parse:NameList" %t6, { i64, ptr } %a1, 1
  store %"compiler/parse:NameList" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:NameList", ptr %rv
  ret %"compiler/parse:NameList" %rr
}

define dso_local void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i1
  %l55 = alloca i1
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca %"compiler/parse:Parser"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l6, !tbaa !29
  store ptr %a1, ptr %l7, !tbaa !29
  store ptr %a2, ptr %l8, !tbaa !29
  store ptr %a3, ptr %l9, !tbaa !29
  store ptr %a4, ptr %l10, !tbaa !29
  store i64 %a5, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i32 0, ptr %l13
  store i32 0, ptr %l14, !tbaa !23
  store i32 0, ptr %l15
  store i32 0, ptr %l16, !tbaa !23
  store i1 false, ptr %l17, !tbaa !21
  store i1 false, ptr %l18, !tbaa !21
  store i1 false, ptr %l19, !tbaa !21
  store i1 false, ptr %l20, !tbaa !21
  store i1 false, ptr %l21, !tbaa !21
  store i1 false, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i64 0, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i64 -1, ptr %l28, !tbaa !24
  store i1 false, ptr %l29, !tbaa !21
  store i32 -1, ptr %l30, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l67
  br label %bb1
bb1:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l31
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l68
  br label %bb2
bb2:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l32
  %t19 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v5)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t19, ptr %l69
  br label %bb3
bb3:
  %t20 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l69
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t20, ptr %l33
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l70
  br label %bb4
bb4:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l34
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l71
  br label %bb5
bb5:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l35
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l72
  br label %bb6
bb6:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l36
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l73
  br label %bb7
bb7:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l37
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l74
  br label %bb8
bb8:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l38
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l75
  br label %bb9
bb9:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l39
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l76
  br label %bb10
bb10:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l40
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l77
  br label %bb11
bb11:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l41
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l78
  br label %bb12
bb12:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l42
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l79
  br label %bb13
bb13:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l43
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l80
  br label %bb14
bb14:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l44
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb17:
  %t47 = mul i64 0, 8
  %t48 = insertvalue { i64, ptr } undef, i64 0, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t49, ptr %l45, !tbaa !27
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l84
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb19:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l46
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l85
  br label %bb20
bb20:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l47
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l86
  br label %bb21
bb21:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l48
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l87
  br label %bb22
bb22:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l49
  store i1 false, ptr %l50, !tbaa !21
  store i1 false, ptr %l51, !tbaa !21
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l88
  br label %bb23
bb23:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l52
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l89
  br label %bb24
bb24:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l53
  store i1 false, ptr %l54, !tbaa !21
  store i1 false, ptr %l55, !tbaa !21
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l90
  br label %bb25
bb25:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t65 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 0
  %t66 = load ptr, ptr %l6, !tbaa !29
  store ptr %t66, ptr %t65, !tbaa !29
  %t67 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 1
  %t68 = load ptr, ptr %l7, !tbaa !29
  store ptr %t68, ptr %t67, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 2
  %t70 = load ptr, ptr %l8, !tbaa !29
  store ptr %t70, ptr %t69, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 3
  %t72 = load ptr, ptr %l9, !tbaa !29
  store ptr %t72, ptr %t71, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 4
  %t74 = load ptr, ptr %l10, !tbaa !29
  store ptr %t74, ptr %t73, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 5
  %t76 = load i64, ptr %l11, !tbaa !24
  store i64 %t76, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 6
  %t78 = load i64, ptr %l12, !tbaa !24
  store i64 %t78, ptr %t77, !tbaa !24
  %t79 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 7
  %t80 = load i32, ptr %l13, !range !{i32 0, i32 98}
  store i32 %t80, ptr %t79
  %t81 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 8
  %t82 = load i32, ptr %l14, !tbaa !23
  store i32 %t82, ptr %t81, !tbaa !23
  %t83 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 9
  %t84 = load i32, ptr %l15, !range !{i32 0, i32 98}
  store i32 %t84, ptr %t83
  %t85 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 10
  %t86 = load i32, ptr %l16, !tbaa !23
  store i32 %t86, ptr %t85, !tbaa !23
  %t87 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 11
  %t88 = load i1, ptr %l17, !tbaa !21
  store i1 %t88, ptr %t87, !tbaa !21
  %t89 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 12
  %t90 = load i1, ptr %l18, !tbaa !21
  store i1 %t90, ptr %t89, !tbaa !21
  %t91 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 13
  %t92 = load i1, ptr %l19, !tbaa !21
  store i1 %t92, ptr %t91, !tbaa !21
  %t93 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 14
  %t94 = load i1, ptr %l20, !tbaa !21
  store i1 %t94, ptr %t93, !tbaa !21
  %t95 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 15
  %t96 = load i1, ptr %l21, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 16
  %t98 = load i1, ptr %l22, !tbaa !21
  store i1 %t98, ptr %t97, !tbaa !21
  %t99 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 17
  %t100 = load i64, ptr %l23, !tbaa !24
  store i64 %t100, ptr %t99, !tbaa !24
  %t101 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 18
  %t102 = load i1, ptr %l24, !tbaa !21
  store i1 %t102, ptr %t101, !tbaa !21
  %t103 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 19
  %t104 = load i1, ptr %l25, !tbaa !21
  store i1 %t104, ptr %t103, !tbaa !21
  %t105 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 20
  %t106 = load i64, ptr %l26, !tbaa !24
  store i64 %t106, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 21
  %t108 = load i1, ptr %l27, !tbaa !21
  store i1 %t108, ptr %t107, !tbaa !21
  %t109 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 22
  %t110 = load i64, ptr %l28, !tbaa !24
  store i64 %t110, ptr %t109, !tbaa !24
  %t111 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 23
  %t112 = load i1, ptr %l29, !tbaa !21
  store i1 %t112, ptr %t111, !tbaa !21
  %t113 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 24
  %t114 = load i32, ptr %l30, !tbaa !23
  store i32 %t114, ptr %t113, !tbaa !23
  %t115 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 25
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t115
  %t117 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 26
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %t117
  %t119 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 27
  %t120 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t120, ptr %t119
  %t121 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 28
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %t121
  %t123 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 29
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %t123
  %t125 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 30
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %t125
  %t127 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 31
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %t127
  %t129 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 32
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %t129
  %t131 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 33
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %t131
  %t133 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 34
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t133
  %t135 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 35
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %t135
  %t137 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 36
  %t138 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %t137
  %t139 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 37
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t139
  %t141 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 38
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %t141
  %t143 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 39
  %t144 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t144, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 40
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %t145
  %t147 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 41
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %t147
  %t149 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 42
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %t149
  %t151 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 43
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %t151
  %t153 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 44
  %t154 = load i1, ptr %l50, !tbaa !21
  store i1 %t154, ptr %t153, !tbaa !21
  %t155 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 45
  %t156 = load i1, ptr %l51, !tbaa !21
  store i1 %t156, ptr %t155, !tbaa !21
  %t157 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 46
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %t157
  %t159 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 47
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %t159
  %t161 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 48
  %t162 = load i1, ptr %l54, !tbaa !21
  store i1 %t162, ptr %t161, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 49
  %t164 = load i1, ptr %l55, !tbaa !21
  store i1 %t164, ptr %t163, !tbaa !21
  %t165 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %t165
  %t167 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 51
  store i1 false, ptr %t167, !tbaa !21
  %t169 = getelementptr %"compiler/parse:Parser", ptr %l91, i32 0, i32 52
  store i1 false, ptr %t169, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l91, i64 880, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"export" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error word" }>, align 8
@.d2 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an element type before the [, as in I32[...]" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"'fn' or 'type' - an extern block declares C's functions and types" }>, align 8
@.d4 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"'for NAME in' after 'comptime'" }>, align 8
@.d5 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an expression" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(...)" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Base" }>, align 8
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Element" }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Target" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d14 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"commutes" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a type" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"an if" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a loop" }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a match" }>, align 8
@.d22 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a block (a block takes no ':')" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a join" }>, align 8
@.d24 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a defer" }>, align 8
@.d25 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an errdefer" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(chain " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(if " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(call " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(generic " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"expr" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"t.olang" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" -" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"decl" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" !" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i32 %a4)
declare { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrPlace(ptr %v0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/msgs:Msg" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0)
@olang_loc_3a8ad8017031eccf_6f47b3cce535c81b = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrs(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9090e2f728d8157a_2317b9fcceb6fe86 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2efieldAttrs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7f479cc541fc1ad4_6e65e2fdc3321828 = external constant [0 x i8]
@olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a = external constant [0 x i8]
@olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9 = external constant [0 x i8]
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0)
declare %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2)
@olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9 = external constant [0 x i8]
@olang_loc_bce5f5de212629d8_a497bbae1a0b61c = external constant [0 x i8]
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
@olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd = external constant [0 x i8]
@olang_loc_34506b7f0a96de24_ffbbf03839f4b990 = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_f716ec0be1acdc8e_190b3cb13895b492 = external constant [0 x i8]
@olang_loc_de9eff954e569147_2ba8982dfff1933 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
declare i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2eisJoiningOp(i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eAt_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3f74969944d00b69_b8e7e882b42021d = external constant [0 x i8]
@olang_loc_cbae392aecd52e99_b08c2106788b334d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0)
@olang_loc_824bfdca782f89b4_8a051d8e1bdc5e78 = external constant [0 x i8]
@olang_loc_c92b08434e34de1e_b2c231b9ab335d4a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_7df95d039a20ef2e_354875480560b892 = external constant [0 x i8]
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eampOperator(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %a0)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fparse_2epathIds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_db61fb5d51a81784_d7c7d8e6a8f1b2c8 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_2c371f21e588b068_13da37aea4ea5bc = external constant [0 x i8]
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_97d42995c5706fd7_20b731538cf045b = external constant [0 x i8]
@olang_loc_787ae3c3318fe322_f2232752b79280c6 = external constant [0 x i8]
@olang_loc_afe07cd3f11f5e9a_d335478c7d935166 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eattrsHere(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_f0055d05bbcc9e33_2e682d4d4b5dbed7 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclareAttrs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3, { i64, ptr } %a4)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0)
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_148080230b4c6cc_b965c2d4ca1d1020 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %a0)
@olang_loc_b7d265f950b1c844_fc5ee8d7b150faf8 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_682b81c4be20c47_acb581c54a6720db = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, i1 %a6, i1 %a7)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b08fe5a62583e117_e5b5edd841fa1acb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
@olang_loc_e98eee410cc159b2_377f58609bf35bd6 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_47198c3f9d8413cf_be7184982b6f0763 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %a0)
@olang_loc_4b26d93c159ce468_272ef8e9c938d194 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_31e39d55c126667c_eaaf5fcb81f21700 = external constant [0 x i8]
@olang_loc_c7048dff8864462d_6ca6baed1a8cf791 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_5787450c8afeca22_493a6afca2796a86 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4582cd3e20803687_2be8b05c8d066113 = external constant [0 x i8]
@olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e37d10a9f86ee49_f510a1627c721295 = external constant [0 x i8]
@olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53 = external constant [0 x i8]
@olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e = external constant [0 x i8]
@olang_loc_3fc06d3a68dac511_cf4e4a3339a21d5d = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_6ff476a4e2a6097a_2b56ab96df058916 = external constant [0 x i8]
@olang_loc_94ee529efe0ddf52_d9208d758fca575e = external constant [0 x i8]
@olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6 = external constant [0 x i8]
@olang_loc_95becaa34f722781_c104ec8a8e14f09d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_a6e4b06ca3f2f7b3_b26c102023f13b6f = external constant [0 x i8]
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fparse_3aOracle_2ector(ptr %out, ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_eccdd3ba5e570728_ba1962c6d7fecaac = external constant [0 x i8]
@olang_loc_e598cf6f5d58c5f9_c6e191fe7fda4d5d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_936bfbc19493319b_da93a9696e3b504f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
