; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
@G_2ecompiler_2fparse_2eMaxNesting = constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2fparse_2eMaxNesting_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 20000, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca ptr
  %l29 = alloca i64
  %l32 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i32
  %l41 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i32
  %l54 = alloca ptr
  %l63 = alloca i1
  %l65 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca ptr
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i32
  %l96 = alloca ptr
  %l108 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca i32
  %l129 = alloca i32
  %l133 = alloca { i64, ptr }
  %s15 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t93 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 90)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l13
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l9, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l13, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l1, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 17
  store i64 %t34, ptr %t37, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 18
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l2, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 19
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 18
  store i1 false, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 19
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 30
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l29
  br label %bb4
bb4:
  %t59 = load i64, ptr %l29, !tbaa !24
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t60, i32 91)
  store i1 %t63, ptr %l32
  br label %bb6
bb6:
  %t64 = load i1, ptr %l32, !tbaa !21
  %t65 = xor i1 %t64, true
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb7, label %bb8
bb7:
  br label %bb42
bb8:
  br label %bb9
bb9:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t69, i32 45)
  store i1 %t72, ptr %l37
  br label %bb10
bb10:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t74)
  store i32 %t76, ptr %l39
  br label %bb13
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t77)
  %t80 = extractvalue { i32, ptr } %t79, 1
  %t81 = extractvalue { i32, ptr } %t79, 0
  store i32 %t81, ptr %l50
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb17, label %ok.83
ok.83:
  store ptr %t80, ptr %l49
  br label %bb16
bb13:
  %t84 = load i32, ptr %l39, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 30
  store ptr %t87, ptr %l41, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t88, i32 %t84)
  store %"compiler/source:Span" %t92, ptr %l44
  br label %bb14
bb14:
  store { i64, [5 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 0
  store i64 26, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l44
  %t96 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t95, 0
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span" } %t96, ptr %t97
  %t98 = load { i64, [5 x i64] }, ptr %t93
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t101, ptr %t100)
  br label %bb15
bb15:
  br label %bb32
bb16:
  %t103 = load ptr, ptr %l49, !tbaa !29
  store ptr %t103, ptr %l47, !tbaa !29
  br label %bb20
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 30
  %t107 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l54, !tbaa !29
  %t111 = load ptr, ptr %l54, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 17
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = sub i64 %t113, 1
  %t117 = load ptr, ptr %l54, !tbaa !29
  %t118 = getelementptr %"compiler/parse:Parser", ptr %t117, i32 0, i32 17
  store i64 %t115, ptr %t118, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l2, !tbaa !21
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t119, i32 0, i32 18
  store i1 %t120, ptr %t123, !tbaa !21
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i1, ptr %l3, !tbaa !21
  %t128 = getelementptr %"compiler/parse:Parser", ptr %t124, i32 0, i32 19
  store i1 %t125, ptr %t128, !tbaa !21
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb20:
  %t131 = load ptr, ptr %l47, !tbaa !29
  store ptr %t131, ptr %l6, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t132)
  store i1 %t134, ptr %l63
  br label %bb21
bb21:
  %t135 = load i1, ptr %l63, !tbaa !21
  br i1 %t135, label %bb22, label %bb23
bb22:
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t136)
  store %"compiler/source:Span" %t138, ptr %l65
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t139 = getelementptr %"compiler/source:Span", ptr %l65, i32 0, i32 0
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t149 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %t142, i32 %t140, ptr null, ptr %t144, i32 91)
  %t150 = extractvalue { i32, ptr } %t149, 1
  %t151 = extractvalue { i32, ptr } %t149, 0
  store i32 %t151, ptr %l73
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb26, label %ok.153
ok.153:
  store ptr %t150, ptr %l72
  br label %bb25
bb25:
  %t154 = load ptr, ptr %l72, !tbaa !29
  store ptr %t154, ptr %l67, !tbaa !29
  br label %bb29
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t155, i32 0, i32 30
  %t158 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t157, i64 %t158)
  br label %bb28
bb28:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l77, !tbaa !29
  %t162 = load ptr, ptr %l77, !tbaa !29
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 17
  %t164 = load i64, ptr %t163, !tbaa !24
  %t166 = sub i64 %t164, 1
  %t168 = load ptr, ptr %l77, !tbaa !29
  %t169 = getelementptr %"compiler/parse:Parser", ptr %t168, i32 0, i32 17
  store i64 %t166, ptr %t169, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i1, ptr %l2, !tbaa !21
  %t174 = getelementptr %"compiler/parse:Parser", ptr %t170, i32 0, i32 18
  store i1 %t171, ptr %t174, !tbaa !21
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i1, ptr %l3, !tbaa !21
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t175, i32 0, i32 19
  store i1 %t176, ptr %t179, !tbaa !21
  %t181 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t181, ptr %rv
  br label %ret
bb29:
  %t182 = load ptr, ptr %l67, !tbaa !29
  store ptr %t182, ptr %l6, !tbaa !29
  br label %bb30
bb30:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 30
  %t186 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t186)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t192 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t189, i32 91)
  %t193 = extractvalue { i32, i1 } %t192, 1
  %t194 = extractvalue { i32, i1 } %t192, 0
  store i32 %t194, ptr %l92
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb34, label %ok.196
ok.196:
  store i1 %t193, ptr %l91
  br label %bb33
bb33:
  %t197 = load i1, ptr %l91, !tbaa !21
  store i1 %t197, ptr %l88, !tbaa !21
  br label %bb37
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t198, i32 0, i32 30
  %t201 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t200, i64 %t201)
  br label %bb36
bb36:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l96, !tbaa !29
  %t205 = load ptr, ptr %l96, !tbaa !29
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t205, i32 0, i32 17
  %t207 = load i64, ptr %t206, !tbaa !24
  %t209 = sub i64 %t207, 1
  %t211 = load ptr, ptr %l96, !tbaa !29
  %t212 = getelementptr %"compiler/parse:Parser", ptr %t211, i32 0, i32 17
  store i64 %t209, ptr %t212, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i1, ptr %l2, !tbaa !21
  %t217 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 18
  store i1 %t214, ptr %t217, !tbaa !21
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i1, ptr %l3, !tbaa !21
  %t222 = getelementptr %"compiler/parse:Parser", ptr %t218, i32 0, i32 19
  store i1 %t219, ptr %t222, !tbaa !21
  %t224 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t224, ptr %rv
  br label %ret
bb37:
  %t225 = load i1, ptr %l88, !tbaa !21
  %t228 = xor i1 %t225, true
  br i1 %t228, label %bb38, label %bb39
bb38:
  br label %bb42
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb5
bb42:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i1, ptr %l2, !tbaa !21
  %t234 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 18
  store i1 %t231, ptr %t234, !tbaa !21
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l108, !tbaa !29
  %t236 = load ptr, ptr %l108, !tbaa !29
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 17
  %t238 = load i64, ptr %t237, !tbaa !24
  %t240 = sub i64 %t238, 1
  %t242 = load ptr, ptr %l108, !tbaa !29
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t242, i32 0, i32 17
  store i64 %t240, ptr %t243, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i1, ptr %l1, !tbaa !21
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 11
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t252 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t249, i32 91)
  store i1 %t252, ptr %l115
  br label %bb43
bb43:
  %t253 = load i1, ptr %l115, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s15
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/parse:Parser", ptr %t256, i32 0, i32 30
  %t259 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t258, i64 %t259)
  br label %bb46
bb45:
  br label %bb51
bb46:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l120, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s15, i32 91)
  store { i64, ptr } %t264, ptr %l122
  br label %bb47
bb47:
  %t265 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t267 = extractvalue { i64, ptr } %t265, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t272 = load ptr, ptr %l120, !tbaa !29
  %t274 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s15, ptr %t272, { i64, ptr } %t271)
  store i32 %t274, ptr %l124
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb49, label %ok.276
ok.276:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t277 = load i32, ptr %l124, !tbaa !23
  %t278 = lshr i32 %t277, 16
  %t279 = and i32 %t277, 65535
  %t280 = icmp eq i32 %t278, 1
  %t281 = select i1 %t280, i32 1, i32 0
  %t282 = icmp eq i32 %t277, 0
  %t283 = shl i32 %t281, 16
  %t284 = or i32 %t283, %t279
  %t285 = select i1 %t282, i32 0, i32 %t284
  call void @__olang_scope_close(ptr %s15)
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i1, ptr %l3, !tbaa !21
  %t290 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 19
  store i1 %t287, ptr %t290, !tbaa !21
  %t292 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t285, 0
  store { i32, { i64, ptr } } %t292, ptr %rv
  br label %ret
bb50:
  call void @__olang_scope_close(ptr %s15)
  br label %bb51
bb51:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t293)
  store i32 %t295, ptr %l129
  br label %bb52
bb52:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t296, i32 0, i32 30
  %t299 = load i64, ptr %l4, !tbaa !24
  %t302 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t298, i64 %t299)
  store { i64, ptr } %t302, ptr %l133
  br label %bb53
bb53:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i1, ptr %l3, !tbaa !21
  %t307 = getelementptr %"compiler/parse:Parser", ptr %t303, i32 0, i32 19
  store i1 %t304, ptr %t307, !tbaa !21
  %t308 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t309 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t308, 1
  store { i32, { i64, ptr } } %t309, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %t21, ptr %t20, i64 %a1)
  %t28 = extractvalue { i32, ptr } %t27, 1
  %t29 = extractvalue { i32, ptr } %t27, 0
  store i32 %t29, ptr %l13
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store ptr %t28, ptr %l12
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l12, !tbaa !29
  store ptr %t32, ptr %l8, !tbaa !29
  br label %bb6
bb5:
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  %t43 = insertvalue { i32, ptr } zeroinitializer, i32 %t41, 0
  store { i32, ptr } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t45 = insertvalue { i32, ptr } zeroinitializer, ptr %t44, 1
  store { i32, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l21 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca ptr
  %l46 = alloca i1
  %l48 = alloca i32
  %l53 = alloca ptr
  %l61 = alloca i1
  %l65 = alloca ptr
  %l70 = alloca i32
  %l74 = alloca i32
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l97 = alloca ptr
  %l107 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i32
  %l115 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i32
  %l135 = alloca ptr
  %l142 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l151 = alloca ptr
  %l157 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca i32
  %l164 = alloca ptr
  %l169 = alloca i1
  %l170 = alloca i1
  %l172 = alloca i32
  %l173 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca i64
  %l180 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca i64
  %l194 = alloca i32
  %l196 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i1
  %l205 = alloca i1
  %l206 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca i64
  %l212 = alloca ptr
  %l214 = alloca i32
  %l216 = alloca i32
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca i32
  %l226 = alloca ptr
  %l231 = alloca i32
  %l233 = alloca ptr
  %l242 = alloca %"compiler/source:Span"
  %l244 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca %"compiler/ast:Chain"
  %l255 = alloca i1
  %l258 = alloca i1
  %l262 = alloca i1
  %l264 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l268 = alloca i1
  %l270 = alloca ptr
  %l272 = alloca %"compiler/source:Span"
  %l276 = alloca %"compiler/source:Span"
  %l283 = alloca i32
  %l285 = alloca ptr
  %rv = alloca { i32, ptr }
  %t178 = alloca { i64, [5 x i64] }, align 8
  %t289 = alloca { i64, [5 x i64] }, align 8
  %t339 = alloca { i64, [5 x i64] }, align 8
  %t620 = alloca { i64, [5 x i64] }, align 8
  %t683 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 45
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  store i1 %t16, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l21, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 46
  store ptr %t21, ptr %l25, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t22)
  store %"compiler/source:Span" %t24, ptr %l27
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l29
  br label %bb11
bb11:
  %t30 = load i32, ptr %l29
  store i32 %t30, ptr %l6
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l6
  %t35 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l32
  br label %bb12
bb12:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp eq i64 %t37, 0
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %a2
  store i1 %t45, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l40, !tbaa !29
  %t50 = load ptr, ptr %l40, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 20
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 20
  store i64 %t56, ptr %t59, !tbaa !24
  %t61 = insertvalue { i32, ptr } zeroinitializer, ptr %t48, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t62 = load i32, ptr %l6
  %t64 = trunc i64 49 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t67, i64 1)
  store i32 %t69, ptr %l48
  br label %bb21
bb20:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb22
bb21:
  %t70 = load i32, ptr %l48
  %t72 = trunc i64 27 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l46, !tbaa !21
  br label %bb22
bb22:
  %t77 = load i1, ptr %l46, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l53, !tbaa !29
  %t80 = load ptr, ptr %l53, !tbaa !29
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 20
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t88, i32 0, i32 20
  store i64 %t86, ptr %t89, !tbaa !24
  %t91 = insertvalue { i32, ptr } zeroinitializer, ptr %t78, 1
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 7
  %t95 = load i32, ptr %t94
  %t97 = trunc i64 0 to i32
  %t98 = icmp eq i32 %t95, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  %t102 = load i32, ptr %l6
  %t104 = trunc i64 83 to i32
  %t105 = icmp eq i32 %t102, %t104
  store i1 %t105, ptr %l61, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb28
bb28:
  %t107 = load i1, ptr %l61, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l65, !tbaa !29
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 20
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 20
  store i64 %t116, ptr %t119, !tbaa !24
  %t121 = insertvalue { i32, ptr } zeroinitializer, ptr %t108, 1
  store { i32, ptr } %t121, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t122)
  store i32 %t124, ptr %l70
  br label %bb32
bb32:
  %t125 = load i32, ptr %l6
  %t127 = trunc i64 49 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb33, label %bb34
bb33:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t130)
  store i32 %t132, ptr %l74
  br label %bb35
bb34:
  br label %bb43
bb35:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  %t139 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t133, i64 %t136)
  %t140 = extractvalue { i32, ptr } %t139, 1
  %t141 = extractvalue { i32, ptr } %t139, 0
  store i32 %t141, ptr %l80
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb37, label %ok.143
ok.143:
  store ptr %t140, ptr %l79
  br label %bb36
bb36:
  %t144 = load ptr, ptr %l79, !tbaa !29
  store ptr %t144, ptr %l75, !tbaa !29
  br label %bb38
bb37:
  %t145 = load i32, ptr %l80, !tbaa !23
  %t146 = lshr i32 %t145, 16
  %t147 = and i32 %t145, 65535
  %t148 = icmp eq i32 %t146, 1
  %t149 = select i1 %t148, i32 1, i32 0
  %t150 = icmp eq i32 %t145, 0
  %t151 = shl i32 %t149, 16
  %t152 = or i32 %t151, %t147
  %t153 = select i1 %t150, i32 0, i32 %t152
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l82, !tbaa !29
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t155, i32 0, i32 20
  %t157 = load i64, ptr %t156, !tbaa !24
  %t158 = load i64, ptr %l5, !tbaa !24
  %t161 = sub i64 %t157, %t158
  %t163 = load ptr, ptr %l82, !tbaa !29
  %t164 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 20
  store i64 %t161, ptr %t164, !tbaa !24
  %t166 = insertvalue { i32, ptr } zeroinitializer, i32 %t153, 0
  store { i32, ptr } %t166, ptr %rv
  br label %ret
bb38:
  %t167 = load ptr, ptr %l75, !tbaa !29
  store ptr %t167, ptr %l8, !tbaa !29
  %t168 = load i32, ptr %l4, !tbaa !23
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t169, i32 0, i32 10
  %t172 = load i32, ptr %t171, !tbaa !23
  %t175 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t168, i32 %t172)
  store %"compiler/source:Span" %t175, ptr %l89
  br label %bb39
bb39:
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 0
  store i64 6, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l89
  %t181 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t180, 0
  %t183 = insertvalue { %"compiler/source:Span", ptr, ptr } %t181, ptr %t176, 1
  %t185 = insertvalue { %"compiler/source:Span", ptr, ptr } %t183, ptr %t177, 2
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t185, ptr %t186
  %t187 = load { i64, [5 x i64] }, ptr %t178
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t187, ptr %t189
  store ptr %t189, ptr %l3, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t191)
  store i32 %t193, ptr %l95
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb41, label %ok.195
ok.195:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t196 = load i32, ptr %l95, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l97, !tbaa !29
  %t206 = load ptr, ptr %l97, !tbaa !29
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t206, i32 0, i32 20
  %t208 = load i64, ptr %t207, !tbaa !24
  %t209 = load i64, ptr %l5, !tbaa !24
  %t212 = sub i64 %t208, %t209
  %t214 = load ptr, ptr %l97, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 20
  store i64 %t212, ptr %t215, !tbaa !24
  %t217 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t217, ptr %rv
  br label %ret
bb42:
  %t218 = load i64, ptr %l5, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l5, !tbaa !24
  br label %bb140
bb43:
  %t222 = load i32, ptr %l6
  %t224 = trunc i64 28 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb44, label %bb45
bb44:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t227, i32 49)
  store i1 %t230, ptr %l107
  br label %bb46
bb45:
  br label %bb62
bb46:
  %t231 = load i1, ptr %l107, !tbaa !21
  store i1 %t231, ptr %l9, !tbaa !21
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %t232)
  store i1 %t234, ptr %l109
  br label %bb47
bb47:
  %t235 = load i1, ptr %l109, !tbaa !21
  br i1 %t235, label %bb48, label %bb49
bb48:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t236)
  %t239 = extractvalue { i32, ptr } %t238, 1
  %t240 = extractvalue { i32, ptr } %t238, 0
  store i32 %t240, ptr %l113
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb51, label %ok.242
ok.242:
  store ptr %t239, ptr %l112
  br label %bb50
bb49:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i64, ptr %l7, !tbaa !24
  %t246 = add i64 %t244, 1
  %t249 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t243, i64 %t246)
  %t250 = extractvalue { i32, ptr } %t249, 1
  %t251 = extractvalue { i32, ptr } %t249, 0
  store i32 %t251, ptr %l133
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb55, label %ok.253
ok.253:
  store ptr %t250, ptr %l132
  br label %bb54
bb50:
  %t254 = load ptr, ptr %l112, !tbaa !29
  store ptr %t254, ptr %l110, !tbaa !29
  br label %bb52
bb51:
  %t255 = load i32, ptr %l113, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l115, !tbaa !29
  %t265 = load ptr, ptr %l115, !tbaa !29
  %t266 = getelementptr %"compiler/parse:Parser", ptr %t265, i32 0, i32 20
  %t267 = load i64, ptr %t266, !tbaa !24
  %t268 = load i64, ptr %l5, !tbaa !24
  %t271 = sub i64 %t267, %t268
  %t273 = load ptr, ptr %l115, !tbaa !29
  %t274 = getelementptr %"compiler/parse:Parser", ptr %t273, i32 0, i32 20
  store i64 %t271, ptr %t274, !tbaa !24
  %t276 = insertvalue { i32, ptr } zeroinitializer, i32 %t263, 0
  store { i32, ptr } %t276, ptr %rv
  br label %ret
bb52:
  %t277 = load ptr, ptr %l110, !tbaa !29
  store ptr %t277, ptr %l10, !tbaa !29
  %t278 = load i32, ptr %l4, !tbaa !23
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/parse:Parser", ptr %t279, i32 0, i32 10
  %t282 = load i32, ptr %t281, !tbaa !23
  %t285 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t278, i32 %t282)
  store %"compiler/source:Span" %t285, ptr %l122
  br label %bb53
bb53:
  %t286 = load ptr, ptr %l3, !tbaa !29
  %t287 = load ptr, ptr %l10, !tbaa !29
  %t288 = load i1, ptr %l9, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 0
  store i64 9, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l122
  %t292 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t291, 0
  %t294 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t292, ptr %t286, 1
  %t296 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t294, ptr %t287, 2
  %t298 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t296, i1 %t288, 3
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t298, ptr %t299
  %t300 = load { i64, [5 x i64] }, ptr %t289
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t300, ptr %t302
  store ptr %t302, ptr %l3, !tbaa !29
  br label %bb58
bb54:
  %t304 = load ptr, ptr %l132, !tbaa !29
  store ptr %t304, ptr %l128, !tbaa !29
  br label %bb56
bb55:
  %t305 = load i32, ptr %l133, !tbaa !23
  %t306 = lshr i32 %t305, 16
  %t307 = and i32 %t305, 65535
  %t308 = icmp eq i32 %t306, 1
  %t309 = select i1 %t308, i32 1, i32 0
  %t310 = icmp eq i32 %t305, 0
  %t311 = shl i32 %t309, 16
  %t312 = or i32 %t311, %t307
  %t313 = select i1 %t310, i32 0, i32 %t312
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l135, !tbaa !29
  %t315 = load ptr, ptr %l135, !tbaa !29
  %t316 = getelementptr %"compiler/parse:Parser", ptr %t315, i32 0, i32 20
  %t317 = load i64, ptr %t316, !tbaa !24
  %t318 = load i64, ptr %l5, !tbaa !24
  %t321 = sub i64 %t317, %t318
  %t323 = load ptr, ptr %l135, !tbaa !29
  %t324 = getelementptr %"compiler/parse:Parser", ptr %t323, i32 0, i32 20
  store i64 %t321, ptr %t324, !tbaa !24
  %t326 = insertvalue { i32, ptr } zeroinitializer, i32 %t313, 0
  store { i32, ptr } %t326, ptr %rv
  br label %ret
bb56:
  %t327 = load ptr, ptr %l128, !tbaa !29
  store ptr %t327, ptr %l11, !tbaa !29
  %t328 = load i32, ptr %l4, !tbaa !23
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t329, i32 0, i32 10
  %t332 = load i32, ptr %t331, !tbaa !23
  %t335 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t328, i32 %t332)
  store %"compiler/source:Span" %t335, ptr %l142
  br label %bb57
bb57:
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t337 = load ptr, ptr %l11, !tbaa !29
  %t338 = load i1, ptr %l9, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 0
  store i64 10, ptr %t340
  %t341 = load %"compiler/source:Span", ptr %l142
  %t342 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } undef, %"compiler/source:Span" %t341, 0
  %t344 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t342, ptr %t336, 1
  %t346 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t344, ptr %t337, 2
  %t348 = insertvalue { %"compiler/source:Span", ptr, ptr, i1 } %t346, i1 %t338, 3
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, i1 } %t348, ptr %t349
  %t350 = load { i64, [5 x i64] }, ptr %t339
  %t352 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t350, ptr %t352
  store ptr %t352, ptr %l3, !tbaa !29
  br label %bb58
bb58:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t354)
  store i32 %t356, ptr %l149
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb60, label %ok.358
ok.358:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t359 = load i32, ptr %l149, !tbaa !23
  %t360 = lshr i32 %t359, 16
  %t361 = and i32 %t359, 65535
  %t362 = icmp eq i32 %t360, 1
  %t363 = select i1 %t362, i32 1, i32 0
  %t364 = icmp eq i32 %t359, 0
  %t365 = shl i32 %t363, 16
  %t366 = or i32 %t365, %t361
  %t367 = select i1 %t364, i32 0, i32 %t366
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l151, !tbaa !29
  %t369 = load ptr, ptr %l151, !tbaa !29
  %t370 = getelementptr %"compiler/parse:Parser", ptr %t369, i32 0, i32 20
  %t371 = load i64, ptr %t370, !tbaa !24
  %t372 = load i64, ptr %l5, !tbaa !24
  %t375 = sub i64 %t371, %t372
  %t377 = load ptr, ptr %l151, !tbaa !29
  %t378 = getelementptr %"compiler/parse:Parser", ptr %t377, i32 0, i32 20
  store i64 %t375, ptr %t378, !tbaa !24
  %t380 = insertvalue { i32, ptr } zeroinitializer, i32 %t367, 0
  store { i32, ptr } %t380, ptr %rv
  br label %ret
bb61:
  %t381 = load i64, ptr %l5, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l5, !tbaa !24
  br label %bb140
bb62:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i64, ptr %l7, !tbaa !24
  %t388 = add i64 %t386, 1
  %t391 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t385, i64 %t388)
  %t392 = extractvalue { i32, ptr } %t391, 1
  %t393 = extractvalue { i32, ptr } %t391, 0
  store i32 %t393, ptr %l162
  %t394 = icmp ne i32 %t393, 0
  br i1 %t394, label %bb64, label %ok.395
ok.395:
  store ptr %t392, ptr %l161
  br label %bb63
bb63:
  %t396 = load ptr, ptr %l161, !tbaa !29
  store ptr %t396, ptr %l157, !tbaa !29
  br label %bb65
bb64:
  %t397 = load i32, ptr %l162, !tbaa !23
  %t398 = lshr i32 %t397, 16
  %t399 = and i32 %t397, 65535
  %t400 = icmp eq i32 %t398, 1
  %t401 = select i1 %t400, i32 1, i32 0
  %t402 = icmp eq i32 %t397, 0
  %t403 = shl i32 %t401, 16
  %t404 = or i32 %t403, %t399
  %t405 = select i1 %t402, i32 0, i32 %t404
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l164, !tbaa !29
  %t407 = load ptr, ptr %l164, !tbaa !29
  %t408 = getelementptr %"compiler/parse:Parser", ptr %t407, i32 0, i32 20
  %t409 = load i64, ptr %t408, !tbaa !24
  %t410 = load i64, ptr %l5, !tbaa !24
  %t413 = sub i64 %t409, %t410
  %t415 = load ptr, ptr %l164, !tbaa !29
  %t416 = getelementptr %"compiler/parse:Parser", ptr %t415, i32 0, i32 20
  store i64 %t413, ptr %t416, !tbaa !24
  %t418 = insertvalue { i32, ptr } zeroinitializer, i32 %t405, 0
  store { i32, ptr } %t418, ptr %rv
  br label %ret
bb65:
  %t419 = load ptr, ptr %l157, !tbaa !29
  store ptr %t419, ptr %l12, !tbaa !29
  %t420 = load i32, ptr %l6
  %t422 = call i1 @compiler_2fparse_2eisOrdering(i32 %t420)
  store i1 %t422, ptr %l169
  br label %bb66
bb66:
  %t423 = load i1, ptr %l169, !tbaa !21
  br i1 %t423, label %bb67, label %bb68
bb67:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t424)
  store i32 %t426, ptr %l172
  br label %bb69
bb68:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb71
bb69:
  %t427 = load i32, ptr %l172
  %t428 = call i1 @compiler_2fparse_2eisOrdering(i32 %t427)
  store i1 %t428, ptr %l173
  br label %bb70
bb70:
  %t429 = load i1, ptr %l173, !tbaa !21
  store i1 %t429, ptr %l170, !tbaa !21
  br label %bb71
bb71:
  %t430 = load i1, ptr %l170, !tbaa !21
  br i1 %t430, label %bb72, label %bb73
bb72:
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l175, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t432)
  store i32 %t434, ptr %l177
  br label %bb74
bb73:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb76
bb74:
  %t435 = load ptr, ptr %l175, !tbaa !29
  %t436 = load i32, ptr %l177
  %t437 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t435, i32 %t436)
  store i64 %t437, ptr %l178
  br label %bb75
bb75:
  %t438 = load i64, ptr %l178, !tbaa !24
  %t439 = icmp sgt i64 %t438, 0
  store i1 %t439, ptr %l174, !tbaa !21
  br label %bb76
bb76:
  %t441 = load i1, ptr %l174, !tbaa !21
  br i1 %t441, label %bb77, label %bb78
bb77:
  %t442 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t442, ptr %l180
  br label %bb79
bb78:
  br label %bb114
bb79:
  %t443 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  %t444 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t443, ptr %t444
  store ptr %t444, ptr %l13, !tbaa !29
  %t446 = load ptr, ptr %l13, !tbaa !29
  %t447 = load i32, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %t446, i32 %t447)
  br label %bb80
bb80:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/parse:Parser", ptr %t450, i32 0, i32 30
  %t454 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t452)
  store i64 %t454, ptr %l186
  br label %bb81
bb81:
  %t455 = load i64, ptr %l186, !tbaa !24
  store i64 %t455, ptr %l14, !tbaa !24
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/parse:Parser", ptr %t456, i32 0, i32 30
  %t459 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t458, ptr %t459)
  br label %bb82
bb82:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t462, i32 0, i32 30
  %t465 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t464, ptr %t465)
  br label %bb83
bb83:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t468)
  store i32 %t470, ptr %l194
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb85, label %ok.472
ok.472:
  br label %bb84
bb84:
  br label %bb86
bb85:
  %t473 = load i32, ptr %l194, !tbaa !23
  %t474 = lshr i32 %t473, 16
  %t475 = and i32 %t473, 65535
  %t476 = icmp eq i32 %t474, 1
  %t477 = select i1 %t476, i32 1, i32 0
  %t478 = icmp eq i32 %t473, 0
  %t479 = shl i32 %t477, 16
  %t480 = or i32 %t479, %t475
  %t481 = select i1 %t478, i32 0, i32 %t480
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l196, !tbaa !29
  %t483 = load ptr, ptr %l196, !tbaa !29
  %t484 = getelementptr %"compiler/parse:Parser", ptr %t483, i32 0, i32 20
  %t485 = load i64, ptr %t484, !tbaa !24
  %t486 = load i64, ptr %l5, !tbaa !24
  %t489 = sub i64 %t485, %t486
  %t491 = load ptr, ptr %l196, !tbaa !29
  %t492 = getelementptr %"compiler/parse:Parser", ptr %t491, i32 0, i32 20
  store i64 %t489, ptr %t492, !tbaa !24
  %t494 = insertvalue { i32, ptr } zeroinitializer, i32 %t481, 0
  store { i32, ptr } %t494, ptr %rv
  br label %ret
bb86:
  %t495 = load i64, ptr %l5, !tbaa !24
  %t497 = add i64 %t495, 1
  store i64 %t497, ptr %l5, !tbaa !24
  br label %bb87
bb87:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t499)
  store i32 %t501, ptr %l203
  br label %bb88
bb88:
  %t502 = load i32, ptr %l203
  %t503 = call i1 @compiler_2fparse_2eisOrdering(i32 %t502)
  store i1 %t503, ptr %l204
  br label %bb89
bb89:
  %t504 = load i1, ptr %l204, !tbaa !21
  br i1 %t504, label %bb90, label %bb91
bb90:
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l206, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t506)
  store i32 %t508, ptr %l208
  br label %bb92
bb91:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb94
bb92:
  %t509 = load ptr, ptr %l206, !tbaa !29
  %t510 = load i32, ptr %l208
  %t511 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t509, i32 %t510)
  store i64 %t511, ptr %l209
  br label %bb93
bb93:
  %t512 = load i64, ptr %l209, !tbaa !24
  %t513 = icmp sgt i64 %t512, 0
  store i1 %t513, ptr %l205, !tbaa !21
  br label %bb94
bb94:
  %t515 = load i1, ptr %l205, !tbaa !21
  %t516 = xor i1 %t515, true
  br i1 %t516, label %bb95, label %bb96
bb95:
  br label %bb109
bb96:
  br label %bb97
bb97:
  %t518 = load ptr, ptr %l13, !tbaa !29
  store ptr %t518, ptr %l212, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t519)
  store i32 %t521, ptr %l214
  br label %bb98
bb98:
  %t522 = load ptr, ptr %l212, !tbaa !29
  %t523 = load i32, ptr %l214
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %t522, i32 %t523)
  br label %bb99
bb99:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t524)
  store i32 %t526, ptr %l216
  br label %bb100
bb100:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/parse:Parser", ptr %t527, i32 0, i32 30
  store ptr %t529, ptr %l218, !tbaa !29
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i64, ptr %l7, !tbaa !24
  %t533 = add i64 %t531, 1
  %t536 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t530, i64 %t533)
  %t537 = extractvalue { i32, ptr } %t536, 1
  %t538 = extractvalue { i32, ptr } %t536, 0
  store i32 %t538, ptr %l224
  %t539 = icmp ne i32 %t538, 0
  br i1 %t539, label %bb102, label %ok.540
ok.540:
  store ptr %t537, ptr %l223
  br label %bb101
bb101:
  %t541 = load ptr, ptr %l223, !tbaa !29
  store ptr %t541, ptr %l219, !tbaa !29
  br label %bb103
bb102:
  %t542 = load i32, ptr %l224, !tbaa !23
  %t543 = lshr i32 %t542, 16
  %t544 = and i32 %t542, 65535
  %t545 = icmp eq i32 %t543, 1
  %t546 = select i1 %t545, i32 1, i32 0
  %t547 = icmp eq i32 %t542, 0
  %t548 = shl i32 %t546, 16
  %t549 = or i32 %t548, %t544
  %t550 = select i1 %t547, i32 0, i32 %t549
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l226, !tbaa !29
  %t552 = load ptr, ptr %l226, !tbaa !29
  %t553 = getelementptr %"compiler/parse:Parser", ptr %t552, i32 0, i32 20
  %t554 = load i64, ptr %t553, !tbaa !24
  %t555 = load i64, ptr %l5, !tbaa !24
  %t558 = sub i64 %t554, %t555
  %t560 = load ptr, ptr %l226, !tbaa !29
  %t561 = getelementptr %"compiler/parse:Parser", ptr %t560, i32 0, i32 20
  store i64 %t558, ptr %t561, !tbaa !24
  %t563 = insertvalue { i32, ptr } zeroinitializer, i32 %t550, 0
  store { i32, ptr } %t563, ptr %rv
  br label %ret
bb103:
  %t564 = load ptr, ptr %l218, !tbaa !29
  %t565 = load ptr, ptr %l219, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t564, ptr %t565)
  br label %bb104
bb104:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t566)
  store i32 %t568, ptr %l231
  %t569 = icmp ne i32 %t568, 0
  br i1 %t569, label %bb106, label %ok.570
ok.570:
  br label %bb105
bb105:
  br label %bb107
bb106:
  %t571 = load i32, ptr %l231, !tbaa !23
  %t572 = lshr i32 %t571, 16
  %t573 = and i32 %t571, 65535
  %t574 = icmp eq i32 %t572, 1
  %t575 = select i1 %t574, i32 1, i32 0
  %t576 = icmp eq i32 %t571, 0
  %t577 = shl i32 %t575, 16
  %t578 = or i32 %t577, %t573
  %t579 = select i1 %t576, i32 0, i32 %t578
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l233, !tbaa !29
  %t581 = load ptr, ptr %l233, !tbaa !29
  %t582 = getelementptr %"compiler/parse:Parser", ptr %t581, i32 0, i32 20
  %t583 = load i64, ptr %t582, !tbaa !24
  %t584 = load i64, ptr %l5, !tbaa !24
  %t587 = sub i64 %t583, %t584
  %t589 = load ptr, ptr %l233, !tbaa !29
  %t590 = getelementptr %"compiler/parse:Parser", ptr %t589, i32 0, i32 20
  store i64 %t587, ptr %t590, !tbaa !24
  %t592 = insertvalue { i32, ptr } zeroinitializer, i32 %t579, 0
  store { i32, ptr } %t592, ptr %rv
  br label %ret
bb107:
  %t593 = load i64, ptr %l5, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l5, !tbaa !24
  br label %bb108
bb108:
  br label %bb87
bb109:
  %t597 = load i32, ptr %l4, !tbaa !23
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/parse:Parser", ptr %t598, i32 0, i32 10
  %t601 = load i32, ptr %t600, !tbaa !23
  %t604 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t597, i32 %t601)
  store %"compiler/source:Span" %t604, ptr %l242
  br label %bb110
bb110:
  %t605 = load ptr, ptr %l13, !tbaa !29
  %t607 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v0, ptr %t605)
  store { i64, ptr } %t607, ptr %l244
  br label %bb111
bb111:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/parse:Parser", ptr %t608, i32 0, i32 30
  %t611 = load i64, ptr %l14, !tbaa !24
  %t614 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t610, i64 %t611)
  store { i64, ptr } %t614, ptr %l248
  br label %bb112
bb112:
  %t615 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t616 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t617 = call %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t615, { i64, ptr } %t616)
  store %"compiler/ast:Chain" %t617, ptr %l249
  br label %bb113
bb113:
  %t618 = load %"compiler/ast:Chain", ptr %l249
  %t619 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Chain" %t618, ptr %t619
  store { i64, [5 x i64] } zeroinitializer, ptr %t620
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t620, i32 0, i32 0
  store i64 7, ptr %t621
  %t622 = load %"compiler/source:Span", ptr %l242
  %t623 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t622, 0
  %t625 = insertvalue { %"compiler/source:Span", ptr } %t623, ptr %t619, 1
  %t626 = getelementptr { i64, [5 x i64] }, ptr %t620, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t625, ptr %t626
  %t627 = load { i64, [5 x i64] }, ptr %t620
  %t629 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t627, ptr %t629
  store ptr %t629, ptr %l3, !tbaa !29
  br label %bb140
bb114:
  %t631 = load i32, ptr %l6
  %t633 = trunc i64 83 to i32
  %t634 = icmp eq i32 %t631, %t633
  br i1 %t634, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb117
bb116:
  %t636 = load i32, ptr %l6
  %t638 = trunc i64 84 to i32
  %t639 = icmp eq i32 %t636, %t638
  store i1 %t639, ptr %l255, !tbaa !21
  br label %bb117
bb117:
  %t641 = load i1, ptr %l255, !tbaa !21
  br i1 %t641, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l258, !tbaa !21
  br label %bb120
bb119:
  %t642 = load i32, ptr %l6
  %t644 = trunc i64 85 to i32
  %t645 = icmp eq i32 %t642, %t644
  store i1 %t645, ptr %l258, !tbaa !21
  br label %bb120
bb120:
  %t647 = load i1, ptr %l258, !tbaa !21
  br i1 %t647, label %bb121, label %bb122
bb121:
  %t648 = load ptr, ptr %l3, !tbaa !29
  %t650 = call i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %t648)
  store i1 %t650, ptr %l262
  br label %bb123
bb122:
  br label %bb135
bb123:
  %t651 = load i1, ptr %l262, !tbaa !21
  br i1 %t651, label %bb124, label %bb125
bb124:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/parse:Parser", ptr %t652, i32 0, i32 43
  store ptr %t654, ptr %l264, !tbaa !29
  %t655 = load ptr, ptr %l3, !tbaa !29
  %t657 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t655)
  store %"compiler/source:Span" %t657, ptr %l266
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t658 = load ptr, ptr %l264, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l266
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t658, %"compiler/source:Span" %t659)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t660 = load ptr, ptr %l12, !tbaa !29
  %t662 = call i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %t660)
  store i1 %t662, ptr %l268
  br label %bb129
bb129:
  %t663 = load i1, ptr %l268, !tbaa !21
  br i1 %t663, label %bb130, label %bb131
bb130:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/parse:Parser", ptr %t664, i32 0, i32 43
  store ptr %t666, ptr %l270, !tbaa !29
  %t667 = load ptr, ptr %l12, !tbaa !29
  %t669 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t667)
  store %"compiler/source:Span" %t669, ptr %l272
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t670 = load ptr, ptr %l270, !tbaa !29
  %t671 = load %"compiler/source:Span", ptr %l272
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t670, %"compiler/source:Span" %t671)
  br label %bb133
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t672 = load i32, ptr %l4, !tbaa !23
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t675 = getelementptr %"compiler/parse:Parser", ptr %t673, i32 0, i32 10
  %t676 = load i32, ptr %t675, !tbaa !23
  %t679 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t672, i32 %t676)
  store %"compiler/source:Span" %t679, ptr %l276
  br label %bb136
bb136:
  %t680 = load i32, ptr %l6
  %t681 = load ptr, ptr %l3, !tbaa !29
  %t682 = load ptr, ptr %l12, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t683
  %t684 = getelementptr { i64, [5 x i64] }, ptr %t683, i32 0, i32 0
  store i64 5, ptr %t684
  %t685 = load %"compiler/source:Span", ptr %l276
  %t686 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t685, 0
  %t688 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t686, i32 %t680, 1
  %t690 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t688, ptr %t681, 2
  %t692 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t690, ptr %t682, 3
  %t693 = getelementptr { i64, [5 x i64] }, ptr %t683, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t692, ptr %t693
  %t694 = load { i64, [5 x i64] }, ptr %t683
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t694, ptr %t696
  store ptr %t696, ptr %l3, !tbaa !29
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t698)
  store i32 %t700, ptr %l283
  %t701 = icmp ne i32 %t700, 0
  br i1 %t701, label %bb138, label %ok.702
ok.702:
  br label %bb137
bb137:
  br label %bb139
bb138:
  %t703 = load i32, ptr %l283, !tbaa !23
  %t704 = lshr i32 %t703, 16
  %t705 = and i32 %t703, 65535
  %t706 = icmp eq i32 %t704, 1
  %t707 = select i1 %t706, i32 1, i32 0
  %t708 = icmp eq i32 %t703, 0
  %t709 = shl i32 %t707, 16
  %t710 = or i32 %t709, %t705
  %t711 = select i1 %t708, i32 0, i32 %t710
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l285, !tbaa !29
  %t713 = load ptr, ptr %l285, !tbaa !29
  %t714 = getelementptr %"compiler/parse:Parser", ptr %t713, i32 0, i32 20
  %t715 = load i64, ptr %t714, !tbaa !24
  %t716 = load i64, ptr %l5, !tbaa !24
  %t719 = sub i64 %t715, %t716
  %t721 = load ptr, ptr %l285, !tbaa !29
  %t722 = getelementptr %"compiler/parse:Parser", ptr %t721, i32 0, i32 20
  store i64 %t719, ptr %t722, !tbaa !24
  %t724 = insertvalue { i32, ptr } zeroinitializer, i32 %t711, 0
  store { i32, ptr } %t724, ptr %rv
  br label %ret
bb139:
  %t725 = load i64, ptr %l5, !tbaa !24
  %t727 = add i64 %t725, 1
  store i64 %t727, ptr %l5, !tbaa !24
  br label %bb140
bb140:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/token:Token"
  %l15 = alloca %"compiler/parse:stackMarks"
  %l16 = alloca i64
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l29 = alloca i32
  %l32 = alloca %"compiler/token:Token"
  %l34 = alloca i32
  %l63 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l84 = alloca i32
  %l86 = alloca %"compiler/token:Token"
  %l95 = alloca ptr
  %l96 = alloca { i64, [3 x i64] }
  %l98 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca %"compiler/msgs:Msg"
  %l103 = alloca i64
  %l108 = alloca i32
  %l125 = alloca %"compiler/parse:stackMarks"
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i32
  %l134 = alloca i1
  %l140 = alloca i32
  %l166 = alloca i1
  %l171 = alloca ptr
  %l173 = alloca { i64, ptr }
  %l175 = alloca i32
  %l176 = alloca i32
  %l193 = alloca i32
  %l197 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t189 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 94)
  store i1 %t4, ptr %l20
  br label %bb1
bb1:
  %t5 = load i1, ptr %l20, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l22, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 94)
  store { i64, ptr } %t10, ptr %l24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t11 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = load ptr, ptr %l22, !tbaa !29
  %t20 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t18, { i64, ptr } %t17)
  store i32 %t20, ptr %l26
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22
ok.22:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l26, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s1)
  %t33 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t31, 0
  store { i32, { i64, ptr } } %t33, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l29
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l29, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t47, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t50)
  store %"compiler/token:Token" %t52, ptr %l32
  br label %bb12
bb12:
  %t53 = load %"compiler/token:Token", ptr %l32
  store %"compiler/token:Token" %t53, ptr %l1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l34
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 12
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l2, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 16
  %t66 = load i1, ptr %t65, !tbaa !21
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 12
  store i1 %t66, ptr %t69, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 16
  store i1 false, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 17
  %t76 = load i64, ptr %t75, !tbaa !24
  store i64 %t76, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t78, i32 0, i32 17
  store i64 0, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 18
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l4, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 18
  store i1 false, ptr %t88, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t89, i32 0, i32 19
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l5, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 19
  store i1 false, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 13
  %t100 = load i1, ptr %t99, !tbaa !21
  store i1 %t100, ptr %l6, !tbaa !21
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 13
  store i1 false, ptr %t104, !tbaa !21
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 15
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l7, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 14
  %t113 = load i1, ptr %t112, !tbaa !21
  store i1 %t113, ptr %l8, !tbaa !21
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/parse:Parser", ptr %t115, i32 0, i32 15
  store i1 false, ptr %t119, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t120, i32 0, i32 14
  store i1 false, ptr %t124, !tbaa !21
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/parse:Parser", ptr %t125, i32 0, i32 31
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t127)
  store i64 %t129, ptr %l63
  br label %bb14
bb14:
  %t130 = load i64, ptr %l63, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t131)
  br label %bb16
bb16:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t133, i32 95)
  store i1 %t136, ptr %l67
  br label %bb17
bb17:
  %t137 = load i1, ptr %l67, !tbaa !21
  br i1 %t137, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t138, i32 0)
  store i1 %t141, ptr %l71
  br label %bb20
bb20:
  %t142 = load i1, ptr %l71, !tbaa !21
  store i1 %t142, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t143 = load i1, ptr %l68, !tbaa !21
  br i1 %t143, label %bb22, label %bb23
bb22:
  br label %bb59
bb23:
  br label %bb24
bb24:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l73
  br label %bb25
bb25:
  %t147 = load i1, ptr %l73, !tbaa !21
  br i1 %t147, label %bb26, label %bb27
bb26:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 21
  %t151 = load i1, ptr %t150, !tbaa !21
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb28, label %bb29
bb27:
  br label %bb41
bb28:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t155, i32 0, i32 23
  %t158 = load i1, ptr %t157, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l77, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb30
bb30:
  %t162 = load i1, ptr %l77, !tbaa !21
  br i1 %t162, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t166, i32 %t168)
  store i32 %t171, ptr %l84
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t172 = load i32, ptr %l84, !tbaa !23
  store i32 %t172, ptr %l12, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t173)
  store %"compiler/token:Token" %t175, ptr %l86
  br label %bb34
bb34:
  %t176 = load %"compiler/token:Token", ptr %l86
  store %"compiler/token:Token" %t176, ptr %l13
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/parse:Parser", ptr %t177, i32 0, i32 5
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 2
  %t182 = load i32, ptr %t181, !tbaa !23
  %t184 = sext i32 %t182 to i64
  %t185 = getelementptr %"compiler/token:Token", ptr %l13, i32 0, i32 3
  %t186 = load i32, ptr %t185, !tbaa !23
  %t188 = sext i32 %t186 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 0
  store i64 3, ptr %t190
  %t192 = insertvalue { i64, i64, i64 } undef, i64 %t180, 0
  %t194 = insertvalue { i64, i64, i64 } %t192, i64 %t184, 1
  %t196 = insertvalue { i64, i64, i64 } %t194, i64 %t188, 2
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 1
  store { i64, i64, i64 } %t196, ptr %t197
  %t198 = load { i64, [3 x i64] }, ptr %t189
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t200, i32 0, i32 4
  %t203 = load ptr, ptr %t202, !tbaa !29
  store ptr %t203, ptr %l95, !tbaa !29
  store { i64, [3 x i64] } %t198, ptr %l96
  %t205 = load i32, ptr %l12, !tbaa !23
  %t207 = sext i32 %t205 to i64
  store i64 %t207, ptr %l98, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s5, ptr %t208)
  store { i64, ptr } %t210, ptr %l100
  br label %bb35
bb35:
  %t211 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load i64, ptr %l98, !tbaa !24
  %t220 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %s5, ptr %s5, i64 %t218, { i64, ptr } %t217)
  store %"compiler/msgs:Msg" %t220, ptr %l102
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l95, !tbaa !29
  %t222 = load { i64, [3 x i64] }, ptr %l96
  %t223 = load %"compiler/msgs:Msg", ptr %l102
  %t224 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s5, ptr %t221, { i64, [3 x i64] } %t222, %"compiler/msgs:Msg" %t223)
  store i64 %t224, ptr %l103
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/parse:Parser", ptr %t225, i32 0, i32 31
  %t228 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t227, i64 %t228)
  br label %bb39
bb39:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/parse:Parser", ptr %t231, i32 0, i32 23
  store i1 true, ptr %t233, !tbaa !21
  store i32 65536, ptr %l108, !tbaa !23
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l7, !tbaa !21
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t234, i32 0, i32 15
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i1, ptr %l8, !tbaa !21
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t239, i32 0, i32 14
  store i1 %t240, ptr %t243, !tbaa !21
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i1, ptr %l6, !tbaa !21
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 13
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i1, ptr %l5, !tbaa !21
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t249, i32 0, i32 19
  store i1 %t250, ptr %t253, !tbaa !21
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i1, ptr %l4, !tbaa !21
  %t258 = getelementptr %"compiler/parse:Parser", ptr %t254, i32 0, i32 18
  store i1 %t255, ptr %t258, !tbaa !21
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l3, !tbaa !24
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 17
  store i64 %t260, ptr %t263, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i1, ptr %l2, !tbaa !21
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t264, i32 0, i32 12
  store i1 %t265, ptr %t268, !tbaa !21
  %t269 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t269)
  br label %bb40
bb40:
  %t271 = load i32, ptr %l108, !tbaa !23
  %t272 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t271, 0
  store { i32, { i64, ptr } } %t272, ptr %rv
  br label %ret
bb41:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %t273)
  store %"compiler/parse:stackMarks" %t275, ptr %l125
  br label %bb42
bb42:
  %t276 = load %"compiler/parse:stackMarks", ptr %l125
  store %"compiler/parse:stackMarks" %t276, ptr %l15
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/parse:Parser", ptr %t277, i32 0, i32 6
  %t280 = load i64, ptr %t279, !tbaa !24
  store i64 %t280, ptr %l16, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %t282)
  %t285 = extractvalue { i32, ptr } %t284, 1
  %t286 = extractvalue { i32, ptr } %t284, 0
  store i32 %t286, ptr %l131
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb44, label %ok.288
ok.288:
  store ptr %t285, ptr %l130
  br label %bb43
bb43:
  %t289 = load ptr, ptr %l130, !tbaa !29
  store ptr %t289, ptr %l128, !tbaa !29
  br label %bb56
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/parse:Parser", ptr %t290, i32 0, i32 21
  %t293 = load i1, ptr %t292, !tbaa !21
  br i1 %t293, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb48
bb47:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/parse:Parser", ptr %t295, i32 0, i32 23
  %t298 = load i1, ptr %t297, !tbaa !21
  store i1 %t298, ptr %l134, !tbaa !21
  br label %bb48
bb48:
  %t300 = load i1, ptr %l134, !tbaa !21
  br i1 %t300, label %bb49, label %bb50
bb49:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/parse:Parser", ptr %t301, i32 0, i32 31
  %t304 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t303, i64 %t304)
  br label %bb51
bb50:
  br label %bb53
bb51:
  store i32 65536, ptr %l140, !tbaa !23
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i1, ptr %l7, !tbaa !21
  %t311 = getelementptr %"compiler/parse:Parser", ptr %t307, i32 0, i32 15
  store i1 %t308, ptr %t311, !tbaa !21
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i1, ptr %l8, !tbaa !21
  %t316 = getelementptr %"compiler/parse:Parser", ptr %t312, i32 0, i32 14
  store i1 %t313, ptr %t316, !tbaa !21
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i1, ptr %l6, !tbaa !21
  %t321 = getelementptr %"compiler/parse:Parser", ptr %t317, i32 0, i32 13
  store i1 %t318, ptr %t321, !tbaa !21
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i1, ptr %l5, !tbaa !21
  %t326 = getelementptr %"compiler/parse:Parser", ptr %t322, i32 0, i32 19
  store i1 %t323, ptr %t326, !tbaa !21
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i1, ptr %l4, !tbaa !21
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t327, i32 0, i32 18
  store i1 %t328, ptr %t331, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i64, ptr %l3, !tbaa !24
  %t336 = getelementptr %"compiler/parse:Parser", ptr %t332, i32 0, i32 17
  store i64 %t333, ptr %t336, !tbaa !24
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i1, ptr %l2, !tbaa !21
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t337, i32 0, i32 12
  store i1 %t338, ptr %t341, !tbaa !21
  %t342 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t342)
  br label %bb52
bb52:
  %t344 = load i32, ptr %l140, !tbaa !23
  %t345 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t344, 0
  store { i32, { i64, ptr } } %t345, ptr %rv
  br label %ret
bb53:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load %"compiler/parse:stackMarks", ptr %l15
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %t346, %"compiler/parse:stackMarks" %t347)
  br label %bb54
bb54:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t350, i32 0, i32 18
  store i1 false, ptr %t352, !tbaa !21
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %t353, i64 %t354)
  br label %bb55
bb55:
  br label %bb58
bb56:
  %t357 = load ptr, ptr %l128, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/parse:Parser", ptr %t358, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t360, ptr %t357)
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb15
bb59:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t367 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t364, i32 95)
  store i1 %t367, ptr %l166
  br label %bb60
bb60:
  %t368 = load i1, ptr %l166, !tbaa !21
  %t369 = xor i1 %t368, true
  br i1 %t369, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s34
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/parse:Parser", ptr %t371, i32 0, i32 31
  %t374 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t373, i64 %t374)
  br label %bb63
bb62:
  br label %bb69
bb63:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l171, !tbaa !29
  %t379 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s34, i32 95)
  store { i64, ptr } %t379, ptr %l173
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 0
  %t382 = extractvalue { i64, ptr } %t380, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  %t387 = load ptr, ptr %l171, !tbaa !29
  %t389 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s34, ptr %t387, { i64, ptr } %t386)
  store i32 %t389, ptr %l175
  %t390 = icmp ne i32 %t389, 0
  br i1 %t390, label %bb66, label %ok.391
ok.391:
  br label %bb65
bb65:
  br label %bb68
bb66:
  %t392 = load i32, ptr %l175, !tbaa !23
  %t393 = lshr i32 %t392, 16
  %t394 = and i32 %t392, 65535
  %t395 = icmp eq i32 %t393, 1
  %t396 = select i1 %t395, i32 1, i32 0
  %t397 = icmp eq i32 %t392, 0
  %t398 = shl i32 %t396, 16
  %t399 = or i32 %t398, %t394
  %t400 = select i1 %t397, i32 0, i32 %t399
  store i32 %t400, ptr %l176, !tbaa !23
  call void @__olang_scope_close(ptr %s34)
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i1, ptr %l7, !tbaa !21
  %t405 = getelementptr %"compiler/parse:Parser", ptr %t401, i32 0, i32 15
  store i1 %t402, ptr %t405, !tbaa !21
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i1, ptr %l8, !tbaa !21
  %t410 = getelementptr %"compiler/parse:Parser", ptr %t406, i32 0, i32 14
  store i1 %t407, ptr %t410, !tbaa !21
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i1, ptr %l6, !tbaa !21
  %t415 = getelementptr %"compiler/parse:Parser", ptr %t411, i32 0, i32 13
  store i1 %t412, ptr %t415, !tbaa !21
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i1, ptr %l5, !tbaa !21
  %t420 = getelementptr %"compiler/parse:Parser", ptr %t416, i32 0, i32 19
  store i1 %t417, ptr %t420, !tbaa !21
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i1, ptr %l4, !tbaa !21
  %t425 = getelementptr %"compiler/parse:Parser", ptr %t421, i32 0, i32 18
  store i1 %t422, ptr %t425, !tbaa !21
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load i64, ptr %l3, !tbaa !24
  %t430 = getelementptr %"compiler/parse:Parser", ptr %t426, i32 0, i32 17
  store i64 %t427, ptr %t430, !tbaa !24
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load i1, ptr %l2, !tbaa !21
  %t435 = getelementptr %"compiler/parse:Parser", ptr %t431, i32 0, i32 12
  store i1 %t432, ptr %t435, !tbaa !21
  %t436 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t436)
  br label %bb67
bb67:
  %t438 = load i32, ptr %l176, !tbaa !23
  %t439 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t438, 0
  store { i32, { i64, ptr } } %t439, ptr %rv
  br label %ret
bb68:
  call void @__olang_scope_close(ptr %s34)
  br label %bb69
bb69:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t440)
  store i32 %t442, ptr %l193
  br label %bb70
bb70:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/parse:Parser", ptr %t443, i32 0, i32 31
  %t446 = load i64, ptr %l11, !tbaa !24
  %t449 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t445, i64 %t446)
  store { i64, ptr } %t449, ptr %l197
  br label %bb71
bb71:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i1, ptr %l7, !tbaa !21
  %t454 = getelementptr %"compiler/parse:Parser", ptr %t450, i32 0, i32 15
  store i1 %t451, ptr %t454, !tbaa !21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i1, ptr %l8, !tbaa !21
  %t459 = getelementptr %"compiler/parse:Parser", ptr %t455, i32 0, i32 14
  store i1 %t456, ptr %t459, !tbaa !21
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i1, ptr %l6, !tbaa !21
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 13
  store i1 %t461, ptr %t464, !tbaa !21
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i1, ptr %l5, !tbaa !21
  %t469 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 19
  store i1 %t466, ptr %t469, !tbaa !21
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i1, ptr %l4, !tbaa !21
  %t474 = getelementptr %"compiler/parse:Parser", ptr %t470, i32 0, i32 18
  store i1 %t471, ptr %t474, !tbaa !21
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load i64, ptr %l3, !tbaa !24
  %t479 = getelementptr %"compiler/parse:Parser", ptr %t475, i32 0, i32 17
  store i64 %t476, ptr %t479, !tbaa !24
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i1, ptr %l2, !tbaa !21
  %t484 = getelementptr %"compiler/parse:Parser", ptr %t480, i32 0, i32 12
  store i1 %t481, ptr %t484, !tbaa !21
  %t485 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t485)
  br label %bb72
bb72:
  %t487 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t488 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t487, 1
  store { i32, { i64, ptr } } %t488, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l12 = alloca i32
  %l15 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 81)
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t23 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t20)
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s1)
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l15
  br label %bb10
bb10:
  %t39 = load i32, ptr %l15, !tbaa !23
  store i32 %t39, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 41
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 6
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = sub i64 %t46, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t42, i64 %t48)
  br label %bb11
bb11:
  %t51 = load i32, ptr %l1
  %t53 = trunc i64 81 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i32 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l23, !tbaa !29
  %t57 = load i32, ptr %l1
  %t59 = trunc i64 89 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i32 81, ptr %l26
  br label %bb20
bb16:
  %t63 = load i32, ptr %l1
  %t65 = trunc i64 82 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i32 60, ptr %l30
  br label %bb19
bb18:
  store i32 82, ptr %l30
  br label %bb19
bb19:
  %t70 = load i32, ptr %l30
  store i32 %t70, ptr %l26
  br label %bb20
bb20:
  %t71 = load i32, ptr %l26
  %t72 = load ptr, ptr %l23, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 7
  store i32 %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t77 = add i32 %t75, 1
  %t80 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 8
  store i32 %t77, ptr %t80, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 9
  store i32 81, ptr %t84
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t88 = add i32 %t86, 1
  %t91 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 10
  store i32 %t88, ptr %t91, !tbaa !23
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclStarts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l30 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l50 = alloca i1
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load i32, ptr %l2
  %t18 = trunc i64 34 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t21 = load i32, ptr %l2
  %t23 = trunc i64 42 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i32, ptr %l2
  %t29 = trunc i64 41 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t33 = load i32, ptr %l2
  %t35 = trunc i64 44 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l16, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i32, ptr %l2
  %t42 = trunc i64 1 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/scan:Tokens", ptr %t51, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t47, %t56
  store i1 %t59, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l22, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/parse:Parser", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/scan:Tokens", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = load i64, ptr %l1, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/token:Token", ptr %t73, i64 %t70
  %t75 = load %"compiler/token:Token", ptr %t74
  %t78 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t62, %"compiler/token:Token" %t75)
  store { i64, ptr } %t78, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb20
bb18:
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t80, ptr %l38
  br label %bb19
bb19:
  %t81 = load i1, ptr %l38, !tbaa !21
  store i1 %t81, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l30, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/scan:Tokens", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l42, !tbaa !27
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/token:Token", ptr %t95, i64 %t92
  %t97 = getelementptr %"compiler/token:Token", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97
  %t100 = trunc i64 38 to i32
  %t101 = icmp eq i32 %t98, %t100
  store i1 %t101, ptr %l39, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t103 = load i1, ptr %l39, !tbaa !21
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t105 = load i32, ptr %l2
  %t107 = trunc i64 38 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t110 = load i64, ptr %l1, !tbaa !24
  %t112 = add i64 %t110, 1
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/scan:Tokens", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t112, %t121
  store i1 %t124, ptr %l50, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t126 = load i1, ptr %l50, !tbaa !21
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/parse:Parser", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/scan:Tokens", ptr %t130, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l61, !tbaa !27
  %t134 = load i64, ptr %l1, !tbaa !24
  %t136 = add i64 %t134, 1
  %t138 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/token:Token", ptr %t139, i64 %t136
  %t141 = getelementptr %"compiler/token:Token", ptr %t140, i32 0, i32 0
  %t142 = load i32, ptr %t141
  %t144 = trunc i64 1 to i32
  %t145 = icmp eq i32 %t142, %t144
  store i1 %t145, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load i1, ptr %l58, !tbaa !21
  store i1 %t147, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i64
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t149 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 92)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t8)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l10
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14
ok.14:
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l7, !tbaa !29
  %t28 = insertvalue { i32, ptr } zeroinitializer, ptr %t27, 1
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l13
  br label %bb8
bb8:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l1, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t33, i32 0, i32 30
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l16
  br label %bb9
bb9:
  %t38 = load i64, ptr %l16, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 93)
  store i1 %t42, ptr %l19
  br label %bb11
bb11:
  %t43 = load i1, ptr %l19, !tbaa !21
  %t44 = xor i1 %t43, true
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 30
  store ptr %t50, ptr %l23, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %t51)
  %t54 = extractvalue { i32, ptr } %t53, 1
  %t55 = extractvalue { i32, ptr } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57
ok.57:
  store ptr %t54, ptr %l26
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l26, !tbaa !29
  store ptr %t58, ptr %l24, !tbaa !29
  br label %bb17
bb16:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t67, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t70, ptr %t71)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t72, i32 93)
  %t76 = extractvalue { i32, i1 } %t75, 1
  %t77 = extractvalue { i32, i1 } %t75, 0
  store i32 %t77, ptr %l33
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb20, label %ok.79
ok.79:
  store i1 %t76, ptr %l32
  br label %bb19
bb19:
  %t80 = load i1, ptr %l32, !tbaa !21
  store i1 %t80, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb21:
  %t92 = load i1, ptr %l29, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb10
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t95, i32 93)
  store i1 %t98, ptr %l38
  br label %bb27
bb27:
  %t99 = load i1, ptr %l38, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 30
  %t105 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t104, i64 %t105)
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l43, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 93)
  store { i64, ptr } %t110, ptr %l45
  br label %bb31
bb31:
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l43, !tbaa !29
  %t120 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t118, { i64, ptr } %t117)
  store i32 %t120, ptr %l47
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb33, label %ok.122
ok.122:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t123 = load i32, ptr %l47, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  call void @__olang_scope_close(ptr %s4)
  %t133 = insertvalue { i32, ptr } zeroinitializer, i32 %t131, 0
  store { i32, ptr } %t133, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t134)
  store i32 %t136, ptr %l50
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t137, i32 %t138)
  store %"compiler/source:Span" %t141, ptr %l53
  br label %bb37
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 30
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t144, i64 %t145)
  store { i64, ptr } %t148, ptr %l57
  br label %bb38
bb38:
  store { i64, [5 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 0
  store i64 19, ptr %t150
  %t151 = load %"compiler/source:Span", ptr %l53
  %t152 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t151, 0
  %t153 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t154 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t152, { i64, ptr } %t153, 1
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t149
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  %t160 = insertvalue { i32, ptr } zeroinitializer, ptr %t158, 1
  store { i32, ptr } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca i32
  %l19 = alloca %"compiler/token:Token"
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca %"compiler/token:Token"
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 58)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t8, i64 1)
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7
  %t13 = trunc i64 58 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t19, i64 2)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13
  %t24 = trunc i64 58 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t31, i64 1)
  store %"compiler/token:Token" %t33, ptr %l19
  br label %bb13
bb13:
  %t34 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t35 = load %"compiler/token:Token", ptr %l19
  %t37 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t35, i8 %t34)
  store i1 %t37, ptr %l21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l21, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t41, i64 2)
  store %"compiler/token:Token" %t43, ptr %l25
  br label %bb17
bb16:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb19
bb17:
  %t44 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t45 = load %"compiler/token:Token", ptr %l25
  %t47 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t45, i8 %t44)
  store i1 %t47, ptr %l27
  br label %bb18
bb18:
  %t48 = load i1, ptr %l27, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l23, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l23, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 15
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t17)
  store i32 %t19, ptr %l11
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb8:
  %t20 = load i32, ptr %l1
  %t22 = trunc i64 95 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb10:
  %t25 = load i32, ptr %l1
  %t27 = trunc i64 0 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 13
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 10 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb20
bb17:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb19
bb18:
  %t41 = load i32, ptr %l1
  %t43 = trunc i64 12 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l22, !tbaa !21
  store i1 %t46, ptr %l19, !tbaa !21
  br label %bb20
bb20:
  %t47 = load i1, ptr %l19, !tbaa !21
  br i1 %t47, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 15
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t53 = load i32, ptr %l1
  %t55 = trunc i64 91 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb32
bb26:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb28
bb27:
  %t58 = load i32, ptr %l1
  %t60 = trunc i64 93 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb30:
  %t64 = load i32, ptr %l1
  %t66 = trunc i64 57 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %l27, !tbaa !21
  br label %bb32
bb32:
  %t70 = load i1, ptr %l27, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t71, i32 0, i32 9
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l2
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 83 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb38
bb37:
  %t81 = load i32, ptr %l2
  %t83 = trunc i64 81 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb38
bb38:
  %t86 = load i1, ptr %l40, !tbaa !21
  br i1 %t86, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb41
bb40:
  %t87 = load i32, ptr %l2
  %t89 = trunc i64 95 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb41
bb41:
  %t92 = load i1, ptr %l43, !tbaa !21
  br i1 %t92, label %bb42, label %bb43
bb42:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t93)
  store i1 %t95, ptr %l48
  br label %bb44
bb43:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb45
bb44:
  %t96 = load i1, ptr %l48, !tbaa !21
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb45
bb45:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t100, ptr %l51
  br label %bb49
bb49:
  %t101 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t110 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s0, ptr %t108, { i64, ptr } %t107)
  store i32 %t110, ptr %l53
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb51, label %ok.112
ok.112:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t113 = load i32, ptr %l53, !tbaa !23
  %t114 = lshr i32 %t113, 16
  %t115 = and i32 %t113, 65535
  %t116 = icmp eq i32 %t114, 1
  %t117 = select i1 %t116, i32 1, i32 0
  %t118 = icmp eq i32 %t113, 0
  %t119 = shl i32 %t117, 16
  %t120 = or i32 %t119, %t115
  %t121 = select i1 %t118, i32 0, i32 %t120
  call void @__olang_scope_close(ptr %s0)
  store i32 %t121, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t1, i32 57)
  store i1 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t6)
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t8, i32 8)
  store i1 %t11, ptr %l7
  br label %bb6
bb6:
  %t12 = load i1, ptr %l7, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t15, i32 95)
  store i1 %t18, ptr %l12
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  %t19 = load i1, ptr %l12, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t22 = load i1, ptr %l9, !tbaa !21
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t23, i32 0)
  store i1 %t26, ptr %l17
  br label %bb13
bb12:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb14
bb13:
  %t27 = load i1, ptr %l17, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb14
bb14:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 95)
  store { i64, ptr } %t33, ptr %l21
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l19, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t41, { i64, ptr } %t40)
  store i32 %t43, ptr %l23
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb19, label %ok.45
ok.45:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s2)
  store i32 %t54, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t56)
  store i32 %t58, ptr %l26
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb23, label %ok.60
ok.60:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t61 = load i32, ptr %l26, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  store i32 %t69, ptr %rv
  br label %ret
bb24:
  %t71 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t71)
  br label %bb25
bb25:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i64
  %l15 = alloca i1
  %l17 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l33 = alloca i32
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 94)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l7
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 35
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l11
  br label %bb4
bb4:
  %t26 = load i64, ptr %l11, !tbaa !24
  store i64 %t26, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t27)
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t29, i32 95)
  store i1 %t32, ptr %l15
  br label %bb6
bb6:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t34, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t36, ptr %l17
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  br label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l17, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  call void @__olang_scope_close(ptr %s1)
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t47, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t50, i32 95)
  store i1 %t53, ptr %l21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l21, !tbaa !21
  %t55 = xor i1 %t54, true
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, i32 } %t61, 1
  %t63 = extractvalue { i32, i32 } %t61, 0
  store i32 %t63, ptr %l27
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65
ok.65:
  store i32 %t62, ptr %l26
  br label %bb18
bb18:
  %t66 = load i32, ptr %l26, !tbaa !23
  store i32 %t66, ptr %l24, !tbaa !23
  br label %bb20
bb19:
  %t67 = load i32, ptr %l27, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t75, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb20:
  %t78 = load i32, ptr %l24, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t79, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t81, i32 %t78)
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t85)
  store i32 %t87, ptr %l33
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb23, label %ok.89
ok.89:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t90 = load i32, ptr %l33, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  %t100 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t98, 0
  store { i32, { i64, ptr } } %t100, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb13
bb26:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l36
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 35
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l40
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t112 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t111, 1
  store { i32, { i64, ptr } } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t1, i64 1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %t21, ptr %t20)
  %t26 = extractvalue { i32, ptr } %t25, 1
  %t27 = extractvalue { i32, ptr } %t25, 0
  store i32 %t27, ptr %l11
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29
ok.29:
  store ptr %t26, ptr %l10
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l10, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  br label %bb6
bb5:
  %t31 = load i32, ptr %l11, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  %t41 = insertvalue { i32, ptr } zeroinitializer, i32 %t39, 0
  store { i32, ptr } %t41, ptr %rv
  br label %ret
bb6:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t43 = insertvalue { i32, ptr } zeroinitializer, ptr %t42, 1
  store { i32, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t192 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 35
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l20, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 35
  %t27 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t26, i32 %t27)
  br label %bb8
bb8:
  br label %bb23
bb9:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 15
  store i1 %t37, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l29, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 35
  %t54 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t53, i32 %t54)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb21
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 35
  %t62 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t61, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t65, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t67, ptr %l44
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb19, label %ok.69
ok.69:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s4)
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 %t78, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 35
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l49
  br label %bb24
bb24:
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = icmp sle i64 %t95, 2305843009213693951
  br i1 %t96, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5d5da79af2b44d73_2d4623f2243944cf)
  unreachable
bb27:
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = mul i64 %t98, 4
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5d5da79af2b44d73_2d4623f2243944cf)
  unreachable
bb29:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb34
bb31:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l63, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb33
bb33:
  %t134 = load i64, ptr %l63, !tbaa !24
  store i64 %t134, ptr %l60, !tbaa !24
  br label %bb34
bb34:
  %t135 = load i64, ptr %l60, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  %t136 = load i64, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  store i64 %t152, ptr %l14, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t154, ptr %l81, !tbaa !27
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t156, ptr %l83, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t161 = sub i64 %t159, 1
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = sub i64 %t161, %t162
  %t167 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t173 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 %t155
  store i32 %t170, ptr %t175, !tbaa !33
  br label %bb39
bb39:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l13, !tbaa !24
  br label %bb35
bb40:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t180)
  store %"compiler/source:Span" %t182, ptr %l93
  br label %bb41
bb41:
  %t183 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t183, ptr %l94, !tbaa !27
  %t184 = icmp sge i64 0, 0
  br i1 %t184, label %bb42, label %bb43
bb42:
  %t186 = icmp sle i64 0, 1152921504606846975
  br i1 %t186, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb44:
  %t188 = mul i64 0, 8
  %t189 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 0, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l93
  %t195 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t194, 0
  %t196 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t197 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t195, { i64, ptr } %t196, 1
  %t199 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t197, { i64, ptr } %t191, 2
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  %t205 = insertvalue { i32, ptr } zeroinitializer, ptr %t203, 1
  store { i32, ptr } %t205, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l19 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 30
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t7)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store ptr %t10, ptr %l8
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  br label %bb7
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 30
  %t18 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb6
bb6:
  %t22 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t26, ptr %t23)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t30, i32 57)
  store i1 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i1, ptr %l19, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb2
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 30
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t39, i64 %t40)
  store { i64, ptr } %t43, ptr %l24
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i64
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l89 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/ast:Multi"
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca %"compiler/source:Span"
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l131 = alloca %"compiler/ast:VarDecl"
  %l135 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i32
  %l143 = alloca i32
  %l145 = alloca i1
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca i32
  %l155 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l167 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %rv = alloca { i32, ptr }
  %t217 = alloca { i64, [4 x i64] }, align 8
  %t319 = alloca { i64, [4 x i64] }, align 8
  %t413 = alloca { i64, [4 x i64] }, align 8
  %t453 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l20
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store ptr %t8, ptr %l19
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l19, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l20, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 57)
  store i1 %t28, ptr %l24
  br label %bb5
bb5:
  %t29 = load i1, ptr %l24, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 30
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l27
  br label %bb8
bb7:
  br label %bb82
bb8:
  %t35 = load i64, ptr %l27, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 30
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t42, i32 57)
  store i1 %t45, ptr %l33
  br label %bb11
bb11:
  %t46 = load i1, ptr %l33, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 30
  store ptr %t51, ptr %l36, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t52)
  %t55 = extractvalue { i32, ptr } %t54, 1
  %t56 = extractvalue { i32, ptr } %t54, 0
  store i32 %t56, ptr %l40
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb16, label %ok.58
ok.58:
  store ptr %t55, ptr %l39
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l39, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  br label %bb17
bb16:
  %t60 = load i32, ptr %l40, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  %t70 = insertvalue { i32, ptr } zeroinitializer, i32 %t68, 0
  store { i32, ptr } %t70, ptr %rv
  br label %ret
bb17:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t71, ptr %t72)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb10
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 30
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t75, i64 %t76)
  store { i64, ptr } %t79, ptr %l45
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t81, i32 62)
  store i1 %t84, ptr %l48
  br label %bb22
bb22:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 12
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t96 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v0, ptr %t92, { i64, ptr } %t93)
  %t97 = extractvalue { i32, ptr } %t96, 1
  %t98 = extractvalue { i32, ptr } %t96, 0
  store i32 %t98, ptr %l56
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb29, label %ok.100
ok.100:
  store ptr %t97, ptr %l55
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t101 = load ptr, ptr %l55, !tbaa !29
  store ptr %t101, ptr %l52, !tbaa !29
  br label %bb30
bb29:
  %t102 = load i32, ptr %l56, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  %t112 = insertvalue { i32, ptr } zeroinitializer, i32 %t110, 0
  store { i32, ptr } %t112, ptr %rv
  br label %ret
bb30:
  %t113 = load ptr, ptr %l52, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t114, i32 %t115, ptr %t113)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l63
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb32, label %ok.124
ok.124:
  store ptr %t121, ptr %l62
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l62, !tbaa !29
  store ptr %t125, ptr %l58, !tbaa !29
  br label %bb33
bb32:
  %t126 = load i32, ptr %l63, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb33:
  %t137 = load ptr, ptr %l58, !tbaa !29
  %t138 = insertvalue { i32, ptr } zeroinitializer, ptr %t137, 1
  store { i32, ptr } %t138, ptr %rv
  br label %ret
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t139, i32 62)
  store i1 %t142, ptr %l67
  br label %bb35
bb35:
  %t143 = load i1, ptr %l67, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb39
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t144, i32 60)
  store i1 %t147, ptr %l71
  br label %bb38
bb38:
  %t148 = load i1, ptr %l71, !tbaa !21
  store i1 %t148, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t149 = load i1, ptr %l68, !tbaa !21
  br i1 %t149, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t150, i32 0, i32 9
  %t153 = load i32, ptr %t152
  %t155 = trunc i64 62 to i32
  %t156 = icmp eq i32 %t153, %t155
  store i1 %t156, ptr %l6, !tbaa !21
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t159)
  store i32 %t161, ptr %l77
  br label %bb42
bb41:
  br label %bb51
bb42:
  %t162 = load i32, ptr %l77, !tbaa !23
  %t163 = load ptr, ptr %l75, !tbaa !29
  %t164 = getelementptr %"compiler/parse:Parser", ptr %t163, i32 0, i32 24
  store i32 %t162, ptr %t164, !tbaa !23
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %t165)
  %t168 = extractvalue { i32, { i64, ptr } } %t167, 1
  %t169 = extractvalue { i32, { i64, ptr } } %t167, 0
  store i32 %t169, ptr %l81
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb44, label %ok.171
ok.171:
  store { i64, ptr } %t168, ptr %l80
  br label %bb43
bb43:
  %t172 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t172, ptr %l78, !tbaa !27
  br label %bb45
bb44:
  %t173 = load i32, ptr %l81, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  %t183 = insertvalue { i32, ptr } zeroinitializer, i32 %t181, 0
  store { i32, ptr } %t183, ptr %rv
  br label %ret
bb45:
  %t184 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t184, ptr %l7, !tbaa !27
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t185, i32 %t186)
  store %"compiler/source:Span" %t189, ptr %l85
  br label %bb46
bb46:
  %t190 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t190, ptr %l8
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t191)
  store i32 %t193, ptr %l87
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb48, label %ok.195
ok.195:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t196 = load i32, ptr %l87, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  %t206 = insertvalue { i32, ptr } zeroinitializer, i32 %t204, 0
  store { i32, ptr } %t206, ptr %rv
  br label %ret
bb49:
  %t207 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t207, ptr %l89
  %t208 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t209 = load i1, ptr %l6, !tbaa !21
  %t210 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t214 = call %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t208, i1 %t209, { i64, ptr } %t210)
  store %"compiler/ast:Multi" %t214, ptr %l93
  br label %bb50
bb50:
  %t215 = load %"compiler/ast:Multi", ptr %l93
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:Multi" %t215, ptr %t216
  store { i64, [4 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t219 = load %"compiler/source:Span", ptr %l89
  %t220 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t219, 0
  %t222 = insertvalue { %"compiler/source:Span", ptr } %t220, ptr %t216, 1
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t217, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t222, ptr %t223
  %t224 = load { i64, [4 x i64] }, ptr %t217
  %t226 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t224, ptr %t226
  %t228 = insertvalue { i32, ptr } zeroinitializer, ptr %t226, 1
  store { i32, ptr } %t228, ptr %rv
  br label %ret
bb51:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t233 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v0, ptr %t229, { i64, ptr } %t230)
  %t234 = extractvalue { i32, ptr } %t233, 1
  %t235 = extractvalue { i32, ptr } %t233, 0
  store i32 %t235, ptr %l101
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb53, label %ok.237
ok.237:
  store ptr %t234, ptr %l100
  br label %bb52
bb52:
  %t238 = load ptr, ptr %l100, !tbaa !29
  store ptr %t238, ptr %l97, !tbaa !29
  br label %bb54
bb53:
  %t239 = load i32, ptr %l101, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 %t247, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb54:
  %t250 = load ptr, ptr %l97, !tbaa !29
  store ptr %t250, ptr %l9, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t251, i32 0, i32 12
  %t254 = load i1, ptr %t253, !tbaa !21
  br i1 %t254, label %bb55, label %bb56
bb55:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t259 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t256, i32 8)
  store i1 %t259, ptr %l108
  br label %bb57
bb56:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb66
bb57:
  %t260 = load i1, ptr %l108, !tbaa !21
  br i1 %t260, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb61
bb59:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t264 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t261, i32 95)
  store i1 %t264, ptr %l112
  br label %bb60
bb60:
  %t265 = load i1, ptr %l112, !tbaa !21
  store i1 %t265, ptr %l109, !tbaa !21
  br label %bb61
bb61:
  %t266 = load i1, ptr %l109, !tbaa !21
  br i1 %t266, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb65
bb63:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t270 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t267, i32 0)
  store i1 %t270, ptr %l116
  br label %bb64
bb64:
  %t271 = load i1, ptr %l116, !tbaa !21
  store i1 %t271, ptr %l113, !tbaa !21
  br label %bb65
bb65:
  %t272 = load i1, ptr %l113, !tbaa !21
  store i1 %t272, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t273 = load i1, ptr %l105, !tbaa !21
  br i1 %t273, label %bb67, label %bb68
bb67:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l1, !tbaa !23
  %t278 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t274, i32 %t275)
  store %"compiler/source:Span" %t278, ptr %l119
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t279 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t279, ptr %l10
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l121
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb71, label %ok.284
ok.284:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t285 = load i32, ptr %l121, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  %t295 = insertvalue { i32, ptr } zeroinitializer, i32 %t293, 0
  store { i32, ptr } %t295, ptr %rv
  br label %ret
bb72:
  %t296 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t296, ptr %l123
  %t297 = load ptr, ptr %l9, !tbaa !29
  %t299 = getelementptr %"compiler/parse:NameList", ptr %t297, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l125, !tbaa !27
  %t301 = load ptr, ptr %l9, !tbaa !29
  %t303 = getelementptr %"compiler/parse:NameList", ptr %t301, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  store { i64, ptr } %t304, ptr %l127, !tbaa !27
  %t305 = icmp sge i64 0, 0
  br i1 %t305, label %bb73, label %bb74
bb73:
  %t307 = icmp sle i64 0, 1152921504606846975
  br i1 %t307, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb75:
  %t309 = mul i64 0, 8
  %t310 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 0, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t313 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t316 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t313, { i64, ptr } %t314, ptr null, { i64, ptr } %t312, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t316, ptr %l131
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb77:
  %t317 = load %"compiler/ast:VarDecl", ptr %l131
  %t318 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t317, ptr %t318
  store { i64, [4 x i64] } zeroinitializer, ptr %t319
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 0
  store i64 1, ptr %t320
  %t321 = load %"compiler/source:Span", ptr %l123
  %t322 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t321, 0
  %t324 = insertvalue { %"compiler/source:Span", ptr } %t322, ptr %t318, 1
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t324, ptr %t325
  %t326 = load { i64, [4 x i64] }, ptr %t319
  %t328 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t326, ptr %t328
  %t330 = insertvalue { i32, ptr } zeroinitializer, ptr %t328, 1
  store { i32, ptr } %t330, ptr %rv
  br label %ret
bb78:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l1, !tbaa !23
  %t333 = load ptr, ptr %l9, !tbaa !29
  %t337 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v0, ptr %t331, i32 %t332, ptr %t333)
  %t338 = extractvalue { i32, ptr } %t337, 1
  %t339 = extractvalue { i32, ptr } %t337, 0
  store i32 %t339, ptr %l140
  %t340 = icmp ne i32 %t339, 0
  br i1 %t340, label %bb80, label %ok.341
ok.341:
  store ptr %t338, ptr %l139
  br label %bb79
bb79:
  %t342 = load ptr, ptr %l139, !tbaa !29
  store ptr %t342, ptr %l135, !tbaa !29
  br label %bb81
bb80:
  %t343 = load i32, ptr %l140, !tbaa !23
  %t344 = lshr i32 %t343, 16
  %t345 = and i32 %t343, 65535
  %t346 = icmp eq i32 %t344, 1
  %t347 = select i1 %t346, i32 1, i32 0
  %t348 = icmp eq i32 %t343, 0
  %t349 = shl i32 %t347, 16
  %t350 = or i32 %t349, %t345
  %t351 = select i1 %t348, i32 0, i32 %t350
  %t353 = insertvalue { i32, ptr } zeroinitializer, i32 %t351, 0
  store { i32, ptr } %t353, ptr %rv
  br label %ret
bb81:
  %t354 = load ptr, ptr %l135, !tbaa !29
  %t355 = insertvalue { i32, ptr } zeroinitializer, ptr %t354, 1
  store { i32, ptr } %t355, ptr %rv
  br label %ret
bb82:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t356)
  store i32 %t358, ptr %l143
  br label %bb83
bb83:
  %t359 = load i32, ptr %l143
  store i32 %t359, ptr %l11
  %t360 = load i32, ptr %l11
  %t362 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t360)
  store i1 %t362, ptr %l145
  br label %bb84
bb84:
  %t363 = load i1, ptr %l145, !tbaa !21
  br i1 %t363, label %bb85, label %bb86
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t364)
  store i32 %t366, ptr %l147
  br label %bb87
bb86:
  br label %bb95
bb87:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t367)
  %t370 = extractvalue { i32, ptr } %t369, 1
  %t371 = extractvalue { i32, ptr } %t369, 0
  store i32 %t371, ptr %l151
  %t372 = icmp ne i32 %t371, 0
  br i1 %t372, label %bb89, label %ok.373
ok.373:
  store ptr %t370, ptr %l150
  br label %bb88
bb88:
  %t374 = load ptr, ptr %l150, !tbaa !29
  store ptr %t374, ptr %l148, !tbaa !29
  br label %bb90
bb89:
  %t375 = load i32, ptr %l151, !tbaa !23
  %t376 = lshr i32 %t375, 16
  %t377 = and i32 %t375, 65535
  %t378 = icmp eq i32 %t376, 1
  %t379 = select i1 %t378, i32 1, i32 0
  %t380 = icmp eq i32 %t375, 0
  %t381 = shl i32 %t379, 16
  %t382 = or i32 %t381, %t377
  %t383 = select i1 %t380, i32 0, i32 %t382
  %t385 = insertvalue { i32, ptr } zeroinitializer, i32 %t383, 0
  store { i32, ptr } %t385, ptr %rv
  br label %ret
bb90:
  %t386 = load ptr, ptr %l148, !tbaa !29
  store ptr %t386, ptr %l12, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l1, !tbaa !23
  %t391 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t387, i32 %t388)
  store %"compiler/source:Span" %t391, ptr %l155
  br label %bb91
bb91:
  %t392 = load %"compiler/source:Span", ptr %l155
  store %"compiler/source:Span" %t392, ptr %l13
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t393)
  store i32 %t395, ptr %l157
  %t396 = icmp ne i32 %t395, 0
  br i1 %t396, label %bb93, label %ok.397
ok.397:
  br label %bb92
bb92:
  br label %bb94
bb93:
  %t398 = load i32, ptr %l157, !tbaa !23
  %t399 = lshr i32 %t398, 16
  %t400 = and i32 %t398, 65535
  %t401 = icmp eq i32 %t399, 1
  %t402 = select i1 %t401, i32 1, i32 0
  %t403 = icmp eq i32 %t398, 0
  %t404 = shl i32 %t402, 16
  %t405 = or i32 %t404, %t400
  %t406 = select i1 %t403, i32 0, i32 %t405
  %t408 = insertvalue { i32, ptr } zeroinitializer, i32 %t406, 0
  store { i32, ptr } %t408, ptr %rv
  br label %ret
bb94:
  %t409 = load %"compiler/source:Span", ptr %l13
  %t410 = load i32, ptr %l11
  %t411 = load ptr, ptr %l2, !tbaa !29
  %t412 = load ptr, ptr %l12, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t413
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t413, i32 0, i32 0
  store i64 3, ptr %t414
  %t416 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t409, 0
  %t418 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t416, i32 %t410, 1
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t418, ptr %t411, 2
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t420, ptr %t412, 3
  %t423 = getelementptr { i64, [4 x i64] }, ptr %t413, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t422, ptr %t423
  %t424 = load { i64, [4 x i64] }, ptr %t413
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t424, ptr %t426
  %t428 = insertvalue { i32, ptr } zeroinitializer, ptr %t426, 1
  store { i32, ptr } %t428, ptr %rv
  br label %ret
bb95:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l1, !tbaa !23
  %t433 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t429, i32 %t430)
  store %"compiler/source:Span" %t433, ptr %l167
  br label %bb96
bb96:
  %t434 = load %"compiler/source:Span", ptr %l167
  store %"compiler/source:Span" %t434, ptr %l14
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t435)
  store i32 %t437, ptr %l169
  %t438 = icmp ne i32 %t437, 0
  br i1 %t438, label %bb98, label %ok.439
ok.439:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t440 = load i32, ptr %l169, !tbaa !23
  %t441 = lshr i32 %t440, 16
  %t442 = and i32 %t440, 65535
  %t443 = icmp eq i32 %t441, 1
  %t444 = select i1 %t443, i32 1, i32 0
  %t445 = icmp eq i32 %t440, 0
  %t446 = shl i32 %t444, 16
  %t447 = or i32 %t446, %t442
  %t448 = select i1 %t445, i32 0, i32 %t447
  %t450 = insertvalue { i32, ptr } zeroinitializer, i32 %t448, 0
  store { i32, ptr } %t450, ptr %rv
  br label %ret
bb99:
  %t451 = load %"compiler/source:Span", ptr %l14
  %t452 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t453
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t453, i32 0, i32 0
  store i64 0, ptr %t454
  %t456 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t451, 0
  %t458 = insertvalue { %"compiler/source:Span", ptr } %t456, ptr %t452, 1
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t453, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t458, ptr %t459
  %t460 = load { i64, [4 x i64] }, ptr %t453
  %t462 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t460, ptr %t462
  %t464 = insertvalue { i32, ptr } zeroinitializer, ptr %t462, 1
  store { i32, ptr } %t464, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l52 = alloca %"compiler/ast:TypeDecl"
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i32
  %l77 = alloca i32
  %l81 = alloca { i64, ptr }
  %l84 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t119 = alloca { i64, [6 x i64] }, align 8
  %t130 = alloca { i64, [6 x i64] }, align 8
  %t172 = alloca { i64, [6 x i64] }, align 8
  %t229 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 94)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 37
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t27)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t29, i32 95)
  store i1 %t32, ptr %l19
  br label %bb7
bb7:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  br label %bb50
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t38, i32 0)
  store i1 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 95)
  store { i64, ptr } %t45, ptr %l27
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t55 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } %t52)
  store i32 %t55, ptr %l29
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb16, label %ok.57
ok.57:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t58 = load i32, ptr %l29, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s2)
  %t68 = insertvalue { i32, ptr } zeroinitializer, i32 %t66, 0
  store { i32, ptr } %t68, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t69)
  store i32 %t71, ptr %l32
  br label %bb19
bb19:
  %t72 = load i32, ptr %l32, !tbaa !23
  store i32 %t72, ptr %l4, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t73, i32 34)
  store i1 %t76, ptr %l35
  br label %bb20
bb20:
  %t77 = load i1, ptr %l35, !tbaa !21
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t78)
  %t81 = extractvalue { i32, i32 } %t80, 1
  %t82 = extractvalue { i32, i32 } %t80, 0
  store i32 %t82, ptr %l39
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb24, label %ok.84
ok.84:
  store i32 %t81, ptr %l38
  br label %bb23
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 38)
  store i1 %t88, ptr %l58
  br label %bb33
bb23:
  %t89 = load i32, ptr %l38, !tbaa !23
  store i32 %t89, ptr %l36, !tbaa !23
  br label %bb25
bb24:
  %t90 = load i32, ptr %l39, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  %t100 = insertvalue { i32, ptr } zeroinitializer, i32 %t98, 0
  store { i32, ptr } %t100, ptr %rv
  br label %ret
bb25:
  %t101 = load i32, ptr %l36, !tbaa !23
  store i32 %t101, ptr %l5, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/parse:Parser", ptr %t102, i32 0, i32 37
  store ptr %t104, ptr %l42, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l4, !tbaa !23
  %t109 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t105, i32 %t106)
  store %"compiler/source:Span" %t109, ptr %l45
  br label %bb26
bb26:
  %t110 = load i32, ptr %l5, !tbaa !23
  store i32 %t110, ptr %l46, !tbaa !23
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t113 = icmp sle i64 0, 1152921504606846975
  br i1 %t113, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb29:
  %t115 = mul i64 0, 8
  %t116 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 0, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [6 x i64] }, ptr %t119, i32 0, i32 0
  store i64 4, ptr %t120
  %t121 = load { i64, [6 x i64] }, ptr %t119
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t121, ptr %t123
  %t124 = load i32, ptr %l46, !tbaa !23
  %t127 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t124, { i64, ptr } %t118, i1 false, ptr %t123)
  store %"compiler/ast:TypeDecl" %t127, ptr %l52
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb31:
  %t128 = load %"compiler/ast:TypeDecl", ptr %l52
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:TypeDecl" %t128, ptr %t129
  store { i64, [6 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [6 x i64] }, ptr %t130, i32 0, i32 0
  store i64 2, ptr %t131
  %t132 = load %"compiler/source:Span", ptr %l45
  %t133 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t132, 0
  %t135 = insertvalue { %"compiler/source:Span", ptr } %t133, ptr %t129, 1
  %t136 = getelementptr { i64, [6 x i64] }, ptr %t130, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t135, ptr %t136
  %t137 = load { i64, [6 x i64] }, ptr %t130
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t137, ptr %t139
  %t140 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb32
bb32:
  br label %bb44
bb33:
  %t142 = load i1, ptr %l58, !tbaa !21
  br i1 %t142, label %bb34, label %bb35
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 37
  store ptr %t145, ptr %l60, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t150 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %t146, i32 %t147)
  %t151 = extractvalue { i32, ptr } %t150, 1
  %t152 = extractvalue { i32, ptr } %t150, 0
  store i32 %t152, ptr %l65
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb37, label %ok.154
ok.154:
  store ptr %t151, ptr %l64
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s6, ptr %t155, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t157, ptr %l70
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb41, label %ok.159
ok.159:
  br label %bb40
bb36:
  %t160 = load ptr, ptr %l64, !tbaa !29
  store ptr %t160, ptr %l61, !tbaa !29
  br label %bb38
bb37:
  %t161 = load i32, ptr %l65, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 1, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  %t171 = insertvalue { i32, ptr } zeroinitializer, i32 %t169, 0
  store { i32, ptr } %t171, ptr %rv
  br label %ret
bb38:
  store { i64, [6 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [6 x i64] }, ptr %t172, i32 0, i32 0
  store i64 1, ptr %t173
  %t174 = load ptr, ptr %l61, !tbaa !29
  %t175 = insertvalue { ptr } undef, ptr %t174, 0
  %t176 = getelementptr { i64, [6 x i64] }, ptr %t172, i32 0, i32 1
  store { ptr } %t175, ptr %t176
  %t177 = load { i64, [6 x i64] }, ptr %t172
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t177, ptr %t179
  %t180 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t180, ptr %t179)
  br label %bb39
bb39:
  br label %bb43
bb40:
  br label %bb42
bb41:
  %t182 = load i32, ptr %l70, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  call void @__olang_scope_close(ptr %s6)
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t193)
  store i32 %t195, ptr %l73
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb46, label %ok.197
ok.197:
  br label %bb45
bb45:
  br label %bb47
bb46:
  %t198 = load i32, ptr %l73, !tbaa !23
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 1, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  %t208 = insertvalue { i32, ptr } zeroinitializer, i32 %t206, 0
  store { i32, ptr } %t208, ptr %rv
  br label %ret
bb47:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t209)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb6
bb50:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t211)
  store i32 %t213, ptr %l77
  br label %bb51
bb51:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/parse:Parser", ptr %t214, i32 0, i32 37
  %t217 = load i64, ptr %l3, !tbaa !24
  %t220 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t216, i64 %t217)
  store { i64, ptr } %t220, ptr %l81
  br label %bb52
bb52:
  %t221 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t221, ptr %l6, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t226 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t222, i32 %a1)
  store %"compiler/source:Span" %t226, ptr %l84
  br label %bb53
bb53:
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [6 x i64] }, ptr %t229, i32 0, i32 0
  store i64 8, ptr %t230
  %t231 = load %"compiler/source:Span", ptr %l84
  %t232 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t231, 0
  %t234 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t232, %"compiler/source:Span" %a2, 1
  %t236 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t234, { i64, ptr } %t228, 2
  %t237 = getelementptr { i64, [6 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t236, ptr %t237
  %t238 = load { i64, [6 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t238, ptr %t240
  %t242 = insertvalue { i32, ptr } zeroinitializer, ptr %t240, 1
  store { i32, ptr } %t242, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca %"compiler/token:Token"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca ptr
  %lp21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca i1
  %l50 = alloca i32
  %l57 = alloca i1
  %l59 = alloca i32
  %l62 = alloca i1
  %l65 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l72 = alloca i1
  %l74 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i32
  %l79 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i32
  %l87 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i32
  %l95 = alloca i64
  %l98 = alloca i1
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i32
  %l124 = alloca %"compiler/source:Span"
  %l127 = alloca i1
  %l129 = alloca i32
  %l130 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/ast:ForIn"
  %l143 = alloca i1
  %l146 = alloca i1
  %l150 = alloca i32
  %l152 = alloca %"compiler/token:Token"
  %l153 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca i32
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca ptr
  %l166 = alloca i1
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i32
  %l177 = alloca { i64, ptr }
  %l178 = alloca %"compiler/ast:VarDecl"
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i32
  %l185 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i32
  %l191 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca i32
  %l203 = alloca { i64, ptr }
  %l204 = alloca %"compiler/ast:VarDecl"
  %l208 = alloca %"compiler/source:Span"
  %l213 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i32
  %l219 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i32
  %l224 = alloca i32
  %l227 = alloca i32
  %l228 = alloca i32
  %l230 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca i32
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l242 = alloca %"compiler/source:Span"
  %l245 = alloca i1
  %l247 = alloca i32
  %l248 = alloca %"compiler/source:Span"
  %l254 = alloca %"compiler/ast:For3"
  %l258 = alloca ptr
  %l260 = alloca ptr
  %l261 = alloca i32
  %l263 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l266 = alloca i32
  %l270 = alloca %"compiler/source:Span"
  %l273 = alloca i1
  %l275 = alloca i32
  %s10 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t63 = alloca { i64, [4 x i64] }, align 8
  %t289 = alloca { i64, [4 x i64] }, align 8
  %t506 = alloca { i64, [4 x i64] }, align 8
  %t644 = alloca { i64, [4 x i64] }, align 8
  %t713 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 25)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l33
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l32
  br label %bb1
bb1:
  %t9 = load i32, ptr %l32, !tbaa !23
  store i32 %t9, ptr %l29, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l33, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l29, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 94)
  store i1 %t25, ptr %l37
  br label %bb4
bb4:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l41
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l40
  br label %bb7
bb6:
  br label %bb16
bb7:
  %t34 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t34, ptr %l38, !tbaa !27
  br label %bb9
bb8:
  %t35 = load i32, ptr %l41, !tbaa !23
  %t36 = lshr i32 %t35, 16
  %t37 = and i32 %t35, 65535
  %t38 = icmp eq i32 %t36, 1
  %t39 = select i1 %t38, i32 1, i32 0
  %t40 = icmp eq i32 %t35, 0
  %t41 = shl i32 %t39, 16
  %t42 = or i32 %t41, %t37
  %t43 = select i1 %t40, i32 0, i32 %t42
  %t45 = insertvalue { i32, ptr } zeroinitializer, i32 %t43, 0
  store { i32, ptr } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t47, i32 %t48)
  store %"compiler/source:Span" %t51, ptr %l45
  br label %bb10
bb10:
  %t52 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t52, ptr %l3
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t53, i32 8)
  store i1 %t56, ptr %l48
  br label %bb11
bb11:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l50
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t61 = load %"compiler/source:Span", ptr %l3
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 0
  store i64 6, ptr %t64
  %t66 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t61, 0
  %t68 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t66, { i64, ptr } %t62, 1
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t68, ptr %t69
  %t70 = load { i64, [4 x i64] }, ptr %t63
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t70, ptr %t72
  %t74 = insertvalue { i32, ptr } zeroinitializer, ptr %t72, 1
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t78 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t75, i32 1)
  store i1 %t78, ptr %l57
  br label %bb17
bb17:
  %t79 = load i1, ptr %l57, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t80, i64 1)
  store i32 %t82, ptr %l59
  br label %bb20
bb19:
  br label %bb133
bb20:
  %t83 = load i32, ptr %l59
  store i32 %t83, ptr %l4
  %t84 = load i32, ptr %l4
  %t86 = trunc i64 27 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb23
bb22:
  %t89 = load i32, ptr %l4
  %t91 = trunc i64 57 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l62, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l62, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i32 0, ptr %l5, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i32 } %t97, 1
  %t99 = extractvalue { i32, i32 } %t97, 0
  store i32 %t99, ptr %l68
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb27, label %ok.101
ok.101:
  store i32 %t98, ptr %l67
  br label %bb26
bb25:
  br label %bb72
bb26:
  %t102 = load i32, ptr %l67, !tbaa !23
  store i32 %t102, ptr %l65, !tbaa !23
  br label %bb28
bb27:
  %t103 = load i32, ptr %l68, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  %t113 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t113, ptr %rv
  br label %ret
bb28:
  %t114 = load i32, ptr %l65, !tbaa !23
  store i32 %t114, ptr %l6, !tbaa !23
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t115, i32 57)
  store i1 %t118, ptr %l72
  br label %bb29
bb29:
  %t119 = load i1, ptr %l72, !tbaa !21
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t120 = load i32, ptr %l6, !tbaa !23
  store i32 %t120, ptr %l5, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t122)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l77
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb33, label %ok.128
ok.128:
  store i32 %t125, ptr %l76
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t129 = load i32, ptr %l76, !tbaa !23
  store i32 %t129, ptr %l74, !tbaa !23
  br label %bb34
bb33:
  %t130 = load i32, ptr %l77, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  %t140 = insertvalue { i32, ptr } zeroinitializer, i32 %t138, 0
  store { i32, ptr } %t140, ptr %rv
  br label %ret
bb34:
  %t141 = load i32, ptr %l74, !tbaa !23
  store i32 %t141, ptr %l6, !tbaa !23
  br label %bb35
bb35:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t142, i32 27)
  %t146 = extractvalue { i32, i32 } %t145, 1
  %t147 = extractvalue { i32, i32 } %t145, 0
  store i32 %t147, ptr %l83
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb37, label %ok.149
ok.149:
  store i32 %t146, ptr %l82
  br label %bb36
bb36:
  %t150 = load i32, ptr %l82, !tbaa !23
  store i32 %t150, ptr %l79, !tbaa !23
  br label %bb38
bb37:
  %t151 = load i32, ptr %l83, !tbaa !23
  %t152 = lshr i32 %t151, 16
  %t153 = and i32 %t151, 65535
  %t154 = icmp eq i32 %t152, 1
  %t155 = select i1 %t154, i32 1, i32 0
  %t156 = icmp eq i32 %t151, 0
  %t157 = shl i32 %t155, 16
  %t158 = or i32 %t157, %t153
  %t159 = select i1 %t156, i32 0, i32 %t158
  %t161 = insertvalue { i32, ptr } zeroinitializer, i32 %t159, 0
  store { i32, ptr } %t161, ptr %rv
  br label %ret
bb38:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t165 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t162, i32 11)
  store i1 %t165, ptr %l87
  br label %bb39
bb39:
  %t166 = load i1, ptr %l87, !tbaa !21
  store i1 %t166, ptr %l7, !tbaa !21
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %t167)
  %t170 = extractvalue { i32, ptr } %t169, 1
  %t171 = extractvalue { i32, ptr } %t169, 0
  store i32 %t171, ptr %l91
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb41, label %ok.173
ok.173:
  store ptr %t170, ptr %l90
  br label %bb40
bb40:
  %t174 = load ptr, ptr %l90, !tbaa !29
  store ptr %t174, ptr %l88, !tbaa !29
  br label %bb42
bb41:
  %t175 = load i32, ptr %l91, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  %t185 = insertvalue { i32, ptr } zeroinitializer, i32 %t183, 0
  store { i32, ptr } %t185, ptr %rv
  br label %ret
bb42:
  %t186 = load ptr, ptr %l88, !tbaa !29
  store ptr %t186, ptr %l8, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 29
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l95
  br label %bb43
bb43:
  %t192 = load i64, ptr %l95, !tbaa !24
  store i64 %t192, ptr %l9, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t197 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v0, ptr %t193, ptr %t194)
  store i1 %t197, ptr %l98
  br label %bb44
bb44:
  %t198 = load i1, ptr %l98, !tbaa !21
  br i1 %t198, label %bb45, label %bb46
bb45:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/parse:Parser", ptr %t199, i32 0, i32 29
  %t202 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t201, i32 %t202)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t205)
  %t208 = extractvalue { i32, { i64, ptr } } %t207, 1
  %t209 = extractvalue { i32, { i64, ptr } } %t207, 0
  store i32 %t209, ptr %l105
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb50, label %ok.211
ok.211:
  store { i64, ptr } %t208, ptr %l104
  br label %bb49
bb49:
  %t212 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t212, ptr %l102, !tbaa !27
  br label %bb53
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 29
  %t216 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t215, i64 %t216)
  br label %bb52
bb52:
  %t220 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t220, ptr %rv
  br label %ret
bb53:
  %t221 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t221, ptr %l10, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/parse:Parser", ptr %t222, i32 0, i32 29
  %t225 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t224, i64 %t225)
  br label %bb54
bb54:
  %t228 = icmp sge i64 0, 0
  br i1 %t228, label %bb55, label %bb56
bb55:
  %t230 = icmp sle i64 0, 1152921504606846975
  br i1 %t230, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb57:
  %t232 = mul i64 0, 8
  %t233 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 0, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l11, !tbaa !27
  %t237 = load i1, ptr %l7, !tbaa !21
  br i1 %t237, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb59:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t239, i1 false)
  %t242 = extractvalue { i32, { i64, ptr } } %t241, 1
  %t243 = extractvalue { i32, { i64, ptr } } %t241, 0
  store i32 %t243, ptr %l120
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb62, label %ok.245
ok.245:
  store { i64, ptr } %t242, ptr %l119
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t246 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t246, ptr %l117, !tbaa !27
  br label %bb63
bb62:
  %t247 = load i32, ptr %l120, !tbaa !23
  %t248 = lshr i32 %t247, 16
  %t249 = and i32 %t247, 65535
  %t250 = icmp eq i32 %t248, 1
  %t251 = select i1 %t250, i32 1, i32 0
  %t252 = icmp eq i32 %t247, 0
  %t253 = shl i32 %t251, 16
  %t254 = or i32 %t253, %t249
  %t255 = select i1 %t252, i32 0, i32 %t254
  %t257 = insertvalue { i32, ptr } zeroinitializer, i32 %t255, 0
  store { i32, ptr } %t257, ptr %rv
  br label %ret
bb63:
  %t258 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t258, ptr %l11, !tbaa !27
  br label %bb64
bb64:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l1, !tbaa !23
  %t263 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t259, i32 %t260)
  store %"compiler/source:Span" %t263, ptr %l124
  br label %bb65
bb65:
  %t264 = load %"compiler/source:Span", ptr %l124
  store %"compiler/source:Span" %t264, ptr %l12
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t268 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t265, i32 8)
  store i1 %t268, ptr %l127
  br label %bb66
bb66:
  %t269 = load i1, ptr %l127, !tbaa !21
  br i1 %t269, label %bb67, label %bb68
bb67:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l129
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t273 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t273, ptr %l130
  %t274 = load i32, ptr %l5, !tbaa !23
  %t275 = load i32, ptr %l6, !tbaa !23
  %t276 = load ptr, ptr %l8, !tbaa !29
  %t277 = load i1, ptr %l7, !tbaa !21
  %t278 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t286 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t274, i32 %t275, ptr %t276, i1 %t277, { i64, ptr } %t278, { i64, ptr } %t279)
  store %"compiler/ast:ForIn" %t286, ptr %l137
  br label %bb71
bb71:
  %t287 = load %"compiler/ast:ForIn", ptr %l137
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/ast:ForIn" %t287, ptr %t288
  store { i64, [4 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 0
  store i64 9, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l130
  %t292 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t291, 0
  %t294 = insertvalue { %"compiler/source:Span", ptr } %t292, ptr %t288, 1
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t289
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t296, ptr %t298
  %t300 = insertvalue { i32, ptr } zeroinitializer, ptr %t298, 1
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb72:
  %t301 = load i32, ptr %l4
  %t303 = trunc i64 62 to i32
  %t304 = icmp eq i32 %t301, %t303
  br i1 %t304, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb75
bb74:
  %t306 = load i32, ptr %l4
  %t308 = trunc i64 1 to i32
  %t309 = icmp eq i32 %t306, %t308
  store i1 %t309, ptr %l143, !tbaa !21
  br label %bb75
bb75:
  %t311 = load i1, ptr %l143, !tbaa !21
  br i1 %t311, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb78
bb77:
  %t312 = load i32, ptr %l4
  %t314 = trunc i64 40 to i32
  %t315 = icmp eq i32 %t312, %t314
  store i1 %t315, ptr %l146, !tbaa !21
  br label %bb78
bb78:
  %t317 = load i1, ptr %l146, !tbaa !21
  br i1 %t317, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s10
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t318)
  store i32 %t320, ptr %l150
  br label %bb81
bb80:
  br label %bb132
bb81:
  %t321 = load i32, ptr %l150, !tbaa !23
  store i32 %t321, ptr %l13, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t322)
  store %"compiler/token:Token" %t324, ptr %l152
  br label %bb82
bb82:
  %t325 = load %"compiler/token:Token", ptr %l152
  store %"compiler/token:Token" %t325, ptr %l14
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t326)
  %t329 = extractvalue { i32, i32 } %t328, 1
  %t330 = extractvalue { i32, i32 } %t328, 0
  store i32 %t330, ptr %l156
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb84, label %ok.332
ok.332:
  store i32 %t329, ptr %l155
  br label %bb83
bb83:
  %t333 = load i32, ptr %l155, !tbaa !23
  store i32 %t333, ptr %l153, !tbaa !23
  br label %bb85
bb84:
  %t334 = load i32, ptr %l156, !tbaa !23
  %t335 = lshr i32 %t334, 16
  %t336 = and i32 %t334, 65535
  %t337 = icmp eq i32 %t335, 1
  %t338 = select i1 %t337, i32 1, i32 0
  %t339 = icmp eq i32 %t334, 0
  %t340 = shl i32 %t338, 16
  %t341 = or i32 %t340, %t336
  %t342 = select i1 %t339, i32 0, i32 %t341
  call void @__olang_scope_close(ptr %s10)
  %t344 = insertvalue { i32, ptr } zeroinitializer, i32 %t342, 0
  store { i32, ptr } %t344, ptr %rv
  br label %ret
bb85:
  %t345 = load i32, ptr %l153, !tbaa !23
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l158, !tbaa !29
  store i32 %t345, ptr %l159, !tbaa !23
  %t348 = getelementptr %"compiler/token:Token", ptr %l14, i32 0, i32 2
  %t349 = load i32, ptr %t348, !tbaa !23
  %t350 = getelementptr %"compiler/token:Token", ptr %l14, i32 0, i32 3
  %t351 = load i32, ptr %t350, !tbaa !23
  %t354 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 %t349, i32 %t351)
  store %"compiler/source:Span" %t354, ptr %l162
  br label %bb86
bb86:
  %t355 = load ptr, ptr %l158, !tbaa !29
  %t356 = load i32, ptr %l159, !tbaa !23
  %t357 = load %"compiler/source:Span", ptr %l162
  %t358 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %t355, i32 %t356, %"compiler/source:Span" %t357)
  store ptr %t358, ptr %l163
  br label %bb87
bb87:
  %t359 = load ptr, ptr %l163, !tbaa !29
  store ptr %t359, ptr %l16, !tbaa !29
  store ptr null, ptr %l17, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t360, i32 62)
  store i1 %t363, ptr %l166
  br label %bb88
bb88:
  %t364 = load i1, ptr %l166, !tbaa !21
  br i1 %t364, label %bb89, label %bb90
bb89:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t365)
  %t368 = extractvalue { i32, ptr } %t367, 1
  %t369 = extractvalue { i32, ptr } %t367, 0
  store i32 %t369, ptr %l170
  %t370 = icmp ne i32 %t369, 0
  br i1 %t370, label %bb92, label %ok.371
ok.371:
  store ptr %t368, ptr %l169
  br label %bb91
bb90:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t372)
  %t375 = extractvalue { i32, ptr } %t374, 1
  %t376 = extractvalue { i32, ptr } %t374, 0
  store i32 %t376, ptr %l183
  %t377 = icmp ne i32 %t376, 0
  br i1 %t377, label %bb96, label %ok.378
ok.378:
  store ptr %t375, ptr %l182
  br label %bb95
bb91:
  %t379 = load ptr, ptr %l169, !tbaa !29
  store ptr %t379, ptr %l167, !tbaa !29
  br label %bb93
bb92:
  %t380 = load i32, ptr %l170, !tbaa !23
  %t381 = lshr i32 %t380, 16
  %t382 = and i32 %t380, 65535
  %t383 = icmp eq i32 %t381, 1
  %t384 = select i1 %t383, i32 1, i32 0
  %t385 = icmp eq i32 %t380, 0
  %t386 = shl i32 %t384, 16
  %t387 = or i32 %t386, %t382
  %t388 = select i1 %t385, i32 0, i32 %t387
  call void @__olang_scope_close(ptr %s10)
  %t390 = insertvalue { i32, ptr } zeroinitializer, i32 %t388, 0
  store { i32, ptr } %t390, ptr %rv
  br label %ret
bb93:
  %t391 = load ptr, ptr %l167, !tbaa !29
  %t392 = load ptr, ptr %l16, !tbaa !29
  %t394 = getelementptr %"compiler/parse:NameList", ptr %t392, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  %t396 = load ptr, ptr %l16, !tbaa !29
  %t398 = getelementptr %"compiler/parse:NameList", ptr %t396, i32 0, i32 1
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  %t401 = mul i64 1, 8
  %t402 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t401)
  %t403 = insertvalue { i64, ptr } undef, i64 1, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  store { i64, ptr } %t404, ptr %l177, !tbaa !27
  %t406 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 0
  store ptr %t391, ptr %t408, !tbaa !39
  %t411 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t412 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t395, { i64, ptr } %t399, ptr null, { i64, ptr } %t411, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t412, ptr %l178
  br label %bb94
bb94:
  %t413 = load %"compiler/ast:VarDecl", ptr %l178
  %t414 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t413, ptr %t414
  store ptr %t414, ptr %l17, !tbaa !29
  br label %bb105
bb95:
  %t416 = load ptr, ptr %l182, !tbaa !29
  store ptr %t416, ptr %l180, !tbaa !29
  br label %bb97
bb96:
  %t417 = load i32, ptr %l183, !tbaa !23
  %t418 = lshr i32 %t417, 16
  %t419 = and i32 %t417, 65535
  %t420 = icmp eq i32 %t418, 1
  %t421 = select i1 %t420, i32 1, i32 0
  %t422 = icmp eq i32 %t417, 0
  %t423 = shl i32 %t421, 16
  %t424 = or i32 %t423, %t419
  %t425 = select i1 %t422, i32 0, i32 %t424
  call void @__olang_scope_close(ptr %s10)
  %t427 = insertvalue { i32, ptr } zeroinitializer, i32 %t425, 0
  store { i32, ptr } %t427, ptr %rv
  br label %ret
bb97:
  %t428 = load ptr, ptr %l180, !tbaa !29
  store ptr %t428, ptr %l19, !tbaa !29
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t432 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t429, i32 60)
  %t433 = extractvalue { i32, i32 } %t432, 1
  %t434 = extractvalue { i32, i32 } %t432, 0
  store i32 %t434, ptr %l189
  %t435 = icmp ne i32 %t434, 0
  br i1 %t435, label %bb99, label %ok.436
ok.436:
  store i32 %t433, ptr %l188
  br label %bb98
bb98:
  %t437 = load i32, ptr %l188, !tbaa !23
  store i32 %t437, ptr %l185, !tbaa !23
  br label %bb100
bb99:
  %t438 = load i32, ptr %l189, !tbaa !23
  %t439 = lshr i32 %t438, 16
  %t440 = and i32 %t438, 65535
  %t441 = icmp eq i32 %t439, 1
  %t442 = select i1 %t441, i32 1, i32 0
  %t443 = icmp eq i32 %t438, 0
  %t444 = shl i32 %t442, 16
  %t445 = or i32 %t444, %t440
  %t446 = select i1 %t443, i32 0, i32 %t445
  call void @__olang_scope_close(ptr %s10)
  %t448 = insertvalue { i32, ptr } zeroinitializer, i32 %t446, 0
  store { i32, ptr } %t448, ptr %rv
  br label %ret
bb100:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t449)
  %t452 = extractvalue { i32, ptr } %t451, 1
  %t453 = extractvalue { i32, ptr } %t451, 0
  store i32 %t453, ptr %l194
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb102, label %ok.455
ok.455:
  store ptr %t452, ptr %l193
  br label %bb101
bb101:
  %t456 = load ptr, ptr %l193, !tbaa !29
  store ptr %t456, ptr %l191, !tbaa !29
  br label %bb103
bb102:
  %t457 = load i32, ptr %l194, !tbaa !23
  %t458 = lshr i32 %t457, 16
  %t459 = and i32 %t457, 65535
  %t460 = icmp eq i32 %t458, 1
  %t461 = select i1 %t460, i32 1, i32 0
  %t462 = icmp eq i32 %t457, 0
  %t463 = shl i32 %t461, 16
  %t464 = or i32 %t463, %t459
  %t465 = select i1 %t462, i32 0, i32 %t464
  call void @__olang_scope_close(ptr %s10)
  %t467 = insertvalue { i32, ptr } zeroinitializer, i32 %t465, 0
  store { i32, ptr } %t467, ptr %rv
  br label %ret
bb103:
  %t468 = load ptr, ptr %l191, !tbaa !29
  %t469 = load ptr, ptr %l16, !tbaa !29
  %t471 = getelementptr %"compiler/parse:NameList", ptr %t469, i32 0, i32 0
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  %t473 = load ptr, ptr %l16, !tbaa !29
  %t475 = getelementptr %"compiler/parse:NameList", ptr %t473, i32 0, i32 1
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  %t477 = load ptr, ptr %l19, !tbaa !29
  %t480 = mul i64 1, 8
  %t481 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t480)
  %t482 = insertvalue { i64, ptr } undef, i64 1, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t481, 1
  store { i64, ptr } %t483, ptr %l203, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 0
  store ptr %t468, ptr %t487, !tbaa !39
  %t491 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t492 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t472, { i64, ptr } %t476, ptr %t477, { i64, ptr } %t491, i1 false, i1 false)
  store %"compiler/ast:VarDecl" %t492, ptr %l204
  br label %bb104
bb104:
  %t493 = load %"compiler/ast:VarDecl", ptr %l204
  %t494 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t493, ptr %t494
  store ptr %t494, ptr %l17, !tbaa !29
  br label %bb105
bb105:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr %l13, !tbaa !23
  %t500 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t496, i32 %t497)
  store %"compiler/source:Span" %t500, ptr %l208
  br label %bb106
bb106:
  %t501 = load ptr, ptr %l17, !tbaa !29
  %t503 = icmp eq ptr %t501, null
  br i1 %t503, label %bb107, label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2)
  unreachable
bb108:
  br label %bb109
bb109:
  %t505 = load ptr, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [4 x i64] }, ptr %t506, i32 0, i32 0
  store i64 1, ptr %t507
  %t508 = load %"compiler/source:Span", ptr %l208
  %t509 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t508, 0
  %t511 = insertvalue { %"compiler/source:Span", ptr } %t509, ptr %t505, 1
  %t512 = getelementptr { i64, [4 x i64] }, ptr %t506, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t511, ptr %t512
  %t513 = load { i64, [4 x i64] }, ptr %t506
  %t514 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t514, ptr %lp21
  %t516 = load ptr, ptr %lp21
  store { i64, [4 x i64] } %t513, ptr %t516
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t520 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t517, i32 57)
  %t521 = extractvalue { i32, i32 } %t520, 1
  %t522 = extractvalue { i32, i32 } %t520, 0
  store i32 %t522, ptr %l217
  %t523 = icmp ne i32 %t522, 0
  br i1 %t523, label %bb111, label %ok.524
ok.524:
  store i32 %t521, ptr %l216
  br label %bb110
bb110:
  %t525 = load i32, ptr %l216, !tbaa !23
  store i32 %t525, ptr %l213, !tbaa !23
  br label %bb112
bb111:
  %t526 = load i32, ptr %l217, !tbaa !23
  %t527 = lshr i32 %t526, 16
  %t528 = and i32 %t526, 65535
  %t529 = icmp eq i32 %t527, 1
  %t530 = select i1 %t529, i32 1, i32 0
  %t531 = icmp eq i32 %t526, 0
  %t532 = shl i32 %t530, 16
  %t533 = or i32 %t532, %t528
  %t534 = select i1 %t531, i32 0, i32 %t533
  call void @__olang_scope_close(ptr %s10)
  %t536 = insertvalue { i32, ptr } zeroinitializer, i32 %t534, 0
  store { i32, ptr } %t536, ptr %rv
  br label %ret
bb112:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t537)
  %t540 = extractvalue { i32, ptr } %t539, 1
  %t541 = extractvalue { i32, ptr } %t539, 0
  store i32 %t541, ptr %l222
  %t542 = icmp ne i32 %t541, 0
  br i1 %t542, label %bb114, label %ok.543
ok.543:
  store ptr %t540, ptr %l221
  br label %bb113
bb113:
  %t544 = load ptr, ptr %l221, !tbaa !29
  store ptr %t544, ptr %l219, !tbaa !29
  br label %bb115
bb114:
  %t545 = load i32, ptr %l222, !tbaa !23
  %t546 = lshr i32 %t545, 16
  %t547 = and i32 %t545, 65535
  %t548 = icmp eq i32 %t546, 1
  %t549 = select i1 %t548, i32 1, i32 0
  %t550 = icmp eq i32 %t545, 0
  %t551 = shl i32 %t549, 16
  %t552 = or i32 %t551, %t547
  %t553 = select i1 %t550, i32 0, i32 %t552
  call void @__olang_scope_close(ptr %s10)
  %t555 = insertvalue { i32, ptr } zeroinitializer, i32 %t553, 0
  store { i32, ptr } %t555, ptr %rv
  br label %ret
bb115:
  %t556 = load ptr, ptr %l219, !tbaa !29
  store ptr %t556, ptr %l22, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t560 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t557, i32 57)
  %t561 = extractvalue { i32, i32 } %t560, 1
  %t562 = extractvalue { i32, i32 } %t560, 0
  store i32 %t562, ptr %l228
  %t563 = icmp ne i32 %t562, 0
  br i1 %t563, label %bb117, label %ok.564
ok.564:
  store i32 %t561, ptr %l227
  br label %bb116
bb116:
  %t565 = load i32, ptr %l227, !tbaa !23
  store i32 %t565, ptr %l224, !tbaa !23
  br label %bb118
bb117:
  %t566 = load i32, ptr %l228, !tbaa !23
  %t567 = lshr i32 %t566, 16
  %t568 = and i32 %t566, 65535
  %t569 = icmp eq i32 %t567, 1
  %t570 = select i1 %t569, i32 1, i32 0
  %t571 = icmp eq i32 %t566, 0
  %t572 = shl i32 %t570, 16
  %t573 = or i32 %t572, %t568
  %t574 = select i1 %t571, i32 0, i32 %t573
  call void @__olang_scope_close(ptr %s10)
  %t576 = insertvalue { i32, ptr } zeroinitializer, i32 %t574, 0
  store { i32, ptr } %t576, ptr %rv
  br label %ret
bb118:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %t577)
  %t580 = extractvalue { i32, ptr } %t579, 1
  %t581 = extractvalue { i32, ptr } %t579, 0
  store i32 %t581, ptr %l233
  %t582 = icmp ne i32 %t581, 0
  br i1 %t582, label %bb120, label %ok.583
ok.583:
  store ptr %t580, ptr %l232
  br label %bb119
bb119:
  %t584 = load ptr, ptr %l232, !tbaa !29
  store ptr %t584, ptr %l230, !tbaa !29
  br label %bb121
bb120:
  %t585 = load i32, ptr %l233, !tbaa !23
  %t586 = lshr i32 %t585, 16
  %t587 = and i32 %t585, 65535
  %t588 = icmp eq i32 %t586, 1
  %t589 = select i1 %t588, i32 1, i32 0
  %t590 = icmp eq i32 %t585, 0
  %t591 = shl i32 %t589, 16
  %t592 = or i32 %t591, %t587
  %t593 = select i1 %t590, i32 0, i32 %t592
  call void @__olang_scope_close(ptr %s10)
  %t595 = insertvalue { i32, ptr } zeroinitializer, i32 %t593, 0
  store { i32, ptr } %t595, ptr %rv
  br label %ret
bb121:
  %t596 = load ptr, ptr %l230, !tbaa !29
  store ptr %t596, ptr %l23, !tbaa !29
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t597)
  %t600 = extractvalue { i32, { i64, ptr } } %t599, 1
  %t601 = extractvalue { i32, { i64, ptr } } %t599, 0
  store i32 %t601, ptr %l238
  %t602 = icmp ne i32 %t601, 0
  br i1 %t602, label %bb123, label %ok.603
ok.603:
  store { i64, ptr } %t600, ptr %l237
  br label %bb122
bb122:
  %t604 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t604, ptr %l235, !tbaa !27
  br label %bb124
bb123:
  %t605 = load i32, ptr %l238, !tbaa !23
  %t606 = lshr i32 %t605, 16
  %t607 = and i32 %t605, 65535
  %t608 = icmp eq i32 %t606, 1
  %t609 = select i1 %t608, i32 1, i32 0
  %t610 = icmp eq i32 %t605, 0
  %t611 = shl i32 %t609, 16
  %t612 = or i32 %t611, %t607
  %t613 = select i1 %t610, i32 0, i32 %t612
  call void @__olang_scope_close(ptr %s10)
  %t615 = insertvalue { i32, ptr } zeroinitializer, i32 %t613, 0
  store { i32, ptr } %t615, ptr %rv
  br label %ret
bb124:
  %t616 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t616, ptr %l24, !tbaa !27
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load i32, ptr %l1, !tbaa !23
  %t621 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t617, i32 %t618)
  store %"compiler/source:Span" %t621, ptr %l242
  br label %bb125
bb125:
  %t622 = load %"compiler/source:Span", ptr %l242
  store %"compiler/source:Span" %t622, ptr %l25
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t626 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t623, i32 8)
  store i1 %t626, ptr %l245
  br label %bb126
bb126:
  %t627 = load i1, ptr %l245, !tbaa !21
  br i1 %t627, label %bb127, label %bb128
bb127:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t628)
  store i32 %t630, ptr %l247
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb130
bb130:
  %t631 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t631, ptr %l248
  %t632 = load ptr, ptr %lp21
  %t633 = load ptr, ptr %l22, !tbaa !29
  %t635 = load ptr, ptr %l23, !tbaa !29
  %t636 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t641 = call %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t632, ptr %t633, ptr %t635, { i64, ptr } %t636)
  store %"compiler/ast:For3" %t641, ptr %l254
  br label %bb131
bb131:
  %t642 = load %"compiler/ast:For3", ptr %l254
  %t643 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:For3" %t642, ptr %t643
  store { i64, [4 x i64] } zeroinitializer, ptr %t644
  %t645 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 0
  store i64 8, ptr %t645
  %t646 = load %"compiler/source:Span", ptr %l248
  %t647 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t646, 0
  %t649 = insertvalue { %"compiler/source:Span", ptr } %t647, ptr %t643, 1
  %t650 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t649, ptr %t650
  %t651 = load { i64, [4 x i64] }, ptr %t644
  %t653 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t651, ptr %t653
  call void @__olang_scope_close(ptr %s10)
  %t655 = insertvalue { i32, ptr } zeroinitializer, ptr %t653, 1
  store { i32, ptr } %t655, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t656)
  %t659 = extractvalue { i32, ptr } %t658, 1
  %t660 = extractvalue { i32, ptr } %t658, 0
  store i32 %t660, ptr %l261
  %t661 = icmp ne i32 %t660, 0
  br i1 %t661, label %bb135, label %ok.662
ok.662:
  store ptr %t659, ptr %l260
  br label %bb134
bb134:
  %t663 = load ptr, ptr %l260, !tbaa !29
  store ptr %t663, ptr %l258, !tbaa !29
  br label %bb136
bb135:
  %t664 = load i32, ptr %l261, !tbaa !23
  %t665 = lshr i32 %t664, 16
  %t666 = and i32 %t664, 65535
  %t667 = icmp eq i32 %t665, 1
  %t668 = select i1 %t667, i32 1, i32 0
  %t669 = icmp eq i32 %t664, 0
  %t670 = shl i32 %t668, 16
  %t671 = or i32 %t670, %t666
  %t672 = select i1 %t669, i32 0, i32 %t671
  %t674 = insertvalue { i32, ptr } zeroinitializer, i32 %t672, 0
  store { i32, ptr } %t674, ptr %rv
  br label %ret
bb136:
  %t675 = load ptr, ptr %l258, !tbaa !29
  store ptr %t675, ptr %l26, !tbaa !29
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t678 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %t676)
  %t679 = extractvalue { i32, { i64, ptr } } %t678, 1
  %t680 = extractvalue { i32, { i64, ptr } } %t678, 0
  store i32 %t680, ptr %l266
  %t681 = icmp ne i32 %t680, 0
  br i1 %t681, label %bb138, label %ok.682
ok.682:
  store { i64, ptr } %t679, ptr %l265
  br label %bb137
bb137:
  %t683 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t683, ptr %l263, !tbaa !27
  br label %bb139
bb138:
  %t684 = load i32, ptr %l266, !tbaa !23
  %t685 = lshr i32 %t684, 16
  %t686 = and i32 %t684, 65535
  %t687 = icmp eq i32 %t685, 1
  %t688 = select i1 %t687, i32 1, i32 0
  %t689 = icmp eq i32 %t684, 0
  %t690 = shl i32 %t688, 16
  %t691 = or i32 %t690, %t686
  %t692 = select i1 %t689, i32 0, i32 %t691
  %t694 = insertvalue { i32, ptr } zeroinitializer, i32 %t692, 0
  store { i32, ptr } %t694, ptr %rv
  br label %ret
bb139:
  %t695 = load { i64, ptr }, ptr %l263, !tbaa !27
  store { i64, ptr } %t695, ptr %l27, !tbaa !27
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load i32, ptr %l1, !tbaa !23
  %t700 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t696, i32 %t697)
  store %"compiler/source:Span" %t700, ptr %l270
  br label %bb140
bb140:
  %t701 = load %"compiler/source:Span", ptr %l270
  store %"compiler/source:Span" %t701, ptr %l28
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t705 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t702, i32 8)
  store i1 %t705, ptr %l273
  br label %bb141
bb141:
  %t706 = load i1, ptr %l273, !tbaa !21
  br i1 %t706, label %bb142, label %bb143
bb142:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t707)
  store i32 %t709, ptr %l275
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  %t710 = load %"compiler/source:Span", ptr %l28
  %t711 = load ptr, ptr %l26, !tbaa !29
  %t712 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t713
  %t714 = getelementptr { i64, [4 x i64] }, ptr %t713, i32 0, i32 0
  store i64 7, ptr %t714
  %t716 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t710, 0
  %t718 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t716, ptr %t711, 1
  %t720 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t718, { i64, ptr } %t712, 2
  %t721 = getelementptr { i64, [4 x i64] }, ptr %t713, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t720, ptr %t721
  %t722 = load { i64, [4 x i64] }, ptr %t713
  %t724 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t722, ptr %t724
  %t726 = insertvalue { i32, ptr } zeroinitializer, ptr %t724, 1
  store { i32, ptr } %t726, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l19 = alloca i32
  %l22 = alloca i64
  %l27 = alloca i32
  %l30 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i64
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l123 = alloca { i64, ptr }
  %l134 = alloca i1
  %l137 = alloca { i64, ptr }
  %l147 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca i1
  %l158 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i64
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l182 = alloca %"compiler/msgs:Msg"
  %l186 = alloca i1
  %l187 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l198 = alloca i64
  %l201 = alloca i1
  %l205 = alloca i32
  %l208 = alloca i1
  %l212 = alloca i32
  %l215 = alloca i1
  %l219 = alloca i32
  %l222 = alloca ptr
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l228 = alloca %"compiler/msgs:Msg"
  %l232 = alloca i1
  %l236 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l252 = alloca %"compiler/msgs:Msg"
  %l256 = alloca ptr
  %l257 = alloca i64
  %l258 = alloca %"compiler/msgs:Msg"
  %l262 = alloca i1
  %l265 = alloca i1
  %l269 = alloca i1
  %l272 = alloca i1
  %l273 = alloca i1
  %l274 = alloca ptr
  %l277 = alloca i64
  %l279 = alloca i1
  %l283 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i1
  %l291 = alloca i1
  %l293 = alloca i1
  %l294 = alloca i1
  %l297 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l308 = alloca i1
  %l312 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i64
  %l317 = alloca i64
  %l318 = alloca i1
  %l322 = alloca i1
  %l326 = alloca i1
  %l329 = alloca i1
  %l332 = alloca i1
  %l336 = alloca ptr
  %l337 = alloca i64
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/msgs:Msg"
  %l346 = alloca i1
  %l349 = alloca ptr
  %l350 = alloca i64
  %l351 = alloca %"compiler/msgs:Msg"
  %l355 = alloca i1
  %l356 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l360 = alloca i1
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l370 = alloca i1
  %l376 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 6
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load i32, ptr %l19
  store i32 %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l22
  br label %bb5
bb5:
  %t28 = load i64, ptr %l22, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l27
  br label %bb6
bb6:
  %t38 = load i32, ptr %l27
  store i32 %t38, ptr %l6
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l30
  br label %bb7
bb7:
  %t44 = load i64, ptr %l30, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t45 = load i32, ptr %l3
  %t47 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t45)
  store i1 %t47, ptr %l32
  br label %bb8
bb8:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t51, ptr %l35
  br label %bb11
bb10:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l35, !tbaa !21
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load i32, ptr %l6
  %t56 = trunc i64 76 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l44
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t69 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %s2, ptr %s2, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t77, ptr %l46
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i64, ptr %l41, !tbaa !24
  %t80 = load %"compiler/msgs:Msg", ptr %l46
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t78, i64 %t79, %"compiler/msgs:Msg" %t80)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l50
  br label %bb22
bb22:
  %t87 = load i1, ptr %l50, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %s3)
  store %"compiler/msgs:Msg" %t90, ptr %l53
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = load %"compiler/msgs:Msg", ptr %l53
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s3, ptr %t91, i64 %t92, %"compiler/msgs:Msg" %t93)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l57
  br label %bb28
bb28:
  %t100 = load i1, ptr %l57, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l58, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t114 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t108, i64 %t111)
  store i64 %t114, ptr %l66
  br label %bb34
bb33:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l66, !tbaa !24
  %t118 = icmp slt i64 %t116, %t115
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb36, label %bb37
bb36:
  %t121 = load i32, ptr %l3
  %t123 = trunc i64 40 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb62
bb38:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb40
bb39:
  %t126 = load i32, ptr %l3
  %t128 = trunc i64 62 to i32
  %t129 = icmp eq i32 %t126, %t128
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l72, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb43
bb42:
  %t132 = load i32, ptr %l3
  %t134 = trunc i64 60 to i32
  %t135 = icmp eq i32 %t132, %t134
  store i1 %t135, ptr %l75, !tbaa !21
  br label %bb43
bb43:
  %t137 = load i1, ptr %l75, !tbaa !21
  br i1 %t137, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb46
bb45:
  %t138 = load i32, ptr %l3
  %t140 = trunc i64 57 to i32
  %t141 = icmp eq i32 %t138, %t140
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb46
bb46:
  %t143 = load i1, ptr %l78, !tbaa !21
  br i1 %t143, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb61
bb48:
  %t144 = load i32, ptr %l3
  %t146 = trunc i64 1 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load i32, ptr %l6
  %t151 = trunc i64 19 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb60
bb51:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb53
bb52:
  %t154 = load i32, ptr %l6
  %t156 = trunc i64 20 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t159 = load i1, ptr %l87, !tbaa !21
  br i1 %t159, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb56
bb55:
  %t160 = load i32, ptr %l6
  %t162 = trunc i64 21 to i32
  %t163 = icmp eq i32 %t160, %t162
  store i1 %t163, ptr %l90, !tbaa !21
  br label %bb56
bb56:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb59
bb58:
  %t166 = load i32, ptr %l6
  %t168 = trunc i64 14 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l93, !tbaa !21
  br label %bb59
bb59:
  %t171 = load i1, ptr %l93, !tbaa !21
  store i1 %t171, ptr %l84, !tbaa !21
  br label %bb60
bb60:
  %t172 = load i1, ptr %l84, !tbaa !21
  store i1 %t172, ptr %l81, !tbaa !21
  br label %bb61
bb61:
  %t173 = load i1, ptr %l81, !tbaa !21
  store i1 %t173, ptr %l69, !tbaa !21
  br label %bb62
bb62:
  %t174 = load i1, ptr %l69, !tbaa !21
  br i1 %t174, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s4
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l96, !tbaa !29
  %t176 = load i64, ptr %l5, !tbaa !24
  store i64 %t176, ptr %l97, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l5, !tbaa !24
  %t181 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s4, ptr %t177, i64 %t178)
  store { i64, ptr } %t181, ptr %l100
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t182 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s4, ptr %s4, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l102
  br label %bb66
bb66:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load i64, ptr %l97, !tbaa !24
  %t193 = load %"compiler/msgs:Msg", ptr %l102
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t191, i64 %t192, %"compiler/msgs:Msg" %t193)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb68:
  %t195 = load i32, ptr %l6
  %t197 = trunc i64 76 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb69, label %bb70
bb69:
  %t200 = load i32, ptr %l3
  %t202 = trunc i64 21 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb83
bb71:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb73
bb72:
  %t205 = load i32, ptr %l3
  %t207 = trunc i64 13 to i32
  %t208 = icmp eq i32 %t205, %t207
  store i1 %t208, ptr %l109, !tbaa !21
  br label %bb73
bb73:
  %t210 = load i1, ptr %l109, !tbaa !21
  br i1 %t210, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb76
bb75:
  %t211 = load i32, ptr %l3
  %t213 = trunc i64 19 to i32
  %t214 = icmp eq i32 %t211, %t213
  store i1 %t214, ptr %l112, !tbaa !21
  br label %bb76
bb76:
  %t216 = load i1, ptr %l112, !tbaa !21
  br i1 %t216, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb79
bb78:
  %t217 = load i32, ptr %l3
  %t219 = trunc i64 20 to i32
  %t220 = icmp eq i32 %t217, %t219
  store i1 %t220, ptr %l115, !tbaa !21
  br label %bb79
bb79:
  %t222 = load i1, ptr %l115, !tbaa !21
  br i1 %t222, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb82
bb81:
  %t223 = load i32, ptr %l3
  %t225 = trunc i64 39 to i32
  %t226 = icmp eq i32 %t223, %t225
  store i1 %t226, ptr %l118, !tbaa !21
  br label %bb82
bb82:
  %t228 = load i1, ptr %l118, !tbaa !21
  store i1 %t228, ptr %l106, !tbaa !21
  br label %bb83
bb83:
  %t229 = load i1, ptr %l106, !tbaa !21
  br i1 %t229, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s5
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/parse:Parser", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = getelementptr %"compiler/scan:Tokens", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l123, !tbaa !27
  %t237 = load i64, ptr %l2, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr %"compiler/token:Token", ptr %t240, i64 %t237
  %t242 = getelementptr %"compiler/token:Token", ptr %t241, i32 0, i32 2
  %t243 = load i32, ptr %t242, !tbaa !23
  %t245 = sext i32 %t243 to i64
  store i64 %t245, ptr %l8, !tbaa !24
  %t247 = load i64, ptr %l8, !tbaa !24
  store i64 %t247, ptr %l9, !tbaa !24
  br label %bb86
bb85:
  br label %bb116
bb86:
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/parse:Parser", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/source:Source", ptr %t253, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t261 = icmp slt i64 %t249, %t258
  br i1 %t261, label %bb87, label %bb88
bb87:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/parse:Parser", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/source:Source", ptr %t266, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l137, !tbaa !27
  %t270 = load i64, ptr %l9, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i8, ptr %t273, i64 %t270
  %t275 = load i8, ptr %t274, !tbaa !32
  %t277 = icmp ne i8 %t275, 10
  store i1 %t277, ptr %l134, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb89
bb89:
  %t279 = load i1, ptr %l134, !tbaa !21
  %t280 = xor i1 %t279, true
  br i1 %t280, label %bb90, label %bb91
bb90:
  br label %bb94
bb91:
  br label %bb92
bb92:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t284 = add i64 %t282, 1
  store i64 %t284, ptr %l9, !tbaa !24
  br label %bb93
bb93:
  br label %bb86
bb94:
  br label %bb95
bb95:
  %t286 = load i64, ptr %l9, !tbaa !24
  %t287 = load i64, ptr %l8, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb96, label %bb97
bb96:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/source:Source", ptr %t295, i32 0, i32 1
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l150, !tbaa !27
  %t299 = load i64, ptr %l9, !tbaa !24
  %t301 = sub i64 %t299, 1
  %t303 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i8, ptr %t304, i64 %t301
  %t306 = load i8, ptr %t305, !tbaa !32
  %t308 = icmp eq i8 %t306, 32
  br i1 %t308, label %bb98, label %bb99
bb97:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb101
bb98:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb100
bb99:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/source:Source", ptr %t313, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l158, !tbaa !27
  %t317 = load i64, ptr %l9, !tbaa !24
  %t319 = sub i64 %t317, 1
  %t321 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i8, ptr %t322, i64 %t319
  %t324 = load i8, ptr %t323, !tbaa !32
  %t326 = icmp eq i8 %t324, 9
  store i1 %t326, ptr %l155, !tbaa !21
  br label %bb100
bb100:
  %t328 = load i1, ptr %l155, !tbaa !21
  store i1 %t328, ptr %l147, !tbaa !21
  br label %bb101
bb101:
  %t329 = load i1, ptr %l147, !tbaa !21
  %t330 = xor i1 %t329, true
  br i1 %t330, label %bb102, label %bb103
bb102:
  br label %bb106
bb103:
  br label %bb104
bb104:
  %t332 = load i64, ptr %l9, !tbaa !24
  %t334 = sub i64 %t332, 1
  store i64 %t334, ptr %l9, !tbaa !24
  br label %bb105
bb105:
  br label %bb95
bb106:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l166, !tbaa !29
  %t337 = load i64, ptr %l2, !tbaa !24
  store i64 %t337, ptr %l167, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l2, !tbaa !24
  %t342 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s5, ptr %t338, i64 %t339)
  store { i64, ptr } %t342, ptr %l170
  br label %bb107
bb107:
  %t343 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l171, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/parse:Parser", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/source:Source", ptr %t353, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  store { i64, ptr } %t356, ptr %l174, !tbaa !27
  %t357 = load i64, ptr %l8, !tbaa !24
  store i64 %t357, ptr %l175, !tbaa !24
  %t358 = load i64, ptr %l9, !tbaa !24
  store i64 %t358, ptr %l176, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l177, !tbaa !24
  %t361 = load i64, ptr %l175, !tbaa !24
  %t362 = icmp sge i64 %t361, 0
  br i1 %t362, label %bb108, label %bb109
bb108:
  %t364 = load i64, ptr %l175, !tbaa !24
  %t365 = load i64, ptr %l176, !tbaa !24
  %t366 = icmp sle i64 %t364, %t365
  br i1 %t366, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb110:
  %t368 = load i64, ptr %l176, !tbaa !24
  %t369 = load i64, ptr %l177, !tbaa !24
  %t370 = icmp sle i64 %t368, %t369
  br i1 %t370, label %bb112, label %bb113
bb111:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb112:
  %t372 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = load i64, ptr %l175, !tbaa !24
  %t375 = load i64, ptr %l176, !tbaa !24
  %t376 = getelementptr i8, ptr %t373, i64 %t374
  %t377 = sub i64 %t375, %t374
  %t378 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t376, 1
  %t380 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t382 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %s5, ptr %v0, ptr %s5, { i64, ptr } %t380, { i64, ptr } %t379)
  store %"compiler/msgs:Msg" %t382, ptr %l182
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5)
  unreachable
bb114:
  %t383 = load ptr, ptr %l166, !tbaa !29
  %t384 = load i64, ptr %l167, !tbaa !24
  %t385 = load %"compiler/msgs:Msg", ptr %l182
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t383, i64 %t384, %"compiler/msgs:Msg" %t385)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb116:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i64, ptr %l2, !tbaa !24
  %t391 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t387, i64 %t388)
  store i1 %t391, ptr %l186
  br label %bb117
bb117:
  %t392 = load i1, ptr %l186, !tbaa !21
  br i1 %t392, label %bb118, label %bb119
bb118:
  %t393 = load i32, ptr %l3
  %t395 = trunc i64 40 to i32
  %t396 = icmp eq i32 %t393, %t395
  %t398 = xor i1 %t396, true
  store i1 %t398, ptr %l187, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb120
bb120:
  %t400 = load i1, ptr %l187, !tbaa !21
  br i1 %t400, label %bb121, label %bb122
bb121:
  %t401 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t403, ptr %l193
  br label %bb123
bb122:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb140
bb123:
  %t404 = load i1, ptr %l193, !tbaa !21
  br i1 %t404, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb139
bb125:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l2, !tbaa !24
  %t408 = add i64 %t406, 1
  %t411 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t405, i64 %t408)
  store i64 %t411, ptr %l198
  br label %bb126
bb126:
  %t412 = load i64, ptr %l4, !tbaa !24
  %t413 = load i64, ptr %l198, !tbaa !24
  %t415 = icmp eq i64 %t413, %t412
  br i1 %t415, label %bb127, label %bb128
bb127:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i64, ptr %l2, !tbaa !24
  %t420 = add i64 %t418, 1
  %t423 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t417, i64 %t420)
  store i32 %t423, ptr %l205
  br label %bb129
bb128:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb138
bb129:
  %t424 = load i32, ptr %l205
  %t426 = trunc i64 1 to i32
  %t427 = icmp eq i32 %t424, %t426
  br i1 %t427, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l208, !tbaa !21
  br label %bb133
bb131:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i64, ptr %l2, !tbaa !24
  %t432 = add i64 %t430, 1
  %t435 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t429, i64 %t432)
  store i32 %t435, ptr %l212
  br label %bb132
bb132:
  %t436 = load i32, ptr %l212
  %t438 = trunc i64 40 to i32
  %t439 = icmp eq i32 %t436, %t438
  store i1 %t439, ptr %l208, !tbaa !21
  br label %bb133
bb133:
  %t441 = load i1, ptr %l208, !tbaa !21
  br i1 %t441, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb137
bb135:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l2, !tbaa !24
  %t445 = add i64 %t443, 1
  %t448 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t442, i64 %t445)
  store i32 %t448, ptr %l219
  br label %bb136
bb136:
  %t449 = load i32, ptr %l219
  %t451 = trunc i64 62 to i32
  %t452 = icmp eq i32 %t449, %t451
  store i1 %t452, ptr %l215, !tbaa !21
  br label %bb137
bb137:
  %t454 = load i1, ptr %l215, !tbaa !21
  store i1 %t454, ptr %l201, !tbaa !21
  br label %bb138
bb138:
  %t455 = load i1, ptr %l201, !tbaa !21
  store i1 %t455, ptr %l194, !tbaa !21
  br label %bb139
bb139:
  %t456 = load i1, ptr %l194, !tbaa !21
  store i1 %t456, ptr %l191, !tbaa !21
  br label %bb140
bb140:
  %t457 = load i1, ptr %l191, !tbaa !21
  br i1 %t457, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s8
  %t458 = load ptr, ptr %l0, !tbaa !29
  store ptr %t458, ptr %l222, !tbaa !29
  %t459 = load i64, ptr %l2, !tbaa !24
  store i64 %t459, ptr %l223, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i64, ptr %l2, !tbaa !24
  %t464 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s8, ptr %t460, i64 %t461)
  store { i64, ptr } %t464, ptr %l226
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t465 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t473 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s8, ptr %s8, { i64, ptr } %t471)
  store %"compiler/msgs:Msg" %t473, ptr %l228
  br label %bb144
bb144:
  %t474 = load ptr, ptr %l222, !tbaa !29
  %t475 = load i64, ptr %l223, !tbaa !24
  %t476 = load %"compiler/msgs:Msg", ptr %l228
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s8, ptr %t474, i64 %t475, %"compiler/msgs:Msg" %t476)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb146:
  %t478 = load i32, ptr %l6
  %t480 = trunc i64 8 to i32
  %t481 = icmp eq i32 %t478, %t480
  br i1 %t481, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb149
bb148:
  %t483 = load i64, ptr %l7, !tbaa !24
  %t484 = load i64, ptr %l4, !tbaa !24
  %t487 = icmp slt i64 %t483, %t484
  store i1 %t487, ptr %l232, !tbaa !21
  br label %bb149
bb149:
  %t489 = load i1, ptr %l232, !tbaa !21
  br i1 %t489, label %bb150, label %bb151
bb150:
  %t490 = load i64, ptr %l4, !tbaa !24
  %t492 = icmp sgt i64 %t490, 0
  store i1 %t492, ptr %l236, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb152
bb152:
  %t494 = load i1, ptr %l236, !tbaa !21
  br i1 %t494, label %bb153, label %bb154
bb153:
  %t495 = load i32, ptr %l3
  %t497 = call i1 @compiler_2fparse_2eisJoiningOp(i32 %t495)
  store i1 %t497, ptr %l241
  br label %bb155
bb154:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb156
bb155:
  %t498 = load i1, ptr %l241, !tbaa !21
  store i1 %t498, ptr %l239, !tbaa !21
  br label %bb156
bb156:
  %t499 = load i1, ptr %l239, !tbaa !21
  br i1 %t499, label %bb157, label %bb158
bb157:
  store %olang.scope zeroinitializer, ptr %s9
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %l2, !tbaa !24
  store i64 %t501, ptr %l243, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i64, ptr %l2, !tbaa !24
  %t506 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s9, ptr %t502, i64 %t503)
  store { i64, ptr } %t506, ptr %l246
  br label %bb159
bb158:
  br label %bb163
bb159:
  %t507 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 0
  %t509 = extractvalue { i64, ptr } %t507, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l247, !tbaa !27
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l2, !tbaa !24
  %t518 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s9, ptr %t514, i64 %t515)
  store { i64, ptr } %t518, ptr %l250
  br label %bb160
bb160:
  %t519 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t521 = extractvalue { i64, ptr } %t519, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  %t526 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t528 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t526, { i64, ptr } %t525)
  store %"compiler/msgs:Msg" %t528, ptr %l252
  br label %bb161
bb161:
  %t529 = load ptr, ptr %l242, !tbaa !29
  %t530 = load i64, ptr %l243, !tbaa !24
  %t531 = load %"compiler/msgs:Msg", ptr %l252
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s9, ptr %t529, i64 %t530, %"compiler/msgs:Msg" %t531)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb163:
  %t533 = load i32, ptr %l3
  %t535 = trunc i64 43 to i32
  %t536 = icmp eq i32 %t533, %t535
  br i1 %t536, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s10
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l256, !tbaa !29
  %t539 = load i64, ptr %l2, !tbaa !24
  store i64 %t539, ptr %l257, !tbaa !24
  %t540 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %s10)
  store %"compiler/msgs:Msg" %t540, ptr %l258
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t541 = load ptr, ptr %l256, !tbaa !29
  %t542 = load i64, ptr %l257, !tbaa !24
  %t543 = load %"compiler/msgs:Msg", ptr %l258
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s10, ptr %t541, i64 %t542, %"compiler/msgs:Msg" %t543)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb168:
  %t545 = load i32, ptr %l3
  %t547 = trunc i64 5 to i32
  %t548 = icmp eq i32 %t545, %t547
  br i1 %t548, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l262, !tbaa !21
  br label %bb171
bb170:
  %t550 = load i32, ptr %l3
  %t552 = trunc i64 87 to i32
  %t553 = icmp eq i32 %t550, %t552
  store i1 %t553, ptr %l262, !tbaa !21
  br label %bb171
bb171:
  %t555 = load i1, ptr %l262, !tbaa !21
  br i1 %t555, label %bb172, label %bb173
bb172:
  %t556 = load i64, ptr %l7, !tbaa !24
  %t557 = load i64, ptr %l4, !tbaa !24
  %t560 = icmp eq i64 %t556, %t557
  store i1 %t560, ptr %l265, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb174
bb174:
  %t562 = load i1, ptr %l265, !tbaa !21
  br i1 %t562, label %bb175, label %bb176
bb175:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i64, ptr %l5, !tbaa !24
  %t567 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %t563, i64 %t564)
  store i1 %t567, ptr %l272
  br label %bb177
bb176:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb178
bb177:
  %t568 = load i1, ptr %l272, !tbaa !21
  store i1 %t568, ptr %l269, !tbaa !21
  br label %bb178
bb178:
  %t569 = load i1, ptr %l269, !tbaa !21
  br i1 %t569, label %bb179, label %bb180
bb179:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l274, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load i64, ptr %l5, !tbaa !24
  %t575 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %t571, i64 %t572)
  store i64 %t575, ptr %l277
  br label %bb181
bb180:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb183
bb181:
  %t576 = load i64, ptr %l5, !tbaa !24
  %t577 = load ptr, ptr %l274, !tbaa !29
  %t578 = load i64, ptr %l277, !tbaa !24
  %t580 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t577, i64 %t578, i64 %t576)
  store i1 %t580, ptr %l279
  br label %bb182
bb182:
  %t581 = load i1, ptr %l279, !tbaa !21
  store i1 %t581, ptr %l273, !tbaa !21
  br label %bb183
bb183:
  %t582 = load i1, ptr %l273, !tbaa !21
  br i1 %t582, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb185:
  br label %bb186
bb186:
  %t584 = load i32, ptr %l6
  %t586 = trunc i64 5 to i32
  %t587 = icmp eq i32 %t584, %t586
  br i1 %t587, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb190
bb188:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i64, ptr %l5, !tbaa !24
  %t593 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %t589, i64 %t590)
  store i1 %t593, ptr %l286
  br label %bb189
bb189:
  %t594 = load i1, ptr %l286, !tbaa !21
  store i1 %t594, ptr %l283, !tbaa !21
  br label %bb190
bb190:
  %t595 = load i1, ptr %l283, !tbaa !21
  br i1 %t595, label %bb191, label %bb192
bb191:
  %t596 = load i64, ptr %l7, !tbaa !24
  %t597 = load i64, ptr %l4, !tbaa !24
  %t600 = icmp eq i64 %t596, %t597
  store i1 %t600, ptr %l287, !tbaa !21
  br label %bb193
bb192:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb193
bb193:
  %t602 = load i1, ptr %l287, !tbaa !21
  br i1 %t602, label %bb194, label %bb195
bb194:
  %t603 = load i32, ptr %l3
  %t605 = call i1 @compiler_2fparse_2eisOperandEndTok(i32 %t603)
  store i1 %t605, ptr %l293
  br label %bb196
bb195:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb200
bb196:
  %t606 = load i1, ptr %l293, !tbaa !21
  br i1 %t606, label %bb197, label %bb198
bb197:
  store i1 true, ptr %l294, !tbaa !21
  br label %bb199
bb198:
  %t607 = load i32, ptr %l3
  %t609 = trunc i64 90 to i32
  %t610 = icmp eq i32 %t607, %t609
  store i1 %t610, ptr %l294, !tbaa !21
  br label %bb199
bb199:
  %t612 = load i1, ptr %l294, !tbaa !21
  store i1 %t612, ptr %l291, !tbaa !21
  br label %bb200
bb200:
  %t613 = load i1, ptr %l291, !tbaa !21
  br i1 %t613, label %bb201, label %bb202
bb201:
  %t614 = load i32, ptr %l3
  %t616 = trunc i64 91 to i32
  %t617 = icmp eq i32 %t614, %t616
  %t619 = xor i1 %t617, true
  store i1 %t619, ptr %l297, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb203
bb203:
  %t621 = load i1, ptr %l297, !tbaa !21
  br i1 %t621, label %bb204, label %bb205
bb204:
  %t622 = load i32, ptr %l3
  %t624 = trunc i64 93 to i32
  %t625 = icmp eq i32 %t622, %t624
  %t627 = xor i1 %t625, true
  store i1 %t627, ptr %l301, !tbaa !21
  br label %bb206
bb205:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb206
bb206:
  %t629 = load i1, ptr %l301, !tbaa !21
  br i1 %t629, label %bb207, label %bb208
bb207:
  %t630 = load i32, ptr %l6
  %t632 = trunc i64 5 to i32
  %t633 = icmp eq i32 %t630, %t632
  br i1 %t633, label %bb209, label %bb210
bb208:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb212
bb209:
  %t635 = load i32, ptr %l3
  %t637 = trunc i64 90 to i32
  %t638 = icmp eq i32 %t635, %t637
  store i1 %t638, ptr %l308, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l308, !tbaa !21
  br label %bb211
bb211:
  %t640 = load i1, ptr %l308, !tbaa !21
  %t641 = xor i1 %t640, true
  store i1 %t641, ptr %l305, !tbaa !21
  br label %bb212
bb212:
  %t643 = load i1, ptr %l305, !tbaa !21
  br i1 %t643, label %bb213, label %bb214
bb213:
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l313, !tbaa !29
  %t645 = load i64, ptr %l2, !tbaa !24
  store i64 %t645, ptr %l314, !tbaa !24
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load i64, ptr %l2, !tbaa !24
  %t650 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %t646, i64 %t647)
  store i64 %t650, ptr %l317
  br label %bb215
bb214:
  store i1 false, ptr %l312, !tbaa !21
  br label %bb217
bb215:
  %t651 = load ptr, ptr %l313, !tbaa !29
  %t652 = load i64, ptr %l314, !tbaa !24
  %t653 = load i64, ptr %l317, !tbaa !24
  %t654 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %t651, i64 %t652, i64 %t653)
  store i1 %t654, ptr %l318
  br label %bb216
bb216:
  %t655 = load i1, ptr %l318, !tbaa !21
  store i1 %t655, ptr %l312, !tbaa !21
  br label %bb217
bb217:
  %t656 = load i1, ptr %l312, !tbaa !21
  br i1 %t656, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb219:
  br label %bb220
bb220:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load i64, ptr %l2, !tbaa !24
  %t662 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %t658, i64 %t659)
  store i1 %t662, ptr %l322
  br label %bb221
bb221:
  %t663 = load i1, ptr %l322, !tbaa !21
  br i1 %t663, label %bb222, label %bb223
bb222:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb223:
  br label %bb224
bb224:
  %t665 = load i32, ptr %l3
  %t667 = trunc i64 91 to i32
  %t668 = icmp eq i32 %t665, %t667
  br i1 %t668, label %bb225, label %bb226
bb225:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb227
bb226:
  %t670 = load i32, ptr %l3
  %t672 = trunc i64 93 to i32
  %t673 = icmp eq i32 %t670, %t672
  store i1 %t673, ptr %l326, !tbaa !21
  br label %bb227
bb227:
  %t675 = load i1, ptr %l326, !tbaa !21
  br i1 %t675, label %bb228, label %bb229
bb228:
  %t676 = load i32, ptr %l6
  %t678 = trunc i64 57 to i32
  %t679 = icmp eq i32 %t676, %t678
  store i1 %t679, ptr %l329, !tbaa !21
  br label %bb230
bb229:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb230
bb230:
  %t681 = load i1, ptr %l329, !tbaa !21
  br i1 %t681, label %bb231, label %bb232
bb231:
  %t682 = load i64, ptr %l7, !tbaa !24
  %t683 = load i64, ptr %l4, !tbaa !24
  %t686 = icmp eq i64 %t682, %t683
  store i1 %t686, ptr %l332, !tbaa !21
  br label %bb233
bb232:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb233
bb233:
  %t688 = load i1, ptr %l332, !tbaa !21
  br i1 %t688, label %bb234, label %bb235
bb234:
  store %olang.scope zeroinitializer, ptr %s14
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l336, !tbaa !29
  %t690 = load i64, ptr %l5, !tbaa !24
  store i64 %t690, ptr %l337, !tbaa !24
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load i64, ptr %l2, !tbaa !24
  %t695 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s14, ptr %t691, i64 %t692)
  store { i64, ptr } %t695, ptr %l340
  br label %bb236
bb235:
  br label %bb239
bb236:
  %t696 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t704 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s14, ptr %s14, { i64, ptr } %t702)
  store %"compiler/msgs:Msg" %t704, ptr %l342
  br label %bb237
bb237:
  %t705 = load ptr, ptr %l336, !tbaa !29
  %t706 = load i64, ptr %l337, !tbaa !24
  %t707 = load %"compiler/msgs:Msg", ptr %l342
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s14, ptr %t705, i64 %t706, %"compiler/msgs:Msg" %t707)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb239:
  %t709 = load i32, ptr %l3
  %t711 = trunc i64 39 to i32
  %t712 = icmp eq i32 %t709, %t711
  br i1 %t712, label %bb240, label %bb241
bb240:
  %t714 = load i32, ptr %l6
  %t716 = trunc i64 59 to i32
  %t717 = icmp eq i32 %t714, %t716
  store i1 %t717, ptr %l346, !tbaa !21
  br label %bb242
bb241:
  store i1 false, ptr %l346, !tbaa !21
  br label %bb242
bb242:
  %t719 = load i1, ptr %l346, !tbaa !21
  br i1 %t719, label %bb243, label %bb244
bb243:
  store %olang.scope zeroinitializer, ptr %s15
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l349, !tbaa !29
  %t721 = load i64, ptr %l2, !tbaa !24
  store i64 %t721, ptr %l350, !tbaa !24
  %t722 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %s15)
  store %"compiler/msgs:Msg" %t722, ptr %l351
  br label %bb245
bb244:
  br label %bb247
bb245:
  %t723 = load ptr, ptr %l349, !tbaa !29
  %t724 = load i64, ptr %l350, !tbaa !24
  %t725 = load %"compiler/msgs:Msg", ptr %l351
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s15, ptr %t723, i64 %t724, %"compiler/msgs:Msg" %t725)
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb247:
  %t727 = load i32, ptr %l3
  %t729 = trunc i64 90 to i32
  %t730 = icmp eq i32 %t727, %t729
  br i1 %t730, label %bb248, label %bb249
bb248:
  %t732 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t732, ptr %l356, !tbaa !27
  %t734 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t734, ptr %l358
  br label %bb250
bb249:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb252
bb250:
  %t735 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 0
  %t737 = extractvalue { i64, ptr } %t735, 1
  %t738 = mul i64 %t736, 1
  %t739 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t738)
  call void @llvm.memcpy.p0.p0.i64(ptr %t739, ptr %t737, i64 %t738, i1 false)
  %t740 = insertvalue { i64, ptr } undef, i64 %t736, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t739, 1
  %t742 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t744 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t742, { i64, ptr } %t741)
  store i1 %t744, ptr %l360
  br label %bb251
bb251:
  %t745 = load i1, ptr %l360, !tbaa !21
  store i1 %t745, ptr %l355, !tbaa !21
  br label %bb252
bb252:
  %t746 = load i1, ptr %l355, !tbaa !21
  br i1 %t746, label %bb253, label %bb254
bb253:
  %t747 = load i32, ptr %l6
  %t749 = trunc i64 81 to i32
  %t750 = icmp eq i32 %t747, %t749
  br i1 %t750, label %bb255, label %bb256
bb254:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb261
bb255:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb257
bb256:
  %t752 = load i32, ptr %l6
  %t754 = trunc i64 89 to i32
  %t755 = icmp eq i32 %t752, %t754
  store i1 %t755, ptr %l364, !tbaa !21
  br label %bb257
bb257:
  %t757 = load i1, ptr %l364, !tbaa !21
  br i1 %t757, label %bb258, label %bb259
bb258:
  store i1 true, ptr %l367, !tbaa !21
  br label %bb260
bb259:
  %t758 = load i32, ptr %l6
  %t760 = trunc i64 1 to i32
  %t761 = icmp eq i32 %t758, %t760
  store i1 %t761, ptr %l367, !tbaa !21
  br label %bb260
bb260:
  %t763 = load i1, ptr %l367, !tbaa !21
  store i1 %t763, ptr %l361, !tbaa !21
  br label %bb261
bb261:
  %t764 = load i1, ptr %l361, !tbaa !21
  br i1 %t764, label %bb262, label %bb263
bb262:
  %t765 = load i64, ptr %l7, !tbaa !24
  %t766 = load i64, ptr %l4, !tbaa !24
  %t769 = icmp eq i64 %t765, %t766
  store i1 %t769, ptr %l370, !tbaa !21
  br label %bb264
bb263:
  store i1 false, ptr %l370, !tbaa !21
  br label %bb264
bb264:
  %t771 = load i1, ptr %l370, !tbaa !21
  br i1 %t771, label %bb265, label %bb266
bb265:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load i64, ptr %l2, !tbaa !24
  %t776 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %t772, i64 %t773)
  store i1 %t776, ptr %l376
  br label %bb267
bb266:
  br label %bb268
bb267:
  call void @__olang_scope_close(ptr %s0)
  %t777 = load i1, ptr %l376, !tbaa !21
  store i1 %t777, ptr %rv
  br label %ret
bb268:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:If"
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/ast:If"
  %rv = alloca { i32, ptr }
  %t123 = alloca { i64, [4 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l7, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28
ok.28:
  store ptr %t25, ptr %l15
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l15, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  br label %bb6
bb5:
  %t30 = load i32, ptr %l16, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = load ptr, ptr %l13, !tbaa !29
  store ptr %t41, ptr %l2, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %t42)
  %t45 = extractvalue { i32, ptr } %t44, 1
  %t46 = extractvalue { i32, ptr } %t44, 0
  store i32 %t46, ptr %l21
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48
ok.48:
  store ptr %t45, ptr %l20
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l20, !tbaa !29
  store ptr %t49, ptr %l18, !tbaa !29
  br label %bb9
bb8:
  %t50 = load i32, ptr %l21, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  %t60 = insertvalue { i32, ptr } zeroinitializer, i32 %t58, 0
  store { i32, ptr } %t60, ptr %rv
  br label %ret
bb9:
  %t61 = load ptr, ptr %l18, !tbaa !29
  store ptr %t61, ptr %l3, !tbaa !29
  store ptr null, ptr %l4, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t62, i32 10)
  store i1 %t65, ptr %l25
  br label %bb10
bb10:
  %t66 = load i1, ptr %l25, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 9)
  store i1 %t70, ptr %l28
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t71 = load i1, ptr %l28, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %t72)
  %t75 = extractvalue { i32, ptr } %t74, 1
  %t76 = extractvalue { i32, ptr } %t74, 0
  store i32 %t76, ptr %l32
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb17, label %ok.78
ok.78:
  store ptr %t75, ptr %l31
  br label %bb16
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %t79)
  %t82 = extractvalue { i32, ptr } %t81, 1
  %t83 = extractvalue { i32, ptr } %t81, 0
  store i32 %t83, ptr %l38
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb20, label %ok.85
ok.85:
  store ptr %t82, ptr %l37
  br label %bb19
bb16:
  %t86 = load ptr, ptr %l31, !tbaa !29
  store ptr %t86, ptr %l29, !tbaa !29
  br label %bb18
bb17:
  %t87 = load i32, ptr %l32, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  %t97 = insertvalue { i32, ptr } zeroinitializer, i32 %t95, 0
  store { i32, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t98 = load ptr, ptr %l29, !tbaa !29
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb23
bb19:
  %t100 = load ptr, ptr %l37, !tbaa !29
  store ptr %t100, ptr %l35, !tbaa !29
  br label %bb21
bb20:
  %t101 = load i32, ptr %l38, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  %t111 = insertvalue { i32, ptr } zeroinitializer, i32 %t109, 0
  store { i32, ptr } %t111, ptr %rv
  br label %ret
bb21:
  %t112 = load ptr, ptr %l35, !tbaa !29
  store ptr %t112, ptr %l5, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Branch", ptr %t113, i32 0, i32 0
  %t116 = load %"compiler/source:Span", ptr %t115
  store %"compiler/source:Span" %t116, ptr %l41
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t120 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr null, ptr %t117, ptr null)
  store %"compiler/ast:If" %t120, ptr %l44
  br label %bb22
bb22:
  %t121 = load %"compiler/ast:If", ptr %l44
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t121, ptr %t122
  store { i64, [4 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 0
  store i64 5, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l41
  %t126 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t125, 0
  %t128 = insertvalue { %"compiler/source:Span", ptr } %t126, ptr %t122, 1
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t128, ptr %t129
  %t130 = load { i64, [4 x i64] }, ptr %t123
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t130, ptr %t132
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t134, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l50
  br label %bb25
bb25:
  %t139 = load %"compiler/source:Span", ptr %l50
  store %"compiler/source:Span" %t139, ptr %l6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t143 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t140, i32 8)
  store i1 %t143, ptr %l53
  br label %bb26
bb26:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t145)
  store i32 %t147, ptr %l55
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t148 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t148, ptr %l56
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t157 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t149, ptr %t151, ptr %t153)
  store %"compiler/ast:If" %t157, ptr %l62
  br label %bb31
bb31:
  %t158 = load %"compiler/ast:If", ptr %l62
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t158, ptr %t159
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 5, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l56
  %t163 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t162, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t163, ptr %t159, 1
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [4 x i64] }, ptr %t160
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t167, ptr %t169
  %t171 = insertvalue { i32, ptr } zeroinitializer, ptr %t169, 1
  store { i32, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/token:Token"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca %"compiler/token:Token"
  %l53 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Oracle", ptr %t8, i32 0, i32 0
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t16)
  store %"compiler/token:Token" %t18, ptr %l18
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = load %"compiler/token:Token", ptr %l18
  %t21 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t19, %"compiler/token:Token" %t20)
  store { i64, ptr } %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t24 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l20
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l21, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb7:
  %t29 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t29, ptr %l22
  br label %bb8
bb8:
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t30, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store ptr %l2, ptr %l48, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l49, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t84 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t80, i64 %t77)
  store %"compiler/token:Token" %t84, ptr %l52
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l49, !tbaa !29
  %t86 = load %"compiler/token:Token", ptr %l52
  %t87 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t85, %"compiler/token:Token" %t86)
  store { i64, ptr } %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t88, { i64, ptr } %t89)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb15
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Oracle", ptr %t97, i32 0, i32 1
  store ptr %t99, ptr %l58, !tbaa !29
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l58, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t104 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } %t103)
  store i1 %t104, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i1, ptr %l61, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca ptr
  %l60 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 26
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i64, ptr %l11, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 25
  store ptr %t14, ptr %l13, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l15
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t18, i32 %t19)
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t22, i1 true)
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t26, i64 0)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 12
  store i1 false, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 17
  store i64 0, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 18
  store i1 false, ptr %t36, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 20
  store i64 0, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 21
  store i1 false, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 23
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t48, i64 0)
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %t50)
  %t53 = extractvalue { i32, ptr } %t52, 1
  %t54 = extractvalue { i32, ptr } %t52, 0
  store i32 %t54, ptr %l31
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb8, label %ok.56
ok.56:
  store ptr %t53, ptr %l30
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l30, !tbaa !29
  store ptr %t57, ptr %l28, !tbaa !29
  br label %bb33
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 26
  %t61 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t60, i64 %t61, i1 false)
  br label %bb10
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 38
  store ptr %t66, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l39
  br label %bb12
bb12:
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eAt_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l44
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/parse:Parser", ptr %t84, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t86, ptr %t83)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l4, !tbaa !24
  br label %bb11
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t94, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t96, i64 0)
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/parse:Parser", ptr %t98, i32 0, i32 23
  %t101 = load i1, ptr %t100, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/parse:Parser", ptr %t103, i32 0, i32 23
  store i1 false, ptr %t105, !tbaa !21
  br label %ret
bb22:
  br label %bb23
bb23:
  %t106 = load i64, ptr %l1, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 6
  %t110 = load i64, ptr %t109, !tbaa !24
  %t113 = icmp eq i64 %t106, %t110
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t115)
  store i32 %t117, ptr %l60
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %t118, i64 %t119)
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 6
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = load i64, ptr %l1, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  br i1 %t129, label %bb29, label %bb30
bb29:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t131)
  store i32 %t133, ptr %l68
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %ret
bb33:
  %t134 = load ptr, ptr %l28, !tbaa !29
  store ptr %t134, ptr %l6, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t135, i32 0, i32 37
  store ptr %t137, ptr %l70, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_3f74969944d00b69_b8e7e882b42021d)
  unreachable
bb35:
  br label %bb36
bb36:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t143 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t143, ptr %t142)
  br label %bb37
bb37:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinPieceHint(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/msgs:Msg"
  %l55 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l13
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l16
  br label %bb7
bb7:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp ne i64 %t20, %t21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/scan:Tokens", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t33
  %t38 = load %"compiler/token:Token", ptr %t37
  store %"compiler/token:Token" %t38, ptr %l3
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/scan:Tokens", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/token:Token", ptr %t50, i64 %t47
  %t52 = load %"compiler/token:Token", ptr %t51
  store %"compiler/token:Token" %t52, ptr %l4
  %t54 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = icmp sgt i32 %t55, %t57
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = sub i32 %t63, %t65
  %t70 = icmp sle i32 %t68, 60
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t72 = load i1, ptr %l32, !tbaa !21
  br i1 %t72, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  store i64 %t74, ptr %l38, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/source:Source", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store i64 %t85, ptr %l43, !tbaa !24
  %t86 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 3
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  store i64 %t89, ptr %l45, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l46, !tbaa !24
  %t92 = load i64, ptr %l43, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb17, label %bb18
bb16:
  %t95 = load i64, ptr %l1, !tbaa !24
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb25, label %bb26
bb17:
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = load i64, ptr %l45, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb19:
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb21:
  %t109 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l43, !tbaa !24
  %t112 = load i64, ptr %l45, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s2, { i64, ptr } %t116)
  store %"compiler/msgs:Msg" %t118, ptr %l51
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cbae392aecd52e99_b08c2106788b334d)
  unreachable
bb23:
  %t119 = load ptr, ptr %l37, !tbaa !29
  %t120 = load i64, ptr %l38, !tbaa !24
  %t121 = load %"compiler/msgs:Msg", ptr %l51
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s2, ptr %t119, i64 %t120, %"compiler/msgs:Msg" %t121)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l55, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  store i64 %t123, ptr %l56, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/token:Token", ptr %l3
  %t128 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t124, %"compiler/token:Token" %t125)
  store { i64, ptr } %t128, ptr %l59
  br label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l61, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l62, !tbaa !24
  %t131 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t131, ptr %l63
  br label %bb30
bb27:
  %t132 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %s4, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t133, ptr %l60
  br label %bb28
bb28:
  %t134 = load ptr, ptr %l55, !tbaa !29
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s4, ptr %t134, i64 %t135, %"compiler/msgs:Msg" %t136)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb30:
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = load %"compiler/msgs:Msg", ptr %l63
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s5, ptr %t137, i64 %t138, %"compiler/msgs:Msg" %t139)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  br label %bb33
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l7 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load %"compiler/token:Token", ptr %l1
  %t6 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t9 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t5, i8 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l2
  %t15 = load i32, ptr %l2
  %t17 = trunc i64 8 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i32, ptr %l2
  %t24 = trunc i64 60 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr %l2
  %t32 = trunc i64 58 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 90 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load i32, ptr %l2
  %t48 = trunc i64 57 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l25, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load i32, ptr %l2
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l29, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = load i32, ptr %l2
  %t64 = trunc i64 95 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l31 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t5)
  store i1 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i1, ptr %l9, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordField(ptr %v0, ptr %t11)
  store i1 %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t19, i64 1)
  store i32 %t21, ptr %l17
  br label %bb10
bb10:
  %t22 = load i32, ptr %l17
  store i32 %t22, ptr %l2
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 5 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 38 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t35 = load i32, ptr %l1
  %t37 = trunc i64 34 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t43, i64 %t47)
  store i64 %t50, ptr %l31
  br label %bb20
bb20:
  %t51 = load i64, ptr %l31, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 6
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/parse:Parser", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/scan:Tokens", ptr %t63, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp slt i64 %t59, %t68
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t73, i64 %t74)
  store i64 %t77, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l44, !tbaa !24
  %t81 = icmp eq i64 %t79, %t78
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l41, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l50
  br label %bb29
bb29:
  %t91 = load i32, ptr %l50
  store i32 %t91, ptr %l5
  %t92 = load i32, ptr %l5
  %t94 = trunc i64 35 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb31:
  %t97 = load i32, ptr %l5
  %t99 = trunc i64 36 to i32
  %t100 = icmp eq i32 %t97, %t99
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb35
bb34:
  %t103 = load i32, ptr %l5
  %t105 = trunc i64 37 to i32
  %t106 = icmp eq i32 %t103, %t105
  store i1 %t106, ptr %l56, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb38
bb37:
  %t109 = load i32, ptr %l5
  %t111 = trunc i64 22 to i32
  %t112 = icmp eq i32 %t109, %t111
  store i1 %t112, ptr %l59, !tbaa !21
  br label %bb38
bb38:
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb40:
  %t115 = load i32, ptr %l5
  %t117 = trunc i64 94 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l4, !tbaa !24
  br label %bb45
bb45:
  br label %bb21
bb46:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l14 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elambdaBody(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 61)
  store i1 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i1, ptr %l8, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l13
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  br label %bb6
bb5:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t27, 1
  store { i32, { i64, ptr } } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 15
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l2, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 14
  %t37 = load i1, ptr %t36, !tbaa !21
  store i1 %t37, ptr %l3, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 15
  store i1 true, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t46, i32 0, i32 14
  store i1 %a1, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %t51)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb9, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l24, !tbaa !27
  br label %bb10
bb9:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l2, !tbaa !21
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t68, i32 0, i32 15
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 14
  store i1 %t74, ptr %t77, !tbaa !21
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t67, 0
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
bb10:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i1, ptr %l2, !tbaa !21
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 15
  store i1 %t81, ptr %t84, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i1, ptr %l3, !tbaa !21
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 14
  store i1 %t86, ptr %t89, !tbaa !21
  %t90 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t2, i32 0, i32 20
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 20
  store i64 %t6, ptr %t9, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/scan:Tokens", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t5, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t24, i32 %t38)
  store i32 %t41, ptr %l19
  br label %bb7
bb7:
  %t42 = load i32, ptr %l19, !tbaa !23
  %t43 = sext i32 %t42 to i64
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elinkClause(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/token:Token"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l21 = alloca %"compiler/token:Token"
  %l23 = alloca i32
  %l26 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 1)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t7)
  store %"compiler/token:Token" %t9, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb7
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load %"compiler/token:Token", ptr %l8
  %t12 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t10, %"compiler/token:Token" %t11)
  store { i64, ptr } %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb6
bb6:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb7
bb7:
  %t16 = load i1, ptr %l5, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t17, i64 1)
  store i32 %t19, ptr %l13
  br label %bb10
bb9:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb11
bb10:
  %t20 = load i32, ptr %l13
  %t22 = trunc i64 5 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb11
bb11:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t28, ptr %l17
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l17
  %t30 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t29, 1
  store { i32, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l19
  br label %bb16
bb16:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t34)
  store %"compiler/token:Token" %t36, ptr %l21
  br label %bb17
bb17:
  %t37 = load %"compiler/token:Token", ptr %l21
  store %"compiler/token:Token" %t37, ptr %l1
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l23
  br label %bb18
bb18:
  %t41 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t44 = load i32, ptr %t43, !tbaa !23
  %t47 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t42, i32 %t44)
  store %"compiler/source:Span" %t47, ptr %l26
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load %"compiler/source:Span", ptr %l26
  %t49 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t48, 1
  store { i32, %"compiler/source:Span" } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %rv = alloca { i32, ptr }
  %t259 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i1, ptr %l23, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t7, i64 2)
  store i32 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i32, ptr %l27
  %t12 = trunc i64 92 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l25, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t18, i32 83)
  store i1 %t21, ptr %l33
  br label %bb8
bb7:
  br label %bb31
bb8:
  %t22 = load i1, ptr %l33, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 92)
  store i1 %t28, ptr %l38
  br label %bb11
bb10:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t29 = load i1, ptr %l38, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t33, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t36, i32 83)
  store i1 %t39, ptr %l43
  br label %bb16
bb16:
  %t40 = load i1, ptr %l43, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t41, i64 1)
  store i32 %t43, ptr %l45
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t44 = load i32, ptr %l45
  store i32 %t44, ptr %l3
  %t45 = load i32, ptr %l3
  %t47 = trunc i64 92 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = load i32, ptr %l3
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t57, i64 2)
  store i32 %t59, ptr %l54
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb25
bb24:
  %t60 = load i32, ptr %l54
  %t62 = trunc i64 92 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l52, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l49, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t69, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t73 = load ptr, ptr %l59, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load ptr, ptr %l59, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 14
  store i1 %t79, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t80 = load i1, ptr %l60, !tbaa !21
  br i1 %t80, label %bb34, label %bb35
bb34:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l4
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t95, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  br label %bb36
bb35:
  br label %bb77
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t99, i32 0, i32 35
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l71
  br label %bb37
bb37:
  %t104 = load i64, ptr %l71, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l5, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  br label %bb38
bb38:
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t108 = load ptr, ptr %l73, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb39, label %bb40
bb39:
  %t111 = load ptr, ptr %l73, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t115 = load i1, ptr %l74, !tbaa !21
  br i1 %t115, label %bb41, label %bb42
bb41:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32 }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/parse:Parser", ptr %t122, i32 0, i32 35
  %t125 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t124, i32 %t125)
  br label %bb44
bb44:
  br label %bb55
bb45:
  %t128 = load ptr, ptr %l8, !tbaa !29
  store ptr %t128, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t129 = load ptr, ptr %l82, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb46, label %bb47
bb46:
  %t132 = load ptr, ptr %l82, !tbaa !29
  %t133 = load i64, ptr %t132
  %t135 = icmp eq i64 %t133, 15
  store i1 %t135, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t136 = load i1, ptr %l83, !tbaa !21
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t137 = load ptr, ptr %l8, !tbaa !29
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t139, i32 0, i32 1
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l10, !tbaa !29
  %t143 = load ptr, ptr %l8, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l11, !tbaa !23
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 35
  %t152 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t151, i32 %t152)
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l10, !tbaa !29
  store ptr %t155, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  br label %bb54
bb54:
  br label %bb38
bb55:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/parse:Parser", ptr %t157, i32 0, i32 35
  %t160 = load i64, ptr %l7, !tbaa !24
  %t163 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t159, i64 %t160)
  store { i64, ptr } %t163, ptr %l97
  br label %bb56
bb56:
  %t164 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l99, !tbaa !24
  %t168 = load i64, ptr %l99, !tbaa !24
  %t169 = icmp sge i64 %t168, 0
  br i1 %t169, label %bb57, label %bb58
bb57:
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = icmp sle i64 %t171, 2305843009213693951
  br i1 %t172, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_2d89971a269bae53_cb14c861cebe6e1f)
  unreachable
bb59:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = mul i64 %t174, 4
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l15, !tbaa !24
  %t185 = load i64, ptr %l14, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2d89971a269bae53_cb14c861cebe6e1f)
  unreachable
bb61:
  %t190 = load i64, ptr %l16, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb66
bb63:
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l111, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb65
bb65:
  %t210 = load i64, ptr %l111, !tbaa !24
  store i64 %t210, ptr %l108, !tbaa !24
  br label %bb66
bb66:
  %t211 = load i64, ptr %l108, !tbaa !24
  store i64 %t211, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb67
bb67:
  %t212 = load i64, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l17, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb68, label %bb69
bb68:
  br label %bb72
bb69:
  br label %bb70
bb70:
  %t220 = load i64, ptr %l14, !tbaa !24
  %t221 = load i64, ptr %l18, !tbaa !24
  %t222 = load i64, ptr %l16, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l19, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t230, ptr %l129, !tbaa !27
  %t231 = load i64, ptr %l19, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t232, ptr %l131, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t237 = sub i64 %t235, 1
  %t238 = load i64, ptr %l19, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t243 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  %t249 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t231
  store i32 %t246, ptr %t251, !tbaa !33
  br label %bb71
bb71:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l18, !tbaa !24
  br label %bb67
bb72:
  %t256 = load %"compiler/source:Span", ptr %l4
  %t257 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t262 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t256, 0
  %t264 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t262, { i64, ptr } %t257, 1
  %t266 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t264, { i64, ptr } %t258, 2
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t266, ptr %t267
  %t268 = load { i64, [5 x i64] }, ptr %t259
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t268, ptr %t270
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l1, !tbaa !23
  %t278 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t272, i32 %t273, ptr %t270)
  store ptr %t278, ptr %l148
  br label %bb73
bb73:
  %t279 = load ptr, ptr %l148, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l1, !tbaa !23
  %t286 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t280, i32 %t281, ptr %t279)
  %t287 = extractvalue { i32, ptr } %t286, 1
  %t288 = extractvalue { i32, ptr } %t286, 0
  store i32 %t288, ptr %l154
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb75, label %ok.290
ok.290:
  store ptr %t287, ptr %l153
  br label %bb74
bb74:
  %t291 = load ptr, ptr %l153, !tbaa !29
  store ptr %t291, ptr %l149, !tbaa !29
  br label %bb76
bb75:
  %t292 = load i32, ptr %l154, !tbaa !23
  %t293 = lshr i32 %t292, 16
  %t294 = and i32 %t292, 65535
  %t295 = icmp eq i32 %t293, 1
  %t296 = select i1 %t295, i32 1, i32 0
  %t297 = icmp eq i32 %t292, 0
  %t298 = shl i32 %t296, 16
  %t299 = or i32 %t298, %t294
  %t300 = select i1 %t297, i32 0, i32 %t299
  %t302 = insertvalue { i32, ptr } zeroinitializer, i32 %t300, 0
  store { i32, ptr } %t302, ptr %rv
  br label %ret
bb76:
  %t303 = load ptr, ptr %l149, !tbaa !29
  %t304 = insertvalue { i32, ptr } zeroinitializer, ptr %t303, 1
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb77:
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = insertvalue { i32, ptr } zeroinitializer, ptr %t305, 1
  store { i32, ptr } %t307, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp sge i64 %t7, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/scan:Tokens", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 %t13, %t14
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %t16, i64 %t15)
  store i64 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/scan:Tokens", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp sge i64 %t20, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/scan:Tokens", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/scan:Tokens", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = sub i64 %t49, 1
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t51
  %t56 = load %"compiler/token:Token", ptr %t55
  store %"compiler/token:Token" %t56, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/parse:Parser", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/scan:Tokens", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i64 %t65
  %t70 = load %"compiler/token:Token", ptr %t69
  store %"compiler/token:Token" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/token:Token"
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l40 = alloca %"compiler/token:Token"
  %l42 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l51 = alloca %"compiler/source:Span"
  %rv = alloca ptr
  %t87 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 7
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 0 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t11, i32 83)
  store i1 %t14, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb4:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l18
  br label %bb7
bb7:
  %t19 = load i1, ptr %l18, !tbaa !21
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l12, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb36
bb11:
  br label %bb12
bb12:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t24, i32 59)
  store i1 %t27, ptr %l22
  br label %bb13
bb13:
  %t28 = load i1, ptr %l22, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  %t29 = load i1, ptr %l4, !tbaa !21
  br i1 %t29, label %bb14, label %bb15
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l25
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l27
  br label %bb18
bb18:
  store i32 0, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t37)
  store i32 %t39, ptr %l29
  br label %bb19
bb19:
  %t40 = load i32, ptr %l29
  store i32 %t40, ptr %l6
  %t41 = load i32, ptr %l6
  %t43 = trunc i64 1 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb22
bb21:
  %t46 = load i32, ptr %l6
  %t48 = trunc i64 13 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb23, label %bb24
bb23:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l37
  br label %bb25
bb24:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb26
bb25:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb26
bb26:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb27, label %bb28
bb27:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t59)
  store %"compiler/token:Token" %t61, ptr %l40
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t62 = load %"compiler/token:Token", ptr %l40
  store %"compiler/token:Token" %t62, ptr %l7
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t63)
  store i32 %t65, ptr %l42
  br label %bb30
bb30:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/parse:Parser", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/token:Token", ptr %l7
  %t74 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t70, %"compiler/token:Token" %t71)
  store { i64, ptr } %t74, ptr %l47
  br label %bb31
bb31:
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t75, { i64, ptr } %t76)
  store i32 %t77, ptr %l48
  br label %bb32
bb32:
  %t78 = load i32, ptr %l48, !tbaa !23
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb33
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t79, i32 %a1)
  store %"compiler/source:Span" %t83, ptr %l51
  br label %bb34
bb34:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i1, ptr %l4, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 0
  store i64 3, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l51
  %t90 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } undef, %"compiler/source:Span" %t89, 0
  %t92 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t90, ptr %t84, 1
  %t94 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t92, i32 %t85, 2
  %t96 = insertvalue { %"compiler/source:Span", ptr, i32, i1 } %t94, i1 %t86, 3
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, i1 } %t96, ptr %t97
  %t98 = load { i64, [5 x i64] }, ptr %t87
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t98, ptr %t100
  store ptr %t100, ptr %l3, !tbaa !29
  br label %bb35
bb35:
  br label %bb1
bb36:
  %t102 = load ptr, ptr %l3, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { { i64, ptr }, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i64
  %lp34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %lp37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { { i64, ptr }, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l63 = alloca %"compiler/token:Token"
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i32
  %l121 = alloca i64
  %l123 = alloca i64
  %l128 = alloca i32
  %l138 = alloca i1
  %l141 = alloca { i64, ptr }
  %l145 = alloca i1
  %l148 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l163 = alloca i1
  %l165 = alloca i1
  %l167 = alloca i1
  %l169 = alloca i1
  %l171 = alloca i1
  %l173 = alloca i1
  %l175 = alloca i1
  %l182 = alloca i1
  %l185 = alloca i1
  %l188 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca i32
  %l197 = alloca i32
  %l200 = alloca i32
  %l201 = alloca i32
  %l209 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l214 = alloca i1
  %l215 = alloca i1
  %l218 = alloca i1
  %l220 = alloca i32
  %l223 = alloca i1
  %l224 = alloca { { i64, ptr }, ptr }
  %l226 = alloca { { i64, ptr }, ptr }
  %l227 = alloca i32
  %l233 = alloca %"compiler/source:Span"
  %l236 = alloca { i64, ptr }
  %l242 = alloca %"compiler/ast:Case"
  %l246 = alloca i1
  %l248 = alloca i32
  %l249 = alloca i32
  %l252 = alloca i32
  %l253 = alloca i32
  %l257 = alloca i64
  %l260 = alloca i64
  %l263 = alloca ptr
  %l264 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca i32
  %l269 = alloca ptr
  %l271 = alloca ptr
  %l272 = alloca i32
  %l275 = alloca i1
  %l276 = alloca i1
  %l279 = alloca i1
  %l280 = alloca i1
  %l282 = alloca %"compiler/token:Token"
  %l284 = alloca i1
  %l287 = alloca i32
  %l288 = alloca i32
  %l290 = alloca i32
  %l291 = alloca i32
  %l295 = alloca i64
  %l296 = alloca [0 x ptr]
  %l297 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca i1
  %l310 = alloca { i64, ptr }
  %l312 = alloca i64
  %l314 = alloca i64
  %l315 = alloca { i64, ptr }
  %l320 = alloca %"compiler/source:Span"
  %l324 = alloca { i64, ptr }
  %l328 = alloca ptr
  %l330 = alloca %"compiler/source:Span"
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca ptr
  %l336 = alloca i32
  %l339 = alloca %"compiler/source:Span"
  %l343 = alloca ptr
  %l346 = alloca ptr
  %l349 = alloca i1
  %l352 = alloca i1
  %l355 = alloca i32
  %l358 = alloca i1
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l370 = alloca i1
  %l373 = alloca i1
  %l377 = alloca i32
  %l381 = alloca { i64, ptr }
  %l385 = alloca { i64, ptr }
  %l388 = alloca i1
  %l389 = alloca ptr
  %l391 = alloca ptr
  %l392 = alloca i32
  %l395 = alloca { { i64, ptr }, ptr }
  %l397 = alloca { { i64, ptr }, ptr }
  %l398 = alloca i32
  %l402 = alloca ptr
  %l405 = alloca %"compiler/source:Span"
  %l411 = alloca %"compiler/ast:Case"
  %l415 = alloca i1
  %l417 = alloca i32
  %l418 = alloca i32
  %l421 = alloca i32
  %l422 = alloca i32
  %l430 = alloca %"compiler/source:Span"
  %l431 = alloca ptr
  %l432 = alloca i1
  %l434 = alloca { i64, ptr }
  %l436 = alloca %"compiler/ast:Match"
  %s15 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t694 = alloca { i64, [5 x i64] }, align 8
  %t729 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 31)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l49
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l48
  br label %bb1
bb1:
  %t9 = load i32, ptr %l48, !tbaa !23
  store i32 %t9, ptr %l45, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l49, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l45, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  store i1 false, ptr %l2, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 1)
  store i1 %t25, ptr %l53
  br label %bb4
bb4:
  %t26 = load i1, ptr %l53, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l56
  br label %bb7
bb6:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i32, ptr %l56
  %t32 = trunc i64 94 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l54, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l54, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l60, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l61, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t41)
  store %"compiler/token:Token" %t43, ptr %l63
  br label %bb11
bb10:
  br label %bb25
bb11:
  %t44 = load ptr, ptr %l61, !tbaa !29
  %t45 = load %"compiler/token:Token", ptr %l63
  %t46 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t44, %"compiler/token:Token" %t45)
  store { i64, ptr } %t46, ptr %l64
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l60, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l65
  br label %bb13
bb13:
  %t50 = load i32, ptr %l65, !tbaa !23
  store i32 %t50, ptr %l3, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 28
  store ptr %t53, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l68, !tbaa !24
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l70
  br label %bb15
bb15:
  %t59 = load i64, ptr %l68, !tbaa !24
  %t60 = load i64, ptr %l70, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t69, ptr %l75
  br label %bb19
bb19:
  %t70 = load i32, ptr %l75, !tbaa !23
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = icmp eq i32 %t70, %t72
  br i1 %t75, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l5, !tbaa !24
  br label %bb14
bb24:
  br label %bb25
bb25:
  %t81 = load i1, ptr %l2, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t88 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t85, i32 1)
  store i1 %t88, ptr %l86
  br label %bb28
bb27:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb29
bb28:
  %t89 = load i1, ptr %l86, !tbaa !21
  store i1 %t89, ptr %l83, !tbaa !21
  br label %bb29
bb29:
  %t90 = load i1, ptr %l83, !tbaa !21
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t91, i64 1)
  store i32 %t93, ptr %l89
  br label %bb32
bb31:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb33
bb32:
  %t94 = load i32, ptr %l89
  %t96 = trunc i64 58 to i32
  %t97 = icmp eq i32 %t94, %t96
  store i1 %t97, ptr %l87, !tbaa !21
  br label %bb33
bb33:
  %t99 = load i1, ptr %l87, !tbaa !21
  br i1 %t99, label %bb34, label %bb35
bb34:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/parse:Parser", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/parse:Parser", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l95, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/parse:Parser", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/scan:Tokens", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l99, !tbaa !27
  %t117 = load i64, ptr %l7, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/token:Token", ptr %t120, i64 %t117
  %t122 = load %"compiler/token:Token", ptr %t121
  %t125 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t109, %"compiler/token:Token" %t122)
  store { i64, ptr } %t125, ptr %l102
  br label %bb36
bb35:
  br label %bb98
bb36:
  %t126 = load ptr, ptr %l95, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t128 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t126, { i64, ptr } %t127)
  store i32 %t128, ptr %l103
  br label %bb37
bb37:
  %t129 = load i32, ptr %l103, !tbaa !23
  store i32 %t129, ptr %l8, !tbaa !23
  store i1 false, ptr %l9, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/parse:Parser", ptr %t130, i32 0, i32 28
  store ptr %t132, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t134 = load i64, ptr %l11, !tbaa !24
  store i64 %t134, ptr %l106, !tbaa !24
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l108
  br label %bb39
bb39:
  %t138 = load i64, ptr %l106, !tbaa !24
  %t139 = load i64, ptr %l108, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t144, i64 %t145)
  store i32 %t148, ptr %l113
  br label %bb43
bb43:
  %t149 = load i32, ptr %l113, !tbaa !23
  %t151 = load i32, ptr %l8, !tbaa !23
  %t154 = icmp eq i32 %t149, %t151
  br i1 %t154, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l11, !tbaa !24
  br label %bb38
bb48:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/parse:Parser", ptr %t160, i32 0, i32 29
  store ptr %t162, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb49
bb49:
  %t164 = load i64, ptr %l14, !tbaa !24
  store i64 %t164, ptr %l121, !tbaa !24
  %t165 = load ptr, ptr %l13, !tbaa !29
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t165)
  store i64 %t167, ptr %l123
  br label %bb50
bb50:
  %t168 = load i64, ptr %l121, !tbaa !24
  %t169 = load i64, ptr %l123, !tbaa !24
  %t170 = icmp slt i64 %t168, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t174 = load ptr, ptr %l13, !tbaa !29
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t174, i64 %t175)
  store i32 %t178, ptr %l128
  br label %bb54
bb54:
  %t179 = load i32, ptr %l128, !tbaa !23
  %t181 = load i32, ptr %l8, !tbaa !23
  %t184 = icmp eq i32 %t179, %t181
  br i1 %t184, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l14, !tbaa !24
  br label %bb49
bb59:
  %t190 = load i64, ptr %l7, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l7, !tbaa !24
  %t194 = load i1, ptr %l9, !tbaa !21
  store i1 %t194, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t196 = load i1, ptr %l16, !tbaa !21
  br i1 %t196, label %bb61, label %bb62
bb61:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/parse:Parser", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/scan:Tokens", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l141, !tbaa !27
  %t205 = load i64, ptr %l7, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr %"compiler/token:Token", ptr %t208, i64 %t205
  %t210 = getelementptr %"compiler/token:Token", ptr %t209, i32 0, i32 0
  %t211 = load i32, ptr %t210
  %t213 = trunc i64 58 to i32
  %t214 = icmp eq i32 %t211, %t213
  store i1 %t214, ptr %l138, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb63
bb63:
  %t216 = load i1, ptr %l138, !tbaa !21
  br i1 %t216, label %bb64, label %bb65
bb64:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/parse:Parser", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/scan:Tokens", ptr %t220, i32 0, i32 0
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l148, !tbaa !27
  %t224 = load i64, ptr %l7, !tbaa !24
  %t226 = add i64 %t224, 1
  %t228 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr %"compiler/token:Token", ptr %t229, i64 %t226
  %t231 = getelementptr %"compiler/token:Token", ptr %t230, i32 0, i32 0
  %t232 = load i32, ptr %t231
  %t234 = trunc i64 1 to i32
  %t235 = icmp eq i32 %t232, %t234
  store i1 %t235, ptr %l145, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb66
bb66:
  %t237 = load i1, ptr %l145, !tbaa !21
  %t238 = xor i1 %t237, true
  br i1 %t238, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb68:
  br label %bb69
bb69:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/scan:Tokens", ptr %t244, i32 0, i32 0
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l157, !tbaa !27
  %t248 = load i64, ptr %l7, !tbaa !24
  %t250 = add i64 %t248, 1
  %t252 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/token:Token", ptr %t253, i64 %t250
  %t255 = load %"compiler/token:Token", ptr %t254
  %t258 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t240, %"compiler/token:Token" %t255)
  store { i64, ptr } %t258, ptr %l161
  br label %bb70
bb70:
  %t259 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t259, ptr %l18, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t260, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t262, ptr %l163
  br label %bb71
bb71:
  %t263 = load i1, ptr %l163, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb72, label %bb73
bb72:
  %t266 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t266, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t268, ptr %l167
  br label %bb74
bb73:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb75
bb74:
  %t269 = load i1, ptr %l167, !tbaa !21
  %t270 = xor i1 %t269, true
  store i1 %t270, ptr %l165, !tbaa !21
  br label %bb75
bb75:
  %t272 = load i1, ptr %l165, !tbaa !21
  br i1 %t272, label %bb76, label %bb77
bb76:
  %t273 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t275 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t273, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t275, ptr %l171
  br label %bb78
bb77:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb79
bb78:
  %t276 = load i1, ptr %l171, !tbaa !21
  %t277 = xor i1 %t276, true
  store i1 %t277, ptr %l169, !tbaa !21
  br label %bb79
bb79:
  %t279 = load i1, ptr %l169, !tbaa !21
  br i1 %t279, label %bb80, label %bb81
bb80:
  %t280 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t282 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t280, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t282, ptr %l175
  br label %bb82
bb81:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb83
bb82:
  %t283 = load i1, ptr %l175, !tbaa !21
  %t284 = xor i1 %t283, true
  store i1 %t284, ptr %l173, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l173, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t287 = load i64, ptr %l7, !tbaa !24
  %t289 = add i64 %t287, 2
  store i64 %t289, ptr %l7, !tbaa !24
  %t291 = load i64, ptr %l17, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb87:
  br label %bb60
bb88:
  %t295 = load i1, ptr %l16, !tbaa !21
  br i1 %t295, label %bb89, label %bb90
bb89:
  %t297 = load i64, ptr %l17, !tbaa !24
  %t299 = icmp sgt i64 %t297, 0
  store i1 %t299, ptr %l182, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb91
bb91:
  %t301 = load i1, ptr %l182, !tbaa !21
  br i1 %t301, label %bb92, label %bb93
bb92:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/parse:Parser", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = getelementptr %"compiler/scan:Tokens", ptr %t305, i32 0, i32 0
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l188, !tbaa !27
  %t309 = load i64, ptr %l7, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr %"compiler/token:Token", ptr %t312, i64 %t309
  %t314 = getelementptr %"compiler/token:Token", ptr %t313, i32 0, i32 0
  %t315 = load i32, ptr %t314
  %t317 = trunc i64 94 to i32
  %t318 = icmp eq i32 %t315, %t317
  store i1 %t318, ptr %l185, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb94
bb94:
  %t320 = load i1, ptr %l185, !tbaa !21
  br i1 %t320, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb97
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t321)
  %t324 = extractvalue { i32, ptr } %t323, 1
  %t325 = extractvalue { i32, ptr } %t323, 0
  store i32 %t325, ptr %l195
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb100, label %ok.327
ok.327:
  store ptr %t324, ptr %l194
  br label %bb99
bb99:
  %t328 = load ptr, ptr %l194, !tbaa !29
  store ptr %t328, ptr %l192, !tbaa !29
  br label %bb101
bb100:
  %t329 = load i32, ptr %l195, !tbaa !23
  %t330 = lshr i32 %t329, 16
  %t331 = and i32 %t329, 65535
  %t332 = icmp eq i32 %t330, 1
  %t333 = select i1 %t332, i32 1, i32 0
  %t334 = icmp eq i32 %t329, 0
  %t335 = shl i32 %t333, 16
  %t336 = or i32 %t335, %t331
  %t337 = select i1 %t334, i32 0, i32 %t336
  %t339 = insertvalue { i32, ptr } zeroinitializer, i32 %t337, 0
  store { i32, ptr } %t339, ptr %rv
  br label %ret
bb101:
  %t340 = load ptr, ptr %l192, !tbaa !29
  store ptr %t340, ptr %l19, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t344 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t341, i32 94)
  %t345 = extractvalue { i32, i32 } %t344, 1
  %t346 = extractvalue { i32, i32 } %t344, 0
  store i32 %t346, ptr %l201
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb103, label %ok.348
ok.348:
  store i32 %t345, ptr %l200
  br label %bb102
bb102:
  %t349 = load i32, ptr %l200, !tbaa !23
  store i32 %t349, ptr %l197, !tbaa !23
  br label %bb104
bb103:
  %t350 = load i32, ptr %l201, !tbaa !23
  %t351 = lshr i32 %t350, 16
  %t352 = and i32 %t350, 65535
  %t353 = icmp eq i32 %t351, 1
  %t354 = select i1 %t353, i32 1, i32 0
  %t355 = icmp eq i32 %t350, 0
  %t356 = shl i32 %t354, 16
  %t357 = or i32 %t356, %t352
  %t358 = select i1 %t355, i32 0, i32 %t357
  %t360 = insertvalue { i32, ptr } zeroinitializer, i32 %t358, 0
  store { i32, ptr } %t360, ptr %rv
  br label %ret
bb104:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 17
  %t364 = load i64, ptr %t363, !tbaa !24
  store i64 %t364, ptr %l20, !tbaa !24
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 17
  store i64 0, ptr %t368, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/parse:Parser", ptr %t369, i32 0, i32 18
  %t372 = load i1, ptr %t371, !tbaa !21
  store i1 %t372, ptr %l21, !tbaa !21
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/parse:Parser", ptr %t374, i32 0, i32 18
  store i1 false, ptr %t376, !tbaa !21
  %t377 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t377, ptr %l209
  br label %bb105
bb105:
  %t378 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l209
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t378, ptr %t379
  store ptr %t379, ptr %l22, !tbaa !29
  store ptr null, ptr %l23, !tbaa !29
  br label %bb106
bb106:
  %t381 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t381)
  br label %bb107
bb107:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t386 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t383, i32 95)
  store i1 %t386, ptr %l214
  br label %bb108
bb108:
  %t387 = load i1, ptr %l214, !tbaa !21
  br i1 %t387, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb112
bb110:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t391 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t388, i32 0)
  store i1 %t391, ptr %l218
  br label %bb111
bb111:
  %t392 = load i1, ptr %l218, !tbaa !21
  store i1 %t392, ptr %l215, !tbaa !21
  br label %bb112
bb112:
  %t393 = load i1, ptr %l215, !tbaa !21
  br i1 %t393, label %bb113, label %bb114
bb113:
  br label %bb251
bb114:
  br label %bb115
bb115:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t394)
  store i32 %t396, ptr %l220
  br label %bb116
bb116:
  %t397 = load i32, ptr %l220, !tbaa !23
  store i32 %t397, ptr %l24, !tbaa !23
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t401 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t398, i32 33)
  store i1 %t401, ptr %l223
  br label %bb117
bb117:
  %t402 = load i1, ptr %l223, !tbaa !21
  br i1 %t402, label %bb118, label %bb119
bb118:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %t403)
  %t406 = extractvalue { i32, { { i64, ptr }, ptr } } %t405, 1
  %t407 = extractvalue { i32, { { i64, ptr }, ptr } } %t405, 0
  store i32 %t407, ptr %l227
  %t408 = icmp ne i32 %t407, 0
  br i1 %t408, label %bb121, label %ok.409
ok.409:
  store { { i64, ptr }, ptr } %t406, ptr %l226
  br label %bb120
bb119:
  br label %bb138
bb120:
  %t410 = load { { i64, ptr }, ptr }, ptr %l226
  store { { i64, ptr }, ptr } %t410, ptr %l224
  br label %bb122
bb121:
  %t411 = load i32, ptr %l227, !tbaa !23
  %t412 = lshr i32 %t411, 16
  %t413 = and i32 %t411, 65535
  %t414 = icmp eq i32 %t412, 1
  %t415 = select i1 %t414, i32 1, i32 0
  %t416 = icmp eq i32 %t411, 0
  %t417 = shl i32 %t415, 16
  %t418 = or i32 %t417, %t413
  %t419 = select i1 %t416, i32 0, i32 %t418
  %t421 = insertvalue { i32, ptr } zeroinitializer, i32 %t419, 0
  store { i32, ptr } %t421, ptr %rv
  br label %ret
bb122:
  %t422 = load { { i64, ptr }, ptr }, ptr %l224
  store { { i64, ptr }, ptr } %t422, ptr %l25
  %t423 = getelementptr { { i64, ptr }, ptr }, ptr %l25, i32 0, i32 0
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  store { i64, ptr } %t424, ptr %l26, !tbaa !27
  %t426 = getelementptr { { i64, ptr }, ptr }, ptr %l25, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !29
  store ptr %t427, ptr %l27, !tbaa !29
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l24, !tbaa !23
  %t433 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t429, i32 %t430)
  store %"compiler/source:Span" %t433, ptr %l233
  br label %bb123
bb123:
  %t434 = icmp sge i64 0, 0
  br i1 %t434, label %bb124, label %bb125
bb124:
  %t436 = icmp sle i64 0, 1152921504606846975
  br i1 %t436, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb126:
  %t438 = mul i64 0, 8
  %t439 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t438)
  %t440 = insertvalue { i64, ptr } undef, i64 0, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l236, !tbaa !27
  %t442 = icmp sge i64 0, 0
  br i1 %t442, label %bb128, label %bb129
bb127:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb128:
  %t444 = icmp sle i64 0, 1152921504606846975
  br i1 %t444, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb130:
  %t446 = mul i64 0, 8
  %t447 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 0, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t450 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t451 = load ptr, ptr %l27, !tbaa !29
  %t452 = load %"compiler/source:Span", ptr %l233
  %t453 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t457 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t452, { i64, ptr } %t453, { i64, ptr } %t449, ptr null, { i64, ptr } %t450, ptr %t451)
  store %"compiler/ast:Case" %t457, ptr %l242
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_1c373b81de794f63_6badee9759230def)
  unreachable
bb132:
  %t458 = load %"compiler/ast:Case", ptr %l242
  %t459 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Case" %t458, ptr %t459
  store ptr %t459, ptr %l23, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t464 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t461, i32 8)
  store i1 %t464, ptr %l246
  br label %bb133
bb133:
  %t465 = load i1, ptr %l246, !tbaa !21
  br i1 %t465, label %bb134, label %bb135
bb134:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t466)
  store i32 %t468, ptr %l248
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  br label %bb250
bb138:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t472 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t469, i32 32)
  %t473 = extractvalue { i32, i32 } %t472, 1
  %t474 = extractvalue { i32, i32 } %t472, 0
  store i32 %t474, ptr %l253
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb140, label %ok.476
ok.476:
  store i32 %t473, ptr %l252
  br label %bb139
bb139:
  %t477 = load i32, ptr %l252, !tbaa !23
  store i32 %t477, ptr %l249, !tbaa !23
  br label %bb141
bb140:
  %t478 = load i32, ptr %l253, !tbaa !23
  %t479 = lshr i32 %t478, 16
  %t480 = and i32 %t478, 65535
  %t481 = icmp eq i32 %t479, 1
  %t482 = select i1 %t481, i32 1, i32 0
  %t483 = icmp eq i32 %t478, 0
  %t484 = shl i32 %t482, 16
  %t485 = or i32 %t484, %t480
  %t486 = select i1 %t483, i32 0, i32 %t485
  %t488 = insertvalue { i32, ptr } zeroinitializer, i32 %t486, 0
  store { i32, ptr } %t488, ptr %rv
  br label %ret
bb141:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/parse:Parser", ptr %t489, i32 0, i32 34
  %t493 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t491)
  store i64 %t493, ptr %l257
  br label %bb142
bb142:
  %t494 = load i64, ptr %l257, !tbaa !24
  store i64 %t494, ptr %l28, !tbaa !24
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/parse:Parser", ptr %t495, i32 0, i32 32
  %t499 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t497)
  store i64 %t499, ptr %l260
  br label %bb143
bb143:
  %t500 = load i64, ptr %l260, !tbaa !24
  store i64 %t500, ptr %l29, !tbaa !24
  br label %bb144
bb144:
  %t501 = load i1, ptr %l2, !tbaa !21
  br i1 %t501, label %bb145, label %bb146
bb145:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/parse:Parser", ptr %t503, i32 0, i32 32
  store ptr %t505, ptr %l263, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %t506)
  %t509 = extractvalue { i32, ptr } %t508, 1
  %t510 = extractvalue { i32, ptr } %t508, 0
  store i32 %t510, ptr %l267
  %t511 = icmp ne i32 %t510, 0
  br i1 %t511, label %bb148, label %ok.512
ok.512:
  store ptr %t509, ptr %l266
  br label %bb147
bb146:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t513, i64 1)
  %t516 = extractvalue { i32, ptr } %t515, 1
  %t517 = extractvalue { i32, ptr } %t515, 0
  store i32 %t517, ptr %l272
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb152, label %ok.519
ok.519:
  store ptr %t516, ptr %l271
  br label %bb151
bb147:
  %t520 = load ptr, ptr %l266, !tbaa !29
  store ptr %t520, ptr %l264, !tbaa !29
  br label %bb149
bb148:
  %t521 = load i32, ptr %l267, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  %t531 = insertvalue { i32, ptr } zeroinitializer, i32 %t529, 0
  store { i32, ptr } %t531, ptr %rv
  br label %ret
bb149:
  %t532 = load ptr, ptr %l263, !tbaa !29
  %t533 = load ptr, ptr %l264, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t532, ptr %t533)
  br label %bb150
bb150:
  br label %bb196
bb151:
  %t534 = load ptr, ptr %l271, !tbaa !29
  store ptr %t534, ptr %l269, !tbaa !29
  br label %bb153
bb152:
  %t535 = load i32, ptr %l272, !tbaa !23
  %t536 = lshr i32 %t535, 16
  %t537 = and i32 %t535, 65535
  %t538 = icmp eq i32 %t536, 1
  %t539 = select i1 %t538, i32 1, i32 0
  %t540 = icmp eq i32 %t535, 0
  %t541 = shl i32 %t539, 16
  %t542 = or i32 %t541, %t537
  %t543 = select i1 %t540, i32 0, i32 %t542
  %t545 = insertvalue { i32, ptr } zeroinitializer, i32 %t543, 0
  store { i32, ptr } %t545, ptr %rv
  br label %ret
bb153:
  %t546 = load ptr, ptr %l269, !tbaa !29
  store ptr %t546, ptr %l30, !tbaa !29
  %t547 = load ptr, ptr %l30, !tbaa !29
  %t549 = call i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %t547)
  store i1 %t549, ptr %l275
  br label %bb154
bb154:
  %t550 = load i1, ptr %l275, !tbaa !21
  br i1 %t550, label %bb155, label %bb156
bb155:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t554 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t551, i32 1)
  store i1 %t554, ptr %l279
  br label %bb157
bb156:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb158
bb157:
  %t555 = load i1, ptr %l279, !tbaa !21
  store i1 %t555, ptr %l276, !tbaa !21
  br label %bb158
bb158:
  %t556 = load i1, ptr %l276, !tbaa !21
  br i1 %t556, label %bb159, label %bb160
bb159:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t557)
  store %"compiler/token:Token" %t559, ptr %l282
  br label %bb161
bb160:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb163
bb161:
  %t560 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t561 = load %"compiler/token:Token", ptr %l282
  %t563 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t561, i8 %t560)
  store i1 %t563, ptr %l284
  br label %bb162
bb162:
  %t564 = load i1, ptr %l284, !tbaa !21
  %t565 = xor i1 %t564, true
  store i1 %t565, ptr %l280, !tbaa !21
  br label %bb163
bb163:
  %t567 = load i1, ptr %l280, !tbaa !21
  br i1 %t567, label %bb164, label %bb165
bb164:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t568)
  store i32 %t570, ptr %l287
  br label %bb166
bb165:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/parse:Parser", ptr %t571, i32 0, i32 34
  store ptr %t573, ptr %l343, !tbaa !29
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %l30, !tbaa !29
  %t578 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %t574, ptr %t575, i1 true)
  store ptr %t578, ptr %l346
  br label %bb193
bb166:
  %t579 = load i32, ptr %l287, !tbaa !23
  store i32 %t579, ptr %l31, !tbaa !23
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t582 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t580)
  %t583 = extractvalue { i32, i32 } %t582, 1
  %t584 = extractvalue { i32, i32 } %t582, 0
  store i32 %t584, ptr %l291
  %t585 = icmp ne i32 %t584, 0
  br i1 %t585, label %bb168, label %ok.586
ok.586:
  store i32 %t583, ptr %l290
  br label %bb167
bb167:
  %t587 = load i32, ptr %l290, !tbaa !23
  store i32 %t587, ptr %l288, !tbaa !23
  br label %bb169
bb168:
  %t588 = load i32, ptr %l291, !tbaa !23
  %t589 = lshr i32 %t588, 16
  %t590 = and i32 %t588, 65535
  %t591 = icmp eq i32 %t589, 1
  %t592 = select i1 %t591, i32 1, i32 0
  %t593 = icmp eq i32 %t588, 0
  %t594 = shl i32 %t592, 16
  %t595 = or i32 %t594, %t590
  %t596 = select i1 %t593, i32 0, i32 %t595
  %t598 = insertvalue { i32, ptr } zeroinitializer, i32 %t596, 0
  store { i32, ptr } %t598, ptr %rv
  br label %ret
bb169:
  %t599 = load i32, ptr %l288, !tbaa !23
  store i32 %t599, ptr %l32, !tbaa !23
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/parse:Parser", ptr %t600, i32 0, i32 35
  %t604 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t602)
  store i64 %t604, ptr %l295
  br label %bb170
bb170:
  %t605 = load i64, ptr %l295, !tbaa !24
  store i64 %t605, ptr %l33, !tbaa !24
  store [0 x ptr] zeroinitializer, ptr %l296
  %t606 = mul i64 0, 8
  %t607 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t606)
  %t608 = insertvalue { i64, ptr } undef, i64 0, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  store { i64, ptr } %t609, ptr %l297, !tbaa !27
  %t610 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t611, ptr %l296, i64 %t612, i1 false)
  %t613 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t613, ptr %lp34
  %t614 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t615 = load ptr, ptr %lp34
  store { i64, ptr } %t614, ptr %t615, !tbaa !27
  %t616 = load ptr, ptr %l30, !tbaa !29
  store ptr %t616, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t617 = load ptr, ptr %l298, !tbaa !29
  %t618 = icmp ne ptr %t617, null
  br i1 %t618, label %bb171, label %bb172
bb171:
  %t620 = load ptr, ptr %l298, !tbaa !29
  %t621 = load i64, ptr %t620
  %t623 = icmp eq i64 %t621, 14
  store i1 %t623, ptr %l299, !tbaa !21
  br label %bb172
bb172:
  %t624 = load i1, ptr %l299, !tbaa !21
  br i1 %t624, label %bb173, label %bb174
bb173:
  %t625 = load ptr, ptr %l30, !tbaa !29
  %t627 = getelementptr { i64, [5 x i64] }, ptr %t625, i32 0, i32 1
  %t628 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t627, i32 0, i32 1
  %t629 = load ptr, ptr %t628
  store ptr %t629, ptr %l35, !tbaa !29
  %t631 = load ptr, ptr %l30, !tbaa !29
  %t633 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t633, i32 0, i32 2
  %t635 = load { i64, ptr }, ptr %t634
  store { i64, ptr } %t635, ptr %l36, !tbaa !27
  br label %bb175
bb174:
  br label %bb180
bb175:
  %t637 = load ptr, ptr %l35, !tbaa !29
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/parse:Parser", ptr %t638, i32 0, i32 35
  call void @compiler_2fparse_2epathIds(ptr %v0, ptr %v0, ptr %t637, ptr %t640)
  br label %bb176
bb176:
  %t643 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t643, ptr %l310, !tbaa !27
  %t645 = load ptr, ptr %lp34
  %t646 = load { i64, ptr }, ptr %t645, !tbaa !27
  %t647 = extractvalue { i64, ptr } %t646, 0
  %t648 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 0
  store i64 %t649, ptr %l312, !tbaa !24
  %t651 = load i64, ptr %l312, !tbaa !24
  %t652 = icmp eq i64 %t647, %t651
  br i1 %t652, label %bb177, label %bb178
bb177:
  %t654 = load ptr, ptr %lp34
  %t655 = getelementptr { i64, ptr }, ptr %t654, i32 0, i32 1
  %t656 = load ptr, ptr %t655, !tbaa !27
  %t657 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !27
  %t659 = load i64, ptr %l312, !tbaa !24
  %t660 = mul i64 %t659, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t656, ptr %t658, i64 %t660, i1 false)
  br label %bb179
bb178:
  %t661 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 0
  store i64 %t662, ptr %l314, !tbaa !24
  %t663 = load i64, ptr %l314, !tbaa !24
  %t664 = mul i64 %t663, 8
  %t665 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t664)
  %t666 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  store { i64, ptr } %t667, ptr %l315, !tbaa !27
  %t668 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !27
  %t670 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !27
  %t672 = load i64, ptr %l314, !tbaa !24
  %t673 = mul i64 %t672, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t669, ptr %t671, i64 %t673, i1 false)
  %t674 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t675 = load ptr, ptr %lp34
  store { i64, ptr } %t674, ptr %t675, !tbaa !27
  br label %bb179
bb179:
  br label %bb186
bb180:
  br i1 true, label %bb181, label %bb182
bb181:
  br label %bb183
bb182:
  br label %bb185
bb183:
  %t676 = load ptr, ptr %l30, !tbaa !29
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = getelementptr %"compiler/parse:Parser", ptr %t677, i32 0, i32 35
  call void @compiler_2fparse_2epathIds(ptr %v0, ptr %v0, ptr %t676, ptr %t679)
  br label %bb184
bb184:
  br label %bb186
bb185:
  call void @__olang_check_failed(ptr @olang_loc_caeb78b52908375_adc8a49ae9a90799)
  unreachable
bb186:
  %t682 = load ptr, ptr %l30, !tbaa !29
  %t684 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t682)
  store %"compiler/source:Span" %t684, ptr %l320
  br label %bb187
bb187:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = getelementptr %"compiler/parse:Parser", ptr %t685, i32 0, i32 35
  %t688 = load i64, ptr %l33, !tbaa !24
  %t691 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t687, i64 %t688)
  store { i64, ptr } %t691, ptr %l324
  br label %bb188
bb188:
  %t692 = load ptr, ptr %lp34
  %t693 = load { i64, ptr }, ptr %t692, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t694
  %t695 = getelementptr { i64, [5 x i64] }, ptr %t694, i32 0, i32 0
  store i64 0, ptr %t695
  %t696 = load %"compiler/source:Span", ptr %l320
  %t697 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t696, 0
  %t698 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t699 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t697, { i64, ptr } %t698, 1
  %t701 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t699, { i64, ptr } %t693, 2
  %t702 = getelementptr { i64, [5 x i64] }, ptr %t694, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t701, ptr %t702
  %t703 = load { i64, [5 x i64] }, ptr %t694
  %t704 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t704, ptr %lp37
  %t706 = load ptr, ptr %lp37
  store { i64, [5 x i64] } %t703, ptr %t706
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/parse:Parser", ptr %t707, i32 0, i32 34
  store ptr %t709, ptr %l328, !tbaa !29
  %t710 = load ptr, ptr %l30, !tbaa !29
  %t712 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t710)
  store %"compiler/source:Span" %t712, ptr %l330
  br label %bb189
bb189:
  %t713 = getelementptr %"compiler/source:Span", ptr %l330, i32 0, i32 0
  %t714 = load i32, ptr %t713, !tbaa !23
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t717 = getelementptr %"compiler/parse:Parser", ptr %t715, i32 0, i32 10
  %t718 = load i32, ptr %t717, !tbaa !23
  %t721 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t714, i32 %t718)
  store %"compiler/source:Span" %t721, ptr %l334
  br label %bb190
bb190:
  %t722 = load ptr, ptr %lp37
  store ptr %t722, ptr %l335, !tbaa !29
  %t723 = load i32, ptr %l32, !tbaa !23
  store i32 %t723, ptr %l336, !tbaa !23
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load i32, ptr %l31, !tbaa !23
  %t728 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t724, i32 %t725)
  store %"compiler/source:Span" %t728, ptr %l339
  br label %bb191
bb191:
  store { i64, [4 x i64] } zeroinitializer, ptr %t729
  %t730 = getelementptr { i64, [4 x i64] }, ptr %t729, i32 0, i32 0
  store i64 5, ptr %t730
  %t731 = load %"compiler/source:Span", ptr %l334
  %t732 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } undef, %"compiler/source:Span" %t731, 0
  %t733 = load ptr, ptr %l335, !tbaa !29
  %t734 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t732, ptr %t733, 1
  %t735 = load i32, ptr %l336, !tbaa !23
  %t736 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t734, i32 %t735, 2
  %t737 = load %"compiler/source:Span", ptr %l339
  %t738 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t736, %"compiler/source:Span" %t737, 3
  %t739 = getelementptr { i64, [4 x i64] }, ptr %t729, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t738, ptr %t739
  %t740 = load { i64, [4 x i64] }, ptr %t729
  %t742 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t740, ptr %t742
  %t743 = load ptr, ptr %l328, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t743, ptr %t742)
  br label %bb192
bb192:
  br label %bb195
bb193:
  %t745 = load ptr, ptr %l343, !tbaa !29
  %t746 = load ptr, ptr %l346, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t745, ptr %t746)
  br label %bb194
bb194:
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t750 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t747, i32 57)
  store i1 %t750, ptr %l349
  br label %bb197
bb197:
  %t751 = load i1, ptr %l349, !tbaa !21
  br i1 %t751, label %bb198, label %bb199
bb198:
  br label %bb228
bb199:
  br label %bb200
bb200:
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t755 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t752, i32 8)
  store i1 %t755, ptr %l352
  br label %bb201
bb201:
  %t756 = load i1, ptr %l352, !tbaa !21
  %t757 = xor i1 %t756, true
  br i1 %t757, label %bb202, label %bb203
bb202:
  br label %bb229
bb203:
  br label %bb204
bb204:
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t759, i64 1)
  store i32 %t761, ptr %l355
  br label %bb205
bb205:
  %t762 = load i32, ptr %l355
  store i32 %t762, ptr %l38
  %t763 = load i32, ptr %l38
  %t765 = trunc i64 94 to i32
  %t766 = icmp eq i32 %t763, %t765
  br i1 %t766, label %bb206, label %bb207
bb206:
  store i1 true, ptr %l358, !tbaa !21
  br label %bb208
bb207:
  %t768 = load i32, ptr %l38
  %t770 = trunc i64 76 to i32
  %t771 = icmp eq i32 %t768, %t770
  store i1 %t771, ptr %l358, !tbaa !21
  br label %bb208
bb208:
  %t773 = load i1, ptr %l358, !tbaa !21
  br i1 %t773, label %bb209, label %bb210
bb209:
  store i1 true, ptr %l361, !tbaa !21
  br label %bb211
bb210:
  %t774 = load i32, ptr %l38
  %t776 = trunc i64 9 to i32
  %t777 = icmp eq i32 %t774, %t776
  store i1 %t777, ptr %l361, !tbaa !21
  br label %bb211
bb211:
  %t779 = load i1, ptr %l361, !tbaa !21
  br i1 %t779, label %bb212, label %bb213
bb212:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb214
bb213:
  %t780 = load i32, ptr %l38
  %t782 = trunc i64 95 to i32
  %t783 = icmp eq i32 %t780, %t782
  store i1 %t783, ptr %l364, !tbaa !21
  br label %bb214
bb214:
  %t785 = load i1, ptr %l364, !tbaa !21
  br i1 %t785, label %bb215, label %bb216
bb215:
  store i1 true, ptr %l367, !tbaa !21
  br label %bb217
bb216:
  %t786 = load i32, ptr %l38
  %t788 = trunc i64 32 to i32
  %t789 = icmp eq i32 %t786, %t788
  store i1 %t789, ptr %l367, !tbaa !21
  br label %bb217
bb217:
  %t791 = load i1, ptr %l367, !tbaa !21
  br i1 %t791, label %bb218, label %bb219
bb218:
  store i1 true, ptr %l370, !tbaa !21
  br label %bb220
bb219:
  %t792 = load i32, ptr %l38
  %t794 = trunc i64 33 to i32
  %t795 = icmp eq i32 %t792, %t794
  store i1 %t795, ptr %l370, !tbaa !21
  br label %bb220
bb220:
  %t797 = load i1, ptr %l370, !tbaa !21
  br i1 %t797, label %bb221, label %bb222
bb221:
  store i1 true, ptr %l373, !tbaa !21
  br label %bb223
bb222:
  %t798 = load i32, ptr %l38
  %t800 = trunc i64 0 to i32
  %t801 = icmp eq i32 %t798, %t800
  store i1 %t801, ptr %l373, !tbaa !21
  br label %bb223
bb223:
  %t803 = load i1, ptr %l373, !tbaa !21
  br i1 %t803, label %bb224, label %bb225
bb224:
  br label %bb229
bb225:
  br label %bb226
bb226:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t806 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t804)
  store i32 %t806, ptr %l377
  br label %bb227
bb227:
  br label %bb228
bb228:
  br label %bb144
bb229:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t809 = getelementptr %"compiler/parse:Parser", ptr %t807, i32 0, i32 34
  %t810 = load i64, ptr %l28, !tbaa !24
  %t813 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t809, i64 %t810)
  store { i64, ptr } %t813, ptr %l381
  br label %bb230
bb230:
  %t814 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t814, ptr %l39, !tbaa !27
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/parse:Parser", ptr %t815, i32 0, i32 32
  %t818 = load i64, ptr %l29, !tbaa !24
  %t821 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t817, i64 %t818)
  store { i64, ptr } %t821, ptr %l385
  br label %bb231
bb231:
  %t822 = load { i64, ptr }, ptr %l385, !tbaa !27
  store { i64, ptr } %t822, ptr %l40, !tbaa !27
  store ptr null, ptr %l41, !tbaa !29
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t826 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t823, i32 9)
  store i1 %t826, ptr %l388
  br label %bb232
bb232:
  %t827 = load i1, ptr %l388, !tbaa !21
  br i1 %t827, label %bb233, label %bb234
bb233:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t828)
  %t831 = extractvalue { i32, ptr } %t830, 1
  %t832 = extractvalue { i32, ptr } %t830, 0
  store i32 %t832, ptr %l392
  %t833 = icmp ne i32 %t832, 0
  br i1 %t833, label %bb236, label %ok.834
ok.834:
  store ptr %t831, ptr %l391
  br label %bb235
bb234:
  br label %bb238
bb235:
  %t835 = load ptr, ptr %l391, !tbaa !29
  store ptr %t835, ptr %l389, !tbaa !29
  br label %bb237
bb236:
  %t836 = load i32, ptr %l392, !tbaa !23
  %t837 = lshr i32 %t836, 16
  %t838 = and i32 %t836, 65535
  %t839 = icmp eq i32 %t837, 1
  %t840 = select i1 %t839, i32 1, i32 0
  %t841 = icmp eq i32 %t836, 0
  %t842 = shl i32 %t840, 16
  %t843 = or i32 %t842, %t838
  %t844 = select i1 %t841, i32 0, i32 %t843
  %t846 = insertvalue { i32, ptr } zeroinitializer, i32 %t844, 0
  store { i32, ptr } %t846, ptr %rv
  br label %ret
bb237:
  %t847 = load ptr, ptr %l389, !tbaa !29
  store ptr %t847, ptr %l41, !tbaa !29
  br label %bb238
bb238:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t851 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %t849)
  %t852 = extractvalue { i32, { { i64, ptr }, ptr } } %t851, 1
  %t853 = extractvalue { i32, { { i64, ptr }, ptr } } %t851, 0
  store i32 %t853, ptr %l398
  %t854 = icmp ne i32 %t853, 0
  br i1 %t854, label %bb240, label %ok.855
ok.855:
  store { { i64, ptr }, ptr } %t852, ptr %l397
  br label %bb239
bb239:
  %t856 = load { { i64, ptr }, ptr }, ptr %l397
  store { { i64, ptr }, ptr } %t856, ptr %l395
  br label %bb241
bb240:
  %t857 = load i32, ptr %l398, !tbaa !23
  %t858 = lshr i32 %t857, 16
  %t859 = and i32 %t857, 65535
  %t860 = icmp eq i32 %t858, 1
  %t861 = select i1 %t860, i32 1, i32 0
  %t862 = icmp eq i32 %t857, 0
  %t863 = shl i32 %t861, 16
  %t864 = or i32 %t863, %t859
  %t865 = select i1 %t862, i32 0, i32 %t864
  %t867 = insertvalue { i32, ptr } zeroinitializer, i32 %t865, 0
  store { i32, ptr } %t867, ptr %rv
  br label %ret
bb241:
  %t868 = load { { i64, ptr }, ptr }, ptr %l395
  store { { i64, ptr }, ptr } %t868, ptr %l42
  %t869 = getelementptr { { i64, ptr }, ptr }, ptr %l42, i32 0, i32 0
  %t870 = load { i64, ptr }, ptr %t869, !tbaa !27
  store { i64, ptr } %t870, ptr %l43, !tbaa !27
  %t872 = getelementptr { { i64, ptr }, ptr }, ptr %l42, i32 0, i32 1
  %t873 = load ptr, ptr %t872, !tbaa !29
  store ptr %t873, ptr %l44, !tbaa !29
  %t875 = load ptr, ptr %l22, !tbaa !29
  store ptr %t875, ptr %l402, !tbaa !29
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load i32, ptr %l24, !tbaa !23
  %t880 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t876, i32 %t877)
  store %"compiler/source:Span" %t880, ptr %l405
  br label %bb242
bb242:
  %t881 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t882 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t883 = load ptr, ptr %l41, !tbaa !29
  %t884 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t885 = load ptr, ptr %l44, !tbaa !29
  %t886 = load %"compiler/source:Span", ptr %l405
  %t892 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t886, { i64, ptr } %t881, { i64, ptr } %t882, ptr %t883, { i64, ptr } %t884, ptr %t885)
  store %"compiler/ast:Case" %t892, ptr %l411
  br label %bb243
bb243:
  %t893 = load %"compiler/ast:Case", ptr %l411
  %t894 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/ast:Case" %t893, ptr %t894
  %t895 = load ptr, ptr %l402, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v0, ptr %t895, ptr %t894)
  br label %bb244
bb244:
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t900 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t897, i32 8)
  store i1 %t900, ptr %l415
  br label %bb245
bb245:
  %t901 = load i1, ptr %l415, !tbaa !21
  br i1 %t901, label %bb246, label %bb247
bb246:
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t904 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t902)
  store i32 %t904, ptr %l417
  br label %bb248
bb247:
  br label %bb249
bb248:
  br label %bb249
bb249:
  br label %bb250
bb250:
  br label %bb106
bb251:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t908 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t905, i32 95)
  %t909 = extractvalue { i32, i32 } %t908, 1
  %t910 = extractvalue { i32, i32 } %t908, 0
  store i32 %t910, ptr %l422
  %t911 = icmp ne i32 %t910, 0
  br i1 %t911, label %bb253, label %ok.912
ok.912:
  store i32 %t909, ptr %l421
  br label %bb252
bb252:
  %t913 = load i32, ptr %l421, !tbaa !23
  store i32 %t913, ptr %l418, !tbaa !23
  br label %bb254
bb253:
  %t914 = load i32, ptr %l422, !tbaa !23
  %t915 = lshr i32 %t914, 16
  %t916 = and i32 %t914, 65535
  %t917 = icmp eq i32 %t915, 1
  %t918 = select i1 %t917, i32 1, i32 0
  %t919 = icmp eq i32 %t914, 0
  %t920 = shl i32 %t918, 16
  %t921 = or i32 %t920, %t916
  %t922 = select i1 %t919, i32 0, i32 %t921
  %t924 = insertvalue { i32, ptr } zeroinitializer, i32 %t922, 0
  store { i32, ptr } %t924, ptr %rv
  br label %ret
bb254:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load i64, ptr %l20, !tbaa !24
  %t929 = getelementptr %"compiler/parse:Parser", ptr %t925, i32 0, i32 17
  store i64 %t926, ptr %t929, !tbaa !24
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t931 = load i1, ptr %l21, !tbaa !21
  %t934 = getelementptr %"compiler/parse:Parser", ptr %t930, i32 0, i32 18
  store i1 %t931, ptr %t934, !tbaa !21
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t936 = load i32, ptr %l1, !tbaa !23
  %t939 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t935, i32 %t936)
  store %"compiler/source:Span" %t939, ptr %l430
  br label %bb255
bb255:
  %t940 = load ptr, ptr %l19, !tbaa !29
  store ptr %t940, ptr %l431, !tbaa !29
  %t941 = load i1, ptr %l2, !tbaa !21
  store i1 %t941, ptr %l432, !tbaa !21
  %t942 = load ptr, ptr %l22, !tbaa !29
  %t944 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v0, ptr %t942)
  store { i64, ptr } %t944, ptr %l434
  br label %bb256
bb256:
  %t945 = load ptr, ptr %l23, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l430
  %t947 = load ptr, ptr %l431, !tbaa !29
  %t948 = load i1, ptr %l432, !tbaa !21
  %t949 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t951 = call %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t946, ptr %t947, i1 %t948, { i64, ptr } %t949, ptr %t945)
  store %"compiler/ast:Match" %t951, ptr %l436
  br label %bb257
bb257:
  %t952 = load %"compiler/ast:Match", ptr %l436
  %t953 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:Match" %t952, ptr %t953
  %t955 = insertvalue { i32, ptr } zeroinitializer, ptr %t953, 1
  store { i32, ptr } %t955, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t1, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/source:Source", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t25 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = sub i32 %t26, %t28
  %t33 = sext i32 %t31 to i64
  %t37 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t20, i64 %t24, i64 %t33)
  store i32 %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load i32, ptr %l18
  store i32 %t38, ptr %l2
  %t39 = load i32, ptr %l2
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i32, ptr %l2
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t57 = load i32, ptr %l2
  %t59 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t57)
  store i1 %t59, ptr %l29
  br label %bb15
bb15:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t61, i64 2)
  store i32 %t63, ptr %l32
  br label %bb18
bb18:
  %t64 = load i32, ptr %l32
  %t66 = trunc i64 90 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l30, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca %"compiler/token:Token"
  %l13 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3
  %t6 = trunc i64 1 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t11, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t13, ptr %l8
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb5, label %ok.15
ok.15:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s1)
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 0
  store { i32, i32 } %t26, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t27)
  store %"compiler/token:Token" %t29, ptr %l11
  br label %bb8
bb8:
  %t30 = load %"compiler/token:Token", ptr %l11
  store %"compiler/token:Token" %t30, ptr %l1
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l13
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l15, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/token:Token", ptr %l1
  %t42 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t38, %"compiler/token:Token" %t39)
  store { i64, ptr } %t42, ptr %l18
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t45 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  store i32 %t45, ptr %l19
  br label %bb11
bb11:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = insertvalue { i32, i32 } zeroinitializer, i32 %t46, 1
  store { i32, i32 } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2
  %t9 = trunc i64 8 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 0 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/scan:Tokens", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/token:Token", ptr %t60, i64 %t57
  %t62 = load %"compiler/token:Token", ptr %t61
  %t65 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t49, %"compiler/token:Token" %t62)
  store { i64, ptr } %t65, ptr %l22
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t66)
  store { i64, ptr } %t67, ptr %l23
  br label %bb9
bb9:
  %t68 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %l59 = alloca %"compiler/parse:NameList"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t34 = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l17, !tbaa !24
  store %"compiler/source:Span" zeroinitializer, ptr %l18
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb5:
  %t22 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t22, ptr %l20
  br label %bb7
bb6:
  %t23 = load i64, ptr %l17, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  %t26 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t26, ptr %l18
  br label %bb6
bb8:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sle i64 %t27, 1152921504606846975
  br i1 %t28, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb10:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = load %"compiler/source:Span", ptr %l18
  store i64 0, ptr %t34
  br label %fill.35
fill.35:
  %t38 = load i64, ptr %t34
  %t39 = icmp slt i64 %t38, %t30
  br i1 %t39, label %fillb.36, label %filld.37
fillb.36:
  %t40 = getelementptr %"compiler/source:Span", ptr %t32, i64 %t38
  store %"compiler/source:Span" %t33, ptr %t40
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %t34
  br label %fill.35
filld.37:
  %t42 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t32, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb12:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb28
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l5, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb16, label %bb17
bb16:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32 }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l9
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l10, !tbaa !23
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l43, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t91
  store i32 %t92, ptr %t97, !tbaa !33
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load %"compiler/source:Span", ptr %l9
  %t103 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i64 %t99
  store %"compiler/source:Span" %t100, ptr %t105
  br label %bb26
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a0, ptr %l49, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 60)
  store { i64, ptr } %t108, ptr %l51
  br label %bb22
bb22:
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t118 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } %t115)
  store i32 %t118, ptr %l53
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb24, label %ok.120
ok.120:
  br label %bb23
bb23:
  br label %bb25
bb24:
  %t121 = load i32, ptr %l53, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  call void @__olang_scope_close(ptr %s4)
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l5, !tbaa !24
  br label %bb12
bb28:
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t136, { i64, ptr } %t137)
  store %"compiler/parse:NameList" %t140, ptr %l59
  br label %bb29
bb29:
  %t141 = load %"compiler/parse:NameList", ptr %l59
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/parse:NameList" %t141, ptr %t142
  %t144 = insertvalue { i32, ptr } zeroinitializer, ptr %t142, 1
  store { i32, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 79)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l5
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/parse:Parser", ptr %t20, i32 0, i32 40
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 6
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t22, i64 %t28)
  br label %bb4
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlives(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/token:Token"
  %l5 = alloca %"compiler/token:Token"
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/token:Token"
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i1
  %l50 = alloca i32
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/ast:Outlives"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %t7
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %t11
  store ptr %t11, ptr %l3, !tbaa !29
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t13)
  store %"compiler/token:Token" %t15, ptr %l13
  br label %bb5
bb5:
  %t16 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t16, ptr %l4
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t17, i32 13)
  store i1 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t22, i32 0)
  br label %bb9
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t25)
  %t28 = extractvalue { i32, i32 } %t27, 1
  %t29 = extractvalue { i32, i32 } %t27, 0
  store i32 %t29, ptr %l22
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb11, label %ok.31
ok.31:
  store i32 %t28, ptr %l21
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t32 = load i32, ptr %l21, !tbaa !23
  store i32 %t32, ptr %l19, !tbaa !23
  br label %bb12
bb11:
  %t33 = load i32, ptr %l22, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  call void @__olang_scope_close(ptr %s1)
  %t43 = insertvalue { i32, ptr } zeroinitializer, i32 %t41, 0
  store { i32, ptr } %t43, ptr %rv
  br label %ret
bb12:
  %t44 = load ptr, ptr %l18, !tbaa !29
  %t45 = load i32, ptr %l19, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t44, i32 %t45)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l3, !tbaa !29
  store ptr %t46, ptr %l24, !tbaa !29
  %t47 = getelementptr %"compiler/token:Token", ptr %l4, i32 0, i32 2
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 10
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t48, i32 %t52)
  store %"compiler/source:Span" %t55, ptr %l28
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l24, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t56, %"compiler/source:Span" %t57)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t58)
  store %"compiler/token:Token" %t60, ptr %l30
  br label %bb17
bb17:
  %t61 = load %"compiler/token:Token", ptr %l30
  store %"compiler/token:Token" %t61, ptr %l5
  %t62 = getelementptr %"compiler/token:Token", ptr %l5, i32 0, i32 0
  %t63 = load i32, ptr %t62
  %t65 = trunc i64 1 to i32
  %t66 = icmp eq i32 %t63, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb27
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/source:Source", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l37, !tbaa !27
  %t77 = getelementptr %"compiler/token:Token", ptr %l5, i32 0, i32 2
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  store i64 %t80, ptr %l39, !tbaa !24
  %t81 = getelementptr %"compiler/token:Token", ptr %l5, i32 0, i32 3
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  store i64 %t84, ptr %l41, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d545a7a4444f1737_b05c101f80cf2a13)
  unreachable
bb22:
  %t94 = load i64, ptr %l41, !tbaa !24
  %t95 = load i64, ptr %l42, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d545a7a4444f1737_b05c101f80cf2a13)
  unreachable
bb24:
  %t98 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l39, !tbaa !24
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t105, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t107, ptr %l47
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d545a7a4444f1737_b05c101f80cf2a13)
  unreachable
bb26:
  %t108 = load i1, ptr %l47, !tbaa !21
  %t109 = xor i1 %t108, true
  store i1 %t109, ptr %l34, !tbaa !21
  br label %bb27
bb27:
  %t111 = load i1, ptr %l34, !tbaa !21
  br i1 %t111, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l50
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb32:
  br label %bb4
bb33:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t115, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l53
  br label %bb34
bb34:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v0, ptr %t120)
  store { i64, ptr } %t122, ptr %l55
  br label %bb35
bb35:
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t125 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v0, ptr %t123)
  store { i64, ptr } %t125, ptr %l57
  br label %bb36
bb36:
  %t126 = load %"compiler/source:Span", ptr %l53
  %t127 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t129 = call %"compiler/ast:Outlives" @compiler_2fast_3aOutlives_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t126, { i64, ptr } %t127, { i64, ptr } %t128)
  store %"compiler/ast:Outlives" %t129, ptr %l58
  br label %bb37
bb37:
  %t130 = load %"compiler/ast:Outlives", ptr %l58
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/ast:Outlives" %t130, ptr %t131
  %t133 = insertvalue { i32, ptr } zeroinitializer, ptr %t131, 1
  store { i32, ptr } %t133, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoutlivesHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l13 = alloca %"compiler/token:Token"
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 1)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t8, i32 13)
  store i1 %t11, ptr %l9
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i1, ptr %l9, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t17, i64 1)
  store %"compiler/token:Token" %t19, ptr %l13
  br label %bb9
bb9:
  %t20 = load %"compiler/token:Token", ptr %l13
  store %"compiler/token:Token" %t20, ptr %l1
  %t21 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/parse:Parser", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l19, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = sext i32 %t39 to i64
  store i64 %t41, ptr %l23, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb19
bb12:
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_913e5c935a5c1029_775f299487b9a2f5)
  unreachable
bb14:
  %t51 = load i64, ptr %l23, !tbaa !24
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_913e5c935a5c1029_775f299487b9a2f5)
  unreachable
bb16:
  %t55 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l21, !tbaa !24
  %t58 = load i64, ptr %l23, !tbaa !24
  %t59 = getelementptr i8, ptr %t56, i64 %t57
  %t60 = sub i64 %t58, %t57
  %t61 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t64, ptr %l29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_913e5c935a5c1029_775f299487b9a2f5)
  unreachable
bb18:
  %t65 = load i1, ptr %l29, !tbaa !21
  store i1 %t65, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l16, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/ast:Param"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store i32 %t8, ptr %l10
  br label %bb2
bb2:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l8, !tbaa !23
  br label %bb4
bb3:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l8, !tbaa !23
  store i32 %t24, ptr %l3, !tbaa !23
  store ptr null, ptr %l4, !tbaa !29
  br i1 %a1, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t27, i32 57)
  store i1 %t30, ptr %l17
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb16
bb7:
  %t31 = load i1, ptr %l17, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t32, i32 91)
  store i1 %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l21, !tbaa !21
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t38, i32 8)
  store i1 %t41, ptr %l25
  br label %bb14
bb14:
  %t42 = load i1, ptr %l25, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %l14, !tbaa !21
  br label %bb16
bb16:
  %t44 = load i1, ptr %l14, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l30
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb20, label %ok.53
ok.53:
  store ptr %t50, ptr %l29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t54 = load ptr, ptr %l29, !tbaa !29
  store ptr %t54, ptr %l27, !tbaa !29
  br label %bb21
bb20:
  %t55 = load i32, ptr %l30, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, ptr } zeroinitializer, i32 %t63, 0
  store { i32, ptr } %t65, ptr %rv
  br label %ret
bb21:
  %t66 = load ptr, ptr %l27, !tbaa !29
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb22
bb22:
  store ptr null, ptr %l5, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t68, i32 60)
  store i1 %t71, ptr %l35
  br label %bb23
bb23:
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t73)
  %t76 = extractvalue { i32, ptr } %t75, 1
  %t77 = extractvalue { i32, ptr } %t75, 0
  store i32 %t77, ptr %l39
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb27, label %ok.79
ok.79:
  store ptr %t76, ptr %l38
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t80 = load ptr, ptr %l38, !tbaa !29
  store ptr %t80, ptr %l36, !tbaa !29
  br label %bb28
bb27:
  %t81 = load i32, ptr %l39, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  %t91 = insertvalue { i32, ptr } zeroinitializer, i32 %t89, 0
  store { i32, ptr } %t91, ptr %rv
  br label %ret
bb28:
  %t92 = load ptr, ptr %l36, !tbaa !29
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t94, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l44
  br label %bb30
bb30:
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l44
  %t106 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t102, i32 %t99, ptr %t100, ptr %t101)
  store %"compiler/ast:Param" %t106, ptr %l48
  br label %bb31
bb31:
  %t107 = load %"compiler/ast:Param", ptr %l48
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t107, ptr %t108
  %t110 = insertvalue { i32, ptr } zeroinitializer, ptr %t108, 1
  store { i32, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/ast:Path"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 35
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 35
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t14)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20
ok.20:
  store i32 %t17, ptr %l13
  br label %bb3
bb3:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  br label %bb5
bb4:
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb5:
  %t33 = load ptr, ptr %l10, !tbaa !29
  %t34 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t33, i32 %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t35, i32 58)
  store i1 %t38, ptr %l18
  br label %bb8
bb8:
  %t39 = load i1, ptr %l18, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l21
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/parse:Parser", ptr %t45, i32 0, i32 35
  store ptr %t47, ptr %l23, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, i32 } %t50, 1
  %t52 = extractvalue { i32, i32 } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54
ok.54:
  store i32 %t51, ptr %l26
  br label %bb13
bb13:
  %t55 = load i32, ptr %l26, !tbaa !23
  store i32 %t55, ptr %l24, !tbaa !23
  br label %bb15
bb14:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb15:
  %t67 = load ptr, ptr %l23, !tbaa !29
  %t68 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t67, i32 %t68)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb7
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/parse:Parser", ptr %t69, i32 0, i32 35
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l32
  br label %bb19
bb19:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l35
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t83 = load %"compiler/source:Span", ptr %l35
  %t85 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t83, { i64, ptr } %t82)
  store %"compiler/ast:Path" %t85, ptr %l37
  br label %bb21
bb21:
  %t86 = load %"compiler/ast:Path", ptr %l37
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:Path" %t86, ptr %t87
  %t89 = insertvalue { i32, ptr } zeroinitializer, ptr %t87, 1
  store { i32, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 7
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/scan:Tokens", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t23, i64 %t27)
  store i64 %t30, ptr %l13
  br label %bb4
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i64 %t31
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 %t14, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %t17)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l8
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23
ok.23:
  store ptr %t20, ptr %l7
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l7, !tbaa !29
  store ptr %t24, ptr %l5, !tbaa !29
  br label %bb7
bb5:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  store i32 %t33, ptr %l9, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t34)
  br label %bb6
bb6:
  %t36 = load i32, ptr %l9, !tbaa !23
  %t37 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t37, ptr %rv
  br label %ret
bb7:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %t39, ptr %t38)
  %t44 = extractvalue { i32, ptr } %t43, 1
  %t45 = extractvalue { i32, ptr } %t43, 0
  store i32 %t45, ptr %l15
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47
ok.47:
  store ptr %t44, ptr %l14
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l14, !tbaa !29
  store ptr %t48, ptr %l11, !tbaa !29
  br label %bb11
bb9:
  %t49 = load i32, ptr %l15, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %l16, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t58)
  br label %bb10
bb10:
  %t60 = load i32, ptr %l16, !tbaa !23
  %t61 = insertvalue { i32, ptr } zeroinitializer, i32 %t60, 0
  store { i32, ptr } %t61, ptr %rv
  br label %ret
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t62)
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l11, !tbaa !29
  %t65 = insertvalue { i32, ptr } zeroinitializer, ptr %t64, 1
  store { i32, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l14 = alloca %"compiler/token:Token"
  %l15 = alloca %"compiler/token:Token"
  %l16 = alloca %"compiler/token:Token"
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l36 = alloca i1
  %l40 = alloca i32
  %l41 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca %"compiler/source:Span"
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i1
  %l82 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l102 = alloca %"compiler/source:Span"
  %l108 = alloca i1
  %l109 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca i32
  %l118 = alloca %"compiler/token:Token"
  %l119 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca %"compiler/msgs:Msg"
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l146 = alloca %"compiler/source:Span"
  %l158 = alloca i32
  %l160 = alloca i32
  %l163 = alloca %"compiler/source:Span"
  %l171 = alloca i32
  %l172 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i32
  %l179 = alloca %"compiler/source:Span"
  %l192 = alloca i32
  %l194 = alloca i1
  %l195 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i32
  %l206 = alloca i1
  %l209 = alloca i1
  %l210 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca i32
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca i32
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca i32
  %l227 = alloca %"compiler/token:Token"
  %l229 = alloca %"compiler/token:Token"
  %l231 = alloca %"compiler/token:Token"
  %l234 = alloca i1
  %l235 = alloca i1
  %l239 = alloca i1
  %l243 = alloca i1
  %l246 = alloca i1
  %l247 = alloca i1
  %l251 = alloca i1
  %l254 = alloca i1
  %l257 = alloca i32
  %l259 = alloca i32
  %l261 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l265 = alloca i32
  %l266 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i32
  %l273 = alloca %"compiler/source:Span"
  %s10 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t84 = alloca { i64, [5 x i64] }, align 8
  %t140 = alloca { i64, [5 x i64] }, align 8
  %t234 = alloca { i64, [5 x i64] }, align 8
  %t307 = alloca { i64, [5 x i64] }, align 8
  %t352 = alloca { i64, [5 x i64] }, align 8
  %t394 = alloca { i64, [5 x i64] }, align 8
  %t442 = alloca { i64, [5 x i64] }, align 8
  %t670 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l24
  br label %bb3
bb3:
  %t12 = load i32, ptr %l24
  store i32 %t12, ptr %l4
  %t13 = load i32, ptr %l4
  %t15 = trunc i64 92 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t22 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %t18, ptr %t19)
  %t23 = extractvalue { i32, ptr } %t22, 1
  %t24 = extractvalue { i32, ptr } %t22, 0
  store i32 %t24, ptr %l31
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb8, label %ok.26
ok.26:
  store ptr %t23, ptr %l30
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l30, !tbaa !29
  store ptr %t27, ptr %l27, !tbaa !29
  br label %bb9
bb8:
  %t28 = load i32, ptr %l31, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  %t38 = insertvalue { i32, ptr } zeroinitializer, i32 %t36, 0
  store { i32, ptr } %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l27, !tbaa !29
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb171
bb10:
  %t40 = load i32, ptr %l4
  %t42 = trunc i64 58 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb77
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l36
  br label %bb14
bb14:
  %t48 = load i1, ptr %l36, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = insertvalue { i32, ptr } zeroinitializer, ptr %t51, 1
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l40
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t57)
  %t60 = extractvalue { i32, i32 } %t59, 1
  %t61 = extractvalue { i32, i32 } %t59, 0
  store i32 %t61, ptr %l44
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb20, label %ok.63
ok.63:
  store i32 %t60, ptr %l43
  br label %bb19
bb19:
  %t64 = load i32, ptr %l43, !tbaa !23
  store i32 %t64, ptr %l41, !tbaa !23
  br label %bb21
bb20:
  %t65 = load i32, ptr %l44, !tbaa !23
  %t66 = lshr i32 %t65, 16
  %t67 = and i32 %t65, 65535
  %t68 = icmp eq i32 %t66, 1
  %t69 = select i1 %t68, i32 1, i32 0
  %t70 = icmp eq i32 %t65, 0
  %t71 = shl i32 %t69, 16
  %t72 = or i32 %t71, %t67
  %t73 = select i1 %t70, i32 0, i32 %t72
  %t75 = insertvalue { i32, ptr } zeroinitializer, i32 %t73, 0
  store { i32, ptr } %t75, ptr %rv
  br label %ret
bb21:
  %t76 = load i32, ptr %l41, !tbaa !23
  store i32 %t76, ptr %l5, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t77, i32 %t78)
  store %"compiler/source:Span" %t81, ptr %l48
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l5, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 0
  store i64 15, ptr %t85
  %t86 = load %"compiler/source:Span", ptr %l48
  %t87 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t86, 0
  %t89 = insertvalue { %"compiler/source:Span", ptr, i32 } %t87, ptr %t82, 1
  %t91 = insertvalue { %"compiler/source:Span", ptr, i32 } %t89, i32 %t83, 2
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t91, ptr %t92
  %t93 = load { i64, [5 x i64] }, ptr %t84
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t93, ptr %t95
  store ptr %t95, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t97, i32 79)
  store i1 %t100, ptr %l55
  br label %bb23
bb23:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t106 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v0, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l59
  br label %bb26
bb25:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb27
bb26:
  %t107 = load i1, ptr %l59, !tbaa !21
  store i1 %t107, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t109)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l63
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb31, label %ok.115
ok.115:
  store { i64, ptr } %t112, ptr %l62
  br label %bb30
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t119 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t116, i32 79)
  store i1 %t119, ptr %l81
  br label %bb37
bb30:
  %t120 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t120, ptr %l60, !tbaa !27
  br label %bb32
bb31:
  %t121 = load i32, ptr %l63, !tbaa !23
  %t122 = lshr i32 %t121, 16
  %t123 = and i32 %t121, 65535
  %t124 = icmp eq i32 %t122, 1
  %t125 = select i1 %t124, i32 1, i32 0
  %t126 = icmp eq i32 %t121, 0
  %t127 = shl i32 %t125, 16
  %t128 = or i32 %t127, %t123
  %t129 = select i1 %t126, i32 0, i32 %t128
  %t131 = insertvalue { i32, ptr } zeroinitializer, i32 %t129, 0
  store { i32, ptr } %t131, ptr %rv
  br label %ret
bb32:
  %t132 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t132, ptr %l6, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l3, !tbaa !23
  %t137 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t133, i32 %t134)
  store %"compiler/source:Span" %t137, ptr %l67
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 0
  store i64 14, ptr %t141
  %t142 = load %"compiler/source:Span", ptr %l67
  %t143 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t142, 0
  %t145 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t143, ptr %t138, 1
  %t147 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t145, { i64, ptr } %t139, 2
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t140
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l3, !tbaa !23
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t159 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %t153, i32 %t154, ptr %t155)
  %t160 = extractvalue { i32, ptr } %t159, 1
  %t161 = extractvalue { i32, ptr } %t159, 0
  store i32 %t161, ptr %l77
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb35, label %ok.163
ok.163:
  store ptr %t160, ptr %l76
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l76, !tbaa !29
  store ptr %t164, ptr %l72, !tbaa !29
  br label %bb36
bb35:
  %t165 = load i32, ptr %l77, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t173, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb36:
  %t176 = load ptr, ptr %l72, !tbaa !29
  store ptr %t176, ptr %l2, !tbaa !29
  br label %bb76
bb37:
  %t177 = load i1, ptr %l81, !tbaa !21
  br i1 %t177, label %bb38, label %bb39
bb38:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t178)
  store i1 %t180, ptr %l84
  br label %bb40
bb39:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  %t181 = load i1, ptr %l84, !tbaa !21
  store i1 %t181, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t182 = load i1, ptr %l82, !tbaa !21
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t183, i32 0, i32 3
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/parse:Oracle", ptr %t186, i32 0, i32 3
  store ptr %t188, ptr %l88, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  store ptr %t192, ptr %l90, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t193)
  store %"compiler/source:Span" %t195, ptr %l92
  br label %bb44
bb43:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb44:
  %t196 = load ptr, ptr %l90, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l92
  %t198 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t196, %"compiler/source:Span" %t197)
  store { i64, ptr } %t198, ptr %l93
  br label %bb45
bb45:
  %t199 = load ptr, ptr %l88, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t201 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t199, { i64, ptr } %t200)
  store i1 %t201, ptr %l94
  br label %bb46
bb46:
  %t202 = load i1, ptr %l94, !tbaa !21
  store i1 %t202, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t203 = load i1, ptr %l85, !tbaa !21
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t204)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l98
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb51, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l97
  br label %bb50
bb49:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %t211, i64 0)
  store i1 %t213, ptr %l108
  br label %bb54
bb50:
  %t214 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t214, ptr %l95, !tbaa !27
  br label %bb52
bb51:
  %t215 = load i32, ptr %l98, !tbaa !23
  %t216 = lshr i32 %t215, 16
  %t217 = and i32 %t215, 65535
  %t218 = icmp eq i32 %t216, 1
  %t219 = select i1 %t218, i32 1, i32 0
  %t220 = icmp eq i32 %t215, 0
  %t221 = shl i32 %t219, 16
  %t222 = or i32 %t221, %t217
  %t223 = select i1 %t220, i32 0, i32 %t222
  %t225 = insertvalue { i32, ptr } zeroinitializer, i32 %t223, 0
  store { i32, ptr } %t225, ptr %rv
  br label %ret
bb52:
  %t226 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t226, ptr %l7, !tbaa !27
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l3, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t227, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l102
  br label %bb53
bb53:
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 0
  store i64 14, ptr %t235
  %t236 = load %"compiler/source:Span", ptr %l102
  %t237 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t236, 0
  %t239 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t237, ptr %t232, 1
  %t241 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t239, { i64, ptr } %t233, 2
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t241, ptr %t242
  %t243 = load { i64, [5 x i64] }, ptr %t234
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t243, ptr %t245
  store ptr %t245, ptr %l2, !tbaa !29
  br label %bb75
bb54:
  %t247 = load i1, ptr %l108, !tbaa !21
  br i1 %t247, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb58
bb56:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t248, i64 0)
  store i1 %t250, ptr %l111
  br label %bb57
bb57:
  %t251 = load i1, ptr %l111, !tbaa !21
  store i1 %t251, ptr %l109, !tbaa !21
  br label %bb58
bb58:
  %t252 = load i1, ptr %l109, !tbaa !21
  br i1 %t252, label %bb59, label %bb60
bb59:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t253, i64 0)
  store i1 %t255, ptr %l113
  br label %bb61
bb60:
  br label %bb74
bb61:
  %t256 = load i1, ptr %l113, !tbaa !21
  br i1 %t256, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l114, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t258)
  store i32 %t260, ptr %l116
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t261, i64 0)
  store %"compiler/token:Token" %t263, ptr %l118
  br label %bb65
bb65:
  %t264 = getelementptr %"compiler/token:Token", ptr %l118, i32 0, i32 3
  %t265 = load i32, ptr %t264, !tbaa !23
  store i32 %t265, ptr %l119, !tbaa !23
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t266, i32 0, i32 2
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t270 = load i32, ptr %l5, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t269, i32 %t270)
  store { i64, ptr } %t273, ptr %l123
  br label %bb66
bb66:
  %t274 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t275 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %s10, { i64, ptr } %t274)
  store %"compiler/msgs:Msg" %t275, ptr %l124
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l114, !tbaa !29
  %t277 = load i32, ptr %l116, !tbaa !23
  %t278 = load i32, ptr %l119, !tbaa !23
  %t279 = load %"compiler/msgs:Msg", ptr %l124
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s10, ptr %t276, i32 %t277, i32 %t278, %"compiler/msgs:Msg" %t279)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb69:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t280)
  %t283 = extractvalue { i32, { i64, ptr } } %t282, 1
  %t284 = extractvalue { i32, { i64, ptr } } %t282, 0
  store i32 %t284, ptr %l128
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb71, label %ok.286
ok.286:
  store { i64, ptr } %t283, ptr %l127
  br label %bb70
bb70:
  %t287 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t287, ptr %l125, !tbaa !27
  br label %bb72
bb71:
  %t288 = load i32, ptr %l128, !tbaa !23
  %t289 = lshr i32 %t288, 16
  %t290 = and i32 %t288, 65535
  %t291 = icmp eq i32 %t289, 1
  %t292 = select i1 %t291, i32 1, i32 0
  %t293 = icmp eq i32 %t288, 0
  %t294 = shl i32 %t292, 16
  %t295 = or i32 %t294, %t290
  %t296 = select i1 %t293, i32 0, i32 %t295
  %t298 = insertvalue { i32, ptr } zeroinitializer, i32 %t296, 0
  store { i32, ptr } %t298, ptr %rv
  br label %ret
bb72:
  %t299 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t299, ptr %l8, !tbaa !27
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l3, !tbaa !23
  %t304 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t300, i32 %t301)
  store %"compiler/source:Span" %t304, ptr %l132
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 14, ptr %t308
  %t309 = load %"compiler/source:Span", ptr %l132
  %t310 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t309, 0
  %t312 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t310, ptr %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [5 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t316, ptr %t318
  store ptr %t318, ptr %l2, !tbaa !29
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb171
bb77:
  %t320 = load i32, ptr %l4
  %t322 = trunc i64 90 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb85
bb80:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %t325)
  %t328 = extractvalue { i32, { i64, ptr } } %t327, 1
  %t329 = extractvalue { i32, { i64, ptr } } %t327, 0
  store i32 %t329, ptr %l142
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb82, label %ok.331
ok.331:
  store { i64, ptr } %t328, ptr %l141
  br label %bb81
bb81:
  %t332 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t332, ptr %l139, !tbaa !27
  br label %bb83
bb82:
  %t333 = load i32, ptr %l142, !tbaa !23
  %t334 = lshr i32 %t333, 16
  %t335 = and i32 %t333, 65535
  %t336 = icmp eq i32 %t334, 1
  %t337 = select i1 %t336, i32 1, i32 0
  %t338 = icmp eq i32 %t333, 0
  %t339 = shl i32 %t337, 16
  %t340 = or i32 %t339, %t335
  %t341 = select i1 %t338, i32 0, i32 %t340
  %t343 = insertvalue { i32, ptr } zeroinitializer, i32 %t341, 0
  store { i32, ptr } %t343, ptr %rv
  br label %ret
bb83:
  %t344 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t344, ptr %l9, !tbaa !27
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l3, !tbaa !23
  %t349 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t345, i32 %t346)
  store %"compiler/source:Span" %t349, ptr %l146
  br label %bb84
bb84:
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t352, i32 0, i32 0
  store i64 12, ptr %t353
  %t354 = load %"compiler/source:Span", ptr %l146
  %t355 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t354, 0
  %t357 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t355, ptr %t350, 1
  %t359 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t357, { i64, ptr } %t351, 2
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t352, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t359, ptr %t360
  %t361 = load { i64, [5 x i64] }, ptr %t352
  %t363 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t361, ptr %t363
  store ptr %t363, ptr %l2, !tbaa !29
  br label %bb171
bb85:
  %t365 = load i32, ptr %l4
  %t367 = trunc i64 73 to i32
  %t368 = icmp eq i32 %t365, %t367
  br i1 %t368, label %bb86, label %bb87
bb86:
  br label %bb92
bb87:
  %t370 = load i32, ptr %l4
  %t372 = trunc i64 74 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb88, label %bb89
bb88:
  br label %bb92
bb89:
  %t375 = load i32, ptr %l4
  %t377 = trunc i64 78 to i32
  %t378 = icmp eq i32 %t375, %t377
  br i1 %t378, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t380)
  store i32 %t382, ptr %l158
  br label %bb93
bb93:
  %t383 = load i32, ptr %l158
  store i32 %t383, ptr %l10
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t384)
  store i32 %t386, ptr %l160
  br label %bb94
bb94:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l3, !tbaa !23
  %t391 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t387, i32 %t388)
  store %"compiler/source:Span" %t391, ptr %l163
  br label %bb95
bb95:
  %t392 = load i32, ptr %l10
  %t393 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 0
  store i64 4, ptr %t395
  %t396 = load %"compiler/source:Span", ptr %l163
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t396, 0
  %t399 = insertvalue { %"compiler/source:Span", i32, ptr } %t397, i32 %t392, 1
  %t401 = insertvalue { %"compiler/source:Span", i32, ptr } %t399, ptr %t393, 2
  %t402 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t401, ptr %t402
  %t403 = load { i64, [5 x i64] }, ptr %t394
  %t405 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t403, ptr %t405
  store ptr %t405, ptr %l2, !tbaa !29
  br label %bb171
bb96:
  %t407 = load i32, ptr %l4
  %t409 = trunc i64 29 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb105
bb99:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t412)
  store i32 %t414, ptr %l171
  br label %bb100
bb100:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t415)
  %t418 = extractvalue { i32, ptr } %t417, 1
  %t419 = extractvalue { i32, ptr } %t417, 0
  store i32 %t419, ptr %l175
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb102, label %ok.421
ok.421:
  store ptr %t418, ptr %l174
  br label %bb101
bb101:
  %t422 = load ptr, ptr %l174, !tbaa !29
  store ptr %t422, ptr %l172, !tbaa !29
  br label %bb103
bb102:
  %t423 = load i32, ptr %l175, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  %t433 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb103:
  %t434 = load ptr, ptr %l172, !tbaa !29
  store ptr %t434, ptr %l11, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i32, ptr %l3, !tbaa !23
  %t439 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t435, i32 %t436)
  store %"compiler/source:Span" %t439, ptr %l179
  br label %bb104
bb104:
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t441 = load ptr, ptr %l11, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t442
  %t443 = getelementptr { i64, [5 x i64] }, ptr %t442, i32 0, i32 0
  store i64 11, ptr %t443
  %t444 = load %"compiler/source:Span", ptr %l179
  %t445 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t444, 0
  %t447 = insertvalue { %"compiler/source:Span", ptr, ptr } %t445, ptr %t440, 1
  %t449 = insertvalue { %"compiler/source:Span", ptr, ptr } %t447, ptr %t441, 2
  %t450 = getelementptr { i64, [5 x i64] }, ptr %t442, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t449, ptr %t450
  %t451 = load { i64, [5 x i64] }, ptr %t442
  %t453 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t451, ptr %t453
  store ptr %t453, ptr %l2, !tbaa !29
  br label %bb171
bb105:
  %t455 = load i32, ptr %l4
  %t457 = trunc i64 83 to i32
  %t458 = icmp eq i32 %t455, %t457
  br i1 %t458, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb170
bb108:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 7
  %t463 = load i32, ptr %t462
  %t465 = trunc i64 0 to i32
  %t466 = icmp eq i32 %t463, %t465
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb109, label %bb110
bb109:
  %t470 = load ptr, ptr %l2, !tbaa !29
  %t472 = insertvalue { i32, ptr } zeroinitializer, ptr %t470, 1
  store { i32, ptr } %t472, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t473, i64 1)
  store i32 %t475, ptr %l192
  br label %bb112
bb112:
  %t476 = load i32, ptr %l192
  store i32 %t476, ptr %l12
  %t477 = load ptr, ptr %l2, !tbaa !29
  %t479 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t477)
  store i1 %t479, ptr %l194
  br label %bb113
bb113:
  %t480 = load i1, ptr %l194, !tbaa !21
  br i1 %t480, label %bb114, label %bb115
bb114:
  %t481 = load i32, ptr %l12
  %t483 = trunc i64 92 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb116, label %bb117
bb115:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb127
bb116:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb126
bb117:
  %t486 = load i32, ptr %l12
  %t488 = trunc i64 1 to i32
  %t489 = icmp eq i32 %t486, %t488
  br i1 %t489, label %bb118, label %bb119
bb118:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t491, i64 2)
  store i32 %t493, ptr %l203
  br label %bb120
bb119:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb121
bb120:
  %t494 = load i32, ptr %l203
  %t496 = trunc i64 92 to i32
  %t497 = icmp eq i32 %t494, %t496
  store i1 %t497, ptr %l201, !tbaa !21
  br label %bb121
bb121:
  %t499 = load i1, ptr %l201, !tbaa !21
  br i1 %t499, label %bb122, label %bb123
bb122:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l2, !tbaa !29
  %t504 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v0, ptr %t500, ptr %t501)
  store i1 %t504, ptr %l209
  br label %bb124
bb123:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb125
bb124:
  %t505 = load i1, ptr %l209, !tbaa !21
  store i1 %t505, ptr %l206, !tbaa !21
  br label %bb125
bb125:
  %t506 = load i1, ptr %l206, !tbaa !21
  store i1 %t506, ptr %l198, !tbaa !21
  br label %bb126
bb126:
  %t507 = load i1, ptr %l198, !tbaa !21
  store i1 %t507, ptr %l195, !tbaa !21
  br label %bb127
bb127:
  %t508 = load i1, ptr %l195, !tbaa !21
  br i1 %t508, label %bb128, label %bb129
bb128:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load ptr, ptr %l2, !tbaa !29
  %t513 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %t509, ptr %t510)
  %t514 = extractvalue { i32, ptr } %t513, 1
  %t515 = extractvalue { i32, ptr } %t513, 0
  store i32 %t515, ptr %l214
  %t516 = icmp ne i32 %t515, 0
  br i1 %t516, label %bb131, label %ok.517
ok.517:
  store ptr %t514, ptr %l213
  br label %bb130
bb129:
  br label %bb137
bb130:
  %t518 = load ptr, ptr %l213, !tbaa !29
  store ptr %t518, ptr %l210, !tbaa !29
  br label %bb132
bb131:
  %t519 = load i32, ptr %l214, !tbaa !23
  %t520 = lshr i32 %t519, 16
  %t521 = and i32 %t519, 65535
  %t522 = icmp eq i32 %t520, 1
  %t523 = select i1 %t522, i32 1, i32 0
  %t524 = icmp eq i32 %t519, 0
  %t525 = shl i32 %t523, 16
  %t526 = or i32 %t525, %t521
  %t527 = select i1 %t524, i32 0, i32 %t526
  %t529 = insertvalue { i32, ptr } zeroinitializer, i32 %t527, 0
  store { i32, ptr } %t529, ptr %rv
  br label %ret
bb132:
  %t530 = load ptr, ptr %l210, !tbaa !29
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l217, !tbaa !29
  %t532 = load i32, ptr %l3, !tbaa !23
  store i32 %t532, ptr %l218, !tbaa !23
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l3, !tbaa !23
  %t539 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t533, i32 %t534, ptr %t530)
  store ptr %t539, ptr %l222
  br label %bb133
bb133:
  %t540 = load ptr, ptr %l217, !tbaa !29
  %t541 = load i32, ptr %l218, !tbaa !23
  %t542 = load ptr, ptr %l222, !tbaa !29
  %t543 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %t540, i32 %t541, ptr %t542)
  %t544 = extractvalue { i32, ptr } %t543, 1
  %t545 = extractvalue { i32, ptr } %t543, 0
  store i32 %t545, ptr %l224
  %t546 = icmp ne i32 %t545, 0
  br i1 %t546, label %bb135, label %ok.547
ok.547:
  store ptr %t544, ptr %l223
  br label %bb134
bb134:
  %t548 = load ptr, ptr %l223, !tbaa !29
  store ptr %t548, ptr %l216, !tbaa !29
  br label %bb136
bb135:
  %t549 = load i32, ptr %l224, !tbaa !23
  %t550 = lshr i32 %t549, 16
  %t551 = and i32 %t549, 65535
  %t552 = icmp eq i32 %t550, 1
  %t553 = select i1 %t552, i32 1, i32 0
  %t554 = icmp eq i32 %t549, 0
  %t555 = shl i32 %t553, 16
  %t556 = or i32 %t555, %t551
  %t557 = select i1 %t554, i32 0, i32 %t556
  %t559 = insertvalue { i32, ptr } zeroinitializer, i32 %t557, 0
  store { i32, ptr } %t559, ptr %rv
  br label %ret
bb136:
  %t560 = load ptr, ptr %l216, !tbaa !29
  store ptr %t560, ptr %l2, !tbaa !29
  br label %bb172
bb137:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t561)
  store %"compiler/token:Token" %t563, ptr %l227
  br label %bb138
bb138:
  %t564 = load %"compiler/token:Token", ptr %l227
  store %"compiler/token:Token" %t564, ptr %l14
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t565, i64 1)
  store %"compiler/token:Token" %t567, ptr %l229
  br label %bb139
bb139:
  %t568 = load %"compiler/token:Token", ptr %l229
  store %"compiler/token:Token" %t568, ptr %l15
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t569, i64 2)
  store %"compiler/token:Token" %t571, ptr %l231
  br label %bb140
bb140:
  %t572 = load %"compiler/token:Token", ptr %l231
  store %"compiler/token:Token" %t572, ptr %l16
  %t573 = load %"compiler/token:Token", ptr %l14
  %t574 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t577 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t573, i8 %t574)
  store i1 %t577, ptr %l234
  br label %bb141
bb141:
  %t578 = load i1, ptr %l234, !tbaa !21
  br i1 %t578, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l235, !tbaa !21
  br label %bb147
bb143:
  %t579 = getelementptr %"compiler/token:Token", ptr %l15, i32 0, i32 0
  %t580 = load i32, ptr %t579
  %t582 = trunc i64 1 to i32
  %t583 = icmp eq i32 %t580, %t582
  %t585 = xor i1 %t583, true
  br i1 %t585, label %bb144, label %bb145
bb144:
  %t587 = getelementptr %"compiler/token:Token", ptr %l15, i32 0, i32 0
  %t588 = load i32, ptr %t587
  %t590 = trunc i64 13 to i32
  %t591 = icmp eq i32 %t588, %t590
  %t593 = xor i1 %t591, true
  store i1 %t593, ptr %l239, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb146
bb146:
  %t595 = load i1, ptr %l239, !tbaa !21
  store i1 %t595, ptr %l235, !tbaa !21
  br label %bb147
bb147:
  %t596 = load i1, ptr %l235, !tbaa !21
  br i1 %t596, label %bb148, label %bb149
bb148:
  store i1 true, ptr %l243, !tbaa !21
  br label %bb151
bb149:
  %t597 = load %"compiler/token:Token", ptr %l15
  %t598 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t601 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t597, i8 %t598)
  store i1 %t601, ptr %l246
  br label %bb150
bb150:
  %t602 = load i1, ptr %l246, !tbaa !21
  store i1 %t602, ptr %l243, !tbaa !21
  br label %bb151
bb151:
  %t603 = load i1, ptr %l243, !tbaa !21
  br i1 %t603, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l247, !tbaa !21
  br label %bb154
bb153:
  %t604 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t605 = load i32, ptr %t604
  %t607 = trunc i64 90 to i32
  %t608 = icmp eq i32 %t605, %t607
  %t610 = xor i1 %t608, true
  store i1 %t610, ptr %l247, !tbaa !21
  br label %bb154
bb154:
  %t612 = load i1, ptr %l247, !tbaa !21
  br i1 %t612, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l251, !tbaa !21
  br label %bb158
bb156:
  %t613 = load %"compiler/token:Token", ptr %l16
  %t614 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t617 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t613, i8 %t614)
  store i1 %t617, ptr %l254
  br label %bb157
bb157:
  %t618 = load i1, ptr %l254, !tbaa !21
  store i1 %t618, ptr %l251, !tbaa !21
  br label %bb158
bb158:
  %t619 = load i1, ptr %l251, !tbaa !21
  br i1 %t619, label %bb159, label %bb160
bb159:
  %t620 = load ptr, ptr %l2, !tbaa !29
  %t622 = insertvalue { i32, ptr } zeroinitializer, ptr %t620, 1
  store { i32, ptr } %t622, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t623)
  store i32 %t625, ptr %l257
  br label %bb162
bb162:
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t628 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t626)
  store i32 %t628, ptr %l259
  br label %bb163
bb163:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/parse:Parser", ptr %t629, i32 0, i32 2
  %t632 = load ptr, ptr %t631, !tbaa !29
  store ptr %t632, ptr %l261, !tbaa !29
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t634 = load %"compiler/token:Token", ptr %l15
  %t637 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t633, %"compiler/token:Token" %t634)
  store { i64, ptr } %t637, ptr %l264
  br label %bb164
bb164:
  %t638 = load ptr, ptr %l261, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t640 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t638, { i64, ptr } %t639)
  store i32 %t640, ptr %l265
  br label %bb165
bb165:
  %t641 = load i32, ptr %l265, !tbaa !23
  store i32 %t641, ptr %l17, !tbaa !23
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %t642)
  %t645 = extractvalue { i32, { i64, ptr } } %t644, 1
  %t646 = extractvalue { i32, { i64, ptr } } %t644, 0
  store i32 %t646, ptr %l269
  %t647 = icmp ne i32 %t646, 0
  br i1 %t647, label %bb167, label %ok.648
ok.648:
  store { i64, ptr } %t645, ptr %l268
  br label %bb166
bb166:
  %t649 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t649, ptr %l266, !tbaa !27
  br label %bb168
bb167:
  %t650 = load i32, ptr %l269, !tbaa !23
  %t651 = lshr i32 %t650, 16
  %t652 = and i32 %t650, 65535
  %t653 = icmp eq i32 %t651, 1
  %t654 = select i1 %t653, i32 1, i32 0
  %t655 = icmp eq i32 %t650, 0
  %t656 = shl i32 %t654, 16
  %t657 = or i32 %t656, %t652
  %t658 = select i1 %t655, i32 0, i32 %t657
  %t660 = insertvalue { i32, ptr } zeroinitializer, i32 %t658, 0
  store { i32, ptr } %t660, ptr %rv
  br label %ret
bb168:
  %t661 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t661, ptr %l18, !tbaa !27
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load i32, ptr %l3, !tbaa !23
  %t666 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t662, i32 %t663)
  store %"compiler/source:Span" %t666, ptr %l273
  br label %bb169
bb169:
  %t667 = load ptr, ptr %l2, !tbaa !29
  %t668 = load i32, ptr %l17, !tbaa !23
  %t669 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t670
  %t671 = getelementptr { i64, [5 x i64] }, ptr %t670, i32 0, i32 0
  store i64 13, ptr %t671
  %t672 = load %"compiler/source:Span", ptr %l273
  %t673 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } undef, %"compiler/source:Span" %t672, 0
  %t675 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t673, ptr %t667, 1
  %t677 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t675, i32 %t668, 2
  %t679 = insertvalue { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t677, { i64, ptr } %t669, 3
  %t680 = getelementptr { i64, [5 x i64] }, ptr %t670, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, { i64, ptr } } %t679, ptr %t680
  %t681 = load { i64, [5 x i64] }, ptr %t670
  %t683 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t681, ptr %t683
  store ptr %t683, ptr %l2, !tbaa !29
  br label %bb171
bb170:
  %t685 = load ptr, ptr %l2, !tbaa !29
  %t687 = insertvalue { i32, ptr } zeroinitializer, ptr %t685, 1
  store { i32, ptr } %t687, ptr %rv
  br label %ret
bb171:
  br label %bb172
bb172:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t22 = load i1, ptr %l2, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp eq i64 %t26, 1
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l30, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l35
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Oracle", ptr %t56, i32 0, i32 0
  %t59 = load i32, ptr %l5, !tbaa !23
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l40
  br label %bb15
bb15:
  %t63 = load i1, ptr %l40, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %t66)
  store i1 %t68, ptr %l44
  br label %bb18
bb17:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i1, ptr %l44, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l42, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 28
  %t76 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t75, i32 %t76)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %ret
bb24:
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l56, !tbaa !27
  %t94 = load i64, ptr %l8, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t101, ptr %t99, i1 true)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb25
bb31:
  br label %bb50
bb32:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l11, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l11, !tbaa !29
  %t126 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i1 %t126)
  br label %bb38
bb38:
  br label %bb50
bb39:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t131 = load ptr, ptr %l72, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 4
  store i1 %t137, ptr %l73, !tbaa !21
  br label %bb41
bb41:
  %t138 = load i1, ptr %l73, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l12, !tbaa !29
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb45, label %bb46
bb45:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l12, !tbaa !29
  %t153 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereceiverVars(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i1 %t153)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %a0, %"compiler/parse:stackMarks" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  store %"compiler/parse:stackMarks" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 30
  %t4 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3, i64 %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 31
  %t11 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t10, i64 %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 32
  %t18 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t17, i64 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 33
  %t25 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t24, i64 %t26)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 34
  %t32 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %t31, i64 %t33)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 35
  %t39 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t38, i64 %t40)
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 36
  %t46 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t45, i64 %t47)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %a1
  %t13 = load %"compiler/token:Token", ptr %t12
  store %"compiler/token:Token" %t13, ptr %l3
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %t15, i32 %t17, i32 %t19, %"compiler/msgs:Msg" %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %a0, i1 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i32
  %l72 = alloca i1
  %l75 = alloca i1
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca %"compiler/token:Token"
  %l96 = alloca { i64, ptr }
  %l97 = alloca i1
  %l99 = alloca i32
  %l100 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l116 = alloca %"compiler/ast:Sig"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 19
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l16, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t9, i32 90)
  %t13 = extractvalue { i32, i32 } %t12, 1
  %t14 = extractvalue { i32, i32 } %t12, 0
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16
ok.16:
  store i32 %t13, ptr %l22
  br label %bb4
bb4:
  %t17 = load i32, ptr %l22, !tbaa !23
  store i32 %t17, ptr %l19, !tbaa !23
  br label %bb6
bb5:
  %t18 = load i32, ptr %l23, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 49
  store i1 false, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %t32, i1 %a1)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l30
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb8, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l29
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  br label %bb9
bb8:
  %t42 = load i32, ptr %l30, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  call void @__olang_scope_close(ptr %s0)
  %t52 = insertvalue { i32, ptr } zeroinitializer, i32 %t50, 0
  store { i32, ptr } %t52, ptr %rv
  br label %ret
bb9:
  %t53 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t53, ptr %l5, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/parse:Parser", ptr %t54, i32 0, i32 49
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 49
  store i1 false, ptr %t61, !tbaa !21
  store ptr null, ptr %l7, !tbaa !29
  %t62 = load i1, ptr %l3, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %t64)
  %t67 = extractvalue { i32, ptr } %t66, 1
  %t68 = extractvalue { i32, ptr } %t66, 0
  store i32 %t68, ptr %l39
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb13, label %ok.70
ok.70:
  store ptr %t67, ptr %l38
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t71 = load ptr, ptr %l38, !tbaa !29
  store ptr %t71, ptr %l36, !tbaa !29
  br label %bb14
bb13:
  %t72 = load i32, ptr %l39, !tbaa !23
  %t73 = lshr i32 %t72, 16
  %t74 = and i32 %t72, 65535
  %t75 = icmp eq i32 %t73, 1
  %t76 = select i1 %t75, i32 1, i32 0
  %t77 = icmp eq i32 %t72, 0
  %t78 = shl i32 %t76, 16
  %t79 = or i32 %t78, %t74
  %t80 = select i1 %t77, i32 0, i32 %t79
  call void @__olang_scope_close(ptr %s0)
  %t82 = insertvalue { i32, ptr } zeroinitializer, i32 %t80, 0
  store { i32, ptr } %t82, ptr %rv
  br label %ret
bb14:
  %t83 = load ptr, ptr %l36, !tbaa !29
  store ptr %t83, ptr %l7, !tbaa !29
  br label %bb15
bb15:
  %t84 = icmp sge i64 0, 0
  br i1 %t84, label %bb16, label %bb17
bb16:
  %t86 = icmp sle i64 0, 1152921504606846975
  br i1 %t86, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb18:
  %t88 = mul i64 0, 8
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t96 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t93, i32 23)
  store i1 %t96, ptr %l46
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb20:
  %t97 = load i1, ptr %l46, !tbaa !21
  store i1 %t97, ptr %l9, !tbaa !21
  %t98 = load i1, ptr %l9, !tbaa !21
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb21, label %bb22
bb21:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %t102)
  store i1 %t104, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb24
bb23:
  %t105 = load i1, ptr %l51, !tbaa !21
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l49, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/parse:Parser", ptr %t107, i32 0, i32 32
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l54
  br label %bb27
bb26:
  br label %bb45
bb27:
  %t112 = load i64, ptr %l54, !tbaa !24
  store i64 %t112, ptr %l10, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t113, i32 0, i32 19
  %t116 = load i1, ptr %t115, !tbaa !21
  store i1 %t116, ptr %l11, !tbaa !21
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/parse:Parser", ptr %t118, i32 0, i32 19
  store i1 true, ptr %t120, !tbaa !21
  br label %bb28
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t121)
  %t124 = extractvalue { i32, ptr } %t123, 1
  %t125 = extractvalue { i32, ptr } %t123, 0
  store i32 %t125, ptr %l61
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb30, label %ok.127
ok.127:
  store ptr %t124, ptr %l60
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l60, !tbaa !29
  store ptr %t128, ptr %l58, !tbaa !29
  br label %bb33
bb30:
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i1, ptr %l11, !tbaa !21
  %t133 = getelementptr %"compiler/parse:Parser", ptr %t129, i32 0, i32 19
  store i1 %t130, ptr %t133, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/parse:Parser", ptr %t134, i32 0, i32 32
  %t137 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t136, i64 %t137)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t141 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t141, ptr %rv
  br label %ret
bb33:
  %t142 = load ptr, ptr %l58, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t145, ptr %t142)
  br label %bb34
bb34:
  %t149 = load i1, ptr %l4, !tbaa !21
  br i1 %t149, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb38
bb36:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t154 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t151, i32 57)
  store i1 %t154, ptr %l75
  br label %bb37
bb37:
  %t155 = load i1, ptr %l75, !tbaa !21
  %t156 = xor i1 %t155, true
  store i1 %t156, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t158 = load i1, ptr %l72, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb28
bb43:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l11, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 19
  store i1 %t160, ptr %t163, !tbaa !21
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 32
  %t167 = load i64, ptr %l10, !tbaa !24
  %t170 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t166, i64 %t167)
  store { i64, ptr } %t170, ptr %l82
  br label %bb44
bb44:
  %t171 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t171, ptr %l8, !tbaa !27
  br label %bb45
bb45:
  store i1 false, ptr %l13, !tbaa !21
  %t172 = load i1, ptr %l3, !tbaa !21
  br i1 %t172, label %bb46, label %bb47
bb46:
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t178 = icmp sgt i64 %t176, 0
  store i1 %t178, ptr %l84, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb48
bb48:
  %t180 = load i1, ptr %l84, !tbaa !21
  br i1 %t180, label %bb49, label %bb50
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t184 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t181, i32 1)
  store i1 %t184, ptr %l91
  br label %bb51
bb50:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb52
bb51:
  %t185 = load i1, ptr %l91, !tbaa !21
  store i1 %t185, ptr %l88, !tbaa !21
  br label %bb52
bb52:
  %t186 = load i1, ptr %l88, !tbaa !21
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l93, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t188)
  store %"compiler/token:Token" %t190, ptr %l95
  br label %bb55
bb54:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb58
bb55:
  %t191 = load ptr, ptr %l93, !tbaa !29
  %t192 = load %"compiler/token:Token", ptr %l95
  %t193 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %t191, %"compiler/token:Token" %t192)
  store { i64, ptr } %t193, ptr %l96
  br label %bb56
bb56:
  %t194 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t194, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t195, ptr %l97
  br label %bb57
bb57:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l92, !tbaa !21
  br label %bb58
bb58:
  %t197 = load i1, ptr %l92, !tbaa !21
  br i1 %t197, label %bb59, label %bb60
bb59:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t198)
  store i32 %t200, ptr %l99
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb62
bb62:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i1, ptr %l4, !tbaa !21
  %t205 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %t201, i1 %t202)
  %t206 = extractvalue { i32, ptr } %t205, 1
  %t207 = extractvalue { i32, ptr } %t205, 0
  store i32 %t207, ptr %l104
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb64, label %ok.209
ok.209:
  store ptr %t206, ptr %l103
  br label %bb63
bb63:
  %t210 = load ptr, ptr %l103, !tbaa !29
  store ptr %t210, ptr %l100, !tbaa !29
  br label %bb65
bb64:
  %t211 = load i32, ptr %l104, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  call void @__olang_scope_close(ptr %s0)
  %t221 = insertvalue { i32, ptr } zeroinitializer, i32 %t219, 0
  store { i32, ptr } %t221, ptr %rv
  br label %ret
bb65:
  %t222 = load ptr, ptr %l100, !tbaa !29
  store ptr %t222, ptr %l14, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t225 = load ptr, ptr %l14, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Sig", ptr %t225, i32 0, i32 2
  %t228 = load i1, ptr %t227, !tbaa !21
  %t229 = load ptr, ptr %l14, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Sig", ptr %t229, i32 0, i32 3
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t233 = load i1, ptr %l9, !tbaa !21
  %t234 = load ptr, ptr %l7, !tbaa !29
  %t235 = load i1, ptr %l13, !tbaa !21
  %t236 = load i1, ptr %l6, !tbaa !21
  %t245 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t223, { i64, ptr } %t224, i1 %t228, { i64, ptr } %t232, i1 %t233, ptr %t234, i1 %t235, i1 %t236)
  store %"compiler/ast:Sig" %t245, ptr %l116
  br label %bb66
bb66:
  %t246 = load %"compiler/ast:Sig", ptr %l116
  %t247 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/ast:Sig" %t246, ptr %t247
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, ptr } zeroinitializer, ptr %t247, 1
  store { i32, ptr } %t249, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 8)
  store i1 %t4, ptr %l3
  br label %bb2
bb2:
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l6
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l13 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 18
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = sub i64 %t17, 1
  %t22 = icmp slt i64 %t8, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/scan:Tokens", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i64 %t31
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t39 = trunc i64 8 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l13, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i32
  %l33 = alloca i32
  %l38 = alloca %"compiler/token:Token"
  %l40 = alloca i1
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1
  %t7 = trunc i64 40 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1
  %t12 = trunc i64 38 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1
  %t19 = trunc i64 1 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t29, ptr %l18
  br label %bb12
bb12:
  %t30 = load i32, ptr %l18
  %t32 = trunc i64 58 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t35, i64 %t38)
  store i32 %t41, ptr %l25
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t42 = load i32, ptr %l25
  %t44 = trunc i64 1 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l21, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = add i64 %t50, 2
  store i64 %t52, ptr %l2, !tbaa !24
  br label %bb20
bb20:
  br label %bb11
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l33
  br label %bb22
bb22:
  %t59 = load i32, ptr %l33
  store i32 %t59, ptr %l3
  %t60 = load i32, ptr %l3
  %t62 = trunc i64 83 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/token:Token" %t69, ptr %l38
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t70 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t71 = load %"compiler/token:Token", ptr %l38
  %t73 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t71, i8 %t70)
  store i1 %t73, ptr %l40
  br label %bb26
bb26:
  %t74 = load i1, ptr %l40, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %rv
  br label %ret
bb27:
  %t77 = load i32, ptr %l3
  %t79 = trunc i64 79 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisTypePath(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l46
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmtRoom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t8 = icmp sge i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 6
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t10, i64 %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l8 = alloca i32
  %l18 = alloca i32
  %l25 = alloca i32
  %l30 = alloca i1
  %l37 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  store i32 0, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 11
  store i1 false, ptr %t7, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i32, ptr %l8
  store i32 %t11, ptr %l2
  %t12 = load i32, ptr %l2
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load i32, ptr %l2
  %t19 = trunc i64 94 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = trunc i64 %t29 to i32
  %t34 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %t25, i32 %t31)
  store i32 %t34, ptr %l18
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t35 = load i32, ptr %l18, !tbaa !23
  store i32 %t35, ptr %l3, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t40, i32 0, i32 6
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l25
  br label %bb12
bb12:
  br label %bb40
bb13:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 95 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  %t55 = load i32, ptr %l2
  %t57 = trunc i64 90 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 92 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l1, !tbaa !24
  br label %bb37
bb20:
  %t70 = load i32, ptr %l2
  %t72 = trunc i64 91 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb23
bb22:
  %t75 = load i32, ptr %l2
  %t77 = trunc i64 93 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t80 = load i1, ptr %l37, !tbaa !21
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb26, label %bb27
bb25:
  %t85 = load i32, ptr %l2
  %t87 = trunc i64 8 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb29, label %bb30
bb26:
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = sub i64 %t90, 1
  store i64 %t92, ptr %l1, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb36
bb29:
  %t94 = load i64, ptr %l1, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t99)
  store i32 %t101, ptr %l50
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t102)
  store i32 %t104, ptr %l52
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb1
ret:
  ret void
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 6
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t11)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 6
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 6
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t27)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %a0, %"compiler/token:Token" %a1) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/token:Token" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/source:Source", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t8 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l8, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb3:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b08fe5a62583e117_e5b5edd841fa1acb)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca %"compiler/token:Token"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/token:Token", ptr %t18, i64 %t16
  %t20 = load %"compiler/token:Token", ptr %t19
  store %"compiler/token:Token" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/token:Token", ptr %rv
  ret %"compiler/token:Token" %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/token:Token"
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, [3 x i64] }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %t39 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 21
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/token:Token", ptr %t19, i64 %a1
  %t21 = load %"compiler/token:Token", ptr %t20
  store %"compiler/token:Token" %t21, ptr %l2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 4
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/parse:Parser", ptr %t27, i32 0, i32 5
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 3
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 0
  store i64 3, ptr %t40
  %t42 = insertvalue { i64, i64, i64 } undef, i64 %t30, 0
  %t44 = insertvalue { i64, i64, i64 } %t42, i64 %t34, 1
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t38, 2
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  store { i64, i64, i64 } %t46, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t39
  store { i64, [3 x i64] } %t48, ptr %l19
  %t49 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %s0, i64 %t49)
  store %"compiler/msgs:Msg" %t51, ptr %l21
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l12, !tbaa !29
  %t53 = load { i64, [3 x i64] }, ptr %l19
  %t54 = load %"compiler/msgs:Msg", ptr %l21
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %s0, ptr %t52, { i64, [3 x i64] } %t53, %"compiler/msgs:Msg" %t54)
  store i64 %t55, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/ast:TopBranch"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 94)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l10
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l10, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l6, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 37
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l17
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t35)
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t37, i32 95)
  store i1 %t40, ptr %l21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 0)
  store i1 %t45, ptr %l25
  br label %bb11
bb11:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t48)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb6
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t53)
  br label %bb19
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t55, i32 95)
  %t59 = extractvalue { i32, i32 } %t58, 1
  %t60 = extractvalue { i32, i32 } %t58, 0
  store i32 %t60, ptr %l33
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb21, label %ok.62
ok.62:
  store i32 %t59, ptr %l32
  br label %bb20
bb20:
  %t63 = load i32, ptr %l32, !tbaa !23
  store i32 %t63, ptr %l29, !tbaa !23
  br label %bb22
bb21:
  %t64 = load i32, ptr %l33, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t75, i32 %t76)
  store %"compiler/source:Span" %t79, ptr %l37
  br label %bb23
bb23:
  %t80 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t80, ptr %l4
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 37
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l41
  br label %bb24
bb24:
  %t88 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t89 = load %"compiler/source:Span", ptr %l4
  %t91 = load i64, ptr %l2, !tbaa !24
  %t95 = call %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v0, %"compiler/source:Span" %t89, { i64, ptr } %t88, i64 %t91)
  store %"compiler/ast:TopBranch" %t95, ptr %l45
  br label %bb25
bb25:
  %t96 = load %"compiler/ast:TopBranch", ptr %l45
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:TopBranch" %t96, ptr %t97
  %t99 = insertvalue { i32, ptr } zeroinitializer, ptr %t97, 1
  store { i32, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca i32
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i32
  %l114 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca i1
  %l157 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i32
  %l169 = alloca %"compiler/source:Span"
  %l171 = alloca i32
  %l182 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l210 = alloca i1
  %l220 = alloca %"compiler/source:Span"
  %l227 = alloca %"compiler/source:Span"
  %l229 = alloca i32
  %rv = alloca { i32, ptr }
  %t67 = alloca { i64, [4 x i64] }, align 8
  %t124 = alloca { i64, [4 x i64] }, align 8
  %t190 = alloca { i64, [4 x i64] }, align 8
  %t285 = alloca { i64, [4 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t404 = alloca { i64, [4 x i64] }, align 8
  %t470 = alloca { i64, [4 x i64] }, align 8
  %t602 = alloca { i64, [5 x i64] }, align 8
  %t644 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i32, ptr %l23, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 20
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 2
  %t11 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 6
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t16, i64 %t20)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 22
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 22
  store i64 -1, ptr %t30, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t31, i32 14)
  store i1 %t34, ptr %l37
  br label %bb6
bb6:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %t36, i1 true)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l41
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb10, label %ok.42
ok.42:
  store ptr %t39, ptr %l40
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t43 = load ptr, ptr %l40, !tbaa !29
  store ptr %t43, ptr %l38, !tbaa !29
  br label %bb11
bb10:
  %t44 = load i32, ptr %l41, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 22
  store i64 %t54, ptr %t57, !tbaa !24
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb11:
  %t60 = load ptr, ptr %l38, !tbaa !29
  store ptr %t60, ptr %l3, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/source:Span" %t65, ptr %l47
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 0
  store i64 17, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l47
  %t70 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t69, 0
  %t72 = insertvalue { %"compiler/source:Span", ptr } %t70, ptr %t66, 1
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t72, ptr %t73
  %t74 = load { i64, [4 x i64] }, ptr %t67
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t74, ptr %t76
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 22
  store i64 %t78, ptr %t81, !tbaa !24
  %t83 = insertvalue { i32, ptr } zeroinitializer, ptr %t76, 1
  store { i32, ptr } %t83, ptr %rv
  br label %ret
bb13:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t84, i32 73)
  store i1 %t87, ptr %l55
  br label %bb14
bb14:
  %t88 = load i1, ptr %l55, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t89, i32 74)
  store i1 %t92, ptr %l59
  br label %bb17
bb17:
  %t93 = load i1, ptr %l59, !tbaa !21
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb19, label %bb20
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, ptr } %t97, 1
  %t99 = extractvalue { i32, ptr } %t97, 0
  store i32 %t99, ptr %l63
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb22, label %ok.101
ok.101:
  store ptr %t98, ptr %l62
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t102 = load ptr, ptr %l62, !tbaa !29
  store ptr %t102, ptr %l60, !tbaa !29
  br label %bb23
bb22:
  %t103 = load i32, ptr %l63, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l2, !tbaa !24
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 22
  store i64 %t113, ptr %t116, !tbaa !24
  %t118 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb23:
  %t119 = load ptr, ptr %l60, !tbaa !29
  store ptr %t119, ptr %l4, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t122 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t120)
  store %"compiler/source:Span" %t122, ptr %l68
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 0
  store i64 0, ptr %t125
  %t126 = load %"compiler/source:Span", ptr %l68
  %t127 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t126, 0
  %t129 = insertvalue { %"compiler/source:Span", ptr } %t127, ptr %t123, 1
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t129, ptr %t130
  %t131 = load { i64, [4 x i64] }, ptr %t124
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t132, ptr %lp5
  %t134 = load ptr, ptr %lp5
  store { i64, [4 x i64] } %t131, ptr %t134
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t135, i1 false)
  %t138 = extractvalue { i32, { i64, ptr } } %t137, 1
  %t139 = extractvalue { i32, { i64, ptr } } %t137, 0
  store i32 %t139, ptr %l74
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb26, label %ok.141
ok.141:
  store { i64, ptr } %t138, ptr %l73
  br label %bb25
bb25:
  %t142 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t142, ptr %l71, !tbaa !27
  br label %bb27
bb26:
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = lshr i32 %t143, 16
  %t145 = and i32 %t143, 65535
  %t146 = icmp eq i32 %t144, 1
  %t147 = select i1 %t146, i32 1, i32 0
  %t148 = icmp eq i32 %t143, 0
  %t149 = shl i32 %t147, 16
  %t150 = or i32 %t149, %t145
  %t151 = select i1 %t148, i32 0, i32 %t150
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 22
  store i64 %t153, ptr %t156, !tbaa !24
  %t158 = insertvalue { i32, ptr } zeroinitializer, i32 %t151, 0
  store { i32, ptr } %t158, ptr %rv
  br label %ret
bb27:
  %t159 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t159, ptr %l6, !tbaa !27
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t160, i32 %t161)
  store %"compiler/source:Span" %t164, ptr %l80
  br label %bb28
bb28:
  %t165 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t165, ptr %l7
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t166)
  store i32 %t168, ptr %l82
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb30, label %ok.170
ok.170:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t171 = load i32, ptr %l82, !tbaa !23
  %t172 = lshr i32 %t171, 16
  %t173 = and i32 %t171, 65535
  %t174 = icmp eq i32 %t172, 1
  %t175 = select i1 %t174, i32 1, i32 0
  %t176 = icmp eq i32 %t171, 0
  %t177 = shl i32 %t175, 16
  %t178 = or i32 %t177, %t173
  %t179 = select i1 %t176, i32 0, i32 %t178
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l2, !tbaa !24
  %t184 = getelementptr %"compiler/parse:Parser", ptr %t180, i32 0, i32 22
  store i64 %t181, ptr %t184, !tbaa !24
  %t186 = insertvalue { i32, ptr } zeroinitializer, i32 %t179, 0
  store { i32, ptr } %t186, ptr %rv
  br label %ret
bb31:
  %t187 = load %"compiler/source:Span", ptr %l7
  %t188 = load ptr, ptr %lp5
  %t189 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 0
  store i64 4, ptr %t191
  %t193 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t187, 0
  %t195 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t193, ptr %t188, 1
  %t197 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t195, { i64, ptr } %t189, 2
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l2, !tbaa !24
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 22
  store i64 %t203, ptr %t206, !tbaa !24
  %t208 = insertvalue { i32, ptr } zeroinitializer, ptr %t201, 1
  store { i32, ptr } %t208, ptr %rv
  br label %ret
bb32:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t209)
  %t212 = extractvalue { i32, ptr } %t211, 1
  %t213 = extractvalue { i32, ptr } %t211, 0
  store i32 %t213, ptr %l96
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb34, label %ok.215
ok.215:
  store ptr %t212, ptr %l95
  br label %bb33
bb33:
  %t216 = load ptr, ptr %l95, !tbaa !29
  store ptr %t216, ptr %l93, !tbaa !29
  br label %bb35
bb34:
  %t217 = load i32, ptr %l96, !tbaa !23
  %t218 = lshr i32 %t217, 16
  %t219 = and i32 %t217, 65535
  %t220 = icmp eq i32 %t218, 1
  %t221 = select i1 %t220, i32 1, i32 0
  %t222 = icmp eq i32 %t217, 0
  %t223 = shl i32 %t221, 16
  %t224 = or i32 %t223, %t219
  %t225 = select i1 %t222, i32 0, i32 %t224
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i64, ptr %l2, !tbaa !24
  %t230 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 22
  store i64 %t227, ptr %t230, !tbaa !24
  %t232 = insertvalue { i32, ptr } zeroinitializer, i32 %t225, 0
  store { i32, ptr } %t232, ptr %rv
  br label %ret
bb35:
  %t233 = load ptr, ptr %l93, !tbaa !29
  store ptr %t233, ptr %l8, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t234)
  store i32 %t236, ptr %l101
  br label %bb36
bb36:
  %t237 = load i32, ptr %l101
  store i32 %t237, ptr %l9
  %t238 = load i32, ptr %l9
  %t240 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t238)
  store i1 %t240, ptr %l103
  br label %bb37
bb37:
  %t241 = load i1, ptr %l103, !tbaa !21
  br i1 %t241, label %bb38, label %bb39
bb38:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t242)
  store i32 %t244, ptr %l105
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %t245)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l109
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb42, label %ok.251
ok.251:
  store ptr %t248, ptr %l108
  br label %bb41
bb41:
  %t252 = load ptr, ptr %l108, !tbaa !29
  store ptr %t252, ptr %l106, !tbaa !29
  br label %bb43
bb42:
  %t253 = load i32, ptr %l109, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i64, ptr %l2, !tbaa !24
  %t266 = getelementptr %"compiler/parse:Parser", ptr %t262, i32 0, i32 22
  store i64 %t263, ptr %t266, !tbaa !24
  %t268 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t268, ptr %rv
  br label %ret
bb43:
  %t269 = load ptr, ptr %l106, !tbaa !29
  store ptr %t269, ptr %l10, !tbaa !29
  %t270 = load ptr, ptr %l8, !tbaa !29
  %t272 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t270)
  store %"compiler/source:Span" %t272, ptr %l114
  br label %bb44
bb44:
  %t273 = getelementptr %"compiler/source:Span", ptr %l114, i32 0, i32 0
  %t274 = load i32, ptr %t273, !tbaa !23
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/parse:Parser", ptr %t275, i32 0, i32 10
  %t278 = load i32, ptr %t277, !tbaa !23
  %t281 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t274, i32 %t278)
  store %"compiler/source:Span" %t281, ptr %l118
  br label %bb45
bb45:
  %t282 = load i32, ptr %l9
  %t283 = load ptr, ptr %l8, !tbaa !29
  %t284 = load ptr, ptr %l10, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t285
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 0
  store i64 3, ptr %t286
  %t287 = load %"compiler/source:Span", ptr %l118
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t287, 0
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t288, i32 %t282, 1
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t290, ptr %t283, 2
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t292, ptr %t284, 3
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t285
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t297, ptr %lp11
  %t299 = load ptr, ptr %lp11
  store { i64, [4 x i64] } %t296, ptr %t299
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t300, i1 false)
  %t303 = extractvalue { i32, { i64, ptr } } %t302, 1
  %t304 = extractvalue { i32, { i64, ptr } } %t302, 0
  store i32 %t304, ptr %l126
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb47, label %ok.306
ok.306:
  store { i64, ptr } %t303, ptr %l125
  br label %bb46
bb46:
  %t307 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t307, ptr %l123, !tbaa !27
  br label %bb48
bb47:
  %t308 = load i32, ptr %l126, !tbaa !23
  %t309 = lshr i32 %t308, 16
  %t310 = and i32 %t308, 65535
  %t311 = icmp eq i32 %t309, 1
  %t312 = select i1 %t311, i32 1, i32 0
  %t313 = icmp eq i32 %t308, 0
  %t314 = shl i32 %t312, 16
  %t315 = or i32 %t314, %t310
  %t316 = select i1 %t313, i32 0, i32 %t315
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i64, ptr %l2, !tbaa !24
  %t321 = getelementptr %"compiler/parse:Parser", ptr %t317, i32 0, i32 22
  store i64 %t318, ptr %t321, !tbaa !24
  %t323 = insertvalue { i32, ptr } zeroinitializer, i32 %t316, 0
  store { i32, ptr } %t323, ptr %rv
  br label %ret
bb48:
  %t324 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t324, ptr %l12, !tbaa !27
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i32, ptr %l1, !tbaa !23
  %t329 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t325, i32 %t326)
  store %"compiler/source:Span" %t329, ptr %l132
  br label %bb49
bb49:
  %t330 = load %"compiler/source:Span", ptr %l132
  store %"compiler/source:Span" %t330, ptr %l13
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t331)
  store i32 %t333, ptr %l134
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb51, label %ok.335
ok.335:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t336 = load i32, ptr %l134, !tbaa !23
  %t337 = lshr i32 %t336, 16
  %t338 = and i32 %t336, 65535
  %t339 = icmp eq i32 %t337, 1
  %t340 = select i1 %t339, i32 1, i32 0
  %t341 = icmp eq i32 %t336, 0
  %t342 = shl i32 %t340, 16
  %t343 = or i32 %t342, %t338
  %t344 = select i1 %t341, i32 0, i32 %t343
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l2, !tbaa !24
  %t349 = getelementptr %"compiler/parse:Parser", ptr %t345, i32 0, i32 22
  store i64 %t346, ptr %t349, !tbaa !24
  %t351 = insertvalue { i32, ptr } zeroinitializer, i32 %t344, 0
  store { i32, ptr } %t351, ptr %rv
  br label %ret
bb52:
  %t352 = load %"compiler/source:Span", ptr %l13
  %t353 = load ptr, ptr %lp11
  %t354 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 4, ptr %t356
  %t358 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t352, 0
  %t360 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t358, ptr %t353, 1
  %t362 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t360, { i64, ptr } %t354, 2
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr %l2, !tbaa !24
  %t371 = getelementptr %"compiler/parse:Parser", ptr %t367, i32 0, i32 22
  store i64 %t368, ptr %t371, !tbaa !24
  %t373 = insertvalue { i32, ptr } zeroinitializer, ptr %t366, 1
  store { i32, ptr } %t373, ptr %rv
  br label %ret
bb53:
  %t374 = load ptr, ptr %l8, !tbaa !29
  store ptr %t374, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t375 = load ptr, ptr %l145, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb54, label %bb55
bb54:
  %t378 = load ptr, ptr %l145, !tbaa !29
  %t379 = load i64, ptr %t378
  %t381 = icmp eq i64 %t379, 4
  store i1 %t381, ptr %l146, !tbaa !21
  br label %bb55
bb55:
  %t382 = load i1, ptr %l146, !tbaa !21
  br i1 %t382, label %bb56, label %bb57
bb56:
  %t383 = load ptr, ptr %l8, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 1
  %t387 = load i32, ptr %t386
  store i32 %t387, ptr %l14
  br label %bb58
bb57:
  br label %bb73
bb58:
  %t389 = load i32, ptr %l14
  %t391 = trunc i64 73 to i32
  %t392 = icmp eq i32 %t389, %t391
  br i1 %t392, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb61
bb60:
  %t394 = load i32, ptr %l14
  %t396 = trunc i64 74 to i32
  %t397 = icmp eq i32 %t394, %t396
  store i1 %t397, ptr %l153, !tbaa !21
  br label %bb61
bb61:
  %t399 = load i1, ptr %l153, !tbaa !21
  br i1 %t399, label %bb62, label %bb63
bb62:
  %t400 = load ptr, ptr %l8, !tbaa !29
  %t402 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t400)
  store %"compiler/source:Span" %t402, ptr %l157
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t403 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 0
  store i64 0, ptr %t405
  %t406 = load %"compiler/source:Span", ptr %l157
  %t407 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t406, 0
  %t409 = insertvalue { %"compiler/source:Span", ptr } %t407, ptr %t403, 1
  %t410 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t409, ptr %t410
  %t411 = load { i64, [4 x i64] }, ptr %t404
  %t412 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t412, ptr %lp15
  %t414 = load ptr, ptr %lp15
  store { i64, [4 x i64] } %t411, ptr %t414
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t415, i1 false)
  %t418 = extractvalue { i32, { i64, ptr } } %t417, 1
  %t419 = extractvalue { i32, { i64, ptr } } %t417, 0
  store i32 %t419, ptr %l163
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb66, label %ok.421
ok.421:
  store { i64, ptr } %t418, ptr %l162
  br label %bb65
bb65:
  %t422 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t422, ptr %l160, !tbaa !27
  br label %bb67
bb66:
  %t423 = load i32, ptr %l163, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i64, ptr %l2, !tbaa !24
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t432, i32 0, i32 22
  store i64 %t433, ptr %t436, !tbaa !24
  %t438 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t438, ptr %rv
  br label %ret
bb67:
  %t439 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t439, ptr %l16, !tbaa !27
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l1, !tbaa !23
  %t444 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t440, i32 %t441)
  store %"compiler/source:Span" %t444, ptr %l169
  br label %bb68
bb68:
  %t445 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t445, ptr %l17
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t446)
  store i32 %t448, ptr %l171
  %t449 = icmp ne i32 %t448, 0
  br i1 %t449, label %bb70, label %ok.450
ok.450:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t451 = load i32, ptr %l171, !tbaa !23
  %t452 = lshr i32 %t451, 16
  %t453 = and i32 %t451, 65535
  %t454 = icmp eq i32 %t452, 1
  %t455 = select i1 %t454, i32 1, i32 0
  %t456 = icmp eq i32 %t451, 0
  %t457 = shl i32 %t455, 16
  %t458 = or i32 %t457, %t453
  %t459 = select i1 %t456, i32 0, i32 %t458
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i64, ptr %l2, !tbaa !24
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 22
  store i64 %t461, ptr %t464, !tbaa !24
  %t466 = insertvalue { i32, ptr } zeroinitializer, i32 %t459, 0
  store { i32, ptr } %t466, ptr %rv
  br label %ret
bb71:
  %t467 = load %"compiler/source:Span", ptr %l17
  %t468 = load ptr, ptr %lp15
  %t469 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [4 x i64] }, ptr %t470, i32 0, i32 0
  store i64 4, ptr %t471
  %t473 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t467, 0
  %t475 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t473, ptr %t468, 1
  %t477 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t475, { i64, ptr } %t469, 2
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t477, ptr %t478
  %t479 = load { i64, [4 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t479, ptr %t481
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i64, ptr %l2, !tbaa !24
  %t486 = getelementptr %"compiler/parse:Parser", ptr %t482, i32 0, i32 22
  store i64 %t483, ptr %t486, !tbaa !24
  %t488 = insertvalue { i32, ptr } zeroinitializer, ptr %t481, 1
  store { i32, ptr } %t488, ptr %rv
  br label %ret
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load ptr, ptr %l8, !tbaa !29
  %t493 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %t489, ptr %t490, i64 1)
  %t494 = extractvalue { i32, ptr } %t493, 1
  %t495 = extractvalue { i32, ptr } %t493, 0
  store i32 %t495, ptr %l186
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb76, label %ok.497
ok.497:
  store ptr %t494, ptr %l185
  br label %bb75
bb75:
  %t498 = load ptr, ptr %l185, !tbaa !29
  store ptr %t498, ptr %l182, !tbaa !29
  br label %bb77
bb76:
  %t499 = load i32, ptr %l186, !tbaa !23
  %t500 = lshr i32 %t499, 16
  %t501 = and i32 %t499, 65535
  %t502 = icmp eq i32 %t500, 1
  %t503 = select i1 %t502, i32 1, i32 0
  %t504 = icmp eq i32 %t499, 0
  %t505 = shl i32 %t503, 16
  %t506 = or i32 %t505, %t501
  %t507 = select i1 %t504, i32 0, i32 %t506
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i64, ptr %l2, !tbaa !24
  %t512 = getelementptr %"compiler/parse:Parser", ptr %t508, i32 0, i32 22
  store i64 %t509, ptr %t512, !tbaa !24
  %t514 = insertvalue { i32, ptr } zeroinitializer, i32 %t507, 0
  store { i32, ptr } %t514, ptr %rv
  br label %ret
bb77:
  %t515 = load ptr, ptr %l182, !tbaa !29
  store ptr %t515, ptr %l8, !tbaa !29
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l8, !tbaa !29
  %t520 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %t516, ptr %t517)
  %t521 = extractvalue { i32, ptr } %t520, 1
  %t522 = extractvalue { i32, ptr } %t520, 0
  store i32 %t522, ptr %l194
  %t523 = icmp ne i32 %t522, 0
  br i1 %t523, label %bb79, label %ok.524
ok.524:
  store ptr %t521, ptr %l193
  br label %bb78
bb78:
  %t525 = load ptr, ptr %l193, !tbaa !29
  store ptr %t525, ptr %l190, !tbaa !29
  br label %bb80
bb79:
  %t526 = load i32, ptr %l194, !tbaa !23
  %t527 = lshr i32 %t526, 16
  %t528 = and i32 %t526, 65535
  %t529 = icmp eq i32 %t527, 1
  %t530 = select i1 %t529, i32 1, i32 0
  %t531 = icmp eq i32 %t526, 0
  %t532 = shl i32 %t530, 16
  %t533 = or i32 %t532, %t528
  %t534 = select i1 %t531, i32 0, i32 %t533
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load i64, ptr %l2, !tbaa !24
  %t539 = getelementptr %"compiler/parse:Parser", ptr %t535, i32 0, i32 22
  store i64 %t536, ptr %t539, !tbaa !24
  %t541 = insertvalue { i32, ptr } zeroinitializer, i32 %t534, 0
  store { i32, ptr } %t541, ptr %rv
  br label %ret
bb80:
  %t542 = load ptr, ptr %l190, !tbaa !29
  store ptr %t542, ptr %l8, !tbaa !29
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/parse:Parser", ptr %t543, i32 0, i32 22
  %t546 = load i64, ptr %t545, !tbaa !24
  store i64 %t546, ptr %l18, !tbaa !24
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %t548, i1 false)
  %t551 = extractvalue { i32, { i64, ptr } } %t550, 1
  %t552 = extractvalue { i32, { i64, ptr } } %t550, 0
  store i32 %t552, ptr %l203
  %t553 = icmp ne i32 %t552, 0
  br i1 %t553, label %bb82, label %ok.554
ok.554:
  store { i64, ptr } %t551, ptr %l202
  br label %bb81
bb81:
  %t555 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t555, ptr %l200, !tbaa !27
  br label %bb83
bb82:
  %t556 = load i32, ptr %l203, !tbaa !23
  %t557 = lshr i32 %t556, 16
  %t558 = and i32 %t556, 65535
  %t559 = icmp eq i32 %t557, 1
  %t560 = select i1 %t559, i32 1, i32 0
  %t561 = icmp eq i32 %t556, 0
  %t562 = shl i32 %t560, 16
  %t563 = or i32 %t562, %t558
  %t564 = select i1 %t561, i32 0, i32 %t563
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i64, ptr %l2, !tbaa !24
  %t569 = getelementptr %"compiler/parse:Parser", ptr %t565, i32 0, i32 22
  store i64 %t566, ptr %t569, !tbaa !24
  %t571 = insertvalue { i32, ptr } zeroinitializer, i32 %t564, 0
  store { i32, ptr } %t571, ptr %rv
  br label %ret
bb83:
  %t572 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t572, ptr %l19, !tbaa !27
  %t573 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t577 = icmp eq i64 %t575, 0
  br i1 %t577, label %bb84, label %bb85
bb84:
  %t579 = load i64, ptr %l18, !tbaa !24
  %t581 = icmp sge i64 %t579, 0
  store i1 %t581, ptr %l210, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb86
bb86:
  %t583 = load i1, ptr %l210, !tbaa !21
  br i1 %t583, label %bb87, label %bb88
bb87:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t584, i64 %t585)
  br label %bb89
bb88:
  br label %bb90
bb89:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i64, ptr %l2, !tbaa !24
  %t592 = getelementptr %"compiler/parse:Parser", ptr %t588, i32 0, i32 22
  store i64 %t589, ptr %t592, !tbaa !24
  %t594 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t594, ptr %rv
  br label %ret
bb90:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l1, !tbaa !23
  %t599 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t595, i32 %t596)
  store %"compiler/source:Span" %t599, ptr %l220
  br label %bb91
bb91:
  %t600 = load ptr, ptr %l8, !tbaa !29
  %t601 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t602
  %t603 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 0
  store i64 22, ptr %t603
  %t604 = load %"compiler/source:Span", ptr %l220
  %t605 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t604, 0
  %t607 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t605, ptr %t600, 1
  %t609 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t607, { i64, ptr } %t601, 2
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t609, ptr %t610
  %t611 = load { i64, [5 x i64] }, ptr %t602
  %t613 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t611, ptr %t613
  store ptr %t613, ptr %l20, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l1, !tbaa !23
  %t619 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t615, i32 %t616)
  store %"compiler/source:Span" %t619, ptr %l227
  br label %bb92
bb92:
  %t620 = load %"compiler/source:Span", ptr %l227
  store %"compiler/source:Span" %t620, ptr %l21
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t621)
  store i32 %t623, ptr %l229
  %t624 = icmp ne i32 %t623, 0
  br i1 %t624, label %bb94, label %ok.625
ok.625:
  br label %bb93
bb93:
  br label %bb95
bb94:
  %t626 = load i32, ptr %l229, !tbaa !23
  %t627 = lshr i32 %t626, 16
  %t628 = and i32 %t626, 65535
  %t629 = icmp eq i32 %t627, 1
  %t630 = select i1 %t629, i32 1, i32 0
  %t631 = icmp eq i32 %t626, 0
  %t632 = shl i32 %t630, 16
  %t633 = or i32 %t632, %t628
  %t634 = select i1 %t631, i32 0, i32 %t633
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load i64, ptr %l2, !tbaa !24
  %t639 = getelementptr %"compiler/parse:Parser", ptr %t635, i32 0, i32 22
  store i64 %t636, ptr %t639, !tbaa !24
  %t641 = insertvalue { i32, ptr } zeroinitializer, i32 %t634, 0
  store { i32, ptr } %t641, ptr %rv
  br label %ret
bb95:
  %t642 = load %"compiler/source:Span", ptr %l21
  %t643 = load ptr, ptr %l20, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t644
  %t645 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 0
  store i64 0, ptr %t645
  %t647 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t642, 0
  %t649 = insertvalue { %"compiler/source:Span", ptr } %t647, ptr %t643, 1
  %t650 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t649, ptr %t650
  %t651 = load { i64, [4 x i64] }, ptr %t644
  %t653 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t651, ptr %t653
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load i64, ptr %l2, !tbaa !24
  %t658 = getelementptr %"compiler/parse:Parser", ptr %t654, i32 0, i32 22
  store i64 %t655, ptr %t658, !tbaa !24
  %t660 = insertvalue { i32, ptr } zeroinitializer, ptr %t653, 1
  store { i32, ptr } %t660, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i32
  %l58 = alloca i32
  %l65 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 11
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 11
  store i1 true, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 18
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 19
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l3, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 18
  store i1 false, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 19
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 32
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l19
  br label %bb4
bb4:
  %t46 = load i64, ptr %l19, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t47, i32 59)
  store i1 %t50, ptr %l22
  br label %bb6
bb6:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb7, label %bb8
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 32
  store ptr %t54, ptr %l24, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %t55)
  %t58 = extractvalue { i32, ptr } %t57, 1
  %t59 = extractvalue { i32, ptr } %t57, 0
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb10, label %ok.61
ok.61:
  store ptr %t58, ptr %l27
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t62 = load ptr, ptr %l27, !tbaa !29
  store ptr %t62, ptr %l25, !tbaa !29
  br label %bb11
bb10:
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i1, ptr %l3, !tbaa !21
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 19
  store i1 %t73, ptr %t76, !tbaa !21
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb11:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t79, ptr %t80)
  br label %bb12
bb12:
  br label %bb29
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 32
  store ptr %t83, ptr %l33, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb15, label %ok.90
ok.90:
  store ptr %t87, ptr %l36
  br label %bb14
bb14:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb16
bb15:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i1, ptr %l3, !tbaa !21
  %t105 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 19
  store i1 %t102, ptr %t105, !tbaa !21
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t100, 0
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb16:
  %t108 = load ptr, ptr %l33, !tbaa !29
  %t109 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t108, ptr %t109)
  br label %bb17
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t113 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t110, i32 59)
  store i1 %t113, ptr %l43
  br label %bb18
bb18:
  %t114 = load i1, ptr %l43, !tbaa !21
  br i1 %t114, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t115, i32 81)
  %t119 = extractvalue { i32, i1 } %t118, 1
  %t120 = extractvalue { i32, i1 } %t118, 0
  store i32 %t120, ptr %l48
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb23, label %ok.122
ok.122:
  store i1 %t119, ptr %l47
  br label %bb22
bb22:
  %t123 = load i1, ptr %l47, !tbaa !21
  store i1 %t123, ptr %l44, !tbaa !21
  br label %bb24
bb23:
  %t124 = load i32, ptr %l48, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l3, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 19
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t132, 0
  store { i32, { i64, ptr } } %t139, ptr %rv
  br label %ret
bb24:
  %t140 = load i1, ptr %l44, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb5
bb29:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i1, ptr %l2, !tbaa !21
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 18
  store i1 %t144, ptr %t147, !tbaa !21
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l1, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 11
  store i1 %t149, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t153)
  store i32 %t155, ptr %l58
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb31, label %ok.157
ok.157:
  br label %bb30
bb30:
  br label %bb32
bb31:
  %t158 = load i32, ptr %l58, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i1, ptr %l3, !tbaa !21
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t167, i32 0, i32 19
  store i1 %t168, ptr %t171, !tbaa !21
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t166, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/parse:Parser", ptr %t174, i32 0, i32 32
  %t177 = load i64, ptr %l4, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l65
  br label %bb33
bb33:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i1, ptr %l3, !tbaa !21
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 19
  store i1 %t182, ptr %t185, !tbaa !21
  %t186 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t187 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t186, 1
  store { i32, { i64, ptr } } %t187, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 2
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l69 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l79 = alloca i1
  %l82 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l93 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l107 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca i32
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i32
  %l143 = alloca i1
  %l145 = alloca i1
  %l147 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i32
  %l153 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i32
  %l158 = alloca i32
  %l159 = alloca i32
  %l163 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i32
  %l168 = alloca i32
  %l169 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i32
  %l178 = alloca i32
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t43 = alloca { i64, [5 x i64] }, align 8
  %t100 = alloca { i64, [5 x i64] }, align 8
  %t150 = alloca { i64, [5 x i64] }, align 8
  %t275 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i32, ptr %l13, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i32, ptr %l15
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 38 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l19
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %t17, i1 false, i1 true, i1 false)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l23
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23
ok.23:
  store ptr %t20, ptr %l22
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l22, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  br label %bb9
bb8:
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  %t35 = insertvalue { i32, ptr } zeroinitializer, i32 %t33, 0
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  store ptr %t36, ptr %l3, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t37, i32 %t38)
  store %"compiler/source:Span" %t41, ptr %l27
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 0
  store i64 1, ptr %t44
  %t45 = load %"compiler/source:Span", ptr %l27
  %t46 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t45, 0
  %t48 = insertvalue { %"compiler/source:Span", ptr } %t46, ptr %t42, 1
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t48, ptr %t49
  %t50 = load { i64, [5 x i64] }, ptr %t43
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t50, ptr %t52
  %t54 = insertvalue { i32, ptr } zeroinitializer, ptr %t52, 1
  store { i32, ptr } %t54, ptr %rv
  br label %ret
bb11:
  %t55 = load i32, ptr %l2
  %t57 = trunc i64 36 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t60 = load i32, ptr %l2
  %t62 = trunc i64 35 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t65 = load i32, ptr %l2
  %t67 = trunc i64 37 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %t70)
  %t73 = extractvalue { i32, ptr } %t72, 1
  %t74 = extractvalue { i32, ptr } %t72, 0
  store i32 %t74, ptr %l40
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76
ok.76:
  store ptr %t73, ptr %l39
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l39, !tbaa !29
  store ptr %t77, ptr %l37, !tbaa !29
  br label %bb21
bb20:
  %t78 = load i32, ptr %l40, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  %t88 = insertvalue { i32, ptr } zeroinitializer, i32 %t86, 0
  store { i32, ptr } %t88, ptr %rv
  br label %ret
bb21:
  %t89 = load ptr, ptr %l37, !tbaa !29
  store ptr %t89, ptr %l4, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t90, i32 %t91)
  store %"compiler/source:Span" %t94, ptr %l44
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  br i1 %t97, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_47198c3f9d8413cf_be7184982b6f0763)
  unreachable
bb24:
  br label %bb25
bb25:
  %t99 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 0
  store i64 2, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l44
  %t103 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t102, 0
  %t105 = insertvalue { %"compiler/source:Span", ptr } %t103, ptr %t99, 1
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t105, ptr %t106
  %t107 = load { i64, [5 x i64] }, ptr %t100
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t107, ptr %t109
  %t111 = insertvalue { i32, ptr } zeroinitializer, ptr %t109, 1
  store { i32, ptr } %t111, ptr %rv
  br label %ret
bb26:
  %t112 = load i32, ptr %l2
  %t114 = trunc i64 1 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb69
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %t117)
  store i1 %t119, ptr %l53
  br label %bb30
bb30:
  %t120 = load i1, ptr %l53, !tbaa !21
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t121)
  store i32 %t123, ptr %l55
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %t124)
  %t127 = extractvalue { i32, ptr } %t126, 1
  %t128 = extractvalue { i32, ptr } %t126, 0
  store i32 %t128, ptr %l59
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb35, label %ok.130
ok.130:
  store ptr %t127, ptr %l58
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l58, !tbaa !29
  store ptr %t131, ptr %l56, !tbaa !29
  br label %bb36
bb35:
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t132, 0
  %t138 = shl i32 %t136, 16
  %t139 = or i32 %t138, %t134
  %t140 = select i1 %t137, i32 0, i32 %t139
  %t142 = insertvalue { i32, ptr } zeroinitializer, i32 %t140, 0
  store { i32, ptr } %t142, ptr %rv
  br label %ret
bb36:
  %t143 = load ptr, ptr %l56, !tbaa !29
  store ptr %t143, ptr %l5, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l1, !tbaa !23
  %t148 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t144, i32 %t145)
  store %"compiler/source:Span" %t148, ptr %l63
  br label %bb37
bb37:
  %t149 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 0
  store i64 5, ptr %t151
  %t152 = load %"compiler/source:Span", ptr %l63
  %t153 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t152, 0
  %t155 = insertvalue { %"compiler/source:Span", ptr } %t153, ptr %t149, 1
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t155, ptr %t156
  %t157 = load { i64, [5 x i64] }, ptr %t150
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t157, ptr %t159
  %t161 = insertvalue { i32, ptr } zeroinitializer, ptr %t159, 1
  store { i32, ptr } %t161, ptr %rv
  br label %ret
bb38:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 35
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t164)
  store i64 %t166, ptr %l69
  br label %bb39
bb39:
  %t167 = load i64, ptr %l69, !tbaa !24
  store i64 %t167, ptr %l6, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/parse:Parser", ptr %t168, i32 0, i32 35
  store ptr %t170, ptr %l71, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t171)
  %t174 = extractvalue { i32, i32 } %t173, 1
  %t175 = extractvalue { i32, i32 } %t173, 0
  store i32 %t175, ptr %l75
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb41, label %ok.177
ok.177:
  store i32 %t174, ptr %l74
  br label %bb40
bb40:
  %t178 = load i32, ptr %l74, !tbaa !23
  store i32 %t178, ptr %l72, !tbaa !23
  br label %bb42
bb41:
  %t179 = load i32, ptr %l75, !tbaa !23
  %t180 = lshr i32 %t179, 16
  %t181 = and i32 %t179, 65535
  %t182 = icmp eq i32 %t180, 1
  %t183 = select i1 %t182, i32 1, i32 0
  %t184 = icmp eq i32 %t179, 0
  %t185 = shl i32 %t183, 16
  %t186 = or i32 %t185, %t181
  %t187 = select i1 %t184, i32 0, i32 %t186
  %t189 = insertvalue { i32, ptr } zeroinitializer, i32 %t187, 0
  store { i32, ptr } %t189, ptr %rv
  br label %ret
bb42:
  %t190 = load ptr, ptr %l71, !tbaa !29
  %t191 = load i32, ptr %l72, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t190, i32 %t191)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t195 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t192, i32 58)
  store i1 %t195, ptr %l79
  br label %bb45
bb45:
  %t196 = load i1, ptr %l79, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb46, label %bb47
bb46:
  br label %bb55
bb47:
  br label %bb48
bb48:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t199)
  store i32 %t201, ptr %l82
  br label %bb49
bb49:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 35
  store ptr %t204, ptr %l84, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t205)
  %t208 = extractvalue { i32, i32 } %t207, 1
  %t209 = extractvalue { i32, i32 } %t207, 0
  store i32 %t209, ptr %l88
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb51, label %ok.211
ok.211:
  store i32 %t208, ptr %l87
  br label %bb50
bb50:
  %t212 = load i32, ptr %l87, !tbaa !23
  store i32 %t212, ptr %l85, !tbaa !23
  br label %bb52
bb51:
  %t213 = load i32, ptr %l88, !tbaa !23
  %t214 = lshr i32 %t213, 16
  %t215 = and i32 %t213, 65535
  %t216 = icmp eq i32 %t214, 1
  %t217 = select i1 %t216, i32 1, i32 0
  %t218 = icmp eq i32 %t213, 0
  %t219 = shl i32 %t217, 16
  %t220 = or i32 %t219, %t215
  %t221 = select i1 %t218, i32 0, i32 %t220
  %t223 = insertvalue { i32, ptr } zeroinitializer, i32 %t221, 0
  store { i32, ptr } %t223, ptr %rv
  br label %ret
bb52:
  %t224 = load ptr, ptr %l84, !tbaa !29
  %t225 = load i32, ptr %l85, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t224, i32 %t225)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb44
bb55:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 35
  %t229 = load i64, ptr %l6, !tbaa !24
  %t232 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t228, i64 %t229)
  store { i64, ptr } %t232, ptr %l93
  br label %bb56
bb56:
  %t233 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t233, ptr %l7, !tbaa !27
  %t234 = icmp sge i64 0, 0
  br i1 %t234, label %bb57, label %bb58
bb57:
  %t236 = icmp sle i64 0, 1152921504606846975
  br i1 %t236, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb59:
  %t238 = mul i64 0, 8
  %t239 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 0, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l8, !tbaa !27
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t243, i32 79)
  store i1 %t246, ptr %l99
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_4b26d93c159ce468_272ef8e9c938d194)
  unreachable
bb61:
  %t247 = load i1, ptr %l99, !tbaa !21
  br i1 %t247, label %bb62, label %bb63
bb62:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %t248)
  %t251 = extractvalue { i32, { i64, ptr } } %t250, 1
  %t252 = extractvalue { i32, { i64, ptr } } %t250, 0
  store i32 %t252, ptr %l103
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb65, label %ok.254
ok.254:
  store { i64, ptr } %t251, ptr %l102
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t255 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t255, ptr %l100, !tbaa !27
  br label %bb66
bb65:
  %t256 = load i32, ptr %l103, !tbaa !23
  %t257 = lshr i32 %t256, 16
  %t258 = and i32 %t256, 65535
  %t259 = icmp eq i32 %t257, 1
  %t260 = select i1 %t259, i32 1, i32 0
  %t261 = icmp eq i32 %t256, 0
  %t262 = shl i32 %t260, 16
  %t263 = or i32 %t262, %t258
  %t264 = select i1 %t261, i32 0, i32 %t263
  %t266 = insertvalue { i32, ptr } zeroinitializer, i32 %t264, 0
  store { i32, ptr } %t266, ptr %rv
  br label %ret
bb66:
  %t267 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t267, ptr %l8, !tbaa !27
  br label %bb67
bb67:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i32, ptr %l1, !tbaa !23
  %t272 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t268, i32 %t269)
  store %"compiler/source:Span" %t272, ptr %l107
  br label %bb68
bb68:
  %t273 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 0
  store i64 0, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l107
  %t278 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t277, 0
  %t280 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t278, { i64, ptr } %t273, 1
  %t282 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t280, { i64, ptr } %t274, 2
  %t283 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t282, ptr %t283
  %t284 = load { i64, [5 x i64] }, ptr %t275
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t284, ptr %t286
  %t288 = insertvalue { i32, ptr } zeroinitializer, ptr %t286, 1
  store { i32, ptr } %t288, ptr %rv
  br label %ret
bb69:
  %t289 = load i32, ptr %l2
  %t291 = trunc i64 90 to i32
  %t292 = icmp eq i32 %t289, %t291
  br i1 %t292, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb99
bb72:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/parse:Parser", ptr %t294, i32 0, i32 42
  store ptr %t296, ptr %l115, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/parse:Parser", ptr %t298, i32 0, i32 6
  %t301 = load i64, ptr %t300, !tbaa !24
  %t304 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t297, i64 %t301)
  store i64 %t304, ptr %l119
  br label %bb73
bb73:
  %t305 = load ptr, ptr %l115, !tbaa !29
  %t306 = load i64, ptr %l119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t305, i64 %t306)
  br label %bb74
bb74:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t307)
  store i32 %t309, ptr %l121
  br label %bb75
bb75:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 19
  %t313 = load i1, ptr %t312, !tbaa !21
  store i1 %t313, ptr %l9, !tbaa !21
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/parse:Parser", ptr %t315, i32 0, i32 18
  %t318 = load i1, ptr %t317, !tbaa !21
  store i1 %t318, ptr %l10, !tbaa !21
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/parse:Parser", ptr %t320, i32 0, i32 19
  store i1 false, ptr %t322, !tbaa !21
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/parse:Parser", ptr %t323, i32 0, i32 18
  store i1 false, ptr %t325, !tbaa !21
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %t326)
  %t329 = extractvalue { i32, ptr } %t328, 1
  %t330 = extractvalue { i32, ptr } %t328, 0
  store i32 %t330, ptr %l131
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb77, label %ok.332
ok.332:
  store ptr %t329, ptr %l130
  br label %bb76
bb76:
  %t333 = load ptr, ptr %l130, !tbaa !29
  store ptr %t333, ptr %l128, !tbaa !29
  br label %bb79
bb77:
  br label %bb78
bb78:
  call void @__olang_ert_req_clear()
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i1, ptr %l9, !tbaa !21
  %t338 = getelementptr %"compiler/parse:Parser", ptr %t334, i32 0, i32 19
  store i1 %t335, ptr %t338, !tbaa !21
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i1, ptr %l10, !tbaa !21
  %t343 = getelementptr %"compiler/parse:Parser", ptr %t339, i32 0, i32 18
  store i1 %t340, ptr %t343, !tbaa !21
  %t345 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t345, ptr %rv
  br label %ret
bb79:
  %t346 = load ptr, ptr %l128, !tbaa !29
  store ptr %t346, ptr %l11, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i1, ptr %l9, !tbaa !21
  %t351 = getelementptr %"compiler/parse:Parser", ptr %t347, i32 0, i32 19
  store i1 %t348, ptr %t351, !tbaa !21
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i1, ptr %l10, !tbaa !21
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t352, i32 0, i32 18
  store i1 %t353, ptr %t356, !tbaa !21
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t360 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t357, i32 91)
  store i1 %t360, ptr %l143
  br label %bb80
bb80:
  %t361 = load i1, ptr %l143, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb81, label %bb82
bb81:
  %t364 = load ptr, ptr %l11, !tbaa !29
  %t366 = call i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %t364)
  store i1 %t366, ptr %l147
  br label %bb83
bb82:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb84
bb83:
  %t367 = load i1, ptr %l147, !tbaa !21
  %t368 = xor i1 %t367, true
  store i1 %t368, ptr %l145, !tbaa !21
  br label %bb84
bb84:
  %t370 = load i1, ptr %l145, !tbaa !21
  br i1 %t370, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s9
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l149, !tbaa !29
  %t372 = load i32, ptr %l1, !tbaa !23
  store i32 %t372, ptr %l150, !tbaa !23
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/parse:Parser", ptr %t373, i32 0, i32 10
  %t376 = load i32, ptr %t375, !tbaa !23
  store i32 %t376, ptr %l152, !tbaa !23
  %t377 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s9)
  store %"compiler/msgs:Msg" %t377, ptr %l153
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t378 = load ptr, ptr %l149, !tbaa !29
  %t379 = load i32, ptr %l150, !tbaa !23
  %t380 = load i32, ptr %l152, !tbaa !23
  %t381 = load %"compiler/msgs:Msg", ptr %l153
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s9, ptr %t378, i32 %t379, i32 %t380, %"compiler/msgs:Msg" %t381)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  %t383 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t383, ptr %rv
  br label %ret
bb89:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t387 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t384, i32 91)
  %t388 = extractvalue { i32, i32 } %t387, 1
  %t389 = extractvalue { i32, i32 } %t387, 0
  store i32 %t389, ptr %l159
  %t390 = icmp ne i32 %t389, 0
  br i1 %t390, label %bb91, label %ok.391
ok.391:
  store i32 %t388, ptr %l158
  br label %bb90
bb90:
  %t392 = load i32, ptr %l158, !tbaa !23
  store i32 %t392, ptr %l155, !tbaa !23
  br label %bb92
bb91:
  %t393 = load i32, ptr %l159, !tbaa !23
  %t394 = lshr i32 %t393, 16
  %t395 = and i32 %t393, 65535
  %t396 = icmp eq i32 %t394, 1
  %t397 = select i1 %t396, i32 1, i32 0
  %t398 = icmp eq i32 %t393, 0
  %t399 = shl i32 %t397, 16
  %t400 = or i32 %t399, %t395
  %t401 = select i1 %t398, i32 0, i32 %t400
  %t403 = insertvalue { i32, ptr } zeroinitializer, i32 %t401, 0
  store { i32, ptr } %t403, ptr %rv
  br label %ret
bb92:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l11, !tbaa !29
  %t408 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v0, ptr %t404, ptr %t405)
  store i1 %t408, ptr %l163
  br label %bb93
bb93:
  %t409 = load i1, ptr %l163, !tbaa !21
  %t410 = xor i1 %t409, true
  br i1 %t410, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s10
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l165, !tbaa !29
  %t413 = load i32, ptr %l1, !tbaa !23
  store i32 %t413, ptr %l166, !tbaa !23
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/parse:Parser", ptr %t414, i32 0, i32 10
  %t417 = load i32, ptr %t416, !tbaa !23
  store i32 %t417, ptr %l168, !tbaa !23
  %t418 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %s10)
  store %"compiler/msgs:Msg" %t418, ptr %l169
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t419 = load ptr, ptr %l165, !tbaa !29
  %t420 = load i32, ptr %l166, !tbaa !23
  %t421 = load i32, ptr %l168, !tbaa !23
  %t422 = load %"compiler/msgs:Msg", ptr %l169
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %s10, ptr %t419, i32 %t420, i32 %t421, %"compiler/msgs:Msg" %t422)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s10)
  %t424 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t424, ptr %rv
  br label %ret
bb98:
  %t425 = load ptr, ptr %l11, !tbaa !29
  %t427 = insertvalue { i32, ptr } zeroinitializer, ptr %t425, 1
  store { i32, ptr } %t427, ptr %rv
  br label %ret
bb99:
  %t428 = load i32, ptr %l2
  %t430 = trunc i64 79 to i32
  %t431 = icmp eq i32 %t428, %t430
  br i1 %t431, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb106
bb102:
  store %olang.scope zeroinitializer, ptr %s11
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s11, ptr %t433, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i32 %t435, ptr %l175
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb104, label %ok.437
ok.437:
  br label %bb103
bb103:
  br label %bb105
bb104:
  %t438 = load i32, ptr %l175, !tbaa !23
  %t439 = lshr i32 %t438, 16
  %t440 = and i32 %t438, 65535
  %t441 = icmp eq i32 %t439, 1
  %t442 = select i1 %t441, i32 1, i32 0
  %t443 = icmp eq i32 %t438, 0
  %t444 = shl i32 %t442, 16
  %t445 = or i32 %t444, %t440
  %t446 = select i1 %t443, i32 0, i32 %t445
  call void @__olang_scope_close(ptr %s11)
  %t448 = insertvalue { i32, ptr } zeroinitializer, i32 %t446, 0
  store { i32, ptr } %t448, ptr %rv
  br label %ret
bb105:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb106:
  store %olang.scope zeroinitializer, ptr %s12
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s12, ptr %t449, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i32 %t451, ptr %l178
  %t452 = icmp ne i32 %t451, 0
  br i1 %t452, label %bb108, label %ok.453
ok.453:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t454 = load i32, ptr %l178, !tbaa !23
  %t455 = lshr i32 %t454, 16
  %t456 = and i32 %t454, 65535
  %t457 = icmp eq i32 %t455, 1
  %t458 = select i1 %t457, i32 1, i32 0
  %t459 = icmp eq i32 %t454, 0
  %t460 = shl i32 %t458, 16
  %t461 = or i32 %t460, %t456
  %t462 = select i1 %t459, i32 0, i32 %t461
  call void @__olang_scope_close(ptr %s12)
  %t464 = insertvalue { i32, ptr } zeroinitializer, i32 %t462, 0
  store { i32, ptr } %t464, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s12)
  br label %bb110
bb110:
  call void @__olang_check_failed(ptr @olang_loc_31e39d55c126667c_eaaf5fcb81f21700)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca { i32, ptr }
  %t48 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t5, i32 40)
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %t10)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l12
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb4, label %ok.16
ok.16:
  store ptr %t13, ptr %l11
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l11, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  br label %bb5
bb4:
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb5:
  %t29 = load ptr, ptr %l9, !tbaa !29
  store ptr %t29, ptr %l3, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t36 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %t30, i32 %t31, ptr %t32)
  store ptr %t36, ptr %l17
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l17, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t40, i32 %t41)
  store %"compiler/source:Span" %t44, ptr %l21
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = load i1, ptr %l2, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 0
  store i64 4, ptr %t49
  %t50 = load %"compiler/source:Span", ptr %l21
  %t51 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t50, 0
  %t53 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t51, ptr %t45, 1
  %t55 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t53, i1 %t47, 2
  %t56 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t55, i1 false, 3
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t56, ptr %t57
  %t58 = load { i64, [5 x i64] }, ptr %t48
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t58, ptr %t60
  %t62 = insertvalue { i32, ptr } zeroinitializer, ptr %t60, 1
  store { i32, ptr } %t62, ptr %rv
  br label %ret
bb10:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = insertvalue { i32, ptr } zeroinitializer, ptr %t63, 1
  store { i32, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i32
  %l46 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l62 = alloca i32
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca %"compiler/source:Span"
  %l81 = alloca i1
  %l83 = alloca i32
  %l87 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca i32
  %l103 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l123 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca i32
  %l134 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca i32
  %rv = alloca { i32, ptr }
  %t61 = alloca { i64, [5 x i64] }, align 8
  %t111 = alloca { i64, [5 x i64] }, align 8
  %t179 = alloca { i64, [5 x i64] }, align 8
  %t347 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load i32, ptr %l13
  store i32 %t8, ptr %l2
  %t9 = load i32, ptr %l2
  %t11 = trunc i64 49 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t14)
  store i32 %t16, ptr %l17
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t17)
  store i32 %t19, ptr %l19
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb8, label %ok.21
ok.21:
  br label %bb7
bb7:
  br label %bb9
bb8:
  %t22 = load i32, ptr %l19, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  %t32 = insertvalue { i32, ptr } zeroinitializer, i32 %t30, 0
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %t33, i64 4)
  %t36 = extractvalue { i32, ptr } %t35, 1
  %t37 = extractvalue { i32, ptr } %t35, 0
  store i32 %t37, ptr %l24
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb11, label %ok.39
ok.39:
  store ptr %t36, ptr %l23
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l23, !tbaa !29
  store ptr %t40, ptr %l21, !tbaa !29
  br label %bb13
bb11:
  %t41 = load i32, ptr %l24, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  store i32 %t49, ptr %l25, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t50)
  br label %bb12
bb12:
  %t52 = load i32, ptr %l25, !tbaa !23
  %t53 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb13:
  %t54 = load ptr, ptr %l21, !tbaa !29
  store ptr %t54, ptr %l3, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t55, i32 %t56)
  store %"compiler/source:Span" %t59, ptr %l29
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l3, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 0
  store i64 3, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l29
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t63, 0
  %t66 = insertvalue { %"compiler/source:Span", i32, ptr } %t64, i32 49, 1
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } %t66, ptr %t60, 2
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t68, ptr %t69
  %t70 = load { i64, [5 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t70, ptr %t72
  store ptr %t72, ptr %l33, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t73)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l33, !tbaa !29
  %t76 = insertvalue { i32, ptr } zeroinitializer, ptr %t75, 1
  store { i32, ptr } %t76, ptr %rv
  br label %ret
bb16:
  %t77 = load i32, ptr %l2
  %t79 = trunc i64 18 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t82)
  store i32 %t84, ptr %l38
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t85)
  %t88 = extractvalue { i32, ptr } %t87, 1
  %t89 = extractvalue { i32, ptr } %t87, 0
  store i32 %t89, ptr %l42
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb22, label %ok.91
ok.91:
  store ptr %t88, ptr %l41
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l41, !tbaa !29
  store ptr %t92, ptr %l39, !tbaa !29
  br label %bb23
bb22:
  %t93 = load i32, ptr %l42, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  %t103 = insertvalue { i32, ptr } zeroinitializer, i32 %t101, 0
  store { i32, ptr } %t103, ptr %rv
  br label %ret
bb23:
  %t104 = load ptr, ptr %l39, !tbaa !29
  store ptr %t104, ptr %l4, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t105, i32 %t106)
  store %"compiler/source:Span" %t109, ptr %l46
  br label %bb24
bb24:
  %t110 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 0
  store i64 3, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l46
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t113, 0
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, i32 18, 1
  %t118 = insertvalue { %"compiler/source:Span", i32, ptr } %t116, ptr %t110, 2
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t118, ptr %t119
  %t120 = load { i64, [5 x i64] }, ptr %t111
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t120, ptr %t122
  %t124 = insertvalue { i32, ptr } zeroinitializer, ptr %t122, 1
  store { i32, ptr } %t124, ptr %rv
  br label %ret
bb25:
  %t125 = load i32, ptr %l2
  %t127 = trunc i64 52 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t130 = load i32, ptr %l2
  %t132 = trunc i64 86 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t135 = load i32, ptr %l2
  %t137 = trunc i64 73 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t140 = load i32, ptr %l2
  %t142 = trunc i64 74 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb41
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t145)
  store i32 %t147, ptr %l60
  br label %bb35
bb35:
  %t148 = load i32, ptr %l60
  store i32 %t148, ptr %l5
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l62
  br label %bb36
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %t152)
  %t155 = extractvalue { i32, ptr } %t154, 1
  %t156 = extractvalue { i32, ptr } %t154, 0
  store i32 %t156, ptr %l66
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb38, label %ok.158
ok.158:
  store ptr %t155, ptr %l65
  br label %bb37
bb37:
  %t159 = load ptr, ptr %l65, !tbaa !29
  store ptr %t159, ptr %l63, !tbaa !29
  br label %bb39
bb38:
  %t160 = load i32, ptr %l66, !tbaa !23
  %t161 = lshr i32 %t160, 16
  %t162 = and i32 %t160, 65535
  %t163 = icmp eq i32 %t161, 1
  %t164 = select i1 %t163, i32 1, i32 0
  %t165 = icmp eq i32 %t160, 0
  %t166 = shl i32 %t164, 16
  %t167 = or i32 %t166, %t162
  %t168 = select i1 %t165, i32 0, i32 %t167
  %t170 = insertvalue { i32, ptr } zeroinitializer, i32 %t168, 0
  store { i32, ptr } %t170, ptr %rv
  br label %ret
bb39:
  %t171 = load ptr, ptr %l63, !tbaa !29
  store ptr %t171, ptr %l6, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t172, i32 %t173)
  store %"compiler/source:Span" %t176, ptr %l70
  br label %bb40
bb40:
  %t177 = load i32, ptr %l5
  %t178 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 0
  store i64 3, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l70
  %t182 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t181, 0
  %t184 = insertvalue { %"compiler/source:Span", i32, ptr } %t182, i32 %t177, 1
  %t186 = insertvalue { %"compiler/source:Span", i32, ptr } %t184, ptr %t178, 2
  %t187 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t186, ptr %t187
  %t188 = load { i64, [5 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t188, ptr %t190
  %t192 = insertvalue { i32, ptr } zeroinitializer, ptr %t190, 1
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb41:
  %t193 = load i32, ptr %l2
  %t195 = trunc i64 5 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  %t198 = load i32, ptr %l2
  %t200 = trunc i64 87 to i32
  %t201 = icmp eq i32 %t198, %t200
  br i1 %t201, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb91
bb46:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t206 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t203, i32 5)
  store i1 %t206, ptr %l81
  br label %bb47
bb47:
  %t207 = load i1, ptr %l81, !tbaa !21
  br i1 %t207, label %bb48, label %bb49
bb48:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t208, i64 1)
  store i32 %t210, ptr %l83
  br label %bb50
bb49:
  br label %bb60
bb50:
  %t211 = load i32, ptr %l83
  store i32 %t211, ptr %l7
  %t212 = load i32, ptr %l7
  %t214 = trunc i64 5 to i32
  %t215 = icmp eq i32 %t212, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb51, label %bb52
bb51:
  %t219 = load i32, ptr %l7
  %t221 = trunc i64 87 to i32
  %t222 = icmp eq i32 %t219, %t221
  %t224 = xor i1 %t222, true
  store i1 %t224, ptr %l87, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t226 = load i1, ptr %l87, !tbaa !21
  br i1 %t226, label %bb54, label %bb55
bb54:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t227)
  %t230 = extractvalue { i32, ptr } %t229, 1
  %t231 = extractvalue { i32, ptr } %t229, 0
  store i32 %t231, ptr %l94
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb57, label %ok.233
ok.233:
  store ptr %t230, ptr %l93
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t234 = load ptr, ptr %l93, !tbaa !29
  store ptr %t234, ptr %l91, !tbaa !29
  br label %bb58
bb57:
  %t235 = load i32, ptr %l94, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 1, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  %t245 = insertvalue { i32, ptr } zeroinitializer, i32 %t243, 0
  store { i32, ptr } %t245, ptr %rv
  br label %ret
bb58:
  %t246 = load ptr, ptr %l91, !tbaa !29
  %t247 = insertvalue { i32, ptr } zeroinitializer, ptr %t246, 1
  store { i32, ptr } %t247, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %t248)
  %t251 = extractvalue { i32, ptr } %t250, 1
  %t252 = extractvalue { i32, ptr } %t250, 0
  store i32 %t252, ptr %l99
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb62, label %ok.254
ok.254:
  store ptr %t251, ptr %l98
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l98, !tbaa !29
  store ptr %t255, ptr %l96, !tbaa !29
  br label %bb63
bb62:
  %t256 = load i32, ptr %l99, !tbaa !23
  %t257 = lshr i32 %t256, 16
  %t258 = and i32 %t256, 65535
  %t259 = icmp eq i32 %t257, 1
  %t260 = select i1 %t259, i32 1, i32 0
  %t261 = icmp eq i32 %t256, 0
  %t262 = shl i32 %t260, 16
  %t263 = or i32 %t262, %t258
  %t264 = select i1 %t261, i32 0, i32 %t263
  %t266 = insertvalue { i32, ptr } zeroinitializer, i32 %t264, 0
  store { i32, ptr } %t266, ptr %rv
  br label %ret
bb63:
  %t267 = load ptr, ptr %l96, !tbaa !29
  store ptr %t267, ptr %l8, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t271 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t268, i32 5)
  store i1 %t271, ptr %l103
  br label %bb64
bb64:
  %t272 = load i1, ptr %l103, !tbaa !21
  %t273 = xor i1 %t272, true
  br i1 %t273, label %bb65, label %bb66
bb65:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t278 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t275, i32 87)
  store i1 %t278, ptr %l108
  br label %bb67
bb66:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb68
bb67:
  %t279 = load i1, ptr %l108, !tbaa !21
  %t280 = xor i1 %t279, true
  store i1 %t280, ptr %l105, !tbaa !21
  br label %bb68
bb68:
  %t282 = load i1, ptr %l105, !tbaa !21
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t283 = load ptr, ptr %l8, !tbaa !29
  %t285 = insertvalue { i32, ptr } zeroinitializer, ptr %t283, 1
  store { i32, ptr } %t285, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t286, i32 0, i32 30
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l113
  br label %bb72
bb72:
  %t291 = load i64, ptr %l113, !tbaa !24
  store i64 %t291, ptr %l9, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 30
  %t295 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t294, ptr %t295)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t301 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t298, i32 5)
  store i1 %t301, ptr %l119
  br label %bb75
bb75:
  %t302 = load i1, ptr %l119, !tbaa !21
  br i1 %t302, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb79
bb77:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t306 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t303, i32 87)
  store i1 %t306, ptr %l123
  br label %bb78
bb78:
  %t307 = load i1, ptr %l123, !tbaa !21
  store i1 %t307, ptr %l120, !tbaa !21
  br label %bb79
bb79:
  %t308 = load i1, ptr %l120, !tbaa !21
  %t309 = xor i1 %t308, true
  br i1 %t309, label %bb80, label %bb81
bb80:
  br label %bb88
bb81:
  br label %bb82
bb82:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/parse:Parser", ptr %t311, i32 0, i32 30
  store ptr %t313, ptr %l126, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %t314)
  %t317 = extractvalue { i32, ptr } %t316, 1
  %t318 = extractvalue { i32, ptr } %t316, 0
  store i32 %t318, ptr %l130
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb84, label %ok.320
ok.320:
  store ptr %t317, ptr %l129
  br label %bb83
bb83:
  %t321 = load ptr, ptr %l129, !tbaa !29
  store ptr %t321, ptr %l127, !tbaa !29
  br label %bb85
bb84:
  %t322 = load i32, ptr %l130, !tbaa !23
  %t323 = lshr i32 %t322, 16
  %t324 = and i32 %t322, 65535
  %t325 = icmp eq i32 %t323, 1
  %t326 = select i1 %t325, i32 1, i32 0
  %t327 = icmp eq i32 %t322, 0
  %t328 = shl i32 %t326, 16
  %t329 = or i32 %t328, %t324
  %t330 = select i1 %t327, i32 0, i32 %t329
  %t332 = insertvalue { i32, ptr } zeroinitializer, i32 %t330, 0
  store { i32, ptr } %t332, ptr %rv
  br label %ret
bb85:
  %t333 = load ptr, ptr %l126, !tbaa !29
  %t334 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t333, ptr %t334)
  br label %bb86
bb86:
  br label %bb87
bb87:
  br label %bb74
bb88:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l1, !tbaa !23
  %t339 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t335, i32 %t336)
  store %"compiler/source:Span" %t339, ptr %l134
  br label %bb89
bb89:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/parse:Parser", ptr %t340, i32 0, i32 30
  %t343 = load i64, ptr %l9, !tbaa !24
  %t346 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t342, i64 %t343)
  store { i64, ptr } %t346, ptr %l138
  br label %bb90
bb90:
  store { i64, [5 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 0
  store i64 21, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l134
  %t350 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t349, 0
  %t351 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t352 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t350, { i64, ptr } %t351, 1
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t352, ptr %t353
  %t354 = load { i64, [5 x i64] }, ptr %t347
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t354, ptr %t356
  %t358 = insertvalue { i32, ptr } zeroinitializer, ptr %t356, 1
  store { i32, ptr } %t358, ptr %rv
  br label %ret
bb91:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %t359)
  %t362 = extractvalue { i32, ptr } %t361, 1
  %t363 = extractvalue { i32, ptr } %t361, 0
  store i32 %t363, ptr %l144
  %t364 = icmp ne i32 %t363, 0
  br i1 %t364, label %bb93, label %ok.365
ok.365:
  store ptr %t362, ptr %l143
  br label %bb92
bb92:
  %t366 = load ptr, ptr %l143, !tbaa !29
  store ptr %t366, ptr %l141, !tbaa !29
  br label %bb94
bb93:
  %t367 = load i32, ptr %l144, !tbaa !23
  %t368 = lshr i32 %t367, 16
  %t369 = and i32 %t367, 65535
  %t370 = icmp eq i32 %t368, 1
  %t371 = select i1 %t370, i32 1, i32 0
  %t372 = icmp eq i32 %t367, 0
  %t373 = shl i32 %t371, 16
  %t374 = or i32 %t373, %t369
  %t375 = select i1 %t372, i32 0, i32 %t374
  %t377 = insertvalue { i32, ptr } zeroinitializer, i32 %t375, 0
  store { i32, ptr } %t377, ptr %rv
  br label %ret
bb94:
  %t378 = load ptr, ptr %l141, !tbaa !29
  %t379 = insertvalue { i32, ptr } zeroinitializer, ptr %t378, 1
  store { i32, ptr } %t379, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l135 = alloca i1
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l166 = alloca i1
  %l176 = alloca i64
  %l179 = alloca i64
  %l197 = alloca { i64, ptr }
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l206 = alloca i1
  %l207 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l250 = alloca i64
  %l251 = alloca i64
  %l257 = alloca ptr
  %l258 = alloca i64
  %l259 = alloca { i64, ptr }
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca i64
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l277 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l24, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  store i64 %t16, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/parse:Parser", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l29, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l32
  br label %bb1
bb1:
  %t27 = load i64, ptr %l32, !tbaa !24
  %t28 = trunc i64 %t27 to i32
  %t29 = load ptr, ptr %l29, !tbaa !29
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t31, ptr %l34
  br label %bb2
bb2:
  %t32 = load i32, ptr %l34, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp slt i64 %t37, %t46
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/source:Source", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  %t58 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp ne i8 %t63, 10
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb6
bb6:
  %t67 = load i1, ptr %l43, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/source:Source", ptr %t77, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l55, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  store i64 %t81, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  store i64 %t82, ptr %l57, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l58, !tbaa !24
  %t85 = load i64, ptr %l56, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb12, label %bb13
bb12:
  %t88 = load i64, ptr %l56, !tbaa !24
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb14:
  %t92 = load i64, ptr %l57, !tbaa !24
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb16:
  %t96 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = sub i64 %t109, %t110
  store i64 %t113, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp sle i64 %t115, 0
  br i1 %t117, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb18:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb20
bb19:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = icmp sge i64 %t119, %t120
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb20
bb20:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  br i1 %t131, label %bb25, label %bb26
bb25:
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = icmp eq i8 %t139, 32
  br i1 %t141, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb29
bb28:
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t143, ptr %l84, !tbaa !27
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 9
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb29
bb29:
  %t153 = load i1, ptr %l83, !tbaa !21
  store i1 %t153, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t154 = load i1, ptr %l78, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t161 = load i64, ptr %l8, !tbaa !24
  store i64 %t161, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l96, !tbaa !27
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp ne i8 %t175, 32
  store i1 %t177, ptr %l95, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l95, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l8, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i8, ptr %t184, i64 %t181
  %t186 = load i8, ptr %t185, !tbaa !32
  %t188 = icmp ne i8 %t186, 9
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t190 = load i1, ptr %l100, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t193 = load i64, ptr %l8, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l8, !tbaa !24
  br label %bb46
bb46:
  br label %bb36
bb47:
  %t197 = load i64, ptr %l8, !tbaa !24
  store i64 %t197, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  %t199 = load i64, ptr %l8, !tbaa !24
  %t200 = load i64, ptr %l7, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t205, ptr %l113, !tbaa !27
  %t206 = load i64, ptr %l8, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i8, ptr %t209, i64 %t206
  %t211 = load i8, ptr %t210, !tbaa !32
  %t213 = icmp eq i8 %t211, 32
  br i1 %t213, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb54
bb51:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb53
bb52:
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t215, ptr %l118, !tbaa !27
  %t216 = load i64, ptr %l8, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t216
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = icmp eq i8 %t221, 9
  store i1 %t223, ptr %l117, !tbaa !21
  br label %bb53
bb53:
  %t225 = load i1, ptr %l117, !tbaa !21
  store i1 %t225, ptr %l112, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l112, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t229 = load i64, ptr %l8, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l8, !tbaa !24
  br label %bb58
bb58:
  br label %bb48
bb59:
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t233, ptr %l125, !tbaa !27
  %t234 = load i64, ptr %l8, !tbaa !24
  store i64 %t234, ptr %l126, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t235, 0
  store i64 %t238, ptr %l129, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l130, !tbaa !24
  %t241 = load i64, ptr %l126, !tbaa !24
  %t242 = icmp sge i64 %t241, 0
  br i1 %t242, label %bb60, label %bb61
bb60:
  %t244 = load i64, ptr %l126, !tbaa !24
  %t245 = load i64, ptr %l129, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb62:
  %t248 = load i64, ptr %l129, !tbaa !24
  %t249 = load i64, ptr %l130, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb64:
  %t252 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = load i64, ptr %l126, !tbaa !24
  %t255 = load i64, ptr %l129, !tbaa !24
  %t256 = getelementptr i8, ptr %t253, i64 %t254
  %t257 = sub i64 %t255, %t254
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t261, ptr %l135
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb66:
  %t262 = load i1, ptr %l135, !tbaa !21
  br i1 %t262, label %bb67, label %bb68
bb67:
  %t263 = load i64, ptr %l8, !tbaa !24
  %t265 = add i64 %t263, 4
  store i64 %t265, ptr %l8, !tbaa !24
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t267 = load i64, ptr %l8, !tbaa !24
  %t268 = load i64, ptr %l7, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  br i1 %t271, label %bb70, label %bb71
bb70:
  %t273 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t273, ptr %l142, !tbaa !27
  %t274 = load i64, ptr %l8, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i8, ptr %t277, i64 %t274
  %t279 = load i8, ptr %t278, !tbaa !32
  %t281 = icmp eq i8 %t279, 32
  store i1 %t281, ptr %l141, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb72
bb72:
  %t283 = load i1, ptr %l141, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t286 = load i64, ptr %l8, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l8, !tbaa !24
  br label %bb76
bb76:
  br label %bb69
bb77:
  br label %bb78
bb78:
  %t290 = load i64, ptr %l8, !tbaa !24
  store i64 %t290, ptr %l11, !tbaa !24
  %t292 = load i64, ptr %l7, !tbaa !24
  store i64 %t292, ptr %l12, !tbaa !24
  br label %bb79
bb79:
  %t294 = load i64, ptr %l12, !tbaa !24
  %t295 = load i64, ptr %l11, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb80, label %bb81
bb80:
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t300, ptr %l155, !tbaa !27
  %t301 = load i64, ptr %l12, !tbaa !24
  %t303 = sub i64 %t301, 1
  %t305 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i8, ptr %t306, i64 %t303
  %t308 = load i8, ptr %t307, !tbaa !32
  %t310 = icmp eq i8 %t308, 32
  store i1 %t310, ptr %l154, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb82
bb82:
  %t312 = load i1, ptr %l154, !tbaa !21
  %t313 = xor i1 %t312, true
  br i1 %t313, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  br label %bb85
bb85:
  %t315 = load i64, ptr %l12, !tbaa !24
  %t317 = sub i64 %t315, 1
  store i64 %t317, ptr %l12, !tbaa !24
  br label %bb86
bb86:
  br label %bb79
bb87:
  %t319 = load i64, ptr %l10, !tbaa !24
  %t320 = load i64, ptr %l9, !tbaa !24
  %t323 = icmp eq i64 %t319, %t320
  br i1 %t323, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb90
bb89:
  %t325 = load i64, ptr %l12, !tbaa !24
  %t326 = load i64, ptr %l11, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  store i1 %t329, ptr %l166, !tbaa !21
  br label %bb90
bb90:
  %t331 = load i1, ptr %l166, !tbaa !21
  br i1 %t331, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t333 = load i64, ptr %l9, !tbaa !24
  store i64 %t333, ptr %l13, !tbaa !24
  %t335 = load i64, ptr %l7, !tbaa !24
  store i64 %t335, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l14, !tbaa !24
  %t338 = load i64, ptr %l13, !tbaa !24
  %t341 = icmp sgt i64 %t337, %t338
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = load i64, ptr %l15, !tbaa !24
  %t345 = icmp sgt i64 %t343, 0
  br i1 %t345, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb99
bb96:
  %t347 = load i64, ptr %l14, !tbaa !24
  %t348 = load i64, ptr %l13, !tbaa !24
  %t351 = sub i64 %t347, %t348
  %t352 = load i64, ptr %l15, !tbaa !24
  %t355 = add i64 %t351, %t352
  %t357 = sub i64 %t355, 1
  %t358 = load i64, ptr %l15, !tbaa !24
  %t361 = sdiv i64 %t357, %t358
  store i64 %t361, ptr %l179, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb98
bb98:
  %t363 = load i64, ptr %l179, !tbaa !24
  store i64 %t363, ptr %l176, !tbaa !24
  br label %bb99
bb99:
  %t364 = load i64, ptr %l176, !tbaa !24
  store i64 %t364, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb100
bb100:
  %t365 = load i64, ptr %l17, !tbaa !24
  %t366 = load i64, ptr %l16, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb101, label %bb102
bb101:
  br label %bb114
bb102:
  br label %bb103
bb103:
  %t373 = load i64, ptr %l13, !tbaa !24
  %t374 = load i64, ptr %l17, !tbaa !24
  %t375 = load i64, ptr %l15, !tbaa !24
  %t378 = mul i64 %t374, %t375
  %t381 = add i64 %t373, %t378
  store i64 %t381, ptr %l18, !tbaa !24
  %t383 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t383, ptr %l197, !tbaa !27
  %t384 = load i64, ptr %l18, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i8, ptr %t387, i64 %t384
  %t389 = load i8, ptr %t388, !tbaa !32
  %t391 = icmp eq i8 %t389, 61
  br i1 %t391, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb106
bb105:
  %t393 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t393, ptr %l202, !tbaa !27
  %t394 = load i64, ptr %l18, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i8, ptr %t397, i64 %t394
  %t399 = load i8, ptr %t398, !tbaa !32
  %t401 = icmp eq i8 %t399, 58
  store i1 %t401, ptr %l201, !tbaa !21
  br label %bb106
bb106:
  %t403 = load i1, ptr %l201, !tbaa !21
  br i1 %t403, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb109
bb108:
  %t404 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t404, ptr %l207, !tbaa !27
  %t405 = load i64, ptr %l18, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i8, ptr %t408, i64 %t405
  %t410 = load i8, ptr %t409, !tbaa !32
  %t412 = icmp eq i8 %t410, 40
  store i1 %t412, ptr %l206, !tbaa !21
  br label %bb109
bb109:
  %t414 = load i1, ptr %l206, !tbaa !21
  br i1 %t414, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t416 = load i64, ptr %l17, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l17, !tbaa !24
  br label %bb100
bb114:
  store i64 0, ptr %l19, !tbaa !24
  %t420 = load i64, ptr %l7, !tbaa !24
  store i64 %t420, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l6, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb116, label %bb117
bb116:
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t430 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t430, ptr %l219, !tbaa !27
  %t431 = load i64, ptr %l20, !tbaa !24
  %t433 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr i8, ptr %t434, i64 %t431
  %t436 = load i8, ptr %t435, !tbaa !32
  %t438 = icmp eq i8 %t436, 40
  br i1 %t438, label %bb119, label %bb120
bb119:
  %t440 = load i64, ptr %l19, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l19, !tbaa !24
  br label %bb127
bb120:
  %t444 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t444, ptr %l225, !tbaa !27
  %t445 = load i64, ptr %l20, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr i8, ptr %t448, i64 %t445
  %t450 = load i8, ptr %t449, !tbaa !32
  %t452 = icmp eq i8 %t450, 41
  br i1 %t452, label %bb121, label %bb122
bb121:
  %t454 = load i64, ptr %l19, !tbaa !24
  %t456 = sub i64 %t454, 1
  store i64 %t456, ptr %l19, !tbaa !24
  %t458 = load i64, ptr %l19, !tbaa !24
  %t460 = icmp eq i64 %t458, 0
  br i1 %t460, label %bb123, label %bb124
bb122:
  br label %bb126
bb123:
  br label %bb129
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t462 = load i64, ptr %l20, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l20, !tbaa !24
  br label %bb128
bb128:
  br label %bb115
bb129:
  %t466 = load i64, ptr %l20, !tbaa !24
  %t467 = load i64, ptr %l6, !tbaa !24
  %t470 = icmp sge i64 %t466, %t467
  br i1 %t470, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t473 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t473, ptr %l239, !tbaa !27
  %t474 = load i64, ptr %l11, !tbaa !24
  store i64 %t474, ptr %l240, !tbaa !24
  %t475 = load i64, ptr %l12, !tbaa !24
  store i64 %t475, ptr %l241, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  store i64 %t477, ptr %l242, !tbaa !24
  %t478 = load i64, ptr %l240, !tbaa !24
  %t479 = icmp sge i64 %t478, 0
  br i1 %t479, label %bb133, label %bb134
bb133:
  %t481 = load i64, ptr %l240, !tbaa !24
  %t482 = load i64, ptr %l241, !tbaa !24
  %t483 = icmp sle i64 %t481, %t482
  br i1 %t483, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb135:
  %t485 = load i64, ptr %l241, !tbaa !24
  %t486 = load i64, ptr %l242, !tbaa !24
  %t487 = icmp sle i64 %t485, %t486
  br i1 %t487, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb137:
  %t489 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l240, !tbaa !24
  %t492 = load i64, ptr %l241, !tbaa !24
  %t493 = getelementptr i8, ptr %t490, i64 %t491
  %t494 = sub i64 %t492, %t491
  %t495 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t493, 1
  store { i64, ptr } %t496, ptr %l246, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t497, ptr %l247, !tbaa !27
  %t498 = load i64, ptr %l7, !tbaa !24
  store i64 %t498, ptr %l248, !tbaa !24
  %t499 = load i64, ptr %l20, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l250, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l251, !tbaa !24
  %t504 = load i64, ptr %l248, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb139:
  %t507 = load i64, ptr %l248, !tbaa !24
  %t508 = load i64, ptr %l250, !tbaa !24
  %t509 = icmp sle i64 %t507, %t508
  br i1 %t509, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb141:
  %t511 = load i64, ptr %l250, !tbaa !24
  %t512 = load i64, ptr %l251, !tbaa !24
  %t513 = icmp sle i64 %t511, %t512
  br i1 %t513, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb143:
  %t515 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = load i64, ptr %l248, !tbaa !24
  %t518 = load i64, ptr %l250, !tbaa !24
  %t519 = getelementptr i8, ptr %t516, i64 %t517
  %t520 = sub i64 %t518, %t517
  %t521 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t519, 1
  %t523 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 1
  %t525 = extractvalue { i64, ptr } %t523, 0
  %t527 = extractvalue { i64, ptr } %t522, 1
  %t528 = extractvalue { i64, ptr } %t522, 0
  %t529 = add i64 %t525, %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t524, i64 %t525)
  %t531 = getelementptr i8, ptr %t530, i64 %t525
  call void @olang_textcopy(ptr %t531, ptr %t527, i64 %t528)
  %t532 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  store { i64, ptr } %t533, ptr %l21, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l257, !tbaa !29
  %t536 = load i64, ptr %l1, !tbaa !24
  store i64 %t536, ptr %l258, !tbaa !24
  %t537 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t537, ptr %l259, !tbaa !27
  %t538 = load i64, ptr %l9, !tbaa !24
  store i64 %t538, ptr %l260, !tbaa !24
  %t539 = load i64, ptr %l12, !tbaa !24
  store i64 %t539, ptr %l261, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 0
  store i64 %t541, ptr %l262, !tbaa !24
  %t542 = load i64, ptr %l260, !tbaa !24
  %t543 = icmp sge i64 %t542, 0
  br i1 %t543, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb145:
  %t545 = load i64, ptr %l260, !tbaa !24
  %t546 = load i64, ptr %l261, !tbaa !24
  %t547 = icmp sle i64 %t545, %t546
  br i1 %t547, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb147:
  %t549 = load i64, ptr %l261, !tbaa !24
  %t550 = load i64, ptr %l262, !tbaa !24
  %t551 = icmp sle i64 %t549, %t550
  br i1 %t551, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb149:
  %t553 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = load i64, ptr %l260, !tbaa !24
  %t556 = load i64, ptr %l261, !tbaa !24
  %t557 = getelementptr i8, ptr %t554, i64 %t555
  %t558 = sub i64 %t556, %t555
  %t559 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t557, 1
  store { i64, ptr } %t560, ptr %l266, !tbaa !27
  %t561 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t561, ptr %l267, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t562, ptr %l268, !tbaa !27
  %t563 = load i64, ptr %l9, !tbaa !24
  store i64 %t563, ptr %l269, !tbaa !24
  %t564 = load i64, ptr %l10, !tbaa !24
  store i64 %t564, ptr %l270, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  store i64 %t566, ptr %l271, !tbaa !24
  %t567 = load i64, ptr %l269, !tbaa !24
  %t568 = icmp sge i64 %t567, 0
  br i1 %t568, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb151:
  %t570 = load i64, ptr %l269, !tbaa !24
  %t571 = load i64, ptr %l270, !tbaa !24
  %t572 = icmp sle i64 %t570, %t571
  br i1 %t572, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb153:
  %t574 = load i64, ptr %l270, !tbaa !24
  %t575 = load i64, ptr %l271, !tbaa !24
  %t576 = icmp sle i64 %t574, %t575
  br i1 %t576, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb155:
  %t578 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = load i64, ptr %l269, !tbaa !24
  %t581 = load i64, ptr %l270, !tbaa !24
  %t582 = getelementptr i8, ptr %t579, i64 %t580
  %t583 = sub i64 %t581, %t580
  %t584 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t582, 1
  %t586 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t587 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t591 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t587, { i64, ptr } %t588, { i64, ptr } %t585, { i64, ptr } %t586)
  store %"compiler/msgs:Msg" %t591, ptr %l277
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb157:
  %t592 = load ptr, ptr %l257, !tbaa !29
  %t593 = load i64, ptr %l258, !tbaa !24
  %t594 = load %"compiler/msgs:Msg", ptr %l277
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %s0, ptr %t592, i64 %t593, %"compiler/msgs:Msg" %t594)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %lp13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l31 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l86 = alloca %"compiler/ast:VarDecl"
  %l96 = alloca { i64, ptr }
  %l101 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l108 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l117 = alloca i32
  %l123 = alloca i32
  %rv = alloca { i32, ptr }
  %t144 = alloca i64
  %t162 = alloca i64
  %t192 = alloca { i64, [4 x i64] }, align 8
  %t251 = alloca { i64, [4 x i64] }, align 8
  %t268 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 12
  %t6 = load i1, ptr %t5, !tbaa !21
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i1 %t6)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l21
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14
ok.14:
  store ptr %t11, ptr %l20
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l20, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb3:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t28, i32 %a1)
  store %"compiler/source:Span" %t32, ptr %l25
  br label %bb4
bb4:
  %t33 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 12
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 57)
  store i1 %t42, ptr %l31
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i1, ptr %l31, !tbaa !21
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/parse:NameList", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 1
  br i1 %t54, label %bb11, label %bb12
bb10:
  br label %bb47
bb11:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/ast:VarDecl", ptr %t56, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l37, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb15:
  br label %bb45
bb16:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb18:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l50, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l50, !tbaa !24
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l47, !tbaa !24
  store i64 %t97, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/parse:NameList", ptr %t116, i32 0, i32 1
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l69, !tbaa !27
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i64 %t120
  %t125 = load %"compiler/source:Span", ptr %t124
  store %"compiler/source:Span" %t125, ptr %l12
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/parse:NameList", ptr %t127, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l73, !tbaa !27
  %t131 = load i64, ptr %l11, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  store i32 %t136, ptr %l75, !tbaa !23
  %t137 = icmp sge i64 1, 0
  br i1 %t137, label %bb26, label %bb27
bb26:
  %t139 = icmp sle i64 1, 2305843009213693951
  br i1 %t139, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb28:
  %t141 = mul i64 1, 4
  %t142 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t141)
  %t143 = load i32, ptr %l75, !tbaa !23
  store i64 0, ptr %t144
  br label %fill.145
fill.145:
  %t148 = load i64, ptr %t144
  %t149 = icmp slt i64 %t148, 1
  br i1 %t149, label %fillb.146, label %filld.147
fillb.146:
  %t150 = getelementptr i32, ptr %t142, i64 %t148
  store i32 %t143, ptr %t150
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %t144
  br label %fill.145
filld.147:
  %t152 = insertvalue { i64, ptr } undef, i64 1, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t142, 1
  store { i64, ptr } %t153, ptr %l78, !tbaa !27
  %t154 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t154, ptr %l79
  %t155 = icmp sge i64 1, 0
  br i1 %t155, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb30:
  %t157 = icmp sle i64 1, 1152921504606846975
  br i1 %t157, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb32:
  %t159 = mul i64 1, 8
  %t160 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t159)
  %t161 = load %"compiler/source:Span", ptr %l79
  store i64 0, ptr %t162
  br label %fill.163
fill.163:
  %t166 = load i64, ptr %t162
  %t167 = icmp slt i64 %t166, 1
  br i1 %t167, label %fillb.164, label %filld.165
fillb.164:
  %t168 = getelementptr %"compiler/source:Span", ptr %t160, i64 %t166
  store %"compiler/source:Span" %t161, ptr %t168
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %t162
  br label %fill.163
filld.165:
  %t170 = insertvalue { i64, ptr } undef, i64 1, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t160, 1
  store { i64, ptr } %t171, ptr %l82, !tbaa !27
  %t172 = icmp sge i64 0, 0
  br i1 %t172, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb34:
  %t174 = icmp sle i64 0, 1152921504606846975
  br i1 %t174, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb36:
  %t176 = mul i64 0, 8
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 0, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t180 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t183 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t180, { i64, ptr } %t181, ptr null, { i64, ptr } %t179, i1 false, i1 true)
  store %"compiler/ast:VarDecl" %t183, ptr %l86
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb38:
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t184, ptr %lp13
  %t185 = load %"compiler/ast:VarDecl", ptr %l86
  %t186 = load ptr, ptr %lp13
  store %"compiler/ast:VarDecl" %t185, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/parse:Parser", ptr %t187, i32 0, i32 31
  %t190 = load %"compiler/source:Span", ptr %l12
  %t191 = load ptr, ptr %lp13
  store { i64, [4 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 0
  store i64 1, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t197 = insertvalue { %"compiler/source:Span", ptr } %t195, ptr %t191, 1
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t192
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t199, ptr %t201
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t189, ptr %t201)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l10, !tbaa !24
  br label %bb22
bb41:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr %"compiler/parse:NameList", ptr %t208, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l96, !tbaa !27
  %t212 = load i64, ptr %l5, !tbaa !24
  %t214 = sub i64 %t212, 1
  %t216 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/source:Span", ptr %t217, i64 %t214
  %t219 = load %"compiler/source:Span", ptr %t218
  store %"compiler/source:Span" %t219, ptr %l14
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t221)
  store i32 %t223, ptr %l101
  br label %bb42
bb42:
  %t224 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t225 = load i32, ptr %t224, !tbaa !23
  %t226 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t227 = load i32, ptr %t226, !tbaa !23
  %t230 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t225, i32 %t227)
  store %"compiler/source:Span" %t230, ptr %l104
  br label %bb43
bb43:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t235 = getelementptr %"compiler/parse:NameList", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l108, !tbaa !27
  %t237 = load i64, ptr %l5, !tbaa !24
  %t239 = sub i64 %t237, 1
  %t241 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  %t245 = load %"compiler/source:Span", ptr %l14
  %t250 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %t231, ptr %t232, i32 %t244, %"compiler/source:Span" %t245)
  store ptr %t250, ptr %l113
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 0
  store i64 1, ptr %t252
  %t253 = load %"compiler/source:Span", ptr %l104
  %t254 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t253, 0
  %t255 = load ptr, ptr %l113, !tbaa !29
  %t256 = insertvalue { %"compiler/source:Span", ptr } %t254, ptr %t255, 1
  %t257 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t256, ptr %t257
  %t258 = load { i64, [4 x i64] }, ptr %t251
  %t260 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t258, ptr %t260
  %t262 = insertvalue { i32, ptr } zeroinitializer, ptr %t260, 1
  store { i32, ptr } %t262, ptr %rv
  br label %ret
bb45:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l117
  br label %bb46
bb46:
  %t266 = load %"compiler/source:Span", ptr %l4
  %t267 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 0
  store i64 1, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t266, 0
  %t273 = insertvalue { %"compiler/source:Span", ptr } %t271, ptr %t267, 1
  %t274 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t273, ptr %t274
  %t275 = load { i64, [4 x i64] }, ptr %t268
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t275, ptr %t277
  %t279 = insertvalue { i32, ptr } zeroinitializer, ptr %t277, 1
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb47:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l123
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb49, label %ok.284
ok.284:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t285 = load i32, ptr %l123, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  %t295 = insertvalue { i32, ptr } zeroinitializer, i32 %t293, 0
  store { i32, ptr } %t295, ptr %rv
  br label %ret
bb50:
  %t296 = load %"compiler/source:Span", ptr %l4
  %t297 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [4 x i64] }, ptr %t298, i32 0, i32 0
  store i64 1, ptr %t299
  %t301 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t296, 0
  %t303 = insertvalue { %"compiler/source:Span", ptr } %t301, ptr %t297, 1
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t303, ptr %t304
  %t305 = load { i64, [4 x i64] }, ptr %t298
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t305, ptr %t307
  %t309 = insertvalue { i32, ptr } zeroinitializer, ptr %t307, 1
  store { i32, ptr } %t309, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2eisAssignOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 60 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 63 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 64 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 65 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 66 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb12:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 67 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 68 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 69 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 70 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 71 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb24:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 72 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb29
bb29:
  %t56 = load i1, ptr %l1, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94ee529efe0ddf52_d9208d758fca575e)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOperandEndTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 91 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 93 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 2 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 3 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 6 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0
  %t44 = trunc i64 7 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisOrdering(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 79 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 80 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 81 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 82 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2elineBodyRefused(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 9 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb35
bb4:
  %t8 = load i32, ptr %l0
  %t10 = trunc i64 25 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l0
  %t15 = trunc i64 26 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  br label %bb35
bb10:
  %t20 = load i32, ptr %l0
  %t22 = trunc i64 31 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %l1, !tbaa !27
  br label %bb35
bb14:
  %t27 = load i32, ptr %l0
  %t29 = trunc i64 94 to i32
  %t30 = icmp eq i32 %t27, %t29
  br i1 %t30, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb35
bb18:
  %t34 = load i32, ptr %l0
  %t36 = trunc i64 14 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l1, !tbaa !27
  br label %bb35
bb22:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 16 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t46, ptr %l1, !tbaa !27
  br label %bb35
bb26:
  %t48 = load i32, ptr %l0
  %t50 = trunc i64 17 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l1, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6)
  unreachable
bb35:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l34, !tbaa !24
  %t59 = load i64, ptr %l34, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l35, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = mul i64 %t68, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t70, ptr %l1, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l28
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  br label %bb73
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t29 = load ptr, ptr %l30, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32 }, ptr %t39, i32 0, i32 0
  %t41 = load %"compiler/source:Span", ptr %t40
  store %"compiler/source:Span" %t41, ptr %l4
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %l36, !tbaa !27
  %t44 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l40, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l41, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb15:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l41, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb17:
  %t65 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = getelementptr i8, ptr %t66, i64 %t67
  %t70 = sub i64 %t68, %t67
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = extractvalue { i64, ptr } %t72, 0
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t74, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l19, !tbaa !27
  br label %bb73
bb18:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t96, { i64, ptr } %t97)
  store { i64, ptr } %t101, ptr %l56
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t102, ptr %l19, !tbaa !27
  br label %bb73
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load i32, ptr %l6
  %t126 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t124)
  store { i64, ptr } %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s6, ptr %t127, ptr %t128, { i64, ptr } %t129)
  store { i64, ptr } %t133, ptr %l70
  br label %bb33
bb33:
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  store { i64, ptr } %t156, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb73
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t159 = load ptr, ptr %l72, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l72, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 5
  store i1 %t165, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l73, !tbaa !21
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l8
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t181, i32 0, i32 3
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load i32, ptr %l8
  %t187 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t185)
  store { i64, ptr } %t187, ptr %l83
  br label %bb40
bb40:
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t188, ptr %t189, { i64, ptr } %t190)
  store { i64, ptr } %t194, ptr %l87
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t195, ptr %t196, { i64, ptr } %t197)
  store { i64, ptr } %t201, ptr %l91
  br label %bb42
bb42:
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t204 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t202, i64 %t203)
  %t226 = getelementptr i8, ptr %t225, i64 %t203
  call void @olang_textcopy(ptr %t226, ptr %t205, i64 %t206)
  %t227 = getelementptr i8, ptr %t226, i64 %t206
  call void @olang_textcopy(ptr %t227, ptr %t208, i64 %t209)
  %t228 = getelementptr i8, ptr %t227, i64 %t209
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t215, i64 %t216)
  %t230 = getelementptr i8, ptr %t229, i64 %t216
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t225, 1
  store { i64, ptr } %t233, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb43:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t236 = load ptr, ptr %l93, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l93, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 7
  store i1 %t242, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t243 = load i1, ptr %l94, !tbaa !21
  br i1 %t243, label %bb46, label %bb47
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/ast:Chain", ptr %t250, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t259 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t260 = add i64 %t257, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t256, i64 %t257)
  %t265 = getelementptr i8, ptr %t264, i64 %t257
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t255)
  %t267 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t267, ptr %t261, i64 %t262)
  %t268 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t264, 1
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  br label %bb73
bb49:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t272 = load ptr, ptr %l103, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb50, label %bb51
bb50:
  %t275 = load ptr, ptr %l103, !tbaa !29
  %t276 = load i64, ptr %t275
  %t278 = icmp eq i64 %t276, 8
  store i1 %t278, ptr %l104, !tbaa !21
  br label %bb51
bb51:
  %t279 = load i1, ptr %l104, !tbaa !21
  br i1 %t279, label %bb52, label %bb53
bb52:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l12, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l13, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t294, i32 0, i32 3
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l14, !tbaa !29
  br label %bb54
bb53:
  br label %bb58
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t298, ptr %t299, { i64, ptr } %t300)
  store { i64, ptr } %t304, ptr %l116
  br label %bb55
bb55:
  %t305 = load ptr, ptr %l12, !tbaa !29
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t305, ptr %t306, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l120
  br label %bb56
bb56:
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t318 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t312, ptr %t313, { i64, ptr } %t314)
  store { i64, ptr } %t318, ptr %l124
  br label %bb57
bb57:
  %t319 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t321 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t319, i64 %t320)
  %t343 = getelementptr i8, ptr %t342, i64 %t320
  call void @olang_textcopy(ptr %t343, ptr %t322, i64 %t323)
  %t344 = getelementptr i8, ptr %t343, i64 %t323
  call void @olang_textcopy(ptr %t344, ptr %t325, i64 %t326)
  %t345 = getelementptr i8, ptr %t344, i64 %t326
  call void @olang_textcopy(ptr %t345, ptr %t329, i64 %t330)
  %t346 = getelementptr i8, ptr %t345, i64 %t330
  call void @olang_textcopy(ptr %t346, ptr %t332, i64 %t333)
  %t347 = getelementptr i8, ptr %t346, i64 %t333
  call void @olang_textcopy(ptr %t347, ptr %t336, i64 %t337)
  %t348 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t348, ptr %t339, i64 %t340)
  %t349 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t342, 1
  store { i64, ptr } %t350, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb73
bb58:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t353 = load ptr, ptr %l126, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb59, label %bb60
bb59:
  %t356 = load ptr, ptr %l126, !tbaa !29
  %t357 = load i64, ptr %t356
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l127, !tbaa !21
  br label %bb60
bb60:
  %t360 = load i1, ptr %l127, !tbaa !21
  br i1 %t360, label %bb61, label %bb62
bb61:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l15, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370
  store { i64, ptr } %t371, ptr %l16, !tbaa !27
  br label %bb63
bb62:
  br label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t373 = load ptr, ptr %l15, !tbaa !29
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t373, ptr %t374, { i64, ptr } %t375)
  store { i64, ptr } %t379, ptr %l137
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t385 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t394 = add i64 %t391, %t393
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t397 = add i64 %t394, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t383, i64 %t384)
  %t399 = getelementptr i8, ptr %t398, i64 %t384
  call void @olang_textcopy(ptr %t399, ptr %t386, i64 %t387)
  %t400 = getelementptr i8, ptr %t399, i64 %t387
  call void @olang_textcopy(ptr %t400, ptr %t389, i64 %t390)
  %t401 = getelementptr i8, ptr %t400, i64 %t390
  %t402 = call i64 @__olang_fmt_i64(ptr %t401, i64 %t382)
  %t403 = getelementptr i8, ptr %t401, i64 %t393
  call void @olang_textcopy(ptr %t403, ptr %t395, i64 %t396)
  %t404 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t398, 1
  store { i64, ptr } %t405, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb65:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t408 = load ptr, ptr %l141, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb66, label %bb67
bb66:
  %t411 = load ptr, ptr %l141, !tbaa !29
  %t412 = load i64, ptr %t411
  %t414 = icmp eq i64 %t412, 14
  store i1 %t414, ptr %l142, !tbaa !21
  br label %bb67
bb67:
  %t415 = load i1, ptr %l142, !tbaa !21
  br i1 %t415, label %bb68, label %bb69
bb68:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t418, i32 0, i32 1
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l17, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t424, i32 0, i32 2
  %t426 = load { i64, ptr }, ptr %t425
  store { i64, ptr } %t426, ptr %l18, !tbaa !27
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t428 = load ptr, ptr %l17, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t434 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s16, ptr %t428, ptr %t429, { i64, ptr } %t430)
  store { i64, ptr } %t434, ptr %l152
  br label %bb71
bb71:
  %t435 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t440 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t437)
  %t449 = add i64 %t446, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t438, i64 %t439)
  %t454 = getelementptr i8, ptr %t453, i64 %t439
  call void @olang_textcopy(ptr %t454, ptr %t441, i64 %t442)
  %t455 = getelementptr i8, ptr %t454, i64 %t442
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  %t457 = call i64 @__olang_fmt_i64(ptr %t456, i64 %t437)
  %t458 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t458, ptr %t450, i64 %t451)
  %t459 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t453, 1
  store { i64, ptr } %t460, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb73
bb72:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l156, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t462, ptr %l19, !tbaa !27
  br label %bb73
bb73:
  %t464 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l158, !tbaa !24
  %t466 = load i64, ptr %l158, !tbaa !24
  %t467 = mul i64 %t466, 1
  %t468 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l159, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = load i64, ptr %l158, !tbaa !24
  %t476 = mul i64 %t475, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t472, ptr %t474, i64 %t476, i1 false)
  %t477 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t477, ptr %l19, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca %"compiler/source:Source"
  %l4 = alloca %"compiler/source:Names"
  %l5 = alloca %"compiler/parse:Oracle"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca i64
  %l12 = alloca %"compiler/scan:Tokens"
  %l13 = alloca %"compiler/parse:Parser"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/diag:Said"
  %l36 = alloca %"compiler/source:Source"
  %l37 = alloca %"compiler/source:Names"
  %l38 = alloca %"compiler/parse:Oracle"
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diag:Diagnostics"
  %l62 = alloca i64
  %l64 = alloca %"compiler/scan:Tokens"
  %l71 = alloca %"compiler/parse:Parser"
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"std/prelude/text:StringBuilder"
  %l84 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i1
  %l97 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i1
  %l134 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i1
  %l156 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l177 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l179 = alloca i64
  %l181 = alloca i64
  %l186 = alloca %"compiler/diag:Said"
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t47 = alloca %"compiler/diag:Diagnostics", align 8
  %t63 = alloca %"compiler/parse:Parser", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } %a0)
  store %"compiler/source:Source" %t3, ptr %l36
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Source", ptr %l36
  store %"compiler/source:Source" %t4, ptr %l3
  %t5 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t5, ptr %l37
  br label %bb2
bb2:
  %t6 = load %"compiler/source:Names", ptr %l37
  store %"compiler/source:Names" %t6, ptr %l4
  %t7 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %s0)
  store %"compiler/parse:Oracle" %t7, ptr %l38
  br label %bb3
bb3:
  %t8 = load %"compiler/parse:Oracle", ptr %l38
  store %"compiler/parse:Oracle" %t8, ptr %l5
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s1, { i64, ptr } %a1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t11, ptr %l40
  br label %bb4
bb4:
  %t12 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l47, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %t29, i64 %t26
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %s0, ptr %s0, ptr %s3, ptr %v1, ptr %l5, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, { i64, ptr } %t39)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb5
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t47, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t47, i64 200, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l58, i64 200, i1 false)
  %t48 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t49, { i64, ptr } %t51, i1 false)
  store i64 %t55, ptr %l62
  br label %bb16
bb16:
  %t56 = load i64, ptr %l62, !tbaa !24
  store i64 %t56, ptr %l11, !tbaa !24
  %t57 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t58)
  store %"compiler/scan:Tokens" %t60, ptr %l64
  br label %bb17
bb17:
  %t61 = load %"compiler/scan:Tokens", ptr %l64
  store %"compiler/scan:Tokens" %t61, ptr %l12
  %t62 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t63, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l3, ptr %l12, ptr %l4, ptr %l5, ptr %l10, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t63, i64 320, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l71, i64 320, i1 false)
  %t71 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %l13)
  store { i64, ptr } %t71, ptr %l73
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  br i1 %a2, label %bb20, label %bb21
bb20:
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %s0, ptr %l10)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t76 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t76, ptr %l76
  br label %bb24
bb24:
  %t77 = load %"std/prelude/text:StringBuilder", ptr %l76
  store %"std/prelude/text:StringBuilder" %t77, ptr %l15
  %t78 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t78, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  %t84 = load i64, ptr %l17, !tbaa !24
  %t85 = load i64, ptr %l18, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb26, label %bb27
bb26:
  br label %bb83
bb27:
  br label %bb28
bb28:
  %t92 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t92, ptr %l84, !tbaa !27
  %t93 = load i64, ptr %l17, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l19, !tbaa !29
  %t101 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l15)
  store i64 %t101, ptr %l88
  br label %bb29
bb29:
  %t102 = load i64, ptr %l88, !tbaa !24
  %t103 = icmp sgt i64 %t102, 0
  br i1 %t103, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l19, !tbaa !29
  store ptr %t106, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t107 = load ptr, ptr %l91, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l91, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l92, !tbaa !21
  br label %bb35
bb35:
  %t114 = load i1, ptr %l92, !tbaa !21
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t115 = load ptr, ptr %l19, !tbaa !29
  %t117 = getelementptr { i64, [6 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { ptr }, ptr %t117, i32 0, i32 0
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l20, !tbaa !29
  br label %bb38
bb37:
  br label %bb53
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l15, ptr %l97, !tbaa !29
  %t121 = load ptr, ptr %l20, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t124)
  store { i64, ptr } %t127, ptr %l101
  br label %bb39
bb39:
  %t128 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t130 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = getelementptr i8, ptr %t138, i64 %t132
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t137, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t149, { i64, ptr } %t148)
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l20, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Func", ptr %t151, i32 0, i32 6
  %t154 = load i1, ptr %t153, !tbaa !21
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb43
bb42:
  %t159 = load ptr, ptr %l20, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Func", ptr %t159, i32 0, i32 4
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l23, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb44:
  store %olang.scope zeroinitializer, ptr %s14
  %t168 = load i64, ptr %l22, !tbaa !24
  %t169 = load i64, ptr %l23, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s14)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t176 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t176, ptr %l116, !tbaa !27
  %t177 = load i64, ptr %l22, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr ptr, ptr %t180, i64 %t177
  %t182 = load ptr, ptr %t181, !tbaa !39
  store ptr %l15, ptr %l119, !tbaa !29
  %t185 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t190 = call { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %s0, ptr %s0, ptr %s0, ptr %s14, ptr %t182, ptr %l4, { i64, ptr } %t186)
  store { i64, ptr } %t190, ptr %l123
  br label %bb48
bb48:
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t193 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t191, i64 %t192)
  %t198 = getelementptr i8, ptr %t197, i64 %t192
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = extractvalue { i64, ptr } %t200, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t208 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t208, { i64, ptr } %t207)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s14)
  br label %bb50
bb50:
  %t210 = load i64, ptr %l22, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l22, !tbaa !24
  br label %bb44
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb81
bb53:
  %t214 = load ptr, ptr %l19, !tbaa !29
  store ptr %t214, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t215 = load ptr, ptr %l128, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb54, label %bb55
bb54:
  %t218 = load ptr, ptr %l128, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 2
  store i1 %t221, ptr %l129, !tbaa !21
  br label %bb55
bb55:
  %t222 = load i1, ptr %l129, !tbaa !21
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t223 = load ptr, ptr %l19, !tbaa !29
  %t225 = getelementptr { i64, [6 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l25, !tbaa !29
  br label %bb58
bb57:
  br label %bb79
bb58:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l15, ptr %l134, !tbaa !29
  %t229 = load ptr, ptr %l25, !tbaa !29
  %t231 = getelementptr %"compiler/ast:TypeDecl", ptr %t229, i32 0, i32 0
  %t232 = load i32, ptr %t231, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t232)
  store { i64, ptr } %t235, ptr %l138
  br label %bb59
bb59:
  %t236 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t238 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = add i64 %t237, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t236, i64 %t237)
  %t243 = getelementptr i8, ptr %t242, i64 %t237
  call void @olang_textcopy(ptr %t243, ptr %t239, i64 %t240)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t242, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = extractvalue { i64, ptr } %t245, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t253 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t253, { i64, ptr } %t252)
  br label %bb60
bb60:
  %t255 = load ptr, ptr %l25, !tbaa !29
  %t257 = getelementptr %"compiler/ast:TypeDecl", ptr %t255, i32 0, i32 3
  %t258 = load ptr, ptr %t257, !tbaa !29
  store ptr %t258, ptr %l26, !tbaa !29
  %t260 = load ptr, ptr %l26, !tbaa !29
  store ptr %t260, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t261 = load ptr, ptr %l143, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb61, label %bb62
bb61:
  %t264 = load ptr, ptr %l143, !tbaa !29
  %t265 = load i64, ptr %t264
  %t267 = icmp eq i64 %t265, 2
  store i1 %t267, ptr %l144, !tbaa !21
  br label %bb62
bb62:
  %t268 = load i1, ptr %l144, !tbaa !21
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t269 = load ptr, ptr %l26, !tbaa !29
  %t271 = getelementptr { i64, [6 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t271, i32 0, i32 0
  %t273 = load { i64, ptr }, ptr %t272
  store { i64, ptr } %t273, ptr %l27, !tbaa !27
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t275 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t275, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  store i64 %t279, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s21
  %t281 = load i64, ptr %l29, !tbaa !24
  %t282 = load i64, ptr %l30, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s21)
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t289 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t289, ptr %l156, !tbaa !27
  %t290 = load i64, ptr %l29, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr ptr, ptr %t293, i64 %t290
  %t295 = load ptr, ptr %t294, !tbaa !39
  store ptr %t295, ptr %l31, !tbaa !29
  store ptr %l15, ptr %l159, !tbaa !29
  %t297 = load ptr, ptr %l31, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Func", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb70, label %bb71
bb70:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb72
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb72
bb72:
  %t306 = load ptr, ptr %l31, !tbaa !29
  %t308 = getelementptr %"compiler/ast:Func", ptr %t306, i32 0, i32 2
  %t309 = load i32, ptr %t308, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %s0, ptr %l4, i32 %t309)
  store { i64, ptr } %t312, ptr %l168
  br label %bb73
bb73:
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t315 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t313, i64 %t314)
  %t324 = getelementptr i8, ptr %t323, i64 %t314
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = getelementptr i8, ptr %t324, i64 %t317
  call void @olang_textcopy(ptr %t325, ptr %t320, i64 %t321)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t323, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = extractvalue { i64, ptr } %t327, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  %t335 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t335, { i64, ptr } %t334)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s21)
  br label %bb75
bb75:
  %t337 = load i64, ptr %l29, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l29, !tbaa !24
  br label %bb66
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb81
bb79:
  store %olang.scope zeroinitializer, ptr %s25
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %l15, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s25)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t342 = load i64, ptr %l17, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l17, !tbaa !24
  br label %bb25
bb83:
  store %olang.scope zeroinitializer, ptr %s27
  %t347 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s27, ptr %l10)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t347, ptr %l177
  br label %bb84
bb84:
  %t348 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l177
  %t349 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t349
  store ptr %t349, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s28
  %t351 = load i64, ptr %l33, !tbaa !24
  store i64 %t351, ptr %l179, !tbaa !24
  %t352 = load ptr, ptr %l32, !tbaa !29
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s27, ptr %t352)
  store i64 %t354, ptr %l181
  br label %bb86
bb86:
  %t355 = load i64, ptr %l179, !tbaa !24
  %t356 = load i64, ptr %l181, !tbaa !24
  %t357 = icmp slt i64 %t355, %t356
  %t359 = xor i1 %t357, true
  br i1 %t359, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s28)
  br label %bb93
bb88:
  br label %bb89
bb89:
  %t361 = load ptr, ptr %l32, !tbaa !29
  %t362 = load i64, ptr %l33, !tbaa !24
  %t365 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s27, ptr %s27, ptr %t361, i64 %t362)
  store %"compiler/diag:Said" %t365, ptr %l186
  br label %bb90
bb90:
  %t366 = load %"compiler/diag:Said", ptr %l186
  store %"compiler/diag:Said" %t366, ptr %l34
  %t367 = getelementptr %"compiler/diag:Said", ptr %l34, i32 0, i32 0
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  %t369 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t372 = extractvalue { i64, ptr } %t368, 1
  %t373 = extractvalue { i64, ptr } %t368, 0
  %t374 = add i64 %t370, %t373
  %t375 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t374)
  call void @olang_textcopy(ptr %t375, ptr %t369, i64 %t370)
  %t376 = getelementptr i8, ptr %t375, i64 %t370
  call void @olang_textcopy(ptr %t376, ptr %t372, i64 %t373)
  %t377 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t375, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l15, { i64, ptr } %t385)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s28)
  br label %bb92
bb92:
  %t388 = load i64, ptr %l33, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l33, !tbaa !24
  br label %bb85
bb93:
  call void @__olang_scope_close(ptr %s27)
  %t393 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l15)
  store { i64, ptr } %t393, ptr %l194
  br label %bb94
bb94:
  %t394 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t394, ptr %l195, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l196, !tbaa !24
  %t397 = load i64, ptr %l196, !tbaa !24
  %t398 = mul i64 %t397, 1
  %t399 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l197, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l196, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t408, ptr %l195, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t409, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/parse:NameList"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/parse:NameList" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/parse:NameList" %t6, { i64, ptr } %a1, 1
  store %"compiler/parse:NameList" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:NameList", ptr %rv
  ret %"compiler/parse:NameList" %rr
}

define dso_local void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"compiler/parse:Parser"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l6, !tbaa !29
  store ptr %a1, ptr %l7, !tbaa !29
  store ptr %a2, ptr %l8, !tbaa !29
  store ptr %a3, ptr %l9, !tbaa !29
  store ptr %a4, ptr %l10, !tbaa !29
  store i64 %a5, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i32 0, ptr %l13
  store i32 0, ptr %l14, !tbaa !23
  store i32 0, ptr %l15
  store i32 0, ptr %l16, !tbaa !23
  store i1 false, ptr %l17, !tbaa !21
  store i1 false, ptr %l18, !tbaa !21
  store i1 false, ptr %l19, !tbaa !21
  store i1 false, ptr %l20, !tbaa !21
  store i1 false, ptr %l21, !tbaa !21
  store i1 false, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i64 0, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i64 -1, ptr %l28, !tbaa !24
  store i1 false, ptr %l29, !tbaa !21
  store i32 -1, ptr %l30, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l64
  br label %bb1
bb1:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l31
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l65
  br label %bb2
bb2:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l32
  %t19 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v5)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l66
  br label %bb3
bb3:
  %t20 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l33
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l67
  br label %bb4
bb4:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l34
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l68
  br label %bb5
bb5:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l35
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l69
  br label %bb6
bb6:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l36
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l70
  br label %bb7
bb7:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l37
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l71
  br label %bb8
bb8:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l38
  %t31 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l72
  br label %bb9
bb9:
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l39
  %t33 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l73
  br label %bb10
bb10:
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l40
  %t35 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l74
  br label %bb11
bb11:
  %t36 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l41
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l75
  br label %bb12
bb12:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l42
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l76
  br label %bb13
bb13:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l43
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l77
  br label %bb14
bb14:
  %t42 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l44
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb17:
  %t47 = mul i64 0, 8
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v5, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 0, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l45, !tbaa !27
  %t52 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l81
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb19:
  %t53 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l46
  %t54 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l82
  br label %bb20
bb20:
  %t55 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l47
  %t56 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l83
  br label %bb21
bb21:
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l48
  %t58 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l84
  br label %bb22
bb22:
  %t59 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l49
  store i1 false, ptr %l50, !tbaa !21
  store i1 false, ptr %l51, !tbaa !21
  %t60 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l85
  br label %bb23
bb23:
  %t61 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l52
  %t62 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l86
  br label %bb24
bb24:
  %t63 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t64 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 0
  %t65 = load ptr, ptr %l6, !tbaa !29
  store ptr %t65, ptr %t64, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 1
  %t67 = load ptr, ptr %l7, !tbaa !29
  store ptr %t67, ptr %t66, !tbaa !29
  %t68 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 2
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %t68, !tbaa !29
  %t70 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 3
  %t71 = load ptr, ptr %l9, !tbaa !29
  store ptr %t71, ptr %t70, !tbaa !29
  %t72 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 4
  %t73 = load ptr, ptr %l10, !tbaa !29
  store ptr %t73, ptr %t72, !tbaa !29
  %t74 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 5
  %t75 = load i64, ptr %l11, !tbaa !24
  store i64 %t75, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 6
  %t77 = load i64, ptr %l12, !tbaa !24
  store i64 %t77, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 7
  %t79 = load i32, ptr %l13
  store i32 %t79, ptr %t78
  %t80 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 8
  %t81 = load i32, ptr %l14, !tbaa !23
  store i32 %t81, ptr %t80, !tbaa !23
  %t82 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 9
  %t83 = load i32, ptr %l15
  store i32 %t83, ptr %t82
  %t84 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 10
  %t85 = load i32, ptr %l16, !tbaa !23
  store i32 %t85, ptr %t84, !tbaa !23
  %t86 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 11
  %t87 = load i1, ptr %l17, !tbaa !21
  store i1 %t87, ptr %t86, !tbaa !21
  %t88 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 12
  %t89 = load i1, ptr %l18, !tbaa !21
  store i1 %t89, ptr %t88, !tbaa !21
  %t90 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 13
  %t91 = load i1, ptr %l19, !tbaa !21
  store i1 %t91, ptr %t90, !tbaa !21
  %t92 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 14
  %t93 = load i1, ptr %l20, !tbaa !21
  store i1 %t93, ptr %t92, !tbaa !21
  %t94 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 15
  %t95 = load i1, ptr %l21, !tbaa !21
  store i1 %t95, ptr %t94, !tbaa !21
  %t96 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 16
  %t97 = load i1, ptr %l22, !tbaa !21
  store i1 %t97, ptr %t96, !tbaa !21
  %t98 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 17
  %t99 = load i64, ptr %l23, !tbaa !24
  store i64 %t99, ptr %t98, !tbaa !24
  %t100 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 18
  %t101 = load i1, ptr %l24, !tbaa !21
  store i1 %t101, ptr %t100, !tbaa !21
  %t102 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 19
  %t103 = load i1, ptr %l25, !tbaa !21
  store i1 %t103, ptr %t102, !tbaa !21
  %t104 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 20
  %t105 = load i64, ptr %l26, !tbaa !24
  store i64 %t105, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 21
  %t107 = load i1, ptr %l27, !tbaa !21
  store i1 %t107, ptr %t106, !tbaa !21
  %t108 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 22
  %t109 = load i64, ptr %l28, !tbaa !24
  store i64 %t109, ptr %t108, !tbaa !24
  %t110 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 23
  %t111 = load i1, ptr %l29, !tbaa !21
  store i1 %t111, ptr %t110, !tbaa !21
  %t112 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 24
  %t113 = load i32, ptr %l30, !tbaa !23
  store i32 %t113, ptr %t112, !tbaa !23
  %t114 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 25
  %t115 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %t114
  %t116 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 26
  %t117 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %t116
  %t118 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 27
  %t119 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %t118
  %t120 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 28
  %t121 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %t120
  %t122 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 29
  %t123 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %t122
  %t124 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 30
  %t125 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %t124
  %t126 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 31
  %t127 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %t126
  %t128 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 32
  %t129 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t128
  %t130 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 33
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %t130
  %t132 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 34
  %t133 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %t132
  %t134 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 35
  %t135 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %t134
  %t136 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 36
  %t137 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %t136
  %t138 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 37
  %t139 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %t138
  %t140 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 38
  %t141 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %t140
  %t142 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 39
  %t143 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t143, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 40
  %t145 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %t144
  %t146 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 41
  %t147 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %t146
  %t148 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 42
  %t149 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %t148
  %t150 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 43
  %t151 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t151, ptr %t150
  %t152 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 44
  %t153 = load i1, ptr %l50, !tbaa !21
  store i1 %t153, ptr %t152, !tbaa !21
  %t154 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 45
  %t155 = load i1, ptr %l51, !tbaa !21
  store i1 %t155, ptr %t154, !tbaa !21
  %t156 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 46
  %t157 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t157, ptr %t156
  %t158 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 47
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %t158
  %t160 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 48
  store i1 false, ptr %t160, !tbaa !21
  %t162 = getelementptr %"compiler/parse:Parser", ptr %l87, i32 0, i32 49
  store i1 false, ptr %t162, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l87, i64 320, i1 false)
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"export" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error word" }>, align 8
@.d2 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an element type before the [, as in I32[...]" }>, align 8
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"'fn' or 'type' - an extern block declares C's functions and types" }>, align 8
@.d4 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an expression" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(...)" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Base" }>, align 8
@.d10 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Element" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Target" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d13 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"outlives" }>, align 8
@.d14 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"outlives" }>, align 8
@.d15 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"commutes" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a type" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"an if" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a loop" }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a match" }>, align 8
@.d22 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a block (a block takes no ':')" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a join" }>, align 8
@.d24 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a defer" }>, align 8
@.d25 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an errdefer" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(chain " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(if " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(call " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(generic " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"expr" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"t.olang" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" -" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"decl" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" !" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i32 %a4)
declare { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclosesAngle(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5d5da79af2b44d73_2d4623f2243944cf = external constant [0 x i8]
@olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a = external constant [0 x i8]
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0)
declare %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2)
@olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9 = external constant [0 x i8]
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
@olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %a0)
@olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %a0)
declare %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
declare i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_79f3dc81f7edd3b9_5bcffd18fc721de5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowLeaves(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2eisJoiningOp(i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisOperandEnd(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandStartBefore(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendsRendering(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eoperandEndAfter(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etextPieceCalled(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %a0)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edecl(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eAt_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncItem(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3f74969944d00b69_b8e7e882b42021d = external constant [0 x i8]
@olang_loc_cbae392aecd52e99_b08c2106788b334d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineBody(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0)
@olang_loc_2d89971a269bae53_cb14c861cebe6e1f = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %a0, i32 %a1, ptr %a2)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eafter(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %a0)
@olang_loc_1c373b81de794f63_6badee9759230def = external constant [0 x i8]
declare %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %a0)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fparse_2epathIds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_caeb78b52908375_adc8a49ae9a90799 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_97d42995c5706fd7_20b731538cf045b = external constant [0 x i8]
@olang_loc_787ae3c3318fe322_f2232752b79280c6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_d545a7a4444f1737_b05c101f80cf2a13 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Outlives" @compiler_2fast_3aOutlives_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_913e5c935a5c1029_775f299487b9a2f5 = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0)
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprimary(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/msgs:Msg" %a3)
declare i1 @compiler_2fparse_2ebuiltinType(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %a0, i1 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econtractHere(ptr %v0, ptr %a0)
@olang_loc_682b81c4be20c47_acb581c54a6720db = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, i1 %a6, i1 %a7)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsShape(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b08fe5a62583e117_e5b5edd841fa1acb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %a0, i1 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %a0)
@olang_loc_47198c3f9d8413cf_be7184982b6f0763 = external constant [0 x i8]
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eanyHere(ptr %v0, ptr %a0)
@olang_loc_4b26d93c159ce468_272ef8e9c938d194 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_31e39d55c126667c_eaaf5fcb81f21700 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epiece(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4582cd3e20803687_2be8b05c8d066113 = external constant [0 x i8]
@olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e37d10a9f86ee49_f510a1627c721295 = external constant [0 x i8]
@olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53 = external constant [0 x i8]
@olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_94ee529efe0ddf52_d9208d758fca575e = external constant [0 x i8]
@olang_loc_944ad1edd3a79eba_8cd1e5aa7bbd35a6 = external constant [0 x i8]
@olang_loc_95becaa34f722781_c104ec8a8e14f09d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2eshapeStmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_936bfbc19493319b_da93a9696e3b504f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
