; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
define dso_local i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l1
  %t2 = load i32, ptr %l1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l2
  %t4 = load i64, ptr %l2
  %t5 = call i64 @std_2fprelude_2fhash_2emixHash(i64 %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fprelude_2fhash_2eI64_2eHash(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l1
  %t2 = load i64, ptr %l1
  %t3 = call i64 @std_2fprelude_2fhash_2emixHash(i64 %t2)
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i64, ptr %l2
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fprelude_2fhash_2emixHash(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l2
  %t2 = load i64, ptr %l2
  %t3 = mul i64 %t2, -7046029254386353131
  store i64 %t3, ptr %l3
  %t4 = load i64, ptr %l3
  store i64 %t4, ptr %l1
  %t5 = load i64, ptr %l1
  store i64 %t5, ptr %l4
  %t6 = load i64, ptr %l1
  store i64 %t6, ptr %l5
  %t7 = load i64, ptr %l5
  %t8 = ashr i64 %t7, 29
  store i64 %t8, ptr %l6
  %t9 = load i64, ptr %l4
  %t10 = load i64, ptr %l6
  %t11 = xor i64 %t9, %t10
  store i64 %t11, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l7
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_scope_close(ptr)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
