; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/doc:Example" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
@G_2ecompiler_2fdoc_2eStyle = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\73\02\00\00\00\00\00\00", ptr @G_2ecompiler_2fdoc_2eStyle.k1 }>, align 8
@G_2ecompiler_2fdoc_2eStyle.k1 = internal constant <{ [627 x i8] }> <{ [627 x i8] c"\62\6F\64\79\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\73\79\73\74\65\6D\2D\75\69\2C\73\61\6E\73\2D\73\65\72\69\66\3B\6D\61\78\2D\77\69\64\74\68\3A\35\32\72\65\6D\3B\6D\61\72\67\69\6E\3A\32\72\65\6D\20\61\75\74\6F\3B\70\61\64\64\69\6E\67\3A\30\20\31\72\65\6D\3B\6C\69\6E\65\2D\68\65\69\67\68\74\3A\31\2E\35\3B\63\6F\6C\6F\72\3A\23\31\64\31\64\31\66\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\66\66\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\35\66\35\66\37\3B\70\61\64\64\69\6E\67\3A\2E\35\72\65\6D\20\2E\37\35\72\65\6D\3B\62\6F\72\64\65\72\2D\72\61\64\69\75\73\3A\34\70\78\3B\6F\76\65\72\66\6C\6F\77\2D\78\3A\61\75\74\6F\3B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\7D\63\6F\64\65\2C\70\72\65\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\75\69\2D\6D\6F\6E\6F\73\70\61\63\65\2C\4D\65\6E\6C\6F\2C\6D\6F\6E\6F\73\70\61\63\65\3B\66\6F\6E\74\2D\73\69\7A\65\3A\2E\39\65\6D\7D\2E\64\6F\63\7B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\20\31\72\65\6D\20\31\72\65\6D\7D\2E\65\78\61\6D\70\6C\65\7B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\20\2E\35\72\65\6D\20\31\72\65\6D\7D\73\75\6D\6D\61\72\79\7B\63\75\72\73\6F\72\3A\70\6F\69\6E\74\65\72\7D\2E\6D\65\6D\62\65\72\7B\6D\61\72\67\69\6E\2D\6C\65\66\74\3A\31\2E\35\72\65\6D\7D\68\32\7B\62\6F\72\64\65\72\2D\62\6F\74\74\6F\6D\3A\31\70\78\20\73\6F\6C\69\64\20\23\64\64\64\3B\70\61\64\64\69\6E\67\2D\62\6F\74\74\6F\6D\3A\2E\32\35\72\65\6D\3B\6D\61\72\67\69\6E\2D\74\6F\70\3A\32\72\65\6D\7D\61\7B\63\6F\6C\6F\72\3A\23\30\62\35\37\64\30\7D\40\6D\65\64\69\61\28\70\72\65\66\65\72\73\2D\63\6F\6C\6F\72\2D\73\63\68\65\6D\65\3A\64\61\72\6B\29\7B\62\6F\64\79\7B\63\6F\6C\6F\72\3A\23\65\38\65\38\65\61\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\31\38\31\38\31\62\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\32\36\32\36\32\62\7D\61\7B\63\6F\6C\6F\72\3A\23\38\61\62\34\66\38\7D\68\32\7B\62\6F\72\64\65\72\2D\63\6F\6C\6F\72\3A\23\33\33\33\7D\7D" }>, align 64
define dso_local { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l100 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l121 = alloca i64
  %l123 = alloca { i64, ptr }
  %l130 = alloca %"std/prelude/text:StringBuilder"
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l154 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l162 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t3, i64 %a1)
  store i64 %t7, ptr %l16
  br label %bb2
bb2:
  %t8 = load i64, ptr %l16, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t15, i64 %t18)
  store i64 %t21, ptr %l23
  br label %bb7
bb7:
  %t22 = load i64, ptr %l23, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l24, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l27, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l28, !tbaa !24
  %t30 = load i64, ptr %l25, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb10:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb12:
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = getelementptr i8, ptr %t42, i64 %t43
  %t46 = sub i64 %t44, %t43
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  %t50 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t48)
  store { i64, ptr } %t50, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb14:
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s1, { i64, ptr } %t51, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t52, ptr %l34
  br label %bb15
bb15:
  %t53 = load i1, ptr %l34, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb3
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb23:
  br label %bb24
bb24:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = sub i64 %t65, 1
  %t70 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t64, i64 %t67)
  store i64 %t70, ptr %l43
  br label %bb25
bb25:
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l5, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = sub i64 %t74, 1
  store i64 %t76, ptr %l47, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load i64, ptr %l45, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb28:
  %t86 = load i64, ptr %l47, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb30:
  %t90 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l45, !tbaa !24
  %t93 = load i64, ptr %l47, !tbaa !24
  %t94 = getelementptr i8, ptr %t91, i64 %t92
  %t95 = sub i64 %t93, %t92
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t101 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t99)
  store i1 %t101, ptr %l54
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb32:
  %t102 = load i1, ptr %l54, !tbaa !21
  %t103 = xor i1 %t102, true
  br i1 %t103, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb34:
  br label %bb35
bb35:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp eq i64 %t105, 0
  br i1 %t107, label %bb36, label %bb37
bb36:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t109, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t111, ptr %l60
  br label %bb38
bb37:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb39
bb38:
  %t112 = load i1, ptr %l60, !tbaa !21
  store i1 %t112, ptr %l58, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l58, !tbaa !21
  br i1 %t113, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t114 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t114)
  br label %bb43
bb43:
  %t117 = load i64, ptr %l5, !tbaa !24
  store i64 %t117, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  br label %bb21
bb45:
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t120, ptr %l65
  br label %bb46
bb46:
  %t121 = load i64, ptr %l65, !tbaa !24
  %t122 = icmp eq i64 %t121, 0
  br i1 %t122, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l68, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l69, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l70, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l69, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t138, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t141, ptr %l72
  br label %bb50
bb50:
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = sub i64 %t142, 1
  store i64 %t143, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb51, label %bb52
bb51:
  %t149 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t149, ptr %l76, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t151 = load i64, ptr %l3, !tbaa !24
  %t153 = sub i64 %t151, 1
  %t156 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t150, i64 %t153)
  store i64 %t156, ptr %l80
  br label %bb53
bb52:
  br label %bb93
bb53:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = sub i64 %t157, 1
  store i64 %t159, ptr %l82, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l83, !tbaa !24
  %t162 = load i64, ptr %l80, !tbaa !24
  %t163 = icmp sge i64 %t162, 0
  br i1 %t163, label %bb54, label %bb55
bb54:
  %t165 = load i64, ptr %l80, !tbaa !24
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = icmp sle i64 %t165, %t166
  br i1 %t167, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb56:
  %t169 = load i64, ptr %l82, !tbaa !24
  %t170 = load i64, ptr %l83, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb58:
  %t173 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l80, !tbaa !24
  %t176 = load i64, ptr %l82, !tbaa !24
  %t177 = getelementptr i8, ptr %t174, i64 %t175
  %t178 = sub i64 %t176, %t175
  %t179 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  store { i64, ptr } %t180, ptr %l8, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = call i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %t182)
  store i64 %t184, ptr %l89
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb60:
  %t185 = load i64, ptr %l89, !tbaa !24
  store i64 %t185, ptr %l9, !tbaa !24
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = icmp sge i64 %t186, 0
  br i1 %t188, label %bb61, label %bb62
bb61:
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t190, ptr %l93, !tbaa !27
  %t191 = load i64, ptr %l9, !tbaa !24
  store i64 %t191, ptr %l94, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l95, !tbaa !24
  %t194 = icmp sge i64 0, 0
  br i1 %t194, label %bb63, label %bb64
bb62:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb70
bb63:
  %t196 = load i64, ptr %l94, !tbaa !24
  %t197 = icmp sle i64 0, %t196
  br i1 %t197, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb65:
  %t199 = load i64, ptr %l94, !tbaa !24
  %t200 = load i64, ptr %l95, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb67:
  %t203 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l94, !tbaa !24
  %t206 = getelementptr i8, ptr %t204, i64 0
  %t207 = sub i64 %t205, 0
  %t208 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t211 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t209)
  store { i64, ptr } %t211, ptr %l100
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb69:
  %t212 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t215 = icmp sgt i64 %t213, 0
  store i1 %t215, ptr %l92, !tbaa !21
  br label %bb70
bb70:
  %t217 = load i1, ptr %l92, !tbaa !21
  br i1 %t217, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb92
bb73:
  %t218 = load i64, ptr %l7, !tbaa !24
  %t220 = icmp sge i64 %t218, 0
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb74, label %bb75
bb74:
  br label %bb91
bb75:
  br label %bb76
bb76:
  %t224 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t224, ptr %l106, !tbaa !27
  %t225 = load i64, ptr %l7, !tbaa !24
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t225)
  store i64 %t228, ptr %l109
  br label %bb77
bb77:
  %t229 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t229, ptr %l110, !tbaa !27
  %t230 = load i64, ptr %l7, !tbaa !24
  %t233 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t230)
  store i64 %t233, ptr %l113
  br label %bb78
bb78:
  %t234 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t235 = load i64, ptr %l113, !tbaa !24
  %t236 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t234, i64 %t235)
  store i64 %t236, ptr %l114
  br label %bb79
bb79:
  %t237 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l115, !tbaa !24
  %t239 = load i64, ptr %l109, !tbaa !24
  %t240 = icmp sge i64 %t239, 0
  br i1 %t240, label %bb80, label %bb81
bb80:
  %t242 = load i64, ptr %l109, !tbaa !24
  %t243 = load i64, ptr %l114, !tbaa !24
  %t244 = icmp sle i64 %t242, %t243
  br i1 %t244, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb82:
  %t246 = load i64, ptr %l114, !tbaa !24
  %t247 = load i64, ptr %l115, !tbaa !24
  %t248 = icmp sle i64 %t246, %t247
  br i1 %t248, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb84:
  %t250 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l109, !tbaa !24
  %t253 = load i64, ptr %l114, !tbaa !24
  %t254 = getelementptr i8, ptr %t251, i64 %t252
  %t255 = sub i64 %t253, %t252
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  store { i64, ptr } %t257, ptr %l10, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l121, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t264 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t262)
  store { i64, ptr } %t264, ptr %l123
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb86:
  %t265 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t267 = load i64, ptr %l121, !tbaa !24
  %t269 = sub i64 %t267, %t266
  %t270 = load i64, ptr %l9, !tbaa !24
  %t273 = icmp ne i64 %t269, %t270
  br i1 %t273, label %bb87, label %bb88
bb87:
  br label %bb91
bb88:
  br label %bb89
bb89:
  %t275 = load i64, ptr %l7, !tbaa !24
  %t277 = sub i64 %t275, 1
  store i64 %t277, ptr %l7, !tbaa !24
  br label %bb90
bb90:
  br label %bb73
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t279 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t279, ptr %l130
  br label %bb94
bb94:
  %t280 = load %"std/prelude/text:StringBuilder", ptr %l130
  store %"std/prelude/text:StringBuilder" %t280, ptr %l11
  %t281 = load i64, ptr %l7, !tbaa !24
  store i64 %t281, ptr %l12, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s12
  %t283 = load i64, ptr %l12, !tbaa !24
  %t285 = icmp sge i64 %t283, 0
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s12)
  br label %bb115
bb97:
  br label %bb98
bb98:
  %t289 = load i64, ptr %l12, !tbaa !24
  %t290 = load i64, ptr %l7, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  br i1 %t293, label %bb99, label %bb100
bb99:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l11, i8 10)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  store ptr %l11, ptr %l139, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t296, ptr %l140, !tbaa !27
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t297)
  store i64 %t300, ptr %l143
  br label %bb103
bb103:
  %t301 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t301, ptr %l144, !tbaa !27
  %t302 = load i64, ptr %l12, !tbaa !24
  %t305 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t302)
  store i64 %t305, ptr %l147
  br label %bb104
bb104:
  %t306 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t307 = load i64, ptr %l147, !tbaa !24
  %t308 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t306, i64 %t307)
  store i64 %t308, ptr %l148
  br label %bb105
bb105:
  %t309 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  store i64 %t310, ptr %l149, !tbaa !24
  %t311 = load i64, ptr %l143, !tbaa !24
  %t312 = icmp sge i64 %t311, 0
  br i1 %t312, label %bb106, label %bb107
bb106:
  %t314 = load i64, ptr %l143, !tbaa !24
  %t315 = load i64, ptr %l148, !tbaa !24
  %t316 = icmp sle i64 %t314, %t315
  br i1 %t316, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb108:
  %t318 = load i64, ptr %l148, !tbaa !24
  %t319 = load i64, ptr %l149, !tbaa !24
  %t320 = icmp sle i64 %t318, %t319
  br i1 %t320, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb110:
  %t322 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = load i64, ptr %l143, !tbaa !24
  %t325 = load i64, ptr %l148, !tbaa !24
  %t326 = getelementptr i8, ptr %t323, i64 %t324
  %t327 = sub i64 %t325, %t324
  %t328 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t326, 1
  %t331 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s12, { i64, ptr } %t329)
  store { i64, ptr } %t331, ptr %l154
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb112:
  %t332 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = extractvalue { i64, ptr } %t332, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t339 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t339, { i64, ptr } %t338)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb114:
  %t341 = load i64, ptr %l12, !tbaa !24
  %t343 = sub i64 %t341, 1
  store i64 %t343, ptr %l12, !tbaa !24
  br label %bb95
bb115:
  %t346 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l11)
  store { i64, ptr } %t346, ptr %l159
  br label %bb116
bb116:
  %t347 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t347, ptr %l160, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l161, !tbaa !24
  %t350 = load i64, ptr %l161, !tbaa !24
  %t351 = mul i64 %t350, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  store { i64, ptr } %t354, ptr %l162, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l161, !tbaa !24
  %t360 = mul i64 %t359, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t356, ptr %t358, i64 %t360, i1 false)
  %t361 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t361, ptr %l160, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t362 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t362, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca i1
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = load ptr, ptr %lp3
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %lp3
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb2
bb2:
  %t13 = load i1, ptr %l8, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t18 = xor i1 %a2, true
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %lp3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l16
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb25
bb25:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 5
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t13, i64 %a1)
  store ptr %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l12, !tbaa !29
  store ptr %t18, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 6
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2d5d282533798e40_ae298936cea775c)
  unreachable
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/load:Module", ptr %t26, i32 0, i32 6
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 8
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = load ptr, ptr %lp3
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t35, { i64, ptr } %t39, { i64, ptr } %t33, { i64, ptr } %a2, ptr %t42)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %lp3
  %t49 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t48
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Module"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l9, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t3)
  store { i64, ptr } %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  br label %bb3
bb3:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb6:
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l21, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/doc:Module", ptr %t47, i64 %t44
  %t49 = load %"compiler/doc:Module", ptr %t48
  store %"compiler/doc:Module" %t49, ptr %l6
  store ptr %l2, ptr %l24, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v1, ptr %s3, { i64, ptr } %t52)
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t55 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s3, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l28
  br label %bb9
bb9:
  %t59 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t59, i64 %t60)
  %t76 = getelementptr i8, ptr %t75, i64 %t60
  call void @olang_textcopy(ptr %t76, ptr %t62, i64 %t63)
  %t77 = getelementptr i8, ptr %t76, i64 %t63
  call void @olang_textcopy(ptr %t77, ptr %t65, i64 %t66)
  %t78 = getelementptr i8, ptr %t77, i64 %t66
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = getelementptr i8, ptr %t78, i64 %t70
  call void @olang_textcopy(ptr %t79, ptr %t72, i64 %t73)
  %t80 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t75, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t89, { i64, ptr } %t88)
  br label %bb10
bb10:
  %t91 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = call { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v1, ptr %s3, { i64, ptr } %t92)
  store { i64, ptr } %t94, ptr %l32
  br label %bb11
bb11:
  %t95 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t95, ptr %l7, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t96, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t98, ptr %l34
  br label %bb12
bb12:
  %t99 = load i1, ptr %l34, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l2, ptr %l36, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s3, ptr %s5, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l38
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t105 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t122, { i64, ptr } %t121)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l4, !tbaa !24
  br label %bb4
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb21
bb21:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l45, !tbaa !27
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t132, ptr %l47
  br label %bb22
bb22:
  %t133 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t135 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t133, { i64, ptr } %t134)
  store { i64, ptr } %t135, ptr %l48
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/doc:Entry"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Entry"
  %l15 = alloca %"compiler/doc:Entry"
  %l16 = alloca i32
  %l18 = alloca %"compiler/doc:Entry"
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  store i64 %t2, ptr %l8, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t13 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t3, ptr %a1, ptr %a2, i64 %t6, { i64, ptr } %a4, i1 true)
  %t14 = extractvalue { i32, %"compiler/doc:Entry" } %t13, 1
  %t15 = extractvalue { i32, %"compiler/doc:Entry" } %t13, 0
  store i32 %t15, ptr %l16
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb2, label %ok.17, !prof !99
ok.17:
  store %"compiler/doc:Entry" %t14, ptr %l15
  br label %bb1
bb1:
  %t18 = load %"compiler/doc:Entry", ptr %l15
  store %"compiler/doc:Entry" %t18, ptr %l9
  br label %bb3
bb2:
  %t19 = load i32, ptr %l16, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 1, i32 0
  %t24 = icmp eq i32 %t19, 0
  %t25 = shl i32 %t23, 16
  %t26 = or i32 %t25, %t21
  %t27 = select i1 %t24, i32 0, i32 %t26
  call void @__olang_scope_close(ptr %s0)
  %t29 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t27, 0
  store { i32, { i64, ptr } } %t29, ptr %rv
  br label %ret
bb3:
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load %"compiler/doc:Entry", ptr %l9
  %t33 = call %"compiler/doc:Entry" @compiler_2fdoc_2eattached(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t30, i64 %t31, %"compiler/doc:Entry" %t32, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store %"compiler/doc:Entry" %t33, ptr %l18
  br label %bb4
bb4:
  %t34 = load %"compiler/doc:Entry", ptr %l18
  store %"compiler/doc:Entry" %t34, ptr %l5
  %t35 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t35, ptr %l19
  br label %bb5
bb5:
  %t36 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t36, ptr %l6
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s0, ptr %s0, ptr %l6, ptr %l5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb6
bb6:
  %t40 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l6)
  store { i64, ptr } %t40, ptr %l23
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t55, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t56, 1
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t5, i64 0)
  store i64 %t7, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t13, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t23, i64 %t24)
  store i64 %t27, ptr %l21
  br label %bb10
bb10:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb15:
  %t45 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t52)
  store i1 %t54, ptr %l30
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l1, !tbaa !24
  br label %bb21
bb21:
  br label %bb6
bb22:
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  br i1 %t66, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l40, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = icmp slt i64 %t84, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t94, i64 %t95)
  store i64 %t98, ptr %l49
  br label %bb28
bb27:
  br label %bb48
bb28:
  %t99 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb31:
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = load i64, ptr %l49, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t119)
  store { i64, ptr } %t121, ptr %l55
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb35:
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t122, ptr %l4, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t125, ptr %l57
  br label %bb36
bb36:
  %t126 = load i1, ptr %l57, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t131, ptr %l61
  br label %bb39
bb38:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb40
bb39:
  %t132 = load i1, ptr %l61, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb40
bb40:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t136, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t138, ptr %l65
  br label %bb43
bb42:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb44
bb43:
  %t139 = load i1, ptr %l65, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t142 = load i1, ptr %l63, !tbaa !21
  br i1 %t142, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t143, ptr %l68, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l69, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l70, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l69, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t159 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t159, ptr %l71
  br label %bb49
bb49:
  %t160 = load %"std/prelude/text:StringBuilder", ptr %l71
  store %"std/prelude/text:StringBuilder" %t160, ptr %l5
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %l6, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb52:
  br label %bb53
bb53:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t171, i64 %t172)
  store i64 %t175, ptr %l79
  br label %bb54
bb54:
  %t176 = load i64, ptr %l79, !tbaa !24
  store i64 %t176, ptr %l7, !tbaa !24
  %t177 = load i64, ptr %l6, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = icmp sgt i64 %t177, %t178
  br i1 %t181, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 10)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  store ptr %l5, ptr %l84, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l85, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  store i64 %t185, ptr %l86, !tbaa !24
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l87, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l88, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb59, label %bb60
bb59:
  %t192 = load i64, ptr %l86, !tbaa !24
  %t193 = load i64, ptr %l87, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb61:
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = load i64, ptr %l88, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb63:
  %t200 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l86, !tbaa !24
  %t203 = load i64, ptr %l87, !tbaa !24
  %t204 = getelementptr i8, ptr %t201, i64 %t202
  %t205 = sub i64 %t203, %t202
  %t206 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t204, 1
  %t209 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l93
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb65:
  %t210 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t217, { i64, ptr } %t216)
  br label %bb66
bb66:
  %t219 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb67:
  br label %bb50
bb68:
  %t224 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t224, ptr %l98
  br label %bb69
bb69:
  %t225 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t225, ptr %l99, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l100, !tbaa !24
  %t228 = load i64, ptr %l100, !tbaa !24
  %t229 = mul i64 %t228, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t229)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  store { i64, ptr } %t232, ptr %l101, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = load i64, ptr %l100, !tbaa !24
  %t238 = mul i64 %t237, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t234, ptr %t236, i64 %t238, i1 false)
  %t239 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t239, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t240 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t240, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"compiler/names:Entry"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i32
  %lp24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %lp34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l46 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/doc:Module"
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l112 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i64
  %l123 = alloca %"compiler/names:Entry"
  %l126 = alloca { i64, ptr }
  %l130 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l142 = alloca i64
  %l145 = alloca i1
  %l149 = alloca ptr
  %l156 = alloca i32
  %l159 = alloca i1
  %l161 = alloca i1
  %l162 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca { i64, ptr }
  %l171 = alloca i1
  %l175 = alloca i1
  %l179 = alloca %"compiler/doc:Entry"
  %l186 = alloca %"compiler/doc:Entry"
  %l187 = alloca i32
  %l189 = alloca i1
  %l198 = alloca i64
  %l202 = alloca i64
  %l205 = alloca i64
  %l226 = alloca ptr
  %l230 = alloca i64
  %l233 = alloca i1
  %l240 = alloca { i64, ptr }
  %l244 = alloca i1
  %l246 = alloca i1
  %l250 = alloca i64
  %l256 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %l267 = alloca %"compiler/doc:Entry"
  %l275 = alloca { i64, ptr }
  %l284 = alloca i64
  %l288 = alloca i64
  %l291 = alloca i64
  %l309 = alloca ptr
  %l310 = alloca i64
  %l311 = alloca ptr
  %l312 = alloca i64
  %l315 = alloca %"compiler/doc:Entry"
  %l316 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca %"compiler/doc:Module"
  %t171 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l46
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l46, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_df2a3aebcfae1327_f5257898d4c97893)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = extractvalue { i64, ptr } %t34, 0
  %t38 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t36, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l57, !tbaa !27
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l61, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v3, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l63
  br label %bb5
bb5:
  %t68 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t78 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t74)
  store %"compiler/doc:Module" %t78, ptr %l65
  br label %bb6
bb6:
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store ptr %t79, ptr %lp7
  %t80 = load %"compiler/doc:Module", ptr %l65
  %t81 = load ptr, ptr %lp7
  store %"compiler/doc:Module" %t80, ptr %t81
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/load:Loader", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l8, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/names:Resolver", ptr %t99, i32 0, i32 1
  %t102 = load i64, ptr %l3, !tbaa !24
  %t105 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l75
  br label %bb7
bb7:
  %t106 = load ptr, ptr %l75, !tbaa !29
  store ptr %t106, ptr %l9, !tbaa !29
  %t107 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l76
  br label %bb8
bb8:
  %t108 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/names:Table", ptr %t109, i32 0, i32 0
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l79
  br label %bb9
bb9:
  %t114 = load i64, ptr %l79, !tbaa !24
  store i64 %t114, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb10, label %bb11
bb10:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb15
bb12:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l86, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb14
bb14:
  %t141 = load i64, ptr %l86, !tbaa !24
  store i64 %t141, ptr %l83, !tbaa !24
  br label %bb15
bb15:
  %t142 = load i64, ptr %l83, !tbaa !24
  store i64 %t142, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t159)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t164 = load i64, ptr %l15, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l15, !tbaa !24
  br label %bb16
bb22:
  %t168 = load ptr, ptr %l9, !tbaa !29
  %t169 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t170 = ptrtoint ptr %t169 to i64
  %t172 = getelementptr { ptr, ptr }, ptr %t171, i32 0, i32 0
  store ptr %t168, ptr %t172, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t174 = getelementptr { ptr, ptr }, ptr %t171, i32 0, i32 1
  store ptr %v0, ptr %t174, !tbaa !28
  %t175 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_25, 0
  %t176 = insertvalue { ptr, ptr } %t175, ptr %t171, 1
  %t179 = extractvalue { ptr, ptr } %t176, 0
  %t180 = extractvalue { ptr, ptr } %t176, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l10, ptr %t179, ptr %t180)
  br label %bb23
bb23:
  store ptr %l10, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load i64, ptr %l18, !tbaa !24
  store i64 %t182, ptr %l112, !tbaa !24
  %t183 = load ptr, ptr %l17, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t183)
  store i64 %t185, ptr %l114
  br label %bb25
bb25:
  %t186 = load i64, ptr %l112, !tbaa !24
  %t187 = load i64, ptr %l114, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb79
bb27:
  br label %bb28
bb28:
  %t192 = load ptr, ptr %l17, !tbaa !29
  %t193 = load i64, ptr %l18, !tbaa !24
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t192, i64 %t193)
  store i64 %t196, ptr %l119
  br label %bb29
bb29:
  %t197 = load i64, ptr %l119, !tbaa !24
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/names:Table", ptr %t198, i32 0, i32 0
  %t204 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t200, i64 %t197)
  store %"compiler/names:Entry" %t204, ptr %l123
  br label %bb30
bb30:
  %t205 = load %"compiler/names:Entry", ptr %l123
  store %"compiler/names:Entry" %t205, ptr %l20
  %t206 = load ptr, ptr %l8, !tbaa !29
  %t207 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t206, i32 %t208)
  store { i64, ptr } %t211, ptr %l126
  br label %bb31
bb31:
  %t212 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t213, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l21, !tbaa !27
  %t219 = load i1, ptr %l4, !tbaa !21
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb32, label %bb33
bb32:
  %t223 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t225 = call i1 @compiler_2fdoc_2eExported(ptr %s7, { i64, ptr } %t223)
  store i1 %t225, ptr %l132
  br label %bb34
bb33:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb35
bb34:
  %t226 = load i1, ptr %l132, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l130, !tbaa !21
  br label %bb35
bb35:
  %t229 = load i1, ptr %l130, !tbaa !21
  br i1 %t229, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb37:
  br label %bb38
bb38:
  %t230 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t232 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s7, ptr %s7, { i64, ptr } %t230, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t232, ptr %l135
  br label %bb39
bb39:
  %t233 = load i1, ptr %l135, !tbaa !21
  br i1 %t233, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb41:
  br label %bb42
bb42:
  %t234 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t235 = load i32, ptr %t234, !range !{i32 0, i32 9}
  %t237 = trunc i64 3 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load i64, ptr %l3, !tbaa !24
  %t245 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t250 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t243, i64 %t244, i32 %t246)
  store i64 %t250, ptr %l142
  br label %bb45
bb44:
  %t251 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t252 = load i32, ptr %t251, !range !{i32 0, i32 9}
  %t254 = trunc i64 2 to i32
  %t255 = icmp eq i32 %t252, %t254
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb66, label %bb67
bb45:
  %t259 = load i64, ptr %l142, !tbaa !24
  store i64 %t259, ptr %l22, !tbaa !24
  %t260 = load i64, ptr %l22, !tbaa !24
  %t262 = icmp slt i64 %t260, 0
  br i1 %t262, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb49
bb47:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t268 = load i64, ptr %l22, !tbaa !24
  %t271 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t267, i64 %t268)
  store ptr %t271, ptr %l149
  br label %bb48
bb48:
  %t272 = load ptr, ptr %l149, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Func", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = icmp eq ptr %t275, null
  %t279 = xor i1 %t277, true
  store i1 %t279, ptr %l145, !tbaa !21
  br label %bb49
bb49:
  %t281 = load i1, ptr %l145, !tbaa !21
  br i1 %t281, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb51:
  br label %bb52
bb52:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i64, ptr %l22, !tbaa !24
  %t286 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t282, i64 %t283)
  store i32 %t286, ptr %l156
  br label %bb53
bb53:
  %t287 = load i32, ptr %l156, !tbaa !23
  store i32 %t287, ptr %l23, !tbaa !23
  %t288 = load i32, ptr %l23, !tbaa !23
  %t290 = icmp sge i32 %t288, 0
  br i1 %t290, label %bb54, label %bb55
bb54:
  %t292 = load i1, ptr %l4, !tbaa !21
  br i1 %t292, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb62
bb56:
  store i1 true, ptr %l161, !tbaa !21
  br label %bb61
bb57:
  %t294 = load ptr, ptr %l8, !tbaa !29
  store ptr %t294, ptr %l162, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/generic:Program", ptr %t298, i32 0, i32 2
  %t301 = load i32, ptr %l23, !tbaa !23
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t300, i32 %t301)
  store i32 %t304, ptr %l167
  br label %bb58
bb58:
  %t305 = load ptr, ptr %l162, !tbaa !29
  %t306 = load i32, ptr %l167, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t305, i32 %t306)
  store { i64, ptr } %t307, ptr %l168
  br label %bb59
bb59:
  %t308 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t310)
  call void @olang_textcopy(ptr %t311, ptr %t309, i64 %t310)
  %t312 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = mul i64 %t315, 1
  %t318 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t317)
  call void @llvm.memcpy.p0.p0.i64(ptr %t318, ptr %t316, i64 %t317, i1 false)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  %t322 = call i1 @compiler_2fdoc_2eExported(ptr %s11, { i64, ptr } %t320)
  store i1 %t322, ptr %l171
  br label %bb60
bb60:
  %t323 = load i1, ptr %l171, !tbaa !21
  store i1 %t323, ptr %l161, !tbaa !21
  br label %bb61
bb61:
  %t324 = load i1, ptr %l161, !tbaa !21
  store i1 %t324, ptr %l159, !tbaa !21
  br label %bb62
bb62:
  %t325 = load i1, ptr %l159, !tbaa !21
  br i1 %t325, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb66:
  %t326 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t327 = load i32, ptr %t326, !range !{i32 0, i32 9}
  %t329 = trunc i64 4 to i32
  %t330 = icmp eq i32 %t327, %t329
  %t332 = xor i1 %t330, true
  store i1 %t332, ptr %l175, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb68
bb68:
  %t334 = load i1, ptr %l175, !tbaa !21
  br i1 %t334, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = load i64, ptr %l3, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t340 = load i1, ptr %l4, !tbaa !21
  %t347 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s7, ptr %v3, ptr %t335, ptr %t336, ptr %a2, i64 %t338, { i64, ptr } %t339, i1 %t340)
  %t348 = extractvalue { i32, %"compiler/doc:Entry" } %t347, 1
  %t349 = extractvalue { i32, %"compiler/doc:Entry" } %t347, 0
  store i32 %t349, ptr %l187
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb74, label %ok.351, !prof !99
ok.351:
  store %"compiler/doc:Entry" %t348, ptr %l186
  br label %bb73
bb73:
  %t352 = load %"compiler/doc:Entry", ptr %l186
  store %"compiler/doc:Entry" %t352, ptr %l179
  br label %bb76
bb74:
  %t353 = load i32, ptr %l187, !tbaa !23
  %t354 = ashr i32 %t353, 16
  %t356 = icmp eq i32 %t354, 1
  store i1 %t356, ptr %l189, !tbaa !21
  br label %bb75
bb75:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb76:
  %t357 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 104, i64 8)
  store ptr %t357, ptr %lp24
  %t358 = load %"compiler/doc:Entry", ptr %l179
  %t359 = load ptr, ptr %lp24
  store %"compiler/doc:Entry" %t358, ptr %t359
  %t360 = load ptr, ptr %lp7
  %t361 = getelementptr %"compiler/doc:Module", ptr %t360, i32 0, i32 3
  %t362 = load ptr, ptr %lp24
  %t363 = load %"compiler/doc:Entry", ptr %t362
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t361, %"compiler/doc:Entry" %t363)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb78:
  %t366 = load i64, ptr %l18, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l18, !tbaa !24
  br label %bb24
bb79:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t373)
  br label %bb80
bb80:
  store i64 0, ptr %l25, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t378)
  store i64 %t380, ptr %l198
  br label %bb81
bb81:
  %t381 = load i64, ptr %l198, !tbaa !24
  store i64 %t381, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t382 = load i64, ptr %l26, !tbaa !24
  %t383 = load i64, ptr %l25, !tbaa !24
  %t386 = icmp sgt i64 %t382, %t383
  br i1 %t386, label %bb82, label %bb83
bb82:
  %t388 = load i64, ptr %l27, !tbaa !24
  %t390 = icmp sgt i64 %t388, 0
  br i1 %t390, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb87
bb84:
  %t392 = load i64, ptr %l26, !tbaa !24
  %t393 = load i64, ptr %l25, !tbaa !24
  %t396 = sub i64 %t392, %t393
  %t397 = load i64, ptr %l27, !tbaa !24
  %t400 = add i64 %t396, %t397
  %t402 = sub i64 %t400, 1
  %t403 = load i64, ptr %l27, !tbaa !24
  %t406 = sdiv i64 %t402, %t403
  store i64 %t406, ptr %l205, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb86
bb86:
  %t408 = load i64, ptr %l205, !tbaa !24
  store i64 %t408, ptr %l202, !tbaa !24
  br label %bb87
bb87:
  %t409 = load i64, ptr %l202, !tbaa !24
  store i64 %t409, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s20
  %t410 = load i64, ptr %l29, !tbaa !24
  %t411 = load i64, ptr %l28, !tbaa !24
  %t414 = icmp slt i64 %t410, %t411
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s20)
  br label %bb119
bb90:
  br label %bb91
bb91:
  %t418 = load i64, ptr %l25, !tbaa !24
  %t419 = load i64, ptr %l29, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  %t423 = mul i64 %t419, %t420
  %t426 = add i64 %t418, %t423
  store i64 %t426, ptr %l30, !tbaa !24
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t432 = load i64, ptr %l30, !tbaa !24
  %t435 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t431, i64 %t432)
  store ptr %t435, ptr %l226
  br label %bb92
bb92:
  %t436 = load ptr, ptr %l226, !tbaa !29
  store ptr %t436, ptr %l31, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t441 = load i64, ptr %l30, !tbaa !24
  %t444 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t440, i64 %t441)
  store i64 %t444, ptr %l230
  br label %bb93
bb93:
  %t445 = load i64, ptr %l3, !tbaa !24
  %t446 = load i64, ptr %l230, !tbaa !24
  %t448 = icmp ne i64 %t446, %t445
  br i1 %t448, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb96
bb95:
  %t450 = load ptr, ptr %l31, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = icmp eq ptr %t453, null
  store i1 %t455, ptr %l233, !tbaa !21
  br label %bb96
bb96:
  %t457 = load i1, ptr %l233, !tbaa !21
  br i1 %t457, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb98:
  br label %bb99
bb99:
  %t458 = load ptr, ptr %l8, !tbaa !29
  %t459 = load ptr, ptr %l31, !tbaa !29
  %t461 = getelementptr %"compiler/ast:Func", ptr %t459, i32 0, i32 2
  %t462 = load i32, ptr %t461, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t458, i32 %t462)
  store { i64, ptr } %t465, ptr %l240
  br label %bb100
bb100:
  %t466 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 1
  %t468 = extractvalue { i64, ptr } %t466, 0
  %t469 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t468)
  call void @olang_textcopy(ptr %t469, ptr %t467, i64 %t468)
  %t470 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t472 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t472, ptr %lp32
  %t474 = load ptr, ptr %lp32
  store { i64, ptr } %t471, ptr %t474, !tbaa !27
  %t475 = load i1, ptr %l4, !tbaa !21
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb101, label %bb102
bb101:
  %t479 = load ptr, ptr %lp32
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  %t482 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t480)
  store i1 %t482, ptr %l246
  br label %bb103
bb102:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb104
bb103:
  %t483 = load i1, ptr %l246, !tbaa !21
  %t484 = xor i1 %t483, true
  store i1 %t484, ptr %l244, !tbaa !21
  br label %bb104
bb104:
  %t486 = load i1, ptr %l244, !tbaa !21
  br i1 %t486, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb106:
  br label %bb107
bb107:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load i64, ptr %l30, !tbaa !24
  %t491 = call i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %t487, i64 %t488)
  store i64 %t491, ptr %l250
  br label %bb108
bb108:
  %t492 = load i64, ptr %l3, !tbaa !24
  %t493 = load i64, ptr %l250, !tbaa !24
  %t495 = icmp eq i64 %t493, %t492
  br i1 %t495, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb110:
  br label %bb111
bb111:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t499 = load i64, ptr %l30, !tbaa !24
  %t503 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v3, ptr %t497, ptr %t498, i64 %t499)
  store { i64, ptr } %t503, ptr %l256
  br label %bb112
bb112:
  %t504 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t505 = extractvalue { i64, ptr } %t504, 0
  %t506 = extractvalue { i64, ptr } %t504, 1
  %t507 = mul i64 %t505, 1
  %t508 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t507)
  call void @llvm.memcpy.p0.p0.i64(ptr %t508, ptr %t506, i64 %t507, i1 false)
  %t509 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  %t512 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v3, ptr %v3, { i64, ptr } %t510)
  store { i64, ptr } %t512, ptr %l258
  br label %bb113
bb113:
  %t513 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t513, ptr %lp33
  %t514 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t515 = load ptr, ptr %lp33
  store { i64, ptr } %t514, ptr %t515, !tbaa !27
  %t516 = load ptr, ptr %lp33
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  store { i64, ptr } %t517, ptr %l259, !tbaa !27
  %t518 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t519 = load ptr, ptr %l31, !tbaa !29
  %t521 = getelementptr %"compiler/ast:Func", ptr %t519, i32 0, i32 0
  %t522 = getelementptr %"compiler/source:Span", ptr %t521, i32 0, i32 0
  %t523 = load i32, ptr %t522, !tbaa !23
  %t525 = sext i32 %t523 to i64
  %t528 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v3, { i64, ptr } %t518, i64 %t525)
  store { i64, ptr } %t528, ptr %l264
  br label %bb114
bb114:
  %t529 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t529, 0
  %t531 = extractvalue { i64, ptr } %t529, 1
  %t532 = mul i64 %t530, 1
  %t533 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t532)
  call void @llvm.memcpy.p0.p0.i64(ptr %t533, ptr %t531, i64 %t532, i1 false)
  %t534 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t533, 1
  %t536 = load ptr, ptr %lp32
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t541 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t538, { i64, ptr } %t535, { i64, ptr } %t537)
  store %"compiler/doc:Entry" %t541, ptr %l267
  br label %bb115
bb115:
  %t542 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 104, i64 8)
  store ptr %t542, ptr %lp34
  %t543 = load %"compiler/doc:Entry", ptr %l267
  %t544 = load ptr, ptr %lp34
  store %"compiler/doc:Entry" %t543, ptr %t544
  %t545 = load ptr, ptr %l5, !tbaa !29
  %t547 = getelementptr %"compiler/load:Module", ptr %t545, i32 0, i32 4
  %t548 = load i64, ptr %t547, !tbaa !24
  %t550 = load ptr, ptr %lp34
  %t551 = getelementptr %"compiler/doc:Entry", ptr %t550, i32 0, i32 3
  store i64 %t548, ptr %t551, !tbaa !24
  %t552 = load ptr, ptr %l31, !tbaa !29
  %t554 = getelementptr %"compiler/ast:Func", ptr %t552, i32 0, i32 0
  %t555 = getelementptr %"compiler/source:Span", ptr %t554, i32 0, i32 0
  %t556 = load i32, ptr %t555, !tbaa !23
  %t558 = sext i32 %t556 to i64
  %t560 = load ptr, ptr %lp34
  %t561 = getelementptr %"compiler/doc:Entry", ptr %t560, i32 0, i32 4
  store i64 %t558, ptr %t561, !tbaa !24
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load i64, ptr %l30, !tbaa !24
  %t566 = call { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %s20, ptr %t562, i64 %t563)
  store { i64, ptr } %t566, ptr %l275
  br label %bb116
bb116:
  %t567 = load ptr, ptr %lp32
  %t568 = load { i64, ptr }, ptr %t567, !tbaa !27
  %t569 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t574 = add i64 %t571, %t573
  %t576 = extractvalue { i64, ptr } %t568, 1
  %t577 = extractvalue { i64, ptr } %t568, 0
  %t578 = add i64 %t574, %t577
  %t579 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t578)
  call void @olang_textcopy(ptr %t579, ptr %t570, i64 %t571)
  %t580 = getelementptr i8, ptr %t579, i64 %t571
  call void @olang_textcopy(ptr %t580, ptr %t572, i64 %t573)
  %t581 = getelementptr i8, ptr %t580, i64 %t573
  call void @olang_textcopy(ptr %t581, ptr %t576, i64 %t577)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t579, 1
  %t585 = extractvalue { i64, ptr } %t583, 0
  %t586 = extractvalue { i64, ptr } %t583, 1
  %t587 = mul i64 %t585, 1
  %t588 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t588, ptr %t586, i64 %t587, i1 false)
  %t589 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  %t592 = load ptr, ptr %lp34
  %t593 = getelementptr %"compiler/doc:Entry", ptr %t592, i32 0, i32 8
  store { i64, ptr } %t590, ptr %t593, !tbaa !27
  %t594 = load ptr, ptr %lp7
  %t595 = getelementptr %"compiler/doc:Module", ptr %t594, i32 0, i32 3
  %t596 = load ptr, ptr %lp34
  %t597 = load %"compiler/doc:Entry", ptr %t596
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t595, %"compiler/doc:Entry" %t597)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb118:
  %t600 = load i64, ptr %l29, !tbaa !24
  %t602 = add i64 %t600, 1
  store i64 %t602, ptr %l29, !tbaa !24
  br label %bb88
bb119:
  store i64 0, ptr %l35, !tbaa !24
  %t604 = load ptr, ptr %lp7
  %t605 = getelementptr %"compiler/doc:Module", ptr %t604, i32 0, i32 3
  %t607 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %t605)
  store i64 %t607, ptr %l284
  br label %bb120
bb120:
  %t608 = load i64, ptr %l284, !tbaa !24
  store i64 %t608, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t609 = load i64, ptr %l36, !tbaa !24
  %t610 = load i64, ptr %l35, !tbaa !24
  %t613 = icmp sgt i64 %t609, %t610
  br i1 %t613, label %bb121, label %bb122
bb121:
  %t615 = load i64, ptr %l37, !tbaa !24
  %t617 = icmp sgt i64 %t615, 0
  br i1 %t617, label %bb123, label %bb124
bb122:
  store i64 0, ptr %l288, !tbaa !24
  br label %bb126
bb123:
  %t619 = load i64, ptr %l36, !tbaa !24
  %t620 = load i64, ptr %l35, !tbaa !24
  %t623 = sub i64 %t619, %t620
  %t624 = load i64, ptr %l37, !tbaa !24
  %t627 = add i64 %t623, %t624
  %t629 = sub i64 %t627, 1
  %t630 = load i64, ptr %l37, !tbaa !24
  %t633 = sdiv i64 %t629, %t630
  store i64 %t633, ptr %l291, !tbaa !24
  br label %bb125
bb124:
  store i64 0, ptr %l291, !tbaa !24
  br label %bb125
bb125:
  %t635 = load i64, ptr %l291, !tbaa !24
  store i64 %t635, ptr %l288, !tbaa !24
  br label %bb126
bb126:
  %t636 = load i64, ptr %l288, !tbaa !24
  store i64 %t636, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb127
bb127:
  %t637 = load i64, ptr %l39, !tbaa !24
  %t638 = load i64, ptr %l38, !tbaa !24
  %t641 = icmp slt i64 %t637, %t638
  %t643 = xor i1 %t641, true
  br i1 %t643, label %bb128, label %bb129
bb128:
  br label %bb135
bb129:
  br label %bb130
bb130:
  %t645 = load i64, ptr %l35, !tbaa !24
  %t646 = load i64, ptr %l39, !tbaa !24
  %t647 = load i64, ptr %l37, !tbaa !24
  %t650 = mul i64 %t646, %t647
  %t653 = add i64 %t645, %t650
  store i64 %t653, ptr %l40, !tbaa !24
  %t655 = load ptr, ptr %lp7
  %t656 = getelementptr %"compiler/doc:Module", ptr %t655, i32 0, i32 3
  store ptr %t656, ptr %l309, !tbaa !29
  %t657 = load i64, ptr %l40, !tbaa !24
  store i64 %t657, ptr %l310, !tbaa !24
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l311, !tbaa !29
  %t659 = load i64, ptr %l3, !tbaa !24
  store i64 %t659, ptr %l312, !tbaa !24
  %t660 = load ptr, ptr %lp7
  %t661 = getelementptr %"compiler/doc:Module", ptr %t660, i32 0, i32 3
  %t662 = load i64, ptr %l40, !tbaa !24
  %t665 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t661, i64 %t662)
  store %"compiler/doc:Entry" %t665, ptr %l315
  br label %bb131
bb131:
  %t666 = load ptr, ptr %l311, !tbaa !29
  %t667 = load i64, ptr %l312, !tbaa !24
  %t668 = load %"compiler/doc:Entry", ptr %l315
  %t669 = call %"compiler/doc:Entry" @compiler_2fdoc_2eattached(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t666, i64 %t667, %"compiler/doc:Entry" %t668, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store %"compiler/doc:Entry" %t669, ptr %l316
  br label %bb132
bb132:
  %t670 = load ptr, ptr %l309, !tbaa !29
  %t671 = load i64, ptr %l310, !tbaa !24
  %t672 = load %"compiler/doc:Entry", ptr %l316
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t670, i64 %t671, %"compiler/doc:Entry" %t672)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t673 = load i64, ptr %l39, !tbaa !24
  %t675 = add i64 %t673, 1
  store i64 %t675, ptr %l39, !tbaa !24
  br label %bb127
bb135:
  %t677 = load ptr, ptr %lp7
  %t678 = load %"compiler/doc:Module", ptr %t677
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/doc:Module" %t678, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca i8
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 47
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i8 46, ptr %l20, !tbaa !22
  br label %bb8
bb7:
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l20, !tbaa !22
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t31, i8 %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb12
bb12:
  %t39 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t39, ptr %l26
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l28, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t55 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i8
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l34 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l51 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 64
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb57
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = icmp slt i64 %t22, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb46
bb10:
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  store i8 %t38, ptr %l4, !tbaa !22
  %t40 = load i1, ptr %l3, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load i8, ptr %l4, !tbaa !22
  %t44 = icmp eq i8 %t42, 92
  br i1 %t44, label %bb14, label %bb15
bb13:
  %t46 = load i8, ptr %l4, !tbaa !22
  %t48 = icmp eq i8 %t46, 34
  br i1 %t48, label %bb20, label %bb21
bb14:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l1, !tbaa !24
  br label %bb19
bb15:
  %t54 = load i8, ptr %l4, !tbaa !22
  %t56 = icmp eq i8 %t54, 34
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb44
bb20:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb43
bb21:
  %t58 = load i8, ptr %l4, !tbaa !22
  %t60 = icmp eq i8 %t58, 40
  br i1 %t60, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t62 = load i8, ptr %l4, !tbaa !22
  %t64 = icmp eq i8 %t62, 60
  store i1 %t64, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb42
bb26:
  %t71 = load i8, ptr %l4, !tbaa !22
  %t73 = icmp eq i8 %t71, 41
  br i1 %t73, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  %t75 = load i8, ptr %l4, !tbaa !22
  %t77 = icmp eq i8 %t75, 62
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l44, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l2, !tbaa !24
  br label %bb41
bb34:
  %t89 = load i8, ptr %l4, !tbaa !22
  %t91 = icmp eq i8 %t89, 32
  br i1 %t91, label %bb35, label %bb36
bb35:
  %t93 = load i64, ptr %l2, !tbaa !24
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l51, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb37
bb37:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t98 = load i64, ptr %l1, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb8
bb46:
  br label %bb47
bb47:
  %t102 = load i64, ptr %l1, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t108 = icmp slt i64 %t102, %t105
  br i1 %t108, label %bb48, label %bb49
bb48:
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t110, ptr %l61, !tbaa !27
  %t111 = load i64, ptr %l1, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = icmp eq i8 %t116, 32
  store i1 %t118, ptr %l60, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb50
bb50:
  %t120 = load i1, ptr %l60, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t123 = load i64, ptr %l1, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l1, !tbaa !24
  br label %bb54
bb54:
  br label %bb47
bb55:
  br label %bb56
bb56:
  br label %bb1
bb57:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l68, !tbaa !27
  %t128 = load i64, ptr %l1, !tbaa !24
  store i64 %t128, ptr %l69, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 0
  store i64 %t132, ptr %l72, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l73, !tbaa !24
  %t135 = load i64, ptr %l69, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb58, label %bb59
bb58:
  %t138 = load i64, ptr %l69, !tbaa !24
  %t139 = load i64, ptr %l72, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
bb60:
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = load i64, ptr %l73, !tbaa !24
  %t144 = icmp sle i64 %t142, %t143
  br i1 %t144, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
bb62:
  %t146 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l69, !tbaa !24
  %t149 = load i64, ptr %l72, !tbaa !24
  %t150 = getelementptr i8, ptr %t147, i64 %t148
  %t151 = sub i64 %t149, %t148
  %t152 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  store { i64, ptr } %t153, ptr %rv
  br label %ret
bb63:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l22 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l22
  br label %bb4
bb4:
  %t43 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l29
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l29, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l34
  br label %bb9
bb9:
  %t69 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb10, label %bb11
bb10:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l40, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  store ptr %t89, ptr %l43, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l2, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l48
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i32, ptr %l48, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t102, ptr %l49
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l40, !tbaa !29
  %t104 = load i32, ptr %l49, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l50
  br label %bb14
bb14:
  %t106 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb15:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load i64, ptr %l1, !tbaa !24
  %t120 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t116, i64 %t117)
  store ptr %t120, ptr %l55
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l55, !tbaa !29
  %t133 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %v1, ptr %t131, ptr %t130)
  store { i64, ptr } %t133, ptr %l60
  br label %bb17
bb17:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t134, ptr %lp3
  %t135 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t136 = load ptr, ptr %lp3
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp3
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t140, ptr %l62
  br label %bb18
bb18:
  %t141 = load i1, ptr %l62, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb19, label %bb20
bb19:
  %t144 = load ptr, ptr %lp3
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l64, !tbaa !27
  br label %bb22
bb20:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l2, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t147, i32 %t148)
  store { i64, ptr } %t151, ptr %l68
  br label %bb21
bb21:
  %t152 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t152, ptr %l64, !tbaa !27
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t1, i64 %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t7, i64 %t8)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l18, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb5:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb7:
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %t38)
  store i64 %t40, ptr %l25
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb9:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb19
bb11:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l31, !tbaa !24
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = icmp sle i64 0, %t52
  br i1 %t53, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb14:
  %t55 = load i64, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb16:
  %t59 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb18:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l28, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t90, ptr %l43
  br label %bb23
bb23:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t91, ptr %l6
  store ptr %l6, ptr %l44, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t94, 0
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l50, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load i64, ptr %l46, !tbaa !24
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb26:
  %t107 = load i64, ptr %l49, !tbaa !24
  %t108 = load i64, ptr %l50, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb28:
  %t111 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = load i64, ptr %l49, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s0, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l55
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb30:
  %t121 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t127)
  br label %bb31
bb31:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = icmp slt i64 %t134, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb34:
  br label %bb35
bb35:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t144, i64 %t145)
  store i64 %t148, ptr %l66
  br label %bb36
bb36:
  %t149 = load i64, ptr %l66, !tbaa !24
  store i64 %t149, ptr %l8, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l67, !tbaa !27
  %t151 = load i64, ptr %l7, !tbaa !24
  store i64 %t151, ptr %l68, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  store i64 %t152, ptr %l69, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l70, !tbaa !24
  %t155 = load i64, ptr %l68, !tbaa !24
  %t156 = icmp sge i64 %t155, 0
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t158 = load i64, ptr %l68, !tbaa !24
  %t159 = load i64, ptr %l69, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb39:
  %t162 = load i64, ptr %l69, !tbaa !24
  %t163 = load i64, ptr %l70, !tbaa !24
  %t164 = icmp sle i64 %t162, %t163
  br i1 %t164, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb41:
  %t166 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l68, !tbaa !24
  %t169 = load i64, ptr %l69, !tbaa !24
  %t170 = getelementptr i8, ptr %t167, i64 %t168
  %t171 = sub i64 %t169, %t168
  %t172 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  store { i64, ptr } %t173, ptr %l9, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t177 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t175)
  store i1 %t177, ptr %l76
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb43:
  %t178 = load i1, ptr %l76, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb47
bb45:
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l80, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t186 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t184)
  store { i64, ptr } %t186, ptr %l82
  br label %bb46
bb46:
  %t187 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = load i64, ptr %l80, !tbaa !24
  %t191 = sub i64 %t189, %t188
  %t192 = load i64, ptr %l5, !tbaa !24
  %t195 = icmp ne i64 %t191, %t192
  store i1 %t195, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t197 = load i1, ptr %l78, !tbaa !21
  br i1 %t197, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb49:
  br label %bb50
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 10)
  br label %bb51
bb51:
  store ptr %l6, ptr %l88, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t199)
  store { i64, ptr } %t201, ptr %l90
  br label %bb52
bb52:
  %t202 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t209, { i64, ptr } %t208)
  br label %bb53
bb53:
  %t211 = load i64, ptr %l8, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  br label %bb32
bb55:
  %t216 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t216, ptr %l95
  br label %bb56
bb56:
  %t217 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t217, ptr %l96, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l97, !tbaa !24
  %t220 = load i64, ptr %l97, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l98, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l97, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t231, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t232 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 125
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l9, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb45
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp eq i8 %t30, 35
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp ne i8 %t48, 10
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb10
bb18:
  br label %bb44
bb19:
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l36, !tbaa !24
  %t67 = load i64, ptr %l32, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb22:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb24:
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = load i64, ptr %l35, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %t85, { i64, ptr } %t86)
  store i1 %t89, ptr %l42
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb26:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb33
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = sub i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = call i1 @compiler_2fdoc_2ewordChar(i8 %t103)
  store i1 %t105, ptr %l51
  br label %bb31
bb31:
  %t106 = load i1, ptr %l51, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l46, !tbaa !21
  store i1 %t109, ptr %l43, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l43, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = add i64 %t111, %t114
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t123 = icmp sge i64 %t117, %t120
  br i1 %t123, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb40
bb36:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb39
bb37:
  %t125 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t125, ptr %l62, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = add i64 %t126, %t129
  %t134 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  %t139 = call i1 @compiler_2fdoc_2ewordChar(i8 %t137)
  store i1 %t139, ptr %l68
  br label %bb38
bb38:
  %t140 = load i1, ptr %l68, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t143 = load i1, ptr %l61, !tbaa !21
  store i1 %t143, ptr %l53, !tbaa !21
  br label %bb40
bb40:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb41, label %bb42
bb41:
  %t145 = load i64, ptr %l3, !tbaa !24
  store i64 %t145, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t147 = load i64, ptr %l3, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l3, !tbaa !24
  br label %bb44
bb44:
  br label %bb1
bb45:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/doc:Entry" @compiler_2fdoc_2eattached(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, %"compiler/doc:Entry" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/doc:Entry"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/doc:Entry"
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/doc:Entry"
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca %"compiler/doc:Entry"
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/doc:Entry"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/doc:Entry" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/doc:Entry", ptr %l2
  store %"compiler/doc:Entry" %t1, ptr %l4
  %t3 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 8
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i1, ptr %l11, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s1, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t10, ptr %l13
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = extractvalue { i64, ptr } %t13, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l14, !tbaa !27
  br label %bb7
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = extractvalue { i64, ptr } %t28, 0
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t30, 1
  %t39 = extractvalue { i64, ptr } %t30, 0
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t38, i64 %t39)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l14, !tbaa !27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t55 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 8
  store { i64, ptr } %t54, ptr %t55, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t56 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t59, ptr %l23
  br label %bb9
bb9:
  %t60 = load i1, ptr %l23, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l1, !tbaa !24
  %t65 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 8
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t70 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v1, ptr %t63, i64 %t64, { i64, ptr } %t66)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l28
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t71 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t72 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 7
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t72
  br label %bb13
bb13:
  %t73 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l29
  br label %bb14
bb14:
  %t74 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t74, ptr %lp5
  %t75 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t76 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %t76
  %t77 = getelementptr %"compiler/doc:Entry", ptr %l2, i32 0, i32 5
  store ptr %t77, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l7, !tbaa !24
  store i64 %t79, ptr %l31, !tbaa !24
  %t80 = load ptr, ptr %l6, !tbaa !29
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t80)
  store i64 %t82, ptr %l33
  br label %bb16
bb16:
  %t83 = load i64, ptr %l31, !tbaa !24
  %t84 = load i64, ptr %l33, !tbaa !24
  %t85 = icmp slt i64 %t83, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t89, i64 %t90)
  store %"compiler/doc:Entry" %t93, ptr %l38
  br label %bb20
bb20:
  %t94 = load %"compiler/doc:Entry", ptr %l38
  %t95 = load ptr, ptr %lp5
  store ptr %t95, ptr %l39, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l40, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l41, !tbaa !24
  store %"compiler/doc:Entry" %t94, ptr %l42
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t99, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t101, ptr %l44
  br label %bb21
bb21:
  %t102 = load i1, ptr %l44, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 8
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l45, !tbaa !27
  br label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l40, !tbaa !29
  %t107 = load i64, ptr %l41, !tbaa !24
  %t108 = load %"compiler/doc:Entry", ptr %l42
  %t109 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t110 = call %"compiler/doc:Entry" @compiler_2fdoc_2eattached(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t106, i64 %t107, %"compiler/doc:Entry" %t108, { i64, ptr } %t109)
  store %"compiler/doc:Entry" %t110, ptr %l47
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l39, !tbaa !29
  %t112 = load %"compiler/doc:Entry", ptr %l47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v1, ptr %t111, %"compiler/doc:Entry" %t112)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb15
bb28:
  %t117 = load ptr, ptr %lp5
  %t118 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t117
  %t120 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t120
  %t121 = load %"compiler/doc:Entry", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/doc:Entry" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Entry", ptr %rv
  ret %"compiler/doc:Entry" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/text:LineIter"
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca %"compiler/source:Span"
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"std/prelude/text:LineIter"
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l98 = alloca %"std/prelude/text:StringBuilder"
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l107 = alloca %"std/prelude/text:LineIter"
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l113 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l22
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t37 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t35, i64 %t34)
  store i64 %t37, ptr %l25
  br label %bb5
bb5:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = sub i64 %t43, 1
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l32
  br label %bb6
bb6:
  %t53 = getelementptr %"compiler/source:Span", ptr %l32, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t59 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t57, i64 %t56)
  store i64 %t59, ptr %l35
  br label %bb7
bb7:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load i64, ptr %l2, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb10:
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = load i64, ptr %l39, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb12:
  %t77 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l37, !tbaa !24
  %t80 = load i64, ptr %l38, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l44
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb14:
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 0
  %t95 = load ptr, ptr %t94, !tbaa !39
  %t97 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t95)
  store %"compiler/source:Span" %t97, ptr %l49
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t98 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l51, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = sub i64 %t105, 1
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l57
  br label %bb19
bb19:
  %t115 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l60, !tbaa !24
  %t121 = load i64, ptr %l51, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb20, label %bb21
bb20:
  %t124 = load i64, ptr %l51, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb22:
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb24:
  %t132 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = getelementptr i8, ptr %t133, i64 %t134
  %t137 = sub i64 %t135, %t134
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb26:
  store i64 -1, ptr %l4, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l67, !tbaa !24
  %t149 = load i64, ptr %l3, !tbaa !24
  store i64 %t149, ptr %l68, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l69, !tbaa !24
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb27, label %bb28
bb27:
  %t155 = load i64, ptr %l67, !tbaa !24
  %t156 = load i64, ptr %l68, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb29:
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = load i64, ptr %l69, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb31:
  %t163 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l67, !tbaa !24
  %t166 = load i64, ptr %l68, !tbaa !24
  %t167 = getelementptr i8, ptr %t164, i64 %t165
  %t168 = sub i64 %t166, %t165
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t170)
  store %"std/prelude/text:LineIter" %t172, ptr %l74
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb33:
  %t173 = load %"std/prelude/text:LineIter", ptr %l74
  store %"std/prelude/text:LineIter" %t173, ptr %l5
  br label %bb34
bb34:
  %t175 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l5)
  %t176 = extractvalue { i32, { i64, ptr } } %t175, 1
  %t177 = extractvalue { i32, { i64, ptr } } %t175, 0
  store i32 %t177, ptr %l78
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb36, label %ok.179, !prof !99
ok.179:
  store { i64, ptr } %t176, ptr %l77
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t180, ptr %l75, !tbaa !27
  br label %bb38
bb36:
  %t181 = load i32, ptr %l78, !tbaa !23
  %t182 = ashr i32 %t181, 16
  %t184 = icmp eq i32 %t182, 1
  store i1 %t184, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  br label %bb51
bb38:
  %t185 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t185, ptr %l6, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t188 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t186)
  store { i64, ptr } %t188, ptr %l82
  br label %bb39
bb39:
  %t189 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp eq i64 %t190, 0
  br i1 %t192, label %bb40, label %bb41
bb40:
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  store i64 %t196, ptr %l86, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t197)
  store { i64, ptr } %t199, ptr %l88
  br label %bb43
bb43:
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = load i64, ptr %l86, !tbaa !24
  %t204 = sub i64 %t202, %t201
  store i64 %t204, ptr %l7, !tbaa !24
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp slt i64 %t206, 0
  br i1 %t208, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t211 = load i64, ptr %l4, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  store i1 %t214, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t216 = load i1, ptr %l93, !tbaa !21
  br i1 %t216, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l7, !tbaa !24
  store i64 %t217, ptr %l4, !tbaa !24
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb34
bb51:
  %t219 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t219, ptr %l98
  br label %bb52
bb52:
  %t220 = load %"std/prelude/text:StringBuilder", ptr %l98
  store %"std/prelude/text:StringBuilder" %t220, ptr %l8
  store i1 true, ptr %l9, !tbaa !21
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t221, ptr %l99, !tbaa !27
  %t222 = load i64, ptr %l2, !tbaa !24
  store i64 %t222, ptr %l100, !tbaa !24
  %t223 = load i64, ptr %l3, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l102, !tbaa !24
  %t226 = load i64, ptr %l100, !tbaa !24
  %t227 = icmp sge i64 %t226, 0
  br i1 %t227, label %bb53, label %bb54
bb53:
  %t229 = load i64, ptr %l100, !tbaa !24
  %t230 = load i64, ptr %l101, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  br i1 %t231, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb55:
  %t233 = load i64, ptr %l101, !tbaa !24
  %t234 = load i64, ptr %l102, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb57:
  %t237 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l100, !tbaa !24
  %t240 = load i64, ptr %l101, !tbaa !24
  %t241 = getelementptr i8, ptr %t238, i64 %t239
  %t242 = sub i64 %t240, %t239
  %t243 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t244)
  store %"std/prelude/text:LineIter" %t246, ptr %l107
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb59:
  %t247 = load %"std/prelude/text:LineIter", ptr %l107
  store %"std/prelude/text:LineIter" %t247, ptr %l10
  br label %bb60
bb60:
  %t249 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l10)
  %t250 = extractvalue { i32, { i64, ptr } } %t249, 1
  %t251 = extractvalue { i32, { i64, ptr } } %t249, 0
  store i32 %t251, ptr %l111
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb62, label %ok.253, !prof !99
ok.253:
  store { i64, ptr } %t250, ptr %l110
  br label %bb61
bb61:
  %t254 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t254, ptr %l108, !tbaa !27
  br label %bb64
bb62:
  %t255 = load i32, ptr %l111, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l113, !tbaa !21
  br label %bb63
bb63:
  call void @__olang_ert_req_clear()
  br label %bb84
bb64:
  %t259 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t259, ptr %l11, !tbaa !27
  %t260 = load i1, ptr %l9, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb65, label %bb66
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 10)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  store i1 false, ptr %l9, !tbaa !21
  store ptr %l8, ptr %l117, !tbaa !29
  %t265 = load i64, ptr %l4, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb69, label %bb70
bb69:
  %t269 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = load i64, ptr %l4, !tbaa !24
  %t275 = icmp sge i64 %t271, %t272
  store i1 %t275, ptr %l120, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb71
bb71:
  %t277 = load i1, ptr %l120, !tbaa !21
  br i1 %t277, label %bb72, label %bb73
bb72:
  %t278 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t278, ptr %l126, !tbaa !27
  %t279 = load i64, ptr %l4, !tbaa !24
  store i64 %t279, ptr %l127, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t280, 0
  store i64 %t283, ptr %l130, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l131, !tbaa !24
  %t286 = load i64, ptr %l127, !tbaa !24
  %t287 = icmp sge i64 %t286, 0
  br i1 %t287, label %bb74, label %bb75
bb73:
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t291 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t289)
  store { i64, ptr } %t291, ptr %l137
  br label %bb80
bb74:
  %t292 = load i64, ptr %l127, !tbaa !24
  %t293 = load i64, ptr %l130, !tbaa !24
  %t294 = icmp sle i64 %t292, %t293
  br i1 %t294, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb76:
  %t296 = load i64, ptr %l130, !tbaa !24
  %t297 = load i64, ptr %l131, !tbaa !24
  %t298 = icmp sle i64 %t296, %t297
  br i1 %t298, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb78:
  %t300 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l127, !tbaa !24
  %t303 = load i64, ptr %l130, !tbaa !24
  %t304 = getelementptr i8, ptr %t301, i64 %t302
  %t305 = sub i64 %t303, %t302
  %t306 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t304, 1
  store { i64, ptr } %t307, ptr %l125, !tbaa !27
  br label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb80:
  %t309 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t309, ptr %l125, !tbaa !27
  br label %bb81
bb81:
  %t310 = load ptr, ptr %l117, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l125, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t310, { i64, ptr } %t311)
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb60
bb84:
  %t313 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l8)
  store { i64, ptr } %t313, ptr %l139
  br label %bb85
bb85:
  %t314 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t314, ptr %l140, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  store i64 %t316, ptr %l141, !tbaa !24
  %t317 = load i64, ptr %l141, !tbaa !24
  %t318 = mul i64 %t317, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t318)
  %t320 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l142, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = load i64, ptr %l141, !tbaa !24
  %t327 = mul i64 %t326, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t323, ptr %t325, i64 %t327, i1 false)
  %t328 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t328, ptr %l140, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t329 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t329, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l2, !tbaa !22
  %t19 = load i8, ptr %l2, !tbaa !22
  %t21 = icmp eq i8 %t19, 34
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 39
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb22
bb10:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp slt i64 %t32, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t47 = load i8, ptr %l2, !tbaa !22
  %t50 = icmp ne i8 %t46, %t47
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = icmp eq i8 %t61, 92
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i64, ptr %l1, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  br label %bb10
bb21:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb45
bb22:
  %t77 = load i8, ptr %l2, !tbaa !22
  %t79 = icmp eq i8 %t77, 35
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp slt i64 %t83, %t86
  br i1 %t89, label %bb25, label %bb26
bb24:
  br label %bb44
bb25:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = load i64, ptr %l1, !tbaa !24
  %t94 = add i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = icmp eq i8 %t99, 35
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l47, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t104, ptr %l54, !tbaa !27
  %t105 = load i64, ptr %l1, !tbaa !24
  %t107 = add i64 %t105, 2
  store i64 %t107, ptr %l56, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t108, 0
  store i64 %t111, ptr %l59, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l60, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = icmp sge i64 %t114, 0
  br i1 %t115, label %bb30, label %bb31
bb29:
  br label %bb43
bb30:
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb32:
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = load i64, ptr %l60, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb34:
  %t125 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = getelementptr i8, ptr %t126, i64 %t127
  %t130 = sub i64 %t128, %t127
  %t131 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t134 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  %t135 = extractvalue { i32, i64 } %t134, 1
  %t136 = extractvalue { i32, i64 } %t134, 0
  store i32 %t136, ptr %l66
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb37, label %ok.138, !prof !99
ok.138:
  store i64 %t135, ptr %l65
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb36:
  %t139 = load i64, ptr %l65, !tbaa !24
  store i64 %t139, ptr %l53, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb39
bb39:
  %t140 = load i64, ptr %l53, !tbaa !24
  store i64 %t140, ptr %l3, !tbaa !24
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  store i64 -1, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t146 = load i64, ptr %l1, !tbaa !24
  %t148 = add i64 %t146, 2
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = add i64 %t152, 2
  store i64 %t154, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb43:
  %t156 = load i64, ptr %l1, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb44:
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb1
bb46:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t8, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = icmp sge i64 1, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = icmp sle i64 1, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb5:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb7:
  %t23 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = getelementptr i8, ptr %t24, i64 1
  %t27 = sub i64 %t25, 1
  %t28 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t33, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb9:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  br label %bb19
bb12:
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb14:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb16:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %t57)
  store { i64, ptr } %t59, ptr %l26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb18:
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l29
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Entry"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l26 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/doc:Entry"
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca %"compiler/doc:Entry"
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l9, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb3
bb3:
  store ptr %l1, ptr %l15, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/doc:Module", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t37, ptr %l18
  br label %bb4
bb4:
  %t38 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t40 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t38, i64 %t39)
  %t48 = getelementptr i8, ptr %t47, i64 %t39
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = getelementptr i8, ptr %t48, i64 %t42
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t58)
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/doc:Module", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t64)
  br label %bb6
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/doc:Module", ptr %t67, i32 0, i32 3
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l26
  br label %bb7
bb7:
  %t72 = load i64, ptr %l26, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb23
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/doc:Module", ptr %t76, i32 0, i32 3
  store ptr %t78, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l31, !tbaa !24
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l33
  br label %bb12
bb12:
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = load i64, ptr %l33, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/doc:Entry" %t94, ptr %l38
  br label %bb16
bb16:
  %t95 = load %"compiler/doc:Entry", ptr %l38
  store %"compiler/doc:Entry" %t95, ptr %l4
  store ptr %l1, ptr %l39, !tbaa !29
  %t96 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t97)
  store { i64, ptr } %t99, ptr %l41
  br label %bb17
bb17:
  %t100 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l43
  br label %bb18
bb18:
  %t104 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t106 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t110, i64 %t111)
  %t123 = getelementptr i8, ptr %t122, i64 %t111
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t120, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t134, { i64, ptr } %t133)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l3, !tbaa !24
  br label %bb11
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/doc:Module", ptr %t141, i32 0, i32 3
  store ptr %t143, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s9
  %t145 = load i64, ptr %l6, !tbaa !24
  store i64 %t145, ptr %l51, !tbaa !24
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l53
  br label %bb25
bb25:
  %t149 = load i64, ptr %l51, !tbaa !24
  %t150 = load i64, ptr %l53, !tbaa !24
  %t151 = icmp slt i64 %t149, %t150
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t156 = load i64, ptr %l6, !tbaa !24
  %t159 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t155, i64 %t156)
  store %"compiler/doc:Entry" %t159, ptr %l58
  br label %bb29
bb29:
  %t160 = load %"compiler/doc:Entry", ptr %l58
  store %"compiler/doc:Entry" %t160, ptr %l7
  call void @compiler_2fdoc_2eentryHtml(ptr %s0, ptr %s9, ptr %l1, ptr %l7, i1 false)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb31:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l6, !tbaa !24
  br label %bb24
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/doc:Module", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l64, !tbaa !27
  %t172 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t172, ptr %l66
  br label %bb33
bb33:
  %t173 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t175 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t173, { i64, ptr } %t174)
  store { i64, ptr } %t175, ptr %l67
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/doc:Entry"
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t10 = extractvalue { i64, ptr } %t6, 1
  %t11 = extractvalue { i64, ptr } %t6, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t27)
  br label %bb2
bb2:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/doc:Module", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t35, ptr %l13
  br label %bb3
bb3:
  %t36 = load i1, ptr %l13, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/doc:Module", ptr %t40, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  call void @compiler_2fdoc_2eindented(ptr %s0, ptr %v0, ptr %s2, ptr %l1, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/doc:Module", ptr %t46, i32 0, i32 3
  store ptr %t48, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l21, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l23
  br label %bb10
bb10:
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/doc:Entry" %t64, ptr %l28
  br label %bb14
bb14:
  %t65 = load %"compiler/doc:Entry", ptr %l28
  store %"compiler/doc:Entry" %t65, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb15
bb15:
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s4, ptr %s4, ptr %l1, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb9
bb18:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t74, ptr %l35
  br label %bb19
bb19:
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l37, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t89, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Entry"
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i32
  %l30 = alloca ptr
  %l34 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca i32
  %l73 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i64
  %l83 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l18, !tbaa !27
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l20, !tbaa !24
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb30
bb7:
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = icmp sle i64 0, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb9:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb11:
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 0
  %t33 = sub i64 %t31, 0
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %l17, !tbaa !24
  %t39 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %t36, i64 %t37, { i64, ptr } %t35)
  store i32 %t39, ptr %l25
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb13:
  %t40 = load i32, ptr %l25, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp slt i32 %t41, 0
  br i1 %t43, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l34
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/load:Loader", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t72, 0
  store i64 %t75, ptr %l44, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l45, !tbaa !24
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = icmp sge i64 %t78, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb20:
  %t85 = load i64, ptr %l44, !tbaa !24
  %t86 = load i64, ptr %l45, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  br i1 %t87, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb22:
  %t89 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = load i64, ptr %l44, !tbaa !24
  %t93 = getelementptr i8, ptr %t90, i64 %t91
  %t94 = sub i64 %t92, %t91
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t99 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t97, { i64, ptr } %t96)
  store i32 %t99, ptr %l50
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb24:
  %t100 = load ptr, ptr %l30, !tbaa !29
  %t101 = load i32, ptr %l34, !tbaa !23
  %t102 = load i32, ptr %l50, !tbaa !23
  %t103 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t100, i32 %t101, i32 %t102)
  store i64 %t103, ptr %l51
  br label %bb25
bb25:
  %t104 = load i64, ptr %l51, !tbaa !24
  store i64 %t104, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb29
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l58
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Func", ptr %t117, i32 0, i32 0
  %t120 = getelementptr %"compiler/source:Span", ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = sext i32 %t121 to i64
  store i64 %t123, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load i64, ptr %l54, !tbaa !24
  store i64 %t125, ptr %rv
  br label %ret
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t136)
  store i32 %t139, ptr %l67
  br label %bb31
bb31:
  %t140 = load i32, ptr %l67, !tbaa !23
  store i32 %t140, ptr %l6, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/names:Resolver", ptr %t147, i32 0, i32 1
  %t150 = load i64, ptr %l1, !tbaa !24
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t149, i64 %t150)
  store ptr %t153, ptr %l73
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l73, !tbaa !29
  %t156 = getelementptr %"compiler/names:Table", ptr %t154, i32 0, i32 0
  store ptr %t156, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb33
bb33:
  %t158 = load i64, ptr %l8, !tbaa !24
  store i64 %t158, ptr %l76, !tbaa !24
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l78
  br label %bb34
bb34:
  %t162 = load i64, ptr %l76, !tbaa !24
  %t163 = load i64, ptr %l78, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t168 = load ptr, ptr %l7, !tbaa !29
  %t169 = load i64, ptr %l8, !tbaa !24
  %t172 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store %"compiler/names:Entry" %t172, ptr %l83
  br label %bb38
bb38:
  %t173 = load %"compiler/names:Entry", ptr %l83
  store %"compiler/names:Entry" %t173, ptr %l9
  %t174 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 0
  %t175 = load i32, ptr %t174, !tbaa !23
  %t176 = load i32, ptr %l6, !tbaa !23
  %t179 = icmp eq i32 %t175, %t176
  br i1 %t179, label %bb39, label %bb40
bb39:
  %t181 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 1
  %t182 = getelementptr %"compiler/source:Span", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  call void @__olang_scope_close(ptr %s0)
  store i64 %t185, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l8, !tbaa !24
  br label %bb33
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca { ptr, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l11
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t9 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_61, 0
  %t10 = insertvalue { ptr, ptr } %t9, ptr null, 1
  store { ptr, ptr } %t10, ptr %l4
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t12)
  store %"std/prelude/text:LineIter" %t14, ptr %l14
  br label %bb7
bb7:
  %t15 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t15, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l5)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l17
  br label %bb9
bb9:
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb12
bb10:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb12:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = load { ptr, ptr }, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i1, ptr %l3, !tbaa !21
  %t36 = extractvalue { ptr, ptr } %t32, 0
  %t37 = extractvalue { ptr, ptr } %t32, 1
  call void %t36(ptr %t37, ptr %s0, ptr %v0, ptr %l2, ptr %t33, i1 %t34)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb17:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t41, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t43, ptr %l28
  br label %bb18
bb18:
  %t44 = load i1, ptr %l28, !tbaa !21
  store i1 %t44, ptr %l7, !tbaa !21
  %t46 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t46, ptr %l30
  br label %bb19
bb19:
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = icmp sgt i64 %t47, 0
  br i1 %t48, label %bb20, label %bb21
bb20:
  %t50 = load i1, ptr %l7, !tbaa !21
  %t51 = load i1, ptr %l3, !tbaa !21
  %t54 = icmp ne i1 %t50, %t51
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load { ptr, ptr }, ptr %l4
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l3, !tbaa !21
  %t61 = extractvalue { ptr, ptr } %t57, 0
  %t62 = extractvalue { ptr, ptr } %t57, 1
  call void %t61(ptr %t62, ptr %s0, ptr %v0, ptr %l2, ptr %t58, i1 %t59)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t66 = load i1, ptr %l7, !tbaa !21
  store i1 %t66, ptr %l3, !tbaa !21
  %t69 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t69, ptr %l42
  br label %bb27
bb27:
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = icmp sgt i64 %t70, 0
  br i1 %t71, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  store ptr %l2, ptr %l45, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb34, label %bb35
bb33:
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t85, ptr %l47, !tbaa !27
  br label %bb40
bb34:
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = icmp sle i64 4, %t87
  br i1 %t88, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb36:
  %t90 = load i64, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb38:
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 4
  %t98 = sub i64 %t96, 4
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb40:
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t102, { i64, ptr } %t103)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  br label %bb8
bb43:
  %t104 = load { ptr, ptr }, ptr %l4
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i1, ptr %l3, !tbaa !21
  %t108 = extractvalue { ptr, ptr } %t104, 0
  %t109 = extractvalue { ptr, ptr } %t104, 1
  call void %t108(ptr %t109, ptr %s0, ptr %v0, ptr %l2, ptr %t105, i1 %t106)
  br label %bb44
bb44:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Example"
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/doc:Entry"
  %l15 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca %"compiler/doc:Example"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca %"compiler/doc:Entry"
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t3, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/doc:Entry", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t13, ptr %l17
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/doc:Entry", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l20
  br label %bb6
bb6:
  %t20 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t20, i64 %t21)
  %t37 = getelementptr i8, ptr %t36, i64 %t21
  call void @olang_textcopy(ptr %t37, ptr %t23, i64 %t24)
  %t38 = getelementptr i8, ptr %t37, i64 %t24
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t36, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t50 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t50, { i64, ptr } %t49)
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/doc:Entry", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %t52, { i64, ptr } %t56)
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/doc:Entry", ptr %t59, i32 0, i32 7
  store ptr %t61, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l28, !tbaa !24
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t64)
  store i64 %t66, ptr %l30
  br label %bb10
bb10:
  %t67 = load i64, ptr %l28, !tbaa !24
  %t68 = load i64, ptr %l30, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t73, i64 %t74)
  store %"compiler/doc:Example" %t77, ptr %l35
  br label %bb14
bb14:
  %t78 = load %"compiler/doc:Example", ptr %l35
  store %"compiler/doc:Example" %t78, ptr %l6
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l36, !tbaa !29
  %t80 = getelementptr %"compiler/doc:Example", ptr %l6, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t81)
  store { i64, ptr } %t83, ptr %l38
  br label %bb15
bb15:
  %t84 = getelementptr %"compiler/doc:Example", ptr %l6, i32 0, i32 1
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t85)
  store { i64, ptr } %t87, ptr %l40
  br label %bb16
bb16:
  %t88 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t88, i64 %t89)
  %t105 = getelementptr i8, ptr %t104, i64 %t89
  call void @olang_textcopy(ptr %t105, ptr %t91, i64 %t92)
  %t106 = getelementptr i8, ptr %t105, i64 %t92
  call void @olang_textcopy(ptr %t106, ptr %t94, i64 %t95)
  %t107 = getelementptr i8, ptr %t106, i64 %t95
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t104, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t118, { i64, ptr } %t117)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l5, !tbaa !24
  br label %bb9
bb19:
  store i1 false, ptr %l7, !tbaa !21
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/doc:Entry", ptr %t124, i32 0, i32 5
  store ptr %t126, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load i64, ptr %l9, !tbaa !24
  store i64 %t128, ptr %l47, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t129)
  store i64 %t131, ptr %l49
  br label %bb21
bb21:
  %t132 = load i64, ptr %l47, !tbaa !24
  %t133 = load i64, ptr %l49, !tbaa !24
  %t134 = icmp slt i64 %t132, %t133
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t138 = load ptr, ptr %l8, !tbaa !29
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t138, i64 %t139)
  store %"compiler/doc:Entry" %t142, ptr %l54
  br label %bb25
bb25:
  %t143 = load %"compiler/doc:Entry", ptr %l54
  store %"compiler/doc:Entry" %t143, ptr %l10
  %t144 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 6
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb26, label %bb27
bb26:
  %t147 = load i1, ptr %l7, !tbaa !21
  %t149 = xor i1 %t147, true
  store i1 %t149, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t151 = load i1, ptr %l56, !tbaa !21
  br i1 %t151, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s9
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t152, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t154 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 6
  %t155 = load i1, ptr %t154, !tbaa !21
  store i1 %t155, ptr %l7, !tbaa !21
  %t157 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %s8, ptr %t157, ptr %l10, i1 true)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  %t160 = load i64, ptr %l9, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l9, !tbaa !24
  br label %bb20
bb35:
  %t164 = load i1, ptr %l2, !tbaa !21
  br i1 %t164, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s11
  %t166 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t166, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Example"
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/doc:Entry"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l28 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca %"compiler/doc:Example"
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca %"compiler/doc:Entry"
  %l69 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/doc:Entry", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t7, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l3)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l17
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  br label %bb6
bb4:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb6:
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = extractvalue { i64, ptr } %t21, 0
  %t27 = extractvalue { i64, ptr } %t19, 1
  %t28 = extractvalue { i64, ptr } %t19, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = getelementptr i8, ptr %t33, i64 %t25
  call void @olang_textcopy(ptr %t34, ptr %t27, i64 %t28)
  %t35 = getelementptr i8, ptr %t34, i64 %t28
  call void @olang_textcopy(ptr %t35, ptr %t30, i64 %t31)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t33, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t20, { i64, ptr } %t44)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  br label %bb2
bb9:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/doc:Entry", ptr %t47, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t52, ptr %l28
  br label %bb10
bb10:
  %t53 = load i1, ptr %l28, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/doc:Entry", ptr %t57, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = getelementptr i8, ptr %t68, i64 %t64
  call void @olang_textcopy(ptr %t69, ptr %t65, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s4, ptr %t56, { i64, ptr } %t60, { i64, ptr } %t78)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/doc:Entry", ptr %t82, i32 0, i32 7
  store ptr %t84, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load i64, ptr %l6, !tbaa !24
  store i64 %t86, ptr %l38, !tbaa !24
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t87)
  store i64 %t89, ptr %l40
  br label %bb16
bb16:
  %t90 = load i64, ptr %l38, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t96, i64 %t97)
  store %"compiler/doc:Example" %t100, ptr %l45
  br label %bb20
bb20:
  %t101 = load %"compiler/doc:Example", ptr %l45
  store %"compiler/doc:Example" %t101, ptr %l7
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t103, 1
  %t108 = extractvalue { i64, ptr } %t103, 0
  %t109 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t105, 1
  %t114 = extractvalue { i64, ptr } %t105, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t107, i64 %t108)
  %t120 = getelementptr i8, ptr %t119, i64 %t108
  call void @olang_textcopy(ptr %t120, ptr %t109, i64 %t110)
  %t121 = getelementptr i8, ptr %t120, i64 %t110
  call void @olang_textcopy(ptr %t121, ptr %t113, i64 %t114)
  %t122 = getelementptr i8, ptr %t121, i64 %t114
  call void @olang_textcopy(ptr %t122, ptr %t116, i64 %t117)
  %t123 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t119, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t102, { i64, ptr } %t131)
  br label %bb21
bb21:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 1
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t139, i64 %t140)
  %t145 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t145, ptr %t141, i64 %t142)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } %t147, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s7, ptr %t134, { i64, ptr } %t136, { i64, ptr } %t154)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb15
bb24:
  store i1 false, ptr %l8, !tbaa !21
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/doc:Entry", ptr %t162, i32 0, i32 5
  store ptr %t164, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s12
  %t166 = load i64, ptr %l10, !tbaa !24
  store i64 %t166, ptr %l60, !tbaa !24
  %t167 = load ptr, ptr %l9, !tbaa !29
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t167)
  store i64 %t169, ptr %l62
  br label %bb26
bb26:
  %t170 = load i64, ptr %l60, !tbaa !24
  %t171 = load i64, ptr %l62, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s12)
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l9, !tbaa !29
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t176, i64 %t177)
  store %"compiler/doc:Entry" %t180, ptr %l67
  br label %bb30
bb30:
  %t181 = load %"compiler/doc:Entry", ptr %l67
  store %"compiler/doc:Entry" %t181, ptr %l11
  %t182 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t183 = load i1, ptr %t182, !tbaa !21
  br i1 %t183, label %bb31, label %bb32
bb31:
  %t185 = load i1, ptr %l8, !tbaa !21
  %t187 = xor i1 %t185, true
  store i1 %t187, ptr %l69, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb33
bb33:
  %t189 = load i1, ptr %l69, !tbaa !21
  br i1 %t189, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s13
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = getelementptr i8, ptr %t198, i64 %t194
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t190, { i64, ptr } %t208)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s13)
  br label %bb37
bb37:
  %t211 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t212 = load i1, ptr %t211, !tbaa !21
  store i1 %t212, ptr %l8, !tbaa !21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t217, i64 %t218)
  %t223 = getelementptr i8, ptr %t222, i64 %t218
  call void @olang_textcopy(ptr %t223, ptr %t219, i64 %t220)
  %t224 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t222, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  call void @compiler_2fdoc_2eentryText(ptr %v0, ptr %s12, ptr %s12, ptr %t214, ptr %l11, { i64, ptr } %t232)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s12)
  br label %bb39
bb39:
  %t236 = load i64, ptr %l10, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l10, !tbaa !24
  br label %bb25
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/doc:Example"
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca ptr
  %l72 = alloca ptr
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l8, !tbaa !29
  %t23 = load ptr, ptr %l8, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 6
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l8, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35
  store { i64, ptr } %t36, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  br label %bb19
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v1, ptr %v0, ptr %s3, ptr %t38, ptr %t48)
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %v3, { i64, ptr } %t58, { i64, ptr } %t59)
  store i1 %t62, ptr %l35
  br label %bb11
bb11:
  %t63 = load i1, ptr %l35, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l4, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v1, ptr %v2, ptr %v4, ptr %t67, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l40
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v2, ptr %v1, ptr %v4, { i64, ptr } %t79, { i64, ptr } %t80)
  store { i64, ptr } %t83, ptr %l44
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t93 = call %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t91, { i64, ptr } %t90)
  store %"compiler/doc:Example" %t93, ptr %l46
  br label %bb17
bb17:
  %t94 = load ptr, ptr %l37, !tbaa !29
  %t95 = load %"compiler/doc:Example", ptr %l46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v4, ptr %v4, ptr %t94, %"compiler/doc:Example" %t95)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb19:
  %t96 = load ptr, ptr %l8, !tbaa !29
  store ptr %t96, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 11}
  %t103 = icmp eq i64 %t101, 7
  store i1 %t103, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l48, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load ptr, ptr %l8, !tbaa !29
  %t107 = getelementptr { i64, [6 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", ptr }, ptr %t107, i32 0, i32 1
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb39
bb24:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = getelementptr %"compiler/ast:TopIf", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb25, label %bb26
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l57, !tbaa !29
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TopIf", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e)
  unreachable
bb28:
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/ast:TopIf", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t134 = getelementptr %"compiler/ast:TopBranch", ptr %t131, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t139 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t139, { i64, ptr } %t135, { i64, ptr } %t136, { i64, ptr } %t137, ptr %t138)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:TopIf", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb32, label %bb33
bb32:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l72, !tbaa !29
  %t154 = load ptr, ptr %l10, !tbaa !29
  %t156 = getelementptr %"compiler/ast:TopIf", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb34, label %bb35
bb33:
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5be1599e6a61f501_71a8850ae192da35)
  unreachable
bb35:
  br label %bb36
bb36:
  %t161 = load ptr, ptr %l10, !tbaa !29
  %t163 = getelementptr %"compiler/ast:TopIf", ptr %t161, i32 0, i32 3
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t167 = getelementptr %"compiler/ast:TopBranch", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t172 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t172, { i64, ptr } %t168, { i64, ptr } %t169, { i64, ptr } %t170, ptr %t171)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fe551cd114f4cb63_729eb01933a49f67)
  unreachable
bb44:
  br label %bb45
bb45:
  %t177 = load i64, ptr %l6, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l6, !tbaa !24
  br label %bb1
bb46:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i64
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l9
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb7:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb8
bb8:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t25, ptr %l17
  br label %bb11
bb11:
  %t26 = load i1, ptr %l17, !tbaa !21
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t29 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t29, ptr %l19
  br label %bb16
bb16:
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t35, ptr %l23
  br label %bb19
bb18:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb20
bb19:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb20
bb20:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t41 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t41, ptr %l26
  br label %bb24
bb24:
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  br i1 %t43, label %bb25, label %bb26
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t46)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb3
bb31:
  %t50 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t50, ptr %l32
  br label %bb32
bb32:
  %t51 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l34, !tbaa !24
  %t64 = mul i64 %t63, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %t62, i64 %t64, i1 false)
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t65, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l11
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t21, ptr %l16
  br label %bb8
bb8:
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t24 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t24, ptr %l18
  br label %bb12
bb12:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp sgt i64 %t25, 0
  br i1 %t26, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l21, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l23
  br label %bb17
bb17:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t32, { i64, ptr } %t33)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb3
bb20:
  %t35 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t35, ptr %l25
  br label %bb21
bb21:
  %t36 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) })
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l29
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb23, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l28
  br label %bb22
bb22:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb25
bb25:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb26, label %bb27
bb26:
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l33, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = icmp sge i64 0, 0
  br i1 %t56, label %bb28, label %bb29
bb27:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  br label %bb34
bb28:
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb30:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb32:
  %t68 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = extractvalue { i64, ptr } %t74, 0
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t76, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l32, !tbaa !27
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb34:
  %t82 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l44, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l45, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l44, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t95, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t21, i8 10)
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t30 = extractvalue { i64, ptr } %t25, 1
  %t31 = extractvalue { i64, ptr } %t25, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t23, { i64, ptr } %t47)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb2
bb14:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i1
  %lp16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %lp27 = alloca ptr
  %lp28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca ptr
  %lp31 = alloca ptr
  %lp32 = alloca ptr
  %l33 = alloca i64
  %l39 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l60 = alloca %"std/prelude/text:StringBuilder"
  %l62 = alloca i1
  %l64 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i64
  %l82 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l93 = alloca { i64, ptr }
  %l96 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca i1
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l129 = alloca %"compiler/doc:Entry"
  %l134 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca { i64, ptr }
  %l145 = alloca i1
  %l146 = alloca i1
  %l154 = alloca i32
  %l155 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l167 = alloca i64
  %l170 = alloca i64
  %l190 = alloca i1
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i1
  %l203 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l219 = alloca %"compiler/doc:Entry"
  %l221 = alloca i1
  %l223 = alloca { i64, ptr }
  %l226 = alloca i1
  %l228 = alloca i1
  %l234 = alloca %"compiler/doc:Entry"
  %l238 = alloca ptr
  %l242 = alloca i32
  %l245 = alloca i32
  %l246 = alloca i64
  %l252 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l279 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l289 = alloca i1
  %l291 = alloca i1
  %l297 = alloca %"compiler/doc:Entry"
  %l302 = alloca i64
  %l307 = alloca i1
  %l310 = alloca i64
  %l313 = alloca i64
  %l317 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/doc:Entry" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l39
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l39, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_29ad09cfbf0a8af1_8e1d5998f6fbfea5)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/load:Loader", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l8, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t42, ptr %t43, ptr %t44, i64 %t45, { i64, ptr } %t46)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l58
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  store { i64, ptr } %t53, ptr %l57
  br label %bb5
bb5:
  %t57 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t57, ptr %l51, !tbaa !27
  br label %bb7
bb6:
  %t58 = load i32, ptr %l58, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s0)
  %t68 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, i32 %t66, 0
  store { i32, %"compiler/doc:Entry" } %t68, ptr %rv
  br label %ret
bb7:
  %t69 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t69, ptr %l9, !tbaa !27
  %t70 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t70, ptr %l60
  br label %bb8
bb8:
  %t71 = load %"std/prelude/text:StringBuilder", ptr %l60
  store %"std/prelude/text:StringBuilder" %t71, ptr %l10
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t72 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s1, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t74, ptr %l62
  br label %bb10
bb10:
  %t75 = load i1, ptr %l62, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb12:
  br label %bb13
bb13:
  %t78 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t80 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s1, { i64, ptr } %t78, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l67
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb15, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l66
  br label %bb14
bb14:
  %t85 = load i64, ptr %l66, !tbaa !24
  store i64 %t85, ptr %l64, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l64, !tbaa !24
  br label %bb17
bb17:
  %t90 = load i64, ptr %l64, !tbaa !24
  store i64 %t90, ptr %l11, !tbaa !24
  store ptr %l10, ptr %l70, !tbaa !29
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l72, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l73, !tbaa !24
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb18, label %bb19
bb18:
  %t98 = load i64, ptr %l72, !tbaa !24
  %t99 = icmp sle i64 0, %t98
  br i1 %t99, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e86af49691d78062_488ad4f960296c76)
  unreachable
bb20:
  %t101 = load i64, ptr %l72, !tbaa !24
  %t102 = load i64, ptr %l73, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e86af49691d78062_488ad4f960296c76)
  unreachable
bb22:
  %t105 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l72, !tbaa !24
  %t108 = getelementptr i8, ptr %t106, i64 0
  %t109 = sub i64 %t107, 0
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  %t112 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t112, { i64, ptr } %t111)
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e86af49691d78062_488ad4f960296c76)
  unreachable
bb24:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t120 = icmp slt i64 %t114, %t117
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l84, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l86, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  store i64 %t129, ptr %l87, !tbaa !24
  %t130 = load i64, ptr %l84, !tbaa !24
  %t131 = icmp sge i64 %t130, 0
  br i1 %t131, label %bb27, label %bb28
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l93, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t133, ptr %l82, !tbaa !27
  br label %bb33
bb27:
  %t135 = load i64, ptr %l84, !tbaa !24
  %t136 = load i64, ptr %l86, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a3b6398f9e3f96e1_5bfdf63cbe459655)
  unreachable
bb29:
  %t139 = load i64, ptr %l86, !tbaa !24
  %t140 = load i64, ptr %l87, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_a3b6398f9e3f96e1_5bfdf63cbe459655)
  unreachable
bb31:
  %t143 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l84, !tbaa !24
  %t146 = load i64, ptr %l86, !tbaa !24
  %t147 = getelementptr i8, ptr %t144, i64 %t145
  %t148 = sub i64 %t146, %t145
  %t149 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  store { i64, ptr } %t150, ptr %l82, !tbaa !27
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_a3b6398f9e3f96e1_5bfdf63cbe459655)
  unreachable
bb33:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l96, !tbaa !24
  %t158 = load i64, ptr %l96, !tbaa !24
  %t159 = icmp eq i64 %t154, %t158
  br i1 %t159, label %bb34, label %bb35
bb34:
  %t161 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l96, !tbaa !24
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  br label %bb36
bb35:
  %t167 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t167, ptr %l9, !tbaa !27
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb37:
  br label %bb9
bb38:
  %t168 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t168, ptr %l98, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l99, !tbaa !24
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = mul i64 %t171, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l100, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = load i64, ptr %l99, !tbaa !24
  %t181 = mul i64 %t180, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t177, ptr %t179, i64 %t181, i1 false)
  %t182 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t182, ptr %l12, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t185 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %s0, { i64, ptr } %t183)
  store { i64, ptr } %t185, ptr %l102
  br label %bb39
bb39:
  %t186 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t187 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store { i64, ptr } %t187, ptr %l103
  br label %bb40
bb40:
  %t188 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t188, ptr %l13, !tbaa !27
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l3, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t195 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v3, ptr %t189, i64 %t190, { i64, ptr } %t191)
  store i64 %t195, ptr %l107
  br label %bb41
bb41:
  %t196 = load i64, ptr %l107, !tbaa !24
  store i64 %t196, ptr %l14, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t197, ptr %l108, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %t199, i64 0
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !37
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t201, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t203, ptr %l110
  br label %bb42
bb42:
  %t204 = load i1, ptr %l110, !tbaa !21
  br i1 %t204, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb46
bb44:
  %t205 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t205, ptr %l112, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %t207, i64 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !37
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t209, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t211, ptr %l114
  br label %bb45
bb45:
  %t212 = load i1, ptr %l114, !tbaa !21
  store i1 %t212, ptr %l111, !tbaa !21
  br label %bb46
bb46:
  %t213 = load i1, ptr %l111, !tbaa !21
  store i1 %t213, ptr %l15, !tbaa !21
  %t215 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t215, ptr %l116
  br label %bb47
bb47:
  %t216 = load i1, ptr %l15, !tbaa !21
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t218 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t220 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s0, ptr %s0, { i64, ptr } %t218)
  store { i64, ptr } %t220, ptr %l120
  br label %bb50
bb49:
  %t221 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t221, ptr %l121, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %t223, i64 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !37
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = extractvalue { i64, ptr } %t225, 0
  %t229 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t227, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l118, !tbaa !27
  br label %bb51
bb50:
  %t233 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t233, ptr %l118, !tbaa !27
  br label %bb51
bb51:
  %t234 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = getelementptr i8, ptr %t241, i64 %t236
  call void @olang_textcopy(ptr %t242, ptr %t238, i64 %t239)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 1
  %t255 = extractvalue { i64, ptr } %t252, 0
  %t256 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t254, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  %t268 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t251, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } %t265)
  store %"compiler/doc:Entry" %t268, ptr %l129
  br label %bb52
bb52:
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 104, i64 8)
  store ptr %t269, ptr %lp16
  %t270 = load %"compiler/doc:Entry", ptr %l129
  %t271 = load ptr, ptr %lp16
  store %"compiler/doc:Entry" %t270, ptr %t271
  %t272 = load i64, ptr %l14, !tbaa !24
  %t274 = icmp sge i64 %t272, 0
  br i1 %t274, label %bb53, label %bb54
bb53:
  %t276 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t277 = load i64, ptr %l14, !tbaa !24
  %t280 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v4, { i64, ptr } %t276, i64 %t277, i1 true)
  store { i64, ptr } %t280, ptr %l134
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t281 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  %t283 = extractvalue { i64, ptr } %t281, 1
  %t284 = mul i64 %t282, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t284)
  call void @llvm.memcpy.p0.p0.i64(ptr %t285, ptr %t283, i64 %t284, i1 false)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  %t289 = load ptr, ptr %lp16
  %t290 = getelementptr %"compiler/doc:Entry", ptr %t289, i32 0, i32 1
  store { i64, ptr } %t287, ptr %t290, !tbaa !27
  br label %bb56
bb56:
  %t291 = load ptr, ptr %l6, !tbaa !29
  %t293 = getelementptr %"compiler/load:Module", ptr %t291, i32 0, i32 4
  %t294 = load i64, ptr %t293, !tbaa !24
  %t296 = load ptr, ptr %lp16
  %t297 = getelementptr %"compiler/doc:Entry", ptr %t296, i32 0, i32 3
  store i64 %t294, ptr %t297, !tbaa !24
  %t298 = load i64, ptr %l14, !tbaa !24
  %t300 = load ptr, ptr %lp16
  %t301 = getelementptr %"compiler/doc:Entry", ptr %t300, i32 0, i32 4
  store i64 %t298, ptr %t301, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t302, ptr %l139, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr { i64, ptr }, ptr %t304, i64 0
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !37
  %t308 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t306, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t308, ptr %l141
  br label %bb57
bb57:
  %t309 = load i1, ptr %l141, !tbaa !21
  br i1 %t309, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb61
bb59:
  %t310 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t310, ptr %l143, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %t312, i64 0
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !37
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t314, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t316, ptr %l145
  br label %bb60
bb60:
  %t317 = load i1, ptr %l145, !tbaa !21
  store i1 %t317, ptr %l142, !tbaa !21
  br label %bb61
bb61:
  %t318 = load i1, ptr %l142, !tbaa !21
  br i1 %t318, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb64
bb63:
  %t319 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t323 = icmp eq i64 %t321, 1
  store i1 %t323, ptr %l146, !tbaa !21
  br label %bb64
bb64:
  %t325 = load i1, ptr %l146, !tbaa !21
  br i1 %t325, label %bb65, label %bb66
bb65:
  %t326 = load ptr, ptr %lp16
  %t327 = load %"compiler/doc:Entry", ptr %t326
  call void @__olang_scope_close(ptr %s0)
  %t329 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, %"compiler/doc:Entry" %t327, 1
  store { i32, %"compiler/doc:Entry" } %t329, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l3, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t336 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v3, ptr %t330, i64 %t331, { i64, ptr } %t332)
  store i32 %t336, ptr %l154
  br label %bb68
bb68:
  %t337 = load i32, ptr %l154, !tbaa !23
  store i32 %t337, ptr %l17, !tbaa !23
  %t338 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t338, ptr %l155
  br label %bb69
bb69:
  %t339 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l155
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t339, ptr %l18
  %t340 = load i32, ptr %l17, !tbaa !23
  %t342 = icmp sge i32 %t340, 0
  br i1 %t342, label %bb70, label %bb71
bb70:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i32, ptr %l17, !tbaa !23
  %t346 = load i1, ptr %l5, !tbaa !21
  %t350 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %s0, ptr %t344, i32 %t345, i1 %t346)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t350, ptr %l161
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t351 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %l18
  br label %bb73
bb73:
  store i1 false, ptr %l19, !tbaa !21
  store i64 1, ptr %l20, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t356 = load i64, ptr %l21, !tbaa !24
  %t357 = load i64, ptr %l20, !tbaa !24
  %t360 = icmp sgt i64 %t356, %t357
  br i1 %t360, label %bb74, label %bb75
bb74:
  %t362 = load i64, ptr %l22, !tbaa !24
  %t364 = icmp sgt i64 %t362, 0
  br i1 %t364, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb79
bb76:
  %t366 = load i64, ptr %l21, !tbaa !24
  %t367 = load i64, ptr %l20, !tbaa !24
  %t370 = sub i64 %t366, %t367
  %t371 = load i64, ptr %l22, !tbaa !24
  %t374 = add i64 %t370, %t371
  %t376 = sub i64 %t374, 1
  %t377 = load i64, ptr %l22, !tbaa !24
  %t380 = sdiv i64 %t376, %t377
  store i64 %t380, ptr %l170, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb78
bb78:
  %t382 = load i64, ptr %l170, !tbaa !24
  store i64 %t382, ptr %l167, !tbaa !24
  br label %bb79
bb79:
  %t383 = load i64, ptr %l167, !tbaa !24
  store i64 %t383, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t384 = load i64, ptr %l24, !tbaa !24
  %t385 = load i64, ptr %l23, !tbaa !24
  %t388 = icmp slt i64 %t384, %t385
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s9)
  br label %bb163
bb82:
  br label %bb83
bb83:
  %t392 = load i64, ptr %l20, !tbaa !24
  %t393 = load i64, ptr %l24, !tbaa !24
  %t394 = load i64, ptr %l22, !tbaa !24
  %t397 = mul i64 %t393, %t394
  %t400 = add i64 %t392, %t397
  store i64 %t400, ptr %l25, !tbaa !24
  %t402 = load i1, ptr %l19, !tbaa !21
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb84, label %bb85
bb84:
  %t406 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t406, ptr %l191, !tbaa !27
  %t407 = load i64, ptr %l25, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %t410, i64 %t407
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !37
  %t414 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t412)
  store { i64, ptr } %t414, ptr %l194
  br label %bb86
bb85:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb88
bb86:
  %t415 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t416 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t415, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t416, ptr %l195
  br label %bb87
bb87:
  %t417 = load i1, ptr %l195, !tbaa !21
  store i1 %t417, ptr %l190, !tbaa !21
  br label %bb88
bb88:
  %t418 = load i1, ptr %l190, !tbaa !21
  br i1 %t418, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l19, !tbaa !21
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t422 = load i64, ptr %l3, !tbaa !24
  %t423 = load ptr, ptr %lp16
  %t424 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t425 = load i1, ptr %l5, !tbaa !21
  call void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %s0, ptr %t419, ptr %t420, ptr %t421, i64 %t422, ptr %t423, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, i1 %t425)
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t433 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t433, ptr %l203, !tbaa !27
  %t434 = load i64, ptr %l25, !tbaa !24
  %t436 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %t437, i64 %t434
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !37
  %t441 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t439)
  store { i64, ptr } %t441, ptr %l206
  br label %bb93
bb93:
  %t442 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t442, ptr %l26, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t445 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t443, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t445, ptr %l208
  br label %bb94
bb94:
  %t446 = load i1, ptr %l208, !tbaa !21
  br i1 %t446, label %bb95, label %bb96
bb95:
  %t447 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t449 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t447, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t449, ptr %l211
  br label %bb97
bb96:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb98
bb97:
  %t450 = load i1, ptr %l211, !tbaa !21
  %t451 = xor i1 %t450, true
  store i1 %t451, ptr %l209, !tbaa !21
  br label %bb98
bb98:
  %t453 = load i1, ptr %l209, !tbaa !21
  br i1 %t453, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb100:
  br label %bb101
bb101:
  %t454 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t456 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t454, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t456, ptr %l214
  br label %bb102
bb102:
  %t457 = load i1, ptr %l214, !tbaa !21
  br i1 %t457, label %bb103, label %bb104
bb103:
  %t458 = load ptr, ptr %lp16
  %t459 = getelementptr %"compiler/doc:Entry", ptr %t458, i32 0, i32 5
  store ptr %t459, ptr %l215, !tbaa !29
  %t460 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t460, 1
  %t463 = extractvalue { i64, ptr } %t460, 0
  %t464 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t462, i64 %t463)
  %t465 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  %t468 = extractvalue { i64, ptr } %t466, 0
  %t469 = extractvalue { i64, ptr } %t466, 1
  %t470 = mul i64 %t468, 1
  %t471 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t470)
  call void @llvm.memcpy.p0.p0.i64(ptr %t471, ptr %t469, i64 %t470, i1 false)
  %t472 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  %t475 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t473, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store %"compiler/doc:Entry" %t475, ptr %l219
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t476 = load ptr, ptr %l215, !tbaa !29
  %t477 = load %"compiler/doc:Entry", ptr %l219
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t476, %"compiler/doc:Entry" %t477)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb107:
  %t478 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t480 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t478, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t480, ptr %l221
  br label %bb108
bb108:
  %t481 = load i1, ptr %l221, !tbaa !21
  br i1 %t481, label %bb109, label %bb110
bb109:
  %t482 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t484 = call { i64, ptr } @compiler_2fdoc_2emethodName(ptr %s0, ptr %v4, { i64, ptr } %t482)
  store { i64, ptr } %t484, ptr %l223
  br label %bb111
bb110:
  br label %bb138
bb111:
  %t485 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t485, ptr %lp27
  %t486 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t487 = load ptr, ptr %lp27
  store { i64, ptr } %t486, ptr %t487, !tbaa !27
  %t488 = load i1, ptr %l5, !tbaa !21
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb112, label %bb113
bb112:
  %t492 = load ptr, ptr %lp27
  %t493 = load { i64, ptr }, ptr %t492, !tbaa !27
  %t495 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t493)
  store i1 %t495, ptr %l228
  br label %bb114
bb113:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb115
bb114:
  %t496 = load i1, ptr %l228, !tbaa !21
  %t497 = xor i1 %t496, true
  store i1 %t497, ptr %l226, !tbaa !21
  br label %bb115
bb115:
  %t499 = load i1, ptr %l226, !tbaa !21
  br i1 %t499, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb117:
  br label %bb118
bb118:
  %t500 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t500, 1
  %t503 = extractvalue { i64, ptr } %t500, 0
  %t504 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t503)
  call void @olang_textcopy(ptr %t504, ptr %t502, i64 %t503)
  %t505 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t504, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  %t514 = load ptr, ptr %lp27
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !27
  %t518 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t513, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } %t515)
  store %"compiler/doc:Entry" %t518, ptr %l234
  br label %bb119
bb119:
  %t519 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 104, i64 8)
  store ptr %t519, ptr %lp28
  %t520 = load %"compiler/doc:Entry", ptr %l234
  %t521 = load ptr, ptr %lp28
  store %"compiler/doc:Entry" %t520, ptr %t521
  %t522 = load i32, ptr %l17, !tbaa !23
  %t524 = icmp sge i32 %t522, 0
  br i1 %t524, label %bb120, label %bb121
bb120:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/check:Checker", ptr %t526, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !29
  store ptr %t529, ptr %l238, !tbaa !29
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/check:Checker", ptr %t530, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t534 = load i32, ptr %l17, !tbaa !23
  %t537 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t533, i32 %t534)
  store i32 %t537, ptr %l242
  br label %bb122
bb121:
  br label %bb136
bb122:
  %t538 = load ptr, ptr %l8, !tbaa !29
  %t539 = load ptr, ptr %lp27
  %t540 = load { i64, ptr }, ptr %t539, !tbaa !27
  %t543 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v4, ptr %t538, { i64, ptr } %t540)
  store i32 %t543, ptr %l245
  br label %bb123
bb123:
  %t544 = load ptr, ptr %l238, !tbaa !29
  %t545 = load i32, ptr %l242, !tbaa !23
  %t546 = load i32, ptr %l245, !tbaa !23
  %t547 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t544, i32 %t545, i32 %t546)
  store i64 %t547, ptr %l246
  br label %bb124
bb124:
  %t548 = load i64, ptr %l246, !tbaa !24
  store i64 %t548, ptr %l29, !tbaa !24
  %t549 = load i64, ptr %l29, !tbaa !24
  %t551 = icmp sge i64 %t549, 0
  br i1 %t551, label %bb125, label %bb126
bb125:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/check:Checker", ptr %t553, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !29
  %t558 = getelementptr %"compiler/generic:Program", ptr %t556, i32 0, i32 0
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t561 = getelementptr %"compiler/load:Loader", ptr %t559, i32 0, i32 5
  store ptr %t561, ptr %l252, !tbaa !29
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/check:Checker", ptr %t562, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !29
  %t566 = load i64, ptr %l29, !tbaa !24
  %t569 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t565, i64 %t566)
  store i64 %t569, ptr %l256
  br label %bb127
bb126:
  br label %bb135
bb127:
  %t570 = load ptr, ptr %l252, !tbaa !29
  %t571 = load i64, ptr %l256, !tbaa !24
  %t572 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t570, i64 %t571)
  store ptr %t572, ptr %l257
  br label %bb128
bb128:
  %t573 = load ptr, ptr %l257, !tbaa !29
  store ptr %t573, ptr %l30, !tbaa !29
  %t574 = load ptr, ptr %l30, !tbaa !29
  %t576 = getelementptr %"compiler/load:Module", ptr %t574, i32 0, i32 6
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t579 = icmp eq ptr %t577, null
  br i1 %t579, label %bb129, label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_8419b84cbf1afefc_dc1ce5aaa0c9e050)
  unreachable
bb130:
  br label %bb131
bb131:
  %t581 = load ptr, ptr %l30, !tbaa !29
  %t583 = getelementptr %"compiler/load:Module", ptr %t581, i32 0, i32 6
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t587 = getelementptr %"compiler/source:Source", ptr %t584, i32 0, i32 1
  %t588 = load { i64, ptr }, ptr %t587, !tbaa !27
  store { i64, ptr } %t588, ptr %l264, !tbaa !27
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t589, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t593 = load i64, ptr %l29, !tbaa !24
  %t596 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t592, i64 %t593)
  store ptr %t596, ptr %l268
  br label %bb132
bb132:
  %t597 = load ptr, ptr %l268, !tbaa !29
  %t599 = getelementptr %"compiler/ast:Func", ptr %t597, i32 0, i32 0
  %t600 = getelementptr %"compiler/source:Span", ptr %t599, i32 0, i32 0
  %t601 = load i32, ptr %t600, !tbaa !23
  %t603 = sext i32 %t601 to i64
  %t604 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t606 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v4, { i64, ptr } %t604, i64 %t603)
  store { i64, ptr } %t606, ptr %l272
  br label %bb133
bb133:
  %t607 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t607, 0
  %t609 = extractvalue { i64, ptr } %t607, 1
  %t610 = mul i64 %t608, 1
  %t611 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t610)
  call void @llvm.memcpy.p0.p0.i64(ptr %t611, ptr %t609, i64 %t610, i1 false)
  %t612 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  %t615 = load ptr, ptr %lp28
  %t616 = getelementptr %"compiler/doc:Entry", ptr %t615, i32 0, i32 1
  store { i64, ptr } %t613, ptr %t616, !tbaa !27
  %t617 = load ptr, ptr %l30, !tbaa !29
  %t619 = getelementptr %"compiler/load:Module", ptr %t617, i32 0, i32 4
  %t620 = load i64, ptr %t619, !tbaa !24
  %t622 = load ptr, ptr %lp28
  %t623 = getelementptr %"compiler/doc:Entry", ptr %t622, i32 0, i32 3
  store i64 %t620, ptr %t623, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/check:Checker", ptr %t624, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !29
  %t628 = load i64, ptr %l29, !tbaa !24
  %t631 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t627, i64 %t628)
  store ptr %t631, ptr %l279
  br label %bb134
bb134:
  %t632 = load ptr, ptr %l279, !tbaa !29
  %t634 = getelementptr %"compiler/ast:Func", ptr %t632, i32 0, i32 0
  %t635 = getelementptr %"compiler/source:Span", ptr %t634, i32 0, i32 0
  %t636 = load i32, ptr %t635, !tbaa !23
  %t638 = sext i32 %t636 to i64
  %t640 = load ptr, ptr %lp28
  %t641 = getelementptr %"compiler/doc:Entry", ptr %t640, i32 0, i32 4
  store i64 %t638, ptr %t641, !tbaa !24
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t642 = load ptr, ptr %lp16
  %t643 = getelementptr %"compiler/doc:Entry", ptr %t642, i32 0, i32 5
  %t644 = load ptr, ptr %lp28
  %t645 = load %"compiler/doc:Entry", ptr %t644
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t643, %"compiler/doc:Entry" %t645)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb138:
  %t648 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t650 = call { i64, ptr } @compiler_2fdoc_2ememberName(ptr %s0, ptr %v4, { i64, ptr } %t648)
  store { i64, ptr } %t650, ptr %l286
  br label %bb139
bb139:
  %t651 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t651, ptr %lp31
  %t652 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t653 = load ptr, ptr %lp31
  store { i64, ptr } %t652, ptr %t653, !tbaa !27
  %t654 = load i1, ptr %l5, !tbaa !21
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb140, label %bb141
bb140:
  %t658 = load ptr, ptr %lp31
  %t659 = load { i64, ptr }, ptr %t658, !tbaa !27
  %t661 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t659)
  store i1 %t661, ptr %l291
  br label %bb142
bb141:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb143
bb142:
  %t662 = load i1, ptr %l291, !tbaa !21
  %t663 = xor i1 %t662, true
  store i1 %t663, ptr %l289, !tbaa !21
  br label %bb143
bb143:
  %t665 = load i1, ptr %l289, !tbaa !21
  br i1 %t665, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb145:
  br label %bb146
bb146:
  %t666 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t666, 1
  %t669 = extractvalue { i64, ptr } %t666, 0
  %t670 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t668, i64 %t669)
  %t671 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = extractvalue { i64, ptr } %t672, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  %t680 = load ptr, ptr %lp31
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !27
  %t684 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t679, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } %t681)
  store %"compiler/doc:Entry" %t684, ptr %l297
  br label %bb147
bb147:
  %t685 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 104, i64 8)
  store ptr %t685, ptr %lp32
  %t686 = load %"compiler/doc:Entry", ptr %l297
  %t687 = load ptr, ptr %lp32
  store %"compiler/doc:Entry" %t686, ptr %t687
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load i64, ptr %l3, !tbaa !24
  %t690 = load i32, ptr %l17, !tbaa !23
  %t691 = load ptr, ptr %lp31
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  %t697 = call i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v4, ptr %t688, i64 %t689, i32 %t690, { i64, ptr } %t692)
  store i64 %t697, ptr %l302
  br label %bb148
bb148:
  %t698 = load i64, ptr %l302, !tbaa !24
  store i64 %t698, ptr %l33, !tbaa !24
  %t699 = load i64, ptr %l33, !tbaa !24
  %t701 = icmp sge i64 %t699, 0
  br i1 %t701, label %bb149, label %bb150
bb149:
  %t703 = load i64, ptr %l14, !tbaa !24
  %t705 = icmp slt i64 %t703, 0
  br i1 %t705, label %bb151, label %bb152
bb150:
  br label %bb160
bb151:
  store i1 true, ptr %l307, !tbaa !21
  br label %bb155
bb152:
  %t707 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t708 = load i64, ptr %l33, !tbaa !24
  %t711 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t707, i64 %t708)
  store i64 %t711, ptr %l310
  br label %bb153
bb153:
  %t712 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t713 = load i64, ptr %l14, !tbaa !24
  %t716 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t712, i64 %t713)
  store i64 %t716, ptr %l313
  br label %bb154
bb154:
  %t717 = load i64, ptr %l310, !tbaa !24
  %t718 = load i64, ptr %l313, !tbaa !24
  %t719 = icmp ne i64 %t717, %t718
  store i1 %t719, ptr %l307, !tbaa !21
  br label %bb155
bb155:
  %t721 = load i1, ptr %l307, !tbaa !21
  br i1 %t721, label %bb156, label %bb157
bb156:
  %t722 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t723 = load i64, ptr %l33, !tbaa !24
  %t726 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v4, { i64, ptr } %t722, i64 %t723, i1 true)
  store { i64, ptr } %t726, ptr %l317
  br label %bb158
bb157:
  br label %bb159
bb158:
  %t727 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t727, 0
  %t729 = extractvalue { i64, ptr } %t727, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  %t735 = load ptr, ptr %lp32
  %t736 = getelementptr %"compiler/doc:Entry", ptr %t735, i32 0, i32 1
  store { i64, ptr } %t733, ptr %t736, !tbaa !27
  br label %bb159
bb159:
  %t737 = load ptr, ptr %l6, !tbaa !29
  %t739 = getelementptr %"compiler/load:Module", ptr %t737, i32 0, i32 4
  %t740 = load i64, ptr %t739, !tbaa !24
  %t742 = load ptr, ptr %lp32
  %t743 = getelementptr %"compiler/doc:Entry", ptr %t742, i32 0, i32 3
  store i64 %t740, ptr %t743, !tbaa !24
  %t744 = load i64, ptr %l33, !tbaa !24
  %t746 = load ptr, ptr %lp32
  %t747 = getelementptr %"compiler/doc:Entry", ptr %t746, i32 0, i32 4
  store i64 %t744, ptr %t747, !tbaa !24
  br label %bb160
bb160:
  %t748 = load ptr, ptr %lp16
  %t749 = getelementptr %"compiler/doc:Entry", ptr %t748, i32 0, i32 5
  %t750 = load ptr, ptr %lp32
  %t751 = load %"compiler/doc:Entry", ptr %t750
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t749, %"compiler/doc:Entry" %t751)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb162:
  %t754 = load i64, ptr %l24, !tbaa !24
  %t756 = add i64 %t754, 1
  store i64 %t756, ptr %l24, !tbaa !24
  br label %bb80
bb163:
  %t758 = load ptr, ptr %lp16
  %t759 = load %"compiler/doc:Entry", ptr %t758
  call void @__olang_scope_close(ptr %s0)
  %t761 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, %"compiler/doc:Entry" %t759, 1
  store { i32, %"compiler/doc:Entry" } %t761, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/doc:Entry" }, ptr %rv
  ret { i32, %"compiler/doc:Entry" } %rr
}

define dso_local i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 10
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = add i64 %t24, 1
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l43 = alloca i32
  %l49 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i32
  %l100 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i1
  %l152 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i1
  %l183 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l187 = alloca i1
  %l198 = alloca i64
  %l201 = alloca i64
  %l220 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t17, { i64, ptr } %t18)
  store i32 %t21, ptr %l43
  br label %bb4
bb4:
  %t22 = load i32, ptr %l43, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l49
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 6
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l6, !tbaa !29
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  br i1 %t43, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_301af787a8ab5449_ce9576e6695793ad)
  unreachable
bb7:
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t48 = getelementptr %"compiler/source:Source", ptr %t45, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l61
  br label %bb9
bb9:
  %t61 = load i32, ptr %l61, !range !{i32 0, i32 6}
  %t63 = trunc i64 2 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l64, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l65, !tbaa !24
  %t68 = load ptr, ptr %l4, !tbaa !29
  store ptr %t68, ptr %l66, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l71
  br label %bb12
bb11:
  br label %bb32
bb12:
  %t79 = load ptr, ptr %l66, !tbaa !29
  %t80 = load i32, ptr %l71, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l72
  br label %bb13
bb13:
  %t82 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t83, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load ptr, ptr %l64, !tbaa !29
  %t96 = load i64, ptr %l65, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %s2, ptr %t95, i64 %t96, { i64, ptr } %t94)
  store i64 %t98, ptr %l75
  br label %bb14
bb14:
  %t99 = load i64, ptr %l75, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t105, ptr %l80, !tbaa !27
  %t106 = load i64, ptr %l8, !tbaa !24
  store i64 %t106, ptr %l81, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t107, 0
  store i64 %t110, ptr %l84, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l85, !tbaa !24
  %t113 = load i64, ptr %l81, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = load i64, ptr %l81, !tbaa !24
  %t117 = load i64, ptr %l84, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb20:
  %t120 = load i64, ptr %l84, !tbaa !24
  %t121 = load i64, ptr %l85, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb22:
  %t124 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l81, !tbaa !24
  %t127 = load i64, ptr %l84, !tbaa !24
  %t128 = getelementptr i8, ptr %t125, i64 %t126
  %t129 = sub i64 %t127, %t126
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  %t133 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t131, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) })
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l91
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb25, label %ok.137, !prof !99
ok.137:
  store i64 %t134, ptr %l90
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb24:
  %t138 = load i64, ptr %l90, !tbaa !24
  store i64 %t138, ptr %l79, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb27
bb27:
  %t139 = load i64, ptr %l79, !tbaa !24
  store i64 %t139, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = icmp slt i64 %t140, 0
  br i1 %t142, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = load i64, ptr %l8, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t151 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %t145, i64 %t150, { i64, ptr } %t151)
  store i64 %t155, ptr %l100
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t156 = load i64, ptr %l100, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i32, ptr %l2, !tbaa !23
  %t164 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t160, i32 %t161)
  store ptr %t164, ptr %l104
  br label %bb33
bb33:
  %t165 = load ptr, ptr %l104, !tbaa !29
  store ptr %t165, ptr %l10, !tbaa !29
  %t166 = load ptr, ptr %l10, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb36
bb35:
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t172 = getelementptr %"compiler/ast:TypeDecl", ptr %t170, i32 0, i32 3
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  store i1 %t175, ptr %l107, !tbaa !21
  br label %bb36
bb36:
  %t177 = load i1, ptr %l107, !tbaa !21
  br i1 %t177, label %bb37, label %bb38
bb37:
  store i64 -1, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t181 = getelementptr %"compiler/ast:TypeDecl", ptr %t179, i32 0, i32 3
  %t182 = load ptr, ptr %t181, !tbaa !29
  store ptr %t182, ptr %l11, !tbaa !29
  %t184 = load ptr, ptr %l11, !tbaa !29
  store ptr %t184, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t185 = load ptr, ptr %l114, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb40, label %bb41
bb40:
  %t188 = load ptr, ptr %l114, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 5}
  %t191 = icmp eq i64 %t189, 1
  store i1 %t191, ptr %l115, !tbaa !21
  br label %bb41
bb41:
  %t192 = load i1, ptr %l115, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr { i64, [6 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { { i64, ptr }, ptr }, ptr %t195, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  br label %bb44
bb43:
  br label %bb54
bb44:
  %t199 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t199, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb46, label %bb47
bb46:
  br label %bb53
bb47:
  br label %bb48
bb48:
  %t213 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t213, ptr %l127, !tbaa !27
  %t214 = load i64, ptr %l14, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  store ptr %t219, ptr %l16, !tbaa !29
  %t221 = load ptr, ptr %l16, !tbaa !29
  %t223 = getelementptr %"compiler/ast:CaseDecl", ptr %t221, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  %t225 = load i32, ptr %l5, !tbaa !23
  %t228 = icmp eq i32 %t224, %t225
  br i1 %t228, label %bb49, label %bb50
bb49:
  %t230 = load ptr, ptr %l16, !tbaa !29
  %t232 = getelementptr %"compiler/ast:CaseDecl", ptr %t230, i32 0, i32 0
  %t233 = getelementptr %"compiler/source:Span", ptr %t232, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = sext i32 %t234 to i64
  store i64 %t236, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t238 = load i64, ptr %l14, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l14, !tbaa !24
  br label %bb45
bb53:
  br label %bb115
bb54:
  %t242 = load ptr, ptr %l11, !tbaa !29
  store ptr %t242, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t243 = load ptr, ptr %l139, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb55, label %bb56
bb55:
  %t246 = load ptr, ptr %l139, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 5}
  %t249 = icmp eq i64 %t247, 2
  store i1 %t249, ptr %l140, !tbaa !21
  br label %bb56
bb56:
  %t250 = load i1, ptr %l140, !tbaa !21
  br i1 %t250, label %bb57, label %bb58
bb57:
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr { i64, [6 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t253, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l17, !tbaa !27
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t257 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t257, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l20, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l19, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb61, label %bb62
bb61:
  br label %bb68
bb62:
  br label %bb63
bb63:
  %t271 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t271, ptr %l152, !tbaa !27
  %t272 = load i64, ptr %l19, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 %t272
  %t277 = load ptr, ptr %t276, !tbaa !39
  store ptr %t277, ptr %l21, !tbaa !29
  %t279 = load ptr, ptr %l21, !tbaa !29
  %t281 = getelementptr %"compiler/ast:Func", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t283 = load i32, ptr %l5, !tbaa !23
  %t286 = icmp eq i32 %t282, %t283
  br i1 %t286, label %bb64, label %bb65
bb64:
  %t288 = load ptr, ptr %l21, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Func", ptr %t288, i32 0, i32 0
  %t291 = getelementptr %"compiler/source:Span", ptr %t290, i32 0, i32 0
  %t292 = load i32, ptr %t291, !tbaa !23
  %t294 = sext i32 %t292 to i64
  store i64 %t294, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t296 = load i64, ptr %l19, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l19, !tbaa !24
  br label %bb60
bb68:
  br label %bb115
bb69:
  %t300 = load ptr, ptr %l11, !tbaa !29
  store ptr %t300, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t301 = load ptr, ptr %l164, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb70, label %bb71
bb70:
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t305 = load i64, ptr %t304, !range !{i64 0, i64 5}
  %t307 = icmp eq i64 %t305, 0
  store i1 %t307, ptr %l165, !tbaa !21
  br label %bb71
bb71:
  %t308 = load i1, ptr %l165, !tbaa !21
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t311 = getelementptr { i64, [6 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { ptr }, ptr %t311, i32 0, i32 0
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l22, !tbaa !29
  br label %bb74
bb73:
  br label %bb110
bb74:
  %t315 = load ptr, ptr %l22, !tbaa !29
  %t317 = getelementptr %"compiler/ast:StructBody", ptr %t315, i32 0, i32 2
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t322 = icmp eq i64 %t320, 0
  br i1 %t322, label %bb75, label %bb76
bb75:
  store i64 -1, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t325 = load ptr, ptr %l22, !tbaa !29
  %t327 = getelementptr %"compiler/ast:StructBody", ptr %t325, i32 0, i32 2
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  store i64 %t332, ptr %l25, !tbaa !24
  br label %bb78
bb78:
  %t334 = load i64, ptr %l24, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb79, label %bb80
bb79:
  br label %bb109
bb80:
  br label %bb81
bb81:
  %t342 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t342, ptr %l183, !tbaa !27
  %t343 = load i64, ptr %l24, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr ptr, ptr %t346, i64 %t343
  %t348 = load ptr, ptr %t347, !tbaa !39
  store ptr %t348, ptr %l26, !tbaa !29
  %t350 = load ptr, ptr %l26, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t351 = load ptr, ptr %l186, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb82, label %bb83
bb82:
  %t354 = load ptr, ptr %l186, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 22}
  %t357 = icmp eq i64 %t355, 1
  store i1 %t357, ptr %l187, !tbaa !21
  br label %bb83
bb83:
  %t358 = load i1, ptr %l187, !tbaa !21
  br i1 %t358, label %bb84, label %bb85
bb84:
  %t359 = load ptr, ptr %l26, !tbaa !29
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", ptr }, ptr %t361, i32 0, i32 1
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l27, !tbaa !29
  br label %bb86
bb85:
  br label %bb102
bb86:
  store i64 0, ptr %l28, !tbaa !24
  %t365 = load ptr, ptr %l27, !tbaa !29
  %t367 = getelementptr %"compiler/ast:VarDecl", ptr %t365, i32 0, i32 0
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  store i64 %t370, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t372 = load i64, ptr %l29, !tbaa !24
  %t373 = load i64, ptr %l28, !tbaa !24
  %t376 = icmp sgt i64 %t372, %t373
  br i1 %t376, label %bb87, label %bb88
bb87:
  %t378 = load i64, ptr %l30, !tbaa !24
  %t380 = icmp sgt i64 %t378, 0
  br i1 %t380, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb92
bb89:
  %t382 = load i64, ptr %l29, !tbaa !24
  %t383 = load i64, ptr %l28, !tbaa !24
  %t386 = sub i64 %t382, %t383
  %t387 = load i64, ptr %l30, !tbaa !24
  %t390 = add i64 %t386, %t387
  %t392 = sub i64 %t390, 1
  %t393 = load i64, ptr %l30, !tbaa !24
  %t396 = sdiv i64 %t392, %t393
  store i64 %t396, ptr %l201, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb91
bb91:
  %t398 = load i64, ptr %l201, !tbaa !24
  store i64 %t398, ptr %l198, !tbaa !24
  br label %bb92
bb92:
  %t399 = load i64, ptr %l198, !tbaa !24
  store i64 %t399, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb93
bb93:
  %t400 = load i64, ptr %l32, !tbaa !24
  %t401 = load i64, ptr %l31, !tbaa !24
  %t404 = icmp slt i64 %t400, %t401
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb94, label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb96
bb96:
  %t408 = load i64, ptr %l28, !tbaa !24
  %t409 = load i64, ptr %l32, !tbaa !24
  %t410 = load i64, ptr %l30, !tbaa !24
  %t413 = mul i64 %t409, %t410
  %t416 = add i64 %t408, %t413
  store i64 %t416, ptr %l33, !tbaa !24
  %t418 = load ptr, ptr %l27, !tbaa !29
  %t420 = getelementptr %"compiler/ast:VarDecl", ptr %t418, i32 0, i32 0
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !27
  store { i64, ptr } %t421, ptr %l220, !tbaa !27
  %t422 = load i64, ptr %l33, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr i32, ptr %t425, i64 %t422
  %t427 = load i32, ptr %t426, !tbaa !33
  %t428 = load i32, ptr %l5, !tbaa !23
  %t431 = icmp eq i32 %t427, %t428
  br i1 %t431, label %bb97, label %bb98
bb97:
  %t433 = load ptr, ptr %l27, !tbaa !29
  %t435 = getelementptr %"compiler/ast:VarDecl", ptr %t433, i32 0, i32 1
  %t436 = load { i64, ptr }, ptr %t435, !tbaa !27
  store { i64, ptr } %t436, ptr %l226, !tbaa !27
  %t437 = load i64, ptr %l33, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr %"compiler/source:Span", ptr %t440, i64 %t437
  %t442 = getelementptr %"compiler/source:Span", ptr %t441, i32 0, i32 0
  %t443 = load i32, ptr %t442, !tbaa !23
  %t445 = sext i32 %t443 to i64
  store i64 %t445, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t447 = load i64, ptr %l32, !tbaa !24
  %t449 = add i64 %t447, 1
  store i64 %t449, ptr %l32, !tbaa !24
  br label %bb93
bb101:
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e)
  unreachable
bb107:
  br label %bb108
bb108:
  %t451 = load i64, ptr %l24, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l24, !tbaa !24
  br label %bb78
bb109:
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_6a9dd6ae82982c7b_35c440a7358a5b8f)
  unreachable
bb115:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t19)
  store i1 %t21, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb13
bb5:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l18
  br label %bb8
bb8:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l20, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = icmp eq i8 %t40, 95
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l19, !tbaa !21
  store i1 %t44, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l9, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t52, ptr %l27, !tbaa !27
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l28, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l29, !tbaa !24
  %t56 = icmp sge i64 0, 0
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = load i64, ptr %l28, !tbaa !24
  %t59 = icmp sle i64 0, %t58
  br i1 %t59, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb21:
  %t61 = load i64, ptr %l28, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb23:
  %t65 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l28, !tbaa !24
  %t68 = getelementptr i8, ptr %t66, i64 0
  %t69 = sub i64 %t67, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t73, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = add i64 %t15, 2
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l26, !tbaa !24
  %t34 = icmp sge i64 3, 0
  br i1 %t34, label %bb13, label %bb14
bb7:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l16, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb9:
  %t40 = load i64, ptr %l16, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb11:
  %t44 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l16, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l10, !tbaa !27
  br label %bb19
bb12:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb13:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 3, %t53
  br i1 %t54, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb17:
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 3
  %t64 = sub i64 %t62, 3
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l10, !tbaa !27
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb19:
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t68, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t69, %t72
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t83)
  store i1 %t85, ptr %l39
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb31
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t93)
  store i1 %t95, ptr %l44
  br label %bb26
bb26:
  %t96 = load i1, ptr %l44, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp eq i8 %t104, 95
  store i1 %t106, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l45, !tbaa !21
  store i1 %t108, ptr %l35, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l35, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l3, !tbaa !24
  br label %bb35
bb35:
  br label %bb20
bb36:
  %t116 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb39:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb41:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr @G_2ecompiler_2fdoc_2eStyle, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %t4, 1
  %t23 = extractvalue { i64, ptr } %t4, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a1, 1
  %t30 = extractvalue { i64, ptr } %a1, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t6, i64 %t7)
  %t36 = getelementptr i8, ptr %t35, i64 %t7
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca %"compiler/doc:Entry"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/doc:Entry"
  %l40 = alloca %"compiler/doc:Entry"
  %l41 = alloca i32
  %l43 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store ptr %l5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t2 = load i64, ptr %l8, !tbaa !24
  store i64 %t2, ptr %l13, !tbaa !24
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp slt i64 %t6, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load i64, ptr %l20, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t31, i64 %t17)
  store ptr %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t40, i32 %t39)
  store { i64, ptr } %t42, ptr %l31
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t62 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %v3, ptr %t50, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %t48, i1 %a6)
  %t63 = extractvalue { i32, %"compiler/doc:Entry" } %t62, 1
  %t64 = extractvalue { i32, %"compiler/doc:Entry" } %t62, 0
  store i32 %t64, ptr %l41
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb10, label %ok.66, !prof !99
ok.66:
  store %"compiler/doc:Entry" %t63, ptr %l40
  br label %bb9
bb9:
  %t67 = load %"compiler/doc:Entry", ptr %l40
  store %"compiler/doc:Entry" %t67, ptr %l33
  br label %bb12
bb10:
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  store i1 %t71, ptr %l43, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb12:
  %t72 = load %"compiler/doc:Entry", ptr %l33
  store %"compiler/doc:Entry" %t72, ptr %l11
  %t73 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  store i1 true, ptr %t73, !tbaa !21
  %t76 = getelementptr %"compiler/doc:Entry", ptr %a4, i32 0, i32 5
  %t77 = load %"compiler/doc:Entry", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t76, %"compiler/doc:Entry" %t77)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb1
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a1)
  store i32 %t20, ptr %l12
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l21
  br label %bb4
bb4:
  %t43 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l28
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l28, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l33
  br label %bb9
bb9:
  %t69 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb10, label %bb11
bb10:
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l39, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l44
  br label %bb13
bb13:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t93, ptr %l45
  br label %bb14
bb14:
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fdoc_2ewordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i1
  %l11 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/doc:Entry"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 -1, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l8
  store i1 false, ptr %l9, !tbaa !21
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = insertvalue %"compiler/doc:Entry" undef, { i64, ptr } %t11, 0
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = insertvalue %"compiler/doc:Entry" %t12, { i64, ptr } %t13, 1
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = insertvalue %"compiler/doc:Entry" %t14, { i64, ptr } %t15, 2
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = insertvalue %"compiler/doc:Entry" %t16, i64 %t17, 3
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/doc:Entry" %t18, i64 %t19, 4
  %t21 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t22 = insertvalue %"compiler/doc:Entry" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 5
  %t23 = load i1, ptr %l9, !tbaa !21
  %t24 = insertvalue %"compiler/doc:Entry" %t22, i1 %t23, 6
  %t26 = insertvalue %"compiler/doc:Entry" %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 7
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t28 = insertvalue %"compiler/doc:Entry" %t26, { i64, ptr } %t27, 8
  store %"compiler/doc:Entry" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Entry", ptr %rv
  ret %"compiler/doc:Entry" %rr
}

define dso_local %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/doc:Example"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/doc:Example" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/doc:Example" %t6, { i64, ptr } %a1, 1
  store %"compiler/doc:Example" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Example", ptr %rv
  ret %"compiler/doc:Example" %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/doc:Module"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = insertvalue %"compiler/doc:Module" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = insertvalue %"compiler/doc:Module" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = insertvalue %"compiler/doc:Module" %t12, { i64, ptr } %t13, 2
  %t16 = insertvalue %"compiler/doc:Module" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 3
  store %"compiler/doc:Module" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<h1>" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</h1>\0A<ul>\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d10 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<li><a href=\22" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d12 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</code></a>" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</li>\0A" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</ul>\0A" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import\22" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_25(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
declare void @__olang_ert_req_clear()
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d44 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"<p><a href=\22index.html\22>index</a></p>\0A<h1>" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</h1>\0A" }>, align 8
@.d46 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<pre>import \22" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22</pre>\0A" }>, align 8
@.d48 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<h2>Index</h2>\0A<ul>\0A" }>, align 8
@.d49 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"<li><a href=\22#" }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d51 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</code></a></li>\0A" }>, align 8
@.d52 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"</ul>\0A<h2>Items</h2>\0A" }>, align 8
@.d53 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"<div class=\22doc\22>" }>, align 8
define internal void @olang_lambda_61(ptr %env, ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb5
bb5:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s2, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l12
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s4, { i64, ptr } %t18)
  store { i64, ptr } %t20, ptr %l17
  br label %bb10
bb8:
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t42, { i64, ptr } %t41)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb10:
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t65, { i64, ptr } %t64)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t67)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d65 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<div class=\22member\22>" }>, align 8
@.d66 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"<pre id=\22" }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22>" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</pre>\0A" }>, align 8
@.d69 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"<details class=\22example\22><summary>Example: " }>, align 8
@.d70 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</summary><pre>" }>, align 8
@.d71 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</pre></details>\0A" }>, align 8
@.d72 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"<h3 class=\22member\22>Builders</h3>\0A" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d77 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    example \22" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d79 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d80 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    builders\0A" }>, align 8
@.d81 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d82 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d83 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d84 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"    [" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c". " }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d94 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d97 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d98 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d99 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn (" }>, align 8
@.d101 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"meets " }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d109 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"<!doctype html>\0A<html lang=\22en\22><head><meta charset=\22utf-8\22>" }>, align 8
@.d110 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"<meta name=\22viewport\22 content=\22width=device-width, initial-scale=1\22>" }>, align 8
@.d111 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"<title>" }>, align 8
@.d112 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</title><style>" }>, align 8
@.d113 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"</style></head><body>\0A" }>, align 8
@.d114 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
@.d115 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d116 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<pre>" }>, align 8
@.d117 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</pre>" }>, align 8
@.d118 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<p>" }>, align 8
@.d119 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_39c265aa723c0dcb_f35d02a7366497b7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_19c80d7aab96fce_b433fa540154765a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9 = external constant [0 x i8]
@olang_loc_89c63e526fea8550_9190d8cdbdd5cacc = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_51c1b9bde331172f_b1d3b315fa602c93 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %v0, i64 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2d5d282533798e40_ae298936cea775c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
@olang_loc_b461083f788c6b86_e65d814f8bc052da = external constant [0 x i8]
@olang_loc_b4b87f1043b41663_258689a2c0d07437 = external constant [0 x i8]
@olang_loc_a37384dcd940e048_c3ba5fc94841a74c = external constant [0 x i8]
@olang_loc_df2a3aebcfae1327_f5257898d4c97893 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Entry" %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/doc:Entry" %a2)
@olang_loc_6644f0af63579e58_6cea556a954a7954 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6 = external constant [0 x i8]
@olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903 = external constant [0 x i8]
@olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8 = external constant [0 x i8]
@olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5 = external constant [0 x i8]
@olang_loc_417cf13f3f24fdcf_48c2325066185a1b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b = external constant [0 x i8]
@olang_loc_91fc21a6b7496c0a_24bc2c9db083308e = external constant [0 x i8]
@olang_loc_f657276e2350bf29_71dbd11cb4dae2ed = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_8ef8e25bc783e73c_af1dce04e2424510 = external constant [0 x i8]
@olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef = external constant [0 x i8]
@olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a = external constant [0 x i8]
@olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)
@olang_loc_d85afc985d0ab39_76fcb7f235eece65 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1f1e658c6da2070c_2842ab33ef4c4808 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_d85c9f08fc02aff9_18b1e7df62bde535 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Example" %a1)
@olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e = external constant [0 x i8]
@olang_loc_5be1599e6a61f501_71a8850ae192da35 = external constant [0 x i8]
@olang_loc_fe551cd114f4cb63_729eb01933a49f67 = external constant [0 x i8]
@olang_loc_46ab965e7000f695_6c81a9a0ef748b89 = external constant [0 x i8]
@olang_loc_29ad09cfbf0a8af1_8e1d5998f6fbfea5 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_e86af49691d78062_488ad4f960296c76 = external constant [0 x i8]
@olang_loc_a3b6398f9e3f96e1_5bfdf63cbe459655 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_8419b84cbf1afefc_dc1ce5aaa0c9e050 = external constant [0 x i8]
@olang_loc_301af787a8ab5449_ce9576e6695793ad = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0afceaceca5551a_2521421923c730de = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e = external constant [0 x i8]
@olang_loc_6a9dd6ae82982c7b_35c440a7358a5b8f = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_fdfaf893749e1d49_869eafdea154472d = external constant [0 x i8]
@olang_loc_93a5825f4266fe40_3fd51f523aa7a28c = external constant [0 x i8]
@olang_loc_249ae2d6db78c99d_2e3c698f52d646b9 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
