; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/doc:Example" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
@G_2ecompiler_2fdoc_2eStyle = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\AC\02\00\00\00\00\00\00", ptr @G_2ecompiler_2fdoc_2eStyle.k1 }>, align 8
@G_2ecompiler_2fdoc_2eStyle.k1 = internal constant <{ [684 x i8] }> <{ [684 x i8] c"\62\6F\64\79\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\73\79\73\74\65\6D\2D\75\69\2C\73\61\6E\73\2D\73\65\72\69\66\3B\6D\61\78\2D\77\69\64\74\68\3A\35\32\72\65\6D\3B\6D\61\72\67\69\6E\3A\32\72\65\6D\20\61\75\74\6F\3B\70\61\64\64\69\6E\67\3A\30\20\31\72\65\6D\3B\6C\69\6E\65\2D\68\65\69\67\68\74\3A\31\2E\35\3B\63\6F\6C\6F\72\3A\23\31\64\31\64\31\66\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\66\66\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\35\66\35\66\37\3B\70\61\64\64\69\6E\67\3A\2E\35\72\65\6D\20\2E\37\35\72\65\6D\3B\62\6F\72\64\65\72\2D\72\61\64\69\75\73\3A\34\70\78\3B\6F\76\65\72\66\6C\6F\77\2D\78\3A\61\75\74\6F\3B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\7D\63\6F\64\65\2C\70\72\65\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\75\69\2D\6D\6F\6E\6F\73\70\61\63\65\2C\4D\65\6E\6C\6F\2C\6D\6F\6E\6F\73\70\61\63\65\3B\66\6F\6E\74\2D\73\69\7A\65\3A\2E\39\65\6D\7D\2E\64\65\70\7B\74\65\78\74\2D\64\65\63\6F\72\61\74\69\6F\6E\3A\6C\69\6E\65\2D\74\68\72\6F\75\67\68\7D\2E\6E\6F\74\65\7B\66\6F\6E\74\2D\77\65\69\67\68\74\3A\62\6F\6C\64\7D\2E\64\6F\63\7B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\20\31\72\65\6D\20\31\72\65\6D\7D\2E\65\78\61\6D\70\6C\65\7B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\20\2E\35\72\65\6D\20\31\72\65\6D\7D\73\75\6D\6D\61\72\79\7B\63\75\72\73\6F\72\3A\70\6F\69\6E\74\65\72\7D\2E\6D\65\6D\62\65\72\7B\6D\61\72\67\69\6E\2D\6C\65\66\74\3A\31\2E\35\72\65\6D\7D\68\32\7B\62\6F\72\64\65\72\2D\62\6F\74\74\6F\6D\3A\31\70\78\20\73\6F\6C\69\64\20\23\64\64\64\3B\70\61\64\64\69\6E\67\2D\62\6F\74\74\6F\6D\3A\2E\32\35\72\65\6D\3B\6D\61\72\67\69\6E\2D\74\6F\70\3A\32\72\65\6D\7D\61\7B\63\6F\6C\6F\72\3A\23\30\62\35\37\64\30\7D\40\6D\65\64\69\61\28\70\72\65\66\65\72\73\2D\63\6F\6C\6F\72\2D\73\63\68\65\6D\65\3A\64\61\72\6B\29\7B\62\6F\64\79\7B\63\6F\6C\6F\72\3A\23\65\38\65\38\65\61\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\31\38\31\38\31\62\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\32\36\32\36\32\62\7D\61\7B\63\6F\6C\6F\72\3A\23\38\61\62\34\66\38\7D\68\32\7B\62\6F\72\64\65\72\2D\63\6F\6C\6F\72\3A\23\33\33\33\7D\7D" }>, align 64
define dso_local { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l100 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l121 = alloca i64
  %l123 = alloca { i64, ptr }
  %l130 = alloca %"std/prelude/text:StringBuilder"
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l154 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t3, i64 %a1)
  store i64 %t7, ptr %l16
  br label %bb2
bb2:
  %t8 = load i64, ptr %l16, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t15, i64 %t18)
  store i64 %t21, ptr %l23
  br label %bb7
bb7:
  %t22 = load i64, ptr %l23, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l24, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l27, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l28, !tbaa !24
  %t30 = load i64, ptr %l25, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb10:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb12:
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = getelementptr i8, ptr %t42, i64 %t43
  %t46 = sub i64 %t44, %t43
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  %t50 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s1, { i64, ptr } %t48)
  store { i64, ptr } %t50, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb14:
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s1, ptr %s1, { i64, ptr } %t51, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t52, ptr %l34
  br label %bb15
bb15:
  %t53 = load i1, ptr %l34, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  store i64 %t56, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb3
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb23:
  br label %bb24
bb24:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = sub i64 %t65, 1
  %t70 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t64, i64 %t67)
  store i64 %t70, ptr %l43
  br label %bb25
bb25:
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l5, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = sub i64 %t74, 1
  store i64 %t76, ptr %l47, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load i64, ptr %l45, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb28:
  %t86 = load i64, ptr %l47, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb30:
  %t90 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l45, !tbaa !24
  %t93 = load i64, ptr %l47, !tbaa !24
  %t94 = getelementptr i8, ptr %t91, i64 %t92
  %t95 = sub i64 %t93, %t92
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t101 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t99)
  store i1 %t101, ptr %l54
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb32:
  %t102 = load i1, ptr %l54, !tbaa !21
  %t103 = xor i1 %t102, true
  br i1 %t103, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb34:
  br label %bb35
bb35:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp eq i64 %t105, 0
  br i1 %t107, label %bb36, label %bb37
bb36:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t109, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t111, ptr %l60
  br label %bb38
bb37:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb39
bb38:
  %t112 = load i1, ptr %l60, !tbaa !21
  store i1 %t112, ptr %l58, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l58, !tbaa !21
  br i1 %t113, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t114 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t114)
  br label %bb43
bb43:
  %t117 = load i64, ptr %l5, !tbaa !24
  store i64 %t117, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  br label %bb21
bb45:
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t120, ptr %l65
  br label %bb46
bb46:
  %t121 = load i64, ptr %l65, !tbaa !24
  %t122 = icmp eq i64 %t121, 0
  br i1 %t122, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l68, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l69, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l70, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l69, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t138, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t141, ptr %l72
  br label %bb50
bb50:
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = sub i64 %t142, 1
  store i64 %t143, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t149, ptr %l76, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t151 = load i64, ptr %l3, !tbaa !24
  %t153 = sub i64 %t151, 1
  %t156 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t150, i64 %t153)
  store i64 %t156, ptr %l80
  br label %bb53
bb52:
  br label %bb93
bb53:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = sub i64 %t157, 1
  store i64 %t159, ptr %l82, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l83, !tbaa !24
  %t162 = load i64, ptr %l80, !tbaa !24
  %t163 = icmp sge i64 %t162, 0
  br i1 %t163, label %bb54, label %bb55
bb54:
  %t165 = load i64, ptr %l80, !tbaa !24
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = icmp sle i64 %t165, %t166
  br i1 %t167, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb56:
  %t169 = load i64, ptr %l82, !tbaa !24
  %t170 = load i64, ptr %l83, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb58:
  %t173 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l80, !tbaa !24
  %t176 = load i64, ptr %l82, !tbaa !24
  %t177 = getelementptr i8, ptr %t174, i64 %t175
  %t178 = sub i64 %t176, %t175
  %t179 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  store { i64, ptr } %t180, ptr %l8, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t182)
  store i64 %t184, ptr %l89
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb60:
  %t185 = load i64, ptr %l89, !tbaa !24
  store i64 %t185, ptr %l9, !tbaa !24
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = icmp sge i64 %t186, 0
  br i1 %t188, label %bb61, label %bb62
bb61:
  %t190 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t190, ptr %l93, !tbaa !27
  %t191 = load i64, ptr %l9, !tbaa !24
  store i64 %t191, ptr %l94, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l95, !tbaa !24
  %t194 = icmp sge i64 0, 0
  br i1 %t194, label %bb63, label %bb64
bb62:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb70
bb63:
  %t196 = load i64, ptr %l94, !tbaa !24
  %t197 = icmp sle i64 0, %t196
  br i1 %t197, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb65:
  %t199 = load i64, ptr %l94, !tbaa !24
  %t200 = load i64, ptr %l95, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb67:
  %t203 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l94, !tbaa !24
  %t206 = getelementptr i8, ptr %t204, i64 0
  %t207 = sub i64 %t205, 0
  %t208 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t211 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s7, { i64, ptr } %t209)
  store { i64, ptr } %t211, ptr %l100
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb69:
  %t212 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t215 = icmp sgt i64 %t213, 0
  store i1 %t215, ptr %l92, !tbaa !21
  br label %bb70
bb70:
  %t217 = load i1, ptr %l92, !tbaa !21
  br i1 %t217, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb92
bb73:
  store %olang.scope zeroinitializer, ptr %s9
  %t218 = load i64, ptr %l7, !tbaa !24
  %t220 = icmp sge i64 %t218, 0
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s9)
  br label %bb91
bb75:
  br label %bb76
bb76:
  %t224 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t224, ptr %l106, !tbaa !27
  %t225 = load i64, ptr %l7, !tbaa !24
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t225)
  store i64 %t228, ptr %l109
  br label %bb77
bb77:
  %t229 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t229, ptr %l110, !tbaa !27
  %t230 = load i64, ptr %l7, !tbaa !24
  %t233 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t230)
  store i64 %t233, ptr %l113
  br label %bb78
bb78:
  %t234 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t235 = load i64, ptr %l113, !tbaa !24
  %t236 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t234, i64 %t235)
  store i64 %t236, ptr %l114
  br label %bb79
bb79:
  %t237 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l115, !tbaa !24
  %t239 = load i64, ptr %l109, !tbaa !24
  %t240 = icmp sge i64 %t239, 0
  br i1 %t240, label %bb80, label %bb81
bb80:
  %t242 = load i64, ptr %l109, !tbaa !24
  %t243 = load i64, ptr %l114, !tbaa !24
  %t244 = icmp sle i64 %t242, %t243
  br i1 %t244, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb82:
  %t246 = load i64, ptr %l114, !tbaa !24
  %t247 = load i64, ptr %l115, !tbaa !24
  %t248 = icmp sle i64 %t246, %t247
  br i1 %t248, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb84:
  %t250 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l109, !tbaa !24
  %t253 = load i64, ptr %l114, !tbaa !24
  %t254 = getelementptr i8, ptr %t251, i64 %t252
  %t255 = sub i64 %t253, %t252
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  store { i64, ptr } %t257, ptr %l10, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l121, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t264 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s9, { i64, ptr } %t262)
  store { i64, ptr } %t264, ptr %l123
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb86:
  %t265 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t267 = load i64, ptr %l121, !tbaa !24
  %t269 = sub i64 %t267, %t266
  %t270 = load i64, ptr %l9, !tbaa !24
  %t273 = icmp ne i64 %t269, %t270
  br i1 %t273, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s9)
  br label %bb91
bb88:
  br label %bb89
bb89:
  %t275 = load i64, ptr %l7, !tbaa !24
  %t277 = sub i64 %t275, 1
  store i64 %t277, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb90:
  br label %bb73
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s7)
  br label %bb93
bb93:
  %t279 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t279, ptr %l130
  br label %bb94
bb94:
  %t280 = load %"std/prelude/text:StringBuilder", ptr %l130
  store %"std/prelude/text:StringBuilder" %t280, ptr %l11
  %t281 = load i64, ptr %l7, !tbaa !24
  store i64 %t281, ptr %l12, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s12
  %t283 = load i64, ptr %l12, !tbaa !24
  %t285 = icmp sge i64 %t283, 0
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s12)
  br label %bb115
bb97:
  br label %bb98
bb98:
  %t289 = load i64, ptr %l12, !tbaa !24
  %t290 = load i64, ptr %l7, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  br i1 %t293, label %bb99, label %bb100
bb99:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l11, i8 10)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  store ptr %l11, ptr %l139, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t296, ptr %l140, !tbaa !27
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t297)
  store i64 %t300, ptr %l143
  br label %bb103
bb103:
  %t301 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t301, ptr %l144, !tbaa !27
  %t302 = load i64, ptr %l12, !tbaa !24
  %t305 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t302)
  store i64 %t305, ptr %l147
  br label %bb104
bb104:
  %t306 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t307 = load i64, ptr %l147, !tbaa !24
  %t308 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t306, i64 %t307)
  store i64 %t308, ptr %l148
  br label %bb105
bb105:
  %t309 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  store i64 %t310, ptr %l149, !tbaa !24
  %t311 = load i64, ptr %l143, !tbaa !24
  %t312 = icmp sge i64 %t311, 0
  br i1 %t312, label %bb106, label %bb107
bb106:
  %t314 = load i64, ptr %l143, !tbaa !24
  %t315 = load i64, ptr %l148, !tbaa !24
  %t316 = icmp sle i64 %t314, %t315
  br i1 %t316, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb108:
  %t318 = load i64, ptr %l148, !tbaa !24
  %t319 = load i64, ptr %l149, !tbaa !24
  %t320 = icmp sle i64 %t318, %t319
  br i1 %t320, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb110:
  %t322 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = load i64, ptr %l143, !tbaa !24
  %t325 = load i64, ptr %l148, !tbaa !24
  %t326 = getelementptr i8, ptr %t323, i64 %t324
  %t327 = sub i64 %t325, %t324
  %t328 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t326, 1
  %t331 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s12, { i64, ptr } %t329)
  store { i64, ptr } %t331, ptr %l154
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836)
  unreachable
bb112:
  %t332 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = extractvalue { i64, ptr } %t332, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t339 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t339, { i64, ptr } %t338)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb114:
  %t341 = load i64, ptr %l12, !tbaa !24
  %t343 = sub i64 %t341, 1
  store i64 %t343, ptr %l12, !tbaa !24
  br label %bb95
bb115:
  %t346 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l11)
  store { i64, ptr } %t346, ptr %l159
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s0)
  %t347 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t347, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca i1
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = load ptr, ptr %lp3
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %lp3
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb2
bb2:
  %t13 = load i1, ptr %l8, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t18 = xor i1 %a2, true
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %lp3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l16
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l2, !tbaa !22
  %t19 = load i8, ptr %l2, !tbaa !22
  %t21 = icmp eq i8 %t19, 34
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 39
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb22
bb10:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp slt i64 %t32, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t47 = load i8, ptr %l2, !tbaa !22
  %t50 = icmp ne i8 %t46, %t47
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = icmp eq i8 %t61, 92
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i64, ptr %l1, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  br label %bb10
bb21:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb45
bb22:
  %t77 = load i8, ptr %l2, !tbaa !22
  %t79 = icmp eq i8 %t77, 35
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp slt i64 %t83, %t86
  br i1 %t89, label %bb25, label %bb26
bb24:
  br label %bb44
bb25:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = load i64, ptr %l1, !tbaa !24
  %t94 = add i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = icmp eq i8 %t99, 35
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l47, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t104, ptr %l54, !tbaa !27
  %t105 = load i64, ptr %l1, !tbaa !24
  %t107 = add i64 %t105, 2
  store i64 %t107, ptr %l56, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t108, 0
  store i64 %t111, ptr %l59, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l60, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = icmp sge i64 %t114, 0
  br i1 %t115, label %bb30, label %bb31
bb29:
  br label %bb43
bb30:
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb32:
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = load i64, ptr %l60, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb34:
  %t125 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = getelementptr i8, ptr %t126, i64 %t127
  %t130 = sub i64 %t128, %t127
  %t131 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t134 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) })
  %t135 = extractvalue { i32, i64 } %t134, 1
  %t136 = extractvalue { i32, i64 } %t134, 0
  store i32 %t136, ptr %l66
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb37, label %ok.138, !prof !99
ok.138:
  store i64 %t135, ptr %l65
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb36:
  %t139 = load i64, ptr %l65, !tbaa !24
  store i64 %t139, ptr %l53, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb39
bb39:
  %t140 = load i64, ptr %l53, !tbaa !24
  store i64 %t140, ptr %l3, !tbaa !24
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  store i64 -1, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t146 = load i64, ptr %l1, !tbaa !24
  %t148 = add i64 %t146, 2
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = add i64 %t152, 2
  store i64 %t154, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb43:
  %t156 = load i64, ptr %l1, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb44:
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb1
bb46:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eDeprecatedNames(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb7:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t19)
  store i1 %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s3, { i64, ptr } %t23)
  store { i64, ptr } %t25, ptr %l23
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s3, { i64, ptr } %t32, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t34, ptr %l25
  br label %bb12
bb12:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb16:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l5, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t38)
  store i64 %t40, ptr %l28
  br label %bb17
bb17:
  %t41 = load i64, ptr %l28, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  store i64 %t47, ptr %l33, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l36, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l37, !tbaa !24
  %t54 = load i64, ptr %l33, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb28
bb20:
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb22:
  %t61 = load i64, ptr %l36, !tbaa !24
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb24:
  %t65 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = getelementptr i8, ptr %t66, i64 %t67
  %t70 = sub i64 %t68, %t67
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l42
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb26:
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t83, ptr %l44
  br label %bb27
bb27:
  %t84 = load i1, ptr %l44, !tbaa !21
  store i1 %t84, ptr %l31, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l31, !tbaa !21
  store i1 %t85, ptr %l7, !tbaa !21
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l47, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  store i64 %t91, ptr %l48, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l49, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  %t96 = load i64, ptr %l48, !tbaa !24
  %t97 = icmp sle i64 0, %t96
  br i1 %t97, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb33:
  %t99 = load i64, ptr %l48, !tbaa !24
  %t100 = load i64, ptr %l49, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb35:
  %t103 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l48, !tbaa !24
  %t106 = getelementptr i8, ptr %t104, i64 0
  %t107 = sub i64 %t105, 0
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l5, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb37:
  %t124 = load i1, ptr %l2, !tbaa !21
  br i1 %t124, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb40
bb39:
  %t126 = load i1, ptr %l7, !tbaa !21
  store i1 %t126, ptr %l57, !tbaa !21
  br label %bb40
bb40:
  %t128 = load i1, ptr %l57, !tbaa !21
  br i1 %t128, label %bb41, label %bb42
bb41:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l60, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_scope_of(ptr %t131, ptr null)
  %t133 = ptrtoint ptr %t132 to i64
  %t135 = inttoptr i64 %t133 to ptr
  %t136 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %t135, ptr %s2, { i64, ptr } %t136)
  store { i64, ptr } %t137, ptr %l62
  br label %bb43
bb42:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb45
bb43:
  %t138 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t138, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t139, ptr %l63
  br label %bb44
bb44:
  %t140 = load i1, ptr %l63, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l59, !tbaa !21
  br label %bb45
bb45:
  %t143 = load i1, ptr %l59, !tbaa !21
  br i1 %t143, label %bb46, label %bb47
bb46:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l65, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_scope_of(ptr %t146, ptr null)
  %t148 = ptrtoint ptr %t147 to i64
  %t150 = inttoptr i64 %t148 to ptr
  %t151 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2ewordsOf(ptr %t150, ptr %v1, { i64, ptr } %t151)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l67
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %t154
  store ptr %t154, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb49
bb49:
  %t156 = load i64, ptr %l9, !tbaa !24
  store i64 %t156, ptr %l69, !tbaa !24
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t157)
  store i64 %t159, ptr %l71
  br label %bb50
bb50:
  %t160 = load i64, ptr %l69, !tbaa !24
  %t161 = load i64, ptr %l71, !tbaa !24
  %t162 = icmp slt i64 %t160, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb51, label %bb52
bb51:
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t166, i64 %t167)
  store { i64, ptr } %t170, ptr %l76
  br label %bb54
bb54:
  %t171 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } %t171)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l9, !tbaa !24
  br label %bb49
bb57:
  br label %bb58
bb58:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb59:
  br label %bb3
bb60:
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 true, ptr %l2, !tbaa !21
  store i1 false, ptr %l3, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l11
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t21, ptr %l16
  br label %bb8
bb8:
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t23 = load i1, ptr %l3, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb10:
  br label %bb14
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb12:
  br label %bb13
bb13:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb14:
  %t25 = load i1, ptr %l2, !tbaa !21
  br i1 %t25, label %bb15, label %bb16
bb15:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t29, ptr %l21
  br label %bb17
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb18
bb17:
  %t30 = load i1, ptr %l21, !tbaa !21
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  store i1 false, ptr %l2, !tbaa !21
  %t32 = load i1, ptr %l3, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t37 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t37, ptr %l25
  br label %bb25
bb25:
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = icmp sgt i64 %t38, 0
  br i1 %t39, label %bb26, label %bb27
bb26:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  store ptr %l1, ptr %l28, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l30
  br label %bb30
bb30:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t45, { i64, ptr } %t46)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb3
bb33:
  %t48 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t48, ptr %l32
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fdoc_2eEntry_2eitem(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %lp12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i1
  %lp16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %lp31 = alloca ptr
  %lp32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %lp35 = alloca ptr
  %lp36 = alloca ptr
  %l37 = alloca i64
  %l43 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l67 = alloca %"std/prelude/text:StringBuilder"
  %l69 = alloca i1
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l77 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l89 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca %"compiler/doc:Entry"
  %l140 = alloca i64
  %l144 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca i1
  %l162 = alloca %"compiler/doc:Entry"
  %l166 = alloca i32
  %l167 = alloca i64
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca i64
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l180 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca i64
  %l190 = alloca i64
  %l210 = alloca i1
  %l211 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca i64
  %l220 = alloca ptr
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l223 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l230 = alloca i1
  %l231 = alloca i1
  %l233 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l239 = alloca i64
  %l241 = alloca i64
  %l247 = alloca { i64, ptr }
  %l250 = alloca i1
  %l252 = alloca i64
  %l257 = alloca %"compiler/doc:Entry"
  %l264 = alloca ptr
  %l265 = alloca ptr
  %l267 = alloca { i64, ptr }
  %l270 = alloca i1
  %l271 = alloca ptr
  %l273 = alloca %"compiler/doc:Entry"
  %l275 = alloca i1
  %l277 = alloca { i64, ptr }
  %l280 = alloca i1
  %l282 = alloca i1
  %l286 = alloca %"compiler/doc:Entry"
  %l290 = alloca ptr
  %l294 = alloca i32
  %l295 = alloca ptr
  %l296 = alloca i64
  %l300 = alloca i32
  %l301 = alloca i64
  %l307 = alloca ptr
  %l311 = alloca i64
  %l312 = alloca ptr
  %l313 = alloca i64
  %l321 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l329 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l343 = alloca %"compiler/doc:Entry"
  %l345 = alloca { i64, ptr }
  %l348 = alloca i1
  %l350 = alloca i1
  %l354 = alloca %"compiler/doc:Entry"
  %l359 = alloca i64
  %l364 = alloca i1
  %l367 = alloca i64
  %l370 = alloca i64
  %l372 = alloca i64
  %l376 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l384 = alloca %"compiler/doc:Entry"
  %l387 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t286 = alloca %"compiler/doc:Entry", align 8
  %t609 = alloca %"compiler/doc:Entry", align 8
  %t664 = alloca %"compiler/doc:Entry", align 8
  %t667 = alloca %"compiler/doc:Entry", align 8
  %t693 = alloca %"compiler/doc:Entry", align 8
  %t847 = alloca %"compiler/doc:Entry", align 8
  %t869 = alloca %"compiler/doc:Entry", align 8
  %t954 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l43
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l43, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2d405ddcd9a8ab59_87891e6f641f4355)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/load:Loader", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l8, !tbaa !29
  %t42 = ptrtoint ptr %s0 to i64
  store i64 %t42, ptr %l56, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e9
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = call ptr @__olang_region_make(ptr %s0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l56, !tbaa !24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = load i64, ptr %l56
  %t53 = inttoptr i64 %t52 to ptr
  %t59 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t53, ptr %t47, ptr %t48, ptr %t49, i64 %t50, { i64, ptr } %t51)
  %t60 = extractvalue { i32, { i64, ptr } } %t59, 1
  %t61 = extractvalue { i32, { i64, ptr } } %t59, 0
  store i32 %t61, ptr %l64
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb8, label %ok.63, !prof !99
ok.63:
  store { i64, ptr } %t60, ptr %l63
  br label %bb7
bb7:
  %t64 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e9
  br i1 %t64, label %bb9, label %bb10
bb8:
  %t66 = load i32, ptr %l64, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  call void @__olang_scope_close(ptr %s0)
  store i32 %t74, ptr %rv
  br label %ret
bb9:
  %t76 = load i64, ptr %l56
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = load { i64, ptr }, ptr %l63
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_region_or(ptr %t79, ptr null)
  %t81 = icmp ne ptr %t80, null
  %t82 = select i1 %t81, ptr %t80, ptr null
  %t83 = icmp eq ptr %t82, %t77
  call void @__olang_region_settle(ptr %t77, i1 %t83)
  br label %bb10
bb10:
  %t84 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t84, ptr %l55, !tbaa !27
  br label %bb11
bb11:
  %t85 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t85, ptr %l9, !tbaa !27
  %t86 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t86, ptr %l67
  br label %bb12
bb12:
  %t87 = load %"std/prelude/text:StringBuilder", ptr %l67
  store %"std/prelude/text:StringBuilder" %t87, ptr %l10
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t88 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s1, { i64, ptr } %t88, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t90, ptr %l69
  br label %bb14
bb14:
  %t91 = load i1, ptr %l69, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb41
bb16:
  br label %bb17
bb17:
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t96 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s1, { i64, ptr } %t94, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  %t97 = extractvalue { i32, i64 } %t96, 1
  %t98 = extractvalue { i32, i64 } %t96, 0
  store i32 %t98, ptr %l74
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb19, label %ok.100, !prof !99
ok.100:
  store i64 %t97, ptr %l73
  br label %bb18
bb18:
  %t101 = load i64, ptr %l73, !tbaa !24
  store i64 %t101, ptr %l71, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l71, !tbaa !24
  br label %bb21
bb21:
  %t106 = load i64, ptr %l71, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  store ptr %l10, ptr %l77, !tbaa !29
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l79, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l80, !tbaa !24
  %t112 = icmp sge i64 0, 0
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t114 = load i64, ptr %l79, !tbaa !24
  %t115 = icmp sle i64 0, %t114
  br i1 %t115, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_84ace3bf0f23a4a_6d246e44ba5edd86)
  unreachable
bb24:
  %t117 = load i64, ptr %l79, !tbaa !24
  %t118 = load i64, ptr %l80, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_84ace3bf0f23a4a_6d246e44ba5edd86)
  unreachable
bb26:
  %t121 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l79, !tbaa !24
  %t124 = getelementptr i8, ptr %t122, i64 0
  %t125 = sub i64 %t123, 0
  %t126 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t124, 1
  %t128 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t127)
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_84ace3bf0f23a4a_6d246e44ba5edd86)
  unreachable
bb28:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t136 = icmp slt i64 %t130, %t133
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l91, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l93, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l94, !tbaa !24
  %t146 = load i64, ptr %l91, !tbaa !24
  %t147 = icmp sge i64 %t146, 0
  br i1 %t147, label %bb31, label %bb32
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t149, ptr %l89, !tbaa !27
  br label %bb37
bb31:
  %t151 = load i64, ptr %l91, !tbaa !24
  %t152 = load i64, ptr %l93, !tbaa !24
  %t153 = icmp sle i64 %t151, %t152
  br i1 %t153, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_ea407f163068c569_14e8b422ff4a82a5)
  unreachable
bb33:
  %t155 = load i64, ptr %l93, !tbaa !24
  %t156 = load i64, ptr %l94, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_ea407f163068c569_14e8b422ff4a82a5)
  unreachable
bb35:
  %t159 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l91, !tbaa !24
  %t162 = load i64, ptr %l93, !tbaa !24
  %t163 = getelementptr i8, ptr %t160, i64 %t161
  %t164 = sub i64 %t162, %t161
  %t165 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  store { i64, ptr } %t166, ptr %l89, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ea407f163068c569_14e8b422ff4a82a5)
  unreachable
bb37:
  %t169 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t169, ptr %l102, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l103, !tbaa !24
  %t172 = load i64, ptr %l103, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l104, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l103, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t183, ptr %l9, !tbaa !27
  %t184 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e9
  br i1 %t184, label %bb38, label %bb39
bb38:
  %t186 = load { i64, ptr }, ptr %l102
  %t187 = extractvalue { i64, ptr } %t186, 1
  call void @__olang_region_release(ptr %t187)
  store { i64, ptr } zeroinitializer, ptr %l102
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s1)
  br label %bb40
bb40:
  br label %bb13
bb41:
  %t188 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t188, ptr %l106, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l107, !tbaa !24
  %t191 = load i64, ptr %l107, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l108, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l107, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t202, ptr %lp12
  %t203 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t204 = load ptr, ptr %lp12
  store { i64, ptr } %t203, ptr %t204, !tbaa !27
  %t205 = load ptr, ptr %lp12
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v4, ptr %v4, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l110
  br label %bb42
bb42:
  %t209 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t210 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v4, ptr %s0, ptr %v4, { i64, ptr } %t209, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store { i64, ptr } %t210, ptr %l111
  br label %bb43
bb43:
  %t211 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t211, ptr %l13, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l3, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t218 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v3, ptr %t212, i64 %t213, { i64, ptr } %t214)
  store i64 %t218, ptr %l115
  br label %bb44
bb44:
  %t219 = load i64, ptr %l115, !tbaa !24
  store i64 %t219, ptr %l14, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t220, ptr %l116, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %t222, i64 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !37
  %t226 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t224, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t226, ptr %l118
  br label %bb45
bb45:
  %t227 = load i1, ptr %l118, !tbaa !21
  br i1 %t227, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb49
bb47:
  %t228 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t228, ptr %l120, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %t230, i64 0
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !37
  %t234 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t232, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t234, ptr %l122
  br label %bb48
bb48:
  %t235 = load i1, ptr %l122, !tbaa !21
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb49
bb49:
  %t236 = load i1, ptr %l119, !tbaa !21
  store i1 %t236, ptr %l15, !tbaa !21
  %t237 = ptrtoint ptr %v4 to i64
  store i64 %t237, ptr %l123, !tbaa !24
  %t238 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t238, label %bb50, label %bb51
bb50:
  %t240 = call ptr @__olang_region_make(ptr %v4)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l123, !tbaa !24
  br label %bb51
bb51:
  %t243 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t243, ptr %l126
  br label %bb52
bb52:
  %t244 = load i1, ptr %l15, !tbaa !21
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t246 = load ptr, ptr %lp12
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  %t249 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v4, ptr %s0, { i64, ptr } %t247)
  store { i64, ptr } %t249, ptr %l130
  br label %bb55
bb54:
  %t250 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t250, ptr %l131, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %t252, i64 0
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !37
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = extractvalue { i64, ptr } %t254, 0
  %t258 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t256, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l128, !tbaa !27
  br label %bb56
bb55:
  %t262 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t262, ptr %l128, !tbaa !27
  br label %bb56
bb56:
  %t263 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = load i64, ptr %l123
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = call ptr @__olang_held_alloc(ptr %t271, i64 %t269)
  call void @olang_textcopy(ptr %t272, ptr %t264, i64 %t265)
  %t273 = getelementptr i8, ptr %t272, i64 %t265
  call void @olang_textcopy(ptr %t273, ptr %t267, i64 %t268)
  %t274 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t272, 1
  %t277 = load i64, ptr %l123
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = extractvalue { i64, ptr } %t275, 0
  %t280 = extractvalue { i64, ptr } %t275, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_held_alloc(ptr %t278, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t286, ptr %v4, ptr %v4, ptr %v3, ptr %v4, { i64, ptr } %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, { i64, ptr } %t285)
  call void @llvm.memmove.p0.p0.i64(ptr %l137, ptr %t286, i64 152, i1 false)
  br label %bb57
bb57:
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t289, ptr %lp16
  %t290 = load ptr, ptr %lp16
  call void @llvm.memmove.p0.p0.i64(ptr %t290, ptr %l137, i64 152, i1 false)
  %t291 = load i64, ptr %l14, !tbaa !24
  %t293 = icmp sge i64 %t291, 0
  br i1 %t293, label %bb58, label %bb59
bb58:
  %t295 = ptrtoint ptr %v4 to i64
  store i64 %t295, ptr %l140, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t296, label %bb60, label %bb61
bb59:
  br label %bb65
bb60:
  %t298 = call ptr @__olang_region_make(ptr %v4)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l140, !tbaa !24
  br label %bb61
bb61:
  %t300 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t301 = load i64, ptr %l14, !tbaa !24
  %t302 = load i64, ptr %l140
  %t303 = inttoptr i64 %t302 to ptr
  %t306 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %t303, { i64, ptr } %t300, i64 %t301, i1 true)
  store { i64, ptr } %t306, ptr %l144
  br label %bb62
bb62:
  %t307 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t308 = load i64, ptr %l140
  %t309 = inttoptr i64 %t308 to ptr
  %t310 = extractvalue { i64, ptr } %t307, 0
  %t311 = extractvalue { i64, ptr } %t307, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_held_alloc(ptr %t309, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %lp16
  %t317 = getelementptr %"compiler/doc:Entry", ptr %t316, i32 0, i32 1
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  store { i64, ptr } %t318, ptr %l146, !tbaa !27
  %t320 = load ptr, ptr %lp16
  %t321 = getelementptr %"compiler/doc:Entry", ptr %t320, i32 0, i32 1
  store { i64, ptr } %t315, ptr %t321, !tbaa !27
  %t322 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t322, label %bb63, label %bb64
bb63:
  %t324 = load { i64, ptr }, ptr %l146
  %t325 = extractvalue { i64, ptr } %t324, 1
  call void @__olang_region_release(ptr %t325)
  store { i64, ptr } zeroinitializer, ptr %l146
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t326 = load ptr, ptr %l6, !tbaa !29
  %t328 = getelementptr %"compiler/load:Module", ptr %t326, i32 0, i32 4
  %t329 = load i64, ptr %t328, !tbaa !24
  %t331 = load ptr, ptr %lp16
  %t332 = getelementptr %"compiler/doc:Entry", ptr %t331, i32 0, i32 3
  store i64 %t329, ptr %t332, !tbaa !24
  %t333 = load i64, ptr %l14, !tbaa !24
  %t335 = load ptr, ptr %lp16
  %t336 = getelementptr %"compiler/doc:Entry", ptr %t335, i32 0, i32 4
  store i64 %t333, ptr %t336, !tbaa !24
  %t337 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t337, ptr %l151, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr { i64, ptr }, ptr %t339, i64 0
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !37
  %t343 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t341, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t343, ptr %l153
  br label %bb66
bb66:
  %t344 = load i1, ptr %l153, !tbaa !21
  br i1 %t344, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb70
bb68:
  %t345 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t345, ptr %l155, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %t347, i64 0
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !37
  %t351 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t349, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t351, ptr %l157
  br label %bb69
bb69:
  %t352 = load i1, ptr %l157, !tbaa !21
  store i1 %t352, ptr %l154, !tbaa !21
  br label %bb70
bb70:
  %t353 = load i1, ptr %l154, !tbaa !21
  br i1 %t353, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l158, !tbaa !21
  br label %bb73
bb72:
  %t354 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t358 = icmp eq i64 %t356, 1
  store i1 %t358, ptr %l158, !tbaa !21
  br label %bb73
bb73:
  %t360 = load i1, ptr %l158, !tbaa !21
  br i1 %t360, label %bb74, label %bb75
bb74:
  %t361 = load ptr, ptr %lp16
  call void @llvm.memmove.p0.p0.i64(ptr %l162, ptr %t361, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l162, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i64, ptr %l3, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t368 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v3, ptr %t362, i64 %t363, { i64, ptr } %t364)
  store i32 %t368, ptr %l166
  br label %bb77
bb77:
  %t369 = load i32, ptr %l166, !tbaa !23
  store i32 %t369, ptr %l17, !tbaa !23
  %t370 = ptrtoint ptr %s0 to i64
  store i64 %t370, ptr %l167, !tbaa !24
  %t371 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18
  br i1 %t371, label %bb78, label %bb79
bb78:
  %t373 = call ptr @__olang_region_make(ptr %s0)
  %t374 = ptrtoint ptr %t373 to i64
  store i64 %t374, ptr %l167, !tbaa !24
  br label %bb79
bb79:
  %t375 = load i64, ptr %l167
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t376, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t377, ptr %l169
  br label %bb80
bb80:
  %t378 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18
  br i1 %t378, label %bb81, label %bb82
bb81:
  %t380 = load i64, ptr %l167
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = call ptr @__olang_region_or(ptr %t384, ptr null)
  %t386 = call ptr @__olang_region_home(ptr %t385)
  %t387 = icmp ne ptr %t386, null
  %t388 = select i1 %t387, ptr %t386, ptr null
  %t389 = icmp eq ptr %t388, %t381
  call void @__olang_region_settle(ptr %t381, i1 %t389)
  br label %bb82
bb82:
  %t390 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t390, ptr %l18
  %t391 = load i32, ptr %l17, !tbaa !23
  %t393 = icmp sge i32 %t391, 0
  br i1 %t393, label %bb83, label %bb84
bb83:
  %t395 = ptrtoint ptr %s0 to i64
  store i64 %t395, ptr %l173, !tbaa !24
  %t396 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18
  br i1 %t396, label %bb85, label %bb86
bb84:
  br label %bb92
bb85:
  %t398 = call ptr @__olang_region_make(ptr %s0)
  %t399 = ptrtoint ptr %t398 to i64
  store i64 %t399, ptr %l173, !tbaa !24
  br label %bb86
bb86:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i32, ptr %l17, !tbaa !23
  %t402 = load i1, ptr %l5, !tbaa !21
  %t403 = load i64, ptr %l173
  %t404 = inttoptr i64 %t403 to ptr
  %t408 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %t404, ptr %t400, i32 %t401, i1 %t402)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t408, ptr %l178
  br label %bb87
bb87:
  %t409 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18
  br i1 %t409, label %bb88, label %bb89
bb88:
  %t411 = load i64, ptr %l173
  %t412 = inttoptr i64 %t411 to ptr
  %t413 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178, i32 0, i32 0
  %t414 = load { i64, ptr }, ptr %t413
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = call ptr @__olang_region_or(ptr %t415, ptr null)
  %t417 = call ptr @__olang_region_home(ptr %t416)
  %t418 = icmp ne ptr %t417, null
  %t419 = select i1 %t418, ptr %t417, ptr null
  %t420 = icmp eq ptr %t419, %t412
  call void @__olang_region_settle(ptr %t412, i1 %t420)
  br label %bb89
bb89:
  %t421 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t421, ptr %l180
  %t422 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t422, ptr %l18
  %t423 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18
  br i1 %t423, label %bb90, label %bb91
bb90:
  %t425 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l180, i32 0, i32 0
  %t426 = load { i64, ptr }, ptr %t425
  %t427 = extractvalue { i64, ptr } %t426, 1
  %t428 = call ptr @__olang_region_or(ptr %t427, ptr null)
  %t429 = call ptr @__olang_region_home(ptr %t428)
  %t430 = icmp ne ptr %t429, null
  %t431 = select i1 %t430, ptr %t429, ptr null
  call void @__olang_region_drop(ptr %t431)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l180
  br label %bb91
bb91:
  br label %bb92
bb92:
  store i1 false, ptr %l19, !tbaa !21
  store i64 1, ptr %l20, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t436 = load i64, ptr %l21, !tbaa !24
  %t437 = load i64, ptr %l20, !tbaa !24
  %t440 = icmp sgt i64 %t436, %t437
  br i1 %t440, label %bb93, label %bb94
bb93:
  %t442 = load i64, ptr %l22, !tbaa !24
  %t444 = icmp sgt i64 %t442, 0
  br i1 %t444, label %bb95, label %bb96
bb94:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb98
bb95:
  %t446 = load i64, ptr %l21, !tbaa !24
  %t447 = load i64, ptr %l20, !tbaa !24
  %t450 = sub i64 %t446, %t447
  %t451 = load i64, ptr %l22, !tbaa !24
  %t454 = add i64 %t450, %t451
  %t456 = sub i64 %t454, 1
  %t457 = load i64, ptr %l22, !tbaa !24
  %t460 = sdiv i64 %t456, %t457
  store i64 %t460, ptr %l190, !tbaa !24
  br label %bb97
bb96:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb97
bb97:
  %t462 = load i64, ptr %l190, !tbaa !24
  store i64 %t462, ptr %l187, !tbaa !24
  br label %bb98
bb98:
  %t463 = load i64, ptr %l187, !tbaa !24
  store i64 %t463, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s8
  %t464 = load i64, ptr %l24, !tbaa !24
  %t465 = load i64, ptr %l23, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s8)
  br label %bb214
bb101:
  br label %bb102
bb102:
  %t472 = load i64, ptr %l20, !tbaa !24
  %t473 = load i64, ptr %l24, !tbaa !24
  %t474 = load i64, ptr %l22, !tbaa !24
  %t477 = mul i64 %t473, %t474
  %t480 = add i64 %t472, %t477
  store i64 %t480, ptr %l25, !tbaa !24
  %t482 = load i1, ptr %l19, !tbaa !21
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb103, label %bb104
bb103:
  %t486 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t486, ptr %l211, !tbaa !27
  %t487 = load i64, ptr %l25, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr { i64, ptr }, ptr %t490, i64 %t487
  %t492 = load { i64, ptr }, ptr %t491, !tbaa !37
  %t494 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v4, ptr %v4, { i64, ptr } %t492)
  store { i64, ptr } %t494, ptr %l214
  br label %bb105
bb104:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb107
bb105:
  %t495 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t496 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t495, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t496, ptr %l215
  br label %bb106
bb106:
  %t497 = load i1, ptr %l215, !tbaa !21
  store i1 %t497, ptr %l210, !tbaa !21
  br label %bb107
bb107:
  %t498 = load i1, ptr %l210, !tbaa !21
  br i1 %t498, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s9
  store i1 true, ptr %l19, !tbaa !21
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l216, !tbaa !29
  %t500 = load ptr, ptr %l1, !tbaa !29
  store ptr %t500, ptr %l217, !tbaa !29
  %t501 = load ptr, ptr %l2, !tbaa !29
  store ptr %t501, ptr %l218, !tbaa !29
  %t502 = load i64, ptr %l3, !tbaa !24
  store i64 %t502, ptr %l219, !tbaa !24
  %t503 = load ptr, ptr %lp16
  store ptr %t503, ptr %l220, !tbaa !29
  %t504 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, ptr %l221
  %t506 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s9, ptr %l221)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t506, ptr %l223
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t507 = load i1, ptr %l5, !tbaa !21
  %t508 = load ptr, ptr %l216, !tbaa !29
  %t509 = load ptr, ptr %l217, !tbaa !29
  %t510 = load ptr, ptr %l218, !tbaa !29
  %t511 = load i64, ptr %l219, !tbaa !24
  %t512 = load ptr, ptr %l220, !tbaa !29
  %t513 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l223
  call void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %s9, ptr %t508, ptr %t509, ptr %t510, i64 %t511, ptr %t512, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t513, i1 %t507)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s9)
  br label %bb112
bb112:
  %t515 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t515, ptr %l225, !tbaa !27
  %t516 = load i64, ptr %l25, !tbaa !24
  %t518 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %t519, i64 %t516
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !37
  %t523 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v4, ptr %v4, { i64, ptr } %t521)
  store { i64, ptr } %t523, ptr %l228
  br label %bb113
bb113:
  %t524 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t524, ptr %l26, !tbaa !27
  %t525 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t527 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t525, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t527, ptr %l230
  br label %bb114
bb114:
  %t528 = load i1, ptr %l230, !tbaa !21
  br i1 %t528, label %bb115, label %bb116
bb115:
  %t529 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t531 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t529, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t531, ptr %l233
  br label %bb117
bb116:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb118
bb117:
  %t532 = load i1, ptr %l233, !tbaa !21
  %t533 = xor i1 %t532, true
  store i1 %t533, ptr %l231, !tbaa !21
  br label %bb118
bb118:
  %t535 = load i1, ptr %l231, !tbaa !21
  br i1 %t535, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb120:
  br label %bb121
bb121:
  %t536 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t538 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t536, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t538, ptr %l236
  br label %bb122
bb122:
  %t539 = load i1, ptr %l236, !tbaa !21
  br i1 %t539, label %bb123, label %bb124
bb123:
  %t540 = load ptr, ptr %lp16
  %t541 = getelementptr %"compiler/doc:Entry", ptr %t540, i32 0, i32 5
  %t543 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %t541)
  store i64 %t543, ptr %l239
  br label %bb125
bb124:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb126
bb125:
  %t544 = load i64, ptr %l239, !tbaa !24
  %t545 = icmp eq i64 %t544, 0
  store i1 %t545, ptr %l237, !tbaa !21
  br label %bb126
bb126:
  %t547 = load i1, ptr %l237, !tbaa !21
  br i1 %t547, label %bb127, label %bb128
bb127:
  %t548 = ptrtoint ptr %v4 to i64
  store i64 %t548, ptr %l241, !tbaa !24
  %t549 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t549, label %bb129, label %bb130
bb128:
  br label %bb133
bb129:
  %t551 = call ptr @__olang_region_make(ptr %v4)
  %t552 = ptrtoint ptr %t551 to i64
  store i64 %t552, ptr %l241, !tbaa !24
  br label %bb130
bb130:
  %t553 = load ptr, ptr %lp16
  %t554 = getelementptr %"compiler/doc:Entry", ptr %t553, i32 0, i32 0
  %t555 = load { i64, ptr }, ptr %t554, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t555, 1
  %t559 = extractvalue { i64, ptr } %t555, 0
  %t560 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t561 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t562 = add i64 %t559, %t561
  %t564 = extractvalue { i64, ptr } %t556, 1
  %t565 = extractvalue { i64, ptr } %t556, 0
  %t566 = add i64 %t562, %t565
  %t567 = load i64, ptr %l241
  %t568 = inttoptr i64 %t567 to ptr
  %t569 = call ptr @__olang_held_alloc(ptr %t568, i64 %t566)
  call void @olang_textcopy(ptr %t569, ptr %t558, i64 %t559)
  %t570 = getelementptr i8, ptr %t569, i64 %t559
  call void @olang_textcopy(ptr %t570, ptr %t560, i64 %t561)
  %t571 = getelementptr i8, ptr %t570, i64 %t561
  call void @olang_textcopy(ptr %t571, ptr %t564, i64 %t565)
  %t572 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t569, 1
  %t575 = load i64, ptr %l241
  %t576 = inttoptr i64 %t575 to ptr
  %t577 = extractvalue { i64, ptr } %t573, 0
  %t578 = extractvalue { i64, ptr } %t573, 1
  %t579 = mul i64 %t577, 1
  %t580 = call ptr @__olang_held_alloc(ptr %t576, i64 %t579)
  call void @llvm.memcpy.p0.p0.i64(ptr %t580, ptr %t578, i64 %t579, i1 false)
  %t581 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  %t583 = load ptr, ptr %lp16
  %t584 = getelementptr %"compiler/doc:Entry", ptr %t583, i32 0, i32 0
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l247, !tbaa !27
  %t587 = load ptr, ptr %lp16
  %t588 = getelementptr %"compiler/doc:Entry", ptr %t587, i32 0, i32 0
  store { i64, ptr } %t582, ptr %t588, !tbaa !27
  %t589 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t589, label %bb131, label %bb132
bb131:
  %t591 = load { i64, ptr }, ptr %l247
  %t592 = extractvalue { i64, ptr } %t591, 1
  call void @__olang_region_release(ptr %t592)
  store { i64, ptr } zeroinitializer, ptr %l247
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb133:
  %t593 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t595 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t593, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t595, ptr %l250
  br label %bb134
bb134:
  %t596 = load i1, ptr %l250, !tbaa !21
  br i1 %t596, label %bb135, label %bb136
bb135:
  %t597 = load ptr, ptr %lp16
  %t598 = getelementptr %"compiler/doc:Entry", ptr %t597, i32 0, i32 5
  %t600 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %t598)
  store i64 %t600, ptr %l252
  br label %bb137
bb136:
  br label %bb142
bb137:
  %t601 = load i64, ptr %l252, !tbaa !24
  %t602 = sub i64 %t601, 1
  store i64 %t602, ptr %l27, !tbaa !24
  %t604 = load i64, ptr %l27, !tbaa !24
  store i64 %t604, ptr %l28, !tbaa !24
  %t606 = load ptr, ptr %lp16
  %t607 = getelementptr %"compiler/doc:Entry", ptr %t606, i32 0, i32 5
  %t608 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t609, ptr %v4, ptr %v4, ptr %t607, i64 %t608)
  call void @llvm.memmove.p0.p0.i64(ptr %l257, ptr %t609, i64 152, i1 false)
  br label %bb138
bb138:
  %t612 = getelementptr %"compiler/doc:Entry", ptr %l257, i32 0, i32 0
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t613, 1
  %t617 = extractvalue { i64, ptr } %t613, 0
  %t618 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t619 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t620 = add i64 %t617, %t619
  %t622 = extractvalue { i64, ptr } %t614, 1
  %t623 = extractvalue { i64, ptr } %t614, 0
  %t624 = add i64 %t620, %t623
  %t625 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t624)
  call void @olang_textcopy(ptr %t625, ptr %t616, i64 %t617)
  %t626 = getelementptr i8, ptr %t625, i64 %t617
  call void @olang_textcopy(ptr %t626, ptr %t618, i64 %t619)
  %t627 = getelementptr i8, ptr %t626, i64 %t619
  call void @olang_textcopy(ptr %t627, ptr %t622, i64 %t623)
  %t628 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t625, 1
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t632 = extractvalue { i64, ptr } %t629, 1
  %t633 = mul i64 %t631, 1
  %t634 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t633)
  call void @llvm.memcpy.p0.p0.i64(ptr %t634, ptr %t632, i64 %t633, i1 false)
  %t635 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  store { i64, ptr } %t636, ptr %l29, !tbaa !27
  %t638 = load ptr, ptr %lp16
  %t639 = getelementptr %"compiler/doc:Entry", ptr %t638, i32 0, i32 5
  %t640 = load i64, ptr %l28, !tbaa !24
  %t643 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eRefMut_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t639, i64 %t640)
  store ptr %t643, ptr %l264
  br label %bb139
bb139:
  %t644 = load ptr, ptr %l264, !tbaa !29
  store ptr %t644, ptr %l265, !tbaa !29
  %t646 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t647 = load ptr, ptr %l265, !tbaa !29
  %t648 = getelementptr %"compiler/doc:Entry", ptr %t647, i32 0, i32 0
  %t649 = load { i64, ptr }, ptr %t648, !tbaa !27
  store { i64, ptr } %t649, ptr %l267, !tbaa !27
  %t651 = load ptr, ptr %l265, !tbaa !29
  %t652 = getelementptr %"compiler/doc:Entry", ptr %t651, i32 0, i32 0
  store { i64, ptr } %t646, ptr %t652, !tbaa !27
  %t653 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t653, label %bb140, label %bb141
bb140:
  %t655 = load { i64, ptr }, ptr %l267
  %t656 = extractvalue { i64, ptr } %t655, 1
  call void @__olang_region_release(ptr %t656)
  store { i64, ptr } zeroinitializer, ptr %l267
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb142:
  %t657 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t659 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t657, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t659, ptr %l270
  br label %bb143
bb143:
  %t660 = load i1, ptr %l270, !tbaa !21
  br i1 %t660, label %bb144, label %bb145
bb144:
  %t661 = load ptr, ptr %lp16
  %t662 = getelementptr %"compiler/doc:Entry", ptr %t661, i32 0, i32 5
  store ptr %t662, ptr %l271, !tbaa !29
  %t663 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t664, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t663, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l273, ptr %t664, i64 152, i1 false)
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t666 = load ptr, ptr %l271, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t667, ptr %l273, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t666, ptr %t667)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb148:
  %t668 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t670 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s8, { i64, ptr } %t668, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t670, ptr %l275
  br label %bb149
bb149:
  %t671 = load i1, ptr %l275, !tbaa !21
  br i1 %t671, label %bb150, label %bb151
bb150:
  %t672 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t674 = call { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v4, ptr %v4, { i64, ptr } %t672)
  store { i64, ptr } %t674, ptr %l277
  br label %bb152
bb151:
  br label %bb185
bb152:
  %t675 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t675, ptr %lp31
  %t676 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t677 = load ptr, ptr %lp31
  store { i64, ptr } %t676, ptr %t677, !tbaa !27
  %t678 = load i1, ptr %l5, !tbaa !21
  %t680 = xor i1 %t678, true
  br i1 %t680, label %bb153, label %bb154
bb153:
  %t682 = load ptr, ptr %lp31
  %t683 = load { i64, ptr }, ptr %t682, !tbaa !27
  %t685 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t683)
  store i1 %t685, ptr %l282
  br label %bb155
bb154:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb156
bb155:
  %t686 = load i1, ptr %l282, !tbaa !21
  %t687 = xor i1 %t686, true
  store i1 %t687, ptr %l280, !tbaa !21
  br label %bb156
bb156:
  %t689 = load i1, ptr %l280, !tbaa !21
  br i1 %t689, label %bb157, label %bb158
bb157:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb158:
  br label %bb159
bb159:
  %t690 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t691 = load ptr, ptr %lp31
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t693, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t690, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, { i64, ptr } %t692)
  call void @llvm.memmove.p0.p0.i64(ptr %l286, ptr %t693, i64 152, i1 false)
  br label %bb160
bb160:
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t696, ptr %lp32
  %t697 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %t697, ptr %l286, i64 152, i1 false)
  %t698 = load i32, ptr %l17, !tbaa !23
  %t700 = icmp sge i32 %t698, 0
  br i1 %t700, label %bb161, label %bb162
bb161:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = getelementptr %"compiler/check:Checker", ptr %t702, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !29
  store ptr %t705, ptr %l290, !tbaa !29
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t710 = load i32, ptr %l17, !tbaa !23
  %t713 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t709, i32 %t710)
  store i32 %t713, ptr %l294
  br label %bb163
bb162:
  br label %bb183
bb163:
  %t714 = load ptr, ptr %l8, !tbaa !29
  store ptr %t714, ptr %l295, !tbaa !29
  %t715 = ptrtoint ptr %v0 to i64
  store i64 %t715, ptr %l296, !tbaa !24
  %t716 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t716, label %bb164, label %bb165
bb164:
  %t718 = load ptr, ptr %l295, !tbaa !29
  %t719 = call ptr @__olang_region_or(ptr %t718, ptr %v0)
  %t720 = ptrtoint ptr %t719 to i64
  store i64 %t720, ptr %l296, !tbaa !24
  br label %bb165
bb165:
  %t721 = load ptr, ptr %l8, !tbaa !29
  %t722 = load ptr, ptr %lp31
  %t723 = load { i64, ptr }, ptr %t722, !tbaa !27
  %t724 = load i64, ptr %l296
  %t725 = inttoptr i64 %t724 to ptr
  %t728 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t725, ptr %v4, ptr %t721, { i64, ptr } %t723)
  store i32 %t728, ptr %l300
  br label %bb166
bb166:
  %t729 = load ptr, ptr %l290, !tbaa !29
  %t730 = load i32, ptr %l294, !tbaa !23
  %t731 = load i32, ptr %l300, !tbaa !23
  %t732 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t729, i32 %t730, i32 %t731)
  store i64 %t732, ptr %l301
  br label %bb167
bb167:
  %t733 = load i64, ptr %l301, !tbaa !24
  store i64 %t733, ptr %l33, !tbaa !24
  %t734 = load i64, ptr %l33, !tbaa !24
  %t736 = icmp sge i64 %t734, 0
  br i1 %t736, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s19
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t740 = getelementptr %"compiler/check:Checker", ptr %t738, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !29
  %t743 = getelementptr %"compiler/generic:Program", ptr %t741, i32 0, i32 0
  %t744 = load ptr, ptr %t743, !tbaa !29
  %t746 = getelementptr %"compiler/load:Loader", ptr %t744, i32 0, i32 10
  store ptr %t746, ptr %l307, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/check:Checker", ptr %t747, i32 0, i32 1
  %t750 = load ptr, ptr %t749, !tbaa !29
  %t751 = load i64, ptr %l33, !tbaa !24
  %t754 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t750, i64 %t751)
  store i64 %t754, ptr %l311
  br label %bb170
bb169:
  br label %bb182
bb170:
  %t755 = load ptr, ptr %l307, !tbaa !29
  %t756 = load i64, ptr %l311, !tbaa !24
  %t757 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t755, i64 %t756)
  store ptr %t757, ptr %l312
  br label %bb171
bb171:
  %t758 = load ptr, ptr %l312, !tbaa !29
  store ptr %t758, ptr %l34, !tbaa !29
  %t759 = ptrtoint ptr %v4 to i64
  store i64 %t759, ptr %l313, !tbaa !24
  %t760 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t760, label %bb172, label %bb173
bb172:
  %t762 = call ptr @__olang_region_make(ptr %v4)
  %t763 = ptrtoint ptr %t762 to i64
  store i64 %t763, ptr %l313, !tbaa !24
  br label %bb173
bb173:
  %t764 = load ptr, ptr %l34, !tbaa !29
  %t766 = getelementptr %"compiler/load:Module", ptr %t764, i32 0, i32 6
  %t767 = load ptr, ptr %t766, !tbaa !29
  %t769 = icmp eq ptr %t767, null
  br i1 %t769, label %bb174, label %bb175
bb174:
  call void @__olang_check_failed(ptr @olang_loc_66caf8065a216fa4_255d0b76d432a940)
  unreachable
bb175:
  br label %bb176
bb176:
  %t771 = load ptr, ptr %l34, !tbaa !29
  %t773 = getelementptr %"compiler/load:Module", ptr %t771, i32 0, i32 6
  %t774 = load ptr, ptr %t773, !tbaa !29
  %t777 = getelementptr %"compiler/source:Source", ptr %t774, i32 0, i32 1
  %t778 = load { i64, ptr }, ptr %t777, !tbaa !27
  store { i64, ptr } %t778, ptr %l321, !tbaa !27
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t781 = getelementptr %"compiler/check:Checker", ptr %t779, i32 0, i32 1
  %t782 = load ptr, ptr %t781, !tbaa !29
  %t783 = load i64, ptr %l33, !tbaa !24
  %t786 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s19, ptr %t782, i64 %t783)
  store ptr %t786, ptr %l325
  br label %bb177
bb177:
  %t787 = load ptr, ptr %l325, !tbaa !29
  %t789 = getelementptr %"compiler/ast:Func", ptr %t787, i32 0, i32 0
  %t790 = getelementptr %"compiler/source:Span", ptr %t789, i32 0, i32 0
  %t791 = load i32, ptr %t790, !tbaa !23
  %t793 = sext i32 %t791 to i64
  %t794 = load i64, ptr %l313
  %t795 = inttoptr i64 %t794 to ptr
  %t796 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t798 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t795, { i64, ptr } %t796, i64 %t793)
  store { i64, ptr } %t798, ptr %l329
  br label %bb178
bb178:
  %t799 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t800 = load i64, ptr %l313
  %t801 = inttoptr i64 %t800 to ptr
  %t802 = extractvalue { i64, ptr } %t799, 0
  %t803 = extractvalue { i64, ptr } %t799, 1
  %t804 = mul i64 %t802, 1
  %t805 = call ptr @__olang_held_alloc(ptr %t801, i64 %t804)
  call void @llvm.memcpy.p0.p0.i64(ptr %t805, ptr %t803, i64 %t804, i1 false)
  %t806 = insertvalue { i64, ptr } undef, i64 %t802, 0
  %t807 = insertvalue { i64, ptr } %t806, ptr %t805, 1
  %t808 = load ptr, ptr %lp32
  %t809 = getelementptr %"compiler/doc:Entry", ptr %t808, i32 0, i32 1
  %t810 = load { i64, ptr }, ptr %t809, !tbaa !27
  store { i64, ptr } %t810, ptr %l331, !tbaa !27
  %t812 = load ptr, ptr %lp32
  %t813 = getelementptr %"compiler/doc:Entry", ptr %t812, i32 0, i32 1
  store { i64, ptr } %t807, ptr %t813, !tbaa !27
  %t814 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t814, label %bb179, label %bb180
bb179:
  %t816 = load { i64, ptr }, ptr %l331
  %t817 = extractvalue { i64, ptr } %t816, 1
  call void @__olang_region_release(ptr %t817)
  store { i64, ptr } zeroinitializer, ptr %l331
  br label %bb180
bb180:
  %t818 = load ptr, ptr %l34, !tbaa !29
  %t820 = getelementptr %"compiler/load:Module", ptr %t818, i32 0, i32 4
  %t821 = load i64, ptr %t820, !tbaa !24
  %t823 = load ptr, ptr %lp32
  %t824 = getelementptr %"compiler/doc:Entry", ptr %t823, i32 0, i32 3
  store i64 %t821, ptr %t824, !tbaa !24
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/check:Checker", ptr %t825, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !29
  %t829 = load i64, ptr %l33, !tbaa !24
  %t832 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s19, ptr %t828, i64 %t829)
  store ptr %t832, ptr %l338
  br label %bb181
bb181:
  %t833 = load ptr, ptr %l338, !tbaa !29
  %t835 = getelementptr %"compiler/ast:Func", ptr %t833, i32 0, i32 0
  %t836 = getelementptr %"compiler/source:Span", ptr %t835, i32 0, i32 0
  %t837 = load i32, ptr %t836, !tbaa !23
  %t839 = sext i32 %t837 to i64
  %t841 = load ptr, ptr %lp32
  %t842 = getelementptr %"compiler/doc:Entry", ptr %t841, i32 0, i32 4
  store i64 %t839, ptr %t842, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb182
bb182:
  br label %bb183
bb183:
  %t843 = load ptr, ptr %lp16
  %t844 = getelementptr %"compiler/doc:Entry", ptr %t843, i32 0, i32 5
  %t845 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %l343, ptr %t845, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t847, ptr %l343, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t844, ptr %t847)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb185:
  %t848 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t850 = call { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v4, ptr %v4, { i64, ptr } %t848)
  store { i64, ptr } %t850, ptr %l345
  br label %bb186
bb186:
  %t851 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t851, ptr %lp35
  %t852 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t853 = load ptr, ptr %lp35
  store { i64, ptr } %t852, ptr %t853, !tbaa !27
  %t854 = load i1, ptr %l5, !tbaa !21
  %t856 = xor i1 %t854, true
  br i1 %t856, label %bb187, label %bb188
bb187:
  %t858 = load ptr, ptr %lp35
  %t859 = load { i64, ptr }, ptr %t858, !tbaa !27
  %t861 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t859)
  store i1 %t861, ptr %l350
  br label %bb189
bb188:
  store i1 false, ptr %l348, !tbaa !21
  br label %bb190
bb189:
  %t862 = load i1, ptr %l350, !tbaa !21
  %t863 = xor i1 %t862, true
  store i1 %t863, ptr %l348, !tbaa !21
  br label %bb190
bb190:
  %t865 = load i1, ptr %l348, !tbaa !21
  br i1 %t865, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb192:
  br label %bb193
bb193:
  %t866 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t867 = load ptr, ptr %lp35
  %t868 = load { i64, ptr }, ptr %t867, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t869, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t866, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } %t868)
  call void @llvm.memmove.p0.p0.i64(ptr %l354, ptr %t869, i64 152, i1 false)
  br label %bb194
bb194:
  %t872 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t872, ptr %lp36
  %t873 = load ptr, ptr %lp36
  call void @llvm.memmove.p0.p0.i64(ptr %t873, ptr %l354, i64 152, i1 false)
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = load i64, ptr %l3, !tbaa !24
  %t876 = load i32, ptr %l17, !tbaa !23
  %t877 = load ptr, ptr %lp35
  %t878 = load { i64, ptr }, ptr %t877, !tbaa !27
  %t883 = call i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v4, ptr %t874, i64 %t875, i32 %t876, { i64, ptr } %t878)
  store i64 %t883, ptr %l359
  br label %bb195
bb195:
  %t884 = load i64, ptr %l359, !tbaa !24
  store i64 %t884, ptr %l37, !tbaa !24
  %t885 = load i64, ptr %l37, !tbaa !24
  %t887 = icmp sge i64 %t885, 0
  br i1 %t887, label %bb196, label %bb197
bb196:
  %t889 = load i64, ptr %l14, !tbaa !24
  %t891 = icmp slt i64 %t889, 0
  br i1 %t891, label %bb198, label %bb199
bb197:
  br label %bb211
bb198:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb202
bb199:
  %t893 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t894 = load i64, ptr %l37, !tbaa !24
  %t897 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t893, i64 %t894)
  store i64 %t897, ptr %l367
  br label %bb200
bb200:
  %t898 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t899 = load i64, ptr %l14, !tbaa !24
  %t902 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t898, i64 %t899)
  store i64 %t902, ptr %l370
  br label %bb201
bb201:
  %t903 = load i64, ptr %l367, !tbaa !24
  %t904 = load i64, ptr %l370, !tbaa !24
  %t905 = icmp ne i64 %t903, %t904
  store i1 %t905, ptr %l364, !tbaa !21
  br label %bb202
bb202:
  %t907 = load i1, ptr %l364, !tbaa !21
  br i1 %t907, label %bb203, label %bb204
bb203:
  %t908 = ptrtoint ptr %v4 to i64
  store i64 %t908, ptr %l372, !tbaa !24
  %t909 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t909, label %bb205, label %bb206
bb204:
  br label %bb210
bb205:
  %t911 = call ptr @__olang_region_make(ptr %v4)
  %t912 = ptrtoint ptr %t911 to i64
  store i64 %t912, ptr %l372, !tbaa !24
  br label %bb206
bb206:
  %t913 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t914 = load i64, ptr %l37, !tbaa !24
  %t915 = load i64, ptr %l372
  %t916 = inttoptr i64 %t915 to ptr
  %t919 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %t916, { i64, ptr } %t913, i64 %t914, i1 true)
  store { i64, ptr } %t919, ptr %l376
  br label %bb207
bb207:
  %t920 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t921 = load i64, ptr %l372
  %t922 = inttoptr i64 %t921 to ptr
  %t923 = extractvalue { i64, ptr } %t920, 0
  %t924 = extractvalue { i64, ptr } %t920, 1
  %t925 = mul i64 %t923, 1
  %t926 = call ptr @__olang_held_alloc(ptr %t922, i64 %t925)
  call void @llvm.memcpy.p0.p0.i64(ptr %t926, ptr %t924, i64 %t925, i1 false)
  %t927 = insertvalue { i64, ptr } undef, i64 %t923, 0
  %t928 = insertvalue { i64, ptr } %t927, ptr %t926, 1
  %t929 = load ptr, ptr %lp36
  %t930 = getelementptr %"compiler/doc:Entry", ptr %t929, i32 0, i32 1
  %t931 = load { i64, ptr }, ptr %t930, !tbaa !27
  store { i64, ptr } %t931, ptr %l378, !tbaa !27
  %t933 = load ptr, ptr %lp36
  %t934 = getelementptr %"compiler/doc:Entry", ptr %t933, i32 0, i32 1
  store { i64, ptr } %t928, ptr %t934, !tbaa !27
  %t935 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t935, label %bb208, label %bb209
bb208:
  %t937 = load { i64, ptr }, ptr %l378
  %t938 = extractvalue { i64, ptr } %t937, 1
  call void @__olang_region_release(ptr %t938)
  store { i64, ptr } zeroinitializer, ptr %l378
  br label %bb209
bb209:
  br label %bb210
bb210:
  %t939 = load ptr, ptr %l6, !tbaa !29
  %t941 = getelementptr %"compiler/load:Module", ptr %t939, i32 0, i32 4
  %t942 = load i64, ptr %t941, !tbaa !24
  %t944 = load ptr, ptr %lp36
  %t945 = getelementptr %"compiler/doc:Entry", ptr %t944, i32 0, i32 3
  store i64 %t942, ptr %t945, !tbaa !24
  %t946 = load i64, ptr %l37, !tbaa !24
  %t948 = load ptr, ptr %lp36
  %t949 = getelementptr %"compiler/doc:Entry", ptr %t948, i32 0, i32 4
  store i64 %t946, ptr %t949, !tbaa !24
  br label %bb211
bb211:
  %t950 = load ptr, ptr %lp16
  %t951 = getelementptr %"compiler/doc:Entry", ptr %t950, i32 0, i32 5
  %t952 = load ptr, ptr %lp36
  call void @llvm.memmove.p0.p0.i64(ptr %l384, ptr %t952, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t954, ptr %l384, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t951, ptr %t954)
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s8)
  br label %bb213
bb213:
  %t955 = load i64, ptr %l24, !tbaa !24
  %t957 = add i64 %t955, 1
  store i64 %t957, ptr %l24, !tbaa !24
  br label %bb99
bb214:
  %t959 = load ptr, ptr %lp16
  call void @llvm.memmove.p0.p0.i64(ptr %l387, ptr %t959, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l387, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t13, i64 %a1)
  store ptr %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l12, !tbaa !29
  store ptr %t18, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 6
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2d5d282533798e40_ae298936cea775c)
  unreachable
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/load:Module", ptr %t26, i32 0, i32 6
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 8
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = load ptr, ptr %lp3
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t35, { i64, ptr } %t39, { i64, ptr } %t33, { i64, ptr } %a2, ptr %t42)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %lp3
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Module"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l9, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t3)
  store { i64, ptr } %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  br label %bb3
bb3:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb6:
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l21, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/doc:Module", ptr %t47, i64 %t44
  %t49 = load %"compiler/doc:Module", ptr %t48
  store %"compiler/doc:Module" %t49, ptr %l6
  store ptr %l2, ptr %l24, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v1, ptr %s3, { i64, ptr } %t52)
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t55 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s3, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l28
  br label %bb9
bb9:
  %t59 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t59, i64 %t60)
  %t76 = getelementptr i8, ptr %t75, i64 %t60
  call void @olang_textcopy(ptr %t76, ptr %t62, i64 %t63)
  %t77 = getelementptr i8, ptr %t76, i64 %t63
  call void @olang_textcopy(ptr %t77, ptr %t65, i64 %t66)
  %t78 = getelementptr i8, ptr %t77, i64 %t66
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = getelementptr i8, ptr %t78, i64 %t70
  call void @olang_textcopy(ptr %t79, ptr %t72, i64 %t73)
  %t80 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t75, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t89, { i64, ptr } %t88)
  br label %bb10
bb10:
  %t91 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = call { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v1, ptr %s3, { i64, ptr } %t92)
  store { i64, ptr } %t94, ptr %l32
  br label %bb11
bb11:
  %t95 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t95, ptr %l7, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t96, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t98, ptr %l34
  br label %bb12
bb12:
  %t99 = load i1, ptr %l34, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l2, ptr %l36, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s3, ptr %s5, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l38
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t105 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t122, { i64, ptr } %t121)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l4, !tbaa !24
  br label %bb4
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb21
bb21:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l45, !tbaa !27
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t132, ptr %l47
  br label %bb22
bb22:
  %t133 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t142 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %s0, ptr %v2, { i64, ptr } %t140, { i64, ptr } %t139)
  store { i64, ptr } %t142, ptr %l49
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/doc:Entry"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Entry"
  %l15 = alloca %"compiler/doc:Entry"
  %l16 = alloca i32
  %l18 = alloca %"compiler/doc:Entry"
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t8 = alloca %"compiler/doc:Entry", align 8
  %t28 = alloca %"compiler/doc:Entry", align 8
  %t31 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  store i64 %t2, ptr %l8, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t14 = call i32 @compiler_2fdoc_2eEntry_2eitem(ptr %t8, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t3, ptr %a1, ptr %a2, i64 %t6, { i64, ptr } %a4, i1 true)
  store i32 %t14, ptr %l16
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb2, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t8, i64 152, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l15, i64 152, i1 false)
  br label %bb3
bb2:
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t25, 0
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb3:
  %t29 = load ptr, ptr %l7, !tbaa !29
  %t30 = load i64, ptr %l8, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %l9, i64 152, i1 false)
  call void @compiler_2fdoc_2eattached(ptr %t28, ptr %v0, ptr %v3, ptr %s0, ptr %s0, ptr %t29, i64 %t30, ptr %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t28, i64 152, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l18, i64 152, i1 false)
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l19
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t33, ptr %l6
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s0, ptr %s0, ptr %l6, ptr %l5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb6
bb6:
  %t37 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l6)
  store { i64, ptr } %t37, ptr %l23
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 10
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = add i64 %t24, 1
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t5, i64 0)
  store i64 %t7, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t13, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t23, i64 %t24)
  store i64 %t27, ptr %l21
  br label %bb10
bb10:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb15:
  %t45 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t52)
  store i1 %t54, ptr %l30
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l1, !tbaa !24
  br label %bb21
bb21:
  br label %bb6
bb22:
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  br i1 %t66, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l40, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = icmp slt i64 %t84, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t94, i64 %t95)
  store i64 %t98, ptr %l49
  br label %bb28
bb27:
  br label %bb48
bb28:
  %t99 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb31:
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = load i64, ptr %l49, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t119)
  store { i64, ptr } %t121, ptr %l55
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb35:
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t122, ptr %l4, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t125, ptr %l57
  br label %bb36
bb36:
  %t126 = load i1, ptr %l57, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t131, ptr %l61
  br label %bb39
bb38:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb40
bb39:
  %t132 = load i1, ptr %l61, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb40
bb40:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t136, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t138, ptr %l65
  br label %bb43
bb42:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb44
bb43:
  %t139 = load i1, ptr %l65, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t142 = load i1, ptr %l63, !tbaa !21
  br i1 %t142, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t143, ptr %l68, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l69, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l70, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l69, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t159 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t159, ptr %l71
  br label %bb49
bb49:
  %t160 = load %"std/prelude/text:StringBuilder", ptr %l71
  store %"std/prelude/text:StringBuilder" %t160, ptr %l5
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %l6, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb52:
  br label %bb53
bb53:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t171, i64 %t172)
  store i64 %t175, ptr %l79
  br label %bb54
bb54:
  %t176 = load i64, ptr %l79, !tbaa !24
  store i64 %t176, ptr %l7, !tbaa !24
  %t177 = load i64, ptr %l6, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = icmp sgt i64 %t177, %t178
  br i1 %t181, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 10)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  store ptr %l5, ptr %l84, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l85, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  store i64 %t185, ptr %l86, !tbaa !24
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l87, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l88, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb59, label %bb60
bb59:
  %t192 = load i64, ptr %l86, !tbaa !24
  %t193 = load i64, ptr %l87, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb61:
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = load i64, ptr %l88, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb63:
  %t200 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l86, !tbaa !24
  %t203 = load i64, ptr %l87, !tbaa !24
  %t204 = getelementptr i8, ptr %t201, i64 %t202
  %t205 = sub i64 %t203, %t202
  %t206 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t204, 1
  %t209 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l93
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb65:
  %t210 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t217, { i64, ptr } %t216)
  br label %bb66
bb66:
  %t219 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb67:
  br label %bb50
bb68:
  %t224 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t224, ptr %l98
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t225 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t225, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"compiler/names:Entry"
  %lp21 = alloca ptr
  %l22 = alloca i64
  %lp23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %lp31 = alloca ptr
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %lp34 = alloca ptr
  %lp35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"compiler/doc:Module"
  %l82 = alloca ptr
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l119 = alloca i64
  %l121 = alloca i64
  %l126 = alloca i64
  %l130 = alloca %"compiler/names:Entry"
  %l133 = alloca { i64, ptr }
  %l137 = alloca i1
  %l139 = alloca i1
  %l142 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca i1
  %l152 = alloca i64
  %l155 = alloca i1
  %l159 = alloca ptr
  %l167 = alloca i1
  %l171 = alloca %"compiler/doc:Entry"
  %l178 = alloca %"compiler/doc:Entry"
  %l179 = alloca i32
  %l181 = alloca i1
  %l183 = alloca %"compiler/doc:Entry"
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l218 = alloca ptr
  %l220 = alloca i1
  %l221 = alloca i1
  %l225 = alloca i64
  %l228 = alloca i1
  %l231 = alloca i32
  %l236 = alloca { i64, ptr }
  %l240 = alloca i1
  %l242 = alloca i1
  %l244 = alloca i64
  %l246 = alloca i64
  %l251 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i64
  %l261 = alloca { i64, ptr }
  %l264 = alloca %"compiler/doc:Entry"
  %l270 = alloca i64
  %l274 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l281 = alloca %"compiler/doc:Entry"
  %l285 = alloca i64
  %l288 = alloca i1
  %l295 = alloca { i64, ptr }
  %l299 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i64
  %l308 = alloca i64
  %l313 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l317 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca %"compiler/doc:Entry"
  %l332 = alloca i64
  %l336 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l343 = alloca %"compiler/doc:Entry"
  %l347 = alloca i64
  %l351 = alloca i64
  %l354 = alloca i64
  %l372 = alloca ptr
  %l373 = alloca i64
  %l374 = alloca ptr
  %l375 = alloca i64
  %l378 = alloca %"compiler/doc:Entry"
  %l380 = alloca %"compiler/doc:Entry"
  %l381 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca %"compiler/doc:Module"
  %t198 = alloca { ptr, ptr }, align 8
  %t335 = alloca %"compiler/doc:Entry", align 8
  %t355 = alloca %"compiler/doc:Entry", align 8
  %t553 = alloca %"compiler/doc:Entry", align 8
  %t628 = alloca %"compiler/doc:Entry", align 8
  %t748 = alloca %"compiler/doc:Entry", align 8
  %t823 = alloca %"compiler/doc:Entry", align 8
  %t887 = alloca %"compiler/doc:Entry", align 8
  %t890 = alloca %"compiler/doc:Entry", align 8
  %t892 = alloca %"compiler/doc:Entry", align 8
  %t895 = alloca %"compiler/doc:Entry", align 8
  %t898 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l47
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l47, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c14737b94c4967d9_488ba51a50b8fbfd)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t31 = ptrtoint ptr %v3 to i64
  store i64 %t31, ptr %l55, !tbaa !24
  %t32 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e0
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = call ptr @__olang_region_make(ptr %v3)
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l55, !tbaa !24
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = extractvalue { i64, ptr } %t39, 0
  %t43 = load i64, ptr %l55
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = call ptr @__olang_held_alloc(ptr %t44, i64 %t42)
  call void @olang_textcopy(ptr %t45, ptr %t41, i64 %t42)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = load i64, ptr %l55
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = extractvalue { i64, ptr } %t47, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_held_alloc(ptr %t50, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l60, !tbaa !27
  %t57 = ptrtoint ptr %v3 to i64
  store i64 %t57, ptr %l61, !tbaa !24
  %t58 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e1
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = call ptr @__olang_region_make(ptr %v3)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l61, !tbaa !24
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr %"compiler/load:Module", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = extractvalue { i64, ptr } %t65, 0
  %t69 = load i64, ptr %l61
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_held_alloc(ptr %t70, i64 %t68)
  call void @olang_textcopy(ptr %t71, ptr %t67, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = load i64, ptr %l61
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = extractvalue { i64, ptr } %t73, 0
  %t78 = extractvalue { i64, ptr } %t73, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_held_alloc(ptr %t76, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l66, !tbaa !27
  %t83 = ptrtoint ptr %v3 to i64
  store i64 %t83, ptr %l67, !tbaa !24
  %t84 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e2
  br i1 %t84, label %bb9, label %bb10
bb9:
  %t86 = call ptr @__olang_region_make(ptr %v3)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l67, !tbaa !24
  br label %bb10
bb10:
  %t88 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = load i64, ptr %l67
  %t90 = inttoptr i64 %t89 to ptr
  %t92 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %t90, { i64, ptr } %t88)
  store { i64, ptr } %t92, ptr %l70
  br label %bb11
bb11:
  %t93 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t94 = load i64, ptr %l67
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = extractvalue { i64, ptr } %t93, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_held_alloc(ptr %t95, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t105 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t102, { i64, ptr } %t103, { i64, ptr } %t101)
  store %"compiler/doc:Module" %t105, ptr %l72
  br label %bb12
bb12:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 80, i64 8)
  store ptr %t106, ptr %lp7
  %t107 = load %"compiler/doc:Module", ptr %l72
  %t108 = load ptr, ptr %lp7
  store %"compiler/doc:Module" %t107, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l8, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/names:Resolver", ptr %t126, i32 0, i32 1
  %t129 = load i64, ptr %l3, !tbaa !24
  %t132 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l82
  br label %bb13
bb13:
  %t133 = load ptr, ptr %l82, !tbaa !29
  store ptr %t133, ptr %l9, !tbaa !29
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l83
  br label %bb14
bb14:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t136 = load ptr, ptr %l9, !tbaa !29
  %t138 = getelementptr %"compiler/names:Table", ptr %t136, i32 0, i32 0
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l86
  br label %bb15
bb15:
  %t141 = load i64, ptr %l86, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb16, label %bb17
bb16:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb21
bb18:
  %t152 = load i64, ptr %l12, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l93, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb20
bb20:
  %t168 = load i64, ptr %l93, !tbaa !24
  store i64 %t168, ptr %l90, !tbaa !24
  br label %bb21
bb21:
  %t169 = load i64, ptr %l90, !tbaa !24
  store i64 %t169, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb22
bb22:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t186)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb22
bb28:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t197 = ptrtoint ptr %t196 to i64
  %t199 = getelementptr { ptr, ptr }, ptr %t198, i32 0, i32 0
  store ptr %t195, ptr %t199, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t201 = getelementptr { ptr, ptr }, ptr %t198, i32 0, i32 1
  store ptr %v0, ptr %t201, !tbaa !28
  %t202 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_53, 0
  %t203 = insertvalue { ptr, ptr } %t202, ptr %t198, 1
  %t206 = extractvalue { ptr, ptr } %t203, 0
  %t207 = extractvalue { ptr, ptr } %t203, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l10, ptr %t206, ptr %t207)
  br label %bb29
bb29:
  store ptr %l10, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t209 = load i64, ptr %l18, !tbaa !24
  store i64 %t209, ptr %l119, !tbaa !24
  %t210 = load ptr, ptr %l17, !tbaa !29
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t210)
  store i64 %t212, ptr %l121
  br label %bb31
bb31:
  %t213 = load i64, ptr %l119, !tbaa !24
  %t214 = load i64, ptr %l121, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb33:
  br label %bb34
bb34:
  %t219 = load ptr, ptr %l17, !tbaa !29
  %t220 = load i64, ptr %l18, !tbaa !24
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t219, i64 %t220)
  store i64 %t223, ptr %l126
  br label %bb35
bb35:
  %t224 = load i64, ptr %l126, !tbaa !24
  %t225 = load ptr, ptr %l9, !tbaa !29
  %t227 = getelementptr %"compiler/names:Table", ptr %t225, i32 0, i32 0
  %t231 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t227, i64 %t224)
  store %"compiler/names:Entry" %t231, ptr %l130
  br label %bb36
bb36:
  %t232 = load %"compiler/names:Entry", ptr %l130
  store %"compiler/names:Entry" %t232, ptr %l20
  %t233 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s7, ptr %t233, i32 %t235)
  store { i64, ptr } %t238, ptr %l133
  br label %bb37
bb37:
  %t239 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t240, i64 %t241)
  %t243 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t245, ptr %lp21
  %t247 = load ptr, ptr %lp21
  store { i64, ptr } %t244, ptr %t247, !tbaa !27
  %t248 = load i1, ptr %l4, !tbaa !21
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb38, label %bb39
bb38:
  %t252 = load ptr, ptr %lp21
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t253)
  store i1 %t255, ptr %l139
  br label %bb40
bb39:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb41
bb40:
  %t256 = load i1, ptr %l139, !tbaa !21
  %t257 = xor i1 %t256, true
  store i1 %t257, ptr %l137, !tbaa !21
  br label %bb41
bb41:
  %t259 = load i1, ptr %l137, !tbaa !21
  br i1 %t259, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb43:
  br label %bb44
bb44:
  %t260 = load ptr, ptr %lp21
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v3, ptr %s7, { i64, ptr } %t261, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t263, ptr %l142
  br label %bb45
bb45:
  %t264 = load i1, ptr %l142, !tbaa !21
  br i1 %t264, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb47:
  br label %bb48
bb48:
  %t265 = load ptr, ptr %lp21
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l144, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t269 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s7, { i64, ptr } %t266, { i64, ptr } %t268)
  store i1 %t269, ptr %l145
  br label %bb49
bb49:
  %t270 = load i1, ptr %l145, !tbaa !21
  br i1 %t270, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb51:
  br label %bb52
bb52:
  %t271 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t272 = load i32, ptr %t271, !range !{i32 0, i32 9}
  %t274 = trunc i64 3 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb53, label %bb54
bb53:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t281 = load i64, ptr %l3, !tbaa !24
  %t282 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t283 = load i32, ptr %t282, !tbaa !23
  %t287 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t280, i64 %t281, i32 %t283)
  store i64 %t287, ptr %l152
  br label %bb55
bb54:
  %t288 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t289 = load i32, ptr %t288, !range !{i32 0, i32 9}
  %t291 = trunc i64 2 to i32
  %t292 = icmp eq i32 %t289, %t291
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb63, label %bb64
bb55:
  %t296 = load i64, ptr %l152, !tbaa !24
  store i64 %t296, ptr %l22, !tbaa !24
  %t297 = load i64, ptr %l22, !tbaa !24
  %t299 = icmp slt i64 %t297, 0
  br i1 %t299, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb59
bb57:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load i64, ptr %l22, !tbaa !24
  %t308 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l159
  br label %bb58
bb58:
  %t309 = load ptr, ptr %l159, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Func", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  %t316 = xor i1 %t314, true
  store i1 %t316, ptr %l155, !tbaa !21
  br label %bb59
bb59:
  %t318 = load i1, ptr %l155, !tbaa !21
  br i1 %t318, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb61:
  br label %bb62
bb62:
  br label %bb69
bb63:
  %t319 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t320 = load i32, ptr %t319, !range !{i32 0, i32 9}
  %t322 = trunc i64 4 to i32
  %t323 = icmp eq i32 %t320, %t322
  %t325 = xor i1 %t323, true
  store i1 %t325, ptr %l167, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb65
bb65:
  %t327 = load i1, ptr %l167, !tbaa !21
  br i1 %t327, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = load i64, ptr %l3, !tbaa !24
  %t332 = load ptr, ptr %lp21
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  %t334 = load i1, ptr %l4, !tbaa !21
  %t342 = call i32 @compiler_2fdoc_2eEntry_2eitem(ptr %t335, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t328, ptr %t329, ptr %a2, i64 %t331, { i64, ptr } %t333, i1 %t334)
  store i32 %t342, ptr %l179
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb71, label %ok.344, !prof !99
ok.344:
  call void @llvm.memmove.p0.p0.i64(ptr %l178, ptr %t335, i64 152, i1 false)
  br label %bb70
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l171, ptr %l178, i64 152, i1 false)
  br label %bb73
bb71:
  %t345 = load i32, ptr %l179, !tbaa !23
  %t346 = ashr i32 %t345, 16
  %t348 = icmp eq i32 %t346, 1
  store i1 %t348, ptr %l181, !tbaa !21
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb73:
  %t349 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t349, ptr %lp23
  %t350 = load ptr, ptr %lp23
  call void @llvm.memmove.p0.p0.i64(ptr %t350, ptr %l171, i64 152, i1 false)
  %t351 = load ptr, ptr %lp7
  %t352 = getelementptr %"compiler/doc:Module", ptr %t351, i32 0, i32 3
  %t353 = load ptr, ptr %lp23
  call void @llvm.memmove.p0.p0.i64(ptr %l183, ptr %t353, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t355, ptr %l183, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t352, ptr %t355)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb75:
  %t356 = load i64, ptr %l18, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l18, !tbaa !24
  br label %bb30
bb76:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t363)
  br label %bb77
bb77:
  store i64 0, ptr %l24, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/check:Checker", ptr %t365, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t368)
  store i64 %t370, ptr %l190
  br label %bb78
bb78:
  %t371 = load i64, ptr %l190, !tbaa !24
  store i64 %t371, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t372 = load i64, ptr %l25, !tbaa !24
  %t373 = load i64, ptr %l24, !tbaa !24
  %t376 = icmp sgt i64 %t372, %t373
  br i1 %t376, label %bb79, label %bb80
bb79:
  %t378 = load i64, ptr %l26, !tbaa !24
  %t380 = icmp sgt i64 %t378, 0
  br i1 %t380, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb84
bb81:
  %t382 = load i64, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l24, !tbaa !24
  %t386 = sub i64 %t382, %t383
  %t387 = load i64, ptr %l26, !tbaa !24
  %t390 = add i64 %t386, %t387
  %t392 = sub i64 %t390, 1
  %t393 = load i64, ptr %l26, !tbaa !24
  %t396 = sdiv i64 %t392, %t393
  store i64 %t396, ptr %l197, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb83
bb83:
  %t398 = load i64, ptr %l197, !tbaa !24
  store i64 %t398, ptr %l194, !tbaa !24
  br label %bb84
bb84:
  %t399 = load i64, ptr %l194, !tbaa !24
  store i64 %t399, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s19
  %t400 = load i64, ptr %l28, !tbaa !24
  %t401 = load i64, ptr %l27, !tbaa !24
  %t404 = icmp slt i64 %t400, %t401
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s19)
  br label %bb160
bb87:
  br label %bb88
bb88:
  %t408 = load i64, ptr %l24, !tbaa !24
  %t409 = load i64, ptr %l28, !tbaa !24
  %t410 = load i64, ptr %l26, !tbaa !24
  %t413 = mul i64 %t409, %t410
  %t416 = add i64 %t408, %t413
  store i64 %t416, ptr %l29, !tbaa !24
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t422 = load i64, ptr %l29, !tbaa !24
  %t425 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t421, i64 %t422)
  store ptr %t425, ptr %l218
  br label %bb89
bb89:
  %t426 = load ptr, ptr %l218, !tbaa !29
  store ptr %t426, ptr %l30, !tbaa !29
  %t427 = load ptr, ptr %l30, !tbaa !29
  %t429 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t427)
  store i1 %t429, ptr %l220
  br label %bb90
bb90:
  %t430 = load i1, ptr %l220, !tbaa !21
  br i1 %t430, label %bb91, label %bb92
bb91:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load i64, ptr %l29, !tbaa !24
  %t438 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t434, i64 %t435)
  store i64 %t438, ptr %l225
  br label %bb93
bb92:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb94
bb93:
  %t439 = load i64, ptr %l3, !tbaa !24
  %t440 = load i64, ptr %l225, !tbaa !24
  %t442 = icmp eq i64 %t440, %t439
  store i1 %t442, ptr %l221, !tbaa !21
  br label %bb94
bb94:
  %t444 = load i1, ptr %l221, !tbaa !21
  br i1 %t444, label %bb95, label %bb96
bb95:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load i64, ptr %l29, !tbaa !24
  %t449 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t445, i64 %t446)
  store i32 %t449, ptr %l231
  br label %bb97
bb96:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb98
bb97:
  %t450 = load i32, ptr %l231, !tbaa !23
  %t451 = icmp slt i32 %t450, 0
  store i1 %t451, ptr %l228, !tbaa !21
  br label %bb98
bb98:
  %t453 = load i1, ptr %l228, !tbaa !21
  br i1 %t453, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s20
  %t454 = load ptr, ptr %l8, !tbaa !29
  %t455 = load ptr, ptr %l30, !tbaa !29
  %t457 = getelementptr %"compiler/ast:Func", ptr %t455, i32 0, i32 10
  %t458 = load i32, ptr %t457, !tbaa !23
  %t461 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s20, ptr %t454, i32 %t458)
  store { i64, ptr } %t461, ptr %l236
  br label %bb101
bb100:
  br label %bb125
bb101:
  %t462 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t462, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t463, i64 %t464)
  %t466 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t468 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t468, ptr %lp31
  %t470 = load ptr, ptr %lp31
  store { i64, ptr } %t467, ptr %t470, !tbaa !27
  %t471 = load i1, ptr %l4, !tbaa !21
  %t473 = xor i1 %t471, true
  br i1 %t473, label %bb102, label %bb103
bb102:
  %t475 = load ptr, ptr %lp31
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  %t478 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t476)
  store i1 %t478, ptr %l242
  br label %bb104
bb103:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb105
bb104:
  %t479 = load i1, ptr %l242, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l240, !tbaa !21
  br label %bb105
bb105:
  %t482 = load i1, ptr %l240, !tbaa !21
  br i1 %t482, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb107:
  br label %bb108
bb108:
  %t483 = ptrtoint ptr %v3 to i64
  store i64 %t483, ptr %l244, !tbaa !24
  %t484 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t484, label %bb109, label %bb110
bb109:
  %t486 = call ptr @__olang_region_make(ptr %v3)
  %t487 = ptrtoint ptr %t486 to i64
  store i64 %t487, ptr %l244, !tbaa !24
  br label %bb110
bb110:
  %t488 = ptrtoint ptr %s20 to i64
  store i64 %t488, ptr %l246, !tbaa !24
  %t489 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t489, label %bb111, label %bb112
bb111:
  %t491 = call ptr @__olang_region_make(ptr %s20)
  %t492 = ptrtoint ptr %t491 to i64
  store i64 %t492, ptr %l246, !tbaa !24
  br label %bb112
bb112:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t495 = load i64, ptr %l29, !tbaa !24
  %t496 = load i64, ptr %l246
  %t497 = inttoptr i64 %t496 to ptr
  %t501 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %t497, ptr %t493, ptr %t494, i64 %t495)
  store { i64, ptr } %t501, ptr %l251
  br label %bb113
bb113:
  %t502 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t503 = load i64, ptr %l246
  %t504 = inttoptr i64 %t503 to ptr
  %t505 = extractvalue { i64, ptr } %t502, 0
  %t506 = extractvalue { i64, ptr } %t502, 1
  %t507 = mul i64 %t505, 1
  %t508 = call ptr @__olang_held_alloc(ptr %t504, i64 %t507)
  call void @llvm.memcpy.p0.p0.i64(ptr %t508, ptr %t506, i64 %t507, i1 false)
  %t509 = insertvalue { i64, ptr } undef, i64 %t505, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  %t511 = load i64, ptr %l244
  %t512 = inttoptr i64 %t511 to ptr
  %t514 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s20, ptr %t512, { i64, ptr } %t510)
  store { i64, ptr } %t514, ptr %l253
  br label %bb114
bb114:
  %t515 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t516 = load i64, ptr %l244
  %t517 = inttoptr i64 %t516 to ptr
  %t518 = extractvalue { i64, ptr } %t515, 0
  %t519 = extractvalue { i64, ptr } %t515, 1
  %t520 = mul i64 %t518, 1
  %t521 = call ptr @__olang_held_alloc(ptr %t517, i64 %t520)
  call void @llvm.memcpy.p0.p0.i64(ptr %t521, ptr %t519, i64 %t520, i1 false)
  %t522 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  store { i64, ptr } %t523, ptr %l254, !tbaa !27
  %t524 = ptrtoint ptr %v3 to i64
  store i64 %t524, ptr %l255, !tbaa !24
  %t525 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t525, label %bb115, label %bb116
bb115:
  %t527 = call ptr @__olang_region_make(ptr %v3)
  %t528 = ptrtoint ptr %t527 to i64
  store i64 %t528, ptr %l255, !tbaa !24
  br label %bb116
bb116:
  %t529 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t530 = load ptr, ptr %l30, !tbaa !29
  %t532 = getelementptr %"compiler/ast:Func", ptr %t530, i32 0, i32 0
  %t533 = getelementptr %"compiler/source:Span", ptr %t532, i32 0, i32 0
  %t534 = load i32, ptr %t533, !tbaa !23
  %t536 = sext i32 %t534 to i64
  %t537 = load i64, ptr %l255
  %t538 = inttoptr i64 %t537 to ptr
  %t541 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t538, { i64, ptr } %t529, i64 %t536)
  store { i64, ptr } %t541, ptr %l261
  br label %bb117
bb117:
  %t542 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t543 = load i64, ptr %l255
  %t544 = inttoptr i64 %t543 to ptr
  %t545 = extractvalue { i64, ptr } %t542, 0
  %t546 = extractvalue { i64, ptr } %t542, 1
  %t547 = mul i64 %t545, 1
  %t548 = call ptr @__olang_held_alloc(ptr %t544, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  %t551 = load ptr, ptr %lp31
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !27
  %t554 = load { i64, ptr }, ptr %l254, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t553, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t554, { i64, ptr } %t550, { i64, ptr } %t552)
  call void @llvm.memmove.p0.p0.i64(ptr %l264, ptr %t553, i64 152, i1 false)
  br label %bb118
bb118:
  %t557 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t557, ptr %lp32
  %t558 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %t558, ptr %l264, i64 152, i1 false)
  %t559 = load ptr, ptr %l5, !tbaa !29
  %t561 = getelementptr %"compiler/load:Module", ptr %t559, i32 0, i32 4
  %t562 = load i64, ptr %t561, !tbaa !24
  %t564 = load ptr, ptr %lp32
  %t565 = getelementptr %"compiler/doc:Entry", ptr %t564, i32 0, i32 3
  store i64 %t562, ptr %t565, !tbaa !24
  %t566 = load ptr, ptr %l30, !tbaa !29
  %t568 = getelementptr %"compiler/ast:Func", ptr %t566, i32 0, i32 0
  %t569 = getelementptr %"compiler/source:Span", ptr %t568, i32 0, i32 0
  %t570 = load i32, ptr %t569, !tbaa !23
  %t572 = sext i32 %t570 to i64
  %t574 = load ptr, ptr %lp32
  %t575 = getelementptr %"compiler/doc:Entry", ptr %t574, i32 0, i32 4
  store i64 %t572, ptr %t575, !tbaa !24
  %t576 = ptrtoint ptr %v3 to i64
  store i64 %t576, ptr %l270, !tbaa !24
  %t577 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t577, label %bb119, label %bb120
bb119:
  %t579 = call ptr @__olang_region_make(ptr %v3)
  %t580 = ptrtoint ptr %t579 to i64
  store i64 %t580, ptr %l270, !tbaa !24
  br label %bb120
bb120:
  %t581 = load ptr, ptr %l30, !tbaa !29
  %t582 = load ptr, ptr %l8, !tbaa !29
  %t585 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s20, ptr %t581, ptr %t582)
  store { i64, ptr } %t585, ptr %l274
  br label %bb121
bb121:
  %t586 = load ptr, ptr %lp31
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t593 = add i64 %t590, %t592
  %t595 = extractvalue { i64, ptr } %t587, 1
  %t596 = extractvalue { i64, ptr } %t587, 0
  %t597 = add i64 %t593, %t596
  %t598 = load i64, ptr %l270
  %t599 = inttoptr i64 %t598 to ptr
  %t600 = call ptr @__olang_held_alloc(ptr %t599, i64 %t597)
  call void @olang_textcopy(ptr %t600, ptr %t589, i64 %t590)
  %t601 = getelementptr i8, ptr %t600, i64 %t590
  call void @olang_textcopy(ptr %t601, ptr %t591, i64 %t592)
  %t602 = getelementptr i8, ptr %t601, i64 %t592
  call void @olang_textcopy(ptr %t602, ptr %t595, i64 %t596)
  %t603 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t600, 1
  %t606 = load i64, ptr %l270
  %t607 = inttoptr i64 %t606 to ptr
  %t608 = extractvalue { i64, ptr } %t604, 0
  %t609 = extractvalue { i64, ptr } %t604, 1
  %t610 = mul i64 %t608, 1
  %t611 = call ptr @__olang_held_alloc(ptr %t607, i64 %t610)
  call void @llvm.memcpy.p0.p0.i64(ptr %t611, ptr %t609, i64 %t610, i1 false)
  %t612 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  %t614 = load ptr, ptr %lp32
  %t615 = getelementptr %"compiler/doc:Entry", ptr %t614, i32 0, i32 8
  %t616 = load { i64, ptr }, ptr %t615, !tbaa !27
  store { i64, ptr } %t616, ptr %l278, !tbaa !27
  %t618 = load ptr, ptr %lp32
  %t619 = getelementptr %"compiler/doc:Entry", ptr %t618, i32 0, i32 8
  store { i64, ptr } %t613, ptr %t619, !tbaa !27
  %t620 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t620, label %bb122, label %bb123
bb122:
  %t622 = load { i64, ptr }, ptr %l278
  %t623 = extractvalue { i64, ptr } %t622, 1
  call void @__olang_region_release(ptr %t623)
  store { i64, ptr } zeroinitializer, ptr %l278
  br label %bb123
bb123:
  %t624 = load ptr, ptr %lp7
  %t625 = getelementptr %"compiler/doc:Module", ptr %t624, i32 0, i32 3
  %t626 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %l281, ptr %t626, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t628, ptr %l281, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t625, ptr %t628)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb125:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/check:Checker", ptr %t629, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !29
  %t633 = load i64, ptr %l29, !tbaa !24
  %t636 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t632, i64 %t633)
  store i64 %t636, ptr %l285
  br label %bb126
bb126:
  %t637 = load i64, ptr %l3, !tbaa !24
  %t638 = load i64, ptr %l285, !tbaa !24
  %t640 = icmp ne i64 %t638, %t637
  br i1 %t640, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l288, !tbaa !21
  br label %bb129
bb128:
  %t642 = load ptr, ptr %l30, !tbaa !29
  %t644 = getelementptr %"compiler/ast:Func", ptr %t642, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !29
  %t647 = icmp eq ptr %t645, null
  store i1 %t647, ptr %l288, !tbaa !21
  br label %bb129
bb129:
  %t649 = load i1, ptr %l288, !tbaa !21
  br i1 %t649, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb131:
  br label %bb132
bb132:
  %t650 = load ptr, ptr %l8, !tbaa !29
  %t651 = load ptr, ptr %l30, !tbaa !29
  %t653 = getelementptr %"compiler/ast:Func", ptr %t651, i32 0, i32 2
  %t654 = load i32, ptr %t653, !tbaa !23
  %t657 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s19, ptr %t650, i32 %t654)
  store { i64, ptr } %t657, ptr %l295
  br label %bb133
bb133:
  %t658 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t659 = extractvalue { i64, ptr } %t658, 1
  %t660 = extractvalue { i64, ptr } %t658, 0
  %t661 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t660)
  call void @olang_textcopy(ptr %t661, ptr %t659, i64 %t660)
  %t662 = insertvalue { i64, ptr } undef, i64 %t660, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t664, ptr %lp33
  %t666 = load ptr, ptr %lp33
  store { i64, ptr } %t663, ptr %t666, !tbaa !27
  %t667 = load i1, ptr %l4, !tbaa !21
  %t669 = xor i1 %t667, true
  br i1 %t669, label %bb134, label %bb135
bb134:
  %t671 = load ptr, ptr %lp33
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  %t674 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t672)
  store i1 %t674, ptr %l301
  br label %bb136
bb135:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb137
bb136:
  %t675 = load i1, ptr %l301, !tbaa !21
  %t676 = xor i1 %t675, true
  store i1 %t676, ptr %l299, !tbaa !21
  br label %bb137
bb137:
  %t678 = load i1, ptr %l299, !tbaa !21
  br i1 %t678, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb139:
  br label %bb140
bb140:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load i64, ptr %l29, !tbaa !24
  %t683 = call i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %t679, i64 %t680)
  store i64 %t683, ptr %l305
  br label %bb141
bb141:
  %t684 = load i64, ptr %l3, !tbaa !24
  %t685 = load i64, ptr %l305, !tbaa !24
  %t687 = icmp eq i64 %t685, %t684
  br i1 %t687, label %bb142, label %bb143
bb142:
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb143:
  br label %bb144
bb144:
  %t689 = ptrtoint ptr %s19 to i64
  store i64 %t689, ptr %l308, !tbaa !24
  %t690 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t690, label %bb145, label %bb146
bb145:
  %t692 = call ptr @__olang_region_make(ptr %s19)
  %t693 = ptrtoint ptr %t692 to i64
  store i64 %t693, ptr %l308, !tbaa !24
  br label %bb146
bb146:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t695 = load ptr, ptr %l1, !tbaa !29
  %t696 = load i64, ptr %l29, !tbaa !24
  %t697 = load i64, ptr %l308
  %t698 = inttoptr i64 %t697 to ptr
  %t702 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %t698, ptr %t694, ptr %t695, i64 %t696)
  store { i64, ptr } %t702, ptr %l313
  br label %bb147
bb147:
  %t703 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t704 = load i64, ptr %l308
  %t705 = inttoptr i64 %t704 to ptr
  %t706 = extractvalue { i64, ptr } %t703, 0
  %t707 = extractvalue { i64, ptr } %t703, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_held_alloc(ptr %t705, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  %t713 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s19, ptr %v3, { i64, ptr } %t711)
  store { i64, ptr } %t713, ptr %l315
  br label %bb148
bb148:
  %t714 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t714, ptr %lp34
  %t715 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t716 = load ptr, ptr %lp34
  store { i64, ptr } %t715, ptr %t716, !tbaa !27
  %t717 = load ptr, ptr %lp34
  %t718 = load { i64, ptr }, ptr %t717, !tbaa !27
  store { i64, ptr } %t718, ptr %l316, !tbaa !27
  %t719 = ptrtoint ptr %v3 to i64
  store i64 %t719, ptr %l317, !tbaa !24
  %t720 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t720, label %bb149, label %bb150
bb149:
  %t722 = call ptr @__olang_region_make(ptr %v3)
  %t723 = ptrtoint ptr %t722 to i64
  store i64 %t723, ptr %l317, !tbaa !24
  br label %bb150
bb150:
  %t724 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t725 = load ptr, ptr %l30, !tbaa !29
  %t727 = getelementptr %"compiler/ast:Func", ptr %t725, i32 0, i32 0
  %t728 = getelementptr %"compiler/source:Span", ptr %t727, i32 0, i32 0
  %t729 = load i32, ptr %t728, !tbaa !23
  %t731 = sext i32 %t729 to i64
  %t732 = load i64, ptr %l317
  %t733 = inttoptr i64 %t732 to ptr
  %t736 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t733, { i64, ptr } %t724, i64 %t731)
  store { i64, ptr } %t736, ptr %l323
  br label %bb151
bb151:
  %t737 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t738 = load i64, ptr %l317
  %t739 = inttoptr i64 %t738 to ptr
  %t740 = extractvalue { i64, ptr } %t737, 0
  %t741 = extractvalue { i64, ptr } %t737, 1
  %t742 = mul i64 %t740, 1
  %t743 = call ptr @__olang_held_alloc(ptr %t739, i64 %t742)
  call void @llvm.memcpy.p0.p0.i64(ptr %t743, ptr %t741, i64 %t742, i1 false)
  %t744 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t743, 1
  %t746 = load ptr, ptr %lp33
  %t747 = load { i64, ptr }, ptr %t746, !tbaa !27
  %t749 = load { i64, ptr }, ptr %l316, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t748, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t749, { i64, ptr } %t745, { i64, ptr } %t747)
  call void @llvm.memmove.p0.p0.i64(ptr %l326, ptr %t748, i64 152, i1 false)
  br label %bb152
bb152:
  %t752 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t752, ptr %lp35
  %t753 = load ptr, ptr %lp35
  call void @llvm.memmove.p0.p0.i64(ptr %t753, ptr %l326, i64 152, i1 false)
  %t754 = load ptr, ptr %l5, !tbaa !29
  %t756 = getelementptr %"compiler/load:Module", ptr %t754, i32 0, i32 4
  %t757 = load i64, ptr %t756, !tbaa !24
  %t759 = load ptr, ptr %lp35
  %t760 = getelementptr %"compiler/doc:Entry", ptr %t759, i32 0, i32 3
  store i64 %t757, ptr %t760, !tbaa !24
  %t761 = load ptr, ptr %l30, !tbaa !29
  %t763 = getelementptr %"compiler/ast:Func", ptr %t761, i32 0, i32 0
  %t764 = getelementptr %"compiler/source:Span", ptr %t763, i32 0, i32 0
  %t765 = load i32, ptr %t764, !tbaa !23
  %t767 = sext i32 %t765 to i64
  %t769 = load ptr, ptr %lp35
  %t770 = getelementptr %"compiler/doc:Entry", ptr %t769, i32 0, i32 4
  store i64 %t767, ptr %t770, !tbaa !24
  %t771 = ptrtoint ptr %v3 to i64
  store i64 %t771, ptr %l332, !tbaa !24
  %t772 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t772, label %bb153, label %bb154
bb153:
  %t774 = call ptr @__olang_region_make(ptr %v3)
  %t775 = ptrtoint ptr %t774 to i64
  store i64 %t775, ptr %l332, !tbaa !24
  br label %bb154
bb154:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load i64, ptr %l29, !tbaa !24
  %t780 = call { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %s19, ptr %t776, i64 %t777)
  store { i64, ptr } %t780, ptr %l336
  br label %bb155
bb155:
  %t781 = load ptr, ptr %lp33
  %t782 = load { i64, ptr }, ptr %t781, !tbaa !27
  %t783 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t784 = extractvalue { i64, ptr } %t783, 1
  %t785 = extractvalue { i64, ptr } %t783, 0
  %t786 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t787 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t788 = add i64 %t785, %t787
  %t790 = extractvalue { i64, ptr } %t782, 1
  %t791 = extractvalue { i64, ptr } %t782, 0
  %t792 = add i64 %t788, %t791
  %t793 = load i64, ptr %l332
  %t794 = inttoptr i64 %t793 to ptr
  %t795 = call ptr @__olang_held_alloc(ptr %t794, i64 %t792)
  call void @olang_textcopy(ptr %t795, ptr %t784, i64 %t785)
  %t796 = getelementptr i8, ptr %t795, i64 %t785
  call void @olang_textcopy(ptr %t796, ptr %t786, i64 %t787)
  %t797 = getelementptr i8, ptr %t796, i64 %t787
  call void @olang_textcopy(ptr %t797, ptr %t790, i64 %t791)
  %t798 = insertvalue { i64, ptr } undef, i64 %t792, 0
  %t799 = insertvalue { i64, ptr } %t798, ptr %t795, 1
  %t801 = load i64, ptr %l332
  %t802 = inttoptr i64 %t801 to ptr
  %t803 = extractvalue { i64, ptr } %t799, 0
  %t804 = extractvalue { i64, ptr } %t799, 1
  %t805 = mul i64 %t803, 1
  %t806 = call ptr @__olang_held_alloc(ptr %t802, i64 %t805)
  call void @llvm.memcpy.p0.p0.i64(ptr %t806, ptr %t804, i64 %t805, i1 false)
  %t807 = insertvalue { i64, ptr } undef, i64 %t803, 0
  %t808 = insertvalue { i64, ptr } %t807, ptr %t806, 1
  %t809 = load ptr, ptr %lp35
  %t810 = getelementptr %"compiler/doc:Entry", ptr %t809, i32 0, i32 8
  %t811 = load { i64, ptr }, ptr %t810, !tbaa !27
  store { i64, ptr } %t811, ptr %l340, !tbaa !27
  %t813 = load ptr, ptr %lp35
  %t814 = getelementptr %"compiler/doc:Entry", ptr %t813, i32 0, i32 8
  store { i64, ptr } %t808, ptr %t814, !tbaa !27
  %t815 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t815, label %bb156, label %bb157
bb156:
  %t817 = load { i64, ptr }, ptr %l340
  %t818 = extractvalue { i64, ptr } %t817, 1
  call void @__olang_region_release(ptr %t818)
  store { i64, ptr } zeroinitializer, ptr %l340
  br label %bb157
bb157:
  %t819 = load ptr, ptr %lp7
  %t820 = getelementptr %"compiler/doc:Module", ptr %t819, i32 0, i32 3
  %t821 = load ptr, ptr %lp35
  call void @llvm.memmove.p0.p0.i64(ptr %l343, ptr %t821, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t823, ptr %l343, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t820, ptr %t823)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb159:
  %t824 = load i64, ptr %l28, !tbaa !24
  %t826 = add i64 %t824, 1
  store i64 %t826, ptr %l28, !tbaa !24
  br label %bb85
bb160:
  store i64 0, ptr %l36, !tbaa !24
  %t828 = load ptr, ptr %lp7
  %t829 = getelementptr %"compiler/doc:Module", ptr %t828, i32 0, i32 3
  %t831 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %t829)
  store i64 %t831, ptr %l347
  br label %bb161
bb161:
  %t832 = load i64, ptr %l347, !tbaa !24
  store i64 %t832, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t833 = load i64, ptr %l37, !tbaa !24
  %t834 = load i64, ptr %l36, !tbaa !24
  %t837 = icmp sgt i64 %t833, %t834
  br i1 %t837, label %bb162, label %bb163
bb162:
  %t839 = load i64, ptr %l38, !tbaa !24
  %t841 = icmp sgt i64 %t839, 0
  br i1 %t841, label %bb164, label %bb165
bb163:
  store i64 0, ptr %l351, !tbaa !24
  br label %bb167
bb164:
  %t843 = load i64, ptr %l37, !tbaa !24
  %t844 = load i64, ptr %l36, !tbaa !24
  %t847 = sub i64 %t843, %t844
  %t848 = load i64, ptr %l38, !tbaa !24
  %t851 = add i64 %t847, %t848
  %t853 = sub i64 %t851, 1
  %t854 = load i64, ptr %l38, !tbaa !24
  %t857 = sdiv i64 %t853, %t854
  store i64 %t857, ptr %l354, !tbaa !24
  br label %bb166
bb165:
  store i64 0, ptr %l354, !tbaa !24
  br label %bb166
bb166:
  %t859 = load i64, ptr %l354, !tbaa !24
  store i64 %t859, ptr %l351, !tbaa !24
  br label %bb167
bb167:
  %t860 = load i64, ptr %l351, !tbaa !24
  store i64 %t860, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb168
bb168:
  store %olang.scope zeroinitializer, ptr %s31
  %t861 = load i64, ptr %l40, !tbaa !24
  %t862 = load i64, ptr %l39, !tbaa !24
  %t865 = icmp slt i64 %t861, %t862
  %t867 = xor i1 %t865, true
  br i1 %t867, label %bb169, label %bb170
bb169:
  call void @__olang_scope_close(ptr %s31)
  br label %bb177
bb170:
  br label %bb171
bb171:
  %t869 = load i64, ptr %l36, !tbaa !24
  %t870 = load i64, ptr %l40, !tbaa !24
  %t871 = load i64, ptr %l38, !tbaa !24
  %t874 = mul i64 %t870, %t871
  %t877 = add i64 %t869, %t874
  store i64 %t877, ptr %l41, !tbaa !24
  %t879 = load ptr, ptr %lp7
  %t880 = getelementptr %"compiler/doc:Module", ptr %t879, i32 0, i32 3
  store ptr %t880, ptr %l372, !tbaa !29
  %t881 = load i64, ptr %l41, !tbaa !24
  store i64 %t881, ptr %l373, !tbaa !24
  %t882 = load ptr, ptr %l0, !tbaa !29
  store ptr %t882, ptr %l374, !tbaa !29
  %t883 = load i64, ptr %l3, !tbaa !24
  store i64 %t883, ptr %l375, !tbaa !24
  %t884 = load ptr, ptr %lp7
  %t885 = getelementptr %"compiler/doc:Module", ptr %t884, i32 0, i32 3
  %t886 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t887, ptr %v3, ptr %v3, ptr %t885, i64 %t886)
  call void @llvm.memmove.p0.p0.i64(ptr %l378, ptr %t887, i64 152, i1 false)
  br label %bb172
bb172:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t890, ptr %s31, ptr %l378)
  call void @llvm.memmove.p0.p0.i64(ptr %l380, ptr %t890, i64 152, i1 false)
  br label %bb173
bb173:
  %t893 = load ptr, ptr %l374, !tbaa !29
  %t894 = load i64, ptr %l375, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t895, ptr %l380, i64 152, i1 false)
  call void @compiler_2fdoc_2eattached(ptr %t892, ptr %v0, ptr %v3, ptr %s31, ptr %v3, ptr %t893, i64 %t894, ptr %t895, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l381, ptr %t892, i64 152, i1 false)
  br label %bb174
bb174:
  %t896 = load ptr, ptr %l372, !tbaa !29
  %t897 = load i64, ptr %l373, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t898, ptr %l381, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t896, i64 %t897, ptr %t898)
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s31)
  br label %bb176
bb176:
  %t899 = load i64, ptr %l40, !tbaa !24
  %t901 = add i64 %t899, 1
  store i64 %t901, ptr %l40, !tbaa !24
  br label %bb168
bb177:
  %t903 = load ptr, ptr %lp7
  %t904 = load %"compiler/doc:Module", ptr %t903
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/doc:Module" %t904, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca i8
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 47
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i8 46, ptr %l20, !tbaa !22
  br label %bb8
bb7:
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l20, !tbaa !22
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t31, i8 %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb12
bb12:
  %t39 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t39, ptr %l26
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i8
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l34 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l51 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 64
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb57
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = icmp slt i64 %t22, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb46
bb10:
  br label %bb11
bb11:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  store i8 %t38, ptr %l4, !tbaa !22
  %t40 = load i1, ptr %l3, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load i8, ptr %l4, !tbaa !22
  %t44 = icmp eq i8 %t42, 92
  br i1 %t44, label %bb14, label %bb15
bb13:
  %t46 = load i8, ptr %l4, !tbaa !22
  %t48 = icmp eq i8 %t46, 34
  br i1 %t48, label %bb20, label %bb21
bb14:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l1, !tbaa !24
  br label %bb19
bb15:
  %t54 = load i8, ptr %l4, !tbaa !22
  %t56 = icmp eq i8 %t54, 34
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb44
bb20:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb43
bb21:
  %t58 = load i8, ptr %l4, !tbaa !22
  %t60 = icmp eq i8 %t58, 40
  br i1 %t60, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t62 = load i8, ptr %l4, !tbaa !22
  %t64 = icmp eq i8 %t62, 60
  store i1 %t64, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb42
bb26:
  %t71 = load i8, ptr %l4, !tbaa !22
  %t73 = icmp eq i8 %t71, 41
  br i1 %t73, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  %t75 = load i8, ptr %l4, !tbaa !22
  %t77 = icmp eq i8 %t75, 62
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l44, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l2, !tbaa !24
  br label %bb41
bb34:
  %t89 = load i8, ptr %l4, !tbaa !22
  %t91 = icmp eq i8 %t89, 32
  br i1 %t91, label %bb35, label %bb36
bb35:
  %t93 = load i64, ptr %l2, !tbaa !24
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l51, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb37
bb37:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t98 = load i64, ptr %l1, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb8
bb46:
  br label %bb47
bb47:
  %t102 = load i64, ptr %l1, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t108 = icmp slt i64 %t102, %t105
  br i1 %t108, label %bb48, label %bb49
bb48:
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t110, ptr %l61, !tbaa !27
  %t111 = load i64, ptr %l1, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = icmp eq i8 %t116, 32
  store i1 %t118, ptr %l60, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb50
bb50:
  %t120 = load i1, ptr %l60, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t123 = load i64, ptr %l1, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l1, !tbaa !24
  br label %bb54
bb54:
  br label %bb47
bb55:
  br label %bb56
bb56:
  br label %bb1
bb57:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l68, !tbaa !27
  %t128 = load i64, ptr %l1, !tbaa !24
  store i64 %t128, ptr %l69, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 0
  store i64 %t132, ptr %l72, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l73, !tbaa !24
  %t135 = load i64, ptr %l69, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb58, label %bb59
bb58:
  %t138 = load i64, ptr %l69, !tbaa !24
  %t139 = load i64, ptr %l72, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
bb60:
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = load i64, ptr %l73, !tbaa !24
  %t144 = icmp sle i64 %t142, %t143
  br i1 %t144, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
bb62:
  %t146 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l69, !tbaa !24
  %t149 = load i64, ptr %l72, !tbaa !24
  %t150 = getelementptr i8, ptr %t147, i64 %t148
  %t151 = sub i64 %t149, %t148
  %t152 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  store { i64, ptr } %t153, ptr %rv
  br label %ret
bb63:
  call void @__olang_check_failed(ptr @olang_loc_6644f0af63579e58_6cea556a954a7954)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l22 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i32
  %l40 = alloca ptr
  %l43 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l22
  br label %bb4
bb4:
  %t43 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l29
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l29, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l34
  br label %bb9
bb9:
  %t69 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l40, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  store ptr %t89, ptr %l43, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l2, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l48
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i32, ptr %l48, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t102, ptr %l49
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l40, !tbaa !29
  %t104 = load i32, ptr %l49, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l50
  br label %bb14
bb14:
  %t106 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb15:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load i64, ptr %l1, !tbaa !24
  %t120 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t116, i64 %t117)
  store ptr %t120, ptr %l55
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l55, !tbaa !29
  %t133 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %v1, ptr %t131, ptr %t130)
  store { i64, ptr } %t133, ptr %l60
  br label %bb17
bb17:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t134, ptr %lp3
  %t135 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t136 = load ptr, ptr %lp3
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp3
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t140, ptr %l62
  br label %bb18
bb18:
  %t141 = load i1, ptr %l62, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb19, label %bb20
bb19:
  %t144 = load ptr, ptr %lp3
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l64, !tbaa !27
  br label %bb22
bb20:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l2, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t147, i32 %t148)
  store { i64, ptr } %t151, ptr %l68
  br label %bb21
bb21:
  %t152 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t152, ptr %l64, !tbaa !27
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t1, i64 %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t7, i64 %t8)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l18, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb5:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb7:
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t38)
  store i64 %t40, ptr %l25
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb9:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb19
bb11:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l31, !tbaa !24
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = icmp sle i64 0, %t52
  br i1 %t53, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb14:
  %t55 = load i64, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb16:
  %t59 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb18:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l28, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t90, ptr %l43
  br label %bb23
bb23:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t91, ptr %l6
  store ptr %l6, ptr %l44, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t94, 0
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l50, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load i64, ptr %l46, !tbaa !24
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb26:
  %t107 = load i64, ptr %l49, !tbaa !24
  %t108 = load i64, ptr %l50, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb28:
  %t111 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = load i64, ptr %l49, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s0, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l55
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb30:
  %t121 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t127)
  br label %bb31
bb31:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = icmp slt i64 %t134, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb34:
  br label %bb35
bb35:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t144, i64 %t145)
  store i64 %t148, ptr %l66
  br label %bb36
bb36:
  %t149 = load i64, ptr %l66, !tbaa !24
  store i64 %t149, ptr %l8, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l67, !tbaa !27
  %t151 = load i64, ptr %l7, !tbaa !24
  store i64 %t151, ptr %l68, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  store i64 %t152, ptr %l69, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l70, !tbaa !24
  %t155 = load i64, ptr %l68, !tbaa !24
  %t156 = icmp sge i64 %t155, 0
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t158 = load i64, ptr %l68, !tbaa !24
  %t159 = load i64, ptr %l69, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb39:
  %t162 = load i64, ptr %l69, !tbaa !24
  %t163 = load i64, ptr %l70, !tbaa !24
  %t164 = icmp sle i64 %t162, %t163
  br i1 %t164, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb41:
  %t166 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l68, !tbaa !24
  %t169 = load i64, ptr %l69, !tbaa !24
  %t170 = getelementptr i8, ptr %t167, i64 %t168
  %t171 = sub i64 %t169, %t168
  %t172 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  store { i64, ptr } %t173, ptr %l9, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t177 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t175)
  store i1 %t177, ptr %l76
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb43:
  %t178 = load i1, ptr %l76, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb47
bb45:
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l80, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t186 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s2, { i64, ptr } %t184)
  store { i64, ptr } %t186, ptr %l82
  br label %bb46
bb46:
  %t187 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = load i64, ptr %l80, !tbaa !24
  %t191 = sub i64 %t189, %t188
  %t192 = load i64, ptr %l5, !tbaa !24
  %t195 = icmp ne i64 %t191, %t192
  store i1 %t195, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t197 = load i1, ptr %l78, !tbaa !21
  br i1 %t197, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb49:
  br label %bb50
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 10)
  br label %bb51
bb51:
  store ptr %l6, ptr %l88, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t199)
  store { i64, ptr } %t201, ptr %l90
  br label %bb52
bb52:
  %t202 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t209, { i64, ptr } %t208)
  br label %bb53
bb53:
  %t211 = load i64, ptr %l8, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  br label %bb32
bb55:
  %t216 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t216, ptr %l95
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t217 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t217, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 125
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l9, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb45
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp eq i8 %t30, 35
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp ne i8 %t48, 10
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb10
bb18:
  br label %bb44
bb19:
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l36, !tbaa !24
  %t67 = load i64, ptr %l32, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb22:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb24:
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = load i64, ptr %l35, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %t85, { i64, ptr } %t86)
  store i1 %t89, ptr %l42
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb26:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb33
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = sub i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = call i1 @compiler_2fdoc_2ewordChar(i8 %t103)
  store i1 %t105, ptr %l51
  br label %bb31
bb31:
  %t106 = load i1, ptr %l51, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l46, !tbaa !21
  store i1 %t109, ptr %l43, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l43, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = add i64 %t111, %t114
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t123 = icmp sge i64 %t117, %t120
  br i1 %t123, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb40
bb36:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb39
bb37:
  %t125 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t125, ptr %l62, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = add i64 %t126, %t129
  %t134 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  %t139 = call i1 @compiler_2fdoc_2ewordChar(i8 %t137)
  store i1 %t139, ptr %l68
  br label %bb38
bb38:
  %t140 = load i1, ptr %l68, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t143 = load i1, ptr %l61, !tbaa !21
  store i1 %t143, ptr %l53, !tbaa !21
  br label %bb40
bb40:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb41, label %bb42
bb41:
  %t145 = load i64, ptr %l3, !tbaa !24
  store i64 %t145, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t147 = load i64, ptr %l3, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l3, !tbaa !24
  br label %bb44
bb44:
  br label %bb1
bb45:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdoc_2eattached(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/doc:Entry"
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca %"compiler/doc:Entry"
  %l11 = alloca %"compiler/doc:Entry"
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/doc:Entry"
  %l51 = alloca %"compiler/doc:Entry"
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca %"compiler/doc:Entry"
  %l57 = alloca %"compiler/doc:Entry"
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/doc:Entry"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t1 = alloca %"compiler/doc:Entry", align 8
  %t147 = alloca %"compiler/doc:Entry", align 8
  %t150 = alloca %"compiler/doc:Entry", align 8
  %t158 = alloca %"compiler/doc:Entry", align 8
  %t168 = alloca %"compiler/doc:Entry", align 8
  %t171 = alloca %"compiler/doc:Entry", align 8
  %t178 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 152, i1 false)
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l2, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t1, ptr %v3, ptr %l9)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t1, i64 152, i1 false)
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t3, ptr %lp4
  %t4 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l11, i64 152, i1 false)
  %t5 = load ptr, ptr %lp4
  %t6 = getelementptr %"compiler/doc:Entry", ptr %t5, i32 0, i32 8
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s1, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t13, ptr %l15
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %lp4
  %t16 = getelementptr %"compiler/doc:Entry", ptr %t15, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  br label %bb8
bb7:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = load ptr, ptr %lp4
  %t34 = getelementptr %"compiler/doc:Entry", ptr %t33, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t32, 1
  %t38 = extractvalue { i64, ptr } %t32, 0
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t35, 1
  %t44 = extractvalue { i64, ptr } %t35, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t37, i64 %t38)
  %t47 = getelementptr i8, ptr %t46, i64 %t38
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t59 = load ptr, ptr %lp4
  %t60 = getelementptr %"compiler/doc:Entry", ptr %t59, i32 0, i32 8
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l24, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t63 = load ptr, ptr %lp4
  %t64 = getelementptr %"compiler/doc:Entry", ptr %t63, i32 0, i32 8
  store { i64, ptr } %t62, ptr %t64, !tbaa !27
  %t65 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t65, label %bb9, label %bb10
bb9:
  %t67 = load { i64, ptr }, ptr %l24
  %t68 = extractvalue { i64, ptr } %t67, 1
  call void @__olang_region_release(ptr %t68)
  store { i64, ptr } zeroinitializer, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t69 = load ptr, ptr %lp4
  %t70 = getelementptr %"compiler/doc:Entry", ptr %t69, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t73, ptr %l27
  br label %bb12
bb12:
  %t74 = load i1, ptr %l27, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = ptrtoint ptr %v3 to i64
  store i64 %t77, ptr %l29, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t78, label %bb15, label %bb16
bb14:
  br label %bb22
bb15:
  %t80 = call ptr @__olang_region_make(ptr %v3)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l29, !tbaa !24
  br label %bb16
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t84 = load ptr, ptr %lp4
  %t85 = getelementptr %"compiler/doc:Entry", ptr %t84, i32 0, i32 8
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l29
  %t88 = inttoptr i64 %t87 to ptr
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v3, ptr %t88, ptr %t82, i64 %t83, { i64, ptr } %t86)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l34
  br label %bb17
bb17:
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load i64, ptr %l29
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = call ptr @__olang_region_home(ptr %t100)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr null
  %t104 = icmp eq ptr %t103, %t96
  call void @__olang_region_settle(ptr %t96, i1 %t104)
  br label %bb19
bb19:
  %t105 = load ptr, ptr %lp4
  %t106 = getelementptr %"compiler/doc:Entry", ptr %t105, i32 0, i32 7
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l36
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t109 = load ptr, ptr %lp4
  %t110 = getelementptr %"compiler/doc:Entry", ptr %t109, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %t110
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = call ptr @__olang_region_or(ptr %t115, ptr null)
  %t117 = call ptr @__olang_region_home(ptr %t116)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  call void @__olang_region_drop(ptr %t119)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l36
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t120 = ptrtoint ptr %v3 to i64
  store i64 %t120, ptr %l38, !tbaa !24
  %t121 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t121, label %bb23, label %bb24
bb23:
  %t123 = call ptr @__olang_region_make(ptr %v3)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l38, !tbaa !24
  br label %bb24
bb24:
  %t125 = load i64, ptr %l38
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %t126, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %l40
  br label %bb25
bb25:
  %t128 = load i64, ptr %l38
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call ptr @__olang_scope_alloc_a(ptr %t129, i64 32, i64 8)
  store ptr %t130, ptr %lp5
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t132 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %t132
  %t133 = getelementptr %"compiler/doc:Entry", ptr %l2, i32 0, i32 5
  store ptr %t133, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load i64, ptr %l7, !tbaa !24
  store i64 %t135, ptr %l42, !tbaa !24
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t136)
  store i64 %t138, ptr %l44
  br label %bb27
bb27:
  %t139 = load i64, ptr %l42, !tbaa !24
  %t140 = load i64, ptr %l44, !tbaa !24
  %t141 = icmp slt i64 %t139, %t140
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb29:
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t146 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t147, ptr %v1, ptr %v1, ptr %t145, i64 %t146)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t147, i64 152, i1 false)
  br label %bb31
bb31:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t150, ptr %v1, ptr %l49)
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %t150, i64 152, i1 false)
  br label %bb32
bb32:
  %t152 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 152, i64 8)
  store ptr %t152, ptr %lp8
  %t153 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %l51, i64 152, i1 false)
  %t154 = load ptr, ptr %lp5
  store ptr %t154, ptr %l52, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l53, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  store i64 %t156, ptr %l54, !tbaa !24
  %t157 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t157, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t158, ptr %v3, ptr %l55)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t158, i64 152, i1 false)
  br label %bb33
bb33:
  %t160 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t162 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t162, ptr %l59
  br label %bb34
bb34:
  %t163 = load i1, ptr %l59, !tbaa !21
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t164 = load ptr, ptr %lp4
  %t165 = getelementptr %"compiler/doc:Entry", ptr %t164, i32 0, i32 8
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l60, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb37
bb37:
  %t169 = load ptr, ptr %l53, !tbaa !29
  %t170 = load i64, ptr %l54, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t171, ptr %l57, i64 152, i1 false)
  %t172 = load { i64, ptr }, ptr %l60, !tbaa !27
  call void @compiler_2fdoc_2eattached(ptr %t168, ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t169, i64 %t170, ptr %t171, { i64, ptr } %t172)
  call void @llvm.memmove.p0.p0.i64(ptr %l62, ptr %t168, i64 152, i1 false)
  br label %bb38
bb38:
  %t173 = load i64, ptr %l38
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = load i64, ptr %l38
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = load ptr, ptr %l52, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %l62, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %t174, ptr %t176, ptr %t177, ptr %t178)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t179 = load i64, ptr %l7, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l7, !tbaa !24
  br label %bb26
bb41:
  %t183 = load ptr, ptr %lp5
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t183
  %t185 = load ptr, ptr %lp4
  %t186 = getelementptr %"compiler/doc:Entry", ptr %t185, i32 0, i32 5
  %t187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t186
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %l66
  %t189 = load ptr, ptr %lp4
  %t190 = getelementptr %"compiler/doc:Entry", ptr %t189, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %t190
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = call ptr @__olang_region_or(ptr %t195, ptr null)
  %t197 = call ptr @__olang_region_home(ptr %t196)
  %t198 = icmp ne ptr %t197, null
  %t199 = select i1 %t198, ptr %t197, ptr null
  call void @__olang_region_drop(ptr %t199)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l66
  br label %bb43
bb43:
  %t200 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t200, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l68, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/text:LineIter"
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca %"compiler/source:Span"
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"std/prelude/text:LineIter"
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l98 = alloca %"std/prelude/text:StringBuilder"
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l107 = alloca %"std/prelude/text:LineIter"
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l113 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l22
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t37 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t35, i64 %t34)
  store i64 %t37, ptr %l25
  br label %bb5
bb5:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = sub i64 %t43, 1
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l32
  br label %bb6
bb6:
  %t53 = getelementptr %"compiler/source:Span", ptr %l32, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t59 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t57, i64 %t56)
  store i64 %t59, ptr %l35
  br label %bb7
bb7:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load i64, ptr %l2, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb10:
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = load i64, ptr %l39, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb12:
  %t77 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l37, !tbaa !24
  %t80 = load i64, ptr %l38, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s0, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l44
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb14:
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 0
  %t95 = load ptr, ptr %t94, !tbaa !39
  %t97 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t95)
  store %"compiler/source:Span" %t97, ptr %l49
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t98 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l51, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = sub i64 %t105, 1
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l57
  br label %bb19
bb19:
  %t115 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l60, !tbaa !24
  %t121 = load i64, ptr %l51, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb20, label %bb21
bb20:
  %t124 = load i64, ptr %l51, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb22:
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb24:
  %t132 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = getelementptr i8, ptr %t133, i64 %t134
  %t137 = sub i64 %t135, %t134
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb26:
  store i64 -1, ptr %l4, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l67, !tbaa !24
  %t149 = load i64, ptr %l3, !tbaa !24
  store i64 %t149, ptr %l68, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l69, !tbaa !24
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb27, label %bb28
bb27:
  %t155 = load i64, ptr %l67, !tbaa !24
  %t156 = load i64, ptr %l68, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb29:
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = load i64, ptr %l69, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb31:
  %t163 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l67, !tbaa !24
  %t166 = load i64, ptr %l68, !tbaa !24
  %t167 = getelementptr i8, ptr %t164, i64 %t165
  %t168 = sub i64 %t166, %t165
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t170)
  store %"std/prelude/text:LineIter" %t172, ptr %l74
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb33:
  %t173 = load %"std/prelude/text:LineIter", ptr %l74
  store %"std/prelude/text:LineIter" %t173, ptr %l5
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t175 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l5)
  %t176 = extractvalue { i32, { i64, ptr } } %t175, 1
  %t177 = extractvalue { i32, { i64, ptr } } %t175, 0
  store i32 %t177, ptr %l78
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb36, label %ok.179, !prof !99
ok.179:
  store { i64, ptr } %t176, ptr %l77
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t180, ptr %l75, !tbaa !27
  br label %bb38
bb36:
  %t181 = load i32, ptr %l78, !tbaa !23
  %t182 = ashr i32 %t181, 16
  %t184 = icmp eq i32 %t182, 1
  store i1 %t184, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb38:
  %t185 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t185, ptr %l6, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t188 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s5, { i64, ptr } %t186)
  store { i64, ptr } %t188, ptr %l82
  br label %bb39
bb39:
  %t189 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp eq i64 %t190, 0
  br i1 %t192, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  store i64 %t196, ptr %l86, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s5, { i64, ptr } %t197)
  store { i64, ptr } %t199, ptr %l88
  br label %bb43
bb43:
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = load i64, ptr %l86, !tbaa !24
  %t204 = sub i64 %t202, %t201
  store i64 %t204, ptr %l7, !tbaa !24
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp slt i64 %t206, 0
  br i1 %t208, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t211 = load i64, ptr %l4, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  store i1 %t214, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t216 = load i1, ptr %l93, !tbaa !21
  br i1 %t216, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l7, !tbaa !24
  store i64 %t217, ptr %l4, !tbaa !24
  br label %bb49
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  br label %bb34
bb51:
  %t219 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t219, ptr %l98
  br label %bb52
bb52:
  %t220 = load %"std/prelude/text:StringBuilder", ptr %l98
  store %"std/prelude/text:StringBuilder" %t220, ptr %l8
  store i1 true, ptr %l9, !tbaa !21
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t221, ptr %l99, !tbaa !27
  %t222 = load i64, ptr %l2, !tbaa !24
  store i64 %t222, ptr %l100, !tbaa !24
  %t223 = load i64, ptr %l3, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l102, !tbaa !24
  %t226 = load i64, ptr %l100, !tbaa !24
  %t227 = icmp sge i64 %t226, 0
  br i1 %t227, label %bb53, label %bb54
bb53:
  %t229 = load i64, ptr %l100, !tbaa !24
  %t230 = load i64, ptr %l101, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  br i1 %t231, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb55:
  %t233 = load i64, ptr %l101, !tbaa !24
  %t234 = load i64, ptr %l102, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb57:
  %t237 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l100, !tbaa !24
  %t240 = load i64, ptr %l101, !tbaa !24
  %t241 = getelementptr i8, ptr %t238, i64 %t239
  %t242 = sub i64 %t240, %t239
  %t243 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t244)
  store %"std/prelude/text:LineIter" %t246, ptr %l107
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb59:
  %t247 = load %"std/prelude/text:LineIter", ptr %l107
  store %"std/prelude/text:LineIter" %t247, ptr %l10
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t249 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l10)
  %t250 = extractvalue { i32, { i64, ptr } } %t249, 1
  %t251 = extractvalue { i32, { i64, ptr } } %t249, 0
  store i32 %t251, ptr %l111
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb62, label %ok.253, !prof !99
ok.253:
  store { i64, ptr } %t250, ptr %l110
  br label %bb61
bb61:
  %t254 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t254, ptr %l108, !tbaa !27
  br label %bb64
bb62:
  %t255 = load i32, ptr %l111, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l113, !tbaa !21
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb84
bb64:
  %t259 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t259, ptr %l11, !tbaa !27
  %t260 = load i1, ptr %l9, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb65, label %bb66
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 10)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  store i1 false, ptr %l9, !tbaa !21
  store ptr %l8, ptr %l117, !tbaa !29
  %t265 = load i64, ptr %l4, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb69, label %bb70
bb69:
  %t269 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = load i64, ptr %l4, !tbaa !24
  %t275 = icmp sge i64 %t271, %t272
  store i1 %t275, ptr %l120, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb71
bb71:
  %t277 = load i1, ptr %l120, !tbaa !21
  br i1 %t277, label %bb72, label %bb73
bb72:
  %t278 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t278, ptr %l126, !tbaa !27
  %t279 = load i64, ptr %l4, !tbaa !24
  store i64 %t279, ptr %l127, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t280, 0
  store i64 %t283, ptr %l130, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l131, !tbaa !24
  %t286 = load i64, ptr %l127, !tbaa !24
  %t287 = icmp sge i64 %t286, 0
  br i1 %t287, label %bb74, label %bb75
bb73:
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t291 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s9, { i64, ptr } %t289)
  store { i64, ptr } %t291, ptr %l137
  br label %bb80
bb74:
  %t292 = load i64, ptr %l127, !tbaa !24
  %t293 = load i64, ptr %l130, !tbaa !24
  %t294 = icmp sle i64 %t292, %t293
  br i1 %t294, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb76:
  %t296 = load i64, ptr %l130, !tbaa !24
  %t297 = load i64, ptr %l131, !tbaa !24
  %t298 = icmp sle i64 %t296, %t297
  br i1 %t298, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb78:
  %t300 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l127, !tbaa !24
  %t303 = load i64, ptr %l130, !tbaa !24
  %t304 = getelementptr i8, ptr %t301, i64 %t302
  %t305 = sub i64 %t303, %t302
  %t306 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t304, 1
  store { i64, ptr } %t307, ptr %l125, !tbaa !27
  br label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb80:
  %t309 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t309, ptr %l125, !tbaa !27
  br label %bb81
bb81:
  %t310 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = call ptr @__olang_scope_of(ptr %t311, ptr null)
  %t313 = ptrtoint ptr %t312 to i64
  %t315 = inttoptr i64 %t313 to ptr
  %t316 = load ptr, ptr %l117, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l125, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %t315, ptr %t316, { i64, ptr } %t317)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s9)
  br label %bb83
bb83:
  br label %bb60
bb84:
  %t319 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l8)
  store { i64, ptr } %t319, ptr %l140
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t320 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t320, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t8, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = icmp sge i64 1, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = icmp sle i64 1, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb5:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb7:
  %t23 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = getelementptr i8, ptr %t24, i64 1
  %t27 = sub i64 %t25, 1
  %t28 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t33, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb9:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  br label %bb19
bb12:
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb14:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb16:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s1, { i64, ptr } %t57)
  store { i64, ptr } %t59, ptr %l26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb18:
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l29
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/doc:Entry"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca %"compiler/doc:Entry"
  %l41 = alloca %"compiler/doc:Entry"
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca %"compiler/doc:Entry"
  %l70 = alloca %"compiler/doc:Entry"
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t92 = alloca %"compiler/doc:Entry", align 8
  %t95 = alloca %"compiler/doc:Entry", align 8
  %t185 = alloca %"compiler/doc:Entry", align 8
  %t188 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb3
bb3:
  store ptr %l1, ptr %l16, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/doc:Module", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t37, ptr %l19
  br label %bb4
bb4:
  %t38 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t40 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t38, i64 %t39)
  %t48 = getelementptr i8, ptr %t47, i64 %t39
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = getelementptr i8, ptr %t48, i64 %t42
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t58)
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/doc:Module", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t64)
  br label %bb6
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/doc:Module", ptr %t67, i32 0, i32 3
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l27
  br label %bb7
bb7:
  %t72 = load i64, ptr %l27, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb29
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/doc:Module", ptr %t76, i32 0, i32 3
  store ptr %t78, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l32, !tbaa !24
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l34
  br label %bb12
bb12:
  %t84 = load i64, ptr %l32, !tbaa !24
  %t85 = load i64, ptr %l34, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t92, ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t92, i64 152, i1 false)
  br label %bb16
bb16:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t95, ptr %v0, ptr %l39)
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %t95, i64 152, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l41, i64 152, i1 false)
  %t97 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v0, ptr %s5, { i64, ptr } %t98)
  store { i64, ptr } %t100, ptr %l43
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t107, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t109, ptr %l45
  br label %bb19
bb19:
  %t110 = load i1, ptr %l45, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb22
bb22:
  %t113 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t113, ptr %l5, !tbaa !27
  store ptr %l1, ptr %l48, !tbaa !29
  %t114 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t115)
  store { i64, ptr } %t117, ptr %l50
  br label %bb23
bb23:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t118, ptr %l51, !tbaa !27
  %t119 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t122 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t120)
  store { i64, ptr } %t122, ptr %l53
  br label %bb24
bb24:
  %t123 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t125 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = add i64 %t131, %t134
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t123, i64 %t124)
  %t147 = getelementptr i8, ptr %t146, i64 %t124
  call void @olang_textcopy(ptr %t147, ptr %t126, i64 %t127)
  %t148 = getelementptr i8, ptr %t147, i64 %t127
  call void @olang_textcopy(ptr %t148, ptr %t129, i64 %t130)
  %t149 = getelementptr i8, ptr %t148, i64 %t130
  call void @olang_textcopy(ptr %t149, ptr %t133, i64 %t134)
  %t150 = getelementptr i8, ptr %t149, i64 %t134
  call void @olang_textcopy(ptr %t150, ptr %t136, i64 %t137)
  %t151 = getelementptr i8, ptr %t150, i64 %t137
  call void @olang_textcopy(ptr %t151, ptr %t140, i64 %t141)
  %t152 = getelementptr i8, ptr %t151, i64 %t141
  call void @olang_textcopy(ptr %t152, ptr %t143, i64 %t144)
  %t153 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t146, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t162, { i64, ptr } %t161)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  %t164 = load i64, ptr %l3, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l3, !tbaa !24
  br label %bb11
bb27:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/doc:Module", ptr %t169, i32 0, i32 3
  store ptr %t171, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t173 = load i64, ptr %l7, !tbaa !24
  store i64 %t173, ptr %l61, !tbaa !24
  %t174 = load ptr, ptr %l6, !tbaa !29
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l63
  br label %bb31
bb31:
  %t177 = load i64, ptr %l61, !tbaa !24
  %t178 = load i64, ptr %l63, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb39
bb33:
  br label %bb34
bb34:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t184 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t185, ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t185, i64 152, i1 false)
  br label %bb35
bb35:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t188, ptr %v0, ptr %l68)
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t188, i64 152, i1 false)
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l70, i64 152, i1 false)
  call void @compiler_2fdoc_2eentryHtml(ptr %s0, ptr %s9, ptr %l1, ptr %l8, i1 false)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb38:
  %t192 = load i64, ptr %l7, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l7, !tbaa !24
  br label %bb30
bb39:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/doc:Module", ptr %t196, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l76, !tbaa !27
  %t201 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t201, ptr %l78
  br label %bb40
bb40:
  %t202 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t211 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %s0, ptr %v1, { i64, ptr } %t209, { i64, ptr } %t208)
  store { i64, ptr } %t211, ptr %l80
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/doc:Entry"
  %l30 = alloca %"compiler/doc:Entry"
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t62 = alloca %"compiler/doc:Entry", align 8
  %t65 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t10 = extractvalue { i64, ptr } %t6, 1
  %t11 = extractvalue { i64, ptr } %t6, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t27)
  br label %bb2
bb2:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/doc:Module", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t35, ptr %l13
  br label %bb3
bb3:
  %t36 = load i1, ptr %l13, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/doc:Module", ptr %t40, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  call void @compiler_2fdoc_2eindented(ptr %s0, ptr %v0, ptr %s2, ptr %l1, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/doc:Module", ptr %t46, i32 0, i32 3
  store ptr %t48, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l21, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l23
  br label %bb10
bb10:
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t62, ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t62, i64 152, i1 false)
  br label %bb14
bb14:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t65, ptr %v0, ptr %l28)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t65, i64 152, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l30, i64 152, i1 false)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb16
bb16:
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s4, ptr %s4, ptr %l1, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb9
bb19:
  %t75 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t75, ptr %l37
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca i32
  %l47 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i64
  %l66 = alloca i64
  %l70 = alloca ptr
  %l79 = alloca i32
  %l85 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l21, !tbaa !24
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb35
bb7:
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = icmp sle i64 0, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb9:
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb11:
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 0
  %t33 = sub i64 %t31, 0
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i64, ptr %l18, !tbaa !24
  %t39 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %t36, i64 %t37, { i64, ptr } %t35)
  store i32 %t39, ptr %l26
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb13:
  %t40 = load i32, ptr %l26, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp slt i32 %t41, 0
  br i1 %t43, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t60, 0
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb19:
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb21:
  %t77 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l36, !tbaa !24
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t87 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t85, { i64, ptr } %t84)
  store i32 %t87, ptr %l45
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb23:
  %t88 = load i32, ptr %l45, !tbaa !23
  store i32 %t88, ptr %l5, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr %l4, !tbaa !23
  %t100 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l51
  br label %bb24
bb24:
  %t101 = load i32, ptr %l5, !tbaa !23
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i32, ptr %l51, !tbaa !23
  %t105 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t102, i32 %t103, i32 %t101)
  store i64 %t105, ptr %l53
  br label %bb25
bb25:
  %t106 = load i64, ptr %l53, !tbaa !24
  store i64 %t106, ptr %l6, !tbaa !24
  %t107 = load i64, ptr %l6, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb26, label %bb27
bb26:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l4, !tbaa !23
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l61
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t123 = load i32, ptr %l5, !tbaa !23
  %t124 = load ptr, ptr %l57, !tbaa !29
  %t125 = load i32, ptr %l61, !tbaa !23
  %t127 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t124, i32 %t125, i32 %t123, i1 true)
  store i64 %t127, ptr %l63
  br label %bb29
bb29:
  %t128 = load i64, ptr %l63, !tbaa !24
  store i64 %t128, ptr %l6, !tbaa !24
  br label %bb30
bb30:
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  br i1 %t131, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %l66, !tbaa !24
  br label %bb34
bb32:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l70
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l70, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Func", ptr %t141, i32 0, i32 0
  %t144 = getelementptr %"compiler/source:Span", ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sext i32 %t145 to i64
  store i64 %t147, ptr %l66, !tbaa !24
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t149 = load i64, ptr %l66, !tbaa !24
  store i64 %t149, ptr %rv
  br label %ret
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t163 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t159, { i64, ptr } %t160)
  store i32 %t163, ptr %l79
  br label %bb36
bb36:
  %t164 = load i32, ptr %l79, !tbaa !23
  store i32 %t164, ptr %l7, !tbaa !23
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/names:Resolver", ptr %t171, i32 0, i32 1
  %t174 = load i64, ptr %l1, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l85
  br label %bb37
bb37:
  %t178 = load ptr, ptr %l85, !tbaa !29
  %t180 = getelementptr %"compiler/names:Table", ptr %t178, i32 0, i32 0
  store ptr %t180, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb38
bb38:
  %t182 = load i64, ptr %l9, !tbaa !24
  store i64 %t182, ptr %l88, !tbaa !24
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l90
  br label %bb39
bb39:
  %t186 = load i64, ptr %l88, !tbaa !24
  %t187 = load i64, ptr %l90, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t192 = load ptr, ptr %l8, !tbaa !29
  %t193 = load i64, ptr %l9, !tbaa !24
  %t196 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t192, i64 %t193)
  store %"compiler/names:Entry" %t196, ptr %l95
  br label %bb43
bb43:
  %t197 = load %"compiler/names:Entry", ptr %l95
  store %"compiler/names:Entry" %t197, ptr %l10
  %t198 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t200 = load i32, ptr %l7, !tbaa !23
  %t203 = icmp eq i32 %t199, %t200
  br i1 %t203, label %bb44, label %bb45
bb44:
  %t205 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 1
  %t206 = getelementptr %"compiler/source:Span", ptr %t205, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = sext i32 %t207 to i64
  call void @__olang_scope_close(ptr %s0)
  store i64 %t209, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l9, !tbaa !24
  br label %bb38
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca { ptr, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l11
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t9 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_94, 0
  %t10 = insertvalue { ptr, ptr } %t9, ptr null, 1
  store { ptr, ptr } %t10, ptr %l4
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t12)
  store %"std/prelude/text:LineIter" %t14, ptr %l14
  br label %bb7
bb7:
  %t15 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t15, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l17
  br label %bb9
bb9:
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb12
bb10:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb12:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = load { ptr, ptr }, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i1, ptr %l3, !tbaa !21
  %t36 = extractvalue { ptr, ptr } %t32, 0
  %t37 = extractvalue { ptr, ptr } %t32, 1
  call void %t36(ptr %t37, ptr %s0, ptr %v0, ptr %l2, ptr %t33, i1 %t34)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb17:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t41, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t43, ptr %l28
  br label %bb18
bb18:
  %t44 = load i1, ptr %l28, !tbaa !21
  store i1 %t44, ptr %l7, !tbaa !21
  %t46 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t46, ptr %l30
  br label %bb19
bb19:
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = icmp sgt i64 %t47, 0
  br i1 %t48, label %bb20, label %bb21
bb20:
  %t50 = load i1, ptr %l7, !tbaa !21
  %t51 = load i1, ptr %l3, !tbaa !21
  %t54 = icmp ne i1 %t50, %t51
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load { ptr, ptr }, ptr %l4
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l3, !tbaa !21
  %t61 = extractvalue { ptr, ptr } %t57, 0
  %t62 = extractvalue { ptr, ptr } %t57, 1
  call void %t61(ptr %t62, ptr %s0, ptr %v0, ptr %l2, ptr %t58, i1 %t59)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t66 = load i1, ptr %l7, !tbaa !21
  store i1 %t66, ptr %l3, !tbaa !21
  %t69 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t69, ptr %l42
  br label %bb27
bb27:
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = icmp sgt i64 %t70, 0
  br i1 %t71, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  store ptr %l2, ptr %l45, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb34, label %bb35
bb33:
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t85, ptr %l47, !tbaa !27
  br label %bb40
bb34:
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = icmp sle i64 4, %t87
  br i1 %t88, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb36:
  %t90 = load i64, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb38:
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 4
  %t98 = sub i64 %t96, 4
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb40:
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t102, { i64, ptr } %t103)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  br label %bb8
bb43:
  %t104 = load { ptr, ptr }, ptr %l4
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i1, ptr %l3, !tbaa !21
  %t108 = extractvalue { ptr, ptr } %t104, 0
  %t109 = extractvalue { ptr, ptr } %t104, 1
  call void %t108(ptr %t109, ptr %s0, ptr %v0, ptr %l2, ptr %t105, i1 %t106)
  br label %bb44
bb44:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Example"
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/doc:Entry"
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca %"compiler/doc:Example"
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca %"compiler/doc:Entry"
  %l65 = alloca %"compiler/doc:Entry"
  %l67 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t169 = alloca %"compiler/doc:Entry", align 8
  %t172 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t3, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/doc:Entry", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/doc:Entry", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v1, ptr %s0, { i64, ptr } %t13)
  store { i64, ptr } %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t24, ptr %l20
  br label %bb6
bb6:
  %t25 = load i1, ptr %l20, !tbaa !21
  %t26 = xor i1 %t25, true
  store i1 %t26, ptr %l4, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l24
  br label %bb7
bb7:
  %t32 = load i1, ptr %l4, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/doc:Entry", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t37)
  store { i64, ptr } %t39, ptr %l29
  br label %bb11
bb11:
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t40, i64 %t41)
  %t64 = getelementptr i8, ptr %t63, i64 %t41
  call void @olang_textcopy(ptr %t64, ptr %t43, i64 %t44)
  %t65 = getelementptr i8, ptr %t64, i64 %t44
  call void @olang_textcopy(ptr %t65, ptr %t46, i64 %t47)
  %t66 = getelementptr i8, ptr %t65, i64 %t47
  call void @olang_textcopy(ptr %t66, ptr %t50, i64 %t51)
  %t67 = getelementptr i8, ptr %t66, i64 %t51
  call void @olang_textcopy(ptr %t67, ptr %t53, i64 %t54)
  %t68 = getelementptr i8, ptr %t67, i64 %t54
  call void @olang_textcopy(ptr %t68, ptr %t57, i64 %t58)
  %t69 = getelementptr i8, ptr %t68, i64 %t58
  call void @olang_textcopy(ptr %t69, ptr %t60, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t63, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t79, { i64, ptr } %t78)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/doc:Entry", ptr %t82, i32 0, i32 1
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %t81, { i64, ptr } %t85)
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/doc:Entry", ptr %t88, i32 0, i32 7
  store ptr %t90, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t92 = load i64, ptr %l6, !tbaa !24
  store i64 %t92, ptr %l37, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t93)
  store i64 %t95, ptr %l39
  br label %bb15
bb15:
  %t96 = load i64, ptr %l37, !tbaa !24
  %t97 = load i64, ptr %l39, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t102, i64 %t103)
  store %"compiler/doc:Example" %t106, ptr %l44
  br label %bb19
bb19:
  %t107 = load %"compiler/doc:Example", ptr %l44
  store %"compiler/doc:Example" %t107, ptr %l7
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l45, !tbaa !29
  %t109 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t110)
  store { i64, ptr } %t112, ptr %l47
  br label %bb20
bb20:
  %t113 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l49
  br label %bb21
bb21:
  %t117 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t119 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t117, i64 %t118)
  %t134 = getelementptr i8, ptr %t133, i64 %t118
  call void @olang_textcopy(ptr %t134, ptr %t120, i64 %t121)
  %t135 = getelementptr i8, ptr %t134, i64 %t121
  call void @olang_textcopy(ptr %t135, ptr %t123, i64 %t124)
  %t136 = getelementptr i8, ptr %t135, i64 %t124
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = getelementptr i8, ptr %t136, i64 %t128
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t147 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t147, { i64, ptr } %t146)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l6, !tbaa !24
  br label %bb14
bb24:
  store i1 false, ptr %l8, !tbaa !21
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/doc:Entry", ptr %t153, i32 0, i32 5
  store ptr %t155, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t157 = load i64, ptr %l10, !tbaa !24
  store i64 %t157, ptr %l56, !tbaa !24
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t158)
  store i64 %t160, ptr %l58
  br label %bb26
bb26:
  %t161 = load i64, ptr %l56, !tbaa !24
  %t162 = load i64, ptr %l58, !tbaa !24
  %t163 = icmp slt i64 %t161, %t162
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb28:
  br label %bb29
bb29:
  %t167 = load ptr, ptr %l9, !tbaa !29
  %t168 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t169, ptr %v1, ptr %v1, ptr %t167, i64 %t168)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t169, i64 152, i1 false)
  br label %bb30
bb30:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t172, ptr %v1, ptr %l63)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t172, i64 152, i1 false)
  br label %bb31
bb31:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l65, i64 152, i1 false)
  %t174 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t175 = load i1, ptr %t174, !tbaa !21
  br i1 %t175, label %bb32, label %bb33
bb32:
  %t177 = load i1, ptr %l8, !tbaa !21
  %t179 = xor i1 %t177, true
  store i1 %t179, ptr %l67, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb34
bb34:
  %t181 = load i1, ptr %l67, !tbaa !21
  br i1 %t181, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t182, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb38:
  %t184 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t185 = load i1, ptr %t184, !tbaa !21
  store i1 %t185, ptr %l8, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %s8, ptr %t187, ptr %l11, i1 true)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb40:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l10, !tbaa !24
  br label %bb25
bb41:
  %t194 = load i1, ptr %l2, !tbaa !21
  br i1 %t194, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t196 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t196, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Example"
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/doc:Entry"
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:LineIter"
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca %"compiler/doc:Example"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/doc:Entry"
  %l81 = alloca %"compiler/doc:Entry"
  %l83 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t206 = alloca %"compiler/doc:Entry", align 8
  %t209 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/doc:Entry", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = mul i64 %t8, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t9, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t15, ptr %l18
  br label %bb2
bb2:
  %t16 = load i1, ptr %l18, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/doc:Entry", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t23)
  store %"std/prelude/text:LineIter" %t25, ptr %l23
  br label %bb6
bb6:
  %t26 = load %"std/prelude/text:LineIter", ptr %l23
  store %"std/prelude/text:LineIter" %t26, ptr %l5
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l27
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb9, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l26
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  br label %bb11
bb9:
  %t34 = load i32, ptr %l27, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb11:
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l30, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l31, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t42 = load i1, ptr %l4, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l34, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l34, !tbaa !27
  br label %bb14
bb14:
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t47, i64 %t48)
  %t61 = getelementptr i8, ptr %t60, i64 %t48
  call void @olang_textcopy(ptr %t61, ptr %t50, i64 %t51)
  %t62 = getelementptr i8, ptr %t61, i64 %t51
  call void @olang_textcopy(ptr %t62, ptr %t54, i64 %t55)
  %t63 = getelementptr i8, ptr %t62, i64 %t55
  call void @olang_textcopy(ptr %t63, ptr %t57, i64 %t58)
  %t64 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t60, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t73, { i64, ptr } %t72)
  br label %bb15
bb15:
  store i1 false, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb7
bb17:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/doc:Entry", ptr %t75, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store i1 %t80, ptr %l40
  br label %bb18
bb18:
  %t81 = load i1, ptr %l40, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/doc:Entry", ptr %t85, i32 0, i32 1
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = getelementptr i8, ptr %t96, i64 %t92
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s4, ptr %t84, { i64, ptr } %t88, { i64, ptr } %t106)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/doc:Entry", ptr %t110, i32 0, i32 7
  store ptr %t112, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t114 = load i64, ptr %l8, !tbaa !24
  store i64 %t114, ptr %l50, !tbaa !24
  %t115 = load ptr, ptr %l7, !tbaa !29
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t115)
  store i64 %t117, ptr %l52
  br label %bb24
bb24:
  %t118 = load i64, ptr %l50, !tbaa !24
  %t119 = load i64, ptr %l52, !tbaa !24
  %t120 = icmp slt i64 %t118, %t119
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb26:
  br label %bb27
bb27:
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t124, i64 %t125)
  store %"compiler/doc:Example" %t128, ptr %l57
  br label %bb28
bb28:
  %t129 = load %"compiler/doc:Example", ptr %l57
  store %"compiler/doc:Example" %t129, ptr %l9
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = getelementptr %"compiler/doc:Example", ptr %l9, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t131, 1
  %t136 = extractvalue { i64, ptr } %t131, 0
  %t137 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t141 = extractvalue { i64, ptr } %t133, 1
  %t142 = extractvalue { i64, ptr } %t133, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t137, i64 %t138)
  %t149 = getelementptr i8, ptr %t148, i64 %t138
  call void @olang_textcopy(ptr %t149, ptr %t141, i64 %t142)
  %t150 = getelementptr i8, ptr %t149, i64 %t142
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t147, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t130, { i64, ptr } %t159)
  br label %bb29
bb29:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/doc:Example", ptr %l9, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t167, i64 %t168)
  %t173 = getelementptr i8, ptr %t172, i64 %t168
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s7, ptr %t162, { i64, ptr } %t164, { i64, ptr } %t182)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t186 = load i64, ptr %l8, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l8, !tbaa !24
  br label %bb23
bb32:
  store i1 false, ptr %l10, !tbaa !21
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr %"compiler/doc:Entry", ptr %t190, i32 0, i32 5
  store ptr %t192, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s12
  %t194 = load i64, ptr %l12, !tbaa !24
  store i64 %t194, ptr %l72, !tbaa !24
  %t195 = load ptr, ptr %l11, !tbaa !29
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t195)
  store i64 %t197, ptr %l74
  br label %bb34
bb34:
  %t198 = load i64, ptr %l72, !tbaa !24
  %t199 = load i64, ptr %l74, !tbaa !24
  %t200 = icmp slt i64 %t198, %t199
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb36:
  br label %bb37
bb37:
  %t204 = load ptr, ptr %l11, !tbaa !29
  %t205 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t206, ptr %v1, ptr %v1, ptr %t204, i64 %t205)
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t206, i64 152, i1 false)
  br label %bb38
bb38:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t209, ptr %v1, ptr %l79)
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %t209, i64 152, i1 false)
  br label %bb39
bb39:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l81, i64 152, i1 false)
  %t211 = getelementptr %"compiler/doc:Entry", ptr %l13, i32 0, i32 6
  %t212 = load i1, ptr %t211, !tbaa !21
  br i1 %t212, label %bb40, label %bb41
bb40:
  %t214 = load i1, ptr %l10, !tbaa !21
  %t216 = xor i1 %t214, true
  store i1 %t216, ptr %l83, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb42
bb42:
  %t218 = load i1, ptr %l83, !tbaa !21
  br i1 %t218, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s13
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = extractvalue { i64, ptr } %t220, 0
  %t224 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = getelementptr i8, ptr %t227, i64 %t223
  call void @olang_textcopy(ptr %t228, ptr %t224, i64 %t225)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = extractvalue { i64, ptr } %t230, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t219, { i64, ptr } %t237)
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb46:
  %t240 = getelementptr %"compiler/doc:Entry", ptr %l13, i32 0, i32 6
  %t241 = load i1, ptr %t240, !tbaa !21
  store i1 %t241, ptr %l10, !tbaa !21
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = extractvalue { i64, ptr } %t244, 0
  %t248 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t246, i64 %t247)
  %t252 = getelementptr i8, ptr %t251, i64 %t247
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  call void @compiler_2fdoc_2eentryText(ptr %v0, ptr %s12, ptr %s12, ptr %t243, ptr %l13, { i64, ptr } %t261)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l12, !tbaa !24
  br label %bb33
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/doc:Example"
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca ptr
  %l76 = alloca ptr
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb50
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l8, !tbaa !29
  %t23 = load ptr, ptr %l8, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 6
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l8, !tbaa !29
  %t34 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35
  store { i64, ptr } %t36, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  br label %bb23
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v1, ptr %v0, ptr %s3, ptr %t38, ptr %t48)
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %v3, { i64, ptr } %t58, { i64, ptr } %t59)
  store i1 %t62, ptr %l35
  br label %bb11
bb11:
  %t63 = load i1, ptr %l35, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l4, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = ptrtoint ptr %v4 to i64
  store i64 %t67, ptr %l38, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aExample_2e0
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = call ptr @__olang_region_make(ptr %v4)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l38, !tbaa !24
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l8, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t74 = load i64, ptr %l38
  %t75 = inttoptr i64 %t74 to ptr
  %t78 = call { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v1, ptr %v2, ptr %t75, ptr %t72, { i64, ptr } %t73)
  store { i64, ptr } %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t80 = load i64, ptr %l38
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = extractvalue { i64, ptr } %t79, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_held_alloc(ptr %t81, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l43, !tbaa !27
  %t88 = ptrtoint ptr %v4 to i64
  store i64 %t88, ptr %l44, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aExample_2e1
  br i1 %t89, label %bb18, label %bb19
bb18:
  %t91 = call ptr @__olang_region_make(ptr %v4)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t95 = load i64, ptr %l44
  %t96 = inttoptr i64 %t95 to ptr
  %t99 = call { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v2, ptr %v1, ptr %t96, { i64, ptr } %t93, { i64, ptr } %t94)
  store { i64, ptr } %t99, ptr %l48
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t101 = load i64, ptr %l44
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = extractvalue { i64, ptr } %t100, 0
  %t104 = extractvalue { i64, ptr } %t100, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_held_alloc(ptr %t102, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t111 = call %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t109, { i64, ptr } %t108)
  store %"compiler/doc:Example" %t111, ptr %l50
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l37, !tbaa !29
  %t113 = load %"compiler/doc:Example", ptr %l50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v4, ptr %v4, ptr %t112, %"compiler/doc:Example" %t113)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb23:
  %t114 = load ptr, ptr %l8, !tbaa !29
  store ptr %t114, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t115 = load ptr, ptr %l51, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb24, label %bb25
bb24:
  %t118 = load ptr, ptr %l51, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 11}
  %t121 = icmp eq i64 %t119, 7
  store i1 %t121, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t122 = load i1, ptr %l52, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = getelementptr { i64, [8 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb28
bb27:
  br label %bb43
bb28:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:TopIf", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l61, !tbaa !29
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t141 = getelementptr %"compiler/ast:TopIf", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb31, label %bb32
bb30:
  br label %bb35
bb31:
  call void @__olang_check_failed(ptr @olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e)
  unreachable
bb32:
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t148 = getelementptr %"compiler/ast:TopIf", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TopBranch", ptr %t149, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t157, { i64, ptr } %t153, { i64, ptr } %t154, { i64, ptr } %t155, ptr %t156)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t162 = load ptr, ptr %l10, !tbaa !29
  %t164 = getelementptr %"compiler/ast:TopIf", ptr %t162, i32 0, i32 3
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb36, label %bb37
bb36:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l76, !tbaa !29
  %t172 = load ptr, ptr %l10, !tbaa !29
  %t174 = getelementptr %"compiler/ast:TopIf", ptr %t172, i32 0, i32 3
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = icmp eq ptr %t175, null
  br i1 %t177, label %bb38, label %bb39
bb37:
  br label %bb42
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5be1599e6a61f501_71a8850ae192da35)
  unreachable
bb39:
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t181 = getelementptr %"compiler/ast:TopIf", ptr %t179, i32 0, i32 3
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t185 = getelementptr %"compiler/ast:TopBranch", ptr %t182, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load ptr, ptr %l4, !tbaa !29
  %t190 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t190, { i64, ptr } %t186, { i64, ptr } %t187, { i64, ptr } %t188, ptr %t189)
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_fe551cd114f4cb63_729eb01933a49f67)
  unreachable
bb48:
  br label %bb49
bb49:
  %t195 = load i64, ptr %l6, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l6, !tbaa !24
  br label %bb1
bb50:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i64
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i64
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l9
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb7:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb8
bb8:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t25, ptr %l17
  br label %bb11
bb11:
  %t26 = load i1, ptr %l17, !tbaa !21
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t29 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t29, ptr %l19
  br label %bb16
bb16:
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t35, ptr %l23
  br label %bb19
bb18:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb20
bb19:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb20
bb20:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb21, label %bb22
bb21:
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t40, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t42, ptr %l27
  br label %bb23
bb22:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb24
bb23:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb24
bb24:
  %t46 = load i1, ptr %l25, !tbaa !21
  br i1 %t46, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb26:
  br label %bb27
bb27:
  %t48 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t48, ptr %l30
  br label %bb28
bb28:
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = icmp sgt i64 %t49, 0
  br i1 %t50, label %bb29, label %bb30
bb29:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t53)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  br label %bb3
bb35:
  %t57 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t57, ptr %l36
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l11
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t21, ptr %l16
  br label %bb8
bb8:
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t24 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t24, ptr %l18
  br label %bb12
bb12:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp sgt i64 %t25, 0
  br i1 %t26, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l21, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l23
  br label %bb17
bb17:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t32, { i64, ptr } %t33)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb3
bb20:
  %t35 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t35, ptr %l25
  br label %bb21
bb21:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t36, ptr %lp4
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = load ptr, ptr %lp4
  store { i64, ptr } %t37, ptr %t38, !tbaa !27
  %t39 = load ptr, ptr %lp4
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d128, i32 0, i32 1) })
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l29
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb23, label %ok.46, !prof !99
ok.46:
  store i64 %t43, ptr %l28
  br label %bb22
bb22:
  %t47 = load i64, ptr %l28, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb25
bb25:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb26, label %bb27
bb26:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l34, !tbaa !24
  %t56 = load ptr, ptr %lp4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l35, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb28, label %bb29
bb27:
  %t61 = load ptr, ptr %lp4
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l32, !tbaa !27
  br label %bb34
bb28:
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = icmp sle i64 0, %t64
  br i1 %t65, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb30:
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = load i64, ptr %l35, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb32:
  %t71 = load ptr, ptr %lp4
  %t72 = getelementptr { i64, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l34, !tbaa !24
  %t75 = getelementptr i8, ptr %t73, i64 0
  %t76 = sub i64 %t74, 0
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l32, !tbaa !27
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t21, i8 10)
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t30 = extractvalue { i64, ptr } %t25, 1
  %t31 = extractvalue { i64, ptr } %t25, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t23, { i64, ptr } %t47)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb2
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca i32
  %l41 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i32
  %l92 = alloca i64
  %l96 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l119 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca i1
  %l144 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l157 = alloca i1
  %l165 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l30, !tbaa !29
  %t18 = ptrtoint ptr %v0 to i64
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l31, !tbaa !24
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = load i64, ptr %l31
  %t27 = inttoptr i64 %t26 to ptr
  %t30 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t27, ptr %v1, ptr %t24, { i64, ptr } %t25)
  store i32 %t30, ptr %l35
  br label %bb6
bb6:
  %t31 = load i32, ptr %l35, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/load:Loader", ptr %t38, i32 0, i32 10
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t44, ptr %l41
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l41, !tbaa !29
  %t47 = getelementptr %"compiler/load:Module", ptr %t45, i32 0, i32 6
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_301af787a8ab5449_ce9576e6695793ad)
  unreachable
bb9:
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t57 = getelementptr %"compiler/source:Source", ptr %t54, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l7, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l2, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l53
  br label %bb11
bb11:
  %t70 = load i32, ptr %l53, !range !{i32 0, i32 6}
  %t72 = trunc i64 2 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l56, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  store i64 %t76, ptr %l57, !tbaa !24
  %t77 = load ptr, ptr %l4, !tbaa !29
  store ptr %t77, ptr %l58, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l2, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l63
  br label %bb14
bb13:
  br label %bb34
bb14:
  %t88 = load ptr, ptr %l58, !tbaa !29
  %t89 = load i32, ptr %l63, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t88, i32 %t89)
  store { i64, ptr } %t90, ptr %l64
  br label %bb15
bb15:
  %t91 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t92, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t105 = load i64, ptr %l57, !tbaa !24
  %t107 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %s2, ptr %t104, i64 %t105, { i64, ptr } %t103)
  store i64 %t107, ptr %l67
  br label %bb16
bb16:
  %t108 = load i64, ptr %l67, !tbaa !24
  store i64 %t108, ptr %l8, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = icmp slt i64 %t109, 0
  br i1 %t111, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t114 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t114, ptr %l72, !tbaa !27
  %t115 = load i64, ptr %l8, !tbaa !24
  store i64 %t115, ptr %l73, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t116, 0
  store i64 %t119, ptr %l76, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  store i64 %t121, ptr %l77, !tbaa !24
  %t122 = load i64, ptr %l73, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb20, label %bb21
bb20:
  %t125 = load i64, ptr %l73, !tbaa !24
  %t126 = load i64, ptr %l76, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb22:
  %t129 = load i64, ptr %l76, !tbaa !24
  %t130 = load i64, ptr %l77, !tbaa !24
  %t131 = icmp sle i64 %t129, %t130
  br i1 %t131, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb24:
  %t133 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l73, !tbaa !24
  %t136 = load i64, ptr %l76, !tbaa !24
  %t137 = getelementptr i8, ptr %t134, i64 %t135
  %t138 = sub i64 %t136, %t135
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t142 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t140, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) })
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l83
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb27, label %ok.146, !prof !99
ok.146:
  store i64 %t143, ptr %l82
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb26:
  %t147 = load i64, ptr %l82, !tbaa !24
  store i64 %t147, ptr %l71, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  store i64 -1, ptr %l71, !tbaa !24
  br label %bb29
bb29:
  %t148 = load i64, ptr %l71, !tbaa !24
  store i64 %t148, ptr %l9, !tbaa !24
  %t149 = load i64, ptr %l9, !tbaa !24
  %t151 = icmp slt i64 %t149, 0
  br i1 %t151, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t155 = load i64, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t155, %t156
  %t160 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t164 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %t154, i64 %t159, { i64, ptr } %t160)
  store i64 %t164, ptr %l92
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  %t165 = load i64, ptr %l92, !tbaa !24
  store i64 %t165, ptr %rv
  br label %ret
bb34:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load i32, ptr %l2, !tbaa !23
  %t173 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t169, i32 %t170)
  store ptr %t173, ptr %l96
  br label %bb35
bb35:
  %t174 = load ptr, ptr %l96, !tbaa !29
  store ptr %t174, ptr %l10, !tbaa !29
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = icmp eq ptr %t175, null
  br i1 %t177, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb38
bb37:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t181 = getelementptr %"compiler/ast:TypeDecl", ptr %t179, i32 0, i32 3
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  store i1 %t184, ptr %l99, !tbaa !21
  br label %bb38
bb38:
  %t186 = load i1, ptr %l99, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t188 = load ptr, ptr %l10, !tbaa !29
  %t190 = getelementptr %"compiler/ast:TypeDecl", ptr %t188, i32 0, i32 3
  %t191 = load ptr, ptr %t190, !tbaa !29
  store ptr %t191, ptr %l11, !tbaa !29
  %t193 = load ptr, ptr %l11, !tbaa !29
  store ptr %t193, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t194 = load ptr, ptr %l106, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb42, label %bb43
bb42:
  %t197 = load ptr, ptr %l106, !tbaa !29
  %t198 = load i64, ptr %t197, !range !{i64 0, i64 5}
  %t200 = icmp eq i64 %t198, 1
  store i1 %t200, ptr %l107, !tbaa !21
  br label %bb43
bb43:
  %t201 = load i1, ptr %l107, !tbaa !21
  br i1 %t201, label %bb44, label %bb45
bb44:
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t204 = getelementptr { i64, [6 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { { i64, ptr }, ptr }, ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205
  store { i64, ptr } %t206, ptr %l12, !tbaa !27
  br label %bb46
bb45:
  br label %bb56
bb46:
  %t208 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t208, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l15, !tbaa !24
  br label %bb47
bb47:
  %t214 = load i64, ptr %l14, !tbaa !24
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb48, label %bb49
bb48:
  br label %bb55
bb49:
  br label %bb50
bb50:
  %t222 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t222, ptr %l119, !tbaa !27
  %t223 = load i64, ptr %l14, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 %t223
  %t228 = load ptr, ptr %t227, !tbaa !39
  store ptr %t228, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l16, !tbaa !29
  %t232 = getelementptr %"compiler/ast:CaseDecl", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  %t234 = load i32, ptr %l5, !tbaa !23
  %t237 = icmp eq i32 %t233, %t234
  br i1 %t237, label %bb51, label %bb52
bb51:
  %t239 = load ptr, ptr %l16, !tbaa !29
  %t241 = getelementptr %"compiler/ast:CaseDecl", ptr %t239, i32 0, i32 0
  %t242 = getelementptr %"compiler/source:Span", ptr %t241, i32 0, i32 0
  %t243 = load i32, ptr %t242, !tbaa !23
  %t245 = sext i32 %t243 to i64
  store i64 %t245, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t247 = load i64, ptr %l14, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l14, !tbaa !24
  br label %bb47
bb55:
  br label %bb83
bb56:
  %t251 = load ptr, ptr %l11, !tbaa !29
  store ptr %t251, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t252 = load ptr, ptr %l131, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  br i1 %t253, label %bb57, label %bb58
bb57:
  %t255 = load ptr, ptr %l131, !tbaa !29
  %t256 = load i64, ptr %t255, !range !{i64 0, i64 5}
  %t258 = icmp eq i64 %t256, 2
  store i1 %t258, ptr %l132, !tbaa !21
  br label %bb58
bb58:
  %t259 = load i1, ptr %l132, !tbaa !21
  br i1 %t259, label %bb59, label %bb60
bb59:
  %t260 = load ptr, ptr %l11, !tbaa !29
  %t262 = getelementptr { i64, [6 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t262, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263
  store { i64, ptr } %t264, ptr %l17, !tbaa !27
  br label %bb61
bb60:
  br label %bb71
bb61:
  %t266 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t266, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t268 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  store i64 %t270, ptr %l20, !tbaa !24
  br label %bb62
bb62:
  %t272 = load i64, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l20, !tbaa !24
  %t276 = icmp slt i64 %t272, %t273
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb63, label %bb64
bb63:
  br label %bb70
bb64:
  br label %bb65
bb65:
  %t280 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t280, ptr %l144, !tbaa !27
  %t281 = load i64, ptr %l19, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 %t281
  %t286 = load ptr, ptr %t285, !tbaa !39
  store ptr %t286, ptr %l21, !tbaa !29
  %t288 = load ptr, ptr %l21, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Func", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %t290, !tbaa !23
  %t292 = load i32, ptr %l5, !tbaa !23
  %t295 = icmp eq i32 %t291, %t292
  br i1 %t295, label %bb66, label %bb67
bb66:
  %t297 = load ptr, ptr %l21, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Func", ptr %t297, i32 0, i32 0
  %t300 = getelementptr %"compiler/source:Span", ptr %t299, i32 0, i32 0
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = sext i32 %t301 to i64
  store i64 %t303, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l19, !tbaa !24
  br label %bb62
bb70:
  br label %bb83
bb71:
  %t309 = load ptr, ptr %l11, !tbaa !29
  store ptr %t309, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t310 = load ptr, ptr %l156, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb72, label %bb73
bb72:
  %t313 = load ptr, ptr %l156, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 5}
  %t316 = icmp eq i64 %t314, 0
  store i1 %t316, ptr %l157, !tbaa !21
  br label %bb73
bb73:
  %t317 = load i1, ptr %l157, !tbaa !21
  br i1 %t317, label %bb74, label %bb75
bb74:
  %t318 = load ptr, ptr %l11, !tbaa !29
  %t320 = getelementptr { i64, [6 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { ptr }, ptr %t320, i32 0, i32 0
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l22, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = getelementptr %"compiler/ast:StructBody", ptr %t324, i32 0, i32 2
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t328 = load i32, ptr %l5, !tbaa !23
  %t331 = call i64 @compiler_2fdoc_2evarNamed(ptr %v0, { i64, ptr } %t327, i32 %t328)
  store i64 %t331, ptr %l165
  br label %bb77
bb77:
  %t332 = load i64, ptr %l165, !tbaa !24
  store i64 %t332, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e)
  unreachable
bb83:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2fdoc_2ePastAttrs(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t19)
  store i1 %t21, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb13
bb5:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l18
  br label %bb8
bb8:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l14, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l20, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = icmp eq i8 %t40, 95
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l19, !tbaa !21
  store i1 %t44, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l9, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t52, ptr %l27, !tbaa !27
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l28, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l29, !tbaa !24
  %t56 = icmp sge i64 0, 0
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = load i64, ptr %l28, !tbaa !24
  %t59 = icmp sle i64 0, %t58
  br i1 %t59, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb21:
  %t61 = load i64, ptr %l28, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb23:
  %t65 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l28, !tbaa !24
  %t68 = getelementptr i8, ptr %t66, i64 0
  %t69 = sub i64 %t67, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t73, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = add i64 %t15, 2
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l26, !tbaa !24
  %t34 = icmp sge i64 3, 0
  br i1 %t34, label %bb13, label %bb14
bb7:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l16, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb9:
  %t40 = load i64, ptr %l16, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb11:
  %t44 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l16, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l10, !tbaa !27
  br label %bb19
bb12:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb13:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 3, %t53
  br i1 %t54, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb17:
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 3
  %t64 = sub i64 %t62, 3
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l10, !tbaa !27
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb19:
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t68, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t69, %t72
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t83)
  store i1 %t85, ptr %l39
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb31
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t93)
  store i1 %t95, ptr %l44
  br label %bb26
bb26:
  %t96 = load i1, ptr %l44, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp eq i8 %t104, 95
  store i1 %t106, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l45, !tbaa !21
  store i1 %t108, ptr %l35, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l35, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l3, !tbaa !24
  br label %bb35
bb35:
  br label %bb20
bb36:
  %t116 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb39:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb41:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr @G_2ecompiler_2fdoc_2eStyle, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %t4, 1
  %t23 = extractvalue { i64, ptr } %t4, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a1, 1
  %t30 = extractvalue { i64, ptr } %a1, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t6, i64 %t7)
  %t36 = getelementptr i8, ptr %t35, i64 %t7
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %lp11 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/doc:Entry"
  %l40 = alloca %"compiler/doc:Entry"
  %l41 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t59 = alloca %"compiler/doc:Entry", align 8
  %t169 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %l5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t2 = load i64, ptr %l8, !tbaa !24
  store i64 %t2, ptr %l13, !tbaa !24
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp slt i64 %t6, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load i64, ptr %l20, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t40, i32 %t39)
  store { i64, ptr } %t42, ptr %l31
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t49, ptr %lp10
  %t51 = load ptr, ptr %lp10
  store { i64, ptr } %t48, ptr %t51, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %lp10
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t66 = call i32 @compiler_2fdoc_2eEntry_2eitem(ptr %t59, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t52, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %t57, i1 %a6)
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb10, label %ok.68, !prof !99
ok.68:
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t59, i64 152, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %l40, i64 152, i1 false)
  br label %bb12
bb10:
  %t69 = load i32, ptr %l41, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb12:
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t73, ptr %lp11
  %t74 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %l33, i64 152, i1 false)
  %t75 = load ptr, ptr %lp11
  %t76 = getelementptr %"compiler/doc:Entry", ptr %t75, i32 0, i32 6
  store i1 true, ptr %t76, !tbaa !21
  %t77 = ptrtoint ptr %v3 to i64
  store i64 %t77, ptr %l44, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = call ptr @__olang_region_make(ptr %v3)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store ptr %t89, ptr %l49
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/load:Loader", ptr %t96, i32 0, i32 3
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l49, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s2, ptr %t100, ptr %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb16
bb16:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t116, i64 %t117)
  store ptr %t120, ptr %l62
  br label %bb17
bb17:
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 10
  %t124 = load i32, ptr %t123, !tbaa !23
  %t125 = load ptr, ptr %l58, !tbaa !29
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t125, i32 %t124)
  store { i64, ptr } %t127, ptr %l65
  br label %bb18
bb18:
  %t128 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = load i64, ptr %l44
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = call ptr @__olang_held_alloc(ptr %t139, i64 %t137)
  call void @olang_textcopy(ptr %t140, ptr %t129, i64 %t130)
  %t141 = getelementptr i8, ptr %t140, i64 %t130
  call void @olang_textcopy(ptr %t141, ptr %t131, i64 %t132)
  %t142 = getelementptr i8, ptr %t141, i64 %t132
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = load i64, ptr %l44
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = extractvalue { i64, ptr } %t144, 0
  %t149 = extractvalue { i64, ptr } %t144, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_held_alloc(ptr %t147, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t154 = load ptr, ptr %lp11
  %t155 = getelementptr %"compiler/doc:Entry", ptr %t154, i32 0, i32 8
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l68, !tbaa !27
  %t158 = load ptr, ptr %lp11
  %t159 = getelementptr %"compiler/doc:Entry", ptr %t158, i32 0, i32 8
  store { i64, ptr } %t153, ptr %t159, !tbaa !27
  %t160 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t160, label %bb19, label %bb20
bb19:
  %t162 = load { i64, ptr }, ptr %l68
  %t163 = extractvalue { i64, ptr } %t162, 1
  call void @__olang_region_release(ptr %t163)
  store { i64, ptr } zeroinitializer, ptr %l68
  br label %bb20
bb20:
  %t166 = getelementptr %"compiler/doc:Entry", ptr %a4, i32 0, i32 5
  %t167 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t167, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t169, ptr %l72, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t166, ptr %t169)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t170 = load i64, ptr %l8, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l8, !tbaa !24
  br label %bb1
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a1)
  store i32 %t20, ptr %l12
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l21
  br label %bb4
bb4:
  %t43 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l28
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l28, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l33
  br label %bb9
bb9:
  %t69 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l39, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l44
  br label %bb13
bb13:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t93, ptr %l45
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fdoc_2evarNamed(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb32
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 22}
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb25
bb9:
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb10, label %bb11
bb10:
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb12:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l38, !tbaa !24
  store i64 %t71, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t72 = load i64, ptr %l35, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr %"compiler/ast:VarDecl", ptr %t91, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load i64, ptr %l12, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t104 = icmp eq i32 %t100, %a1
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t106 = load ptr, ptr %l6, !tbaa !29
  %t108 = getelementptr %"compiler/ast:VarDecl", ptr %t106, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = load i64, ptr %l12, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/source:Span", ptr %t113, i64 %t110
  %t115 = getelementptr %"compiler/source:Span", ptr %t114, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l11, !tbaa !24
  br label %bb16
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8ab72cd26d658e2b_1072abfe1978b2bf)
  unreachable
bb30:
  br label %bb31
bb31:
  %t124 = load i64, ptr %l3, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l3, !tbaa !24
  br label %bb1
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdoc_2ewordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2ewordsOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb33
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t19)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 95
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l14, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb32
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp slt i64 %t42, %t45
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  %t58 = call i1 @compiler_2fdoc_2ewordChar(i8 %t56)
  store i1 %t58, ptr %l31
  br label %bb16
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  %t59 = load i1, ptr %l31, !tbaa !21
  store i1 %t59, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l27, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb21
bb21:
  br label %bb13
bb22:
  store ptr %l1, ptr %l35, !tbaa !29
  %t67 = ptrtoint ptr %v1 to i64
  store i64 %t67, ptr %l36, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = call ptr @__olang_region_make(ptr %v1)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l36, !tbaa !24
  br label %bb24
bb24:
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = load i64, ptr %l3, !tbaa !24
  store i64 %t73, ptr %l39, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l40, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l39, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = load i64, ptr %l40, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb27:
  %t84 = load i64, ptr %l40, !tbaa !24
  %t85 = load i64, ptr %l41, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb29:
  %t88 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = getelementptr i8, ptr %t89, i64 %t90
  %t93 = sub i64 %t91, %t90
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t97 = extractvalue { i64, ptr } %t95, 1
  %t98 = extractvalue { i64, ptr } %t95, 0
  %t99 = load i64, ptr %l36
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = call ptr @__olang_held_alloc(ptr %t100, i64 %t98)
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t105 = load i64, ptr %l36
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = extractvalue { i64, ptr } %t103, 0
  %t108 = extractvalue { i64, ptr } %t103, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_held_alloc(ptr %t106, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t113, { i64, ptr } %t112)
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb31:
  br label %bb32
bb32:
  br label %bb2
bb33:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fdoc_3aEntry_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i1
  %l11 = alloca { i64, ptr }
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"compiler/doc:Entry"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 -1, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = ptrtoint ptr %v3 to i64
  store i64 %t7, ptr %l15, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_region_make(ptr %v3)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l15, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %t13, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l17
  br label %bb3
bb3:
  %t15 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l15
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr null)
  %t23 = call ptr @__olang_region_home(ptr %t22)
  %t24 = icmp ne ptr %t23, null
  %t25 = select i1 %t24, ptr %t23, ptr null
  %t26 = icmp eq ptr %t25, %t18
  call void @__olang_region_settle(ptr %t18, i1 %t26)
  br label %bb5
bb5:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l8
  store i1 false, ptr %l9, !tbaa !21
  %t28 = ptrtoint ptr %v3 to i64
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = call ptr @__olang_region_make(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l19
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %t34, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l21
  br label %bb8
bb8:
  %t36 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l19
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = call ptr @__olang_region_or(ptr %t42, ptr null)
  %t44 = call ptr @__olang_region_home(ptr %t43)
  %t45 = icmp ne ptr %t44, null
  %t46 = select i1 %t45, ptr %t44, ptr null
  %t47 = icmp eq ptr %t46, %t39
  call void @__olang_region_settle(ptr %t39, i1 %t47)
  br label %bb10
bb10:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t49 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 3
  %t56 = load i64, ptr %l6, !tbaa !24
  store i64 %t56, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 4
  %t58 = load i64, ptr %l7, !tbaa !24
  store i64 %t58, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 5
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t59
  %t61 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 6
  %t62 = load i1, ptr %l9, !tbaa !21
  store i1 %t62, ptr %t61, !tbaa !21
  %t63 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t63
  %t65 = getelementptr %"compiler/doc:Entry", ptr %l23, i32 0, i32 8
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t66, ptr %t65, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l23, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/doc:Example"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/doc:Example" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/doc:Example" %t6, { i64, ptr } %a1, 1
  store %"compiler/doc:Example" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Example", ptr %rv
  ret %"compiler/doc:Example" %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/doc:Module"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = ptrtoint ptr %v3 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e3
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_region_make(ptr %v3)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l10
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %t13, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l12
  br label %bb3
bb3:
  %t15 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e3
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l10
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr null)
  %t23 = call ptr @__olang_region_home(ptr %t22)
  %t24 = icmp ne ptr %t23, null
  %t25 = select i1 %t24, ptr %t23, ptr null
  %t26 = icmp eq ptr %t25, %t18
  call void @__olang_region_settle(ptr %t18, i1 %t26)
  br label %bb5
bb5:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = insertvalue %"compiler/doc:Module" undef, { i64, ptr } %t28, 0
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = insertvalue %"compiler/doc:Module" %t29, { i64, ptr } %t30, 1
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = insertvalue %"compiler/doc:Module" %t31, { i64, ptr } %t32, 2
  %t35 = insertvalue %"compiler/doc:Module" %t33, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, 3
  store %"compiler/doc:Module" %t35, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d5 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
@.d6 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
@olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e9 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_region_release(ptr) noinline
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d15 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e1 = weak hidden constant i1 false
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d18 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e18 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn (" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0A    " }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d25 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0A    " }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"meets " }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<h1>" }>, align 8
@.d37 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</h1>\0A<ul>\0A" }>, align 8
@.d38 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<li><a href=\22" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</code></a>" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</li>\0A" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</ul>\0A" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import\22" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aModule_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aModule_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aModule_2e2 = weak hidden constant i1 false
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_53(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e8 = weak hidden constant i1 false
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/doc:Entry"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 152, i1 false)
  %t2 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e5 = weak hidden constant i1 false
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d73 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"<p><a href=\22index.html\22>index</a></p>\0A<h1>" }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</h1>\0A" }>, align 8
@.d75 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<pre>import \22" }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22</pre>\0A" }>, align 8
@.d77 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<h2>Index</h2>\0A<ul>\0A" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" class=\22dep\22" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"<li><a href=\22#" }>, align 8
@.d82 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\22><code" }>, align 8
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d84 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</code></a></li>\0A" }>, align 8
@.d85 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"</ul>\0A<h2>Items</h2>\0A" }>, align 8
@.d86 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"<div class=\22doc\22>" }>, align 8
define internal void @olang_lambda_94(ptr %env, ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb5
bb5:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s2, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l12
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t17, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store i1 %t19, ptr %l16
  br label %bb10
bb8:
  %t20 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t41 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t41, { i64, ptr } %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  %t43 = load i1, ptr %l16, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l17, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s5, { i64, ptr } %t45)
  store { i64, ptr } %t47, ptr %l19
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l22, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s7, { i64, ptr } %t49)
  store { i64, ptr } %t51, ptr %l24
  br label %bb15
bb13:
  %t52 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t54 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = getelementptr i8, ptr %t61, i64 %t53
  call void @olang_textcopy(ptr %t62, ptr %t55, i64 %t56)
  %t63 = getelementptr i8, ptr %t62, i64 %t56
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t73, { i64, ptr } %t72)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb15:
  %t75 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t77 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t75, i64 %t76)
  %t85 = getelementptr i8, ptr %t84, i64 %t76
  call void @olang_textcopy(ptr %t85, ptr %t78, i64 %t79)
  %t86 = getelementptr i8, ptr %t85, i64 %t79
  call void @olang_textcopy(ptr %t86, ptr %t81, i64 %t82)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t84, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t96 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t96, { i64, ptr } %t95)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s7)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t98)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d97 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d98 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<div class=\22member\22>" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" class=\22dep\22" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"<pre id=\22" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d105 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</pre>\0A" }>, align 8
@.d106 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"<details class=\22example\22><summary>Example: " }>, align 8
@.d107 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</summary><pre>" }>, align 8
@.d108 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</pre></details>\0A" }>, align 8
@.d109 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"<h3 class=\22member\22>Builders</h3>\0A" }>, align 8
@.d110 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"   # deprecated" }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d117 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d118 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    example \22" }>, align 8
@.d119 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d120 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d121 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    builders\0A" }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aExample_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aExample_2e1 = weak hidden constant i1 false
@.d123 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d124 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d125 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"    [" }>, align 8
@.d126 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"    #" }>, align 8
@.d127 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d128 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c". " }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d133 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"<!doctype html>\0A<html lang=\22en\22><head><meta charset=\22utf-8\22>" }>, align 8
@.d134 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"<meta name=\22viewport\22 content=\22width=device-width, initial-scale=1\22>" }>, align 8
@.d135 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"<title>" }>, align 8
@.d136 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</title><style>" }>, align 8
@.d137 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"</style></head><body>\0A" }>, align 8
@.d138 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
@.d139 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aModule_2e3 = weak hidden constant i1 false
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d141 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
@.d142 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<pre>" }>, align 8
@.d143 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</pre>" }>, align 8
@.d144 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"<p class=\22note\22>" }>, align 8
@.d145 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
@.d146 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<p>" }>, align 8
@.d147 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/doc:Entry"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/doc:Entry", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 152
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t14, i64 %t12
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 152, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/doc:Entry", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 152, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_39c265aa723c0dcb_f35d02a7366497b7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_19c80d7aab96fce_b433fa540154765a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9 = external constant [0 x i8]
@olang_loc_89c63e526fea8550_9190d8cdbdd5cacc = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_51c1b9bde331172f_b1d3b315fa602c93 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_e6eab810f8bf9eb2_b1c2bcfaa1dcc836 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8d5034eaa81491fd_13883a423d047079 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_af70a68dd18f91cd_78b5556af2db7259 = external constant [0 x i8]
@olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2d405ddcd9a8ab59_87891e6f641f4355 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_84ace3bf0f23a4a_6d246e44ba5edd86 = external constant [0 x i8]
@olang_loc_ea407f163068c569_14e8b422ff4a82a5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eRefMut_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_66caf8065a216fa4_255d0b76d432a940 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2d5d282533798e40_ae298936cea775c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
@olang_loc_b461083f788c6b86_e65d814f8bc052da = external constant [0 x i8]
@olang_loc_b4b87f1043b41663_258689a2c0d07437 = external constant [0 x i8]
@olang_loc_a37384dcd940e048_c3ba5fc94841a74c = external constant [0 x i8]
@olang_loc_c14737b94c4967d9_488ba51a50b8fbfd = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_6644f0af63579e58_6cea556a954a7954 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6 = external constant [0 x i8]
@olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903 = external constant [0 x i8]
@olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8 = external constant [0 x i8]
@olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5 = external constant [0 x i8]
@olang_loc_417cf13f3f24fdcf_48c2325066185a1b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b = external constant [0 x i8]
@olang_loc_91fc21a6b7496c0a_24bc2c9db083308e = external constant [0 x i8]
@olang_loc_f657276e2350bf29_71dbd11cb4dae2ed = external constant [0 x i8]
@olang_loc_8ef8e25bc783e73c_af1dce04e2424510 = external constant [0 x i8]
@olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef = external constant [0 x i8]
@olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a = external constant [0 x i8]
@olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7 = external constant [0 x i8]
@olang_loc_d85afc985d0ab39_76fcb7f235eece65 = external constant [0 x i8]
@olang_loc_1f1e658c6da2070c_2842ab33ef4c4808 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@olang_loc_d85c9f08fc02aff9_18b1e7df62bde535 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Example" %a1)
@olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e = external constant [0 x i8]
@olang_loc_5be1599e6a61f501_71a8850ae192da35 = external constant [0 x i8]
@olang_loc_fe551cd114f4cb63_729eb01933a49f67 = external constant [0 x i8]
@olang_loc_46ab965e7000f695_6c81a9a0ef748b89 = external constant [0 x i8]
@olang_loc_301af787a8ab5449_ce9576e6695793ad = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0afceaceca5551a_2521421923c730de = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_fdfaf893749e1d49_869eafdea154472d = external constant [0 x i8]
@olang_loc_93a5825f4266fe40_3fd51f523aa7a28c = external constant [0 x i8]
@olang_loc_249ae2d6db78c99d_2e3c698f52d646b9 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_8ab72cd26d658e2b_1072abfe1978b2bf = external constant [0 x i8]
@olang_loc_648623c9a60da9e4_705f5426fdf26810 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
