; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2fdoc_2eStyle = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\38\02\00\00\00\00\00\00", ptr @G_2ecompiler_2fdoc_2eStyle.k1 }>, align 8
@G_2ecompiler_2fdoc_2eStyle.k1 = internal constant <{ [568 x i8] }> <{ [568 x i8] c"\62\6F\64\79\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\73\79\73\74\65\6D\2D\75\69\2C\73\61\6E\73\2D\73\65\72\69\66\3B\6D\61\78\2D\77\69\64\74\68\3A\35\32\72\65\6D\3B\6D\61\72\67\69\6E\3A\32\72\65\6D\20\61\75\74\6F\3B\70\61\64\64\69\6E\67\3A\30\20\31\72\65\6D\3B\6C\69\6E\65\2D\68\65\69\67\68\74\3A\31\2E\35\3B\63\6F\6C\6F\72\3A\23\31\64\31\64\31\66\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\66\66\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\66\35\66\35\66\37\3B\70\61\64\64\69\6E\67\3A\2E\35\72\65\6D\20\2E\37\35\72\65\6D\3B\62\6F\72\64\65\72\2D\72\61\64\69\75\73\3A\34\70\78\3B\6F\76\65\72\66\6C\6F\77\2D\78\3A\61\75\74\6F\3B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\7D\63\6F\64\65\2C\70\72\65\7B\66\6F\6E\74\2D\66\61\6D\69\6C\79\3A\75\69\2D\6D\6F\6E\6F\73\70\61\63\65\2C\4D\65\6E\6C\6F\2C\6D\6F\6E\6F\73\70\61\63\65\3B\66\6F\6E\74\2D\73\69\7A\65\3A\2E\39\65\6D\7D\2E\64\6F\63\7B\6D\61\72\67\69\6E\3A\2E\32\35\72\65\6D\20\30\20\31\72\65\6D\20\31\72\65\6D\7D\2E\6D\65\6D\62\65\72\7B\6D\61\72\67\69\6E\2D\6C\65\66\74\3A\31\2E\35\72\65\6D\7D\68\32\7B\62\6F\72\64\65\72\2D\62\6F\74\74\6F\6D\3A\31\70\78\20\73\6F\6C\69\64\20\23\64\64\64\3B\70\61\64\64\69\6E\67\2D\62\6F\74\74\6F\6D\3A\2E\32\35\72\65\6D\3B\6D\61\72\67\69\6E\2D\74\6F\70\3A\32\72\65\6D\7D\61\7B\63\6F\6C\6F\72\3A\23\30\62\35\37\64\30\7D\40\6D\65\64\69\61\28\70\72\65\66\65\72\73\2D\63\6F\6C\6F\72\2D\73\63\68\65\6D\65\3A\64\61\72\6B\29\7B\62\6F\64\79\7B\63\6F\6C\6F\72\3A\23\65\38\65\38\65\61\3B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\31\38\31\38\31\62\7D\70\72\65\7B\62\61\63\6B\67\72\6F\75\6E\64\3A\23\32\36\32\36\32\62\7D\61\7B\63\6F\6C\6F\72\3A\23\38\61\62\34\66\38\7D\68\32\7B\62\6F\72\64\65\72\2D\63\6F\6C\6F\72\3A\23\33\33\33\7D\7D" }>, align 64
define dso_local { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l100 = alloca i64
  %l102 = alloca { i64, ptr }
  %l109 = alloca %"std/prelude/text:StringBuilder"
  %l118 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l133 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l141 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t3, i64 %a1)
  store i64 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t15, i64 %t18)
  store i64 %t21, ptr %l22
  br label %bb7
bb7:
  %t22 = load i64, ptr %l22, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l23, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l26, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb10:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb12:
  %t41 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l26, !tbaa !24
  %t45 = getelementptr i8, ptr %t42, i64 %t43
  %t46 = sub i64 %t44, %t43
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t50)
  store i1 %t52, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb14:
  %t53 = load i1, ptr %l33, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s1, { i64, ptr } %t60, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t62, ptr %l39
  br label %bb20
bb19:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t65 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t65)
  br label %bb25
bb25:
  %t68 = load i64, ptr %l4, !tbaa !24
  store i64 %t68, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  br label %bb3
bb27:
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t71, ptr %l44
  br label %bb28
bb28:
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = icmp eq i64 %t72, 0
  br i1 %t73, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l49, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t89, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t92, ptr %l51
  br label %bb32
bb32:
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = sub i64 %t93, 1
  store i64 %t94, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb33, label %bb34
bb33:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l55, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t102 = load i64, ptr %l3, !tbaa !24
  %t104 = sub i64 %t102, 1
  %t107 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t101, i64 %t104)
  store i64 %t107, ptr %l59
  br label %bb35
bb34:
  br label %bb75
bb35:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = sub i64 %t108, 1
  store i64 %t110, ptr %l61, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l62, !tbaa !24
  %t113 = load i64, ptr %l59, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t116 = load i64, ptr %l59, !tbaa !24
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb38:
  %t120 = load i64, ptr %l61, !tbaa !24
  %t121 = load i64, ptr %l62, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb40:
  %t124 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l59, !tbaa !24
  %t127 = load i64, ptr %l61, !tbaa !24
  %t128 = getelementptr i8, ptr %t125, i64 %t126
  %t129 = sub i64 %t127, %t126
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  store { i64, ptr } %t131, ptr %l7, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t135 = call i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %t133)
  store i64 %t135, ptr %l68
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb42:
  %t136 = load i64, ptr %l68, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t141, ptr %l72, !tbaa !27
  %t142 = load i64, ptr %l8, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l74, !tbaa !24
  %t145 = icmp sge i64 0, 0
  br i1 %t145, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb52
bb45:
  %t147 = load i64, ptr %l73, !tbaa !24
  %t148 = icmp sle i64 0, %t147
  br i1 %t148, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb47:
  %t150 = load i64, ptr %l73, !tbaa !24
  %t151 = load i64, ptr %l74, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb49:
  %t154 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l73, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 0
  %t158 = sub i64 %t156, 0
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  %t162 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t160)
  store { i64, ptr } %t162, ptr %l79
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb51:
  %t163 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t166 = icmp sgt i64 %t164, 0
  store i1 %t166, ptr %l71, !tbaa !21
  br label %bb52
bb52:
  %t168 = load i1, ptr %l71, !tbaa !21
  br i1 %t168, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb74
bb55:
  %t169 = load i64, ptr %l6, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb56, label %bb57
bb56:
  br label %bb73
bb57:
  br label %bb58
bb58:
  %t175 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t175, ptr %l85, !tbaa !27
  %t176 = load i64, ptr %l6, !tbaa !24
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t176)
  store i64 %t179, ptr %l88
  br label %bb59
bb59:
  %t180 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = load i64, ptr %l6, !tbaa !24
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t181)
  store i64 %t184, ptr %l92
  br label %bb60
bb60:
  %t185 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t186 = load i64, ptr %l92, !tbaa !24
  %t187 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t185, i64 %t186)
  store i64 %t187, ptr %l93
  br label %bb61
bb61:
  %t188 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l94, !tbaa !24
  %t190 = load i64, ptr %l88, !tbaa !24
  %t191 = icmp sge i64 %t190, 0
  br i1 %t191, label %bb62, label %bb63
bb62:
  %t193 = load i64, ptr %l88, !tbaa !24
  %t194 = load i64, ptr %l93, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb64:
  %t197 = load i64, ptr %l93, !tbaa !24
  %t198 = load i64, ptr %l94, !tbaa !24
  %t199 = icmp sle i64 %t197, %t198
  br i1 %t199, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb66:
  %t201 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l88, !tbaa !24
  %t204 = load i64, ptr %l93, !tbaa !24
  %t205 = getelementptr i8, ptr %t202, i64 %t203
  %t206 = sub i64 %t204, %t203
  %t207 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  store { i64, ptr } %t208, ptr %l9, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l100, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t215 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t213)
  store { i64, ptr } %t215, ptr %l102
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb68:
  %t216 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = load i64, ptr %l100, !tbaa !24
  %t220 = sub i64 %t218, %t217
  %t221 = load i64, ptr %l8, !tbaa !24
  %t224 = icmp ne i64 %t220, %t221
  br i1 %t224, label %bb69, label %bb70
bb69:
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t226 = load i64, ptr %l6, !tbaa !24
  %t228 = sub i64 %t226, 1
  store i64 %t228, ptr %l6, !tbaa !24
  br label %bb72
bb72:
  br label %bb55
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t230 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t230, ptr %l109
  br label %bb76
bb76:
  %t231 = load %"std/prelude/text:StringBuilder", ptr %l109
  store %"std/prelude/text:StringBuilder" %t231, ptr %l10
  %t232 = load i64, ptr %l6, !tbaa !24
  store i64 %t232, ptr %l11, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s10
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = icmp sge i64 %t234, 0
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s10)
  br label %bb97
bb79:
  br label %bb80
bb80:
  %t240 = load i64, ptr %l11, !tbaa !24
  %t241 = load i64, ptr %l6, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  br i1 %t244, label %bb81, label %bb82
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  store ptr %l10, ptr %l118, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t247, ptr %l119, !tbaa !27
  %t248 = load i64, ptr %l11, !tbaa !24
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t248)
  store i64 %t251, ptr %l122
  br label %bb85
bb85:
  %t252 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t252, ptr %l123, !tbaa !27
  %t253 = load i64, ptr %l11, !tbaa !24
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t253)
  store i64 %t256, ptr %l126
  br label %bb86
bb86:
  %t257 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t258 = load i64, ptr %l126, !tbaa !24
  %t259 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t257, i64 %t258)
  store i64 %t259, ptr %l127
  br label %bb87
bb87:
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  store i64 %t261, ptr %l128, !tbaa !24
  %t262 = load i64, ptr %l122, !tbaa !24
  %t263 = icmp sge i64 %t262, 0
  br i1 %t263, label %bb88, label %bb89
bb88:
  %t265 = load i64, ptr %l122, !tbaa !24
  %t266 = load i64, ptr %l127, !tbaa !24
  %t267 = icmp sle i64 %t265, %t266
  br i1 %t267, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb90:
  %t269 = load i64, ptr %l127, !tbaa !24
  %t270 = load i64, ptr %l128, !tbaa !24
  %t271 = icmp sle i64 %t269, %t270
  br i1 %t271, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb92:
  %t273 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = load i64, ptr %l122, !tbaa !24
  %t276 = load i64, ptr %l127, !tbaa !24
  %t277 = getelementptr i8, ptr %t274, i64 %t275
  %t278 = sub i64 %t276, %t275
  %t279 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t277, 1
  %t282 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s10, { i64, ptr } %t280)
  store { i64, ptr } %t282, ptr %l133
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb94:
  %t283 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t290 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t290, { i64, ptr } %t289)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t292 = load i64, ptr %l11, !tbaa !24
  %t294 = sub i64 %t292, 1
  store i64 %t294, ptr %l11, !tbaa !24
  br label %bb77
bb97:
  %t297 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l10)
  store { i64, ptr } %t297, ptr %l138
  br label %bb98
bb98:
  %t298 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t298, ptr %l139, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  store i64 %t300, ptr %l140, !tbaa !24
  %t301 = load i64, ptr %l140, !tbaa !24
  %t302 = mul i64 %t301, 1
  %t303 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l141, !tbaa !27
  %t306 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = load i64, ptr %l140, !tbaa !24
  %t311 = mul i64 %t310, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t307, ptr %t309, i64 %t311, i1 false)
  %t312 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t312, ptr %l139, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t313 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t313, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %lp3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca i1
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = load ptr, ptr %lp3
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %lp3
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb2
bb2:
  %t13 = load i1, ptr %l8, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t18 = xor i1 %a2, true
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %lp3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l16
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb25
bb25:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Module"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l9, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t3)
  store { i64, ptr } %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  br label %bb3
bb3:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb6:
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l21, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/doc:Module", ptr %t47, i64 %t44
  %t49 = load %"compiler/doc:Module", ptr %t48
  store %"compiler/doc:Module" %t49, ptr %l6
  store ptr %l2, ptr %l24, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v1, ptr %s3, { i64, ptr } %t52)
  store { i64, ptr } %t54, ptr %l26
  br label %bb8
bb8:
  %t55 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s3, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l28
  br label %bb9
bb9:
  %t59 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t59, i64 %t60)
  %t76 = getelementptr i8, ptr %t75, i64 %t60
  call void @olang_textcopy(ptr %t76, ptr %t62, i64 %t63)
  %t77 = getelementptr i8, ptr %t76, i64 %t63
  call void @olang_textcopy(ptr %t77, ptr %t65, i64 %t66)
  %t78 = getelementptr i8, ptr %t77, i64 %t66
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = getelementptr i8, ptr %t78, i64 %t70
  call void @olang_textcopy(ptr %t79, ptr %t72, i64 %t73)
  %t80 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t75, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t89, { i64, ptr } %t88)
  br label %bb10
bb10:
  %t91 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = call { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v1, ptr %s3, { i64, ptr } %t92)
  store { i64, ptr } %t94, ptr %l32
  br label %bb11
bb11:
  %t95 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t95, ptr %l7, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t96, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t98, ptr %l34
  br label %bb12
bb12:
  %t99 = load i1, ptr %l34, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l2, ptr %l36, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s3, ptr %s5, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l38
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t105 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = getelementptr i8, ptr %t111, i64 %t106
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t122, { i64, ptr } %t121)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l4, !tbaa !24
  br label %bb4
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb21
bb21:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l45, !tbaa !27
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t132, ptr %l47
  br label %bb22
bb22:
  %t133 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t135 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t133, { i64, ptr } %t134)
  store { i64, ptr } %t135, ptr %l48
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca %"compiler/doc:Entry"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"compiler/doc:Entry"
  %l13 = alloca %"compiler/doc:Entry"
  %l14 = alloca i32
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t11 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i1 true)
  %t12 = extractvalue { i32, %"compiler/doc:Entry" } %t11, 1
  %t13 = extractvalue { i32, %"compiler/doc:Entry" } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store %"compiler/doc:Entry" %t12, ptr %l13
  br label %bb1
bb1:
  %t16 = load %"compiler/doc:Entry", ptr %l13
  store %"compiler/doc:Entry" %t16, ptr %l7
  br label %bb3
bb2:
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t25, 0
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb3:
  %t28 = load %"compiler/doc:Entry", ptr %l7
  store %"compiler/doc:Entry" %t28, ptr %l5
  %t29 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t30, ptr %l6
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s0, ptr %s0, ptr %l6, ptr %l5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb5
bb5:
  %t34 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l6)
  store { i64, ptr } %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %l21, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t49, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t51 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t50, 1
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t5, i64 0)
  store i64 %t7, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t13, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t23, i64 %t24)
  store i64 %t27, ptr %l21
  br label %bb10
bb10:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb15:
  %t45 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t52)
  store i1 %t54, ptr %l30
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l1, !tbaa !24
  br label %bb21
bb21:
  br label %bb6
bb22:
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  br i1 %t66, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l40, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = icmp slt i64 %t84, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t94, i64 %t95)
  store i64 %t98, ptr %l49
  br label %bb28
bb27:
  br label %bb48
bb28:
  %t99 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb31:
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = load i64, ptr %l49, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t119)
  store { i64, ptr } %t121, ptr %l55
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb35:
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t122, ptr %l4, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t125, ptr %l57
  br label %bb36
bb36:
  %t126 = load i1, ptr %l57, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t131, ptr %l61
  br label %bb39
bb38:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb40
bb39:
  %t132 = load i1, ptr %l61, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb40
bb40:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t136, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t138, ptr %l65
  br label %bb43
bb42:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb44
bb43:
  %t139 = load i1, ptr %l65, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t142 = load i1, ptr %l63, !tbaa !21
  br i1 %t142, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t143, ptr %l68, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l69, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l70, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l69, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t159 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t159, ptr %l71
  br label %bb49
bb49:
  %t160 = load %"std/prelude/text:StringBuilder", ptr %l71
  store %"std/prelude/text:StringBuilder" %t160, ptr %l5
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %l6, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb52:
  br label %bb53
bb53:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t171, i64 %t172)
  store i64 %t175, ptr %l79
  br label %bb54
bb54:
  %t176 = load i64, ptr %l79, !tbaa !24
  store i64 %t176, ptr %l7, !tbaa !24
  %t177 = load i64, ptr %l6, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = icmp sgt i64 %t177, %t178
  br i1 %t181, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 10)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  store ptr %l5, ptr %l84, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l85, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  store i64 %t185, ptr %l86, !tbaa !24
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l87, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l88, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb59, label %bb60
bb59:
  %t192 = load i64, ptr %l86, !tbaa !24
  %t193 = load i64, ptr %l87, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb61:
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = load i64, ptr %l88, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb63:
  %t200 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l86, !tbaa !24
  %t203 = load i64, ptr %l87, !tbaa !24
  %t204 = getelementptr i8, ptr %t201, i64 %t202
  %t205 = sub i64 %t203, %t202
  %t206 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t204, 1
  %t209 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l93
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb65:
  %t210 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t217, { i64, ptr } %t216)
  br label %bb66
bb66:
  %t219 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb67:
  br label %bb50
bb68:
  %t224 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t224, ptr %l98
  br label %bb69
bb69:
  %t225 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t225, ptr %l99, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l100, !tbaa !24
  %t228 = load i64, ptr %l100, !tbaa !24
  %t229 = mul i64 %t228, 1
  %t230 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t229)
  %t231 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  store { i64, ptr } %t232, ptr %l101, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = load i64, ptr %l100, !tbaa !24
  %t238 = mul i64 %t237, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t234, ptr %t236, i64 %t238, i1 false)
  %t239 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t239, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t240 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t240, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"compiler/names:Entry"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i32
  %lp24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %l34 = alloca %"compiler/doc:Entry"
  %l40 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca %"compiler/doc:Module"
  %l69 = alloca ptr
  %l70 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i64
  %l117 = alloca %"compiler/names:Entry"
  %l120 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca i1
  %l134 = alloca i64
  %l137 = alloca i1
  %l141 = alloca ptr
  %l148 = alloca i32
  %l151 = alloca i1
  %l153 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca %"compiler/doc:Entry"
  %l178 = alloca %"compiler/doc:Entry"
  %l179 = alloca i32
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l218 = alloca ptr
  %l222 = alloca i64
  %l225 = alloca i1
  %l232 = alloca { i64, ptr }
  %l236 = alloca i1
  %l238 = alloca i1
  %l242 = alloca i64
  %l248 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l260 = alloca %"compiler/doc:Entry"
  %l261 = alloca ptr
  %l263 = alloca i64
  %l265 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"compiler/doc:Module"
  %t171 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l40
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l40, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_df2a3aebcfae1327_f5257898d4c97893)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = extractvalue { i64, ptr } %t34, 0
  %t38 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t36, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l51, !tbaa !27
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l55, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v3, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l57
  br label %bb5
bb5:
  %t68 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t78 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t74)
  store %"compiler/doc:Module" %t78, ptr %l59
  br label %bb6
bb6:
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store ptr %t79, ptr %lp7
  %t80 = load %"compiler/doc:Module", ptr %l59
  %t81 = load ptr, ptr %lp7
  store %"compiler/doc:Module" %t80, ptr %t81
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/load:Loader", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l8, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/names:Resolver", ptr %t99, i32 0, i32 1
  %t102 = load i64, ptr %l3, !tbaa !24
  %t105 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l69
  br label %bb7
bb7:
  %t106 = load ptr, ptr %l69, !tbaa !29
  store ptr %t106, ptr %l9, !tbaa !29
  %t107 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l70
  br label %bb8
bb8:
  %t108 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/names:Table", ptr %t109, i32 0, i32 0
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l73
  br label %bb9
bb9:
  %t114 = load i64, ptr %l73, !tbaa !24
  store i64 %t114, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb10, label %bb11
bb10:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb15
bb12:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb14
bb14:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb15
bb15:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t159)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t164 = load i64, ptr %l15, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l15, !tbaa !24
  br label %bb16
bb22:
  %t168 = load ptr, ptr %l9, !tbaa !29
  %t169 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t170 = ptrtoint ptr %t169 to i64
  %t172 = getelementptr { ptr, ptr }, ptr %t171, i32 0, i32 0
  store ptr %t168, ptr %t172, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t174 = getelementptr { ptr, ptr }, ptr %t171, i32 0, i32 1
  store ptr %v0, ptr %t174, !tbaa !28
  %t175 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_23, 0
  %t176 = insertvalue { ptr, ptr } %t175, ptr %t171, 1
  %t179 = extractvalue { ptr, ptr } %t176, 0
  %t180 = extractvalue { ptr, ptr } %t176, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l10, ptr %t179, ptr %t180)
  br label %bb23
bb23:
  store ptr %l10, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load i64, ptr %l18, !tbaa !24
  store i64 %t182, ptr %l106, !tbaa !24
  %t183 = load ptr, ptr %l17, !tbaa !29
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t183)
  store i64 %t185, ptr %l108
  br label %bb25
bb25:
  %t186 = load i64, ptr %l106, !tbaa !24
  %t187 = load i64, ptr %l108, !tbaa !24
  %t188 = icmp slt i64 %t186, %t187
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb77
bb27:
  br label %bb28
bb28:
  %t192 = load ptr, ptr %l17, !tbaa !29
  %t193 = load i64, ptr %l18, !tbaa !24
  %t196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t192, i64 %t193)
  store i64 %t196, ptr %l113
  br label %bb29
bb29:
  %t197 = load i64, ptr %l113, !tbaa !24
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/names:Table", ptr %t198, i32 0, i32 0
  %t204 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t200, i64 %t197)
  store %"compiler/names:Entry" %t204, ptr %l117
  br label %bb30
bb30:
  %t205 = load %"compiler/names:Entry", ptr %l117
  store %"compiler/names:Entry" %t205, ptr %l20
  %t206 = load ptr, ptr %l8, !tbaa !29
  %t207 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t206, i32 %t208)
  store { i64, ptr } %t211, ptr %l120
  br label %bb31
bb31:
  %t212 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t213, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l21, !tbaa !27
  %t219 = load i1, ptr %l4, !tbaa !21
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb32, label %bb33
bb32:
  %t223 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t225 = call i1 @compiler_2fdoc_2eExported(ptr %s7, { i64, ptr } %t223)
  store i1 %t225, ptr %l126
  br label %bb34
bb33:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb35
bb34:
  %t226 = load i1, ptr %l126, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l124, !tbaa !21
  br label %bb35
bb35:
  %t229 = load i1, ptr %l124, !tbaa !21
  br i1 %t229, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb37:
  br label %bb38
bb38:
  %t230 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t231 = load i32, ptr %t230
  %t233 = trunc i64 3 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t240 = load i64, ptr %l3, !tbaa !24
  %t241 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t246 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t239, i64 %t240, i32 %t242)
  store i64 %t246, ptr %l134
  br label %bb41
bb40:
  %t247 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t248 = load i32, ptr %t247
  %t250 = trunc i64 2 to i32
  %t251 = icmp eq i32 %t248, %t250
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb62, label %bb63
bb41:
  %t255 = load i64, ptr %l134, !tbaa !24
  store i64 %t255, ptr %l22, !tbaa !24
  %t256 = load i64, ptr %l22, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  br i1 %t258, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb45
bb43:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t263, i64 %t264)
  store ptr %t267, ptr %l141
  br label %bb44
bb44:
  %t268 = load ptr, ptr %l141, !tbaa !29
  %t270 = getelementptr %"compiler/ast:Func", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  %t275 = xor i1 %t273, true
  store i1 %t275, ptr %l137, !tbaa !21
  br label %bb45
bb45:
  %t277 = load i1, ptr %l137, !tbaa !21
  br i1 %t277, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb47:
  br label %bb48
bb48:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l22, !tbaa !24
  %t282 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t278, i64 %t279)
  store i32 %t282, ptr %l148
  br label %bb49
bb49:
  %t283 = load i32, ptr %l148, !tbaa !23
  store i32 %t283, ptr %l23, !tbaa !23
  %t284 = load i32, ptr %l23, !tbaa !23
  %t286 = icmp sge i32 %t284, 0
  br i1 %t286, label %bb50, label %bb51
bb50:
  %t288 = load i1, ptr %l4, !tbaa !21
  br i1 %t288, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb58
bb52:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb57
bb53:
  %t290 = load ptr, ptr %l8, !tbaa !29
  store ptr %t290, ptr %l154, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  %t297 = load i32, ptr %l23, !tbaa !23
  %t300 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t300, ptr %l159
  br label %bb54
bb54:
  %t301 = load ptr, ptr %l154, !tbaa !29
  %t302 = load i32, ptr %l159, !tbaa !23
  %t303 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t301, i32 %t302)
  store { i64, ptr } %t303, ptr %l160
  br label %bb55
bb55:
  %t304 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t305, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t318 = call i1 @compiler_2fdoc_2eExported(ptr %s10, { i64, ptr } %t316)
  store i1 %t318, ptr %l163
  br label %bb56
bb56:
  %t319 = load i1, ptr %l163, !tbaa !21
  store i1 %t319, ptr %l153, !tbaa !21
  br label %bb57
bb57:
  %t320 = load i1, ptr %l153, !tbaa !21
  store i1 %t320, ptr %l151, !tbaa !21
  br label %bb58
bb58:
  %t321 = load i1, ptr %l151, !tbaa !21
  br i1 %t321, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb62:
  %t322 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t323 = load i32, ptr %t322
  %t325 = trunc i64 4 to i32
  %t326 = icmp eq i32 %t323, %t325
  %t328 = xor i1 %t326, true
  store i1 %t328, ptr %l167, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb64
bb64:
  %t330 = load i1, ptr %l167, !tbaa !21
  br i1 %t330, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = load i64, ptr %l3, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t336 = load i1, ptr %l4, !tbaa !21
  %t343 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s7, ptr %v3, ptr %t331, ptr %t332, ptr %a2, i64 %t334, { i64, ptr } %t335, i1 %t336)
  %t344 = extractvalue { i32, %"compiler/doc:Entry" } %t343, 1
  %t345 = extractvalue { i32, %"compiler/doc:Entry" } %t343, 0
  store i32 %t345, ptr %l179
  %t346 = icmp ne i32 %t345, 0
  br i1 %t346, label %bb70, label %ok.347
ok.347:
  store %"compiler/doc:Entry" %t344, ptr %l178
  br label %bb69
bb69:
  %t348 = load %"compiler/doc:Entry", ptr %l178
  store %"compiler/doc:Entry" %t348, ptr %l171
  br label %bb74
bb70:
  %t349 = load i32, ptr %l179, !tbaa !23
  %t350 = ashr i32 %t349, 16
  %t352 = icmp eq i32 %t350, 1
  br i1 %t352, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_1c56ca671fe1533f_201d7c6ca50c87eb)
  unreachable
bb73:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb74:
  %t354 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 80, i64 8)
  store ptr %t354, ptr %lp24
  %t355 = load %"compiler/doc:Entry", ptr %l171
  %t356 = load ptr, ptr %lp24
  store %"compiler/doc:Entry" %t355, ptr %t356
  %t357 = load ptr, ptr %lp7
  %t358 = getelementptr %"compiler/doc:Module", ptr %t357, i32 0, i32 3
  %t359 = load ptr, ptr %lp24
  %t360 = load %"compiler/doc:Entry", ptr %t359
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t358, %"compiler/doc:Entry" %t360)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb76:
  %t363 = load i64, ptr %l18, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l18, !tbaa !24
  br label %bb24
bb77:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/check:Checker", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t370)
  br label %bb78
bb78:
  store i64 0, ptr %l25, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t375)
  store i64 %t377, ptr %l190
  br label %bb79
bb79:
  %t378 = load i64, ptr %l190, !tbaa !24
  store i64 %t378, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t379 = load i64, ptr %l26, !tbaa !24
  %t380 = load i64, ptr %l25, !tbaa !24
  %t383 = icmp sgt i64 %t379, %t380
  br i1 %t383, label %bb80, label %bb81
bb80:
  %t385 = load i64, ptr %l27, !tbaa !24
  %t387 = icmp sgt i64 %t385, 0
  br i1 %t387, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb85
bb82:
  %t389 = load i64, ptr %l26, !tbaa !24
  %t390 = load i64, ptr %l25, !tbaa !24
  %t393 = sub i64 %t389, %t390
  %t394 = load i64, ptr %l27, !tbaa !24
  %t397 = add i64 %t393, %t394
  %t399 = sub i64 %t397, 1
  %t400 = load i64, ptr %l27, !tbaa !24
  %t403 = sdiv i64 %t399, %t400
  store i64 %t403, ptr %l197, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb84
bb84:
  %t405 = load i64, ptr %l197, !tbaa !24
  store i64 %t405, ptr %l194, !tbaa !24
  br label %bb85
bb85:
  %t406 = load i64, ptr %l194, !tbaa !24
  store i64 %t406, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb86
bb86:
  %t407 = load i64, ptr %l29, !tbaa !24
  %t408 = load i64, ptr %l28, !tbaa !24
  %t411 = icmp slt i64 %t407, %t408
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb87, label %bb88
bb87:
  br label %bb118
bb88:
  br label %bb89
bb89:
  %t415 = load i64, ptr %l25, !tbaa !24
  %t416 = load i64, ptr %l29, !tbaa !24
  %t417 = load i64, ptr %l27, !tbaa !24
  %t420 = mul i64 %t416, %t417
  %t423 = add i64 %t415, %t420
  store i64 %t423, ptr %l30, !tbaa !24
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t425, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i64, ptr %l30, !tbaa !24
  %t432 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t428, i64 %t429)
  store ptr %t432, ptr %l218
  br label %bb90
bb90:
  %t433 = load ptr, ptr %l218, !tbaa !29
  store ptr %t433, ptr %l31, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t434, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t438 = load i64, ptr %l30, !tbaa !24
  %t441 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t437, i64 %t438)
  store i64 %t441, ptr %l222
  br label %bb91
bb91:
  %t442 = load i64, ptr %l3, !tbaa !24
  %t443 = load i64, ptr %l222, !tbaa !24
  %t445 = icmp ne i64 %t443, %t442
  br i1 %t445, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l225, !tbaa !21
  br label %bb94
bb93:
  %t447 = load ptr, ptr %l31, !tbaa !29
  %t449 = getelementptr %"compiler/ast:Func", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = icmp eq ptr %t450, null
  store i1 %t452, ptr %l225, !tbaa !21
  br label %bb94
bb94:
  %t454 = load i1, ptr %l225, !tbaa !21
  br i1 %t454, label %bb95, label %bb96
bb95:
  br label %bb117
bb96:
  br label %bb97
bb97:
  %t455 = load ptr, ptr %l8, !tbaa !29
  %t456 = load ptr, ptr %l31, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Func", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %t458, !tbaa !23
  %t462 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t455, i32 %t459)
  store { i64, ptr } %t462, ptr %l232
  br label %bb98
bb98:
  %t463 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t466 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t464, i64 %t465)
  %t467 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t469, ptr %lp32
  %t471 = load ptr, ptr %lp32
  store { i64, ptr } %t468, ptr %t471, !tbaa !27
  %t472 = load i1, ptr %l4, !tbaa !21
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb99, label %bb100
bb99:
  %t476 = load ptr, ptr %lp32
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !27
  %t479 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t477)
  store i1 %t479, ptr %l238
  br label %bb101
bb100:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb102
bb101:
  %t480 = load i1, ptr %l238, !tbaa !21
  %t481 = xor i1 %t480, true
  store i1 %t481, ptr %l236, !tbaa !21
  br label %bb102
bb102:
  %t483 = load i1, ptr %l236, !tbaa !21
  br i1 %t483, label %bb103, label %bb104
bb103:
  br label %bb117
bb104:
  br label %bb105
bb105:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i64, ptr %l30, !tbaa !24
  %t488 = call i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %t484, i64 %t485)
  store i64 %t488, ptr %l242
  br label %bb106
bb106:
  %t489 = load i64, ptr %l3, !tbaa !24
  %t490 = load i64, ptr %l242, !tbaa !24
  %t492 = icmp eq i64 %t490, %t489
  br i1 %t492, label %bb107, label %bb108
bb107:
  br label %bb117
bb108:
  br label %bb109
bb109:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t496 = load i64, ptr %l30, !tbaa !24
  %t500 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v3, ptr %t494, ptr %t495, i64 %t496)
  store { i64, ptr } %t500, ptr %l248
  br label %bb110
bb110:
  %t501 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  %t503 = extractvalue { i64, ptr } %t501, 1
  %t504 = mul i64 %t502, 1
  %t505 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t504)
  call void @llvm.memcpy.p0.p0.i64(ptr %t505, ptr %t503, i64 %t504, i1 false)
  %t506 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  %t509 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v3, ptr %v3, { i64, ptr } %t507)
  store { i64, ptr } %t509, ptr %l250
  br label %bb111
bb111:
  %t510 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t510, ptr %lp33
  %t511 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t512 = load ptr, ptr %lp33
  store { i64, ptr } %t511, ptr %t512, !tbaa !27
  %t513 = load ptr, ptr %lp7
  %t514 = getelementptr %"compiler/doc:Module", ptr %t513, i32 0, i32 3
  store ptr %t514, ptr %l251, !tbaa !29
  %t515 = load ptr, ptr %lp33
  %t516 = load { i64, ptr }, ptr %t515, !tbaa !27
  store { i64, ptr } %t516, ptr %l252, !tbaa !27
  %t517 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t518 = load ptr, ptr %l31, !tbaa !29
  %t520 = getelementptr %"compiler/ast:Func", ptr %t518, i32 0, i32 0
  %t521 = getelementptr %"compiler/source:Span", ptr %t520, i32 0, i32 0
  %t522 = load i32, ptr %t521, !tbaa !23
  %t524 = sext i32 %t522 to i64
  %t527 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v3, { i64, ptr } %t517, i64 %t524)
  store { i64, ptr } %t527, ptr %l257
  br label %bb112
bb112:
  %t528 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 0
  %t530 = extractvalue { i64, ptr } %t528, 1
  %t531 = mul i64 %t529, 1
  %t532 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t531)
  call void @llvm.memcpy.p0.p0.i64(ptr %t532, ptr %t530, i64 %t531, i1 false)
  %t533 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t534 = insertvalue { i64, ptr } %t533, ptr %t532, 1
  %t535 = load ptr, ptr %lp32
  %t536 = load { i64, ptr }, ptr %t535, !tbaa !27
  %t537 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t540 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t537, { i64, ptr } %t534, { i64, ptr } %t536)
  store %"compiler/doc:Entry" %t540, ptr %l260
  br label %bb113
bb113:
  %t541 = load ptr, ptr %l251, !tbaa !29
  %t542 = load %"compiler/doc:Entry", ptr %l260
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t541, %"compiler/doc:Entry" %t542)
  br label %bb114
bb114:
  %t543 = load ptr, ptr %lp7
  %t544 = getelementptr %"compiler/doc:Module", ptr %t543, i32 0, i32 3
  store ptr %t544, ptr %l261, !tbaa !29
  %t545 = load ptr, ptr %lp7
  %t546 = getelementptr %"compiler/doc:Module", ptr %t545, i32 0, i32 3
  %t548 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %t546)
  store i64 %t548, ptr %l263
  br label %bb115
bb115:
  %t549 = load i64, ptr %l263, !tbaa !24
  %t550 = sub i64 %t549, 1
  %t551 = load ptr, ptr %l261, !tbaa !29
  %t553 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t551, i64 %t550)
  store %"compiler/doc:Entry" %t553, ptr %l265
  br label %bb116
bb116:
  %t554 = load %"compiler/doc:Entry", ptr %l265
  store %"compiler/doc:Entry" %t554, ptr %l34
  %t555 = load ptr, ptr %l5, !tbaa !29
  %t557 = getelementptr %"compiler/load:Module", ptr %t555, i32 0, i32 4
  %t558 = load i64, ptr %t557, !tbaa !24
  %t560 = getelementptr %"compiler/doc:Entry", ptr %l34, i32 0, i32 3
  store i64 %t558, ptr %t560, !tbaa !24
  %t561 = load ptr, ptr %l31, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Func", ptr %t561, i32 0, i32 0
  %t564 = getelementptr %"compiler/source:Span", ptr %t563, i32 0, i32 0
  %t565 = load i32, ptr %t564, !tbaa !23
  %t567 = sext i32 %t565 to i64
  %t569 = getelementptr %"compiler/doc:Entry", ptr %l34, i32 0, i32 4
  store i64 %t567, ptr %t569, !tbaa !24
  br label %bb117
bb117:
  %t570 = load i64, ptr %l29, !tbaa !24
  %t572 = add i64 %t570, 1
  store i64 %t572, ptr %l29, !tbaa !24
  br label %bb86
bb118:
  %t574 = load ptr, ptr %lp7
  %t575 = load %"compiler/doc:Module", ptr %t574
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/doc:Module" %t575, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca i8
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 47
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i8 46, ptr %l20, !tbaa !22
  br label %bb8
bb7:
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l20, !tbaa !22
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t31, i8 %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb12
bb12:
  %t39 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t39, ptr %l26
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l28, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t55 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2eStyle_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call ptr @__olang_scope_alloc(ptr %t18, i64 %t17)
  call void @olang_textcopy(ptr %t19, ptr %t1, i64 %t2)
  %t20 = getelementptr i8, ptr %t19, i64 %t2
  call void @olang_textcopy(ptr %t20, ptr %t3, i64 %t4)
  %t21 = getelementptr i8, ptr %t20, i64 %t4
  call void @olang_textcopy(ptr %t21, ptr %t6, i64 %t7)
  %t22 = getelementptr i8, ptr %t21, i64 %t7
  call void @olang_textcopy(ptr %t22, ptr %t9, i64 %t10)
  %t23 = getelementptr i8, ptr %t22, i64 %t10
  call void @olang_textcopy(ptr %t23, ptr %t12, i64 %t13)
  %t24 = getelementptr i8, ptr %t23, i64 %t13
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t19, 1
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = extractvalue { i64, ptr } %t26, 0
  %t30 = extractvalue { i64, ptr } %t26, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %t28, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr @G_2ecompiler_2fdoc_2eStyle, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t1, i64 %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t7, i64 %t8)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l18, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb5:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb7:
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %t38)
  store i64 %t40, ptr %l25
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb9:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb19
bb11:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l31, !tbaa !24
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = icmp sle i64 0, %t52
  br i1 %t53, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb14:
  %t55 = load i64, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb16:
  %t59 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb18:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l28, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t90, ptr %l43
  br label %bb23
bb23:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t91, ptr %l6
  store ptr %l6, ptr %l44, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t94, 0
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l50, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load i64, ptr %l46, !tbaa !24
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb26:
  %t107 = load i64, ptr %l49, !tbaa !24
  %t108 = load i64, ptr %l50, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb28:
  %t111 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = load i64, ptr %l49, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s0, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l55
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb30:
  %t121 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t128, { i64, ptr } %t127)
  br label %bb31
bb31:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = icmp slt i64 %t134, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb34:
  br label %bb35
bb35:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = call i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %t144, i64 %t145)
  store i64 %t148, ptr %l66
  br label %bb36
bb36:
  %t149 = load i64, ptr %l66, !tbaa !24
  store i64 %t149, ptr %l8, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l67, !tbaa !27
  %t151 = load i64, ptr %l7, !tbaa !24
  store i64 %t151, ptr %l68, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  store i64 %t152, ptr %l69, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l70, !tbaa !24
  %t155 = load i64, ptr %l68, !tbaa !24
  %t156 = icmp sge i64 %t155, 0
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t158 = load i64, ptr %l68, !tbaa !24
  %t159 = load i64, ptr %l69, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb39:
  %t162 = load i64, ptr %l69, !tbaa !24
  %t163 = load i64, ptr %l70, !tbaa !24
  %t164 = icmp sle i64 %t162, %t163
  br i1 %t164, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb41:
  %t166 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l68, !tbaa !24
  %t169 = load i64, ptr %l69, !tbaa !24
  %t170 = getelementptr i8, ptr %t167, i64 %t168
  %t171 = sub i64 %t169, %t168
  %t172 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  store { i64, ptr } %t173, ptr %l9, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t177 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t175)
  store i1 %t177, ptr %l76
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb43:
  %t178 = load i1, ptr %l76, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb47
bb45:
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l80, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t186 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t184)
  store { i64, ptr } %t186, ptr %l82
  br label %bb46
bb46:
  %t187 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = load i64, ptr %l80, !tbaa !24
  %t191 = sub i64 %t189, %t188
  %t192 = load i64, ptr %l5, !tbaa !24
  %t195 = icmp ne i64 %t191, %t192
  store i1 %t195, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t197 = load i1, ptr %l78, !tbaa !21
  br i1 %t197, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb49:
  br label %bb50
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 10)
  br label %bb51
bb51:
  store ptr %l6, ptr %l88, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t199)
  store { i64, ptr } %t201, ptr %l90
  br label %bb52
bb52:
  %t202 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t209, { i64, ptr } %t208)
  br label %bb53
bb53:
  %t211 = load i64, ptr %l8, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  br label %bb32
bb55:
  %t216 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t216, ptr %l95
  br label %bb56
bb56:
  %t217 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t217, ptr %l96, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l97, !tbaa !24
  %t220 = load i64, ptr %l97, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l98, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l97, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t231, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t232 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 125
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l9, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb45
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp eq i8 %t30, 35
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp ne i8 %t48, 10
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb10
bb18:
  br label %bb44
bb19:
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l36, !tbaa !24
  %t67 = load i64, ptr %l32, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb22:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb24:
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = load i64, ptr %l35, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %t85, { i64, ptr } %t86)
  store i1 %t89, ptr %l42
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_417cf13f3f24fdcf_48c2325066185a1b)
  unreachable
bb26:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb33
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = sub i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = call i1 @compiler_2fdoc_2ewordChar(i8 %t103)
  store i1 %t105, ptr %l51
  br label %bb31
bb31:
  %t106 = load i1, ptr %l51, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l46, !tbaa !21
  store i1 %t109, ptr %l43, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l43, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = add i64 %t111, %t114
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t123 = icmp sge i64 %t117, %t120
  br i1 %t123, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb40
bb36:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb39
bb37:
  %t125 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t125, ptr %l62, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = add i64 %t126, %t129
  %t134 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  %t139 = call i1 @compiler_2fdoc_2ewordChar(i8 %t137)
  store i1 %t139, ptr %l68
  br label %bb38
bb38:
  %t140 = load i1, ptr %l68, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t143 = load i1, ptr %l61, !tbaa !21
  store i1 %t143, ptr %l53, !tbaa !21
  br label %bb40
bb40:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb41, label %bb42
bb41:
  %t145 = load i64, ptr %l3, !tbaa !24
  store i64 %t145, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t147 = load i64, ptr %l3, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l3, !tbaa !24
  br label %bb44
bb44:
  br label %bb1
bb45:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2ecommentColumn(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l2, !tbaa !22
  %t19 = load i8, ptr %l2, !tbaa !22
  %t21 = icmp eq i8 %t19, 34
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 39
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb22
bb10:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp slt i64 %t32, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t47 = load i8, ptr %l2, !tbaa !22
  %t50 = icmp ne i8 %t46, %t47
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = icmp eq i8 %t61, 92
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i64, ptr %l1, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  br label %bb10
bb21:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb45
bb22:
  %t77 = load i8, ptr %l2, !tbaa !22
  %t79 = icmp eq i8 %t77, 35
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp slt i64 %t83, %t86
  br i1 %t89, label %bb25, label %bb26
bb24:
  br label %bb44
bb25:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = load i64, ptr %l1, !tbaa !24
  %t94 = add i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = icmp eq i8 %t99, 35
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l47, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t104, ptr %l54, !tbaa !27
  %t105 = load i64, ptr %l1, !tbaa !24
  %t107 = add i64 %t105, 2
  store i64 %t107, ptr %l56, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t108, 0
  store i64 %t111, ptr %l59, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l60, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = icmp sge i64 %t114, 0
  br i1 %t115, label %bb30, label %bb31
bb29:
  br label %bb43
bb30:
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb32:
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = load i64, ptr %l60, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb34:
  %t125 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = getelementptr i8, ptr %t126, i64 %t127
  %t130 = sub i64 %t128, %t127
  %t131 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t134 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) })
  %t135 = extractvalue { i32, i64 } %t134, 1
  %t136 = extractvalue { i32, i64 } %t134, 0
  store i32 %t136, ptr %l66
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb37, label %ok.138
ok.138:
  store i64 %t135, ptr %l65
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9)
  unreachable
bb36:
  %t139 = load i64, ptr %l65, !tbaa !24
  store i64 %t139, ptr %l53, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb39
bb39:
  %t140 = load i64, ptr %l53, !tbaa !24
  store i64 %t140, ptr %l3, !tbaa !24
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  store i64 -1, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t146 = load i64, ptr %l1, !tbaa !24
  %t148 = add i64 %t146, 2
  %t149 = load i64, ptr %l3, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = add i64 %t152, 2
  store i64 %t154, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb43:
  %t156 = load i64, ptr %l1, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb44:
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb1
bb46:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t8, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = icmp sge i64 1, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = icmp sle i64 1, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb5:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb7:
  %t23 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = getelementptr i8, ptr %t24, i64 1
  %t27 = sub i64 %t25, 1
  %t28 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t33, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb9:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  br label %bb19
bb12:
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb14:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb16:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %t57)
  store { i64, ptr } %t59, ptr %l26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb18:
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l29
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Entry"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l26 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/doc:Entry"
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca %"compiler/doc:Entry"
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l9, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb3
bb3:
  store ptr %l1, ptr %l15, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/doc:Module", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t37, ptr %l18
  br label %bb4
bb4:
  %t38 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t40 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t38, i64 %t39)
  %t48 = getelementptr i8, ptr %t47, i64 %t39
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = getelementptr i8, ptr %t48, i64 %t42
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t58)
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/doc:Module", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t64)
  br label %bb6
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/doc:Module", ptr %t67, i32 0, i32 3
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l26
  br label %bb7
bb7:
  %t72 = load i64, ptr %l26, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb23
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/doc:Module", ptr %t76, i32 0, i32 3
  store ptr %t78, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l31, !tbaa !24
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l33
  br label %bb12
bb12:
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = load i64, ptr %l33, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/doc:Entry" %t94, ptr %l38
  br label %bb16
bb16:
  %t95 = load %"compiler/doc:Entry", ptr %l38
  store %"compiler/doc:Entry" %t95, ptr %l4
  store ptr %l1, ptr %l39, !tbaa !29
  %t96 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t97)
  store { i64, ptr } %t99, ptr %l41
  br label %bb17
bb17:
  %t100 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l43
  br label %bb18
bb18:
  %t104 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t106 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t112 = add i64 %t109, %t111
  %t113 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t110, i64 %t111)
  %t123 = getelementptr i8, ptr %t122, i64 %t111
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t120, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t134, { i64, ptr } %t133)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l3, !tbaa !24
  br label %bb11
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/doc:Module", ptr %t141, i32 0, i32 3
  store ptr %t143, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s9
  %t145 = load i64, ptr %l6, !tbaa !24
  store i64 %t145, ptr %l51, !tbaa !24
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l53
  br label %bb25
bb25:
  %t149 = load i64, ptr %l51, !tbaa !24
  %t150 = load i64, ptr %l53, !tbaa !24
  %t151 = icmp slt i64 %t149, %t150
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t156 = load i64, ptr %l6, !tbaa !24
  %t159 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t155, i64 %t156)
  store %"compiler/doc:Entry" %t159, ptr %l58
  br label %bb29
bb29:
  %t160 = load %"compiler/doc:Entry", ptr %l58
  store %"compiler/doc:Entry" %t160, ptr %l7
  call void @compiler_2fdoc_2eentryHtml(ptr %s0, ptr %s9, ptr %l1, ptr %l7, i1 false)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb31:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l6, !tbaa !24
  br label %bb24
bb32:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/doc:Module", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l64, !tbaa !27
  %t172 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t172, ptr %l66
  br label %bb33
bb33:
  %t173 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t175 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t173, { i64, ptr } %t174)
  store { i64, ptr } %t175, ptr %l67
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/doc:Entry"
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t10 = extractvalue { i64, ptr } %t6, 1
  %t11 = extractvalue { i64, ptr } %t6, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t27)
  br label %bb2
bb2:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/doc:Module", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t35, ptr %l13
  br label %bb3
bb3:
  %t36 = load i1, ptr %l13, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/doc:Module", ptr %t40, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  call void @compiler_2fdoc_2eindented(ptr %s0, ptr %v0, ptr %s2, ptr %l1, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/doc:Module", ptr %t46, i32 0, i32 3
  store ptr %t48, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l21, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l23
  br label %bb10
bb10:
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/doc:Entry" %t64, ptr %l28
  br label %bb14
bb14:
  %t65 = load %"compiler/doc:Entry", ptr %l28
  store %"compiler/doc:Entry" %t65, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb15
bb15:
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s4, ptr %s4, ptr %l1, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb9
bb18:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t74, ptr %l35
  br label %bb19
bb19:
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l37, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t89, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/names:Entry"
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i32
  %l30 = alloca ptr
  %l34 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca i32
  %l73 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i64
  %l83 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l18, !tbaa !27
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l20, !tbaa !24
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb30
bb7:
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = icmp sle i64 0, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb9:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb11:
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 0
  %t33 = sub i64 %t31, 0
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %l17, !tbaa !24
  %t39 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %t36, i64 %t37, { i64, ptr } %t35)
  store i32 %t39, ptr %l25
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb13:
  %t40 = load i32, ptr %l25, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp slt i32 %t41, 0
  br i1 %t43, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l34
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/load:Loader", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t72, 0
  store i64 %t75, ptr %l44, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l45, !tbaa !24
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = icmp sge i64 %t78, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb20:
  %t85 = load i64, ptr %l44, !tbaa !24
  %t86 = load i64, ptr %l45, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  br i1 %t87, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb22:
  %t89 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = load i64, ptr %l44, !tbaa !24
  %t93 = getelementptr i8, ptr %t90, i64 %t91
  %t94 = sub i64 %t92, %t91
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t99 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t97, { i64, ptr } %t96)
  store i32 %t99, ptr %l50
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb24:
  %t100 = load ptr, ptr %l30, !tbaa !29
  %t101 = load i32, ptr %l34, !tbaa !23
  %t102 = load i32, ptr %l50, !tbaa !23
  %t103 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t100, i32 %t101, i32 %t102)
  store i64 %t103, ptr %l51
  br label %bb25
bb25:
  %t104 = load i64, ptr %l51, !tbaa !24
  store i64 %t104, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb29
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l58
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Func", ptr %t117, i32 0, i32 0
  %t120 = getelementptr %"compiler/source:Span", ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = sext i32 %t121 to i64
  store i64 %t123, ptr %l54, !tbaa !24
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load i64, ptr %l54, !tbaa !24
  store i64 %t125, ptr %rv
  br label %ret
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t136)
  store i32 %t139, ptr %l67
  br label %bb31
bb31:
  %t140 = load i32, ptr %l67, !tbaa !23
  store i32 %t140, ptr %l6, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/names:Resolver", ptr %t147, i32 0, i32 1
  %t150 = load i64, ptr %l1, !tbaa !24
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t149, i64 %t150)
  store ptr %t153, ptr %l73
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l73, !tbaa !29
  %t156 = getelementptr %"compiler/names:Table", ptr %t154, i32 0, i32 0
  store ptr %t156, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb33
bb33:
  %t158 = load i64, ptr %l8, !tbaa !24
  store i64 %t158, ptr %l76, !tbaa !24
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l78
  br label %bb34
bb34:
  %t162 = load i64, ptr %l76, !tbaa !24
  %t163 = load i64, ptr %l78, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t168 = load ptr, ptr %l7, !tbaa !29
  %t169 = load i64, ptr %l8, !tbaa !24
  %t172 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store %"compiler/names:Entry" %t172, ptr %l83
  br label %bb38
bb38:
  %t173 = load %"compiler/names:Entry", ptr %l83
  store %"compiler/names:Entry" %t173, ptr %l9
  %t174 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 0
  %t175 = load i32, ptr %t174, !tbaa !23
  %t176 = load i32, ptr %l6, !tbaa !23
  %t179 = icmp eq i32 %t175, %t176
  br i1 %t179, label %bb39, label %bb40
bb39:
  %t181 = getelementptr %"compiler/names:Entry", ptr %l9, i32 0, i32 1
  %t182 = getelementptr %"compiler/source:Span", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  call void @__olang_scope_close(ptr %s0)
  store i64 %t185, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l8, !tbaa !24
  br label %bb33
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca { ptr, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l22 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l11
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t9 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_53, 0
  %t10 = insertvalue { ptr, ptr } %t9, ptr null, 1
  store { ptr, ptr } %t10, ptr %l4
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t12)
  store %"std/prelude/text:LineIter" %t14, ptr %l14
  br label %bb7
bb7:
  %t15 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t15, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l5)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21
ok.21:
  store { i64, ptr } %t18, ptr %l17
  br label %bb9
bb9:
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb14
bb10:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_30bf8a45e8d985ba_f8b3da4d87360d56)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb14:
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t31, ptr %l22
  br label %bb15
bb15:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb16, label %bb17
bb16:
  %t33 = load { ptr, ptr }, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i1, ptr %l3, !tbaa !21
  %t37 = extractvalue { ptr, ptr } %t33, 0
  %t38 = extractvalue { ptr, ptr } %t33, 1
  call void %t37(ptr %t38, ptr %s0, ptr %v0, ptr %l2, ptr %t34, i1 %t35)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb19:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t42, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t44, ptr %l28
  br label %bb20
bb20:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l7, !tbaa !21
  %t47 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t47, ptr %l30
  br label %bb21
bb21:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = icmp sgt i64 %t48, 0
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load i1, ptr %l7, !tbaa !21
  %t52 = load i1, ptr %l3, !tbaa !21
  %t55 = icmp ne i1 %t51, %t52
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb25, label %bb26
bb25:
  %t58 = load { ptr, ptr }, ptr %l4
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i1, ptr %l3, !tbaa !21
  %t62 = extractvalue { ptr, ptr } %t58, 0
  %t63 = extractvalue { ptr, ptr } %t58, 1
  call void %t62(ptr %t63, ptr %s0, ptr %v0, ptr %l2, ptr %t59, i1 %t60)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t67 = load i1, ptr %l7, !tbaa !21
  store i1 %t67, ptr %l3, !tbaa !21
  %t70 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t70, ptr %l42
  br label %bb29
bb29:
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = icmp sgt i64 %t71, 0
  br i1 %t72, label %bb30, label %bb31
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  store ptr %l2, ptr %l45, !tbaa !29
  %t75 = load i1, ptr %l3, !tbaa !21
  br i1 %t75, label %bb34, label %bb35
bb34:
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t78, 0
  store i64 %t81, ptr %l51, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l52, !tbaa !24
  %t84 = icmp sge i64 4, 0
  br i1 %t84, label %bb36, label %bb37
bb35:
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t86, ptr %l47, !tbaa !27
  br label %bb42
bb36:
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = icmp sle i64 4, %t88
  br i1 %t89, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_2b8dd137328a1bcc_379fe1abcfd798d8)
  unreachable
bb38:
  %t91 = load i64, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_2b8dd137328a1bcc_379fe1abcfd798d8)
  unreachable
bb40:
  %t95 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l51, !tbaa !24
  %t98 = getelementptr i8, ptr %t96, i64 4
  %t99 = sub i64 %t97, 4
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } %t101, ptr %l47, !tbaa !27
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_2b8dd137328a1bcc_379fe1abcfd798d8)
  unreachable
bb42:
  %t103 = load ptr, ptr %l45, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t103, { i64, ptr } %t104)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  br label %bb8
bb45:
  %t105 = load { ptr, ptr }, ptr %l4
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i1, ptr %l3, !tbaa !21
  %t109 = extractvalue { ptr, ptr } %t105, 0
  %t110 = extractvalue { ptr, ptr } %t105, 1
  call void %t109(ptr %t110, ptr %s0, ptr %v0, ptr %l2, ptr %t106, i1 %t107)
  br label %bb46
bb46:
  %t114 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t114, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Entry"
  %l12 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/doc:Entry"
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t3, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/doc:Entry", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t13, ptr %l14
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/doc:Entry", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l17
  br label %bb6
bb6:
  %t20 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t20, i64 %t21)
  %t37 = getelementptr i8, ptr %t36, i64 %t21
  call void @olang_textcopy(ptr %t37, ptr %t23, i64 %t24)
  %t38 = getelementptr i8, ptr %t37, i64 %t24
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t36, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t50 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t50, { i64, ptr } %t49)
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/doc:Entry", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %t52, { i64, ptr } %t56)
  br label %bb8
bb8:
  store i1 false, ptr %l4, !tbaa !21
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/doc:Entry", ptr %t59, i32 0, i32 5
  store ptr %t61, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l25, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t64)
  store i64 %t66, ptr %l27
  br label %bb10
bb10:
  %t67 = load i64, ptr %l25, !tbaa !24
  %t68 = load i64, ptr %l27, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t73, i64 %t74)
  store %"compiler/doc:Entry" %t77, ptr %l32
  br label %bb14
bb14:
  %t78 = load %"compiler/doc:Entry", ptr %l32
  store %"compiler/doc:Entry" %t78, ptr %l7
  %t79 = getelementptr %"compiler/doc:Entry", ptr %l7, i32 0, i32 6
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load i1, ptr %l4, !tbaa !21
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t86 = load i1, ptr %l34, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t87, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  %t89 = getelementptr %"compiler/doc:Entry", ptr %l7, i32 0, i32 6
  %t90 = load i1, ptr %t89, !tbaa !21
  store i1 %t90, ptr %l4, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %s4, ptr %t92, ptr %l7, i1 true)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l6, !tbaa !24
  br label %bb9
bb24:
  %t99 = load i1, ptr %l2, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t101, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/doc:Entry"
  %l11 = alloca %"std/prelude/text:LineIter"
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca %"compiler/doc:Entry"
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/doc:Entry", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:LineIter", ptr %l11
  store %"std/prelude/text:LineIter" %t7, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l3)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c35fe19348e7098e_ccc017350f6cb562)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = extractvalue { i64, ptr } %t22, 0
  %t28 = extractvalue { i64, ptr } %t20, 1
  %t29 = extractvalue { i64, ptr } %t20, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = getelementptr i8, ptr %t35, i64 %t29
  call void @olang_textcopy(ptr %t36, ptr %t31, i64 %t32)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t34, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t21, { i64, ptr } %t45)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/doc:Entry", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t53, ptr %l25
  br label %bb12
bb12:
  %t54 = load i1, ptr %l25, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/doc:Entry", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = getelementptr i8, ptr %t69, i64 %t65
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s4, ptr %t57, { i64, ptr } %t61, { i64, ptr } %t79)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  store i1 false, ptr %l5, !tbaa !21
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/doc:Entry", ptr %t83, i32 0, i32 5
  store ptr %t85, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l35, !tbaa !24
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t88)
  store i64 %t90, ptr %l37
  br label %bb18
bb18:
  %t91 = load i64, ptr %l35, !tbaa !24
  %t92 = load i64, ptr %l37, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = call %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t97, i64 %t98)
  store %"compiler/doc:Entry" %t101, ptr %l42
  br label %bb22
bb22:
  %t102 = load %"compiler/doc:Entry", ptr %l42
  store %"compiler/doc:Entry" %t102, ptr %l8
  %t103 = getelementptr %"compiler/doc:Entry", ptr %l8, i32 0, i32 6
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i1, ptr %l5, !tbaa !21
  %t108 = xor i1 %t106, true
  store i1 %t108, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t110 = load i1, ptr %l44, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = extractvalue { i64, ptr } %t112, 0
  %t116 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t114, i64 %t115)
  %t120 = getelementptr i8, ptr %t119, i64 %t115
  call void @olang_textcopy(ptr %t120, ptr %t116, i64 %t117)
  %t121 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t111, { i64, ptr } %t129)
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb29:
  %t132 = getelementptr %"compiler/doc:Entry", ptr %l8, i32 0, i32 6
  %t133 = load i1, ptr %t132, !tbaa !21
  store i1 %t133, ptr %l5, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = extractvalue { i64, ptr } %t136, 0
  %t140 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t138, i64 %t139)
  %t144 = getelementptr i8, ptr %t143, i64 %t139
  call void @olang_textcopy(ptr %t144, ptr %t140, i64 %t141)
  %t145 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t143, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = extractvalue { i64, ptr } %t146, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  call void @compiler_2fdoc_2eentryText(ptr %v0, ptr %s7, ptr %s7, ptr %t135, ptr %l8, { i64, ptr } %t153)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t157 = load i64, ptr %l7, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l7, !tbaa !24
  br label %bb17
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i64
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l9
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_559bec864ce93c2_13178ba825cc9596)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb10
bb10:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb14
bb12:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t24, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t26, ptr %l17
  br label %bb13
bb13:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb16:
  br label %bb17
bb17:
  %t30 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t30, ptr %l19
  br label %bb18
bb18:
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb19, label %bb20
bb19:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t34, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t36, ptr %l23
  br label %bb21
bb20:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb22
bb21:
  %t37 = load i1, ptr %l23, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb22
bb22:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t42 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t42, ptr %l26
  br label %bb26
bb26:
  %t43 = load i64, ptr %l26, !tbaa !24
  %t44 = icmp sgt i64 %t43, 0
  br i1 %t44, label %bb27, label %bb28
bb27:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t47)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb3
bb33:
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t51, ptr %l32
  br label %bb34
bb34:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t52, ptr %l33, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l34, !tbaa !24
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l35, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l11
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_de8f9580e3a2c1b6_8aed4bb0fc26762a)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t22, ptr %l16
  br label %bb10
bb10:
  %t23 = load i1, ptr %l16, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb12:
  br label %bb13
bb13:
  %t25 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t25, ptr %l18
  br label %bb14
bb14:
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  br i1 %t27, label %bb15, label %bb16
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  store ptr %l1, ptr %l21, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t30)
  store { i64, ptr } %t32, ptr %l23
  br label %bb19
bb19:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t33, { i64, ptr } %t34)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb3
bb22:
  %t36 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t36, ptr %l25
  br label %bb23
bb23:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) })
  %t41 = extractvalue { i32, i64 } %t40, 1
  %t42 = extractvalue { i32, i64 } %t40, 0
  store i32 %t42, ptr %l29
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb25, label %ok.44
ok.44:
  store i64 %t41, ptr %l28
  br label %bb24
bb24:
  %t45 = load i64, ptr %l28, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb27
bb27:
  %t46 = load i64, ptr %l26, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb28, label %bb29
bb28:
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = icmp sge i64 0, 0
  br i1 %t57, label %bb30, label %bb31
bb29:
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l32, !tbaa !27
  br label %bb36
bb30:
  %t62 = load i64, ptr %l35, !tbaa !24
  %t63 = icmp sle i64 0, %t62
  br i1 %t63, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6eced34899e0a0b8_e168c2a0bee48e1c)
  unreachable
bb32:
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_6eced34899e0a0b8_e168c2a0bee48e1c)
  unreachable
bb34:
  %t69 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = getelementptr i8, ptr %t70, i64 0
  %t73 = sub i64 %t71, 0
  %t74 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l32, !tbaa !27
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_6eced34899e0a0b8_e168c2a0bee48e1c)
  unreachable
bb36:
  %t83 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l44, !tbaa !24
  %t85 = load i64, ptr %l44, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l45, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t96, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %a1)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb8
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d78f5016d0b28924_cf0ac2a6bee39f28)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb8:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t20, ptr %l14
  br label %bb9
bb9:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t22, i8 10)
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t31 = extractvalue { i64, ptr } %t26, 1
  %t32 = extractvalue { i64, ptr } %t26, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t28, i64 %t29)
  %t38 = getelementptr i8, ptr %t37, i64 %t29
  call void @olang_textcopy(ptr %t38, ptr %t31, i64 %t32)
  %t39 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t24, { i64, ptr } %t48)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb2
bb16:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %lp25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %lp28 = alloca ptr
  %lp29 = alloca ptr
  %l30 = alloca i64
  %l36 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l83 = alloca %"compiler/doc:Entry"
  %l88 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i32
  %l109 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca i64
  %l124 = alloca i64
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i1
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l162 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca ptr
  %l173 = alloca %"compiler/doc:Entry"
  %l175 = alloca i1
  %l177 = alloca { i64, ptr }
  %l180 = alloca i1
  %l182 = alloca i1
  %l188 = alloca %"compiler/doc:Entry"
  %l192 = alloca ptr
  %l196 = alloca i32
  %l199 = alloca i32
  %l200 = alloca i64
  %l206 = alloca ptr
  %l210 = alloca i64
  %l211 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l240 = alloca { i64, ptr }
  %l243 = alloca i1
  %l245 = alloca i1
  %l251 = alloca %"compiler/doc:Entry"
  %l256 = alloca i64
  %l261 = alloca i1
  %l264 = alloca i64
  %l267 = alloca i64
  %l271 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/doc:Entry" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l36
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l36, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_29ad09cfbf0a8af1_8e1d5998f6fbfea5)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/load:Loader", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l8, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t42, ptr %t43, ptr %t44, i64 %t45, { i64, ptr } %t46)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l55
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l54
  br label %bb5
bb5:
  %t57 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t57, ptr %l48, !tbaa !27
  br label %bb7
bb6:
  %t58 = load i32, ptr %l55, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s0)
  %t68 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, i32 %t66, 0
  store { i32, %"compiler/doc:Entry" } %t68, ptr %rv
  br label %ret
bb7:
  %t69 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t69, ptr %l9, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t72 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %s0, { i64, ptr } %t70)
  store { i64, ptr } %t72, ptr %l58
  br label %bb8
bb8:
  %t73 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t74, ptr %l59
  br label %bb9
bb9:
  %t75 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t75, ptr %l10, !tbaa !27
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v3, ptr %t76, i64 %t77, { i64, ptr } %t78)
  store i64 %t82, ptr %l63
  br label %bb10
bb10:
  %t83 = load i64, ptr %l63, !tbaa !24
  store i64 %t83, ptr %l11, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t84, ptr %l64, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t90, ptr %l66
  br label %bb11
bb11:
  %t91 = load i1, ptr %l66, !tbaa !21
  br i1 %t91, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb15
bb13:
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t92, ptr %l68, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %t94, i64 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !37
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t96, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t98, ptr %l70
  br label %bb14
bb14:
  %t99 = load i1, ptr %l70, !tbaa !21
  store i1 %t99, ptr %l67, !tbaa !21
  br label %bb15
bb15:
  %t100 = load i1, ptr %l67, !tbaa !21
  br i1 %t100, label %bb16, label %bb17
bb16:
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t105 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s0, ptr %v4, { i64, ptr } %t103)
  store { i64, ptr } %t105, ptr %l74
  br label %bb18
bb17:
  %t106 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t106, ptr %l76, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = extractvalue { i64, ptr } %t110, 0
  %t114 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t112, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l72, !tbaa !27
  br label %bb19
bb18:
  %t125 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l72, !tbaa !27
  br label %bb19
bb19:
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t135, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t147 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t149 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t147, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, { i64, ptr } %t146)
  store %"compiler/doc:Entry" %t149, ptr %l83
  br label %bb20
bb20:
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 80, i64 8)
  store ptr %t150, ptr %lp13
  %t151 = load %"compiler/doc:Entry", ptr %l83
  %t152 = load ptr, ptr %lp13
  store %"compiler/doc:Entry" %t151, ptr %t152
  %t153 = load i64, ptr %l11, !tbaa !24
  %t155 = icmp sge i64 %t153, 0
  br i1 %t155, label %bb21, label %bb22
bb21:
  %t157 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v4, { i64, ptr } %t157, i64 %t158, i1 true)
  store { i64, ptr } %t161, ptr %l88
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t162 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t170 = load ptr, ptr %lp13
  %t171 = getelementptr %"compiler/doc:Entry", ptr %t170, i32 0, i32 1
  store { i64, ptr } %t168, ptr %t171, !tbaa !27
  br label %bb24
bb24:
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t174 = getelementptr %"compiler/load:Module", ptr %t172, i32 0, i32 4
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = load ptr, ptr %lp13
  %t178 = getelementptr %"compiler/doc:Entry", ptr %t177, i32 0, i32 3
  store i64 %t175, ptr %t178, !tbaa !24
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = load ptr, ptr %lp13
  %t182 = getelementptr %"compiler/doc:Entry", ptr %t181, i32 0, i32 4
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t183, ptr %l93, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %t185, i64 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !37
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t189, ptr %l95
  br label %bb25
bb25:
  %t190 = load i1, ptr %l95, !tbaa !21
  br i1 %t190, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb29
bb27:
  %t191 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t191, ptr %l97, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %t193, i64 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !37
  %t197 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t195, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t197, ptr %l99
  br label %bb28
bb28:
  %t198 = load i1, ptr %l99, !tbaa !21
  store i1 %t198, ptr %l96, !tbaa !21
  br label %bb29
bb29:
  %t199 = load i1, ptr %l96, !tbaa !21
  br i1 %t199, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb32
bb31:
  %t200 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t204 = icmp eq i64 %t202, 1
  store i1 %t204, ptr %l100, !tbaa !21
  br label %bb32
bb32:
  %t206 = load i1, ptr %l100, !tbaa !21
  br i1 %t206, label %bb33, label %bb34
bb33:
  %t207 = load ptr, ptr %lp13
  %t208 = load %"compiler/doc:Entry", ptr %t207
  call void @__olang_scope_close(ptr %s0)
  %t210 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, %"compiler/doc:Entry" %t208, 1
  store { i32, %"compiler/doc:Entry" } %t210, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l3, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t217 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v3, ptr %t211, i64 %t212, { i64, ptr } %t213)
  store i32 %t217, ptr %l108
  br label %bb36
bb36:
  %t218 = load i32, ptr %l108, !tbaa !23
  store i32 %t218, ptr %l14, !tbaa !23
  %t219 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l109
  br label %bb37
bb37:
  %t220 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %l15
  %t221 = load i32, ptr %l14, !tbaa !23
  %t223 = icmp sge i32 %t221, 0
  br i1 %t223, label %bb38, label %bb39
bb38:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l14, !tbaa !23
  %t227 = load i1, ptr %l5, !tbaa !21
  %t231 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %s0, ptr %t225, i32 %t226, i1 %t227)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t231, ptr %l115
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t232 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l15
  br label %bb41
bb41:
  store i1 false, ptr %l16, !tbaa !21
  store i64 1, ptr %l17, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb42, label %bb43
bb42:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb47
bb44:
  %t247 = load i64, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l19, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l124, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb46
bb46:
  %t263 = load i64, ptr %l124, !tbaa !24
  store i64 %t263, ptr %l121, !tbaa !24
  br label %bb47
bb47:
  %t264 = load i64, ptr %l121, !tbaa !24
  store i64 %t264, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t265 = load i64, ptr %l21, !tbaa !24
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb131
bb50:
  br label %bb51
bb51:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l19, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l22, !tbaa !24
  %t283 = load i1, ptr %l16, !tbaa !21
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb52, label %bb53
bb52:
  %t287 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t287, ptr %l145, !tbaa !27
  %t288 = load i64, ptr %l22, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr { i64, ptr }, ptr %t291, i64 %t288
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !37
  %t295 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t293)
  store { i64, ptr } %t295, ptr %l148
  br label %bb54
bb53:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb56
bb54:
  %t296 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t297 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t296, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t297, ptr %l149
  br label %bb55
bb55:
  %t298 = load i1, ptr %l149, !tbaa !21
  store i1 %t298, ptr %l144, !tbaa !21
  br label %bb56
bb56:
  %t299 = load i1, ptr %l144, !tbaa !21
  br i1 %t299, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l16, !tbaa !21
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t302 = load ptr, ptr %l2, !tbaa !29
  %t303 = load i64, ptr %l3, !tbaa !24
  %t304 = load ptr, ptr %lp13
  %t305 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t306 = load i1, ptr %l5, !tbaa !21
  call void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %s0, ptr %t300, ptr %t301, ptr %t302, i64 %t303, ptr %t304, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, i1 %t306)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t314 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t314, ptr %l157, !tbaa !27
  %t315 = load i64, ptr %l22, !tbaa !24
  %t317 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, ptr }, ptr %t318, i64 %t315
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !37
  %t322 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t320)
  store { i64, ptr } %t322, ptr %l160
  br label %bb61
bb61:
  %t323 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t323, ptr %l23, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t326 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t324, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t326, ptr %l162
  br label %bb62
bb62:
  %t327 = load i1, ptr %l162, !tbaa !21
  br i1 %t327, label %bb63, label %bb64
bb63:
  %t328 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t330 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t328, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t330, ptr %l165
  br label %bb65
bb64:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb66
bb65:
  %t331 = load i1, ptr %l165, !tbaa !21
  %t332 = xor i1 %t331, true
  store i1 %t332, ptr %l163, !tbaa !21
  br label %bb66
bb66:
  %t334 = load i1, ptr %l163, !tbaa !21
  br i1 %t334, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb68:
  br label %bb69
bb69:
  %t335 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t337 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t335, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t337, ptr %l168
  br label %bb70
bb70:
  %t338 = load i1, ptr %l168, !tbaa !21
  br i1 %t338, label %bb71, label %bb72
bb71:
  %t339 = load ptr, ptr %lp13
  %t340 = getelementptr %"compiler/doc:Entry", ptr %t339, i32 0, i32 5
  store ptr %t340, ptr %l169, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t341, 1
  %t344 = extractvalue { i64, ptr } %t341, 0
  %t345 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t343, i64 %t344)
  %t346 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t354, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store %"compiler/doc:Entry" %t356, ptr %l173
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t357 = load ptr, ptr %l169, !tbaa !29
  %t358 = load %"compiler/doc:Entry", ptr %l173
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t357, %"compiler/doc:Entry" %t358)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb75:
  %t359 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t359, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t361, ptr %l175
  br label %bb76
bb76:
  %t362 = load i1, ptr %l175, !tbaa !21
  br i1 %t362, label %bb77, label %bb78
bb77:
  %t363 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t365 = call { i64, ptr } @compiler_2fdoc_2emethodName(ptr %s0, ptr %v4, { i64, ptr } %t363)
  store { i64, ptr } %t365, ptr %l177
  br label %bb79
bb78:
  br label %bb106
bb79:
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t366, ptr %lp24
  %t367 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t368 = load ptr, ptr %lp24
  store { i64, ptr } %t367, ptr %t368, !tbaa !27
  %t369 = load i1, ptr %l5, !tbaa !21
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb80, label %bb81
bb80:
  %t373 = load ptr, ptr %lp24
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  %t376 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t374)
  store i1 %t376, ptr %l182
  br label %bb82
bb81:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb83
bb82:
  %t377 = load i1, ptr %l182, !tbaa !21
  %t378 = xor i1 %t377, true
  store i1 %t378, ptr %l180, !tbaa !21
  br label %bb83
bb83:
  %t380 = load i1, ptr %l180, !tbaa !21
  br i1 %t380, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb85:
  br label %bb86
bb86:
  %t381 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = extractvalue { i64, ptr } %t381, 0
  %t385 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t383, i64 %t384)
  %t386 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = extractvalue { i64, ptr } %t387, 1
  %t391 = mul i64 %t389, 1
  %t392 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t391)
  call void @llvm.memcpy.p0.p0.i64(ptr %t392, ptr %t390, i64 %t391, i1 false)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  %t395 = load ptr, ptr %lp24
  %t396 = load { i64, ptr }, ptr %t395, !tbaa !27
  %t399 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t394, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) }, { i64, ptr } %t396)
  store %"compiler/doc:Entry" %t399, ptr %l188
  br label %bb87
bb87:
  %t400 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 80, i64 8)
  store ptr %t400, ptr %lp25
  %t401 = load %"compiler/doc:Entry", ptr %l188
  %t402 = load ptr, ptr %lp25
  store %"compiler/doc:Entry" %t401, ptr %t402
  %t403 = load i32, ptr %l14, !tbaa !23
  %t405 = icmp sge i32 %t403, 0
  br i1 %t405, label %bb88, label %bb89
bb88:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !29
  store ptr %t410, ptr %l192, !tbaa !29
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t415 = load i32, ptr %l14, !tbaa !23
  %t418 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t414, i32 %t415)
  store i32 %t418, ptr %l196
  br label %bb90
bb89:
  br label %bb104
bb90:
  %t419 = load ptr, ptr %l8, !tbaa !29
  %t420 = load ptr, ptr %lp24
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !27
  %t424 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v4, ptr %t419, { i64, ptr } %t421)
  store i32 %t424, ptr %l199
  br label %bb91
bb91:
  %t425 = load ptr, ptr %l192, !tbaa !29
  %t426 = load i32, ptr %l196, !tbaa !23
  %t427 = load i32, ptr %l199, !tbaa !23
  %t428 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t425, i32 %t426, i32 %t427)
  store i64 %t428, ptr %l200
  br label %bb92
bb92:
  %t429 = load i64, ptr %l200, !tbaa !24
  store i64 %t429, ptr %l26, !tbaa !24
  %t430 = load i64, ptr %l26, !tbaa !24
  %t432 = icmp sge i64 %t430, 0
  br i1 %t432, label %bb93, label %bb94
bb93:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t434, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = getelementptr %"compiler/generic:Program", ptr %t437, i32 0, i32 0
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = getelementptr %"compiler/load:Loader", ptr %t440, i32 0, i32 5
  store ptr %t442, ptr %l206, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t447 = load i64, ptr %l26, !tbaa !24
  %t450 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t446, i64 %t447)
  store i64 %t450, ptr %l210
  br label %bb95
bb94:
  br label %bb103
bb95:
  %t451 = load ptr, ptr %l206, !tbaa !29
  %t452 = load i64, ptr %l210, !tbaa !24
  %t453 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t451, i64 %t452)
  store ptr %t453, ptr %l211
  br label %bb96
bb96:
  %t454 = load ptr, ptr %l211, !tbaa !29
  store ptr %t454, ptr %l27, !tbaa !29
  %t455 = load ptr, ptr %l27, !tbaa !29
  %t457 = getelementptr %"compiler/load:Module", ptr %t455, i32 0, i32 6
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = icmp eq ptr %t458, null
  br i1 %t460, label %bb97, label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_bfa8c07d4a324eea_d03e95c21dac21fe)
  unreachable
bb98:
  br label %bb99
bb99:
  %t462 = load ptr, ptr %l27, !tbaa !29
  %t464 = getelementptr %"compiler/load:Module", ptr %t462, i32 0, i32 6
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t468 = getelementptr %"compiler/source:Source", ptr %t465, i32 0, i32 1
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !27
  store { i64, ptr } %t469, ptr %l218, !tbaa !27
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/check:Checker", ptr %t470, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !29
  %t474 = load i64, ptr %l26, !tbaa !24
  %t477 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t473, i64 %t474)
  store ptr %t477, ptr %l222
  br label %bb100
bb100:
  %t478 = load ptr, ptr %l222, !tbaa !29
  %t480 = getelementptr %"compiler/ast:Func", ptr %t478, i32 0, i32 0
  %t481 = getelementptr %"compiler/source:Span", ptr %t480, i32 0, i32 0
  %t482 = load i32, ptr %t481, !tbaa !23
  %t484 = sext i32 %t482 to i64
  %t485 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t487 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v4, { i64, ptr } %t485, i64 %t484)
  store { i64, ptr } %t487, ptr %l226
  br label %bb101
bb101:
  %t488 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t488, 0
  %t490 = extractvalue { i64, ptr } %t488, 1
  %t491 = mul i64 %t489, 1
  %t492 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t491)
  call void @llvm.memcpy.p0.p0.i64(ptr %t492, ptr %t490, i64 %t491, i1 false)
  %t493 = insertvalue { i64, ptr } undef, i64 %t489, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t492, 1
  %t496 = load ptr, ptr %lp25
  %t497 = getelementptr %"compiler/doc:Entry", ptr %t496, i32 0, i32 1
  store { i64, ptr } %t494, ptr %t497, !tbaa !27
  %t498 = load ptr, ptr %l27, !tbaa !29
  %t500 = getelementptr %"compiler/load:Module", ptr %t498, i32 0, i32 4
  %t501 = load i64, ptr %t500, !tbaa !24
  %t503 = load ptr, ptr %lp25
  %t504 = getelementptr %"compiler/doc:Entry", ptr %t503, i32 0, i32 3
  store i64 %t501, ptr %t504, !tbaa !24
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/check:Checker", ptr %t505, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !29
  %t509 = load i64, ptr %l26, !tbaa !24
  %t512 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t508, i64 %t509)
  store ptr %t512, ptr %l233
  br label %bb102
bb102:
  %t513 = load ptr, ptr %l233, !tbaa !29
  %t515 = getelementptr %"compiler/ast:Func", ptr %t513, i32 0, i32 0
  %t516 = getelementptr %"compiler/source:Span", ptr %t515, i32 0, i32 0
  %t517 = load i32, ptr %t516, !tbaa !23
  %t519 = sext i32 %t517 to i64
  %t521 = load ptr, ptr %lp25
  %t522 = getelementptr %"compiler/doc:Entry", ptr %t521, i32 0, i32 4
  store i64 %t519, ptr %t522, !tbaa !24
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t523 = load ptr, ptr %lp13
  %t524 = getelementptr %"compiler/doc:Entry", ptr %t523, i32 0, i32 5
  %t525 = load ptr, ptr %lp25
  %t526 = load %"compiler/doc:Entry", ptr %t525
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t524, %"compiler/doc:Entry" %t526)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb106:
  %t529 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t531 = call { i64, ptr } @compiler_2fdoc_2ememberName(ptr %s0, ptr %v4, { i64, ptr } %t529)
  store { i64, ptr } %t531, ptr %l240
  br label %bb107
bb107:
  %t532 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t532, ptr %lp28
  %t533 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t534 = load ptr, ptr %lp28
  store { i64, ptr } %t533, ptr %t534, !tbaa !27
  %t535 = load i1, ptr %l5, !tbaa !21
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb108, label %bb109
bb108:
  %t539 = load ptr, ptr %lp28
  %t540 = load { i64, ptr }, ptr %t539, !tbaa !27
  %t542 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t540)
  store i1 %t542, ptr %l245
  br label %bb110
bb109:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb111
bb110:
  %t543 = load i1, ptr %l245, !tbaa !21
  %t544 = xor i1 %t543, true
  store i1 %t544, ptr %l243, !tbaa !21
  br label %bb111
bb111:
  %t546 = load i1, ptr %l243, !tbaa !21
  br i1 %t546, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb113:
  br label %bb114
bb114:
  %t547 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t547, 1
  %t550 = extractvalue { i64, ptr } %t547, 0
  %t551 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t549, i64 %t550)
  %t552 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = extractvalue { i64, ptr } %t553, 1
  %t557 = mul i64 %t555, 1
  %t558 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t558, ptr %t556, i64 %t557, i1 false)
  %t559 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  %t561 = load ptr, ptr %lp28
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  %t565 = call %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t560, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) }, { i64, ptr } %t562)
  store %"compiler/doc:Entry" %t565, ptr %l251
  br label %bb115
bb115:
  %t566 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 80, i64 8)
  store ptr %t566, ptr %lp29
  %t567 = load %"compiler/doc:Entry", ptr %l251
  %t568 = load ptr, ptr %lp29
  store %"compiler/doc:Entry" %t567, ptr %t568
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i64, ptr %l3, !tbaa !24
  %t571 = load i32, ptr %l14, !tbaa !23
  %t572 = load ptr, ptr %lp28
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  %t578 = call i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v4, ptr %t569, i64 %t570, i32 %t571, { i64, ptr } %t573)
  store i64 %t578, ptr %l256
  br label %bb116
bb116:
  %t579 = load i64, ptr %l256, !tbaa !24
  store i64 %t579, ptr %l30, !tbaa !24
  %t580 = load i64, ptr %l30, !tbaa !24
  %t582 = icmp sge i64 %t580, 0
  br i1 %t582, label %bb117, label %bb118
bb117:
  %t584 = load i64, ptr %l11, !tbaa !24
  %t586 = icmp slt i64 %t584, 0
  br i1 %t586, label %bb119, label %bb120
bb118:
  br label %bb128
bb119:
  store i1 true, ptr %l261, !tbaa !21
  br label %bb123
bb120:
  %t588 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t589 = load i64, ptr %l30, !tbaa !24
  %t592 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t588, i64 %t589)
  store i64 %t592, ptr %l264
  br label %bb121
bb121:
  %t593 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t594 = load i64, ptr %l11, !tbaa !24
  %t597 = call i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %t593, i64 %t594)
  store i64 %t597, ptr %l267
  br label %bb122
bb122:
  %t598 = load i64, ptr %l264, !tbaa !24
  %t599 = load i64, ptr %l267, !tbaa !24
  %t600 = icmp ne i64 %t598, %t599
  store i1 %t600, ptr %l261, !tbaa !21
  br label %bb123
bb123:
  %t602 = load i1, ptr %l261, !tbaa !21
  br i1 %t602, label %bb124, label %bb125
bb124:
  %t603 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t604 = load i64, ptr %l30, !tbaa !24
  %t607 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v4, { i64, ptr } %t603, i64 %t604, i1 true)
  store { i64, ptr } %t607, ptr %l271
  br label %bb126
bb125:
  br label %bb127
bb126:
  %t608 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t609 = extractvalue { i64, ptr } %t608, 0
  %t610 = extractvalue { i64, ptr } %t608, 1
  %t611 = mul i64 %t609, 1
  %t612 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t611)
  call void @llvm.memcpy.p0.p0.i64(ptr %t612, ptr %t610, i64 %t611, i1 false)
  %t613 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t612, 1
  %t616 = load ptr, ptr %lp29
  %t617 = getelementptr %"compiler/doc:Entry", ptr %t616, i32 0, i32 1
  store { i64, ptr } %t614, ptr %t617, !tbaa !27
  br label %bb127
bb127:
  %t618 = load ptr, ptr %l6, !tbaa !29
  %t620 = getelementptr %"compiler/load:Module", ptr %t618, i32 0, i32 4
  %t621 = load i64, ptr %t620, !tbaa !24
  %t623 = load ptr, ptr %lp29
  %t624 = getelementptr %"compiler/doc:Entry", ptr %t623, i32 0, i32 3
  store i64 %t621, ptr %t624, !tbaa !24
  %t625 = load i64, ptr %l30, !tbaa !24
  %t627 = load ptr, ptr %lp29
  %t628 = getelementptr %"compiler/doc:Entry", ptr %t627, i32 0, i32 4
  store i64 %t625, ptr %t628, !tbaa !24
  br label %bb128
bb128:
  %t629 = load ptr, ptr %lp13
  %t630 = getelementptr %"compiler/doc:Entry", ptr %t629, i32 0, i32 5
  %t631 = load ptr, ptr %lp29
  %t632 = load %"compiler/doc:Entry", ptr %t631
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t630, %"compiler/doc:Entry" %t632)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s7)
  br label %bb130
bb130:
  %t635 = load i64, ptr %l21, !tbaa !24
  %t637 = add i64 %t635, 1
  store i64 %t637, ptr %l21, !tbaa !24
  br label %bb48
bb131:
  %t639 = load ptr, ptr %lp13
  %t640 = load %"compiler/doc:Entry", ptr %t639
  call void @__olang_scope_close(ptr %s0)
  %t642 = insertvalue { i32, %"compiler/doc:Entry" } zeroinitializer, %"compiler/doc:Entry" %t640, 1
  store { i32, %"compiler/doc:Entry" } %t642, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/doc:Entry" }, ptr %rv
  ret { i32, %"compiler/doc:Entry" } %rr
}

define dso_local i64 @compiler_2fdoc_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 10
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = add i64 %t24, 1
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2elineStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l43 = alloca i32
  %l49 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i32
  %l100 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i1
  %l152 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i1
  %l183 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l187 = alloca i1
  %l198 = alloca i64
  %l201 = alloca i64
  %l220 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t17, { i64, ptr } %t18)
  store i32 %t21, ptr %l43
  br label %bb4
bb4:
  %t22 = load i32, ptr %l43, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l49
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 6
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l6, !tbaa !29
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  br i1 %t43, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_301af787a8ab5449_ce9576e6695793ad)
  unreachable
bb7:
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t48 = getelementptr %"compiler/source:Source", ptr %t45, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l61
  br label %bb9
bb9:
  %t61 = load i32, ptr %l61
  %t63 = trunc i64 2 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l64, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l65, !tbaa !24
  %t68 = load ptr, ptr %l4, !tbaa !29
  store ptr %t68, ptr %l66, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l71
  br label %bb12
bb11:
  br label %bb32
bb12:
  %t79 = load ptr, ptr %l66, !tbaa !29
  %t80 = load i32, ptr %l71, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l72
  br label %bb13
bb13:
  %t82 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t83, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load ptr, ptr %l64, !tbaa !29
  %t96 = load i64, ptr %l65, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %s2, ptr %t95, i64 %t96, { i64, ptr } %t94)
  store i64 %t98, ptr %l75
  br label %bb14
bb14:
  %t99 = load i64, ptr %l75, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t105, ptr %l80, !tbaa !27
  %t106 = load i64, ptr %l8, !tbaa !24
  store i64 %t106, ptr %l81, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t107, 0
  store i64 %t110, ptr %l84, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l85, !tbaa !24
  %t113 = load i64, ptr %l81, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = load i64, ptr %l81, !tbaa !24
  %t117 = load i64, ptr %l84, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb20:
  %t120 = load i64, ptr %l84, !tbaa !24
  %t121 = load i64, ptr %l85, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb22:
  %t124 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l81, !tbaa !24
  %t127 = load i64, ptr %l84, !tbaa !24
  %t128 = getelementptr i8, ptr %t125, i64 %t126
  %t129 = sub i64 %t127, %t126
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  %t133 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t131, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l91
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb25, label %ok.137
ok.137:
  store i64 %t134, ptr %l90
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb24:
  %t138 = load i64, ptr %l90, !tbaa !24
  store i64 %t138, ptr %l79, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb27
bb27:
  %t139 = load i64, ptr %l79, !tbaa !24
  store i64 %t139, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = icmp slt i64 %t140, 0
  br i1 %t142, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t146 = load i64, ptr %l8, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t151 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %t145, i64 %t150, { i64, ptr } %t151)
  store i64 %t155, ptr %l100
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t156 = load i64, ptr %l100, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i32, ptr %l2, !tbaa !23
  %t164 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t160, i32 %t161)
  store ptr %t164, ptr %l104
  br label %bb33
bb33:
  %t165 = load ptr, ptr %l104, !tbaa !29
  store ptr %t165, ptr %l10, !tbaa !29
  %t166 = load ptr, ptr %l10, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb36
bb35:
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t172 = getelementptr %"compiler/ast:TypeDecl", ptr %t170, i32 0, i32 3
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  store i1 %t175, ptr %l107, !tbaa !21
  br label %bb36
bb36:
  %t177 = load i1, ptr %l107, !tbaa !21
  br i1 %t177, label %bb37, label %bb38
bb37:
  store i64 -1, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t181 = getelementptr %"compiler/ast:TypeDecl", ptr %t179, i32 0, i32 3
  %t182 = load ptr, ptr %t181, !tbaa !29
  store ptr %t182, ptr %l11, !tbaa !29
  %t184 = load ptr, ptr %l11, !tbaa !29
  store ptr %t184, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t185 = load ptr, ptr %l114, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb40, label %bb41
bb40:
  %t188 = load ptr, ptr %l114, !tbaa !29
  %t189 = load i64, ptr %t188
  %t191 = icmp eq i64 %t189, 1
  store i1 %t191, ptr %l115, !tbaa !21
  br label %bb41
bb41:
  %t192 = load i1, ptr %l115, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr { i64, [6 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { { i64, ptr }, ptr }, ptr %t195, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  br label %bb44
bb43:
  br label %bb54
bb44:
  %t199 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t199, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb46, label %bb47
bb46:
  br label %bb53
bb47:
  br label %bb48
bb48:
  %t213 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t213, ptr %l127, !tbaa !27
  %t214 = load i64, ptr %l14, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  store ptr %t219, ptr %l16, !tbaa !29
  %t221 = load ptr, ptr %l16, !tbaa !29
  %t223 = getelementptr %"compiler/ast:CaseDecl", ptr %t221, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  %t225 = load i32, ptr %l5, !tbaa !23
  %t228 = icmp eq i32 %t224, %t225
  br i1 %t228, label %bb49, label %bb50
bb49:
  %t230 = load ptr, ptr %l16, !tbaa !29
  %t232 = getelementptr %"compiler/ast:CaseDecl", ptr %t230, i32 0, i32 0
  %t233 = getelementptr %"compiler/source:Span", ptr %t232, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = sext i32 %t234 to i64
  store i64 %t236, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t238 = load i64, ptr %l14, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l14, !tbaa !24
  br label %bb45
bb53:
  br label %bb115
bb54:
  %t242 = load ptr, ptr %l11, !tbaa !29
  store ptr %t242, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t243 = load ptr, ptr %l139, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb55, label %bb56
bb55:
  %t246 = load ptr, ptr %l139, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 2
  store i1 %t249, ptr %l140, !tbaa !21
  br label %bb56
bb56:
  %t250 = load i1, ptr %l140, !tbaa !21
  br i1 %t250, label %bb57, label %bb58
bb57:
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr { i64, [6 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t253, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l17, !tbaa !27
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t257 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t257, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l20, !tbaa !24
  br label %bb60
bb60:
  %t263 = load i64, ptr %l19, !tbaa !24
  %t264 = load i64, ptr %l20, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb61, label %bb62
bb61:
  br label %bb68
bb62:
  br label %bb63
bb63:
  %t271 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t271, ptr %l152, !tbaa !27
  %t272 = load i64, ptr %l19, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 %t272
  %t277 = load ptr, ptr %t276, !tbaa !39
  store ptr %t277, ptr %l21, !tbaa !29
  %t279 = load ptr, ptr %l21, !tbaa !29
  %t281 = getelementptr %"compiler/ast:Func", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t283 = load i32, ptr %l5, !tbaa !23
  %t286 = icmp eq i32 %t282, %t283
  br i1 %t286, label %bb64, label %bb65
bb64:
  %t288 = load ptr, ptr %l21, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Func", ptr %t288, i32 0, i32 0
  %t291 = getelementptr %"compiler/source:Span", ptr %t290, i32 0, i32 0
  %t292 = load i32, ptr %t291, !tbaa !23
  %t294 = sext i32 %t292 to i64
  store i64 %t294, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t296 = load i64, ptr %l19, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l19, !tbaa !24
  br label %bb60
bb68:
  br label %bb115
bb69:
  %t300 = load ptr, ptr %l11, !tbaa !29
  store ptr %t300, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t301 = load ptr, ptr %l164, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb70, label %bb71
bb70:
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t305 = load i64, ptr %t304
  %t307 = icmp eq i64 %t305, 0
  store i1 %t307, ptr %l165, !tbaa !21
  br label %bb71
bb71:
  %t308 = load i1, ptr %l165, !tbaa !21
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t311 = getelementptr { i64, [6 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { ptr }, ptr %t311, i32 0, i32 0
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l22, !tbaa !29
  br label %bb74
bb73:
  br label %bb110
bb74:
  %t315 = load ptr, ptr %l22, !tbaa !29
  %t317 = getelementptr %"compiler/ast:StructBody", ptr %t315, i32 0, i32 2
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t322 = icmp eq i64 %t320, 0
  br i1 %t322, label %bb75, label %bb76
bb75:
  store i64 -1, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t325 = load ptr, ptr %l22, !tbaa !29
  %t327 = getelementptr %"compiler/ast:StructBody", ptr %t325, i32 0, i32 2
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  store i64 %t332, ptr %l25, !tbaa !24
  br label %bb78
bb78:
  %t334 = load i64, ptr %l24, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb79, label %bb80
bb79:
  br label %bb109
bb80:
  br label %bb81
bb81:
  %t342 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t342, ptr %l183, !tbaa !27
  %t343 = load i64, ptr %l24, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr ptr, ptr %t346, i64 %t343
  %t348 = load ptr, ptr %t347, !tbaa !39
  store ptr %t348, ptr %l26, !tbaa !29
  %t350 = load ptr, ptr %l26, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t351 = load ptr, ptr %l186, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb82, label %bb83
bb82:
  %t354 = load ptr, ptr %l186, !tbaa !29
  %t355 = load i64, ptr %t354
  %t357 = icmp eq i64 %t355, 1
  store i1 %t357, ptr %l187, !tbaa !21
  br label %bb83
bb83:
  %t358 = load i1, ptr %l187, !tbaa !21
  br i1 %t358, label %bb84, label %bb85
bb84:
  %t359 = load ptr, ptr %l26, !tbaa !29
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", ptr }, ptr %t361, i32 0, i32 1
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l27, !tbaa !29
  br label %bb86
bb85:
  br label %bb102
bb86:
  store i64 0, ptr %l28, !tbaa !24
  %t365 = load ptr, ptr %l27, !tbaa !29
  %t367 = getelementptr %"compiler/ast:VarDecl", ptr %t365, i32 0, i32 0
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  store i64 %t370, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t372 = load i64, ptr %l29, !tbaa !24
  %t373 = load i64, ptr %l28, !tbaa !24
  %t376 = icmp sgt i64 %t372, %t373
  br i1 %t376, label %bb87, label %bb88
bb87:
  %t378 = load i64, ptr %l30, !tbaa !24
  %t380 = icmp sgt i64 %t378, 0
  br i1 %t380, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb92
bb89:
  %t382 = load i64, ptr %l29, !tbaa !24
  %t383 = load i64, ptr %l28, !tbaa !24
  %t386 = sub i64 %t382, %t383
  %t387 = load i64, ptr %l30, !tbaa !24
  %t390 = add i64 %t386, %t387
  %t392 = sub i64 %t390, 1
  %t393 = load i64, ptr %l30, !tbaa !24
  %t396 = sdiv i64 %t392, %t393
  store i64 %t396, ptr %l201, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb91
bb91:
  %t398 = load i64, ptr %l201, !tbaa !24
  store i64 %t398, ptr %l198, !tbaa !24
  br label %bb92
bb92:
  %t399 = load i64, ptr %l198, !tbaa !24
  store i64 %t399, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb93
bb93:
  %t400 = load i64, ptr %l32, !tbaa !24
  %t401 = load i64, ptr %l31, !tbaa !24
  %t404 = icmp slt i64 %t400, %t401
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb94, label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb96
bb96:
  %t408 = load i64, ptr %l28, !tbaa !24
  %t409 = load i64, ptr %l32, !tbaa !24
  %t410 = load i64, ptr %l30, !tbaa !24
  %t413 = mul i64 %t409, %t410
  %t416 = add i64 %t408, %t413
  store i64 %t416, ptr %l33, !tbaa !24
  %t418 = load ptr, ptr %l27, !tbaa !29
  %t420 = getelementptr %"compiler/ast:VarDecl", ptr %t418, i32 0, i32 0
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !27
  store { i64, ptr } %t421, ptr %l220, !tbaa !27
  %t422 = load i64, ptr %l33, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr i32, ptr %t425, i64 %t422
  %t427 = load i32, ptr %t426, !tbaa !33
  %t428 = load i32, ptr %l5, !tbaa !23
  %t431 = icmp eq i32 %t427, %t428
  br i1 %t431, label %bb97, label %bb98
bb97:
  %t433 = load ptr, ptr %l27, !tbaa !29
  %t435 = getelementptr %"compiler/ast:VarDecl", ptr %t433, i32 0, i32 1
  %t436 = load { i64, ptr }, ptr %t435, !tbaa !27
  store { i64, ptr } %t436, ptr %l226, !tbaa !27
  %t437 = load i64, ptr %l33, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr %"compiler/source:Span", ptr %t440, i64 %t437
  %t442 = getelementptr %"compiler/source:Span", ptr %t441, i32 0, i32 0
  %t443 = load i32, ptr %t442, !tbaa !23
  %t445 = sext i32 %t443 to i64
  store i64 %t445, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t447 = load i64, ptr %l32, !tbaa !24
  %t449 = add i64 %t447, 1
  store i64 %t449, ptr %l32, !tbaa !24
  br label %bb93
bb101:
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e)
  unreachable
bb107:
  br label %bb108
bb108:
  %t451 = load i64, ptr %l24, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l24, !tbaa !24
  br label %bb78
bb109:
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_6a9dd6ae82982c7b_35c440a7358a5b8f)
  unreachable
bb115:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t15)
  store i1 %t17, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb12
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t25)
  store i1 %t27, ptr %l15
  br label %bb7
bb7:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 %t31
  %t36 = load i8, ptr %t35, !tbaa !32
  %t38 = icmp eq i8 %t36, 95
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %l6, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l6, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t48, ptr %l24, !tbaa !27
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l26, !tbaa !24
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = load i64, ptr %l25, !tbaa !24
  %t55 = icmp sle i64 0, %t54
  br i1 %t55, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb20:
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb22:
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = getelementptr i8, ptr %t62, i64 0
  %t65 = sub i64 %t63, 0
  %t66 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = add i64 %t15, 2
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l26, !tbaa !24
  %t34 = icmp sge i64 3, 0
  br i1 %t34, label %bb13, label %bb14
bb7:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l16, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb9:
  %t40 = load i64, ptr %l16, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb11:
  %t44 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l16, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l10, !tbaa !27
  br label %bb19
bb12:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb13:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 3, %t53
  br i1 %t54, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb17:
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 3
  %t64 = sub i64 %t62, 3
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l10, !tbaa !27
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb19:
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t68, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t69, %t72
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t83)
  store i1 %t85, ptr %l39
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb31
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t93)
  store i1 %t95, ptr %l44
  br label %bb26
bb26:
  %t96 = load i1, ptr %l44, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp eq i8 %t104, 95
  store i1 %t106, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l45, !tbaa !21
  store i1 %t108, ptr %l35, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l35, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l3, !tbaa !24
  br label %bb35
bb35:
  br label %bb20
bb36:
  %t116 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb39:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb41:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr @G_2ecompiler_2fdoc_2eStyle, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %t4, 1
  %t23 = extractvalue { i64, ptr } %t4, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a1, 1
  %t30 = extractvalue { i64, ptr } %a1, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t6, i64 %t7)
  %t36 = getelementptr i8, ptr %t35, i64 %t7
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca %"compiler/doc:Entry"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/doc:Entry"
  %l40 = alloca %"compiler/doc:Entry"
  %l41 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store ptr %l5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t2 = load i64, ptr %l8, !tbaa !24
  store i64 %t2, ptr %l13, !tbaa !24
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp slt i64 %t6, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load i64, ptr %l20, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t31, i64 %t17)
  store ptr %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t40, i32 %t39)
  store { i64, ptr } %t42, ptr %l31
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t62 = call { i32, %"compiler/doc:Entry" } @compiler_2fdoc_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %v3, ptr %t50, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %t48, i1 %a6)
  %t63 = extractvalue { i32, %"compiler/doc:Entry" } %t62, 1
  %t64 = extractvalue { i32, %"compiler/doc:Entry" } %t62, 0
  store i32 %t64, ptr %l41
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb10, label %ok.66
ok.66:
  store %"compiler/doc:Entry" %t63, ptr %l40
  br label %bb9
bb9:
  %t67 = load %"compiler/doc:Entry", ptr %l40
  store %"compiler/doc:Entry" %t67, ptr %l33
  br label %bb14
bb10:
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  br i1 %t71, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_249cddf00de61241_3c386a7e8fc683d5)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb14:
  %t73 = load %"compiler/doc:Entry", ptr %l33
  store %"compiler/doc:Entry" %t73, ptr %l11
  %t74 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  store i1 true, ptr %t74, !tbaa !21
  %t77 = getelementptr %"compiler/doc:Entry", ptr %a4, i32 0, i32 5
  %t78 = load %"compiler/doc:Entry", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t77, %"compiler/doc:Entry" %t78)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l8, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a1)
  store i32 %t20, ptr %l12
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l21
  br label %bb4
bb4:
  %t43 = load i32, ptr %l21
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l28
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l28, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l33
  br label %bb9
bb9:
  %t69 = load i32, ptr %l33
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb10, label %bb11
bb10:
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l39, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l44
  br label %bb13
bb13:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t93, ptr %l45
  br label %bb14
bb14:
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fdoc_2ewordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/doc:Entry" @compiler_2fdoc_3aEntry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/doc:Entry"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 -1, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = insertvalue %"compiler/doc:Entry" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = insertvalue %"compiler/doc:Entry" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = insertvalue %"compiler/doc:Entry" %t12, { i64, ptr } %t13, 2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = insertvalue %"compiler/doc:Entry" %t14, i64 %t15, 3
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = insertvalue %"compiler/doc:Entry" %t16, i64 %t17, 4
  %t20 = insertvalue %"compiler/doc:Entry" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 5
  %t22 = insertvalue %"compiler/doc:Entry" %t20, i1 false, 6
  store %"compiler/doc:Entry" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Entry", ptr %rv
  ret %"compiler/doc:Entry" %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/doc:Module"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = insertvalue %"compiler/doc:Module" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = insertvalue %"compiler/doc:Module" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = insertvalue %"compiler/doc:Module" %t12, { i64, ptr } %t13, 2
  %t16 = insertvalue %"compiler/doc:Module" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 3
  store %"compiler/doc:Module" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fdoc() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fdoc_2eStyle_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<h1>" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</h1>\0A<ul>\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<li><a href=\22" }>, align 8
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d11 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</code></a>" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</li>\0A" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</ul>\0A" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import\22" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_23(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_ert_req_clear()
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d25 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"body{font-family:system-ui,sans-serif;max-width:52rem;margin:2rem auto;padding:0 1rem;line-height:1.5;" }>, align 8
@.d26 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"color:#1d1d1f;background:#fff}pre{background:#f5f5f7;padding:.5rem .75rem;border-radius:4px;" }>, align 8
@.d27 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"overflow-x:auto;margin:.25rem 0}code,pre{font-family:ui-monospace,Menlo,monospace;font-size:.9em}" }>, align 8
@.d28 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c".doc{margin:.25rem 0 1rem 1rem}.member{margin-left:1.5rem}h2{border-bottom:1px solid #ddd;" }>, align 8
@.d29 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"padding-bottom:.25rem;margin-top:2rem}a{color:#0b57d0}@media(prefers-color-scheme:dark){body{" }>, align 8
@.d30 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"color:#e8e8ea;background:#18181b}pre{background:#26262b}a{color:#8ab4f8}h2{border-color:#333}}" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d36 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"<p><a href=\22index.html\22>index</a></p>\0A<h1>" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</h1>\0A" }>, align 8
@.d38 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<pre>import \22" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22</pre>\0A" }>, align 8
@.d40 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<h2>Index</h2>\0A<ul>\0A" }>, align 8
@.d41 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"<li><a href=\22#" }>, align 8
@.d42 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</code></a></li>\0A" }>, align 8
@.d44 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"</ul>\0A<h2>Items</h2>\0A" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"<div class=\22doc\22>" }>, align 8
define internal void @olang_lambda_53(ptr %env, ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb5
bb5:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s2, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l12
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s4, { i64, ptr } %t18)
  store { i64, ptr } %t20, ptr %l17
  br label %bb10
bb8:
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t42, { i64, ptr } %t41)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb10:
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t46 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t65, { i64, ptr } %t64)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t67)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d56 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d57 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<div class=\22member\22>" }>, align 8
@.d58 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"<pre id=\22" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22>" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</pre>\0A" }>, align 8
@.d61 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"<h3 class=\22member\22>Builders</h3>\0A" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d66 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    builders\0A" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d68 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d69 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d70 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"    [" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c". " }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d77 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d80 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d83 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn (" }>, align 8
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"meets " }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d92 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"<!doctype html>\0A<html lang=\22en\22><head><meta charset=\22utf-8\22>" }>, align 8
@.d93 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"<meta name=\22viewport\22 content=\22width=device-width, initial-scale=1\22>" }>, align 8
@.d94 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"<title>" }>, align 8
@.d95 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</title><style>" }>, align 8
@.d96 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"</style></head><body>\0A" }>, align 8
@.d97 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d98 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<pre>" }>, align 8
@.d99 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</pre>" }>, align 8
@.d100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<p>" }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_39c265aa723c0dcb_f35d02a7366497b7 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_19c80d7aab96fce_b433fa540154765a = external constant [0 x i8]
@olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_89c63e526fea8550_9190d8cdbdd5cacc = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_51c1b9bde331172f_b1d3b315fa602c93 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
@olang_loc_b461083f788c6b86_e65d814f8bc052da = external constant [0 x i8]
@olang_loc_b4b87f1043b41663_258689a2c0d07437 = external constant [0 x i8]
@olang_loc_a37384dcd940e048_c3ba5fc94841a74c = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_df2a3aebcfae1327_f5257898d4c97893 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1c56ca671fe1533f_201d7c6ca50c87eb = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Entry" %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6 = external constant [0 x i8]
@olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903 = external constant [0 x i8]
@olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8 = external constant [0 x i8]
@olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5 = external constant [0 x i8]
@olang_loc_417cf13f3f24fdcf_48c2325066185a1b = external constant [0 x i8]
@olang_loc_e6e1aeb3ff9e985d_a1531f588fabd6d9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a = external constant [0 x i8]
@olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)
@olang_loc_d85afc985d0ab39_76fcb7f235eece65 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1f1e658c6da2070c_2842ab33ef4c4808 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_30bf8a45e8d985ba_f8b3da4d87360d56 = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_2b8dd137328a1bcc_379fe1abcfd798d8 = external constant [0 x i8]
@olang_loc_c35fe19348e7098e_ccc017350f6cb562 = external constant [0 x i8]
@olang_loc_559bec864ce93c2_13178ba825cc9596 = external constant [0 x i8]
@olang_loc_de8f9580e3a2c1b6_8aed4bb0fc26762a = external constant [0 x i8]
@olang_loc_6eced34899e0a0b8_e168c2a0bee48e1c = external constant [0 x i8]
@olang_loc_d78f5016d0b28924_cf0ac2a6bee39f28 = external constant [0 x i8]
@olang_loc_29ad09cfbf0a8af1_8e1d5998f6fbfea5 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_bfa8c07d4a324eea_d03e95c21dac21fe = external constant [0 x i8]
@olang_loc_301af787a8ab5449_ce9576e6695793ad = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0afceaceca5551a_2521421923c730de = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e = external constant [0 x i8]
@olang_loc_6a9dd6ae82982c7b_35c440a7358a5b8f = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_fdfaf893749e1d49_869eafdea154472d = external constant [0 x i8]
@olang_loc_93a5825f4266fe40_3fd51f523aa7a28c = external constant [0 x i8]
@olang_loc_249ae2d6db78c99d_2e3c698f52d646b9 = external constant [0 x i8]
@olang_loc_249cddf00de61241_3c386a7e8fc683d5 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
