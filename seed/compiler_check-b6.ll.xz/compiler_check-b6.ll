; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] }, i1, { i64, [3 x i64] } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32, i64 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:fixedProof" = type { i64, { i64, ptr }, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, i64, i64 }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, i64, i64 }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i32
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l50 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l72 = alloca i32
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l83 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca i32
  %l103 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l111 = alloca i32
  %l112 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l125 = alloca i32
  %l126 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l135 = alloca i32
  %l136 = alloca ptr
  %l141 = alloca i64
  %l145 = alloca { i64, i64, i64 }
  %l149 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l158 = alloca i32
  %l162 = alloca ptr
  %l166 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l175 = alloca ptr
  %l180 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca i32
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l198 = alloca %"compiler/typed:Elem"
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca i32
  %l207 = alloca %"compiler/source:Span"
  %l208 = alloca i32
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l218 = alloca ptr
  %l220 = alloca %"compiler/typed:Elem"
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca %"compiler/source:Span"
  %l233 = alloca ptr
  %l239 = alloca ptr
  %l247 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca { i64, i64, i64 }
  %l258 = alloca ptr
  %l259 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca i64
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l265 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l273 = alloca ptr
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca i32
  %l286 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l292 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t43 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t128 = alloca { i64, [3 x i64] }, align 8
  %t192 = alloca { i64, [3 x i64] }, align 8
  %t231 = alloca { i64, [3 x i64] }, align 8
  %t343 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  %t398 = alloca { i64, [4 x i64] }, align 8
  %t423 = alloca { i64, [4 x i64] }, align 8
  %t448 = alloca { i64, [4 x i64] }, align 8
  %t470 = alloca { i64, [3 x i64] }, align 8
  %t555 = alloca { i64, [3 x i64] }, align 8
  %t591 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 48
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l30
  br label %bb1
bb1:
  %t6 = load i64, ptr %l30, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t12, i32 %t13, i64 %t14)
  store i32 %t18, ptr %l36
  br label %bb2
bb2:
  %t19 = load i32, ptr %l36, !tbaa !23
  store i32 %t19, ptr %l6, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l6, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t20, %"compiler/source:Span" %t21, i32 %t22)
  store i64 %t26, ptr %l40
  br label %bb3
bb3:
  %t27 = load i64, ptr %l40, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l41, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l42
  %t30 = load i64, ptr %l7, !tbaa !24
  %t32 = trunc i64 %t30 to i32
  store i32 %t32, ptr %l45, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t37 = load %"compiler/source:Span", ptr %l1
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v0, ptr %t34, ptr %a2, i32 %t36, %"compiler/source:Span" %t37)
  store ptr %t42, ptr %l50
  br label %bb4
bb4:
  store { i64, [3 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t45 = load %"compiler/source:Span", ptr %l42
  %t46 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t45, 0
  %t47 = load i32, ptr %l45, !tbaa !23
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } %t46, i32 %t47, 1
  %t49 = load ptr, ptr %l50, !tbaa !29
  %t50 = insertvalue { %"compiler/source:Span", i32, ptr } %t48, ptr %t49, 2
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t50, ptr %t51
  %t52 = load { i64, [3 x i64] }, ptr %t43
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t52, ptr %t54
  %t55 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t55, ptr %t54)
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l1
  %t59 = load i32, ptr %l6, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t57, %"compiler/source:Span" %t58, i32 %t59)
  store i64 %t63, ptr %l56
  br label %bb6
bb6:
  %t64 = load i64, ptr %l56, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l57, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l58
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l61, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l6, !tbaa !23
  %t74 = load %"compiler/source:Span", ptr %l1
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t71, ptr %a3, i32 %t73, %"compiler/source:Span" %t74)
  store ptr %t79, ptr %l66
  br label %bb7
bb7:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l58
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l61, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l66, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t92, ptr %t91)
  br label %bb8
bb8:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l69, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t95, ptr %l70
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t96)
  store i32 %t98, ptr %l72
  br label %bb9
bb9:
  %t99 = load ptr, ptr %l69, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l70
  %t101 = load i32, ptr %l72, !tbaa !23
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t99, %"compiler/source:Span" %t100, i32 %t101)
  store i64 %t102, ptr %l73
  br label %bb10
bb10:
  %t103 = load i64, ptr %l73, !tbaa !24
  store i64 %t103, ptr %l9, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l74, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l75
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = trunc i64 %t106 to i32
  store i32 %t108, ptr %l78, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l79, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l80
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l82
  br label %bb11
bb11:
  store i32 22, ptr %l83
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t117 = load i64, ptr %l7, !tbaa !24
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t115, %"compiler/source:Span" %t116, i64 %t117)
  store ptr %t121, ptr %l87
  br label %bb12
bb12:
  %t122 = load ptr, ptr %l79, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l80
  %t124 = load i32, ptr %l82, !tbaa !23
  %t125 = load i32, ptr %l83, !range !{i32 0, i32 54}
  %t126 = load ptr, ptr %l87, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t122, %"compiler/source:Span" %t123, i32 %t124, i32 %t125, ptr %t126, ptr null)
  store ptr %t127, ptr %l88
  br label %bb13
bb13:
  store { i64, [3 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 0
  store i64 0, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l75
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t130, 0
  %t132 = load i32, ptr %l78, !tbaa !23
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t132, 1
  %t134 = load ptr, ptr %l88, !tbaa !29
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t134, 2
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [3 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t137, ptr %t139
  %t140 = load ptr, ptr %l74, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb14
bb14:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t142, %"compiler/source:Span" %t143, i32 %t144)
  store i64 %t148, ptr %l94
  br label %bb15
bb15:
  %t149 = load i64, ptr %l94, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l95, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t151, ptr %l96
  %t152 = load i64, ptr %l10, !tbaa !24
  %t154 = trunc i64 %t152 to i32
  store i32 %t154, ptr %l99, !tbaa !23
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l100, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l101
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t158, ptr %l102, !tbaa !23
  store i32 13, ptr %l103
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i64, ptr %l9, !tbaa !24
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t159, %"compiler/source:Span" %t160, i64 %t161)
  store ptr %t165, ptr %l107
  br label %bb16
bb16:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l108, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t167, ptr %l109
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t168)
  store i32 %t170, ptr %l111
  br label %bb17
bb17:
  store i32 22, ptr %l112
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l1
  %t173 = load i64, ptr %l8, !tbaa !24
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172, i64 %t173)
  store ptr %t177, ptr %l116
  br label %bb18
bb18:
  %t178 = load ptr, ptr %l108, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l109
  %t180 = load i32, ptr %l111, !tbaa !23
  %t181 = load i32, ptr %l112, !range !{i32 0, i32 54}
  %t182 = load ptr, ptr %l116, !tbaa !29
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t178, %"compiler/source:Span" %t179, i32 %t180, i32 %t181, ptr %t182, ptr null)
  store ptr %t183, ptr %l117
  br label %bb19
bb19:
  %t184 = load ptr, ptr %l117, !tbaa !29
  %t185 = load ptr, ptr %l100, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l101
  %t187 = load i32, ptr %l102, !tbaa !23
  %t188 = load i32, ptr %l103, !range !{i32 0, i32 54}
  %t189 = load ptr, ptr %l107, !tbaa !29
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i32 %t187, i32 %t188, ptr %t189, ptr %t184)
  store ptr %t191, ptr %l119
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l96
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t194, 0
  %t196 = load i32, ptr %l99, !tbaa !23
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t196, 1
  %t198 = load ptr, ptr %l119, !tbaa !29
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t198, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t201, ptr %t203
  %t204 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t204, ptr %t203)
  br label %bb21
bb21:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l122, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l123
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t208)
  store i32 %t210, ptr %l125
  br label %bb22
bb22:
  %t211 = load ptr, ptr %l122, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l123
  %t213 = load i32, ptr %l125, !tbaa !23
  %t214 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t211, %"compiler/source:Span" %t212, i32 %t213)
  store i64 %t214, ptr %l126
  br label %bb23
bb23:
  %t215 = load i64, ptr %l126, !tbaa !24
  store i64 %t215, ptr %l11, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l127, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t217, ptr %l128
  %t218 = load i64, ptr %l11, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  store i32 %t220, ptr %l131, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l132, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t223, ptr %l133
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t224)
  store i32 %t226, ptr %l135
  br label %bb24
bb24:
  %t227 = load ptr, ptr %l132, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l133
  %t229 = load i32, ptr %l135, !tbaa !23
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t227, %"compiler/source:Span" %t228, i32 %t229, i64 0)
  store ptr %t230, ptr %l136
  br label %bb25
bb25:
  store { i64, [3 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 0
  store i64 0, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l128
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t235 = load i32, ptr %l131, !tbaa !23
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t235, 1
  %t237 = load ptr, ptr %l136, !tbaa !29
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t237, 2
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t240, ptr %t242
  %t243 = load ptr, ptr %l127, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t243, ptr %t242)
  br label %bb26
bb26:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 48
  %t249 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t247)
  store i64 %t249, ptr %l141
  br label %bb27
bb27:
  %t250 = load i64, ptr %l141, !tbaa !24
  store i64 %t250, ptr %l12, !tbaa !24
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  %t256 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t251, i32 2, %"compiler/source:Span" %t252)
  store { i64, i64, i64 } %t256, ptr %l145
  br label %bb28
bb28:
  %t257 = load { i64, i64, i64 }, ptr %l145
  store { i64, i64, i64 } %t257, ptr %l13
  %t258 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 0
  %t259 = load i64, ptr %t258, !tbaa !24
  store i64 %t259, ptr %l14, !tbaa !24
  %t261 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 1
  %t262 = load i64, ptr %t261, !tbaa !24
  store i64 %t262, ptr %l15, !tbaa !24
  %t264 = getelementptr { i64, i64, i64 }, ptr %l13, i32 0, i32 2
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l16, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l149, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t268, ptr %l150
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load i64, ptr %l10, !tbaa !24
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t269, %"compiler/source:Span" %t270, i64 %t271)
  store ptr %t275, ptr %l154
  br label %bb29
bb29:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l155, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t277, ptr %l156
  %t278 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t278, ptr %l157, !tbaa !23
  store i32 15, ptr %l158
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t281 = load i64, ptr %l11, !tbaa !24
  %t285 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t279, %"compiler/source:Span" %t280, i64 %t281)
  store ptr %t285, ptr %l162
  br label %bb30
bb30:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  %t288 = load i64, ptr %l9, !tbaa !24
  %t292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t286, %"compiler/source:Span" %t287, i64 %t288)
  store ptr %t292, ptr %l166
  br label %bb31
bb31:
  %t293 = load ptr, ptr %l166, !tbaa !29
  %t294 = load ptr, ptr %l155, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l156
  %t296 = load i32, ptr %l157, !tbaa !23
  %t297 = load i32, ptr %l158, !range !{i32 0, i32 54}
  %t298 = load ptr, ptr %l162, !tbaa !29
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t294, %"compiler/source:Span" %t295, i32 %t296, i32 %t297, ptr %t298, ptr %t293)
  store ptr %t300, ptr %l168
  br label %bb32
bb32:
  %t301 = load ptr, ptr %l149, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l150
  %t303 = load ptr, ptr %l154, !tbaa !29
  %t304 = load ptr, ptr %l168, !tbaa !29
  %t305 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t301, %"compiler/source:Span" %t302, ptr %t303, ptr %t304)
  store ptr %t305, ptr %l169
  br label %bb33
bb33:
  %t306 = load ptr, ptr %l169, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l170, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l1
  %t311 = load i64, ptr %l14, !tbaa !24
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v3, ptr %v0, ptr %t308, %"compiler/source:Span" %t309, ptr %t306, i64 %t311)
  store ptr %t316, ptr %l175
  br label %bb34
bb34:
  %t317 = load ptr, ptr %l170, !tbaa !29
  %t318 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t317, ptr %t318)
  br label %bb35
bb35:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %l4, !tbaa !23
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l180
  br label %bb36
bb36:
  %t329 = load i32, ptr %l180, !tbaa !23
  store i32 %t329, ptr %l18, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l181, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t331, ptr %l182
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l183
  %t333 = load i32, ptr %l18, !tbaa !23
  store i32 %t333, ptr %l184, !tbaa !23
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l185
  %t335 = load i32, ptr %l4, !tbaa !23
  store i32 %t335, ptr %l186, !tbaa !23
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  %t338 = load i64, ptr %l7, !tbaa !24
  %t342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t336, %"compiler/source:Span" %t337, i64 %t338)
  store ptr %t342, ptr %l190
  br label %bb37
bb37:
  store { i64, [4 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 0
  store i64 2, ptr %t344
  %t345 = load %"compiler/source:Span", ptr %l185
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t345, 0
  %t347 = load i32, ptr %l186, !tbaa !23
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } %t346, i32 %t347, 1
  %t349 = load ptr, ptr %l190, !tbaa !29
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } %t348, ptr %t349, 2
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t350, ptr %t351
  %t352 = load { i64, [4 x i64] }, ptr %t343
  %t354 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t352, ptr %t354
  store ptr %t354, ptr %l192, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l1
  %t357 = load i64, ptr %l11, !tbaa !24
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t355, %"compiler/source:Span" %t356, i64 %t357)
  store ptr %t361, ptr %l196
  br label %bb38
bb38:
  %t362 = load ptr, ptr %l192, !tbaa !29
  %t363 = load ptr, ptr %l196, !tbaa !29
  %t365 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %t362, ptr %t363, i32 0)
  store %"compiler/typed:Elem" %t365, ptr %l198
  br label %bb39
bb39:
  %t366 = load %"compiler/typed:Elem", ptr %l198
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Elem" %t366, ptr %t367
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 4, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l183
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t370, 0
  %t372 = load i32, ptr %l184, !tbaa !23
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr } %t371, i32 %t372, 1
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr } %t373, ptr %t367, 2
  %t376 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t375, ptr %t376
  %t377 = load { i64, [4 x i64] }, ptr %t368
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t377, ptr %t379
  %t380 = load ptr, ptr %l181, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l182
  %t383 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t380, %"compiler/source:Span" %t381, ptr %t379)
  store ptr %t383, ptr %l202
  br label %bb40
bb40:
  %t384 = load ptr, ptr %l202, !tbaa !29
  store ptr %t384, ptr %l19, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l203, !tbaa !29
  %t386 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t386, ptr %l204
  %t387 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t387, ptr %l205
  %t388 = load i32, ptr %l18, !tbaa !23
  store i32 %t388, ptr %l206, !tbaa !23
  %t389 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t389, ptr %l207
  %t390 = load i32, ptr %l4, !tbaa !23
  store i32 %t390, ptr %l208, !tbaa !23
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l1
  %t393 = load i64, ptr %l8, !tbaa !24
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t391, %"compiler/source:Span" %t392, i64 %t393)
  store ptr %t397, ptr %l212
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t398
  %t399 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 0
  store i64 2, ptr %t399
  %t400 = load %"compiler/source:Span", ptr %l207
  %t401 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t400, 0
  %t402 = load i32, ptr %l208, !tbaa !23
  %t403 = insertvalue { %"compiler/source:Span", i32, ptr } %t401, i32 %t402, 1
  %t404 = load ptr, ptr %l212, !tbaa !29
  %t405 = insertvalue { %"compiler/source:Span", i32, ptr } %t403, ptr %t404, 2
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t405, ptr %t406
  %t407 = load { i64, [4 x i64] }, ptr %t398
  %t409 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t407, ptr %t409
  store ptr %t409, ptr %l214, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load %"compiler/source:Span", ptr %l1
  %t412 = load i64, ptr %l11, !tbaa !24
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t410, %"compiler/source:Span" %t411, i64 %t412)
  store ptr %t416, ptr %l218
  br label %bb42
bb42:
  %t417 = load ptr, ptr %l214, !tbaa !29
  %t418 = load ptr, ptr %l218, !tbaa !29
  %t420 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %t417, ptr %t418, i32 0)
  store %"compiler/typed:Elem" %t420, ptr %l220
  br label %bb43
bb43:
  %t421 = load %"compiler/typed:Elem", ptr %l220
  %t422 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Elem" %t421, ptr %t422
  store { i64, [4 x i64] } zeroinitializer, ptr %t423
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t423, i32 0, i32 0
  store i64 4, ptr %t424
  %t425 = load %"compiler/source:Span", ptr %l205
  %t426 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t425, 0
  %t427 = load i32, ptr %l206, !tbaa !23
  %t428 = insertvalue { %"compiler/source:Span", i32, ptr } %t426, i32 %t427, 1
  %t430 = insertvalue { %"compiler/source:Span", i32, ptr } %t428, ptr %t422, 2
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t423, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t430, ptr %t431
  %t432 = load { i64, [4 x i64] }, ptr %t423
  %t434 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t432, ptr %t434
  %t435 = load ptr, ptr %l203, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l204
  %t438 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t435, %"compiler/source:Span" %t436, ptr %t434)
  store ptr %t438, ptr %l224
  br label %bb44
bb44:
  %t439 = load ptr, ptr %l224, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l225, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t441, ptr %l226
  %t442 = load %"compiler/source:Span", ptr %l1
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t444 = load i64, ptr %l10, !tbaa !24
  %t446 = trunc i64 %t444 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t448
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 0
  store i64 0, ptr %t449
  %t451 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t442, 0
  %t453 = insertvalue { %"compiler/source:Span", i32, i32 } %t451, i32 %t443, 1
  %t455 = insertvalue { %"compiler/source:Span", i32, i32 } %t453, i32 %t446, 2
  %t456 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t455, ptr %t456
  %t457 = load { i64, [4 x i64] }, ptr %t448
  %t459 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t457, ptr %t459
  store ptr %t459, ptr %l233, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  %t462 = load ptr, ptr %l19, !tbaa !29
  %t469 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v3, ptr %v3, ptr %v0, ptr %t460, %"compiler/source:Span" %t461, i32 95, ptr %t462, ptr %t439, i1 false)
  store ptr %t469, ptr %l239
  br label %bb45
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [3 x i64] }, ptr %t470, i32 0, i32 0
  store i64 1, ptr %t471
  %t472 = load %"compiler/source:Span", ptr %l226
  %t473 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t472, 0
  %t474 = load ptr, ptr %l233, !tbaa !29
  %t475 = insertvalue { %"compiler/source:Span", ptr, ptr } %t473, ptr %t474, 1
  %t476 = load ptr, ptr %l239, !tbaa !29
  %t477 = insertvalue { %"compiler/source:Span", ptr, ptr } %t475, ptr %t476, 2
  %t478 = getelementptr { i64, [3 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t477, ptr %t478
  %t479 = load { i64, [3 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t479, ptr %t481
  %t482 = load ptr, ptr %l225, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t482, ptr %t481)
  br label %bb46
bb46:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i64, ptr %l14, !tbaa !24
  %t486 = load i64, ptr %l15, !tbaa !24
  %t487 = load i64, ptr %l16, !tbaa !24
  %t488 = load i64, ptr %l12, !tbaa !24
  %t494 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v3, ptr %t484, i64 %t485, i64 %t486, i64 %t487, i64 %t488)
  store ptr %t494, ptr %l247
  br label %bb47
bb47:
  %t495 = load ptr, ptr %l247, !tbaa !29
  store ptr %t495, ptr %l21, !tbaa !29
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 48
  %t500 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t498)
  store i64 %t500, ptr %l250
  br label %bb48
bb48:
  %t501 = load i64, ptr %l250, !tbaa !24
  store i64 %t501, ptr %l22, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load %"compiler/source:Span", ptr %l1
  %t507 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t502, i32 3, %"compiler/source:Span" %t503)
  store { i64, i64, i64 } %t507, ptr %l254
  br label %bb49
bb49:
  %t508 = load { i64, i64, i64 }, ptr %l254
  store { i64, i64, i64 } %t508, ptr %l23
  %t509 = getelementptr { i64, i64, i64 }, ptr %l23, i32 0, i32 0
  %t510 = load i64, ptr %t509, !tbaa !24
  store i64 %t510, ptr %l24, !tbaa !24
  %t512 = getelementptr { i64, i64, i64 }, ptr %l23, i32 0, i32 1
  %t513 = load i64, ptr %t512, !tbaa !24
  store i64 %t513, ptr %l25, !tbaa !24
  %t515 = getelementptr { i64, i64, i64 }, ptr %l23, i32 0, i32 2
  %t516 = load i64, ptr %t515, !tbaa !24
  store i64 %t516, ptr %l26, !tbaa !24
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l258, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  store ptr %t519, ptr %l259, !tbaa !29
  %t520 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t520, ptr %l260
  %t521 = load i64, ptr %l11, !tbaa !24
  store i64 %t521, ptr %l261, !tbaa !24
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l262, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t523, ptr %l263
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t524)
  store i32 %t526, ptr %l265
  br label %bb50
bb50:
  %t527 = load ptr, ptr %l262, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l263
  %t529 = load i32, ptr %l265, !tbaa !23
  %t530 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t527, %"compiler/source:Span" %t528, i32 %t529, i64 1)
  store ptr %t530, ptr %l266
  br label %bb51
bb51:
  %t531 = load ptr, ptr %l259, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l260
  %t533 = load i64, ptr %l261, !tbaa !24
  %t534 = load ptr, ptr %l266, !tbaa !29
  %t535 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t531, %"compiler/source:Span" %t532, i64 %t533, ptr %t534)
  store ptr %t535, ptr %l267
  br label %bb52
bb52:
  %t536 = load ptr, ptr %l258, !tbaa !29
  %t537 = load ptr, ptr %l267, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t536, ptr %t537)
  br label %bb53
bb53:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i64, ptr %l24, !tbaa !24
  %t540 = load i64, ptr %l25, !tbaa !24
  %t541 = load i64, ptr %l26, !tbaa !24
  %t542 = load i64, ptr %l22, !tbaa !24
  %t548 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v3, ptr %t538, i64 %t539, i64 %t540, i64 %t541, i64 %t542)
  store ptr %t548, ptr %l273
  br label %bb54
bb54:
  %t549 = load ptr, ptr %l273, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l1
  %t552 = load ptr, ptr %l21, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t555
  %t556 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 0
  store i64 4, ptr %t556
  %t558 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t551, 0
  %t560 = insertvalue { %"compiler/source:Span", ptr, ptr } %t558, ptr %t552, 1
  %t562 = insertvalue { %"compiler/source:Span", ptr, ptr } %t560, ptr %t549, 2
  %t563 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t562, ptr %t563
  %t564 = load { i64, [3 x i64] }, ptr %t555
  %t566 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t564, ptr %t566
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t550, ptr %t566)
  br label %bb55
bb55:
  %t569 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t569, ptr %l281
  %t570 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t570, ptr %l282, !tbaa !23
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 48
  %t574 = load i64, ptr %l5, !tbaa !24
  %t577 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t573, i64 %t574)
  store { i64, ptr } %t577, ptr %l286
  br label %bb56
bb56:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load %"compiler/source:Span", ptr %l1
  %t580 = load i64, ptr %l10, !tbaa !24
  %t584 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t578, %"compiler/source:Span" %t579, i64 %t580)
  store ptr %t584, ptr %l290
  br label %bb57
bb57:
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t588 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t586, ptr %t585, i1 false)
  store %"compiler/typed:Seq" %t588, ptr %l292
  br label %bb58
bb58:
  %t589 = load %"compiler/typed:Seq", ptr %l292
  %t590 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t589, ptr %t590
  store { i64, [5 x i64] } zeroinitializer, ptr %t591
  %t592 = getelementptr { i64, [5 x i64] }, ptr %t591, i32 0, i32 0
  store i64 12, ptr %t592
  %t593 = load %"compiler/source:Span", ptr %l281
  %t594 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t593, 0
  %t595 = load i32, ptr %l282, !tbaa !23
  %t596 = insertvalue { %"compiler/source:Span", i32, ptr } %t594, i32 %t595, 1
  %t598 = insertvalue { %"compiler/source:Span", i32, ptr } %t596, ptr %t590, 2
  %t599 = getelementptr { i64, [5 x i64] }, ptr %t591, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t598, ptr %t599
  %t600 = load { i64, [5 x i64] }, ptr %t591
  %t602 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t600, ptr %t602
  store ptr %t602, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l71 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca { i64, [2 x i64] }
  %l86 = alloca i32
  %l89 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca i64
  %l102 = alloca %"compiler/generic:Context"
  %l103 = alloca %"compiler/generic:Context"
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l136 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l144 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %l153 = alloca %"compiler/generic:Context"
  %l164 = alloca ptr
  %l167 = alloca i32
  %l170 = alloca i64
  %l174 = alloca ptr
  %l179 = alloca ptr
  %l183 = alloca ptr
  %l189 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca %"compiler/typed:Block"
  %l212 = alloca i64
  %l215 = alloca i1
  %l218 = alloca i64
  %l229 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca i64
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca i32
  %l237 = alloca i64
  %l245 = alloca { i64, [3 x i64] }
  %l246 = alloca %"compiler/check:ValueAsk"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t133 = alloca { i64, [2 x i64] }, align 8
  %t742 = alloca { i64, [3 x i64] }, align 8
  %t840 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 154
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 21
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load i64, ptr %l21, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  store i1 %t12, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l23, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 3}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l33
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t34 = load i1, ptr %l33, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 3}
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i1, ptr %l45, !tbaa !21
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t62 = load i1, ptr %l42, !tbaa !21
  br i1 %t62, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l48, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb26
bb24:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load i32, ptr %l53, !tbaa !23
  %t79 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t77, i32 %t78)
  store i64 %t79, ptr %l54
  br label %bb25
bb25:
  %t80 = load i64, ptr %l54, !tbaa !24
  %t81 = icmp sgt i64 %t80, 0
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t85, ptr %l57
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l60
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t91 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s3, ptr %s3, ptr %v0, { i64, ptr } %t91, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t93, ptr %l62
  br label %bb30
bb30:
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l57
  %t96 = load %"compiler/diagmsg:Msg", ptr %l62
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t94, %"compiler/source:Span" %t95, %"compiler/diagmsg:Msg" %t96)
  store i64 %t97, ptr %l63
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l65
  br label %bb33
bb33:
  %t101 = load i64, ptr %l65, !tbaa !24
  store i64 %t101, ptr %l6, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 20
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l68
  br label %bb34
bb34:
  %t107 = load i64, ptr %l68, !tbaa !24
  store i64 %t107, ptr %l7, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 154
  store i1 true, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t111)
  store ptr %t113, ptr %l71
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l71, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t117 = getelementptr %"compiler/check:frame", ptr %t115, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  %t120 = load ptr, ptr %l8, !tbaa !29
  %t122 = getelementptr %"compiler/check:frame", ptr %t120, i32 0, i32 2
  %t123 = load i64, ptr %t122, !tbaa !24
  store i64 %t123, ptr %l10, !tbaa !24
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr %"compiler/check:frame", ptr %t125, i32 0, i32 4
  store ptr %t127, ptr %l11, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l78, !tbaa !29
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 7, ptr %t134
  %t136 = insertvalue { i64, i32 } undef, i64 %t130, 0
  %t138 = insertvalue { i64, i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { i64, i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t140, ptr %l81
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l3, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t146, i32 0, i32 %t147, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t150, ptr %l86
  br label %bb36
bb36:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l2
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l81
  %t155 = load i32, ptr %l86, !tbaa !23
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, i32 %t155, i64 %t151, %"compiler/source:Span" %t152)
  store i64 %t158, ptr %l89
  br label %bb37
bb37:
  %t159 = load i64, ptr %l89, !tbaa !24
  store i64 %t159, ptr %l12, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 24
  %t163 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163, i64 1)
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i32, ptr %l3, !tbaa !23
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t166, i64 %t167, i64 %t168, i32 %t169, i32 0)
  store ptr %t174, ptr %l97
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l97, !tbaa !29
  store ptr %t175, ptr %l98, !tbaa !29
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l99, !tbaa !24
  %t179 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t181 = call ptr @__olang_region_make(ptr %v0)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l99, !tbaa !24
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l11, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %t183, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %l102, i64 160, i1 false)
  %t185 = load i64, ptr %l99
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_scope_hold(ptr %t186)
  %t188 = ptrtoint ptr %t187 to i64
  store i64 %t188, ptr %l104, !tbaa !24
  %t189 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t189, label %bb42, label %bb43
bb42:
  %t191 = load i64, ptr %l99
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call ptr @__olang_region_make_part(ptr %t192)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l104, !tbaa !24
  br label %bb43
bb43:
  %t195 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t196 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t195, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l106, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l107, !tbaa !24
  %t200 = load i64, ptr %l107, !tbaa !24
  %t201 = mul i64 %t200, 8
  %t202 = load i64, ptr %l104
  %t203 = inttoptr i64 %t202 to ptr
  %t204 = call ptr @__olang_held_alloc(ptr %t203, i64 %t201)
  %t205 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l108, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l107, !tbaa !24
  %t212 = mul i64 %t211, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t214 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t214, i32 0, i32 0
  store { i64, ptr } %t213, ptr %t215, !tbaa !27
  %t216 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t216, label %bb44, label %bb45
bb44:
  %t218 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t219 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t218, i32 0, i32 0
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t223 = icmp eq i64 %t221, 0
  br i1 %t223, label %bb46, label %bb47
bb45:
  %t225 = load i64, ptr %l99
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = call ptr @__olang_scope_hold(ptr %t226)
  %t228 = ptrtoint ptr %t227 to i64
  store i64 %t228, ptr %l112, !tbaa !24
  %t229 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t229, label %bb48, label %bb49
bb46:
  %t231 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t232, !tbaa !27
  br label %bb47
bb47:
  %t233 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t234 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t233, i32 0, i32 0
  %t235 = load i64, ptr %l104
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = load { i64, ptr }, ptr %t234
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = call ptr @__olang_region_or(ptr %t238, ptr null)
  %t240 = icmp ne ptr %t239, null
  %t241 = select i1 %t240, ptr %t239, ptr null
  call void @__olang_region_settle_in(ptr %t236, ptr %t241)
  br label %bb45
bb48:
  %t242 = load i64, ptr %l99
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = call ptr @__olang_region_make_part(ptr %t243)
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l112, !tbaa !24
  br label %bb49
bb49:
  %t246 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t247 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t246, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l114, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l115, !tbaa !24
  %t251 = load i64, ptr %l115, !tbaa !24
  %t252 = mul i64 %t251, 8
  %t253 = load i64, ptr %l112
  %t254 = inttoptr i64 %t253 to ptr
  %t255 = call ptr @__olang_held_alloc(ptr %t254, i64 %t252)
  %t256 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l116, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l115, !tbaa !24
  %t263 = mul i64 %t262, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t265 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t266 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t265, i32 0, i32 1
  store { i64, ptr } %t264, ptr %t266, !tbaa !27
  %t267 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t267, label %bb50, label %bb51
bb50:
  %t269 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t270 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t269, i32 0, i32 1
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  %t274 = icmp eq i64 %t272, 0
  br i1 %t274, label %bb52, label %bb53
bb51:
  %t276 = load i64, ptr %l99
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = call ptr @__olang_scope_hold(ptr %t277)
  %t279 = ptrtoint ptr %t278 to i64
  store i64 %t279, ptr %l120, !tbaa !24
  %t280 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t280, label %bb54, label %bb55
bb52:
  %t282 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t283 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t282, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t283, !tbaa !27
  br label %bb53
bb53:
  %t284 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t285 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t284, i32 0, i32 1
  %t286 = load i64, ptr %l112
  %t287 = inttoptr i64 %t286 to ptr
  %t288 = load { i64, ptr }, ptr %t285
  %t289 = extractvalue { i64, ptr } %t288, 1
  %t290 = call ptr @__olang_region_or(ptr %t289, ptr null)
  %t291 = icmp ne ptr %t290, null
  %t292 = select i1 %t291, ptr %t290, ptr null
  call void @__olang_region_settle_in(ptr %t287, ptr %t292)
  br label %bb51
bb54:
  %t293 = load i64, ptr %l99
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = call ptr @__olang_region_make_part(ptr %t294)
  %t296 = ptrtoint ptr %t295 to i64
  store i64 %t296, ptr %l120, !tbaa !24
  br label %bb55
bb55:
  %t297 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t298 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t297, i32 0, i32 2
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l122, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l123, !tbaa !24
  %t302 = load i64, ptr %l123, !tbaa !24
  %t303 = mul i64 %t302, 8
  %t304 = load i64, ptr %l120
  %t305 = inttoptr i64 %t304 to ptr
  %t306 = call ptr @__olang_held_alloc(ptr %t305, i64 %t303)
  %t307 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l124, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = load i64, ptr %l123, !tbaa !24
  %t314 = mul i64 %t313, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t310, ptr %t312, i64 %t314, i1 false)
  %t315 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t316 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t317 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t316, i32 0, i32 2
  store { i64, ptr } %t315, ptr %t317, !tbaa !27
  %t318 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t318, label %bb56, label %bb57
bb56:
  %t320 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t321 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t320, i32 0, i32 2
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 0
  %t325 = icmp eq i64 %t323, 0
  br i1 %t325, label %bb58, label %bb59
bb57:
  %t327 = load i64, ptr %l99
  %t328 = inttoptr i64 %t327 to ptr
  %t329 = call ptr @__olang_scope_hold(ptr %t328)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l128, !tbaa !24
  %t331 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t331, label %bb60, label %bb61
bb58:
  %t333 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t334 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t333, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t334, !tbaa !27
  br label %bb59
bb59:
  %t335 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t336 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t335, i32 0, i32 2
  %t337 = load i64, ptr %l120
  %t338 = inttoptr i64 %t337 to ptr
  %t339 = load { i64, ptr }, ptr %t336
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = call ptr @__olang_region_or(ptr %t340, ptr null)
  %t342 = icmp ne ptr %t341, null
  %t343 = select i1 %t342, ptr %t341, ptr null
  call void @__olang_region_settle_in(ptr %t338, ptr %t343)
  br label %bb57
bb60:
  %t344 = load i64, ptr %l99
  %t345 = inttoptr i64 %t344 to ptr
  %t346 = call ptr @__olang_region_make_part(ptr %t345)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l128, !tbaa !24
  br label %bb61
bb61:
  %t348 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t349 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t348, i32 0, i32 0
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  store { i64, ptr } %t350, ptr %l130, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  store i64 %t352, ptr %l131, !tbaa !24
  %t353 = load i64, ptr %l131, !tbaa !24
  %t354 = mul i64 %t353, 8
  %t355 = load i64, ptr %l128
  %t356 = inttoptr i64 %t355 to ptr
  %t357 = call ptr @__olang_held_alloc(ptr %t356, i64 %t354)
  %t358 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l132, !tbaa !27
  %t360 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l131, !tbaa !24
  %t365 = mul i64 %t364, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t361, ptr %t363, i64 %t365, i1 false)
  %t366 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t367 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t368 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t367, i32 0, i32 0
  store { i64, ptr } %t366, ptr %t368, !tbaa !27
  %t369 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t369, label %bb62, label %bb63
bb62:
  %t371 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t372 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t371, i32 0, i32 0
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 0
  %t376 = icmp eq i64 %t374, 0
  br i1 %t376, label %bb64, label %bb65
bb63:
  %t378 = load i64, ptr %l99
  %t379 = inttoptr i64 %t378 to ptr
  %t380 = call ptr @__olang_scope_hold(ptr %t379)
  %t381 = ptrtoint ptr %t380 to i64
  store i64 %t381, ptr %l136, !tbaa !24
  %t382 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t382, label %bb66, label %bb67
bb64:
  %t384 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t385 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t384, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t385, !tbaa !27
  br label %bb65
bb65:
  %t386 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t387 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t386, i32 0, i32 0
  %t388 = load i64, ptr %l128
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = load { i64, ptr }, ptr %t387
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = call ptr @__olang_region_or(ptr %t391, ptr null)
  %t393 = icmp ne ptr %t392, null
  %t394 = select i1 %t393, ptr %t392, ptr null
  call void @__olang_region_settle_in(ptr %t389, ptr %t394)
  br label %bb63
bb66:
  %t395 = load i64, ptr %l99
  %t396 = inttoptr i64 %t395 to ptr
  %t397 = call ptr @__olang_region_make_part(ptr %t396)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l136, !tbaa !24
  br label %bb67
bb67:
  %t399 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t400 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t399, i32 0, i32 1
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l138, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  store i64 %t403, ptr %l139, !tbaa !24
  %t404 = load i64, ptr %l139, !tbaa !24
  %t405 = mul i64 %t404, 8
  %t406 = load i64, ptr %l136
  %t407 = inttoptr i64 %t406 to ptr
  %t408 = call ptr @__olang_held_alloc(ptr %t407, i64 %t405)
  %t409 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  store { i64, ptr } %t410, ptr %l140, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = load i64, ptr %l139, !tbaa !24
  %t416 = mul i64 %t415, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t412, ptr %t414, i64 %t416, i1 false)
  %t417 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t418 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t419 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t418, i32 0, i32 1
  store { i64, ptr } %t417, ptr %t419, !tbaa !27
  %t420 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t420, label %bb68, label %bb69
bb68:
  %t422 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t423 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t422, i32 0, i32 1
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  %t427 = icmp eq i64 %t425, 0
  br i1 %t427, label %bb70, label %bb71
bb69:
  %t429 = load i64, ptr %l99
  %t430 = inttoptr i64 %t429 to ptr
  %t431 = call ptr @__olang_scope_hold(ptr %t430)
  %t432 = ptrtoint ptr %t431 to i64
  store i64 %t432, ptr %l144, !tbaa !24
  %t433 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t433, label %bb72, label %bb73
bb70:
  %t435 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t436 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t435, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t436, !tbaa !27
  br label %bb71
bb71:
  %t437 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t438 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t437, i32 0, i32 1
  %t439 = load i64, ptr %l136
  %t440 = inttoptr i64 %t439 to ptr
  %t441 = load { i64, ptr }, ptr %t438
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = call ptr @__olang_region_or(ptr %t442, ptr null)
  %t444 = icmp ne ptr %t443, null
  %t445 = select i1 %t444, ptr %t443, ptr null
  call void @__olang_region_settle_in(ptr %t440, ptr %t445)
  br label %bb69
bb72:
  %t446 = load i64, ptr %l99
  %t447 = inttoptr i64 %t446 to ptr
  %t448 = call ptr @__olang_region_make_part(ptr %t447)
  %t449 = ptrtoint ptr %t448 to i64
  store i64 %t449, ptr %l144, !tbaa !24
  br label %bb73
bb73:
  %t450 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t451 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t450, i32 0, i32 2
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  store { i64, ptr } %t452, ptr %l146, !tbaa !27
  %t453 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 0
  store i64 %t454, ptr %l147, !tbaa !24
  %t455 = load i64, ptr %l147, !tbaa !24
  %t456 = mul i64 %t455, 8
  %t457 = load i64, ptr %l144
  %t458 = inttoptr i64 %t457 to ptr
  %t459 = call ptr @__olang_held_alloc(ptr %t458, i64 %t456)
  %t460 = insertvalue { i64, ptr } undef, i64 %t455, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  store { i64, ptr } %t461, ptr %l148, !tbaa !27
  %t462 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = load i64, ptr %l147, !tbaa !24
  %t467 = mul i64 %t466, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t463, ptr %t465, i64 %t467, i1 false)
  %t468 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t469 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t470 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t469, i32 0, i32 2
  store { i64, ptr } %t468, ptr %t470, !tbaa !27
  %t471 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t471, label %bb74, label %bb75
bb74:
  %t473 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t474 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t473, i32 0, i32 2
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t475, 0
  %t478 = icmp eq i64 %t476, 0
  br i1 %t478, label %bb76, label %bb77
bb75:
  %t480 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t480, label %bb78, label %bb79
bb76:
  %t482 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t483 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t482, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t483, !tbaa !27
  br label %bb77
bb77:
  %t484 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t485 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t484, i32 0, i32 2
  %t486 = load i64, ptr %l144
  %t487 = inttoptr i64 %t486 to ptr
  %t488 = load { i64, ptr }, ptr %t485
  %t489 = extractvalue { i64, ptr } %t488, 1
  %t490 = call ptr @__olang_region_or(ptr %t489, ptr null)
  %t491 = icmp ne ptr %t490, null
  %t492 = select i1 %t491, ptr %t490, ptr null
  call void @__olang_region_settle_in(ptr %t487, ptr %t492)
  br label %bb75
bb78:
  %t493 = load i64, ptr %l99
  %t494 = inttoptr i64 %t493 to ptr
  %t495 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t496 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t495, i32 0, i32 2
  %t497 = load { i64, ptr }, ptr %t496
  %t498 = extractvalue { i64, ptr } %t497, 1
  %t499 = call ptr @__olang_region_or(ptr %t498, ptr null)
  %t500 = call ptr @__olang_region_home(ptr %t499)
  %t501 = icmp ne ptr %t500, null
  %t502 = select i1 %t501, ptr %t500, ptr null
  %t503 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t504 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t503, i32 0, i32 1
  %t505 = load { i64, ptr }, ptr %t504
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = call ptr @__olang_region_or(ptr %t506, ptr null)
  %t508 = call ptr @__olang_region_home(ptr %t507)
  %t509 = icmp ne ptr %t508, null
  %t510 = select i1 %t509, ptr %t508, ptr %t502
  %t511 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 3
  %t512 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t511, i32 0, i32 0
  %t513 = load { i64, ptr }, ptr %t512
  %t514 = extractvalue { i64, ptr } %t513, 1
  %t515 = call ptr @__olang_region_or(ptr %t514, ptr null)
  %t516 = call ptr @__olang_region_home(ptr %t515)
  %t517 = icmp ne ptr %t516, null
  %t518 = select i1 %t517, ptr %t516, ptr %t510
  %t519 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t520 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t519, i32 0, i32 2
  %t521 = load { i64, ptr }, ptr %t520
  %t522 = extractvalue { i64, ptr } %t521, 1
  %t523 = call ptr @__olang_region_or(ptr %t522, ptr null)
  %t524 = call ptr @__olang_region_home(ptr %t523)
  %t525 = icmp ne ptr %t524, null
  %t526 = select i1 %t525, ptr %t524, ptr %t518
  %t527 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t528 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t527, i32 0, i32 1
  %t529 = load { i64, ptr }, ptr %t528
  %t530 = extractvalue { i64, ptr } %t529, 1
  %t531 = call ptr @__olang_region_or(ptr %t530, ptr null)
  %t532 = call ptr @__olang_region_home(ptr %t531)
  %t533 = icmp ne ptr %t532, null
  %t534 = select i1 %t533, ptr %t532, ptr %t526
  %t535 = getelementptr %"compiler/generic:Context", ptr %l103, i32 0, i32 2
  %t536 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t535, i32 0, i32 0
  %t537 = load { i64, ptr }, ptr %t536
  %t538 = extractvalue { i64, ptr } %t537, 1
  %t539 = call ptr @__olang_region_or(ptr %t538, ptr null)
  %t540 = call ptr @__olang_region_home(ptr %t539)
  %t541 = icmp ne ptr %t540, null
  %t542 = select i1 %t541, ptr %t540, ptr %t534
  call void @__olang_region_settle_in(ptr %t494, ptr %t542)
  br label %bb79
bb79:
  %t543 = load ptr, ptr %l98, !tbaa !29
  %t544 = getelementptr %"compiler/check:frame", ptr %t543, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l153, ptr %t544, i64 160, i1 false)
  %t545 = load ptr, ptr %l98, !tbaa !29
  %t546 = getelementptr %"compiler/check:frame", ptr %t545, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t546, ptr %l103, i64 160, i1 false)
  %t547 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t547, label %bb80, label %bb81
bb80:
  %t549 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t550 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t549, i32 0, i32 2
  %t551 = load { i64, ptr }, ptr %t550
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = call ptr @__olang_region_or(ptr %t552, ptr null)
  %t554 = call ptr @__olang_region_home(ptr %t553)
  %t555 = icmp ne ptr %t554, null
  %t556 = select i1 %t555, ptr %t554, ptr null
  %t557 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t558 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t557, i32 0, i32 1
  %t559 = load { i64, ptr }, ptr %t558
  %t560 = extractvalue { i64, ptr } %t559, 1
  %t561 = call ptr @__olang_region_or(ptr %t560, ptr null)
  %t562 = call ptr @__olang_region_home(ptr %t561)
  %t563 = icmp ne ptr %t562, null
  %t564 = select i1 %t563, ptr %t562, ptr %t556
  %t565 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t566 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t565, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = call ptr @__olang_region_or(ptr %t568, ptr null)
  %t570 = call ptr @__olang_region_home(ptr %t569)
  %t571 = icmp ne ptr %t570, null
  %t572 = select i1 %t571, ptr %t570, ptr %t564
  %t573 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t574 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t573, i32 0, i32 2
  %t575 = load { i64, ptr }, ptr %t574
  %t576 = extractvalue { i64, ptr } %t575, 1
  %t577 = call ptr @__olang_region_or(ptr %t576, ptr null)
  %t578 = call ptr @__olang_region_home(ptr %t577)
  %t579 = icmp ne ptr %t578, null
  %t580 = select i1 %t579, ptr %t578, ptr %t572
  %t581 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t582 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t581, i32 0, i32 1
  %t583 = load { i64, ptr }, ptr %t582
  %t584 = extractvalue { i64, ptr } %t583, 1
  %t585 = call ptr @__olang_region_or(ptr %t584, ptr null)
  %t586 = call ptr @__olang_region_home(ptr %t585)
  %t587 = icmp ne ptr %t586, null
  %t588 = select i1 %t587, ptr %t586, ptr %t580
  %t589 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t590 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t589, i32 0, i32 0
  %t591 = load { i64, ptr }, ptr %t590
  %t592 = extractvalue { i64, ptr } %t591, 1
  %t593 = call ptr @__olang_region_or(ptr %t592, ptr null)
  %t594 = call ptr @__olang_region_home(ptr %t593)
  %t595 = icmp ne ptr %t594, null
  %t596 = select i1 %t595, ptr %t594, ptr %t588
  call void @__olang_region_drop(ptr %t596)
  store %"compiler/generic:Context" zeroinitializer, ptr %l153
  br label %bb81
bb81:
  %t597 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t597, label %bb82, label %bb83
bb82:
  %t599 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t600 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t599, i32 0, i32 2
  %t601 = load { i64, ptr }, ptr %t600
  %t602 = extractvalue { i64, ptr } %t601, 1
  %t603 = call ptr @__olang_region_or(ptr %t602, ptr null)
  %t604 = call ptr @__olang_region_home(ptr %t603)
  %t605 = icmp ne ptr %t604, null
  %t606 = select i1 %t605, ptr %t604, ptr null
  %t607 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t599, i32 0, i32 1
  %t608 = load { i64, ptr }, ptr %t607
  %t609 = extractvalue { i64, ptr } %t608, 1
  %t610 = call ptr @__olang_region_or(ptr %t609, ptr null)
  %t611 = call ptr @__olang_region_home(ptr %t610)
  %t612 = icmp ne ptr %t611, null
  %t613 = select i1 %t612, ptr %t611, ptr %t606
  %t614 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t599, i32 0, i32 0
  %t615 = load { i64, ptr }, ptr %t614
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = call ptr @__olang_region_or(ptr %t616, ptr null)
  %t618 = call ptr @__olang_region_home(ptr %t617)
  %t619 = icmp ne ptr %t618, null
  %t620 = select i1 %t619, ptr %t618, ptr %t613
  call void @__olang_region_drop(ptr %t620)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t599
  br label %bb83
bb83:
  %t621 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t621, label %bb84, label %bb85
bb84:
  %t623 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t624 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t623, i32 0, i32 2
  %t625 = load { i64, ptr }, ptr %t624
  %t626 = extractvalue { i64, ptr } %t625, 1
  %t627 = call ptr @__olang_region_or(ptr %t626, ptr null)
  %t628 = call ptr @__olang_region_home(ptr %t627)
  %t629 = icmp ne ptr %t628, null
  %t630 = select i1 %t629, ptr %t628, ptr null
  %t631 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t623, i32 0, i32 1
  %t632 = load { i64, ptr }, ptr %t631
  %t633 = extractvalue { i64, ptr } %t632, 1
  %t634 = call ptr @__olang_region_or(ptr %t633, ptr null)
  %t635 = call ptr @__olang_region_home(ptr %t634)
  %t636 = icmp ne ptr %t635, null
  %t637 = select i1 %t636, ptr %t635, ptr %t630
  %t638 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t623, i32 0, i32 0
  %t639 = load { i64, ptr }, ptr %t638
  %t640 = extractvalue { i64, ptr } %t639, 1
  %t641 = call ptr @__olang_region_or(ptr %t640, ptr null)
  %t642 = call ptr @__olang_region_home(ptr %t641)
  %t643 = icmp ne ptr %t642, null
  %t644 = select i1 %t643, ptr %t642, ptr %t637
  call void @__olang_region_drop(ptr %t644)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t623
  br label %bb85
bb85:
  %t645 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t645, label %bb86, label %bb87
bb86:
  %t647 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t648 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t647, i32 0, i32 0
  %t649 = load { i64, ptr }, ptr %t648
  %t650 = extractvalue { i64, ptr } %t649, 0
  %t651 = extractvalue { i64, ptr } %t649, 1
  call void @__olang_region_release_part(ptr %t651, i64 %t650)
  store { i64, ptr } zeroinitializer, ptr %t648
  br label %bb87
bb87:
  %t652 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t652, label %bb88, label %bb89
bb88:
  %t654 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t655 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t654, i32 0, i32 1
  %t656 = load { i64, ptr }, ptr %t655
  %t657 = extractvalue { i64, ptr } %t656, 0
  %t658 = extractvalue { i64, ptr } %t656, 1
  call void @__olang_region_release_part(ptr %t658, i64 %t657)
  store { i64, ptr } zeroinitializer, ptr %t655
  br label %bb89
bb89:
  %t659 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t659, label %bb90, label %bb91
bb90:
  %t661 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 2
  %t662 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t661, i32 0, i32 2
  %t663 = load { i64, ptr }, ptr %t662
  %t664 = extractvalue { i64, ptr } %t663, 0
  %t665 = extractvalue { i64, ptr } %t663, 1
  call void @__olang_region_release_part(ptr %t665, i64 %t664)
  store { i64, ptr } zeroinitializer, ptr %t662
  br label %bb91
bb91:
  %t666 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t666, label %bb92, label %bb93
bb92:
  %t668 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t669 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t668, i32 0, i32 0
  %t670 = load { i64, ptr }, ptr %t669
  %t671 = extractvalue { i64, ptr } %t670, 0
  %t672 = extractvalue { i64, ptr } %t670, 1
  call void @__olang_region_release_part(ptr %t672, i64 %t671)
  store { i64, ptr } zeroinitializer, ptr %t669
  br label %bb93
bb93:
  %t673 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t673, label %bb94, label %bb95
bb94:
  %t675 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t676 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t675, i32 0, i32 1
  %t677 = load { i64, ptr }, ptr %t676
  %t678 = extractvalue { i64, ptr } %t677, 0
  %t679 = extractvalue { i64, ptr } %t677, 1
  call void @__olang_region_release_part(ptr %t679, i64 %t678)
  store { i64, ptr } zeroinitializer, ptr %t676
  br label %bb95
bb95:
  %t680 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t680, label %bb96, label %bb97
bb96:
  %t682 = getelementptr %"compiler/generic:Context", ptr %l153, i32 0, i32 3
  %t683 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t682, i32 0, i32 2
  %t684 = load { i64, ptr }, ptr %t683
  %t685 = extractvalue { i64, ptr } %t684, 0
  %t686 = extractvalue { i64, ptr } %t684, 1
  call void @__olang_region_release_part(ptr %t686, i64 %t685)
  store { i64, ptr } zeroinitializer, ptr %t683
  br label %bb97
bb97:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t689 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t687)
  store ptr %t689, ptr %l164
  br label %bb98
bb98:
  %t690 = load %"compiler/source:Span", ptr %l2
  %t691 = load ptr, ptr %l164, !tbaa !29
  %t694 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t691, i32 -1, i32 0, %"compiler/source:Span" %t690)
  store i32 %t694, ptr %l167
  br label %bb99
bb99:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/check:Checker", ptr %t695, i32 0, i32 48
  %t699 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t697)
  store i64 %t699, ptr %l170
  br label %bb100
bb100:
  %t700 = load i64, ptr %l170, !tbaa !24
  store i64 %t700, ptr %l14, !tbaa !24
  %t701 = load ptr, ptr %l4, !tbaa !29
  %t703 = icmp eq ptr %t701, null
  %t705 = xor i1 %t703, true
  br i1 %t705, label %bb101, label %bb102
bb101:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load ptr, ptr %l4, !tbaa !29
  %t710 = load i32, ptr %l3, !tbaa !23
  %t714 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %v0, ptr %t707, ptr %t708, i32 %t710)
  store ptr %t714, ptr %l179
  br label %bb103
bb102:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load %"compiler/source:Span", ptr %l2
  %t717 = load i32, ptr %l3, !tbaa !23
  %t721 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t715, %"compiler/source:Span" %t716, i32 %t717)
  store ptr %t721, ptr %l183
  br label %bb104
bb103:
  %t722 = load ptr, ptr %l179, !tbaa !29
  store ptr %t722, ptr %l174, !tbaa !29
  br label %bb105
bb104:
  %t723 = load ptr, ptr %l183, !tbaa !29
  store ptr %t723, ptr %l174, !tbaa !29
  br label %bb105
bb105:
  %t725 = load ptr, ptr %l174, !tbaa !29
  store ptr %t725, ptr %l15, !tbaa !29
  %t726 = load ptr, ptr %l15, !tbaa !29
  %t728 = icmp eq ptr %t726, null
  br i1 %t728, label %bb106, label %bb107
bb106:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load %"compiler/source:Span", ptr %l2
  %t734 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v0, ptr %t730, %"compiler/source:Span" %t731)
  store ptr %t734, ptr %l189
  br label %bb108
bb107:
  br label %bb109
bb108:
  %t735 = load ptr, ptr %l189, !tbaa !29
  store ptr %t735, ptr %l15, !tbaa !29
  br label %bb109
bb109:
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/check:Checker", ptr %t737, i32 0, i32 48
  %t740 = load %"compiler/source:Span", ptr %l2
  %t741 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t742
  %t743 = getelementptr { i64, [3 x i64] }, ptr %t742, i32 0, i32 0
  store i64 6, ptr %t743
  %t745 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t740, 0
  %t747 = insertvalue { %"compiler/source:Span", ptr } %t745, ptr %t741, 1
  %t748 = getelementptr { i64, [3 x i64] }, ptr %t742, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t747, ptr %t748
  %t749 = load { i64, [3 x i64] }, ptr %t742
  %t751 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t749, ptr %t751
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t739, ptr %t751)
  br label %bb110
bb110:
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t754)
  store ptr %t756, ptr %l198
  br label %bb111
bb111:
  %t757 = load ptr, ptr %l198, !tbaa !29
  store ptr %t757, ptr %l199, !tbaa !29
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = getelementptr %"compiler/check:Checker", ptr %t758, i32 0, i32 48
  %t761 = load i64, ptr %l14, !tbaa !24
  %t764 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t760, i64 %t761)
  store { i64, ptr } %t764, ptr %l203
  br label %bb112
bb112:
  %t765 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t766 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t765)
  store %"compiler/typed:Block" %t766, ptr %l204
  br label %bb113
bb113:
  %t767 = load %"compiler/typed:Block", ptr %l204
  %t768 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t767, ptr %t768
  %t770 = load ptr, ptr %l199, !tbaa !29
  %t771 = getelementptr %"compiler/typed:Body", ptr %t770, i32 0, i32 11
  store ptr %t768, ptr %t771, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t772)
  br label %bb114
bb114:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/check:Checker", ptr %t774, i32 0, i32 24
  %t777 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t776, i64 %t777, i64 2)
  br label %bb115
bb115:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t782 = getelementptr %"compiler/check:Checker", ptr %t780, i32 0, i32 154
  store i1 false, ptr %t782, !tbaa !21
  %t783 = load ptr, ptr %l5, !tbaa !29
  %t785 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t783)
  store i64 %t785, ptr %l212
  br label %bb116
bb116:
  %t786 = load i64, ptr %l6, !tbaa !24
  %t787 = load i64, ptr %l212, !tbaa !24
  %t789 = icmp sgt i64 %t787, %t786
  br i1 %t789, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l215, !tbaa !21
  br label %bb120
bb118:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = getelementptr %"compiler/check:Checker", ptr %t791, i32 0, i32 20
  %t795 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t793)
  store i64 %t795, ptr %l218
  br label %bb119
bb119:
  %t796 = load i64, ptr %l7, !tbaa !24
  %t797 = load i64, ptr %l218, !tbaa !24
  %t799 = icmp sgt i64 %t797, %t796
  store i1 %t799, ptr %l215, !tbaa !21
  br label %bb120
bb120:
  %t801 = load i1, ptr %l215, !tbaa !21
  br i1 %t801, label %bb121, label %bb122
bb121:
  %t802 = load ptr, ptr %l5, !tbaa !29
  %t803 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t802, i64 %t803, i64 -1)
  br label %bb123
bb122:
  br label %bb126
bb123:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t808 = getelementptr %"compiler/check:Checker", ptr %t806, i32 0, i32 20
  %t809 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t808, i64 %t809)
  br label %bb124
bb124:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t814 = getelementptr %"compiler/check:Checker", ptr %t812, i32 0, i32 19
  %t815 = load i64, ptr %l12, !tbaa !24
  %t818 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t814, i64 %t815)
  store ptr %t818, ptr %l229
  br label %bb125
bb125:
  %t819 = load ptr, ptr %l229, !tbaa !29
  %t821 = getelementptr %"compiler/typed:Body", ptr %t819, i32 0, i32 11
  store ptr null, ptr %t821, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb126:
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t824 = getelementptr %"compiler/check:Checker", ptr %t822, i32 0, i32 128
  store ptr %t824, ptr %l232, !tbaa !29
  %t825 = load i32, ptr %l1, !range !{i32 0, i32 3}
  store i32 %t825, ptr %l233
  %t826 = load i64, ptr %l10, !tbaa !24
  store i64 %t826, ptr %l234, !tbaa !24
  %t827 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t827, ptr %l235
  %t828 = load i32, ptr %l3, !tbaa !23
  store i32 %t828, ptr %l236, !tbaa !23
  %t829 = load i64, ptr %l12, !tbaa !24
  store i64 %t829, ptr %l237, !tbaa !24
  %t830 = load ptr, ptr %l5, !tbaa !29
  %t831 = load i64, ptr %l10, !tbaa !24
  %t832 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t833 = load i32, ptr %t832, !tbaa !23
  %t835 = sext i32 %t833 to i64
  %t836 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t837 = load i32, ptr %t836, !tbaa !23
  %t839 = sext i32 %t837 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t840
  %t841 = getelementptr { i64, [3 x i64] }, ptr %t840, i32 0, i32 0
  store i64 3, ptr %t841
  %t843 = insertvalue { i64, i64, i64 } undef, i64 %t831, 0
  %t845 = insertvalue { i64, i64, i64 } %t843, i64 %t835, 1
  %t847 = insertvalue { i64, i64, i64 } %t845, i64 %t839, 2
  %t848 = getelementptr { i64, [3 x i64] }, ptr %t840, i32 0, i32 1
  store { i64, i64, i64 } %t847, ptr %t848
  %t849 = load { i64, [3 x i64] }, ptr %t840
  %t852 = call { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %t830, { i64, [3 x i64] } %t849)
  store { i64, [3 x i64] } %t852, ptr %l245
  br label %bb127
bb127:
  %t853 = load i32, ptr %l233, !range !{i32 0, i32 3}
  %t854 = load i64, ptr %l234, !tbaa !24
  %t855 = load %"compiler/source:Span", ptr %l235
  %t856 = load i32, ptr %l236, !tbaa !23
  %t857 = load i64, ptr %l237, !tbaa !24
  %t858 = load { i64, [3 x i64] }, ptr %l245
  %t859 = call %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %s0, i32 %t853, i64 %t854, %"compiler/source:Span" %t855, i32 %t856, i64 %t857, { i64, [3 x i64] } %t858)
  store %"compiler/check:ValueAsk" %t859, ptr %l246
  br label %bb128
bb128:
  %t860 = load ptr, ptr %l232, !tbaa !29
  %t861 = load %"compiler/check:ValueAsk", ptr %l246
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ePush_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t860, %"compiler/check:ValueAsk" %t861)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassertStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %lp14 = alloca ptr
  %l15 = alloca i1
  %lp16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l21 = alloca { i64, [3 x i64] }
  %lp22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca { i64, [3 x i64] }
  %l26 = alloca i1
  %l30 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca i1
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l79 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l98 = alloca i1
  %l101 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca ptr
  %l127 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca i32
  %l132 = alloca i64
  %l136 = alloca i64
  %l138 = alloca i64
  %l143 = alloca i64
  %l149 = alloca i64
  %l151 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l163 = alloca i1
  %l170 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i64
  %l174 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l184 = alloca i1
  %l188 = alloca i1
  %l190 = alloca i1
  %l193 = alloca i1
  %l195 = alloca i1
  %l199 = alloca i1
  %l202 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l208 = alloca %"compiler/source:Span"
  %l213 = alloca ptr
  %l216 = alloca { i64, [3 x i64] }
  %l217 = alloca i1
  %l219 = alloca i1
  %l221 = alloca i1
  %l224 = alloca { i64, [3 x i64] }
  %l227 = alloca i1
  %l232 = alloca ptr
  %l235 = alloca { i64, [3 x i64] }
  %l236 = alloca { i64, [3 x i64] }
  %l237 = alloca { i64, [3 x i64] }
  %l238 = alloca ptr
  %l241 = alloca { i64, [3 x i64] }
  %l243 = alloca i1
  %l246 = alloca ptr
  %l248 = alloca i64
  %l250 = alloca i64
  %l251 = alloca %"compiler/source:Span"
  %l252 = alloca %"compiler/source:Span"
  %l253 = alloca i64
  %l254 = alloca i64
  %l255 = alloca i64
  %l258 = alloca { i64, ptr }
  %l265 = alloca %"compiler/check:AssertAsk"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t26 = alloca { i64, [5 x i64] }, align 8
  %t49 = alloca { i64, [3 x i64] }, align 8
  %t426 = alloca { i64, [3 x i64] }, align 8
  %t500 = alloca { i64, [3 x i64] }, align 8
  %t538 = alloca %"compiler/check:AssertAsk", align 8
  %t553 = alloca %"compiler/check:AssertAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t6, ptr %l30
  br label %bb1
bb1:
  %t7 = load i64, ptr %l30, !tbaa !24
  store i64 %t7, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp eq i64 %t8, 1
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l38
  br label %bb7
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t21)
  store %"compiler/source:Span" %t23, ptr %l40
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l38, !tbaa !29
  store ptr %t24, ptr %l35, !tbaa !29
  br label %bb9
bb8:
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t28 = load %"compiler/source:Span", ptr %l40
  %t29 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t31 = insertvalue { %"compiler/source:Span", i32, i64 } %t29, i32 %t25, 1
  %t32 = insertvalue { %"compiler/source:Span", i32, i64 } %t31, i64 0, 2
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t32, ptr %t33
  %t34 = load { i64, [5 x i64] }, ptr %t26
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t34, ptr %t36
  store ptr %t36, ptr %l35, !tbaa !29
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l35, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v2, ptr %v0, ptr %t39, ptr %t40, i1 false)
  store ptr %t43, ptr %l46
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l46, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load ptr, ptr %l5, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 0
  store i64 10, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t46, 0
  %t54 = insertvalue { %"compiler/source:Span", ptr, ptr } %t52, ptr %t47, 1
  %t56 = insertvalue { %"compiler/source:Span", ptr, ptr } %t54, ptr %t44, 2
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t56, ptr %t57
  %t58 = load { i64, [3 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t58, ptr %t60
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t45, ptr %t60)
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l53, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l54, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t65)
  store ptr %t67, ptr %l56
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l56, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 7
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l53, !tbaa !29
  %t73 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i1 true, i64 %t71)
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l60
  br label %bb14
bb14:
  %t78 = load ptr, ptr %l60, !tbaa !29
  store ptr %t78, ptr %l7, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 2
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb15, label %bb16
bb15:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/check:frame", ptr %t86, i32 0, i32 12
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l64, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb17
bb17:
  %t91 = load i1, ptr %l64, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l8, !tbaa !24
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l67
  br label %bb21
bb21:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l9
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 155
  store i1 true, ptr %t100, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t101, i64 %t105, ptr %t106)
  store i64 %t110, ptr %l75
  br label %bb24
bb23:
  br label %bb34
bb24:
  %t111 = load i64, ptr %l75, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 155
  store i1 false, ptr %t114, !tbaa !21
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 166
  store ptr %t117, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t119 = load i64, ptr %l11, !tbaa !24
  store i64 %t119, ptr %l79, !tbaa !24
  %t120 = load ptr, ptr %l10, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l81
  br label %bb26
bb26:
  %t123 = load i64, ptr %l79, !tbaa !24
  %t124 = load i64, ptr %l81, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l86
  br label %bb30
bb30:
  %t134 = load i64, ptr %l86, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t134)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l11, !tbaa !24
  br label %bb25
bb33:
  br label %bb34
bb34:
  store i64 -1, ptr %l13, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t144, ptr %lp14
  %t146 = load ptr, ptr %lp14
  store { i64, ptr } %t143, ptr %t146, !tbaa !27
  store i1 false, ptr %l15, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t148, ptr %lp16
  %t150 = load ptr, ptr %lp16
  store { i64, ptr } %t147, ptr %t150, !tbaa !27
  %t151 = load i64, ptr %l8, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb37
bb36:
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = icmp eq i64 %t155, 0
  store i1 %t157, ptr %l98, !tbaa !21
  br label %bb37
bb37:
  %t159 = load i1, ptr %l98, !tbaa !21
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  %t164 = xor i1 %t162, true
  store i1 %t164, ptr %l101, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t166 = load i1, ptr %l101, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l15, !tbaa !21
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l3, !tbaa !29
  %t171 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v2, ptr %v0, ptr %t167, ptr %t168)
  %t172 = extractvalue { i32, { i64, ptr } } %t171, 1
  %t173 = extractvalue { i32, { i64, ptr } } %t171, 0
  store i32 %t173, ptr %l109
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb44, label %ok.175, !prof !99
ok.175:
  store { i64, ptr } %t172, ptr %l108
  br label %bb43
bb42:
  br label %bb72
bb43:
  %t176 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t176, ptr %l105, !tbaa !27
  br label %bb46
bb44:
  %t177 = load i32, ptr %l109, !tbaa !23
  %t178 = ashr i32 %t177, 16
  %t180 = icmp eq i32 %t178, 1
  store i1 %t180, ptr %l111, !tbaa !21
  br label %bb45
bb45:
  store i1 false, ptr %l15, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t181, ptr %l105, !tbaa !27
  br label %bb46
bb46:
  %t183 = load ptr, ptr %lp14
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  store { i64, ptr } %t184, ptr %l114, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l115, !tbaa !24
  %t187 = load i64, ptr %l115, !tbaa !24
  %t188 = mul i64 %t187, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l116, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l115, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  %t198 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t199 = load ptr, ptr %lp14
  store { i64, ptr } %t198, ptr %t199, !tbaa !27
  %t200 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e14
  br i1 %t200, label %bb47, label %bb48
bb47:
  %t202 = load { i64, ptr }, ptr %l114
  %t203 = extractvalue { i64, ptr } %t202, 1
  call void @__olang_region_release(ptr %t203)
  store { i64, ptr } zeroinitializer, ptr %l114
  br label %bb48
bb48:
  %t204 = load i1, ptr %l15, !tbaa !21
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 155
  store i1 true, ptr %t210, !tbaa !21
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l121, !tbaa !29
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t212, i32 0, i32 1
  %t215 = load i64, ptr %t214, !tbaa !24
  store i64 %t215, ptr %l123, !tbaa !24
  %t216 = load ptr, ptr %l3, !tbaa !29
  store ptr %t216, ptr %l124, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 2
  store ptr %t222, ptr %l127, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t223)
  store i32 %t225, ptr %l129
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t226 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t227 = load ptr, ptr %l127, !tbaa !29
  %t228 = load i32, ptr %l129, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t227, i32 %t228, i64 %t226)
  store i32 %t230, ptr %l131
  br label %bb52
bb52:
  %t231 = load ptr, ptr %l121, !tbaa !29
  %t232 = load i64, ptr %l123, !tbaa !24
  %t233 = load ptr, ptr %l124, !tbaa !29
  %t234 = load i32, ptr %l131, !tbaa !23
  %t235 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v2, ptr %t231, i64 %t232, ptr %t233, i32 %t234)
  store i64 %t235, ptr %l132
  br label %bb53
bb53:
  %t236 = load i64, ptr %l132, !tbaa !24
  store i64 %t236, ptr %l13, !tbaa !24
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 155
  store i1 false, ptr %t239, !tbaa !21
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 166
  store ptr %t242, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb54
bb54:
  %t244 = load i64, ptr %l18, !tbaa !24
  store i64 %t244, ptr %l136, !tbaa !24
  %t245 = load ptr, ptr %l17, !tbaa !29
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l138
  br label %bb55
bb55:
  %t248 = load i64, ptr %l136, !tbaa !24
  %t249 = load i64, ptr %l138, !tbaa !24
  %t250 = icmp slt i64 %t248, %t249
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  br label %bb58
bb58:
  %t254 = load ptr, ptr %l17, !tbaa !29
  %t255 = load i64, ptr %l18, !tbaa !24
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t254, i64 %t255)
  store i64 %t258, ptr %l143
  br label %bb59
bb59:
  %t259 = load i64, ptr %l143, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t259)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = add i64 %t263, 1
  store i64 %t266, ptr %l18, !tbaa !24
  br label %bb54
bb62:
  %t268 = call ptr @__olang_scope_hold(ptr %v0)
  %t269 = ptrtoint ptr %t268 to i64
  store i64 %t269, ptr %l149, !tbaa !24
  %t270 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e16
  br i1 %t270, label %bb63, label %bb64
bb63:
  %t272 = call ptr @__olang_region_make(ptr %v0)
  %t273 = ptrtoint ptr %t272 to i64
  store i64 %t273, ptr %l149, !tbaa !24
  br label %bb64
bb64:
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l151, !tbaa !29
  %t275 = load ptr, ptr %l3, !tbaa !29
  %t277 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t275)
  store %"compiler/source:Span" %t277, ptr %l153
  br label %bb65
bb65:
  %t278 = load ptr, ptr %l151, !tbaa !29
  %t279 = load %"compiler/source:Span", ptr %l153
  %t280 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s9, ptr %t278, %"compiler/source:Span" %t279)
  store { i64, ptr } %t280, ptr %l154
  br label %bb66
bb66:
  %t281 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t281, ptr %l155, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  store i64 %t283, ptr %l156, !tbaa !24
  %t284 = load i64, ptr %l156, !tbaa !24
  %t285 = mul i64 %t284, 1
  %t286 = load i64, ptr %l149
  %t287 = inttoptr i64 %t286 to ptr
  %t288 = call ptr @__olang_held_alloc(ptr %t287, i64 %t285)
  %t289 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l157, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l156, !tbaa !24
  %t296 = mul i64 %t295, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t292, ptr %t294, i64 %t296, i1 false)
  %t297 = load ptr, ptr %lp16
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l158, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t300 = load ptr, ptr %lp16
  store { i64, ptr } %t299, ptr %t300, !tbaa !27
  %t301 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e16
  br i1 %t301, label %bb67, label %bb68
bb67:
  %t303 = load { i64, ptr }, ptr %l158
  %t304 = extractvalue { i64, ptr } %t303, 1
  call void @__olang_region_release(ptr %t304)
  store { i64, ptr } zeroinitializer, ptr %l158
  br label %bb68
bb68:
  %t305 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e16
  br i1 %t305, label %bb69, label %bb70
bb69:
  %t307 = load ptr, ptr %lp16
  %t308 = load i64, ptr %l149
  %t309 = inttoptr i64 %t308 to ptr
  %t310 = load { i64, ptr }, ptr %t307
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = call ptr @__olang_region_or(ptr %t311, ptr null)
  %t313 = icmp ne ptr %t312, null
  %t314 = select i1 %t313, ptr %t312, ptr null
  call void @__olang_region_settle_in(ptr %t309, ptr %t314)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t315 = load i64, ptr %l8, !tbaa !24
  %t317 = icmp slt i64 %t315, 0
  br i1 %t317, label %bb73, label %bb74
bb73:
  %t319 = load i64, ptr %l4, !tbaa !24
  %t321 = icmp ne i64 %t319, 0
  store i1 %t321, ptr %l163, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb75
bb75:
  %t323 = load i1, ptr %l163, !tbaa !21
  br i1 %t323, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb77:
  br label %bb78
bb78:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 0
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = getelementptr %"compiler/load:Loader", ptr %t330, i32 0, i32 4
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t333)
  store { { i64, [3 x i64] }, { i64, ptr } } %t335, ptr %l170
  br label %bb79
bb79:
  %t336 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l170
  store { { i64, [3 x i64] }, { i64, ptr } } %t336, ptr %l20
  %t337 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t338 = load { i64, [3 x i64] }, ptr %t337
  store { i64, [3 x i64] } %t338, ptr %l21
  %t340 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !27
  store { i64, ptr } %t341, ptr %l172, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  store i64 %t343, ptr %l173, !tbaa !24
  %t344 = load i64, ptr %l173, !tbaa !24
  %t345 = mul i64 %t344, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t345)
  %t347 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  store { i64, ptr } %t348, ptr %l174, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l173, !tbaa !24
  %t354 = mul i64 %t353, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t350, ptr %t352, i64 %t354, i1 false)
  %t355 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t355, ptr %lp22
  %t356 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t357 = load ptr, ptr %lp22
  store { i64, ptr } %t356, ptr %t357, !tbaa !27
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t363 = getelementptr %"compiler/generic:Program", ptr %t361, i32 0, i32 0
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = getelementptr %"compiler/load:Loader", ptr %t364, i32 0, i32 10
  %t367 = load ptr, ptr %l7, !tbaa !29
  %t369 = getelementptr %"compiler/check:frame", ptr %t367, i32 0, i32 1
  %t370 = load i64, ptr %t369, !tbaa !24
  %t373 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t366, i64 %t370)
  store ptr %t373, ptr %l181
  br label %bb80
bb80:
  %t374 = load ptr, ptr %l181, !tbaa !29
  %t376 = getelementptr %"compiler/load:Module", ptr %t374, i32 0, i32 2
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t379 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t377, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t379, ptr %l184
  br label %bb81
bb81:
  %t380 = load i1, ptr %l184, !tbaa !21
  store i1 %t380, ptr %l23, !tbaa !21
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l2, !tbaa !29
  %t386 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t381, ptr %t382)
  store i1 %t386, ptr %l188
  br label %bb82
bb82:
  %t387 = load i1, ptr %l188, !tbaa !21
  %t388 = xor i1 %t387, true
  br i1 %t388, label %bb83, label %bb84
bb83:
  %t390 = load i64, ptr %l4, !tbaa !24
  %t392 = icmp slt i64 %t390, 0
  store i1 %t392, ptr %l190, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb85
bb85:
  %t394 = load i1, ptr %l190, !tbaa !21
  br i1 %t394, label %bb86, label %bb87
bb86:
  %t395 = load i1, ptr %l15, !tbaa !21
  br i1 %t395, label %bb88, label %bb89
bb87:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb91
bb88:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 172
  %t400 = load i1, ptr %t399, !tbaa !21
  store i1 %t400, ptr %l195, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb90
bb90:
  %t402 = load i1, ptr %l195, !tbaa !21
  %t403 = xor i1 %t402, true
  store i1 %t403, ptr %l193, !tbaa !21
  br label %bb91
bb91:
  %t405 = load i1, ptr %l193, !tbaa !21
  br i1 %t405, label %bb92, label %bb93
bb92:
  %t406 = load i1, ptr %l23, !tbaa !21
  %t408 = xor i1 %t406, true
  store i1 %t408, ptr %l199, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb94
bb94:
  %t410 = load i1, ptr %l199, !tbaa !21
  br i1 %t410, label %bb95, label %bb96
bb95:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l202, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t412 = load ptr, ptr %lp22
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l204, !tbaa !27
  %t415 = load ptr, ptr %lp22
  store { i64, ptr } %t411, ptr %t415, !tbaa !27
  %t416 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e22
  br i1 %t416, label %bb97, label %bb98
bb96:
  br label %bb99
bb97:
  %t418 = load { i64, ptr }, ptr %l204
  %t419 = extractvalue { i64, ptr } %t418, 1
  call void @__olang_region_release(ptr %t419)
  store { i64, ptr } zeroinitializer, ptr %l204
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t424 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t420, ptr %t421)
  store %"compiler/source:Span" %t424, ptr %l208
  br label %bb100
bb100:
  %t425 = load %"compiler/source:Span", ptr %l208
  store %"compiler/source:Span" %t425, ptr %l24
  store { i64, [3 x i64] } zeroinitializer, ptr %t426
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t426, i32 0, i32 0
  store i64 0, ptr %t427
  %t428 = load { i64, [3 x i64] }, ptr %t426
  store { i64, [3 x i64] } %t428, ptr %l25
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !29
  %t435 = getelementptr %"compiler/generic:Program", ptr %t433, i32 0, i32 0
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t438 = getelementptr %"compiler/load:Loader", ptr %t436, i32 0, i32 4
  %t439 = load ptr, ptr %t438, !tbaa !29
  store ptr %t439, ptr %l213, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l24
  %t444 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t440, %"compiler/source:Span" %t441)
  store { i64, [3 x i64] } %t444, ptr %l216
  br label %bb101
bb101:
  %t445 = load ptr, ptr %l213, !tbaa !29
  %t446 = load { i64, [3 x i64] }, ptr %l216
  %t447 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsLibrary(ptr %v0, ptr %t445, { i64, [3 x i64] } %t446)
  store i1 %t447, ptr %l217
  br label %bb102
bb102:
  %t448 = load i1, ptr %l217, !tbaa !21
  store i1 %t448, ptr %l26, !tbaa !21
  %t449 = load ptr, ptr %lp22
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  %t452 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t450, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t452, ptr %l219
  br label %bb103
bb103:
  %t453 = load i1, ptr %l219, !tbaa !21
  %t454 = xor i1 %t453, true
  br i1 %t454, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb106
bb105:
  %t456 = load i1, ptr %l26, !tbaa !21
  store i1 %t456, ptr %l221, !tbaa !21
  br label %bb106
bb106:
  %t458 = load i1, ptr %l221, !tbaa !21
  br i1 %t458, label %bb107, label %bb108
bb107:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprogramOrigin(ptr %v0, ptr %t459)
  store { i64, [3 x i64] } %t461, ptr %l224
  br label %bb109
bb108:
  br label %bb123
bb109:
  %t462 = load { i64, [3 x i64] }, ptr %l224
  store { i64, [3 x i64] } %t462, ptr %l25
  %t463 = load { i64, [3 x i64] }, ptr %l25
  %t465 = extractvalue { i64, [3 x i64] } %t463, 0
  %t466 = icmp eq i64 %t465, 0
  br i1 %t466, label %bb110, label %bb111
bb110:
  %t468 = load i1, ptr %l26, !tbaa !21
  store i1 %t468, ptr %l227, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb112
bb112:
  %t470 = load i1, ptr %l227, !tbaa !21
  br i1 %t470, label %bb113, label %bb114
bb113:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/check:Checker", ptr %t471, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/generic:Program", ptr %t474, i32 0, i32 0
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/load:Loader", ptr %t477, i32 0, i32 4
  %t480 = load ptr, ptr %t479, !tbaa !29
  store ptr %t480, ptr %l232, !tbaa !29
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load %"compiler/source:Span", ptr %l24
  %t485 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t481, %"compiler/source:Span" %t482)
  store { i64, [3 x i64] } %t485, ptr %l235
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t486 = load ptr, ptr %l232, !tbaa !29
  %t487 = load { i64, [3 x i64] }, ptr %l235
  %t488 = call { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %t486, { i64, [3 x i64] } %t487)
  store { i64, [3 x i64] } %t488, ptr %l236
  br label %bb116
bb116:
  %t489 = load { i64, [3 x i64] }, ptr %l236
  store { i64, [3 x i64] } %t489, ptr %l25
  br label %bb117
bb117:
  %t490 = load { i64, [3 x i64] }, ptr %l25
  store { i64, [3 x i64] } %t490, ptr %l237
  store ptr %l237, ptr %l238, !tbaa !29
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load %"compiler/source:Span", ptr %l24
  %t495 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t491, %"compiler/source:Span" %t492)
  store { i64, [3 x i64] } %t495, ptr %l241
  br label %bb118
bb118:
  %t496 = load ptr, ptr %l238, !tbaa !29
  %t498 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %t496, ptr %l241)
  store i1 %t498, ptr %l243
  br label %bb119
bb119:
  %t499 = load i1, ptr %l243, !tbaa !21
  br i1 %t499, label %bb120, label %bb121
bb120:
  store { i64, [3 x i64] } zeroinitializer, ptr %t500
  %t501 = getelementptr { i64, [3 x i64] }, ptr %t500, i32 0, i32 0
  store i64 0, ptr %t501
  %t502 = load { i64, [3 x i64] }, ptr %t500
  store { i64, [3 x i64] } %t502, ptr %l25
  br label %bb122
bb121:
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t504, i32 0, i32 125
  store ptr %t506, ptr %l246, !tbaa !29
  %t507 = load ptr, ptr %l7, !tbaa !29
  %t509 = getelementptr %"compiler/check:frame", ptr %t507, i32 0, i32 0
  %t510 = load i64, ptr %t509, !tbaa !24
  store i64 %t510, ptr %l248, !tbaa !24
  %t511 = load ptr, ptr %l7, !tbaa !29
  %t513 = getelementptr %"compiler/check:frame", ptr %t511, i32 0, i32 2
  %t514 = load i64, ptr %t513, !tbaa !24
  store i64 %t514, ptr %l250, !tbaa !24
  %t515 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t515, ptr %l251
  %t516 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t516, ptr %l252
  %t517 = load i64, ptr %l8, !tbaa !24
  store i64 %t517, ptr %l253, !tbaa !24
  %t518 = load i64, ptr %l13, !tbaa !24
  store i64 %t518, ptr %l254, !tbaa !24
  %t519 = call ptr @__olang_scope_hold(ptr %v0)
  %t520 = ptrtoint ptr %t519 to i64
  store i64 %t520, ptr %l255, !tbaa !24
  %t521 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aAssertAsk_2e10
  br i1 %t521, label %bb124, label %bb125
bb124:
  %t523 = call ptr @__olang_region_make(ptr %v0)
  %t524 = ptrtoint ptr %t523 to i64
  store i64 %t524, ptr %l255, !tbaa !24
  br label %bb125
bb125:
  %t525 = load i64, ptr %l255
  %t526 = inttoptr i64 %t525 to ptr
  %t528 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %t526, ptr %l9)
  store { i64, ptr } %t528, ptr %l258
  br label %bb126
bb126:
  %t529 = load { i64, [3 x i64] }, ptr %l21
  %t530 = load ptr, ptr %lp22
  %t531 = load { i64, ptr }, ptr %t530, !tbaa !27
  %t532 = load i1, ptr %l15, !tbaa !21
  %t533 = load ptr, ptr %lp14
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !27
  %t535 = load ptr, ptr %lp16
  %t536 = load { i64, ptr }, ptr %t535, !tbaa !27
  %t537 = load { i64, [3 x i64] }, ptr %l25
  %t539 = load i64, ptr %l248, !tbaa !24
  %t540 = load i64, ptr %l250, !tbaa !24
  %t541 = load %"compiler/source:Span", ptr %l251
  %t542 = load %"compiler/source:Span", ptr %l252
  %t543 = load i64, ptr %l253, !tbaa !24
  %t544 = load i64, ptr %l254, !tbaa !24
  %t545 = load { i64, ptr }, ptr %l258, !tbaa !27
  call void @compiler_2fcheck_3aAssertAsk_2ector(ptr %t538, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t539, i64 %t540, %"compiler/source:Span" %t541, %"compiler/source:Span" %t542, i64 %t543, i64 %t544, { i64, ptr } %t545, { i64, [3 x i64] } %t529, { i64, ptr } %t531, i1 %t532, { i64, ptr } %t534, { i64, ptr } %t536, { i64, [3 x i64] } %t537)
  call void @llvm.memmove.p0.p0.i64(ptr %l265, ptr %t538, i64 184, i1 false)
  br label %bb127
bb127:
  %t552 = load ptr, ptr %l246, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t553, ptr %l265, i64 184, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v0, ptr %t552, ptr %t553)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseDefaultCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, i32 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca i1
  %l79 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = load i32, ptr %l14, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t11, ptr %l17
  store %"compiler/source:Span" %a2, ptr %l18
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l19, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l20, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t15)
  store %"compiler/source:Span" %t17, ptr %l22
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load ptr, ptr %l20, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l22
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v0, ptr %t20, %"compiler/source:Span" %t21, ptr %t18, i32 %t19)
  store ptr %t24, ptr %l25
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l25, !tbaa !29
  store ptr %t25, ptr %l26, !tbaa !29
  store { i64, ptr } %a6, ptr %l27, !tbaa !27
  %t27 = icmp sge i64 0, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = icmp sle i64 0, 1152921504606846975
  br i1 %t29, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7a7e3734e2ac5540_e5e6042583167994)
  unreachable
bb7:
  %t31 = mul i64 0, 8
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t33, ptr %l30, !tbaa !27
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_7a7e3734e2ac5540_e5e6042583167994)
  unreachable
bb9:
  %t36 = icmp sle i64 0, 2305843009213693951
  br i1 %t36, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_299e8d70417dba6d_28fb9bcaf3f636a1)
  unreachable
bb11:
  %t38 = mul i64 0, 4
  %t39 = insertvalue { i64, ptr } undef, i64 0, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t41 = load ptr, ptr %l16, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l17
  %t43 = load %"compiler/source:Span", ptr %l18
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t41, %"compiler/source:Span" %t42, %"compiler/source:Span" %t43, i64 %t44, ptr %t45, { i64, ptr } %t46, { i64, ptr } %t47, { i64, ptr } %t40)
  store ptr %t49, ptr %l34
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_299e8d70417dba6d_28fb9bcaf3f636a1)
  unreachable
bb13:
  %t50 = load ptr, ptr %l34, !tbaa !29
  store ptr %t50, ptr %l8, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l38
  br label %bb14
bb14:
  %t59 = load i32, ptr %l38, !tbaa !23
  store i32 %t59, ptr %l9, !tbaa !23
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l41, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l9, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l46
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = load i32, ptr %l46, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l47
  br label %bb16
bb16:
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t79, ptr %l10, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp eq i64 %t82, 0
  br i1 %t84, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb21
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l54, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l9, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l59
  br label %bb19
bb19:
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l60, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i32, ptr %t104, i64 0
  %t106 = load i32, ptr %t105, !tbaa !33
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t110 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t107, i32 %t108, i32 %t106)
  store i1 %t110, ptr %l62
  br label %bb20
bb20:
  %t111 = load i1, ptr %l62, !tbaa !21
  %t112 = xor i1 %t111, true
  store i1 %t112, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t114 = load i1, ptr %l51, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb26
bb23:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  store ptr %t120, ptr %l67, !tbaa !29
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t124 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t121)
  store i32 %t124, ptr %l70
  br label %bb24
bb24:
  %t125 = load i32, ptr %l5, !tbaa !23
  %t126 = load ptr, ptr %l67, !tbaa !29
  %t127 = load i32, ptr %l70, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t126, i32 %t127, i32 %t125)
  store i1 %t129, ptr %l72
  br label %bb25
bb25:
  %t130 = load i1, ptr %l72, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l64, !tbaa !21
  br label %bb26
bb26:
  %t133 = load i1, ptr %l64, !tbaa !21
  br i1 %t133, label %bb27, label %bb28
bb27:
  %t134 = load ptr, ptr %l8, !tbaa !29
  store ptr %t134, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t138 = load ptr, ptr %l8, !tbaa !29
  %t139 = load i32, ptr %l7, !tbaa !23
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v3, ptr %v3, ptr %t136, %"compiler/source:Span" %t137, ptr %t138, i32 %t139)
  store ptr %t144, ptr %l79
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l79, !tbaa !29
  store ptr %t145, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i64
  %l17 = alloca i1
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i32
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t15, i32 %t16, i32 %t17)
  store i64 %t21, ptr %l15
  br label %bb2
bb2:
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l2, !tbaa !23
  %t34 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i64 %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l27
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l30
  br label %bb11
bb11:
  %t51 = load i32, ptr %l30, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t54, ptr %l32
  br label %bb12
bb12:
  %t55 = load i1, ptr %l32, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l5, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l37
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l37, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb16:
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t69, ptr %l39
  br label %bb17
bb17:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb21
bb19:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = call i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %t71)
  store i32 %t73, ptr %l42
  br label %bb20
bb20:
  %t74 = load i32, ptr %l42, !range !{i32 0, i32 54}
  %t76 = trunc i64 29 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l5, !tbaa !23
  %t91 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t87, i32 %t88)
  store i1 %t91, ptr %l50
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinaryOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/check:factsMark"
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/check:litv"
  %l16 = alloca %"compiler/check:litv"
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l79 = alloca ptr
  %l85 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca i1
  %l123 = alloca ptr
  %l128 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca ptr
  %l134 = alloca i64
  %l136 = alloca i1
  %l137 = alloca ptr
  %l140 = alloca i32
  %l141 = alloca i1
  %l142 = alloca ptr
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/source:Span"
  %l165 = alloca ptr
  %l169 = alloca ptr
  %l171 = alloca %"compiler/check:factsMark"
  %l174 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca i1
  %l180 = alloca ptr
  %l185 = alloca i64
  %l190 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l200 = alloca { i64, ptr }
  %l203 = alloca %"compiler/typed:Seq"
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca i32
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca %"compiler/typed:Cond"
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca i32
  %l226 = alloca ptr
  %l230 = alloca ptr
  %l233 = alloca %"compiler/typed:Cond"
  %l237 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l241 = alloca %"compiler/source:Span"
  %l243 = alloca { i64, ptr }
  %l245 = alloca %"compiler/source:Span"
  %l249 = alloca %"compiler/check:litv"
  %l253 = alloca %"compiler/check:litv"
  %l256 = alloca i1
  %l259 = alloca i1
  %l261 = alloca i1
  %l264 = alloca i1
  %l267 = alloca i1
  %l270 = alloca i1
  %l272 = alloca i1
  %l275 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/diagmsg:Msg"
  %l280 = alloca i64
  %l283 = alloca ptr
  %l286 = alloca i1
  %l290 = alloca i1
  %l294 = alloca i1
  %l297 = alloca i1
  %l298 = alloca i1
  %l300 = alloca i1
  %l303 = alloca i1
  %l306 = alloca i1
  %l309 = alloca i1
  %l312 = alloca i1
  %l314 = alloca i1
  %l318 = alloca ptr
  %l320 = alloca %"compiler/source:Span"
  %l321 = alloca %"compiler/diagmsg:Msg"
  %l322 = alloca i64
  %l325 = alloca ptr
  %l328 = alloca i1
  %l331 = alloca i1
  %l334 = alloca i1
  %l336 = alloca i1
  %l338 = alloca i1
  %l340 = alloca i1
  %l343 = alloca i1
  %l353 = alloca %"compiler/check:litv"
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %l358 = alloca %"compiler/diagmsg:Msg"
  %l359 = alloca i64
  %l362 = alloca ptr
  %l365 = alloca i1
  %l368 = alloca i1
  %l371 = alloca i1
  %l374 = alloca i1
  %l378 = alloca i1
  %l379 = alloca ptr
  %l384 = alloca ptr
  %l386 = alloca %"compiler/source:Span"
  %l387 = alloca ptr
  %l388 = alloca ptr
  %l391 = alloca i32
  %l392 = alloca i1
  %l393 = alloca i1
  %l394 = alloca ptr
  %l397 = alloca i32
  %l398 = alloca i1
  %l399 = alloca i32
  %l400 = alloca ptr
  %l403 = alloca i32
  %l404 = alloca i32
  %l409 = alloca i1
  %l410 = alloca ptr
  %l411 = alloca i32
  %l412 = alloca ptr
  %l414 = alloca i32
  %l417 = alloca ptr
  %l420 = alloca i1
  %l421 = alloca ptr
  %l422 = alloca %"compiler/source:Span"
  %l425 = alloca i32
  %l428 = alloca i32
  %l429 = alloca i1
  %l432 = alloca ptr
  %l441 = alloca ptr
  %l442 = alloca ptr
  %l447 = alloca ptr
  %l449 = alloca %"compiler/source:Span"
  %l450 = alloca ptr
  %l451 = alloca ptr
  %l454 = alloca i32
  %l455 = alloca i1
  %l456 = alloca i1
  %l457 = alloca ptr
  %l460 = alloca i32
  %l461 = alloca i1
  %l462 = alloca i32
  %l463 = alloca ptr
  %l466 = alloca i32
  %l467 = alloca i32
  %l472 = alloca i1
  %l473 = alloca ptr
  %l474 = alloca i32
  %l475 = alloca ptr
  %l477 = alloca i32
  %l480 = alloca ptr
  %l483 = alloca i1
  %l484 = alloca ptr
  %l485 = alloca %"compiler/source:Span"
  %l488 = alloca i32
  %l491 = alloca i32
  %l492 = alloca i1
  %l495 = alloca ptr
  %l504 = alloca ptr
  %l506 = alloca i1
  %l509 = alloca i1
  %l511 = alloca ptr
  %l516 = alloca ptr
  %l518 = alloca %"compiler/source:Span"
  %l519 = alloca ptr
  %l523 = alloca i1
  %l524 = alloca i32
  %l527 = alloca i32
  %l531 = alloca i1
  %l532 = alloca ptr
  %l537 = alloca ptr
  %l543 = alloca ptr
  %l546 = alloca i1
  %l549 = alloca ptr
  %l554 = alloca ptr
  %l556 = alloca %"compiler/source:Span"
  %l557 = alloca ptr
  %l565 = alloca ptr
  %l570 = alloca ptr
  %l572 = alloca i1
  %l575 = alloca ptr
  %l576 = alloca ptr
  %l577 = alloca i32
  %l578 = alloca ptr
  %l580 = alloca i32
  %l583 = alloca ptr
  %l585 = alloca %"compiler/source:Span"
  %l586 = alloca ptr
  %l589 = alloca ptr
  %l592 = alloca i32
  %l593 = alloca i32
  %l596 = alloca i1
  %l598 = alloca ptr
  %l601 = alloca i32
  %l603 = alloca i32
  %l607 = alloca i1
  %l608 = alloca ptr
  %l613 = alloca ptr
  %l619 = alloca ptr
  %l627 = alloca ptr
  %l632 = alloca ptr
  %l635 = alloca i1
  %l636 = alloca i1
  %l639 = alloca i1
  %l641 = alloca ptr
  %l646 = alloca ptr
  %l648 = alloca %"compiler/source:Span"
  %l649 = alloca ptr
  %l651 = alloca ptr
  %l652 = alloca ptr
  %l653 = alloca i32
  %l654 = alloca ptr
  %l655 = alloca ptr
  %l658 = alloca i32
  %l659 = alloca i1
  %l660 = alloca i32
  %l661 = alloca ptr
  %l664 = alloca i32
  %l665 = alloca i32
  %l667 = alloca ptr
  %l669 = alloca %"compiler/source:Span"
  %l670 = alloca ptr
  %l674 = alloca i1
  %l675 = alloca i1
  %l678 = alloca i1
  %l680 = alloca ptr
  %l685 = alloca ptr
  %l687 = alloca %"compiler/source:Span"
  %l688 = alloca ptr
  %l690 = alloca ptr
  %l691 = alloca ptr
  %l692 = alloca i32
  %l693 = alloca ptr
  %l694 = alloca ptr
  %l697 = alloca i32
  %l698 = alloca i1
  %l699 = alloca i32
  %l700 = alloca ptr
  %l703 = alloca i32
  %l704 = alloca i32
  %l706 = alloca ptr
  %l708 = alloca %"compiler/source:Span"
  %l709 = alloca ptr
  %l712 = alloca i1
  %l714 = alloca i1
  %l717 = alloca i1
  %l720 = alloca i1
  %l723 = alloca i1
  %l726 = alloca i1
  %l727 = alloca i1
  %l730 = alloca i1
  %l734 = alloca i32
  %l735 = alloca ptr
  %l736 = alloca ptr
  %l737 = alloca %"compiler/check:litv"
  %l741 = alloca i1
  %l742 = alloca i32
  %l745 = alloca ptr
  %l747 = alloca ptr
  %l748 = alloca ptr
  %l749 = alloca %"compiler/check:litv"
  %l753 = alloca i1
  %l754 = alloca i32
  %l757 = alloca ptr
  %l759 = alloca ptr
  %l764 = alloca ptr
  %l766 = alloca %"compiler/source:Span"
  %l767 = alloca ptr
  %l769 = alloca ptr
  %l774 = alloca ptr
  %l776 = alloca %"compiler/source:Span"
  %l777 = alloca ptr
  %l779 = alloca ptr
  %l780 = alloca %"compiler/source:Span"
  %l781 = alloca %"compiler/source:Span"
  %l782 = alloca i32
  %l785 = alloca ptr
  %l791 = alloca ptr
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %rv = alloca ptr
  %t344 = alloca { i64, [5 x i64] }, align 8
  %t384 = alloca { i64, [5 x i64] }, align 8
  %t415 = alloca { i64, [5 x i64] }, align 8
  %t646 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t3 = trunc i64 71 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l5, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epower(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t6, %"compiler/source:Span" %t7, ptr %t8, ptr %t9, i32 %t10)
  store ptr %t16, ptr %l38
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load ptr, ptr %l38, !tbaa !29
  store ptr %t17, ptr %rv
  br label %ret
bb4:
  %t18 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t20 = trunc i64 68 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2etextWritten(ptr %v1, ptr %t23)
  store i1 %t25, ptr %l43
  br label %bb7
bb6:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb12
bb7:
  %t26 = load i1, ptr %l43, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb11
bb9:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i1 @compiler_2fcheck_2etextWritten(ptr %v2, ptr %t27)
  store i1 %t29, ptr %l46
  br label %bb10
bb10:
  %t30 = load i1, ptr %l46, !tbaa !21
  store i1 %t30, ptr %l44, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l44, !tbaa !21
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l41, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextPlus(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t33, %"compiler/source:Span" %t34, ptr %t35, ptr %t36)
  store ptr %t41, ptr %l51
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load ptr, ptr %l51, !tbaa !29
  store ptr %t42, ptr %rv
  br label %ret
bb16:
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t45 = trunc i64 28 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb19
bb18:
  %t48 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t50 = trunc i64 106 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l54, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, ptr %t57, ptr %t58)
  store ptr %t64, ptr %l62
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load ptr, ptr %l62, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb23:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t68 = trunc i64 95 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb26
bb25:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t73 = trunc i64 96 to i32
  %t74 = icmp eq i32 %t71, %t73
  store i1 %t74, ptr %l65, !tbaa !21
  br label %bb26
bb26:
  %t76 = load i1, ptr %l65, !tbaa !21
  br i1 %t76, label %bb27, label %bb28
bb27:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t77)
  store i1 %t79, ptr %l69
  br label %bb29
bb28:
  br label %bb60
bb29:
  %t80 = load i1, ptr %l69, !tbaa !21
  br i1 %t80, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb33
bb31:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t81)
  store i1 %t83, ptr %l72
  br label %bb32
bb32:
  %t84 = load i1, ptr %l72, !tbaa !21
  store i1 %t84, ptr %l70, !tbaa !21
  br label %bb33
bb33:
  %t85 = load i1, ptr %l70, !tbaa !21
  br i1 %t85, label %bb34, label %bb35
bb34:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t90 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t92 = trunc i64 96 to i32
  %t93 = icmp eq i32 %t90, %t92
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t86, %"compiler/source:Span" %t87, ptr %t88, ptr %t89, i1 %t93)
  store ptr %t99, ptr %l79
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load ptr, ptr %l79, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb37:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t105 = load ptr, ptr %l4, !tbaa !29
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t101, %"compiler/source:Span" %t102, i32 %t103, ptr %t104, ptr %t105)
  store ptr %t111, ptr %l85
  br label %bb38
bb38:
  %t112 = load ptr, ptr %l85, !tbaa !29
  store ptr %t112, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t119, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t121, ptr %t122)
  store i1 %t125, ptr %l92
  br label %bb42
bb42:
  %t126 = load i1, ptr %l92, !tbaa !21
  br i1 %t126, label %bb43, label %bb44
bb43:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t127, ptr %t128)
  store i1 %t131, ptr %l96
  br label %bb45
bb44:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  %t132 = load i1, ptr %l96, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t135 = load i1, ptr %l93, !tbaa !21
  br i1 %t135, label %bb47, label %bb48
bb47:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t138 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t140 = load ptr, ptr %l4, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t136, %"compiler/source:Span" %t137, i32 %t138, ptr %t139, ptr %t140)
  store ptr %t146, ptr %l103
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load ptr, ptr %l103, !tbaa !29
  store ptr %t147, ptr %rv
  br label %ret
bb50:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t152 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  store i1 %t152, ptr %l106
  br label %bb51
bb51:
  %t153 = load i1, ptr %l106, !tbaa !21
  br i1 %t153, label %bb52, label %bb53
bb52:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t158 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t154, ptr %t155)
  store i1 %t158, ptr %l110
  br label %bb54
bb53:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb55
bb54:
  %t159 = load i1, ptr %l110, !tbaa !21
  %t160 = xor i1 %t159, true
  store i1 %t160, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  %t162 = load i1, ptr %l107, !tbaa !21
  br i1 %t162, label %bb56, label %bb57
bb56:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t165 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t163, %"compiler/source:Span" %t164, i32 %t165, ptr %t166, ptr %t167)
  store ptr %t173, ptr %l117
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t174 = load ptr, ptr %l117, !tbaa !29
  store ptr %t174, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t175 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t177 = trunc i64 45 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb63
bb62:
  %t180 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t182 = trunc i64 46 to i32
  %t183 = icmp eq i32 %t180, %t182
  store i1 %t183, ptr %l120, !tbaa !21
  br label %bb63
bb63:
  %t185 = load i1, ptr %l120, !tbaa !21
  br i1 %t185, label %bb64, label %bb65
bb64:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l123, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t190 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t187, i32 %t188, ptr %t189, i32 %t190)
  store ptr %t195, ptr %l128
  br label %bb66
bb65:
  br label %bb108
bb66:
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t196)
  store %"compiler/source:Span" %t198, ptr %l130
  br label %bb67
bb67:
  %t199 = load ptr, ptr %l123, !tbaa !29
  %t200 = load ptr, ptr %l128, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l130
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t199, ptr %t200, %"compiler/source:Span" %t201)
  store ptr %t202, ptr %l131
  br label %bb68
bb68:
  %t203 = load ptr, ptr %l131, !tbaa !29
  store ptr %t203, ptr %l7, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l7, !tbaa !29
  %t208 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v3, ptr %t204, ptr %t205)
  store i64 %t208, ptr %l134
  br label %bb69
bb69:
  %t209 = load i64, ptr %l134, !tbaa !24
  %t210 = icmp sge i64 %t209, 0
  br i1 %t210, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb74
bb71:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l137, !tbaa !29
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t213)
  store i32 %t216, ptr %l140
  br label %bb72
bb72:
  %t217 = load ptr, ptr %l137, !tbaa !29
  %t218 = load i32, ptr %l140, !tbaa !23
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t219, ptr %l141
  br label %bb73
bb73:
  %t220 = load i1, ptr %l141, !tbaa !21
  store i1 %t220, ptr %l136, !tbaa !21
  br label %bb74
bb74:
  %t221 = load i1, ptr %l136, !tbaa !21
  br i1 %t221, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l142, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t225 = load ptr, ptr %l4, !tbaa !29
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t223, i32 %t224, ptr %t225, i32 %t226)
  store ptr %t231, ptr %l147
  br label %bb77
bb76:
  br label %bb85
bb77:
  %t232 = load ptr, ptr %l4, !tbaa !29
  %t234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t232)
  store %"compiler/source:Span" %t234, ptr %l149
  br label %bb78
bb78:
  %t235 = load ptr, ptr %l142, !tbaa !29
  %t236 = load ptr, ptr %l147, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l149
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t235, ptr %t236, %"compiler/source:Span" %t237)
  store ptr %t238, ptr %l150
  br label %bb79
bb79:
  %t239 = load ptr, ptr %l150, !tbaa !29
  store ptr %t239, ptr %l8, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l151, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t241, ptr %l152
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l153, !tbaa !29
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t245 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t243)
  store %"compiler/source:Span" %t245, ptr %l155
  br label %bb80
bb80:
  %t246 = load ptr, ptr %l4, !tbaa !29
  %t248 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t246)
  store %"compiler/source:Span" %t248, ptr %l157
  br label %bb81
bb81:
  %t249 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t251 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s10, i32 %t249)
  store { i64, ptr } %t251, ptr %l159
  br label %bb82
bb82:
  %t252 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t254 = load ptr, ptr %l153, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l155
  %t256 = load %"compiler/source:Span", ptr %l157
  %t258 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, %"compiler/source:Span" %t256, i64 %t253)
  store %"compiler/source:Span" %t258, ptr %l161
  br label %bb83
bb83:
  %t259 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t260 = load ptr, ptr %l7, !tbaa !29
  %t261 = load ptr, ptr %l8, !tbaa !29
  %t262 = load ptr, ptr %l151, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l152
  %t264 = load %"compiler/source:Span", ptr %l161
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t262, %"compiler/source:Span" %t263, %"compiler/source:Span" %t264, i32 %t259, ptr %t260, ptr %t261)
  store ptr %t268, ptr %l165
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t269 = load ptr, ptr %l165, !tbaa !29
  store ptr %t269, ptr %rv
  br label %ret
bb85:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l3, !tbaa !29
  %t272 = load ptr, ptr %l7, !tbaa !29
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %v3, ptr %v3, ptr %t270, ptr %t271, ptr %t272)
  store ptr %t276, ptr %l169
  br label %bb86
bb86:
  %t277 = load ptr, ptr %l169, !tbaa !29
  store ptr %t277, ptr %l9, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %t278)
  store %"compiler/check:factsMark" %t280, ptr %l171
  br label %bb87
bb87:
  %t281 = load %"compiler/check:factsMark", ptr %l171
  store %"compiler/check:factsMark" %t281, ptr %l10
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 48
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l174
  br label %bb88
bb88:
  %t287 = load i64, ptr %l174, !tbaa !24
  store i64 %t287, ptr %l11, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l175, !tbaa !29
  %t289 = load ptr, ptr %l3, !tbaa !29
  store ptr %t289, ptr %l176, !tbaa !29
  %t290 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t292 = trunc i64 45 to i32
  %t293 = icmp eq i32 %t290, %t292
  store i1 %t293, ptr %l178, !tbaa !21
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t294)
  store ptr %t296, ptr %l180
  br label %bb89
bb89:
  %t297 = load ptr, ptr %l180, !tbaa !29
  %t299 = getelementptr %"compiler/check:frame", ptr %t297, i32 0, i32 7
  %t300 = load i64, ptr %t299, !tbaa !24
  %t301 = load ptr, ptr %l175, !tbaa !29
  %t302 = load ptr, ptr %l176, !tbaa !29
  %t303 = load i1, ptr %l178, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t301, ptr %t302, i1 %t303, i64 %t300)
  br label %bb90
bb90:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 48
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t307)
  store i64 %t309, ptr %l185
  br label %bb91
bb91:
  %t310 = load i64, ptr %l11, !tbaa !24
  %t311 = load i64, ptr %l185, !tbaa !24
  %t313 = icmp sgt i64 %t311, %t310
  store i1 %t313, ptr %l12, !tbaa !21
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l4, !tbaa !29
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %v3, ptr %t315, ptr %t316)
  store ptr %t319, ptr %l190
  br label %bb92
bb92:
  %t320 = load ptr, ptr %l190, !tbaa !29
  store ptr %t320, ptr %l13, !tbaa !29
  %t321 = load i1, ptr %l12, !tbaa !21
  br i1 %t321, label %bb93, label %bb94
bb93:
  %t323 = load ptr, ptr %l4, !tbaa !29
  %t325 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t323)
  store %"compiler/source:Span" %t325, ptr %l193
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t326 = load ptr, ptr %l13, !tbaa !29
  %t329 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t326)
  store i32 %t329, ptr %l196
  br label %bb96
bb96:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 48
  %t333 = load i64, ptr %l11, !tbaa !24
  %t336 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t332, i64 %t333)
  store { i64, ptr } %t336, ptr %l200
  br label %bb97
bb97:
  %t337 = load ptr, ptr %l13, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t341 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t339, ptr %t337, i1 false)
  store %"compiler/typed:Seq" %t341, ptr %l203
  br label %bb98
bb98:
  %t342 = load %"compiler/typed:Seq", ptr %l203
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t342, ptr %t343
  store { i64, [5 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [5 x i64] }, ptr %t344, i32 0, i32 0
  store i64 12, ptr %t345
  %t346 = load %"compiler/source:Span", ptr %l193
  %t347 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t346, 0
  %t348 = load i32, ptr %l196, !tbaa !23
  %t349 = insertvalue { %"compiler/source:Span", i32, ptr } %t347, i32 %t348, 1
  %t351 = insertvalue { %"compiler/source:Span", i32, ptr } %t349, ptr %t343, 2
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t344, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t351, ptr %t352
  %t353 = load { i64, [5 x i64] }, ptr %t344
  %t355 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t353, ptr %t355
  store ptr %t355, ptr %l13, !tbaa !29
  br label %bb99
bb99:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/check:factsMark", ptr %l10
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %t357, %"compiler/check:factsMark" %t358)
  br label %bb100
bb100:
  %t361 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t363 = trunc i64 45 to i32
  %t364 = icmp eq i32 %t361, %t363
  br i1 %t364, label %bb101, label %bb102
bb101:
  %t366 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t366, ptr %l211
  %t367 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t367, ptr %l212, !tbaa !23
  %t368 = load ptr, ptr %l9, !tbaa !29
  store ptr %t368, ptr %l213, !tbaa !29
  %t369 = load ptr, ptr %l13, !tbaa !29
  store ptr %t369, ptr %l215, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l1
  %t373 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t377 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t371, %"compiler/source:Span" %t372, i32 %t373, i64 0)
  store ptr %t377, ptr %l219
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t378 = load ptr, ptr %l213, !tbaa !29
  %t379 = load ptr, ptr %l215, !tbaa !29
  %t380 = load ptr, ptr %l219, !tbaa !29
  %t381 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t378, ptr %t379, ptr %t380)
  store %"compiler/typed:Cond" %t381, ptr %l220
  br label %bb104
bb104:
  %t382 = load %"compiler/typed:Cond", ptr %l220
  %t383 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t382, ptr %t383
  store { i64, [5 x i64] } zeroinitializer, ptr %t384
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t384, i32 0, i32 0
  store i64 11, ptr %t385
  %t386 = load %"compiler/source:Span", ptr %l211
  %t387 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t386, 0
  %t388 = load i32, ptr %l212, !tbaa !23
  %t389 = insertvalue { %"compiler/source:Span", i32, ptr } %t387, i32 %t388, 1
  %t391 = insertvalue { %"compiler/source:Span", i32, ptr } %t389, ptr %t383, 2
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t384, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t391, ptr %t392
  %t393 = load { i64, [5 x i64] }, ptr %t384
  %t395 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t393, ptr %t395
  call void @__olang_scope_close(ptr %s0)
  store ptr %t395, ptr %rv
  br label %ret
bb105:
  %t397 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t397, ptr %l224
  %t398 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t398, ptr %l225, !tbaa !23
  %t399 = load ptr, ptr %l9, !tbaa !29
  store ptr %t399, ptr %l226, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load %"compiler/source:Span", ptr %l1
  %t402 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t406 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t400, %"compiler/source:Span" %t401, i32 %t402, i64 1)
  store ptr %t406, ptr %l230
  br label %bb106
bb106:
  %t407 = load ptr, ptr %l230, !tbaa !29
  %t408 = load ptr, ptr %l13, !tbaa !29
  %t409 = load ptr, ptr %l226, !tbaa !29
  %t412 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t409, ptr %t407, ptr %t408)
  store %"compiler/typed:Cond" %t412, ptr %l233
  br label %bb107
bb107:
  %t413 = load %"compiler/typed:Cond", ptr %l233
  %t414 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t413, ptr %t414
  store { i64, [5 x i64] } zeroinitializer, ptr %t415
  %t416 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 0
  store i64 11, ptr %t416
  %t417 = load %"compiler/source:Span", ptr %l224
  %t418 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t417, 0
  %t419 = load i32, ptr %l225, !tbaa !23
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } %t418, i32 %t419, 1
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, ptr %t414, 2
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t422, ptr %t423
  %t424 = load { i64, [5 x i64] }, ptr %t415
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t424, ptr %t426
  call void @__olang_scope_close(ptr %s0)
  store ptr %t426, ptr %rv
  br label %ret
bb108:
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l237, !tbaa !29
  %t429 = load ptr, ptr %l3, !tbaa !29
  %t431 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t429)
  store %"compiler/source:Span" %t431, ptr %l239
  br label %bb109
bb109:
  %t432 = load ptr, ptr %l4, !tbaa !29
  %t434 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t432)
  store %"compiler/source:Span" %t434, ptr %l241
  br label %bb110
bb110:
  %t435 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t437 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t435)
  store { i64, ptr } %t437, ptr %l243
  br label %bb111
bb111:
  %t438 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 0
  %t440 = load ptr, ptr %l237, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l239
  %t442 = load %"compiler/source:Span", ptr %l241
  %t444 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t440, %"compiler/source:Span" %t441, %"compiler/source:Span" %t442, i64 %t439)
  store %"compiler/source:Span" %t444, ptr %l245
  br label %bb112
bb112:
  %t445 = load %"compiler/source:Span", ptr %l245
  store %"compiler/source:Span" %t445, ptr %l14
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l3, !tbaa !29
  %t451 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t446, ptr %t447)
  store %"compiler/check:litv" %t451, ptr %l249
  br label %bb113
bb113:
  %t452 = load %"compiler/check:litv", ptr %l249
  store %"compiler/check:litv" %t452, ptr %l15
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l4, !tbaa !29
  %t458 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t453, ptr %t454)
  store %"compiler/check:litv" %t458, ptr %l253
  br label %bb114
bb114:
  %t459 = load %"compiler/check:litv", ptr %l253
  store %"compiler/check:litv" %t459, ptr %l16
  %t460 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t462 = trunc i64 72 to i32
  %t463 = icmp eq i32 %t460, %t462
  br i1 %t463, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb117
bb116:
  %t465 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t467 = trunc i64 73 to i32
  %t468 = icmp eq i32 %t465, %t467
  store i1 %t468, ptr %l256, !tbaa !21
  br label %bb117
bb117:
  %t470 = load i1, ptr %l256, !tbaa !21
  br i1 %t470, label %bb118, label %bb119
bb118:
  %t471 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t472 = load i1, ptr %t471, !tbaa !21
  store i1 %t472, ptr %l259, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb120
bb120:
  %t474 = load i1, ptr %l259, !tbaa !21
  br i1 %t474, label %bb121, label %bb122
bb121:
  %t475 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 1
  %t476 = load i1, ptr %t475, !tbaa !21
  %t478 = xor i1 %t476, true
  store i1 %t478, ptr %l261, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb123
bb123:
  %t480 = load i1, ptr %l261, !tbaa !21
  br i1 %t480, label %bb124, label %bb125
bb124:
  %t481 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 2
  %t482 = load i1, ptr %t481, !tbaa !21
  %t484 = xor i1 %t482, true
  store i1 %t484, ptr %l264, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb126
bb126:
  %t486 = load i1, ptr %l264, !tbaa !21
  br i1 %t486, label %bb127, label %bb128
bb127:
  %t487 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 3
  %t488 = load i64, ptr %t487, !tbaa !24
  %t490 = icmp eq i64 %t488, 0
  store i1 %t490, ptr %l267, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l267, !tbaa !21
  br label %bb129
bb129:
  %t492 = load i1, ptr %l267, !tbaa !21
  br i1 %t492, label %bb130, label %bb131
bb130:
  %t493 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t494 = load i1, ptr %t493, !tbaa !21
  br i1 %t494, label %bb132, label %bb133
bb131:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb135
bb132:
  %t496 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 1
  %t497 = load i1, ptr %t496, !tbaa !21
  store i1 %t497, ptr %l272, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb134
bb134:
  %t499 = load i1, ptr %l272, !tbaa !21
  %t500 = xor i1 %t499, true
  store i1 %t500, ptr %l270, !tbaa !21
  br label %bb135
bb135:
  %t502 = load i1, ptr %l270, !tbaa !21
  br i1 %t502, label %bb136, label %bb137
bb136:
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l275, !tbaa !29
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load ptr, ptr %l4, !tbaa !29
  %t508 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v2, ptr %t504, ptr %t505)
  store %"compiler/source:Span" %t508, ptr %l278
  br label %bb138
bb137:
  br label %bb142
bb138:
  %t509 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0)
  store %"compiler/diagmsg:Msg" %t509, ptr %l279
  br label %bb139
bb139:
  %t510 = load ptr, ptr %l275, !tbaa !29
  %t511 = load %"compiler/source:Span", ptr %l278
  %t512 = load %"compiler/diagmsg:Msg", ptr %l279
  %t513 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t510, %"compiler/source:Span" %t511, %"compiler/diagmsg:Msg" %t512)
  store i64 %t513, ptr %l280
  br label %bb140
bb140:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l1
  %t518 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t514, %"compiler/source:Span" %t515)
  store ptr %t518, ptr %l283
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s0)
  %t519 = load ptr, ptr %l283, !tbaa !29
  store ptr %t519, ptr %rv
  br label %ret
bb142:
  %t520 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t522 = trunc i64 108 to i32
  %t523 = icmp eq i32 %t520, %t522
  br i1 %t523, label %bb143, label %bb144
bb143:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb145
bb144:
  %t525 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t527 = trunc i64 109 to i32
  %t528 = icmp eq i32 %t525, %t527
  store i1 %t528, ptr %l286, !tbaa !21
  br label %bb145
bb145:
  %t530 = load i1, ptr %l286, !tbaa !21
  store i1 %t530, ptr %l17, !tbaa !21
  %t531 = load i1, ptr %l17, !tbaa !21
  br i1 %t531, label %bb146, label %bb147
bb146:
  %t533 = load i32, ptr %l5, !tbaa !23
  %t534 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t537 = icmp eq i32 %t533, %t534
  store i1 %t537, ptr %l290, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb148
bb148:
  %t539 = load i1, ptr %l290, !tbaa !21
  br i1 %t539, label %bb149, label %bb150
bb149:
  %t540 = load ptr, ptr %l3, !tbaa !29
  %t543 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v1, ptr %t540)
  store i1 %t543, ptr %l297
  br label %bb151
bb150:
  store i1 false, ptr %l294, !tbaa !21
  br label %bb152
bb151:
  %t544 = load i1, ptr %l297, !tbaa !21
  store i1 %t544, ptr %l294, !tbaa !21
  br label %bb152
bb152:
  %t545 = load i1, ptr %l294, !tbaa !21
  br i1 %t545, label %bb153, label %bb154
bb153:
  %t546 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t547 = load i1, ptr %t546, !tbaa !21
  store i1 %t547, ptr %l298, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb155
bb155:
  %t549 = load i1, ptr %l298, !tbaa !21
  br i1 %t549, label %bb156, label %bb157
bb156:
  %t550 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 1
  %t551 = load i1, ptr %t550, !tbaa !21
  %t553 = xor i1 %t551, true
  store i1 %t553, ptr %l300, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb158
bb158:
  %t555 = load i1, ptr %l300, !tbaa !21
  br i1 %t555, label %bb159, label %bb160
bb159:
  %t556 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 2
  %t557 = load i1, ptr %t556, !tbaa !21
  %t559 = xor i1 %t557, true
  store i1 %t559, ptr %l303, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb161
bb161:
  %t561 = load i1, ptr %l303, !tbaa !21
  br i1 %t561, label %bb162, label %bb163
bb162:
  %t562 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 3
  %t563 = load i64, ptr %t562, !tbaa !24
  %t565 = icmp slt i64 %t563, 0
  br i1 %t565, label %bb164, label %bb165
bb163:
  store i1 false, ptr %l306, !tbaa !21
  br label %bb173
bb164:
  store i1 true, ptr %l309, !tbaa !21
  br label %bb172
bb165:
  %t567 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 3
  %t568 = load i64, ptr %t567, !tbaa !24
  %t570 = icmp sge i64 %t568, 64
  br i1 %t570, label %bb166, label %bb167
bb166:
  %t572 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t573 = load i1, ptr %t572, !tbaa !21
  br i1 %t573, label %bb168, label %bb169
bb167:
  store i1 false, ptr %l312, !tbaa !21
  br label %bb171
bb168:
  %t575 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 1
  %t576 = load i1, ptr %t575, !tbaa !21
  %t578 = xor i1 %t576, true
  store i1 %t578, ptr %l314, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb170
bb170:
  %t580 = load i1, ptr %l314, !tbaa !21
  %t581 = xor i1 %t580, true
  store i1 %t581, ptr %l312, !tbaa !21
  br label %bb171
bb171:
  %t583 = load i1, ptr %l312, !tbaa !21
  store i1 %t583, ptr %l309, !tbaa !21
  br label %bb172
bb172:
  %t584 = load i1, ptr %l309, !tbaa !21
  store i1 %t584, ptr %l306, !tbaa !21
  br label %bb173
bb173:
  %t585 = load i1, ptr %l306, !tbaa !21
  br i1 %t585, label %bb174, label %bb175
bb174:
  %t586 = load ptr, ptr %l0, !tbaa !29
  store ptr %t586, ptr %l318, !tbaa !29
  %t587 = load ptr, ptr %l4, !tbaa !29
  %t589 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t587)
  store %"compiler/source:Span" %t589, ptr %l320
  br label %bb176
bb175:
  br label %bb180
bb176:
  %t590 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0)
  store %"compiler/diagmsg:Msg" %t590, ptr %l321
  br label %bb177
bb177:
  %t591 = load ptr, ptr %l318, !tbaa !29
  %t592 = load %"compiler/source:Span", ptr %l320
  %t593 = load %"compiler/diagmsg:Msg", ptr %l321
  %t594 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t591, %"compiler/source:Span" %t592, %"compiler/diagmsg:Msg" %t593)
  store i64 %t594, ptr %l322
  br label %bb178
bb178:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load %"compiler/source:Span", ptr %l1
  %t599 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t595, %"compiler/source:Span" %t596)
  store ptr %t599, ptr %l325
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  %t600 = load ptr, ptr %l325, !tbaa !29
  store ptr %t600, ptr %rv
  br label %ret
bb180:
  %t601 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t603 = trunc i64 68 to i32
  %t604 = icmp eq i32 %t601, %t603
  br i1 %t604, label %bb181, label %bb182
bb181:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb183
bb182:
  %t606 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t608 = trunc i64 69 to i32
  %t609 = icmp eq i32 %t606, %t608
  store i1 %t609, ptr %l328, !tbaa !21
  br label %bb183
bb183:
  %t611 = load i1, ptr %l328, !tbaa !21
  br i1 %t611, label %bb184, label %bb185
bb184:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb186
bb185:
  %t612 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t614 = trunc i64 70 to i32
  %t615 = icmp eq i32 %t612, %t614
  store i1 %t615, ptr %l331, !tbaa !21
  br label %bb186
bb186:
  %t617 = load i1, ptr %l331, !tbaa !21
  br i1 %t617, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l334, !tbaa !21
  br label %bb189
bb188:
  %t618 = load i1, ptr %l17, !tbaa !21
  store i1 %t618, ptr %l334, !tbaa !21
  br label %bb189
bb189:
  %t620 = load i1, ptr %l334, !tbaa !21
  br i1 %t620, label %bb190, label %bb191
bb190:
  %t621 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t622 = load i1, ptr %t621, !tbaa !21
  store i1 %t622, ptr %l336, !tbaa !21
  br label %bb192
bb191:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb192
bb192:
  %t624 = load i1, ptr %l336, !tbaa !21
  br i1 %t624, label %bb193, label %bb194
bb193:
  %t625 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t626 = load i1, ptr %t625, !tbaa !21
  store i1 %t626, ptr %l338, !tbaa !21
  br label %bb195
bb194:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb195
bb195:
  %t628 = load i1, ptr %l338, !tbaa !21
  br i1 %t628, label %bb196, label %bb197
bb196:
  %t629 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 1
  %t630 = load i1, ptr %t629, !tbaa !21
  %t632 = xor i1 %t630, true
  store i1 %t632, ptr %l340, !tbaa !21
  br label %bb198
bb197:
  store i1 false, ptr %l340, !tbaa !21
  br label %bb198
bb198:
  %t634 = load i1, ptr %l340, !tbaa !21
  br i1 %t634, label %bb199, label %bb200
bb199:
  %t635 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 1
  %t636 = load i1, ptr %t635, !tbaa !21
  %t638 = xor i1 %t636, true
  store i1 %t638, ptr %l343, !tbaa !21
  br label %bb201
bb200:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb201
bb201:
  %t640 = load i1, ptr %l343, !tbaa !21
  br i1 %t640, label %bb202, label %bb203
bb202:
  store %olang.scope zeroinitializer, ptr %s15
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l1
  %t643 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t644 = load ptr, ptr %l3, !tbaa !29
  %t645 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t646
  %t647 = getelementptr { i64, [4 x i64] }, ptr %t646, i32 0, i32 0
  store i64 5, ptr %t647
  %t649 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t642, 0
  %t651 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t649, i32 %t643, 1
  %t653 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t651, ptr %t644, 2
  %t655 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t653, ptr %t645, 3
  %t656 = getelementptr { i64, [4 x i64] }, ptr %t646, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t655, ptr %t656
  %t657 = load { i64, [4 x i64] }, ptr %t646
  %t659 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 40, i64 8)
  store { i64, [4 x i64] } %t657, ptr %t659
  %t662 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %s15, ptr %t641, ptr %t659)
  store %"compiler/check:litv" %t662, ptr %l353
  br label %bb204
bb203:
  br label %bb211
bb204:
  %t663 = getelementptr %"compiler/check:litv", ptr %l353, i32 0, i32 0
  %t664 = load i1, ptr %t663, !tbaa !21
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb205, label %bb206
bb205:
  %t668 = load ptr, ptr %l0, !tbaa !29
  store ptr %t668, ptr %l356, !tbaa !29
  %t669 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t669, ptr %l357
  %t670 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %v0)
  store %"compiler/diagmsg:Msg" %t670, ptr %l358
  br label %bb207
bb206:
  br label %bb210
bb207:
  %t671 = load ptr, ptr %l356, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l357
  %t673 = load %"compiler/diagmsg:Msg", ptr %l358
  %t674 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t671, %"compiler/source:Span" %t672, %"compiler/diagmsg:Msg" %t673)
  store i64 %t674, ptr %l359
  br label %bb208
bb208:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load %"compiler/source:Span", ptr %l1
  %t679 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t675, %"compiler/source:Span" %t676)
  store ptr %t679, ptr %l362
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t680 = load ptr, ptr %l362, !tbaa !29
  store ptr %t680, ptr %rv
  br label %ret
bb210:
  call void @__olang_scope_close(ptr %s15)
  br label %bb211
bb211:
  %t681 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t682 = load i1, ptr %t681, !tbaa !21
  %t684 = xor i1 %t682, true
  br i1 %t684, label %bb212, label %bb213
bb212:
  %t686 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t687 = load i1, ptr %t686, !tbaa !21
  %t689 = xor i1 %t687, true
  store i1 %t689, ptr %l365, !tbaa !21
  br label %bb214
bb213:
  store i1 false, ptr %l365, !tbaa !21
  br label %bb214
bb214:
  %t691 = load i1, ptr %l365, !tbaa !21
  br i1 %t691, label %bb215, label %bb216
bb215:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load ptr, ptr %l3, !tbaa !29
  %t696 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t692, ptr %t693)
  store i1 %t696, ptr %l371
  br label %bb217
bb216:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb219
bb217:
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t698 = load ptr, ptr %l4, !tbaa !29
  %t701 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t697, ptr %t698)
  store i1 %t701, ptr %l374
  br label %bb218
bb218:
  %t702 = load i1, ptr %l371, !tbaa !21
  %t703 = load i1, ptr %l374, !tbaa !21
  %t704 = icmp ne i1 %t702, %t703
  store i1 %t704, ptr %l368, !tbaa !21
  br label %bb219
bb219:
  %t706 = load i1, ptr %l368, !tbaa !21
  br i1 %t706, label %bb220, label %bb221
bb220:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load ptr, ptr %l4, !tbaa !29
  %t711 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t707, ptr %t708)
  store i1 %t711, ptr %l378
  br label %bb222
bb221:
  br label %bb288
bb222:
  %t712 = load i1, ptr %l378, !tbaa !21
  br i1 %t712, label %bb223, label %bb224
bb223:
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l379, !tbaa !29
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t715 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t716 = load ptr, ptr %l3, !tbaa !29
  %t717 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t714, i32 %t715, ptr %t716, i32 %t717)
  store ptr %t722, ptr %l384
  br label %bb225
bb224:
  br label %bb256
bb225:
  %t723 = load ptr, ptr %l3, !tbaa !29
  %t725 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t723)
  store %"compiler/source:Span" %t725, ptr %l386
  br label %bb226
bb226:
  %t726 = load ptr, ptr %l379, !tbaa !29
  %t727 = load ptr, ptr %l384, !tbaa !29
  %t728 = load %"compiler/source:Span", ptr %l386
  %t729 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t726, ptr %t727, %"compiler/source:Span" %t728)
  store ptr %t729, ptr %l387
  br label %bb227
bb227:
  %t730 = load ptr, ptr %l387, !tbaa !29
  store ptr %t730, ptr %l18, !tbaa !29
  %t731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t731, ptr %l388, !tbaa !29
  %t732 = load ptr, ptr %l18, !tbaa !29
  %t735 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t732)
  store i32 %t735, ptr %l391
  br label %bb228
bb228:
  %t736 = load ptr, ptr %l388, !tbaa !29
  %t737 = load i32, ptr %l391, !tbaa !23
  %t738 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t736, i32 %t737)
  store i1 %t738, ptr %l392
  br label %bb229
bb229:
  %t739 = load i1, ptr %l392, !tbaa !21
  br i1 %t739, label %bb230, label %bb231
bb230:
  store i1 true, ptr %l393, !tbaa !21
  br label %bb234
bb231:
  %t740 = load ptr, ptr %l0, !tbaa !29
  store ptr %t740, ptr %l394, !tbaa !29
  %t741 = load ptr, ptr %l18, !tbaa !29
  %t744 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t741)
  store i32 %t744, ptr %l397
  br label %bb232
bb232:
  %t745 = load ptr, ptr %l394, !tbaa !29
  %t746 = load i32, ptr %l397, !tbaa !23
  %t747 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t745, i32 %t746)
  store i1 %t747, ptr %l398
  br label %bb233
bb233:
  %t748 = load i1, ptr %l398, !tbaa !21
  store i1 %t748, ptr %l393, !tbaa !21
  br label %bb234
bb234:
  %t749 = load i1, ptr %l393, !tbaa !21
  br i1 %t749, label %bb235, label %bb236
bb235:
  %t750 = load ptr, ptr %l0, !tbaa !29
  store ptr %t750, ptr %l400, !tbaa !29
  %t751 = load ptr, ptr %l18, !tbaa !29
  %t754 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t751)
  store i32 %t754, ptr %l403
  br label %bb237
bb236:
  %t755 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t755, ptr %l399, !tbaa !23
  br label %bb239
bb237:
  %t757 = load ptr, ptr %l400, !tbaa !29
  %t758 = load i32, ptr %l403, !tbaa !23
  %t759 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t757, i32 %t758)
  store i32 %t759, ptr %l404
  br label %bb238
bb238:
  %t760 = load i32, ptr %l404, !tbaa !23
  store i32 %t760, ptr %l399, !tbaa !23
  br label %bb239
bb239:
  %t761 = load i32, ptr %l399, !tbaa !23
  store i32 %t761, ptr %l19, !tbaa !23
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l4, !tbaa !29
  %t764 = load i32, ptr %l19, !tbaa !23
  %t768 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v2, ptr %t762, ptr %t763, i32 %t764)
  store i1 %t768, ptr %l409
  br label %bb240
bb240:
  %t769 = load i1, ptr %l409, !tbaa !21
  store i1 %t769, ptr %l20, !tbaa !21
  %t770 = load ptr, ptr %l0, !tbaa !29
  store ptr %t770, ptr %l410, !tbaa !29
  %t771 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t771, ptr %l411
  %t772 = load ptr, ptr %l4, !tbaa !29
  store ptr %t772, ptr %l412, !tbaa !29
  %t773 = load i1, ptr %l20, !tbaa !21
  br i1 %t773, label %bb241, label %bb242
bb241:
  %t775 = load i32, ptr %l19, !tbaa !23
  store i32 %t775, ptr %l414, !tbaa !23
  br label %bb243
bb242:
  %t777 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t777, ptr %l414, !tbaa !23
  br label %bb243
bb243:
  %t779 = load ptr, ptr %l410, !tbaa !29
  %t780 = load i32, ptr %l411, !range !{i32 0, i32 116}
  %t781 = load ptr, ptr %l412, !tbaa !29
  %t782 = load i32, ptr %l414, !tbaa !23
  %t783 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v3, ptr %t779, i32 %t780, ptr %t781, i32 %t782)
  store ptr %t783, ptr %l417
  br label %bb244
bb244:
  %t784 = load ptr, ptr %l417, !tbaa !29
  store ptr %t784, ptr %l21, !tbaa !29
  %t785 = load i1, ptr %l20, !tbaa !21
  %t787 = xor i1 %t785, true
  br i1 %t787, label %bb245, label %bb246
bb245:
  %t789 = load ptr, ptr %l0, !tbaa !29
  store ptr %t789, ptr %l421, !tbaa !29
  %t790 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t790, ptr %l422
  %t791 = load ptr, ptr %l18, !tbaa !29
  %t794 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t791)
  store i32 %t794, ptr %l425
  br label %bb247
bb246:
  store i1 false, ptr %l420, !tbaa !21
  br label %bb250
bb247:
  %t795 = load ptr, ptr %l21, !tbaa !29
  %t798 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t795)
  store i32 %t798, ptr %l428
  br label %bb248
bb248:
  %t799 = load ptr, ptr %l421, !tbaa !29
  %t800 = load %"compiler/source:Span", ptr %l422
  %t801 = load i32, ptr %l425, !tbaa !23
  %t802 = load i32, ptr %l428, !tbaa !23
  %t803 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t799, %"compiler/source:Span" %t800, i32 %t801, i32 %t802)
  store i1 %t803, ptr %l429
  br label %bb249
bb249:
  %t804 = load i1, ptr %l429, !tbaa !21
  store i1 %t804, ptr %l420, !tbaa !21
  br label %bb250
bb250:
  %t805 = load i1, ptr %l420, !tbaa !21
  br i1 %t805, label %bb251, label %bb252
bb251:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l1
  %t810 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t806, %"compiler/source:Span" %t807)
  store ptr %t810, ptr %l432
  br label %bb253
bb252:
  br label %bb254
bb253:
  call void @__olang_scope_close(ptr %s0)
  %t811 = load ptr, ptr %l432, !tbaa !29
  store ptr %t811, ptr %rv
  br label %ret
bb254:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load %"compiler/source:Span", ptr %l1
  %t814 = load %"compiler/source:Span", ptr %l14
  %t815 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t816 = load ptr, ptr %l18, !tbaa !29
  %t817 = load ptr, ptr %l21, !tbaa !29
  %t818 = load ptr, ptr %l3, !tbaa !29
  %t819 = load ptr, ptr %l4, !tbaa !29
  %t828 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAst(ptr %v0, ptr %v3, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t812, %"compiler/source:Span" %t813, %"compiler/source:Span" %t814, i32 %t815, ptr %t816, ptr %t817, ptr %t818, ptr %t819)
  store ptr %t828, ptr %l441
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s0)
  %t829 = load ptr, ptr %l441, !tbaa !29
  store ptr %t829, ptr %rv
  br label %ret
bb256:
  %t830 = load ptr, ptr %l0, !tbaa !29
  store ptr %t830, ptr %l442, !tbaa !29
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t833 = load ptr, ptr %l4, !tbaa !29
  %t834 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t839 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t831, i32 %t832, ptr %t833, i32 %t834)
  store ptr %t839, ptr %l447
  br label %bb257
bb257:
  %t840 = load ptr, ptr %l4, !tbaa !29
  %t842 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t840)
  store %"compiler/source:Span" %t842, ptr %l449
  br label %bb258
bb258:
  %t843 = load ptr, ptr %l442, !tbaa !29
  %t844 = load ptr, ptr %l447, !tbaa !29
  %t845 = load %"compiler/source:Span", ptr %l449
  %t846 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t843, ptr %t844, %"compiler/source:Span" %t845)
  store ptr %t846, ptr %l450
  br label %bb259
bb259:
  %t847 = load ptr, ptr %l450, !tbaa !29
  store ptr %t847, ptr %l22, !tbaa !29
  %t848 = load ptr, ptr %l0, !tbaa !29
  store ptr %t848, ptr %l451, !tbaa !29
  %t849 = load ptr, ptr %l22, !tbaa !29
  %t852 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t849)
  store i32 %t852, ptr %l454
  br label %bb260
bb260:
  %t853 = load ptr, ptr %l451, !tbaa !29
  %t854 = load i32, ptr %l454, !tbaa !23
  %t855 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t853, i32 %t854)
  store i1 %t855, ptr %l455
  br label %bb261
bb261:
  %t856 = load i1, ptr %l455, !tbaa !21
  br i1 %t856, label %bb262, label %bb263
bb262:
  store i1 true, ptr %l456, !tbaa !21
  br label %bb266
bb263:
  %t857 = load ptr, ptr %l0, !tbaa !29
  store ptr %t857, ptr %l457, !tbaa !29
  %t858 = load ptr, ptr %l22, !tbaa !29
  %t861 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t858)
  store i32 %t861, ptr %l460
  br label %bb264
bb264:
  %t862 = load ptr, ptr %l457, !tbaa !29
  %t863 = load i32, ptr %l460, !tbaa !23
  %t864 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t862, i32 %t863)
  store i1 %t864, ptr %l461
  br label %bb265
bb265:
  %t865 = load i1, ptr %l461, !tbaa !21
  store i1 %t865, ptr %l456, !tbaa !21
  br label %bb266
bb266:
  %t866 = load i1, ptr %l456, !tbaa !21
  br i1 %t866, label %bb267, label %bb268
bb267:
  %t867 = load ptr, ptr %l0, !tbaa !29
  store ptr %t867, ptr %l463, !tbaa !29
  %t868 = load ptr, ptr %l22, !tbaa !29
  %t871 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t868)
  store i32 %t871, ptr %l466
  br label %bb269
bb268:
  %t872 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t872, ptr %l462, !tbaa !23
  br label %bb271
bb269:
  %t874 = load ptr, ptr %l463, !tbaa !29
  %t875 = load i32, ptr %l466, !tbaa !23
  %t876 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t874, i32 %t875)
  store i32 %t876, ptr %l467
  br label %bb270
bb270:
  %t877 = load i32, ptr %l467, !tbaa !23
  store i32 %t877, ptr %l462, !tbaa !23
  br label %bb271
bb271:
  %t878 = load i32, ptr %l462, !tbaa !23
  store i32 %t878, ptr %l23, !tbaa !23
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = load ptr, ptr %l3, !tbaa !29
  %t881 = load i32, ptr %l23, !tbaa !23
  %t885 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t879, ptr %t880, i32 %t881)
  store i1 %t885, ptr %l472
  br label %bb272
bb272:
  %t886 = load i1, ptr %l472, !tbaa !21
  store i1 %t886, ptr %l24, !tbaa !21
  %t887 = load ptr, ptr %l0, !tbaa !29
  store ptr %t887, ptr %l473, !tbaa !29
  %t888 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t888, ptr %l474
  %t889 = load ptr, ptr %l3, !tbaa !29
  store ptr %t889, ptr %l475, !tbaa !29
  %t890 = load i1, ptr %l24, !tbaa !21
  br i1 %t890, label %bb273, label %bb274
bb273:
  %t892 = load i32, ptr %l23, !tbaa !23
  store i32 %t892, ptr %l477, !tbaa !23
  br label %bb275
bb274:
  %t894 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t894, ptr %l477, !tbaa !23
  br label %bb275
bb275:
  %t896 = load ptr, ptr %l473, !tbaa !29
  %t897 = load i32, ptr %l474, !range !{i32 0, i32 116}
  %t898 = load ptr, ptr %l475, !tbaa !29
  %t899 = load i32, ptr %l477, !tbaa !23
  %t900 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v3, ptr %t896, i32 %t897, ptr %t898, i32 %t899)
  store ptr %t900, ptr %l480
  br label %bb276
bb276:
  %t901 = load ptr, ptr %l480, !tbaa !29
  store ptr %t901, ptr %l25, !tbaa !29
  %t902 = load i1, ptr %l24, !tbaa !21
  %t904 = xor i1 %t902, true
  br i1 %t904, label %bb277, label %bb278
bb277:
  %t906 = load ptr, ptr %l0, !tbaa !29
  store ptr %t906, ptr %l484, !tbaa !29
  %t907 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t907, ptr %l485
  %t908 = load ptr, ptr %l22, !tbaa !29
  %t911 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t908)
  store i32 %t911, ptr %l488
  br label %bb279
bb278:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb282
bb279:
  %t912 = load ptr, ptr %l25, !tbaa !29
  %t915 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t912)
  store i32 %t915, ptr %l491
  br label %bb280
bb280:
  %t916 = load ptr, ptr %l484, !tbaa !29
  %t917 = load %"compiler/source:Span", ptr %l485
  %t918 = load i32, ptr %l488, !tbaa !23
  %t919 = load i32, ptr %l491, !tbaa !23
  %t920 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t916, %"compiler/source:Span" %t917, i32 %t918, i32 %t919)
  store i1 %t920, ptr %l492
  br label %bb281
bb281:
  %t921 = load i1, ptr %l492, !tbaa !21
  store i1 %t921, ptr %l483, !tbaa !21
  br label %bb282
bb282:
  %t922 = load i1, ptr %l483, !tbaa !21
  br i1 %t922, label %bb283, label %bb284
bb283:
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load %"compiler/source:Span", ptr %l1
  %t927 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t923, %"compiler/source:Span" %t924)
  store ptr %t927, ptr %l495
  br label %bb285
bb284:
  br label %bb286
bb285:
  call void @__olang_scope_close(ptr %s0)
  %t928 = load ptr, ptr %l495, !tbaa !29
  store ptr %t928, ptr %rv
  br label %ret
bb286:
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t930 = load %"compiler/source:Span", ptr %l1
  %t931 = load %"compiler/source:Span", ptr %l14
  %t932 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t933 = load ptr, ptr %l25, !tbaa !29
  %t934 = load ptr, ptr %l22, !tbaa !29
  %t935 = load ptr, ptr %l3, !tbaa !29
  %t936 = load ptr, ptr %l4, !tbaa !29
  %t945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAst(ptr %v0, ptr %v3, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t929, %"compiler/source:Span" %t930, %"compiler/source:Span" %t931, i32 %t932, ptr %t933, ptr %t934, ptr %t935, ptr %t936)
  store ptr %t945, ptr %l504
  br label %bb287
bb287:
  call void @__olang_scope_close(ptr %s0)
  %t946 = load ptr, ptr %l504, !tbaa !29
  store ptr %t946, ptr %rv
  br label %ret
bb288:
  store ptr null, ptr %l26, !tbaa !29
  store ptr null, ptr %l27, !tbaa !29
  %t947 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t948 = load i1, ptr %t947, !tbaa !21
  br i1 %t948, label %bb289, label %bb290
bb289:
  %t950 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t951 = load i1, ptr %t950, !tbaa !21
  %t953 = xor i1 %t951, true
  store i1 %t953, ptr %l506, !tbaa !21
  br label %bb291
bb290:
  store i1 false, ptr %l506, !tbaa !21
  br label %bb291
bb291:
  %t955 = load i1, ptr %l506, !tbaa !21
  br i1 %t955, label %bb292, label %bb293
bb292:
  %t956 = load i1, ptr %l17, !tbaa !21
  store i1 %t956, ptr %l509, !tbaa !21
  br label %bb294
bb293:
  store i1 false, ptr %l509, !tbaa !21
  br label %bb294
bb294:
  %t958 = load i1, ptr %l509, !tbaa !21
  br i1 %t958, label %bb295, label %bb296
bb295:
  %t959 = load ptr, ptr %l0, !tbaa !29
  store ptr %t959, ptr %l511, !tbaa !29
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t961 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t962 = load ptr, ptr %l4, !tbaa !29
  %t963 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t968 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t960, i32 %t961, ptr %t962, i32 %t963)
  store ptr %t968, ptr %l516
  br label %bb297
bb296:
  %t969 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t970 = load i1, ptr %t969, !tbaa !21
  br i1 %t970, label %bb311, label %bb312
bb297:
  %t972 = load ptr, ptr %l4, !tbaa !29
  %t974 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t972)
  store %"compiler/source:Span" %t974, ptr %l518
  br label %bb298
bb298:
  %t975 = load ptr, ptr %l511, !tbaa !29
  %t976 = load ptr, ptr %l516, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l518
  %t978 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t975, ptr %t976, %"compiler/source:Span" %t977)
  store ptr %t978, ptr %l519
  br label %bb299
bb299:
  %t979 = load ptr, ptr %l519, !tbaa !29
  store ptr %t979, ptr %l27, !tbaa !29
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t982 = load i32, ptr %l5, !tbaa !23
  %t985 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t981, i32 %t982)
  store i1 %t985, ptr %l523
  br label %bb300
bb300:
  %t986 = load i1, ptr %l523, !tbaa !21
  br i1 %t986, label %bb301, label %bb302
bb301:
  %t987 = load i32, ptr %l5, !tbaa !23
  store i32 %t987, ptr %l524, !tbaa !23
  br label %bb304
bb302:
  %t989 = load ptr, ptr %l0, !tbaa !29
  %t991 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t989)
  store i32 %t991, ptr %l527
  br label %bb303
bb303:
  %t992 = load i32, ptr %l527, !tbaa !23
  store i32 %t992, ptr %l524, !tbaa !23
  br label %bb304
bb304:
  %t993 = load i32, ptr %l524, !tbaa !23
  store i32 %t993, ptr %l28, !tbaa !23
  %t994 = load ptr, ptr %l0, !tbaa !29
  %t995 = load %"compiler/check:litv", ptr %l15
  %t996 = load i32, ptr %l28, !tbaa !23
  %t1000 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t994, %"compiler/check:litv" %t995, i32 %t996)
  store i1 %t1000, ptr %l531
  br label %bb305
bb305:
  %t1001 = load i1, ptr %l531, !tbaa !21
  br i1 %t1001, label %bb306, label %bb307
bb306:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1003 = load ptr, ptr %l3, !tbaa !29
  %t1004 = load %"compiler/check:litv", ptr %l15
  %t1005 = load i32, ptr %l28, !tbaa !23
  %t1010 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t1002, ptr %t1003, %"compiler/check:litv" %t1004, i32 %t1005)
  store ptr %t1010, ptr %l537
  br label %bb308
bb307:
  %t1011 = load ptr, ptr %l0, !tbaa !29
  %t1012 = load ptr, ptr %l3, !tbaa !29
  %t1013 = load %"compiler/check:litv", ptr %l15
  %t1014 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1019 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t1011, ptr %t1012, %"compiler/check:litv" %t1013, i32 %t1014)
  store ptr %t1019, ptr %l543
  br label %bb309
bb308:
  %t1020 = load ptr, ptr %l537, !tbaa !29
  store ptr %t1020, ptr %l532, !tbaa !29
  br label %bb310
bb309:
  %t1022 = load ptr, ptr %l543, !tbaa !29
  store ptr %t1022, ptr %l532, !tbaa !29
  br label %bb310
bb310:
  %t1024 = load ptr, ptr %l532, !tbaa !29
  store ptr %t1024, ptr %l26, !tbaa !29
  br label %bb441
bb311:
  %t1025 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t1026 = load i1, ptr %t1025, !tbaa !21
  %t1028 = xor i1 %t1026, true
  store i1 %t1028, ptr %l546, !tbaa !21
  br label %bb313
bb312:
  store i1 false, ptr %l546, !tbaa !21
  br label %bb313
bb313:
  %t1030 = load i1, ptr %l546, !tbaa !21
  br i1 %t1030, label %bb314, label %bb315
bb314:
  %t1031 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1031, ptr %l549, !tbaa !29
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1033 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1034 = load ptr, ptr %l4, !tbaa !29
  %t1035 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1040 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t1032, i32 %t1033, ptr %t1034, i32 %t1035)
  store ptr %t1040, ptr %l554
  br label %bb316
bb315:
  %t1041 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t1042 = load i1, ptr %t1041, !tbaa !21
  br i1 %t1042, label %bb324, label %bb325
bb316:
  %t1044 = load ptr, ptr %l4, !tbaa !29
  %t1046 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1044)
  store %"compiler/source:Span" %t1046, ptr %l556
  br label %bb317
bb317:
  %t1047 = load ptr, ptr %l549, !tbaa !29
  %t1048 = load ptr, ptr %l554, !tbaa !29
  %t1049 = load %"compiler/source:Span", ptr %l556
  %t1050 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1047, ptr %t1048, %"compiler/source:Span" %t1049)
  store ptr %t1050, ptr %l557
  br label %bb318
bb318:
  %t1051 = load ptr, ptr %l557, !tbaa !29
  store ptr %t1051, ptr %l27, !tbaa !29
  %t1053 = load ptr, ptr %l0, !tbaa !29
  %t1054 = load ptr, ptr %l3, !tbaa !29
  %t1055 = load %"compiler/check:litv", ptr %l15
  %t1056 = load ptr, ptr %l27, !tbaa !29
  %t1057 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1058 = load %"compiler/source:Span", ptr %l14
  %t1065 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v3, ptr %v3, ptr %t1053, ptr %t1054, %"compiler/check:litv" %t1055, ptr %t1056, i32 %t1057, %"compiler/source:Span" %t1058, i1 false)
  store ptr %t1065, ptr %l565
  br label %bb319
bb319:
  %t1066 = load ptr, ptr %l565, !tbaa !29
  store ptr %t1066, ptr %l26, !tbaa !29
  %t1067 = load ptr, ptr %l26, !tbaa !29
  %t1069 = icmp eq ptr %t1067, null
  br i1 %t1069, label %bb320, label %bb321
bb320:
  %t1071 = load ptr, ptr %l0, !tbaa !29
  %t1072 = load %"compiler/source:Span", ptr %l1
  %t1075 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1071, %"compiler/source:Span" %t1072)
  store ptr %t1075, ptr %l570
  br label %bb322
bb321:
  br label %bb323
bb322:
  call void @__olang_scope_close(ptr %s0)
  %t1076 = load ptr, ptr %l570, !tbaa !29
  store ptr %t1076, ptr %rv
  br label %ret
bb323:
  br label %bb440
bb324:
  %t1077 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t1078 = load i1, ptr %t1077, !tbaa !21
  %t1080 = xor i1 %t1078, true
  store i1 %t1080, ptr %l572, !tbaa !21
  br label %bb326
bb325:
  store i1 false, ptr %l572, !tbaa !21
  br label %bb326
bb326:
  %t1082 = load i1, ptr %l572, !tbaa !21
  br i1 %t1082, label %bb327, label %bb328
bb327:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1083, ptr %l575, !tbaa !29
  %t1084 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1084, ptr %l576, !tbaa !29
  %t1085 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t1085, ptr %l577
  %t1086 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1086, ptr %l578, !tbaa !29
  %t1087 = load i1, ptr %l17, !tbaa !21
  br i1 %t1087, label %bb329, label %bb330
bb328:
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1090 = load ptr, ptr %l4, !tbaa !29
  %t1093 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v2, ptr %t1089, ptr %t1090)
  store i1 %t1093, ptr %l635
  br label %bb357
bb329:
  %t1094 = load i32, ptr %l5, !tbaa !23
  store i32 %t1094, ptr %l580, !tbaa !23
  br label %bb331
bb330:
  %t1096 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1096, ptr %l580, !tbaa !23
  br label %bb331
bb331:
  %t1098 = load ptr, ptr %l576, !tbaa !29
  %t1099 = load i32, ptr %l577, !range !{i32 0, i32 116}
  %t1100 = load ptr, ptr %l578, !tbaa !29
  %t1101 = load i32, ptr %l580, !tbaa !23
  %t1102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t1098, i32 %t1099, ptr %t1100, i32 %t1101)
  store ptr %t1102, ptr %l583
  br label %bb332
bb332:
  %t1103 = load ptr, ptr %l3, !tbaa !29
  %t1105 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1103)
  store %"compiler/source:Span" %t1105, ptr %l585
  br label %bb333
bb333:
  %t1106 = load ptr, ptr %l575, !tbaa !29
  %t1107 = load ptr, ptr %l583, !tbaa !29
  %t1108 = load %"compiler/source:Span", ptr %l585
  %t1109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1106, ptr %t1107, %"compiler/source:Span" %t1108)
  store ptr %t1109, ptr %l586
  br label %bb334
bb334:
  %t1110 = load ptr, ptr %l586, !tbaa !29
  store ptr %t1110, ptr %l26, !tbaa !29
  %t1112 = load i1, ptr %l17, !tbaa !21
  br i1 %t1112, label %bb335, label %bb336
bb335:
  %t1114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1114, ptr %l589, !tbaa !29
  %t1115 = load ptr, ptr %l26, !tbaa !29
  %t1118 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1115)
  store i32 %t1118, ptr %l592
  br label %bb337
bb336:
  %t1119 = load ptr, ptr %l0, !tbaa !29
  %t1120 = load ptr, ptr %l4, !tbaa !29
  %t1121 = load %"compiler/check:litv", ptr %l16
  %t1122 = load ptr, ptr %l26, !tbaa !29
  %t1123 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1124 = load %"compiler/source:Span", ptr %l14
  %t1131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t1119, ptr %t1120, %"compiler/check:litv" %t1121, ptr %t1122, i32 %t1123, %"compiler/source:Span" %t1124, i1 true)
  store ptr %t1131, ptr %l627
  br label %bb351
bb337:
  %t1132 = load ptr, ptr %l589, !tbaa !29
  %t1133 = load i32, ptr %l592, !tbaa !23
  %t1134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t1132, i32 %t1133)
  store i32 %t1134, ptr %l593
  br label %bb338
bb338:
  %t1135 = load i32, ptr %l593, !tbaa !23
  store i32 %t1135, ptr %l29, !tbaa !23
  %t1136 = load ptr, ptr %l0, !tbaa !29
  %t1137 = load i32, ptr %l29, !tbaa !23
  %t1140 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1136, i32 %t1137)
  store i1 %t1140, ptr %l596
  br label %bb339
bb339:
  %t1141 = load i1, ptr %l596, !tbaa !21
  %t1142 = xor i1 %t1141, true
  br i1 %t1142, label %bb340, label %bb341
bb340:
  %t1144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1144, ptr %l598, !tbaa !29
  %t1145 = load ptr, ptr %l26, !tbaa !29
  %t1148 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1145)
  store i32 %t1148, ptr %l601
  br label %bb342
bb341:
  br label %bb344
bb342:
  %t1149 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1150 = load ptr, ptr %l598, !tbaa !29
  %t1151 = load i32, ptr %l601, !tbaa !23
  %t1153 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t1150, i32 %t1151, i32 %t1149)
  store i32 %t1153, ptr %l603
  br label %bb343
bb343:
  %t1154 = load i32, ptr %l603, !tbaa !23
  store i32 %t1154, ptr %l29, !tbaa !23
  br label %bb344
bb344:
  %t1155 = load ptr, ptr %l0, !tbaa !29
  %t1156 = load %"compiler/check:litv", ptr %l16
  %t1157 = load i32, ptr %l29, !tbaa !23
  %t1161 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t1155, %"compiler/check:litv" %t1156, i32 %t1157)
  store i1 %t1161, ptr %l607
  br label %bb345
bb345:
  %t1162 = load i1, ptr %l607, !tbaa !21
  br i1 %t1162, label %bb346, label %bb347
bb346:
  %t1163 = load ptr, ptr %l0, !tbaa !29
  %t1164 = load ptr, ptr %l4, !tbaa !29
  %t1165 = load %"compiler/check:litv", ptr %l16
  %t1166 = load i32, ptr %l29, !tbaa !23
  %t1171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %v3, ptr %t1163, ptr %t1164, %"compiler/check:litv" %t1165, i32 %t1166)
  store ptr %t1171, ptr %l613
  br label %bb348
bb347:
  %t1172 = load ptr, ptr %l0, !tbaa !29
  %t1173 = load ptr, ptr %l4, !tbaa !29
  %t1174 = load %"compiler/check:litv", ptr %l16
  %t1175 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %v3, ptr %t1172, ptr %t1173, %"compiler/check:litv" %t1174, i32 %t1175)
  store ptr %t1180, ptr %l619
  br label %bb349
bb348:
  %t1181 = load ptr, ptr %l613, !tbaa !29
  store ptr %t1181, ptr %l608, !tbaa !29
  br label %bb350
bb349:
  %t1183 = load ptr, ptr %l619, !tbaa !29
  store ptr %t1183, ptr %l608, !tbaa !29
  br label %bb350
bb350:
  %t1185 = load ptr, ptr %l608, !tbaa !29
  store ptr %t1185, ptr %l27, !tbaa !29
  br label %bb356
bb351:
  %t1186 = load ptr, ptr %l627, !tbaa !29
  store ptr %t1186, ptr %l27, !tbaa !29
  %t1187 = load ptr, ptr %l27, !tbaa !29
  %t1189 = icmp eq ptr %t1187, null
  br i1 %t1189, label %bb352, label %bb353
bb352:
  %t1191 = load ptr, ptr %l0, !tbaa !29
  %t1192 = load %"compiler/source:Span", ptr %l1
  %t1195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1191, %"compiler/source:Span" %t1192)
  store ptr %t1195, ptr %l632
  br label %bb354
bb353:
  br label %bb355
bb354:
  call void @__olang_scope_close(ptr %s0)
  %t1196 = load ptr, ptr %l632, !tbaa !29
  store ptr %t1196, ptr %rv
  br label %ret
bb355:
  br label %bb356
bb356:
  br label %bb439
bb357:
  %t1197 = load i1, ptr %l635, !tbaa !21
  br i1 %t1197, label %bb358, label %bb359
bb358:
  %t1198 = load ptr, ptr %l0, !tbaa !29
  %t1199 = load ptr, ptr %l3, !tbaa !29
  %t1202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t1198, ptr %t1199)
  store i1 %t1202, ptr %l639
  br label %bb360
bb359:
  store i1 false, ptr %l636, !tbaa !21
  br label %bb361
bb360:
  %t1203 = load i1, ptr %l639, !tbaa !21
  %t1204 = xor i1 %t1203, true
  store i1 %t1204, ptr %l636, !tbaa !21
  br label %bb361
bb361:
  %t1206 = load i1, ptr %l636, !tbaa !21
  br i1 %t1206, label %bb362, label %bb363
bb362:
  %t1207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1207, ptr %l641, !tbaa !29
  %t1208 = load ptr, ptr %l0, !tbaa !29
  %t1209 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1210 = load ptr, ptr %l3, !tbaa !29
  %t1211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t1208, i32 %t1209, ptr %t1210, i32 %t1211)
  store ptr %t1216, ptr %l646
  br label %bb364
bb363:
  %t1217 = load ptr, ptr %l0, !tbaa !29
  %t1218 = load ptr, ptr %l3, !tbaa !29
  %t1221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t1217, ptr %t1218)
  store i1 %t1221, ptr %l674
  br label %bb377
bb364:
  %t1222 = load ptr, ptr %l3, !tbaa !29
  %t1224 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1222)
  store %"compiler/source:Span" %t1224, ptr %l648
  br label %bb365
bb365:
  %t1225 = load ptr, ptr %l641, !tbaa !29
  %t1226 = load ptr, ptr %l646, !tbaa !29
  %t1227 = load %"compiler/source:Span", ptr %l648
  %t1228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1225, ptr %t1226, %"compiler/source:Span" %t1227)
  store ptr %t1228, ptr %l649
  br label %bb366
bb366:
  %t1229 = load ptr, ptr %l649, !tbaa !29
  store ptr %t1229, ptr %l26, !tbaa !29
  %t1231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1231, ptr %l651, !tbaa !29
  %t1232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1232, ptr %l652, !tbaa !29
  %t1233 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t1233, ptr %l653
  %t1234 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1234, ptr %l654, !tbaa !29
  %t1235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1235, ptr %l655, !tbaa !29
  %t1236 = load ptr, ptr %l26, !tbaa !29
  %t1239 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1236)
  store i32 %t1239, ptr %l658
  br label %bb367
bb367:
  %t1240 = load ptr, ptr %l655, !tbaa !29
  %t1241 = load i32, ptr %l658, !tbaa !23
  %t1242 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1240, i32 %t1241)
  store i1 %t1242, ptr %l659
  br label %bb368
bb368:
  %t1243 = load i1, ptr %l659, !tbaa !21
  br i1 %t1243, label %bb369, label %bb370
bb369:
  %t1244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1244, ptr %l661, !tbaa !29
  %t1245 = load ptr, ptr %l26, !tbaa !29
  %t1248 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1245)
  store i32 %t1248, ptr %l664
  br label %bb371
bb370:
  %t1249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1249, ptr %l660, !tbaa !23
  br label %bb373
bb371:
  %t1251 = load ptr, ptr %l661, !tbaa !29
  %t1252 = load i32, ptr %l664, !tbaa !23
  %t1253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t1251, i32 %t1252)
  store i32 %t1253, ptr %l665
  br label %bb372
bb372:
  %t1254 = load i32, ptr %l665, !tbaa !23
  store i32 %t1254, ptr %l660, !tbaa !23
  br label %bb373
bb373:
  %t1255 = load ptr, ptr %l652, !tbaa !29
  %t1256 = load i32, ptr %l653, !range !{i32 0, i32 116}
  %t1257 = load ptr, ptr %l654, !tbaa !29
  %t1258 = load i32, ptr %l660, !tbaa !23
  %t1259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t1255, i32 %t1256, ptr %t1257, i32 %t1258)
  store ptr %t1259, ptr %l667
  br label %bb374
bb374:
  %t1260 = load ptr, ptr %l4, !tbaa !29
  %t1262 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1260)
  store %"compiler/source:Span" %t1262, ptr %l669
  br label %bb375
bb375:
  %t1263 = load ptr, ptr %l651, !tbaa !29
  %t1264 = load ptr, ptr %l667, !tbaa !29
  %t1265 = load %"compiler/source:Span", ptr %l669
  %t1266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1263, ptr %t1264, %"compiler/source:Span" %t1265)
  store ptr %t1266, ptr %l670
  br label %bb376
bb376:
  %t1267 = load ptr, ptr %l670, !tbaa !29
  store ptr %t1267, ptr %l27, !tbaa !29
  br label %bb438
bb377:
  %t1269 = load i1, ptr %l674, !tbaa !21
  br i1 %t1269, label %bb378, label %bb379
bb378:
  %t1270 = load ptr, ptr %l0, !tbaa !29
  %t1271 = load ptr, ptr %l4, !tbaa !29
  %t1274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v2, ptr %t1270, ptr %t1271)
  store i1 %t1274, ptr %l678
  br label %bb380
bb379:
  store i1 false, ptr %l675, !tbaa !21
  br label %bb381
bb380:
  %t1275 = load i1, ptr %l678, !tbaa !21
  %t1276 = xor i1 %t1275, true
  store i1 %t1276, ptr %l675, !tbaa !21
  br label %bb381
bb381:
  %t1278 = load i1, ptr %l675, !tbaa !21
  br i1 %t1278, label %bb382, label %bb383
bb382:
  %t1279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1279, ptr %l680, !tbaa !29
  %t1280 = load ptr, ptr %l0, !tbaa !29
  %t1281 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1282 = load ptr, ptr %l4, !tbaa !29
  %t1283 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t1280, i32 %t1281, ptr %t1282, i32 %t1283)
  store ptr %t1288, ptr %l685
  br label %bb384
bb383:
  %t1289 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 0
  %t1290 = load i1, ptr %t1289, !tbaa !21
  br i1 %t1290, label %bb397, label %bb398
bb384:
  %t1292 = load ptr, ptr %l4, !tbaa !29
  %t1294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1292)
  store %"compiler/source:Span" %t1294, ptr %l687
  br label %bb385
bb385:
  %t1295 = load ptr, ptr %l680, !tbaa !29
  %t1296 = load ptr, ptr %l685, !tbaa !29
  %t1297 = load %"compiler/source:Span", ptr %l687
  %t1298 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1295, ptr %t1296, %"compiler/source:Span" %t1297)
  store ptr %t1298, ptr %l688
  br label %bb386
bb386:
  %t1299 = load ptr, ptr %l688, !tbaa !29
  store ptr %t1299, ptr %l27, !tbaa !29
  %t1301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1301, ptr %l690, !tbaa !29
  %t1302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1302, ptr %l691, !tbaa !29
  %t1303 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t1303, ptr %l692
  %t1304 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1304, ptr %l693, !tbaa !29
  %t1305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1305, ptr %l694, !tbaa !29
  %t1306 = load ptr, ptr %l27, !tbaa !29
  %t1309 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1306)
  store i32 %t1309, ptr %l697
  br label %bb387
bb387:
  %t1310 = load ptr, ptr %l694, !tbaa !29
  %t1311 = load i32, ptr %l697, !tbaa !23
  %t1312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1310, i32 %t1311)
  store i1 %t1312, ptr %l698
  br label %bb388
bb388:
  %t1313 = load i1, ptr %l698, !tbaa !21
  br i1 %t1313, label %bb389, label %bb390
bb389:
  %t1314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1314, ptr %l700, !tbaa !29
  %t1315 = load ptr, ptr %l27, !tbaa !29
  %t1318 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t1315)
  store i32 %t1318, ptr %l703
  br label %bb391
bb390:
  %t1319 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1319, ptr %l699, !tbaa !23
  br label %bb393
bb391:
  %t1321 = load ptr, ptr %l700, !tbaa !29
  %t1322 = load i32, ptr %l703, !tbaa !23
  %t1323 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t1321, i32 %t1322)
  store i32 %t1323, ptr %l704
  br label %bb392
bb392:
  %t1324 = load i32, ptr %l704, !tbaa !23
  store i32 %t1324, ptr %l699, !tbaa !23
  br label %bb393
bb393:
  %t1325 = load ptr, ptr %l691, !tbaa !29
  %t1326 = load i32, ptr %l692, !range !{i32 0, i32 116}
  %t1327 = load ptr, ptr %l693, !tbaa !29
  %t1328 = load i32, ptr %l699, !tbaa !23
  %t1329 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t1325, i32 %t1326, ptr %t1327, i32 %t1328)
  store ptr %t1329, ptr %l706
  br label %bb394
bb394:
  %t1330 = load ptr, ptr %l3, !tbaa !29
  %t1332 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1330)
  store %"compiler/source:Span" %t1332, ptr %l708
  br label %bb395
bb395:
  %t1333 = load ptr, ptr %l690, !tbaa !29
  %t1334 = load ptr, ptr %l706, !tbaa !29
  %t1335 = load %"compiler/source:Span", ptr %l708
  %t1336 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1333, ptr %t1334, %"compiler/source:Span" %t1335)
  store ptr %t1336, ptr %l709
  br label %bb396
bb396:
  %t1337 = load ptr, ptr %l709, !tbaa !29
  store ptr %t1337, ptr %l26, !tbaa !29
  br label %bb437
bb397:
  %t1339 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t1340 = load i1, ptr %t1339, !tbaa !21
  store i1 %t1340, ptr %l712, !tbaa !21
  br label %bb399
bb398:
  store i1 false, ptr %l712, !tbaa !21
  br label %bb399
bb399:
  %t1342 = load i1, ptr %l712, !tbaa !21
  br i1 %t1342, label %bb400, label %bb401
bb400:
  %t1343 = getelementptr %"compiler/check:litv", ptr %l15, i32 0, i32 1
  %t1344 = load i1, ptr %t1343, !tbaa !21
  %t1346 = xor i1 %t1344, true
  store i1 %t1346, ptr %l714, !tbaa !21
  br label %bb402
bb401:
  store i1 false, ptr %l714, !tbaa !21
  br label %bb402
bb402:
  %t1348 = load i1, ptr %l714, !tbaa !21
  br i1 %t1348, label %bb403, label %bb404
bb403:
  %t1349 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 1
  %t1350 = load i1, ptr %t1349, !tbaa !21
  %t1352 = xor i1 %t1350, true
  store i1 %t1352, ptr %l717, !tbaa !21
  br label %bb405
bb404:
  store i1 false, ptr %l717, !tbaa !21
  br label %bb405
bb405:
  %t1354 = load i1, ptr %l717, !tbaa !21
  br i1 %t1354, label %bb406, label %bb407
bb406:
  %t1355 = load i1, ptr %l17, !tbaa !21
  %t1357 = xor i1 %t1355, true
  store i1 %t1357, ptr %l720, !tbaa !21
  br label %bb408
bb407:
  store i1 false, ptr %l720, !tbaa !21
  br label %bb408
bb408:
  %t1359 = load i1, ptr %l720, !tbaa !21
  br i1 %t1359, label %bb409, label %bb410
bb409:
  %t1360 = load ptr, ptr %l0, !tbaa !29
  %t1361 = load ptr, ptr %l3, !tbaa !29
  %t1364 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t1360, ptr %t1361)
  store i1 %t1364, ptr %l726
  br label %bb411
bb410:
  store i1 false, ptr %l723, !tbaa !21
  br label %bb416
bb411:
  %t1365 = load i1, ptr %l726, !tbaa !21
  br i1 %t1365, label %bb412, label %bb413
bb412:
  store i1 true, ptr %l727, !tbaa !21
  br label %bb415
bb413:
  %t1366 = load ptr, ptr %l0, !tbaa !29
  %t1367 = load ptr, ptr %l4, !tbaa !29
  %t1370 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v2, ptr %t1366, ptr %t1367)
  store i1 %t1370, ptr %l730
  br label %bb414
bb414:
  %t1371 = load i1, ptr %l730, !tbaa !21
  store i1 %t1371, ptr %l727, !tbaa !21
  br label %bb415
bb415:
  %t1372 = load i1, ptr %l727, !tbaa !21
  store i1 %t1372, ptr %l723, !tbaa !21
  br label %bb416
bb416:
  %t1373 = load i1, ptr %l723, !tbaa !21
  br i1 %t1373, label %bb417, label %bb418
bb417:
  store %olang.scope zeroinitializer, ptr %s36
  %t1374 = load ptr, ptr %l0, !tbaa !29
  %t1376 = getelementptr %"compiler/check:Checker", ptr %t1374, i32 0, i32 1
  %t1377 = load ptr, ptr %t1376, !tbaa !29
  %t1379 = getelementptr %"compiler/generic:Program", ptr %t1377, i32 0, i32 2
  %t1381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s36, ptr %t1379, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i32 %t1381, ptr %l734
  br label %bb419
bb418:
  %t1382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1382, ptr %l759, !tbaa !29
  %t1383 = load ptr, ptr %l0, !tbaa !29
  %t1384 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1385 = load ptr, ptr %l3, !tbaa !29
  %t1386 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1391 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v0, ptr %t1383, i32 %t1384, ptr %t1385, i32 %t1386)
  store ptr %t1391, ptr %l764
  br label %bb430
bb419:
  %t1392 = load i32, ptr %l734, !tbaa !23
  store i32 %t1392, ptr %l30, !tbaa !23
  %t1393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1393, ptr %l735, !tbaa !29
  %t1394 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1394, ptr %l736, !tbaa !29
  %t1395 = load %"compiler/check:litv", ptr %l15
  store %"compiler/check:litv" %t1395, ptr %l737
  %t1396 = load ptr, ptr %l0, !tbaa !29
  %t1397 = load %"compiler/check:litv", ptr %l15
  %t1398 = load i32, ptr %l30, !tbaa !23
  %t1402 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t1396, %"compiler/check:litv" %t1397, i32 %t1398)
  store i1 %t1402, ptr %l741
  br label %bb420
bb420:
  %t1403 = load i1, ptr %l741, !tbaa !21
  br i1 %t1403, label %bb421, label %bb422
bb421:
  %t1404 = load i32, ptr %l30, !tbaa !23
  store i32 %t1404, ptr %l742, !tbaa !23
  br label %bb423
bb422:
  %t1406 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1406, ptr %l742, !tbaa !23
  br label %bb423
bb423:
  %t1408 = load ptr, ptr %l735, !tbaa !29
  %t1409 = load ptr, ptr %l736, !tbaa !29
  %t1410 = load %"compiler/check:litv", ptr %l737
  %t1411 = load i32, ptr %l742, !tbaa !23
  %t1412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t1408, ptr %t1409, %"compiler/check:litv" %t1410, i32 %t1411)
  store ptr %t1412, ptr %l745
  br label %bb424
bb424:
  %t1413 = load ptr, ptr %l745, !tbaa !29
  store ptr %t1413, ptr %l26, !tbaa !29
  %t1415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1415, ptr %l747, !tbaa !29
  %t1416 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1416, ptr %l748, !tbaa !29
  %t1417 = load %"compiler/check:litv", ptr %l16
  store %"compiler/check:litv" %t1417, ptr %l749
  %t1418 = load ptr, ptr %l0, !tbaa !29
  %t1419 = load %"compiler/check:litv", ptr %l16
  %t1420 = load i32, ptr %l30, !tbaa !23
  %t1424 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t1418, %"compiler/check:litv" %t1419, i32 %t1420)
  store i1 %t1424, ptr %l753
  br label %bb425
bb425:
  %t1425 = load i1, ptr %l753, !tbaa !21
  br i1 %t1425, label %bb426, label %bb427
bb426:
  %t1426 = load i32, ptr %l30, !tbaa !23
  store i32 %t1426, ptr %l754, !tbaa !23
  br label %bb428
bb427:
  %t1428 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1428, ptr %l754, !tbaa !23
  br label %bb428
bb428:
  %t1430 = load ptr, ptr %l747, !tbaa !29
  %t1431 = load ptr, ptr %l748, !tbaa !29
  %t1432 = load %"compiler/check:litv", ptr %l749
  %t1433 = load i32, ptr %l754, !tbaa !23
  %t1434 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %v3, ptr %t1430, ptr %t1431, %"compiler/check:litv" %t1432, i32 %t1433)
  store ptr %t1434, ptr %l757
  br label %bb429
bb429:
  %t1435 = load ptr, ptr %l757, !tbaa !29
  store ptr %t1435, ptr %l27, !tbaa !29
  call void @__olang_scope_close(ptr %s36)
  br label %bb436
bb430:
  %t1437 = load ptr, ptr %l3, !tbaa !29
  %t1439 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1437)
  store %"compiler/source:Span" %t1439, ptr %l766
  br label %bb431
bb431:
  %t1440 = load ptr, ptr %l759, !tbaa !29
  %t1441 = load ptr, ptr %l764, !tbaa !29
  %t1442 = load %"compiler/source:Span", ptr %l766
  %t1443 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1440, ptr %t1441, %"compiler/source:Span" %t1442)
  store ptr %t1443, ptr %l767
  br label %bb432
bb432:
  %t1444 = load ptr, ptr %l767, !tbaa !29
  store ptr %t1444, ptr %l26, !tbaa !29
  %t1446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1446, ptr %l769, !tbaa !29
  %t1447 = load ptr, ptr %l0, !tbaa !29
  %t1448 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t1449 = load ptr, ptr %l4, !tbaa !29
  %t1450 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1455 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v2, ptr %v0, ptr %t1447, i32 %t1448, ptr %t1449, i32 %t1450)
  store ptr %t1455, ptr %l774
  br label %bb433
bb433:
  %t1456 = load ptr, ptr %l4, !tbaa !29
  %t1458 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1456)
  store %"compiler/source:Span" %t1458, ptr %l776
  br label %bb434
bb434:
  %t1459 = load ptr, ptr %l769, !tbaa !29
  %t1460 = load ptr, ptr %l774, !tbaa !29
  %t1461 = load %"compiler/source:Span", ptr %l776
  %t1462 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t1459, ptr %t1460, %"compiler/source:Span" %t1461)
  store ptr %t1462, ptr %l777
  br label %bb435
bb435:
  %t1463 = load ptr, ptr %l777, !tbaa !29
  store ptr %t1463, ptr %l27, !tbaa !29
  br label %bb436
bb436:
  br label %bb437
bb437:
  br label %bb438
bb438:
  br label %bb439
bb439:
  br label %bb440
bb440:
  br label %bb441
bb441:
  %t1465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1465, ptr %l779, !tbaa !29
  %t1466 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1466, ptr %l780
  %t1467 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t1467, ptr %l781
  %t1468 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t1468, ptr %l782
  %t1469 = load ptr, ptr %l26, !tbaa !29
  %t1471 = icmp eq ptr %t1469, null
  br i1 %t1471, label %bb442, label %bb443
bb442:
  call void @__olang_check_failed(ptr @olang_loc_65fe1e2545381fa4_5766bfa4307d0508)
  unreachable
bb443:
  br label %bb444
bb444:
  %t1473 = load ptr, ptr %l26, !tbaa !29
  store ptr %t1473, ptr %l785, !tbaa !29
  %t1474 = load ptr, ptr %l27, !tbaa !29
  %t1476 = icmp eq ptr %t1474, null
  br i1 %t1476, label %bb445, label %bb446
bb445:
  call void @__olang_check_failed(ptr @olang_loc_65fe1e2545381fa4_5766bfa4307d0508)
  unreachable
bb446:
  br label %bb447
bb447:
  %t1478 = load ptr, ptr %l27, !tbaa !29
  %t1479 = load ptr, ptr %l3, !tbaa !29
  %t1480 = load ptr, ptr %l4, !tbaa !29
  %t1481 = load ptr, ptr %l779, !tbaa !29
  %t1482 = load %"compiler/source:Span", ptr %l780
  %t1483 = load %"compiler/source:Span", ptr %l781
  %t1484 = load i32, ptr %l782, !range !{i32 0, i32 116}
  %t1485 = load ptr, ptr %l785, !tbaa !29
  %t1489 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAst(ptr %v0, ptr %v3, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t1481, %"compiler/source:Span" %t1482, %"compiler/source:Span" %t1483, i32 %t1484, ptr %t1485, ptr %t1478, ptr %t1479, ptr %t1480)
  store ptr %t1489, ptr %l791
  br label %bb448
bb448:
  call void @__olang_scope_close(ptr %s0)
  %t1490 = load ptr, ptr %l791, !tbaa !29
  store ptr %t1490, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundsMet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca { i64, ptr }
  %l41 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l58 = alloca i32
  %l60 = alloca { i64, ptr }
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l14, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  br label %bb24
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Binding", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = icmp ne i32 %t61, %t62
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t76 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t70, i64 %t71, i64 %t72)
  store i1 %t76, ptr %l46
  br label %bb13
bb12:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb14
bb13:
  %t77 = load i1, ptr %l46, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t80 = load i1, ptr %l41, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %l52, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Binding", ptr %t93, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  store i32 %t99, ptr %l58
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Binding", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l60, !tbaa !27
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load ptr, ptr %l50, !tbaa !29
  %t111 = load i64, ptr %l51, !tbaa !24
  %t112 = load i64, ptr %l52, !tbaa !24
  %t113 = load i32, ptr %l58, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t110, i64 %t111, i64 %t112, i32 %t113, i32 %t109)
  store i1 %t115, ptr %l63
  br label %bb18
bb18:
  %t116 = load i1, ptr %l63, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb7
bb24:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderOwnerOk(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l13 = alloca i64
  %l19 = alloca ptr
  %l26 = alloca i32
  %l32 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i1
  %l58 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l81 = alloca i32
  %l86 = alloca i1
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l98 = alloca i64
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca { i64, ptr }
  %l110 = alloca %"compiler/diagmsg:Msg"
  %l111 = alloca i64
  %l115 = alloca i32
  %l119 = alloca i1
  %l123 = alloca i1
  %l127 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca i64
  %l151 = alloca i1
  %l153 = alloca i1
  %l159 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l167 = alloca { i64, ptr }
  %l169 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca i64
  %l176 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l19
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l19, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 3
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l26
  br label %bb3
bb3:
  %t38 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t40 = trunc i64 25 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l39
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s2, ptr %v0, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t65, ptr %l41
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l36
  %t68 = load %"compiler/diagmsg:Msg", ptr %l41
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, %"compiler/diagmsg:Msg" %t68)
  store i64 %t69, ptr %l42
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = shl i64 1, 40
  %t78 = sub i64 %t76, 1
  %t81 = and i64 %t75, %t78
  %t83 = trunc i64 %t81 to i32
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t74, i32 %t83)
  store i64 %t87, ptr %l52
  br label %bb13
bb13:
  %t88 = load i64, ptr %l52, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l4, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb15:
  %t95 = load i1, ptr %l5, !tbaa !21
  br i1 %t95, label %bb16, label %bb17
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/load:Loader", ptr %t103, i32 0, i32 10
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t105, i64 %t106)
  store ptr %t109, ptr %l64
  br label %bb18
bb17:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb19
bb18:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t112 = getelementptr %"compiler/load:Module", ptr %t110, i32 0, i32 3
  %t113 = load i1, ptr %t112, !tbaa !21
  store i1 %t113, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t115 = load i1, ptr %l58, !tbaa !21
  store i1 %t115, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t116 = load i1, ptr %l56, !tbaa !21
  br i1 %t116, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l68, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t119, ptr %l69
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t120, i32 %t121)
  store { i64, ptr } %t124, ptr %l72
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t127 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s1, ptr %v0, { i64, ptr } %t125)
  store %"compiler/diagmsg:Msg" %t127, ptr %l74
  br label %bb25
bb25:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l69
  %t130 = load %"compiler/diagmsg:Msg", ptr %l74
  %t131 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t128, %"compiler/source:Span" %t129, %"compiler/diagmsg:Msg" %t130)
  store i64 %t131, ptr %l75
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb27:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l2, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l81
  br label %bb28
bb28:
  %t143 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t145 = trunc i64 18 to i32
  %t146 = icmp eq i32 %t143, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load i1, ptr %l5, !tbaa !21
  br i1 %t150, label %bb31, label %bb32
bb30:
  br label %bb47
bb31:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  %t159 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t159, ptr %l90
  br label %bb33
bb32:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb34
bb33:
  %t160 = load i64, ptr %l90, !tbaa !24
  %t161 = icmp sge i64 %t160, 0
  store i1 %t161, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t163 = load i1, ptr %l86, !tbaa !21
  br i1 %t163, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l93, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t166, ptr %l94
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l1, !tbaa !24
  %t174 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %t170, i64 %t171)
  store i64 %t174, ptr %l98
  br label %bb38
bb38:
  %t175 = load i64, ptr %l98, !tbaa !24
  %t176 = icmp sge i64 %t175, 0
  br i1 %t176, label %bb39, label %bb40
bb39:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l2, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t178, i32 %t179)
  store { i64, ptr } %t182, ptr %l103
  br label %bb41
bb40:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l2, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l108
  br label %bb43
bb41:
  %t188 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t190 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s4, ptr %v0, { i64, ptr } %t188)
  store %"compiler/diagmsg:Msg" %t190, ptr %l105
  br label %bb42
bb42:
  %t191 = load %"compiler/diagmsg:Msg", ptr %l105
  store %"compiler/diagmsg:Msg" %t191, ptr %l100
  br label %bb45
bb43:
  %t192 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t194 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s4, ptr %v0, { i64, ptr } %t192)
  store %"compiler/diagmsg:Msg" %t194, ptr %l110
  br label %bb44
bb44:
  %t195 = load %"compiler/diagmsg:Msg", ptr %l110
  store %"compiler/diagmsg:Msg" %t195, ptr %l100
  br label %bb45
bb45:
  %t196 = load ptr, ptr %l93, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l94
  %t198 = load %"compiler/diagmsg:Msg", ptr %l100
  %t199 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197, %"compiler/diagmsg:Msg" %t198)
  store i64 %t199, ptr %l111
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb47:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l2, !tbaa !23
  %t205 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l115
  br label %bb48
bb48:
  %t206 = load i32, ptr %l115, !range !{i32 0, i32 6}
  store i32 %t206, ptr %l8
  %t207 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t209 = trunc i64 0 to i32
  %t210 = icmp eq i32 %t207, %t209
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb49, label %bb50
bb49:
  %t214 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t216 = trunc i64 1 to i32
  %t217 = icmp eq i32 %t214, %t216
  %t219 = xor i1 %t217, true
  store i1 %t219, ptr %l119, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb51
bb51:
  %t221 = load i1, ptr %l119, !tbaa !21
  br i1 %t221, label %bb52, label %bb53
bb52:
  %t222 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t224 = trunc i64 4 to i32
  %t225 = icmp eq i32 %t222, %t224
  %t227 = xor i1 %t225, true
  store i1 %t227, ptr %l123, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb54
bb54:
  %t229 = load i1, ptr %l123, !tbaa !21
  br i1 %t229, label %bb55, label %bb56
bb55:
  %t230 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t232 = trunc i64 5 to i32
  %t233 = icmp eq i32 %t230, %t232
  %t235 = xor i1 %t233, true
  store i1 %t235, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t237 = load i1, ptr %l127, !tbaa !21
  br i1 %t237, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s6
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l131, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t239, ptr %l132
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l2, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l135
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t245 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t247 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %s6, ptr %v0, { i64, ptr } %t245)
  store %"compiler/diagmsg:Msg" %t247, ptr %l137
  br label %bb61
bb61:
  %t248 = load ptr, ptr %l131, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l132
  %t250 = load %"compiler/diagmsg:Msg", ptr %l137
  %t251 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t248, %"compiler/source:Span" %t249, %"compiler/diagmsg:Msg" %t250)
  store i64 %t251, ptr %l138
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
bb63:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  store ptr %t256, ptr %l141, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l2, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t262, i32 %t263)
  store i32 %t266, ptr %l146
  br label %bb64
bb64:
  %t267 = load ptr, ptr %l141, !tbaa !29
  %t268 = load i32, ptr %l146, !tbaa !23
  %t269 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t267, i32 %t268)
  store i64 %t269, ptr %l147
  br label %bb65
bb65:
  %t270 = load i64, ptr %l147, !tbaa !24
  store i64 %t270, ptr %l9, !tbaa !24
  %t271 = load i64, ptr %l9, !tbaa !24
  %t272 = load i64, ptr %l4, !tbaa !24
  %t275 = icmp ne i64 %t271, %t272
  br i1 %t275, label %bb66, label %bb67
bb66:
  %t277 = load i1, ptr %l5, !tbaa !21
  br i1 %t277, label %bb68, label %bb69
bb67:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb72
bb68:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 10
  %t288 = load i64, ptr %l9, !tbaa !24
  %t291 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t287, i64 %t288)
  store ptr %t291, ptr %l159
  br label %bb70
bb69:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb71
bb70:
  %t292 = load ptr, ptr %l159, !tbaa !29
  %t294 = getelementptr %"compiler/load:Module", ptr %t292, i32 0, i32 3
  %t295 = load i1, ptr %t294, !tbaa !21
  store i1 %t295, ptr %l153, !tbaa !21
  br label %bb71
bb71:
  %t297 = load i1, ptr %l153, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l151, !tbaa !21
  br label %bb72
bb72:
  %t300 = load i1, ptr %l151, !tbaa !21
  br i1 %t300, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s7
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l163, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t302, ptr %l164
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t303, i32 %t304)
  store { i64, ptr } %t307, ptr %l167
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t308 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t310 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %s7, ptr %v0, { i64, ptr } %t308)
  store %"compiler/diagmsg:Msg" %t310, ptr %l169
  br label %bb76
bb76:
  %t311 = load ptr, ptr %l163, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l164
  %t313 = load %"compiler/diagmsg:Msg", ptr %l169
  %t314 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t311, %"compiler/source:Span" %t312, %"compiler/diagmsg:Msg" %t313)
  store i64 %t314, ptr %l170
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s7)
  store i1 false, ptr %rv
  br label %ret
bb78:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i64, ptr %l1, !tbaa !24
  %t318 = load i32, ptr %l2, !tbaa !23
  %t319 = load %"compiler/source:Span", ptr %l3
  %t324 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerWritten(ptr %v0, ptr %t316, i64 %t317, i32 %t318, %"compiler/source:Span" %t319)
  store i1 %t324, ptr %l176
  br label %bb79
bb79:
  %t325 = load i1, ptr %l176, !tbaa !21
  store i1 %t325, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp ne i32 %t12, %t13
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t20)
  store %"compiler/source:Span" %t22, ptr %l16
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l19
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t30 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %v0, { i64, ptr } %t28)
  store %"compiler/diagmsg:Msg" %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l14, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l16
  %t33 = load %"compiler/diagmsg:Msg", ptr %l21
  %t34 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/diagmsg:Msg" %t33)
  store i64 %t34, ptr %l22
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t36)
  store %"compiler/source:Span" %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l25
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t39, %"compiler/source:Span" %t40)
  store ptr %t41, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %l26, !tbaa !29
  store ptr %t42, ptr %rv
  br label %ret
bb13:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultTypes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca %"compiler/generic:varRow"
  %l62 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %l99 = alloca i32
  %l101 = alloca { i64, ptr }
  %l110 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i64
  %l122 = alloca i32
  %l123 = alloca i32
  %l127 = alloca i1
  %l132 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i64
  %l137 = alloca i64
  %l143 = alloca i32
  %l145 = alloca i1
  %l147 = alloca i1
  %l151 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca ptr
  %l159 = alloca %"compiler/generic:varRow"
  %l161 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l166 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca %"compiler/diagmsg:Msg"
  %l175 = alloca i64
  %l178 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l28, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l28, !tbaa !24
  store i64 %t32, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l9, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb65
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  store i64 %t50, ptr %l10, !tbaa !24
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Binding", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l47, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = icmp ne i32 %t61, %t62
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb12:
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t76 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t70, i64 %t71, i64 %t72)
  store %"compiler/generic:varRow" %t76, ptr %l56
  br label %bb14
bb14:
  %t77 = getelementptr %"compiler/generic:varRow", ptr %l56, i32 0, i32 4
  %t78 = load i32, ptr %t77, !tbaa !23
  store i32 %t78, ptr %l11, !tbaa !23
  %t80 = load i32, ptr %l11, !tbaa !23
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb16:
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Binding", ptr %t86, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l62, !tbaa !24
  %t90 = load i64, ptr %l62, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = load i64, ptr %l62, !tbaa !24
  %t94 = icmp sle i64 %t93, 2305843009213693951
  br i1 %t94, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f6b13c9d74679e52_66e9acddac9b88a6)
  unreachable
bb20:
  %t96 = load i64, ptr %l62, !tbaa !24
  %t97 = mul i64 %t96, 4
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Binding", ptr %t102, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  store i64 %t105, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f6b13c9d74679e52_66e9acddac9b88a6)
  unreachable
bb22:
  %t113 = load i64, ptr %l15, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb27
bb24:
  %t117 = load i64, ptr %l14, !tbaa !24
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l15, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l74, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb26
bb26:
  %t133 = load i64, ptr %l74, !tbaa !24
  store i64 %t133, ptr %l71, !tbaa !24
  br label %bb27
bb27:
  %t134 = load i64, ptr %l71, !tbaa !24
  store i64 %t134, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb28
bb28:
  %t135 = load i64, ptr %l17, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t143 = load i64, ptr %l13, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l18, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  store i64 %t153, ptr %l92, !tbaa !24
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Binding", ptr %t154, i32 0, i32 2
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l94, !tbaa !27
  %t158 = load i64, ptr %l18, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i32, ptr %t161, i64 %t158
  %t163 = load i32, ptr %t162, !tbaa !33
  %t164 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t167 = icmp ne i32 %t163, %t164
  br i1 %t167, label %bb32, label %bb33
bb32:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Binding", ptr %t169, i32 0, i32 2
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l101, !tbaa !27
  %t173 = load i64, ptr %l18, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t173
  %t178 = load i32, ptr %t177, !tbaa !33
  store i32 %t178, ptr %l99, !tbaa !23
  br label %bb35
bb33:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i64, ptr %l3, !tbaa !24
  %t187 = load i64, ptr %l18, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t185, i64 %t186, i64 %t187, i64 %t188)
  store i32 %t193, ptr %l110
  br label %bb34
bb34:
  %t194 = load i32, ptr %l110, !tbaa !23
  store i32 %t194, ptr %l99, !tbaa !23
  br label %bb35
bb35:
  %t195 = load i32, ptr %l99, !tbaa !23
  %t196 = load i64, ptr %l92, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i32, ptr %t198, i64 %t196
  store i32 %t195, ptr %t199, !tbaa !33
  br label %bb36
bb36:
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l17, !tbaa !24
  br label %bb28
bb37:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  store ptr %t208, ptr %l115, !tbaa !29
  %t209 = load i32, ptr %l11, !tbaa !23
  store i32 %t209, ptr %l116, !tbaa !23
  %t210 = load i64, ptr %l3, !tbaa !24
  store i64 %t210, ptr %l117, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t216, { i64, ptr } %t217)
  store i32 %t220, ptr %l122
  br label %bb38
bb38:
  %t221 = load ptr, ptr %l115, !tbaa !29
  %t222 = load i32, ptr %l116, !tbaa !23
  %t223 = load i64, ptr %l117, !tbaa !24
  %t224 = load i32, ptr %l122, !tbaa !23
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t221, i32 %t222, i64 %t223, i32 %t224)
  store i32 %t225, ptr %l123
  br label %bb39
bb39:
  %t226 = load i32, ptr %l123, !tbaa !23
  store i32 %t226, ptr %l19, !tbaa !23
  %t227 = load i32, ptr %l19, !tbaa !23
  %t228 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t231 = icmp eq i32 %t227, %t228
  br i1 %t231, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb43
bb41:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l19, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l132
  br label %bb42
bb42:
  %t243 = load i1, ptr %l132, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l127, !tbaa !21
  br label %bb43
bb43:
  %t246 = load i1, ptr %l127, !tbaa !21
  br i1 %t246, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb45:
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  store ptr %t250, ptr %l135, !tbaa !29
  %t251 = load i64, ptr %l3, !tbaa !24
  store i64 %t251, ptr %l136, !tbaa !24
  %t252 = load i64, ptr %l10, !tbaa !24
  store i64 %t252, ptr %l137, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  %t259 = load ptr, ptr %l4, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Binding", ptr %t259, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t258, { i64, ptr } %t262)
  store i32 %t265, ptr %l143
  br label %bb47
bb47:
  %t266 = load i32, ptr %l19, !tbaa !23
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i64, ptr %l136, !tbaa !24
  %t269 = load i64, ptr %l137, !tbaa !24
  %t270 = load i32, ptr %l143, !tbaa !23
  %t272 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t267, i64 %t268, i64 %t269, i32 %t270, i32 %t266)
  store i1 %t272, ptr %l145
  br label %bb48
bb48:
  %t273 = load i1, ptr %l145, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb49, label %bb50
bb49:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l3, !tbaa !24
  %t278 = load ptr, ptr %l4, !tbaa !29
  %t282 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundsMet(ptr %v0, ptr %v1, ptr %t276, i64 %t277, ptr %t278)
  store i1 %t282, ptr %l151
  br label %bb51
bb50:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb52
bb51:
  %t283 = load i1, ptr %l151, !tbaa !21
  store i1 %t283, ptr %l147, !tbaa !21
  br label %bb52
bb52:
  %t284 = load i1, ptr %l147, !tbaa !21
  br i1 %t284, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l152, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l153
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l154, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = load i64, ptr %l3, !tbaa !24
  %t293 = load i64, ptr %l10, !tbaa !24
  %t297 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t291, i64 %t292, i64 %t293)
  store %"compiler/generic:varRow" %t297, ptr %l159
  br label %bb55
bb54:
  br label %bb62
bb55:
  %t298 = getelementptr %"compiler/generic:varRow", ptr %l159, i32 0, i32 1
  %t299 = load i32, ptr %t298, !tbaa !23
  %t300 = load ptr, ptr %l154, !tbaa !29
  %t302 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t300, i32 %t299)
  store { i64, ptr } %t302, ptr %l161
  br label %bb56
bb56:
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l162, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t311 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s9, ptr %t307, i64 %a2)
  store ptr %t311, ptr %l166
  br label %bb57
bb57:
  %t312 = load ptr, ptr %l166, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Func", ptr %t312, i32 0, i32 2
  %t315 = load i32, ptr %t314, !tbaa !23
  %t316 = load ptr, ptr %l162, !tbaa !29
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t316, i32 %t315)
  store { i64, ptr } %t318, ptr %l169
  br label %bb58
bb58:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l19, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t319, i32 %t320)
  store { i64, ptr } %t323, ptr %l172
  br label %bb59
bb59:
  %t324 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t328 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeDefaultUnmet(ptr %v0, ptr %v0, ptr %s9, ptr %v0, { i64, ptr } %t325, { i64, ptr } %t326, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t328, ptr %l174
  br label %bb60
bb60:
  %t329 = load ptr, ptr %l152, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l153
  %t331 = load %"compiler/diagmsg:Msg", ptr %l174
  %t332 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t329, %"compiler/source:Span" %t330, %"compiler/diagmsg:Msg" %t331)
  store i64 %t332, ptr %l175
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  store i32 65536, ptr %rv
  br label %ret
bb62:
  %t334 = load ptr, ptr %l4, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Binding", ptr %t334, i32 0, i32 2
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l178, !tbaa !27
  %t338 = load i64, ptr %l10, !tbaa !24
  %t339 = load i32, ptr %l19, !tbaa !23
  %t342 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t338
  store i32 %t339, ptr %t344, !tbaa !33
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb64:
  %t352 = load i64, ptr %l9, !tbaa !24
  %t355 = add i64 %t352, 1
  store i64 %t355, ptr %l9, !tbaa !24
  br label %bb7
bb65:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l9, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = load i32, ptr %l11, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 5
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 5
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l26
  br label %bb6
bb6:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load i32, ptr %l26, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l28
  br label %bb8
bb8:
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb9
bb9:
  %t77 = load i1, ptr %l32, !tbaa !21
  br i1 %t77, label %bb10, label %bb11
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l36
  br label %bb12
bb11:
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  br label %bb13
bb12:
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t85, 1
  %t94 = extractvalue { i64, ptr } %t85, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = getelementptr i8, ptr %t101, i64 %t94
  call void @olang_textcopy(ptr %t102, ptr %t96, i64 %t97)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l40, !tbaa !24
  %t108 = load i64, ptr %l40, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l41, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l40, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i1, ptr %l3, !tbaa !21
  %t124 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 5
  store i1 %t121, ptr %t124, !tbaa !21
  store { i64, ptr } %t119, ptr %l44, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l45, !tbaa !24
  %t128 = load i64, ptr %l45, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l46, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l45, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t139, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/diagmsg:Msg"
  %l33 = alloca i64
  %l37 = alloca ptr
  %l45 = alloca ptr
  %l52 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  store i1 %t6, ptr %l5, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v2, ptr %t7, ptr %t8)
  store i1 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i1, ptr %l12, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  %t13 = load i1, ptr %l5, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i1, ptr %l6, !tbaa !21
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store ptr null, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i1, ptr %l5, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load i1, ptr %l6, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l24
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v2, ptr %t34, ptr %t35)
  store i1 %t38, ptr %l28
  br label %bb17
bb16:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb18
bb17:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb19, label %bb20
bb19:
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t43, ptr %l31
  %t44 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %v0)
  store %"compiler/diagmsg:Msg" %t44, ptr %l32
  br label %bb22
bb22:
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l31
  %t47 = load %"compiler/diagmsg:Msg", ptr %l32
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t45, %"compiler/source:Span" %t46, %"compiler/diagmsg:Msg" %t47)
  store i64 %t48, ptr %l33
  br label %bb23
bb23:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t49, %"compiler/source:Span" %t50, i32 %t51, i64 0)
  store ptr %t55, ptr %l37
  br label %bb24
bb24:
  %t56 = load ptr, ptr %l37, !tbaa !29
  store ptr %t56, ptr %rv
  br label %ret
bb25:
  %t58 = load i1, ptr %l5, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t60, %"compiler/source:Span" %t61, i32 %t62, ptr %t63, ptr %t64)
  store ptr %t70, ptr %l45
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t71 = load ptr, ptr %l45, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb29:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, %"compiler/source:Span" %t74, i32 %t75, ptr %t76, ptr %t77)
  store ptr %t83, ptr %l52
  br label %bb30
bb30:
  %t84 = load ptr, ptr %l52, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t25 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t22, ptr %t20, ptr %t21)
  store i32 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = icmp eq i32 %t27, %t26
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i32
  %l78 = alloca i64
  %l81 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca i32
  %l112 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %t9, %"compiler/source:Span" %a1, i64 %t11, i64 %t12)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l32
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l5
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t26, %t27
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 28
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l38
  br label %bb10
bb10:
  %t37 = load i64, ptr %l38, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l45, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l45, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store ptr %l5, ptr %l63, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 28
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t86, i64 %t82)
  store i32 %t90, ptr %l67
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l63, !tbaa !29
  %t92 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t91, i32 %t92)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l10, !tbaa !24
  br label %bb17
bb24:
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = add i64 %t100, %t101
  store i64 %t104, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp sgt i64 %t106, %t107
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load i64, ptr %l14, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb30
bb27:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = sub i64 %t116, %t117
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t126 = sub i64 %t124, 1
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = sdiv i64 %t126, %t127
  store i64 %t130, ptr %l81, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l81, !tbaa !24
  store i64 %t132, ptr %l78, !tbaa !24
  br label %bb30
bb30:
  %t133 = load i64, ptr %l78, !tbaa !24
  store i64 %t133, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = mul i64 %t143, %t144
  %t150 = add i64 %t142, %t147
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 29
  store ptr %t154, ptr %l100, !tbaa !29
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t157 = getelementptr %"compiler/check:frame", ptr %t155, i32 0, i32 28
  %t161 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t157, i64 %t150)
  store i32 %t161, ptr %l104
  br label %bb35
bb35:
  %t162 = load ptr, ptr %l100, !tbaa !29
  %t163 = load i32, ptr %l104, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t162, i32 %t163)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l16, !tbaa !24
  br label %bb31
bb38:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 28
  %t172 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t171, i64 %t172)
  br label %bb39
bb39:
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  %t176 = load i64, ptr %l19, !tbaa !24
  store i64 %t176, ptr %l112, !tbaa !24
  %t177 = load ptr, ptr %l18, !tbaa !29
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t177)
  store i64 %t179, ptr %l114
  br label %bb41
bb41:
  %t180 = load i64, ptr %l112, !tbaa !24
  %t181 = load i64, ptr %l114, !tbaa !24
  %t182 = icmp slt i64 %t180, %t181
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t186 = load ptr, ptr %l18, !tbaa !29
  %t187 = load i64, ptr %l19, !tbaa !24
  %t190 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t186, i64 %t187)
  store i32 %t190, ptr %l119
  br label %bb45
bb45:
  %t191 = load i32, ptr %l119, !tbaa !23
  %t192 = load ptr, ptr %l4, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t194, i32 %t191)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t198 = load i64, ptr %l19, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l19, !tbaa !24
  br label %bb40
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldWalk(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i64
  %l28 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i64
  %l57 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t11, i64 %a3, i32 %t13)
  store i32 %t17, ptr %l17
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i32, ptr %l17, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l18
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l19
  br label %bb3
bb3:
  %t24 = load i32, ptr %l19, !tbaa !23
  store i32 %t24, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l5, !tbaa !23
  %t29 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t25, i32 %t26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, i64 0)
  store i64 %t29, ptr %l22
  br label %bb4
bb4:
  %t30 = load i64, ptr %l22, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i32, ptr %l5, !tbaa !23
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t45, i64 %t46, i32 %t47)
  store i32 %t51, ptr %l33
  br label %bb8
bb8:
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = load i32, ptr %l33, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l34
  br label %bb9
bb9:
  %t55 = load i32, ptr %l34, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l7, !tbaa !23
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l37
  br label %bb10
bb10:
  %t61 = load i1, ptr %l37, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb14
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l7, !tbaa !23
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l41
  br label %bb13
bb13:
  %t67 = load i1, ptr %l41, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l38, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkedWritably(ptr %v0, ptr %v1, ptr %t72, ptr %a2)
  store i1 %t76, ptr %l46
  br label %bb18
bb18:
  %t77 = load i1, ptr %l46, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l1, !tbaa !23
  %t80 = load %"compiler/source:Span", ptr %l4
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s3, ptr %s3, ptr %t78, i32 %t79, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t80, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i64 %t84, ptr %l50
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t85 = load i64, ptr %l50, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t90, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr %l4
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t92, i32 %t93, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t94, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i64 %t98, ptr %l57
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i64, ptr %l57, !tbaa !24
  store i64 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritedDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l52 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l65 = alloca i32
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l10, !tbaa !23
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t2)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l10, !tbaa !23
  %t6 = load i32, ptr %l12, !tbaa !23
  %t7 = icmp eq i32 %t5, %t6
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb11
bb4:
  %t14 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l22
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t23, ptr %l23
  br label %bb9
bb9:
  %t24 = load i1, ptr %l23, !tbaa !21
  store i1 %t24, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t27, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t29 = load i32, ptr %l1, !tbaa !23
  store i32 %t29, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb15, label %bb16
bb15:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb20
bb17:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l32, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb19
bb19:
  %t57 = load i64, ptr %l32, !tbaa !24
  store i64 %t57, ptr %l29, !tbaa !24
  br label %bb20
bb20:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb23:
  br label %bb24
bb24:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l52
  br label %bb25
bb25:
  %t82 = load i1, ptr %l52, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l58
  br label %bb28
bb28:
  %t93 = load i1, ptr %l58, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t96 = load i1, ptr %l54, !tbaa !21
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t97, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l65
  br label %bb33
bb33:
  %t109 = load i32, ptr %l65, !tbaa !23
  store i32 %t109, ptr %l3, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i32, ptr %l3, !tbaa !23
  %t115 = load i32, ptr %l2, !tbaa !23
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s3, ptr %t113, i32 %t114, i32 %t115)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l70
  br label %bb34
bb34:
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %l70)
  store i64 %t121, ptr %l72
  br label %bb35
bb35:
  %t122 = load i64, ptr %l72, !tbaa !24
  %t123 = icmp eq i64 %t122, 1
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t125, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l8, !tbaa !24
  br label %bb21
bb40:
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l74 = alloca i32
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca i64
  %l107 = alloca i32
  %l118 = alloca i32
  %l123 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i1
  %l137 = alloca i1
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 45 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t23 = trunc i64 46 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t27 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t29 = trunc i64 47 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb15, label %bb16
bb14:
  br label %bb21
bb15:
  %t39 = load i32, ptr %l3, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t46, ptr %l30, !tbaa !23
  br label %bb20
bb19:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %l30, !tbaa !23
  br label %bb20
bb20:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb21:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l35
  br label %bb22
bb22:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l39
  br label %bb25
bb24:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb25:
  %t62 = load i1, ptr %l39, !tbaa !21
  br i1 %t62, label %bb26, label %bb27
bb26:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i32, ptr %l2, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l44
  br label %bb28
bb27:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb29
bb28:
  %t71 = load i1, ptr %l44, !tbaa !21
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t72 = load i1, ptr %l40, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t75 = load i1, ptr %l36, !tbaa !21
  br i1 %t75, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l46, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l47, !tbaa !23
  %t78 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t80 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s3, i32 %t78)
  store { i64, ptr } %t80, ptr %l49
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load i32, ptr %l47, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t81, i32 %t82, { i64, ptr } %t83, i64 1)
  store i64 %t84, ptr %l50
  br label %bb34
bb34:
  %t85 = load i64, ptr %l50, !tbaa !24
  store i64 %t85, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb35, label %bb36
bb35:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i32, ptr %l2, !tbaa !23
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t90, i64 %t91, i32 %t92)
  store i32 %t96, ptr %l56
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  %t97 = load i32, ptr %l56, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l59
  br label %bb40
bb40:
  %t103 = load i1, ptr %l59, !tbaa !21
  br i1 %t103, label %bb41, label %bb42
bb41:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l63
  br label %bb43
bb42:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb44
bb43:
  %t109 = load i1, ptr %l63, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l60, !tbaa !21
  br label %bb44
bb44:
  %t112 = load i1, ptr %l60, !tbaa !21
  br i1 %t112, label %bb45, label %bb46
bb45:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l3, !tbaa !23
  %t115 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t119, ptr %l68
  br label %bb47
bb46:
  br label %bb52
bb47:
  %t120 = load i64, ptr %l68, !tbaa !24
  store i64 %t120, ptr %l5, !tbaa !24
  %t121 = load i64, ptr %l5, !tbaa !24
  %t123 = icmp sge i64 %t121, 0
  br i1 %t123, label %bb48, label %bb49
bb48:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l5, !tbaa !24
  %t127 = load i32, ptr %l3, !tbaa !23
  %t131 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t125, i64 %t126, i32 %t127)
  store i32 %t131, ptr %l74
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t132 = load i32, ptr %l74, !tbaa !23
  store i32 %t132, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l2, !tbaa !23
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l77
  br label %bb53
bb53:
  %t138 = load i1, ptr %l77, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb57
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l3, !tbaa !23
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l82
  br label %bb56
bb56:
  %t146 = load i1, ptr %l82, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l79, !tbaa !21
  br label %bb57
bb57:
  %t149 = load i1, ptr %l79, !tbaa !21
  br i1 %t149, label %bb58, label %bb59
bb58:
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t152 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t154 = trunc i64 108 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb63
bb62:
  %t157 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t159 = trunc i64 109 to i32
  %t160 = icmp eq i32 %t157, %t159
  store i1 %t160, ptr %l87, !tbaa !21
  br label %bb63
bb63:
  %t162 = load i1, ptr %l87, !tbaa !21
  br i1 %t162, label %bb64, label %bb65
bb64:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l92
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb67, label %bb68
bb67:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l3, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l96
  br label %bb69
bb68:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb70
bb69:
  %t174 = load i1, ptr %l96, !tbaa !21
  store i1 %t174, ptr %l93, !tbaa !21
  br label %bb70
bb70:
  %t175 = load i1, ptr %l93, !tbaa !21
  br i1 %t175, label %bb71, label %bb72
bb71:
  %t176 = load i32, ptr %l2, !tbaa !23
  store i32 %t176, ptr %l97, !tbaa !23
  br label %bb73
bb72:
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t178, ptr %l97, !tbaa !23
  br label %bb73
bb73:
  %t180 = load i32, ptr %l97, !tbaa !23
  store i32 %t180, ptr %rv
  br label %ret
bb74:
  %t181 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t183 = trunc i64 71 to i32
  %t184 = icmp eq i32 %t181, %t183
  br i1 %t184, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l102, !tbaa !29
  %t187 = load i32, ptr %l2, !tbaa !23
  store i32 %t187, ptr %l103, !tbaa !23
  %t188 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 -1, i32 -1)
  store %"compiler/source:Span" %t188, ptr %l104
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t189 = load ptr, ptr %l102, !tbaa !29
  %t190 = load i32, ptr %l103, !tbaa !23
  %t191 = load %"compiler/source:Span", ptr %l104
  %t192 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %t189, i32 %t190, %"compiler/source:Span" %t191)
  store i64 %t192, ptr %l105
  br label %bb78
bb78:
  %t193 = load i64, ptr %l105, !tbaa !24
  %t194 = icmp sge i64 %t193, 0
  br i1 %t194, label %bb79, label %bb80
bb79:
  %t196 = load i32, ptr %l2, !tbaa !23
  store i32 %t196, ptr %l107, !tbaa !23
  br label %bb81
bb80:
  %t198 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t198, ptr %l107, !tbaa !23
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s9)
  %t200 = load i32, ptr %l107, !tbaa !23
  store i32 %t200, ptr %rv
  br label %ret
bb82:
  %t201 = load i32, ptr %l2, !tbaa !23
  store i32 %t201, ptr %l6, !tbaa !23
  %t203 = load i32, ptr %l2, !tbaa !23
  %t204 = load i32, ptr %l3, !tbaa !23
  %t207 = icmp ne i32 %t203, %t204
  br i1 %t207, label %bb83, label %bb84
bb83:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load i32, ptr %l2, !tbaa !23
  %t214 = load i32, ptr %l3, !tbaa !23
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t212, i32 %t213, i32 %t214)
  store i32 %t218, ptr %l118
  br label %bb85
bb84:
  br label %bb86
bb85:
  %t219 = load i32, ptr %l118, !tbaa !23
  store i32 %t219, ptr %l6, !tbaa !23
  br label %bb86
bb86:
  %t220 = load i32, ptr %l6, !tbaa !23
  %t222 = icmp slt i32 %t220, 0
  br i1 %t222, label %bb87, label %bb88
bb87:
  %t224 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t224, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  %t226 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t228 = call i1 @compiler_2fcheck_2eintOnly(i32 %t226)
  store i1 %t228, ptr %l123
  br label %bb90
bb90:
  %t229 = load i1, ptr %l123, !tbaa !21
  br i1 %t229, label %bb91, label %bb92
bb91:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l6, !tbaa !23
  %t234 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l127
  br label %bb93
bb92:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb94
bb93:
  %t235 = load i1, ptr %l127, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l124, !tbaa !21
  br label %bb94
bb94:
  %t238 = load i1, ptr %l124, !tbaa !21
  br i1 %t238, label %bb95, label %bb96
bb95:
  %t239 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t239, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l6, !tbaa !23
  %t245 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t241, i32 %t242)
  store i1 %t245, ptr %l132
  br label %bb98
bb98:
  %t246 = load i1, ptr %l132, !tbaa !21
  br i1 %t246, label %bb99, label %bb100
bb99:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t251 = load i32, ptr %l6, !tbaa !23
  %t254 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t250, i32 %t251)
  store i1 %t254, ptr %l137
  br label %bb101
bb100:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb102
bb101:
  %t255 = load i1, ptr %l137, !tbaa !21
  %t256 = xor i1 %t255, true
  store i1 %t256, ptr %l133, !tbaa !21
  br label %bb102
bb102:
  %t258 = load i1, ptr %l133, !tbaa !21
  br i1 %t258, label %bb103, label %bb104
bb103:
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t259, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t261 = load i32, ptr %l6, !tbaa !23
  store i32 %t261, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneGroups(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i32 %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca %"compiler/check:laneNode"
  %l50 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l86 = alloca %"compiler/check:laneNode"
  %l87 = alloca i64
  %l88 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a3, ptr %l3
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load i32, ptr %l7, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l7, !tbaa !23
  %t20 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l21
  br label %bb4
bb3:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t25 = icmp sle i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l25, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  store ptr %t29, ptr %l26, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l28
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load i32, ptr %l28, !tbaa !23
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t33, ptr %t34, i32 %t35)
  store ptr %t36, ptr %l29
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l31
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l31
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %s1, ptr %t40, ptr %t41, %"compiler/source:Span" %t42)
  store ptr %t43, ptr %l32
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l33, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneGroupSize(ptr %v0)
  store %"compiler/diagmsg:Msg" %t48, ptr %l36
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l33, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l35
  %t51 = load %"compiler/diagmsg:Msg", ptr %l36
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t49, %"compiler/source:Span" %t50, %"compiler/diagmsg:Msg" %t51)
  store i64 %t52, ptr %l37
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l40
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l40, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb16:
  store i32 %a4, ptr %l9, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 51
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t63, i64 %t64)
  store %"compiler/check:laneNode" %t67, ptr %l45
  br label %bb17
bb17:
  %t68 = getelementptr %"compiler/check:laneNode", ptr %l45, i32 0, i32 8
  %t69 = load i32, ptr %t68, !tbaa !23
  store i32 %t69, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l9, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t75 = icmp eq i32 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = load i32, ptr %l10, !tbaa !23
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = icmp eq i32 %t77, %t78
  store i1 %t81, ptr %l50, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t83 = load i1, ptr %l50, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t86 = load i64, ptr %l3, !tbaa !24
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v2, ptr %t84, %"compiler/source:Span" %t85, i64 %t86)
  store ptr %t90, ptr %l57
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load ptr, ptr %l57, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
bb24:
  %t92 = load i32, ptr %l9, !tbaa !23
  %t93 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t96 = icmp eq i32 %t92, %t93
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l61, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l10, !tbaa !23
  %t103 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t103, ptr %l64
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l64, !tbaa !23
  %t106 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaccumulator(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t106, ptr %l65
  br label %bb28
bb28:
  %t107 = load i32, ptr %l65, !tbaa !23
  store i32 %t107, ptr %l9, !tbaa !23
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l3, !tbaa !24
  %t110 = load i32, ptr %l9, !tbaa !23
  %t116 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWorksIn(ptr %v0, ptr %t108, i64 %t109, i32 %t110, %"compiler/source:Span" %a5)
  store i1 %t116, ptr %l70
  br label %bb30
bb30:
  %t117 = load i1, ptr %l70, !tbaa !21
  %t118 = xor i1 %t117, true
  br i1 %t118, label %bb31, label %bb32
bb31:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t120, %"compiler/source:Span" %t121)
  store ptr %t124, ptr %l74
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load ptr, ptr %l74, !tbaa !29
  store ptr %t125, ptr %rv
  br label %ret
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l75, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t127, ptr %l76
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l77, !tbaa !29
  %t129 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneGroup, !tbaa !24
  %t130 = load %"compiler/source:Span", ptr %l1
  %t132 = load i64, ptr %l3, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t134 = load i32, ptr %l9, !tbaa !23
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t129, i32 68, %"compiler/source:Span" %t130, %"compiler/source:Span" %a2, i64 %t132, i64 %t133, i64 -1, ptr null, i32 %t134, i64 -1, i32 %t135, i64 -1)
  store %"compiler/check:laneNode" %t144, ptr %l86
  br label %bb35
bb35:
  %t145 = load ptr, ptr %l77, !tbaa !29
  %t146 = load %"compiler/check:laneNode", ptr %l86
  %t147 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t145, %"compiler/check:laneNode" %t146)
  store i64 %t147, ptr %l87
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l75, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l76
  %t150 = load i64, ptr %l87, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v2, ptr %t148, %"compiler/source:Span" %t149, i64 %t150)
  store ptr %t151, ptr %l88
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t152 = load ptr, ptr %l88, !tbaa !29
  store ptr %t152, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l30 = alloca i1
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l63 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca i64
  %l70 = alloca i1
  %l73 = alloca i1
  %l76 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i1
  %l83 = alloca ptr
  %l86 = alloca i32
  %l88 = alloca i64
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i1
  %l95 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca i32
  %l108 = alloca i1
  %l114 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca { i64, ptr }
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca i64
  %l137 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca { i64, ptr }
  %l156 = alloca i64
  %l159 = alloca ptr
  %l164 = alloca ptr
  %l167 = alloca i32
  %l169 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca i32
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l180 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i1
  %l189 = alloca { i64, ptr }
  %l190 = alloca i1
  %l191 = alloca i1
  %l192 = alloca ptr
  %l195 = alloca i32
  %l196 = alloca i1
  %l203 = alloca ptr
  %l206 = alloca i1
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca i32
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l219 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/diagmsg:Msg"
  %l225 = alloca i64
  %l230 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca ptr
  %l245 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca %"compiler/source:Span"
  %l254 = alloca { i64, ptr }
  %l256 = alloca %"compiler/diagmsg:Msg"
  %l257 = alloca i64
  %l258 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca i64
  %l263 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l269 = alloca ptr
  %l272 = alloca { i64, ptr }
  %l274 = alloca i1
  %l275 = alloca i1
  %l279 = alloca i1
  %l281 = alloca i1
  %l282 = alloca i1
  %l286 = alloca i1
  %l288 = alloca ptr
  %l290 = alloca ptr
  %l293 = alloca i1
  %l296 = alloca ptr
  %l299 = alloca i32
  %l300 = alloca i32
  %l303 = alloca i1
  %l313 = alloca ptr
  %l315 = alloca ptr
  %l318 = alloca i32
  %l320 = alloca i64
  %l324 = alloca ptr
  %l327 = alloca i32
  %l329 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l331 = alloca i64
  %l333 = alloca ptr
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca ptr
  %l338 = alloca i32
  %l339 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l345 = alloca %"compiler/diagmsg:Msg"
  %l346 = alloca i64
  %l351 = alloca ptr
  %l353 = alloca i64
  %l356 = alloca i64
  %l359 = alloca ptr
  %l362 = alloca i32
  %l364 = alloca i32
  %l368 = alloca ptr
  %l369 = alloca %"compiler/source:Span"
  %l370 = alloca %"compiler/source:Span"
  %l375 = alloca i64
  %l379 = alloca ptr
  %l382 = alloca i1
  %l385 = alloca i1
  %l386 = alloca i1
  %l391 = alloca i1
  %l392 = alloca i1
  %l395 = alloca ptr
  %l397 = alloca %"compiler/source:Span"
  %l398 = alloca ptr
  %l400 = alloca %"compiler/source:Span"
  %l401 = alloca { i64, ptr }
  %l404 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l406 = alloca ptr
  %l408 = alloca %"compiler/source:Span"
  %l409 = alloca { i64, ptr }
  %l410 = alloca { i64, ptr }
  %l411 = alloca i64
  %l412 = alloca { i64, ptr }
  %l413 = alloca { i64, ptr }
  %l414 = alloca i64
  %l416 = alloca ptr
  %l417 = alloca ptr
  %l419 = alloca %"compiler/source:Span"
  %l420 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l423 = alloca %"compiler/diagmsg:Msg"
  %l424 = alloca i64
  %l429 = alloca i32
  %l432 = alloca i1
  %l434 = alloca i1
  %l435 = alloca i1
  %l439 = alloca i1
  %l442 = alloca i32
  %l445 = alloca ptr
  %l446 = alloca %"compiler/source:Span"
  %l448 = alloca i32
  %l451 = alloca ptr
  %l454 = alloca i1
  %l457 = alloca i32
  %l460 = alloca i1
  %l461 = alloca ptr
  %l464 = alloca i32
  %l465 = alloca i1
  %l470 = alloca ptr
  %l473 = alloca i1
  %l475 = alloca i1
  %l477 = alloca i1
  %l478 = alloca ptr
  %l481 = alloca i32
  %l482 = alloca i1
  %l483 = alloca i1
  %l484 = alloca ptr
  %l487 = alloca i32
  %l488 = alloca i1
  %l489 = alloca i1
  %l491 = alloca ptr
  %l494 = alloca i32
  %l495 = alloca i1
  %l497 = alloca i1
  %l498 = alloca ptr
  %l501 = alloca i32
  %l503 = alloca i1
  %l504 = alloca ptr
  %l505 = alloca %"compiler/source:Span"
  %l506 = alloca ptr
  %l509 = alloca i32
  %l510 = alloca { i64, ptr }
  %l511 = alloca { i64, ptr }
  %l514 = alloca { i64, ptr }
  %l516 = alloca %"compiler/diagmsg:Msg"
  %l517 = alloca i64
  %l522 = alloca ptr
  %l532 = alloca ptr
  %l539 = alloca i32
  %l542 = alloca i1
  %l543 = alloca i1
  %l547 = alloca i64
  %l550 = alloca ptr
  %l554 = alloca %"compiler/source:Span"
  %l555 = alloca i32
  %l556 = alloca ptr
  %l557 = alloca ptr
  %l558 = alloca i32
  %l560 = alloca %"compiler/source:Span"
  %l561 = alloca i32
  %l564 = alloca ptr
  %l565 = alloca %"compiler/source:Span"
  %l566 = alloca %"compiler/source:Span"
  %l571 = alloca ptr
  %l573 = alloca %"compiler/source:Span"
  %l576 = alloca %"compiler/source:Span"
  %l580 = alloca ptr
  %l581 = alloca %"compiler/source:Span"
  %l582 = alloca %"compiler/source:Span"
  %l583 = alloca ptr
  %l584 = alloca %"compiler/source:Span"
  %l590 = alloca ptr
  %l591 = alloca ptr
  %l593 = alloca ptr
  %l596 = alloca i1
  %l597 = alloca i1
  %l600 = alloca i32
  %l607 = alloca ptr
  %l609 = alloca i1
  %l610 = alloca i1
  %l612 = alloca i1
  %l615 = alloca i32
  %l617 = alloca i32
  %l619 = alloca i1
  %l621 = alloca i1
  %l622 = alloca i1
  %l624 = alloca i1
  %l625 = alloca ptr
  %l626 = alloca %"compiler/source:Span"
  %l629 = alloca { i64, ptr }
  %l632 = alloca %"compiler/diagmsg:Msg"
  %l633 = alloca i64
  %l634 = alloca ptr
  %l635 = alloca %"compiler/source:Span"
  %l636 = alloca i32
  %l639 = alloca { i64, ptr }
  %l641 = alloca { i64, ptr }
  %l644 = alloca { i64, ptr }
  %l645 = alloca { i64, ptr }
  %l648 = alloca { i64, ptr }
  %l649 = alloca { i64, ptr }
  %l653 = alloca { i64, ptr }
  %l655 = alloca %"compiler/diagmsg:Msg"
  %l656 = alloca i64
  %l661 = alloca ptr
  %l665 = alloca i1
  %l666 = alloca ptr
  %l667 = alloca %"compiler/source:Span"
  %l670 = alloca { i64, ptr }
  %l672 = alloca %"compiler/diagmsg:Msg"
  %l673 = alloca i64
  %l674 = alloca ptr
  %l675 = alloca %"compiler/source:Span"
  %l676 = alloca ptr
  %l677 = alloca %"compiler/source:Span"
  %l678 = alloca %"compiler/source:Span"
  %l679 = alloca i64
  %l681 = alloca ptr
  %l682 = alloca { i64, ptr }
  %l685 = alloca { i64, ptr }
  %l689 = alloca ptr
  %l690 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %rv = alloca ptr
  %t1061 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb8
bb2:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp eq i64 %t9, 1
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l37
  br label %bb5
bb4:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb7
bb5:
  %t18 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t19, ptr %l38
  br label %bb6
bb6:
  %t20 = load i1, ptr %l38, !tbaa !21
  store i1 %t20, ptr %l34, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l34, !tbaa !21
  store i1 %t21, ptr %l30, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l30, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l42
  br label %bb11
bb10:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb11:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t33 = call i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %t31, i64 %t30)
  store i1 %t33, ptr %l45
  br label %bb12
bb12:
  %t34 = load i1, ptr %l45, !tbaa !21
  store i1 %t34, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l39, !tbaa !21
  store i1 %t35, ptr %l8, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i1, ptr %l8, !tbaa !21
  %t40 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 52
  store i1 %t37, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v4, ptr %t41, ptr %t42, i32 %t44)
  store ptr %t48, ptr %l52
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l52, !tbaa !29
  store ptr %t49, ptr %l9, !tbaa !29
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t50)
  store i32 %t53, ptr %l55
  br label %bb15
bb15:
  %t54 = load i32, ptr %l55, !tbaa !23
  store i32 %t54, ptr %l10, !tbaa !23
  %t55 = load i32, ptr %l10, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp eq i32 %t55, %t56
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t61, { i64, ptr } %t62)
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t65, %"compiler/source:Span" %t66)
  store ptr %t69, ptr %l63
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l63, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb20:
  %t71 = load i1, ptr %l8, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t73, ptr %t74)
  store i64 %t77, ptr %l68
  br label %bb23
bb22:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb28
bb23:
  %t78 = load i64, ptr %l68, !tbaa !24
  %t79 = icmp sge i64 %t78, 0
  br i1 %t79, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb27
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t81, i32 %t82)
  store i1 %t85, ptr %l73
  br label %bb26
bb26:
  %t86 = load i1, ptr %l73, !tbaa !21
  store i1 %t86, ptr %l70, !tbaa !21
  br label %bb27
bb27:
  %t87 = load i1, ptr %l70, !tbaa !21
  store i1 %t87, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l65, !tbaa !21
  br i1 %t88, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l76
  br label %bb31
bb30:
  br label %bb79
bb31:
  %t94 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l9, !tbaa !29
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t95, ptr %t96)
  store i64 %t99, ptr %l79
  br label %bb32
bb32:
  %t100 = load i64, ptr %l79, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb37
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l83, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l10, !tbaa !23
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l86
  br label %bb35
bb35:
  %t112 = load i32, ptr %l3, !tbaa !23
  %t113 = load ptr, ptr %l83, !tbaa !29
  %t114 = load i32, ptr %l86, !tbaa !23
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t113, i32 %t114, i32 %t112)
  store i64 %t116, ptr %l88
  br label %bb36
bb36:
  %t117 = load i64, ptr %l88, !tbaa !24
  %t118 = icmp slt i64 %t117, 0
  store i1 %t118, ptr %l81, !tbaa !21
  br label %bb37
bb37:
  %t120 = load i1, ptr %l81, !tbaa !21
  br i1 %t120, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb41
bb39:
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t121, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t123, ptr %l92
  br label %bb40
bb40:
  %t124 = load i1, ptr %l92, !tbaa !21
  store i1 %t124, ptr %l90, !tbaa !21
  br label %bb41
bb41:
  %t125 = load i1, ptr %l90, !tbaa !21
  br i1 %t125, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb45
bb43:
  %t126 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t126, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t128, ptr %l95
  br label %bb44
bb44:
  %t129 = load i1, ptr %l95, !tbaa !21
  store i1 %t129, ptr %l93, !tbaa !21
  br label %bb45
bb45:
  %t130 = load i1, ptr %l93, !tbaa !21
  br i1 %t130, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s3
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t131, ptr %l12, !tbaa !23
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb48, label %bb49
bb47:
  br label %bb78
bb48:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t140, ptr %l101, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 0
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t148 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v3, ptr %t139, ptr %t144)
  store i32 %t148, ptr %l104
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t149 = load i32, ptr %l104, !tbaa !23
  store i32 %t149, ptr %l12, !tbaa !23
  br label %bb51
bb51:
  %t150 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load i32, ptr %l12, !tbaa !23
  %t157 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t160 = icmp eq i32 %t156, %t157
  store i1 %t160, ptr %l108, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb54
bb54:
  %t162 = load i1, ptr %l108, !tbaa !21
  br i1 %t162, label %bb55, label %bb56
bb55:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t163, %"compiler/source:Span" %t164)
  store ptr %t167, ptr %l114
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t168 = load ptr, ptr %l114, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb58:
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb59, label %bb60
bb59:
  %t175 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t175, ptr %l119, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr ptr, ptr %t177, i64 0
  %t179 = load ptr, ptr %t178, !tbaa !39
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l121
  br label %bb61
bb60:
  %t182 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t182, ptr %l118
  br label %bb62
bb61:
  %t184 = load %"compiler/source:Span", ptr %l121
  store %"compiler/source:Span" %t184, ptr %l118
  br label %bb62
bb62:
  %t185 = load %"compiler/source:Span", ptr %l118
  store %"compiler/source:Span" %t185, ptr %l13
  %t186 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s3, { i64, ptr } %t186, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t188, ptr %l124
  br label %bb63
bb63:
  %t189 = load i1, ptr %l124, !tbaa !21
  br i1 %t189, label %bb64, label %bb65
bb64:
  %t190 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 1
  store i1 %t194, ptr %l125, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb66
bb66:
  %t196 = load i1, ptr %l125, !tbaa !21
  br i1 %t196, label %bb67, label %bb68
bb67:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l129, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t198, ptr %l130
  %t199 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t199, ptr %l131
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l9, !tbaa !29
  %t204 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v4, ptr %t200, ptr %t201)
  store i64 %t204, ptr %l134
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t205 = load i32, ptr %l12, !tbaa !23
  %t206 = load %"compiler/source:Span", ptr %l13
  %t207 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t207, ptr %l137, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 0
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t212 = load ptr, ptr %l129, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l130
  %t214 = load %"compiler/source:Span", ptr %l131
  %t215 = load i64, ptr %l134, !tbaa !24
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneGroups(ptr %v0, ptr %v2, ptr %v4, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214, i64 %t215, i32 %t205, %"compiler/source:Span" %t206, ptr %t211)
  store ptr %t219, ptr %l139
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t220 = load ptr, ptr %l139, !tbaa !29
  store ptr %t220, ptr %rv
  br label %ret
bb71:
  %t221 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp eq i64 %t223, 0
  br i1 %t225, label %bb72, label %bb73
bb72:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load %"compiler/source:Span", ptr %l4
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t231 = load ptr, ptr %l9, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t227, %"compiler/source:Span" %t228, %"compiler/source:Span" %t229, { i64, ptr } %t230, ptr %t231, { i64, ptr } %t232)
  store ptr %t239, ptr %l149
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t240 = load ptr, ptr %l149, !tbaa !29
  store ptr %t240, ptr %rv
  br label %ret
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l150, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t242, ptr %l151
  %t243 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t243, ptr %l152
  %t244 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t244, ptr %l153, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l9, !tbaa !29
  %t249 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v4, ptr %t245, ptr %t246)
  store i64 %t249, ptr %l156
  br label %bb76
bb76:
  %t250 = load i32, ptr %l12, !tbaa !23
  %t251 = load %"compiler/source:Span", ptr %l13
  %t252 = load ptr, ptr %l150, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l151
  %t254 = load %"compiler/source:Span", ptr %l152
  %t255 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t256 = load i64, ptr %l156, !tbaa !24
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v4, ptr %v4, ptr %t252, %"compiler/source:Span" %t253, %"compiler/source:Span" %t254, { i64, ptr } %t255, i64 %t256, i32 %t250, %"compiler/source:Span" %t251)
  store ptr %t259, ptr %l159
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t260 = load ptr, ptr %l159, !tbaa !29
  store ptr %t260, ptr %rv
  br label %ret
bb78:
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb79:
  %t261 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t265 = icmp sgt i64 %t263, 0
  br i1 %t265, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s8
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  store ptr %t270, ptr %l164, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i32, ptr %l10, !tbaa !23
  %t275 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t271, i32 %t272)
  store i32 %t275, ptr %l167
  br label %bb82
bb81:
  br label %bb141
bb82:
  %t276 = load i32, ptr %l3, !tbaa !23
  %t277 = load ptr, ptr %l164, !tbaa !29
  %t278 = load i32, ptr %l167, !tbaa !23
  %t280 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t277, i32 %t278, i32 %t276)
  store i64 %t280, ptr %l169
  br label %bb83
bb83:
  %t281 = load i64, ptr %l169, !tbaa !24
  store i64 %t281, ptr %l14, !tbaa !24
  %t282 = load i64, ptr %l14, !tbaa !24
  %t284 = icmp slt i64 %t282, 0
  br i1 %t284, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s9
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  store ptr %t289, ptr %l173, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l10, !tbaa !23
  %t294 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l176
  br label %bb86
bb85:
  br label %bb93
bb86:
  %t295 = load i32, ptr %l3, !tbaa !23
  %t296 = load ptr, ptr %l173, !tbaa !29
  %t297 = load i32, ptr %l176, !tbaa !23
  %t299 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s9, ptr %t296, i32 %t297, i32 %t295)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %l178
  br label %bb87
bb87:
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %l15
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s9, ptr %l15)
  store i64 %t302, ptr %l180
  br label %bb88
bb88:
  %t303 = load i64, ptr %l180, !tbaa !24
  %t304 = icmp eq i64 %t303, 1
  br i1 %t304, label %bb89, label %bb90
bb89:
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %l15, i64 0)
  store i64 %t307, ptr %l183
  br label %bb91
bb90:
  br label %bb92
bb91:
  %t308 = load i64, ptr %l183, !tbaa !24
  store i64 %t308, ptr %l14, !tbaa !24
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s9)
  br label %bb93
bb93:
  %t309 = load i64, ptr %l14, !tbaa !24
  %t311 = icmp slt i64 %t309, 0
  br i1 %t311, label %bb94, label %bb95
bb94:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l3, !tbaa !23
  %t317 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t313, i32 %t314)
  store { i64, ptr } %t317, ptr %l189
  br label %bb96
bb95:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb98
bb96:
  %t318 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t319 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t318, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t319, ptr %l190
  br label %bb97
bb97:
  %t320 = load i1, ptr %l190, !tbaa !21
  store i1 %t320, ptr %l186, !tbaa !21
  br label %bb98
bb98:
  %t321 = load i1, ptr %l186, !tbaa !21
  br i1 %t321, label %bb99, label %bb100
bb99:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l192, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l10, !tbaa !23
  %t327 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t323, i32 %t324)
  store i32 %t327, ptr %l195
  br label %bb101
bb100:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb103
bb101:
  %t328 = load ptr, ptr %l192, !tbaa !29
  %t329 = load i32, ptr %l195, !tbaa !23
  %t330 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t328, i32 %t329)
  store i1 %t330, ptr %l196
  br label %bb102
bb102:
  %t331 = load i1, ptr %l196, !tbaa !21
  store i1 %t331, ptr %l191, !tbaa !21
  br label %bb103
bb103:
  %t332 = load i1, ptr %l191, !tbaa !21
  br i1 %t332, label %bb104, label %bb105
bb104:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  %t335 = load %"compiler/source:Span", ptr %l4
  %t336 = load ptr, ptr %l9, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t345 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v4, ptr %v3, ptr %v2, ptr %v4, ptr %t333, %"compiler/source:Span" %t334, %"compiler/source:Span" %t335, ptr %t336, { i64, ptr } %t337, { i64, ptr } %t338)
  store ptr %t345, ptr %l203
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t346 = load ptr, ptr %l203, !tbaa !29
  store ptr %t346, ptr %rv
  br label %ret
bb107:
  %t347 = load i64, ptr %l14, !tbaa !24
  %t349 = icmp slt i64 %t347, 0
  br i1 %t349, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb112
bb109:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = getelementptr %"compiler/generic:Program", ptr %t354, i32 0, i32 2
  store ptr %t356, ptr %l209, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l10, !tbaa !23
  %t361 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t357, i32 %t358)
  store i32 %t361, ptr %l212
  br label %bb110
bb110:
  %t362 = load ptr, ptr %l209, !tbaa !29
  %t363 = load i32, ptr %l212, !tbaa !23
  %t364 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t362, i32 %t363)
  store i32 %t364, ptr %l213
  br label %bb111
bb111:
  %t365 = load i32, ptr %l213, !range !{i32 0, i32 33}
  %t367 = trunc i64 29 to i32
  %t368 = icmp eq i32 %t365, %t367
  store i1 %t368, ptr %l206, !tbaa !21
  br label %bb112
bb112:
  %t370 = load i1, ptr %l206, !tbaa !21
  br i1 %t370, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s12
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l216, !tbaa !29
  %t372 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t372, ptr %l217, !tbaa !27
  %t373 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr ptr, ptr %t374, i64 0
  %t376 = load ptr, ptr %t375, !tbaa !39
  %t378 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l219
  br label %bb115
bb114:
  br label %bb121
bb115:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr %l3, !tbaa !23
  %t383 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t379, i32 %t380)
  store { i64, ptr } %t383, ptr %l222
  br label %bb116
bb116:
  %t384 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t386 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %s12, ptr %v0, { i64, ptr } %t384)
  store %"compiler/diagmsg:Msg" %t386, ptr %l224
  br label %bb117
bb117:
  %t387 = load ptr, ptr %l216, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l219
  %t389 = load %"compiler/diagmsg:Msg", ptr %l224
  %t390 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t387, %"compiler/source:Span" %t388, %"compiler/diagmsg:Msg" %t389)
  store i64 %t390, ptr %l225
  br label %bb118
bb118:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t391, { i64, ptr } %t392)
  br label %bb119
bb119:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t395, %"compiler/source:Span" %t396)
  store ptr %t399, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t400 = load ptr, ptr %l230, !tbaa !29
  store ptr %t400, ptr %rv
  br label %ret
bb121:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i64, ptr %l14, !tbaa !24
  %t403 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t409 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v3, ptr %v4, ptr %t401, i64 %t402, { i64, ptr } %t403, %"compiler/source:Span" %a7)
  store { i64, ptr } %t409, ptr %l235
  br label %bb122
bb122:
  %t410 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t410, ptr %l16, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t415 = icmp eq i64 %t413, 0
  br i1 %t415, label %bb123, label %bb124
bb123:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t417, { i64, ptr } %t418)
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l1
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t421, %"compiler/source:Span" %t422)
  store ptr %t425, ptr %l243
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t426 = load ptr, ptr %l243, !tbaa !29
  store ptr %t426, ptr %rv
  br label %ret
bb127:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l244, !tbaa !29
  %t428 = load i64, ptr %l14, !tbaa !24
  store i64 %t428, ptr %l245, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l3, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t429, i32 %t430)
  store { i64, ptr } %t433, ptr %l248
  br label %bb128
bb128:
  %t434 = load ptr, ptr %l244, !tbaa !29
  %t435 = load i64, ptr %l245, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t437 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateMethod(ptr %v0, ptr %v0, ptr %t434, i64 %t435, { i64, ptr } %t436)
  store i1 %t437, ptr %l249
  br label %bb129
bb129:
  %t438 = load i1, ptr %l249, !tbaa !21
  br i1 %t438, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s14
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l250, !tbaa !29
  %t440 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t440, ptr %l251
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load i32, ptr %l3, !tbaa !23
  %t445 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t441, i32 %t442)
  store { i64, ptr } %t445, ptr %l254
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t446 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t448 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s14, ptr %v0, { i64, ptr } %t446)
  store %"compiler/diagmsg:Msg" %t448, ptr %l256
  br label %bb133
bb133:
  %t449 = load ptr, ptr %l250, !tbaa !29
  %t450 = load %"compiler/source:Span", ptr %l251
  %t451 = load %"compiler/diagmsg:Msg", ptr %l256
  %t452 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t449, %"compiler/source:Span" %t450, %"compiler/diagmsg:Msg" %t451)
  store i64 %t452, ptr %l257
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s14)
  br label %bb135
bb135:
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l258, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t454, ptr %l259
  %t455 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t455, ptr %l260
  %t456 = load i64, ptr %l14, !tbaa !24
  store i64 %t456, ptr %l261, !tbaa !24
  %t457 = load ptr, ptr %l9, !tbaa !29
  store ptr %t457, ptr %l263, !tbaa !29
  %t459 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t459, ptr %l264, !tbaa !27
  %t460 = icmp sge i64 0, 0
  br i1 %t460, label %bb136, label %bb137
bb136:
  %t462 = icmp sle i64 0, 1152921504606846975
  br i1 %t462, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb138:
  %t464 = mul i64 0, 8
  %t465 = insertvalue { i64, ptr } undef, i64 0, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t467 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t468 = load ptr, ptr %l258, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l259
  %t470 = load %"compiler/source:Span", ptr %l260
  %t471 = load i64, ptr %l261, !tbaa !24
  %t472 = load ptr, ptr %l263, !tbaa !29
  %t473 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t476 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v4, ptr %v4, ptr %t468, %"compiler/source:Span" %t469, %"compiler/source:Span" %t470, i64 %t471, ptr %t472, { i64, ptr } %t473, { i64, ptr } %t466, { i64, ptr } %t467)
  store ptr %t476, ptr %l269
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb140:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t477 = load ptr, ptr %l269, !tbaa !29
  store ptr %t477, ptr %rv
  br label %ret
bb141:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i32, ptr %l3, !tbaa !23
  %t482 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t478, i32 %t479)
  store { i64, ptr } %t482, ptr %l272
  br label %bb142
bb142:
  %t483 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t483, ptr %l17, !tbaa !27
  %t484 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t486 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t484, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t486, ptr %l274
  br label %bb143
bb143:
  %t487 = load i1, ptr %l274, !tbaa !21
  br i1 %t487, label %bb144, label %bb145
bb144:
  %t488 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t492 = icmp eq i64 %t490, 0
  store i1 %t492, ptr %l275, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb146
bb146:
  %t494 = load i1, ptr %l275, !tbaa !21
  br i1 %t494, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l279, !tbaa !21
  br label %bb153
bb148:
  %t495 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t497 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t495, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t497, ptr %l281
  br label %bb149
bb149:
  %t498 = load i1, ptr %l281, !tbaa !21
  br i1 %t498, label %bb150, label %bb151
bb150:
  %t499 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t499, 0
  %t503 = icmp eq i64 %t501, 1
  store i1 %t503, ptr %l282, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb152
bb152:
  %t505 = load i1, ptr %l282, !tbaa !21
  store i1 %t505, ptr %l279, !tbaa !21
  br label %bb153
bb153:
  %t506 = load i1, ptr %l279, !tbaa !21
  br i1 %t506, label %bb154, label %bb155
bb154:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/check:Checker", ptr %t507, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !29
  store ptr %t510, ptr %l288, !tbaa !29
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t511)
  store ptr %t513, ptr %l290
  br label %bb156
bb155:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb158
bb156:
  %t514 = load ptr, ptr %l290, !tbaa !29
  %t516 = getelementptr %"compiler/check:frame", ptr %t514, i32 0, i32 1
  %t517 = load i64, ptr %t516, !tbaa !24
  %t518 = load ptr, ptr %l288, !tbaa !29
  %t520 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t518, i64 %t517)
  store i1 %t520, ptr %l293
  br label %bb157
bb157:
  %t521 = load i1, ptr %l293, !tbaa !21
  store i1 %t521, ptr %l286, !tbaa !21
  br label %bb158
bb158:
  %t522 = load i1, ptr %l286, !tbaa !21
  store i1 %t522, ptr %l18, !tbaa !21
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/check:Checker", ptr %t523, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !29
  %t528 = getelementptr %"compiler/generic:Program", ptr %t526, i32 0, i32 2
  store ptr %t528, ptr %l296, !tbaa !29
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l10, !tbaa !23
  %t533 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t529, i32 %t530)
  store i32 %t533, ptr %l299
  br label %bb159
bb159:
  %t534 = load ptr, ptr %l296, !tbaa !29
  %t535 = load i32, ptr %l299, !tbaa !23
  %t536 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t534, i32 %t535)
  store i32 %t536, ptr %l300
  br label %bb160
bb160:
  %t537 = load i32, ptr %l300, !range !{i32 0, i32 33}
  %t539 = trunc i64 29 to i32
  %t540 = icmp eq i32 %t537, %t539
  br i1 %t540, label %bb161, label %bb162
bb161:
  %t542 = load i1, ptr %l18, !tbaa !21
  %t544 = xor i1 %t542, true
  store i1 %t544, ptr %l303, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb163
bb163:
  %t546 = load i1, ptr %l303, !tbaa !21
  br i1 %t546, label %bb164, label %bb165
bb164:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  %t549 = load ptr, ptr %l2, !tbaa !29
  %t550 = load ptr, ptr %l9, !tbaa !29
  %t551 = load i32, ptr %l3, !tbaa !23
  %t552 = load %"compiler/source:Span", ptr %l4
  %t553 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t561 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v4, ptr %v2, ptr %v4, ptr %t547, %"compiler/source:Span" %t548, ptr %t549, ptr %t550, i32 %t551, %"compiler/source:Span" %t552, { i64, ptr } %t553)
  store ptr %t561, ptr %l313
  br label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_scope_close(ptr %s0)
  %t562 = load ptr, ptr %l313, !tbaa !29
  store ptr %t562, ptr %rv
  br label %ret
bb167:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/check:Checker", ptr %t563, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !29
  store ptr %t566, ptr %l315, !tbaa !29
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i32, ptr %l10, !tbaa !23
  %t571 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t567, i32 %t568)
  store i32 %t571, ptr %l318
  br label %bb168
bb168:
  %t572 = load i32, ptr %l3, !tbaa !23
  %t573 = load ptr, ptr %l315, !tbaa !29
  %t574 = load i32, ptr %l318, !tbaa !23
  %t576 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t573, i32 %t574, i32 %t572)
  store i64 %t576, ptr %l320
  br label %bb169
bb169:
  %t577 = load i64, ptr %l320, !tbaa !24
  store i64 %t577, ptr %l19, !tbaa !24
  %t578 = load i64, ptr %l19, !tbaa !24
  %t580 = icmp slt i64 %t578, 0
  br i1 %t580, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s16
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !29
  store ptr %t585, ptr %l324, !tbaa !29
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load i32, ptr %l10, !tbaa !23
  %t590 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t586, i32 %t587)
  store i32 %t590, ptr %l327
  br label %bb172
bb171:
  br label %bb190
bb172:
  %t591 = load i32, ptr %l3, !tbaa !23
  %t592 = load ptr, ptr %l324, !tbaa !29
  %t593 = load i32, ptr %l327, !tbaa !23
  %t595 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s16, ptr %t592, i32 %t593, i32 %t591)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t595, ptr %l329
  br label %bb173
bb173:
  %t596 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l329
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l20
  %t598 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s16, ptr %l20)
  store i64 %t598, ptr %l331
  br label %bb174
bb174:
  %t599 = load i64, ptr %l331, !tbaa !24
  %t600 = icmp sgt i64 %t599, 1
  br i1 %t600, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s17
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l333, !tbaa !29
  %t603 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t603, ptr %l334
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l335, !tbaa !29
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l10, !tbaa !23
  %t609 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t605, i32 %t606)
  store i32 %t609, ptr %l338
  br label %bb177
bb176:
  br label %bb184
bb177:
  %t610 = load ptr, ptr %l335, !tbaa !29
  %t611 = load i32, ptr %l338, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t610, i32 %t611)
  store { i64, ptr } %t612, ptr %l339
  br label %bb178
bb178:
  %t613 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t613, ptr %l340, !tbaa !27
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l3, !tbaa !23
  %t618 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s17, ptr %t614, i32 %t615)
  store { i64, ptr } %t618, ptr %l343
  br label %bb179
bb179:
  %t619 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t620 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t622 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %s17, ptr %s17, ptr %v0, { i64, ptr } %t620, { i64, ptr } %t619)
  store %"compiler/diagmsg:Msg" %t622, ptr %l345
  br label %bb180
bb180:
  %t623 = load ptr, ptr %l333, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l334
  %t625 = load %"compiler/diagmsg:Msg", ptr %l345
  %t626 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t623, %"compiler/source:Span" %t624, %"compiler/diagmsg:Msg" %t625)
  store i64 %t626, ptr %l346
  br label %bb181
bb181:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t627, { i64, ptr } %t628)
  br label %bb182
bb182:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load %"compiler/source:Span", ptr %l1
  %t635 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t631, %"compiler/source:Span" %t632)
  store ptr %t635, ptr %l351
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t636 = load ptr, ptr %l351, !tbaa !29
  store ptr %t636, ptr %rv
  br label %ret
bb184:
  %t638 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s16, ptr %l20)
  store i64 %t638, ptr %l353
  br label %bb185
bb185:
  %t639 = load i64, ptr %l353, !tbaa !24
  %t640 = icmp eq i64 %t639, 1
  br i1 %t640, label %bb186, label %bb187
bb186:
  %t643 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s16, ptr %l20, i64 0)
  store i64 %t643, ptr %l356
  br label %bb188
bb187:
  br label %bb189
bb188:
  %t644 = load i64, ptr %l356, !tbaa !24
  store i64 %t644, ptr %l19, !tbaa !24
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s16)
  br label %bb190
bb190:
  %t645 = load i64, ptr %l19, !tbaa !24
  %t647 = icmp slt i64 %t645, 0
  br i1 %t647, label %bb191, label %bb192
bb191:
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l359, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load i32, ptr %l10, !tbaa !23
  %t654 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t650, i32 %t651)
  store i32 %t654, ptr %l362
  br label %bb193
bb192:
  br label %bb200
bb193:
  %t655 = load i32, ptr %l3, !tbaa !23
  %t656 = load ptr, ptr %l359, !tbaa !29
  %t657 = load i32, ptr %l362, !tbaa !23
  %t659 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritedDefault(ptr %v0, ptr %t656, i32 %t657, i32 %t655)
  store i32 %t659, ptr %l364
  br label %bb194
bb194:
  %t660 = load i32, ptr %l364, !tbaa !23
  store i32 %t660, ptr %l21, !tbaa !23
  %t661 = load i32, ptr %l21, !tbaa !23
  %t662 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t665 = icmp ne i32 %t661, %t662
  br i1 %t665, label %bb195, label %bb196
bb195:
  %t667 = load ptr, ptr %l0, !tbaa !29
  store ptr %t667, ptr %l368, !tbaa !29
  %t668 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t668, ptr %l369
  %t669 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t669, ptr %l370
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/check:Checker", ptr %t670, i32 0, i32 1
  %t673 = load ptr, ptr %t672, !tbaa !29
  %t674 = load i32, ptr %l21, !tbaa !23
  %t675 = load i32, ptr %l3, !tbaa !23
  %t679 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t673, i32 %t674, i32 %t675)
  store i64 %t679, ptr %l375
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t680 = load ptr, ptr %l9, !tbaa !29
  %t681 = load i32, ptr %l21, !tbaa !23
  %t682 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t683 = load ptr, ptr %l368, !tbaa !29
  %t684 = load %"compiler/source:Span", ptr %l369
  %t685 = load %"compiler/source:Span", ptr %l370
  %t686 = load i64, ptr %l375, !tbaa !24
  %t690 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseDefaultCall(ptr %v0, ptr %v4, ptr %v2, ptr %v4, ptr %t683, %"compiler/source:Span" %t684, %"compiler/source:Span" %t685, i64 %t686, ptr %t680, i32 %t681, { i64, ptr } %t682)
  store ptr %t690, ptr %l379
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s0)
  %t691 = load ptr, ptr %l379, !tbaa !29
  store ptr %t691, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  %t692 = load i64, ptr %l19, !tbaa !24
  %t694 = icmp slt i64 %t692, 0
  br i1 %t694, label %bb201, label %bb202
bb201:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load i32, ptr %l10, !tbaa !23
  %t700 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t696, i32 %t697)
  store i1 %t700, ptr %l385
  br label %bb203
bb202:
  store i1 false, ptr %l382, !tbaa !21
  br label %bb204
bb203:
  %t701 = load i1, ptr %l385, !tbaa !21
  store i1 %t701, ptr %l382, !tbaa !21
  br label %bb204
bb204:
  %t702 = load i1, ptr %l382, !tbaa !21
  br i1 %t702, label %bb205, label %bb206
bb205:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t705 = getelementptr %"compiler/check:Checker", ptr %t703, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !29
  %t708 = getelementptr %"compiler/generic:Program", ptr %t706, i32 0, i32 2
  %t709 = load i32, ptr %l10, !tbaa !23
  %t712 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t708, i32 %t709)
  store i1 %t712, ptr %l391
  br label %bb207
bb206:
  store i1 false, ptr %l386, !tbaa !21
  br label %bb208
bb207:
  %t713 = load i1, ptr %l391, !tbaa !21
  store i1 %t713, ptr %l386, !tbaa !21
  br label %bb208
bb208:
  %t714 = load i1, ptr %l386, !tbaa !21
  br i1 %t714, label %bb209, label %bb210
bb209:
  %t715 = load i1, ptr %l18, !tbaa !21
  %t717 = xor i1 %t715, true
  store i1 %t717, ptr %l392, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb211
bb211:
  %t719 = load i1, ptr %l392, !tbaa !21
  br i1 %t719, label %bb212, label %bb213
bb212:
  store %olang.scope zeroinitializer, ptr %s21
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l395, !tbaa !29
  %t721 = load ptr, ptr %l2, !tbaa !29
  %t723 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t721)
  store %"compiler/source:Span" %t723, ptr %l397
  br label %bb214
bb213:
  br label %bb229
bb214:
  %t724 = load ptr, ptr %l0, !tbaa !29
  store ptr %t724, ptr %l398, !tbaa !29
  %t725 = load ptr, ptr %l2, !tbaa !29
  %t727 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t725)
  store %"compiler/source:Span" %t727, ptr %l400
  br label %bb215
bb215:
  %t728 = load ptr, ptr %l398, !tbaa !29
  %t729 = load %"compiler/source:Span", ptr %l400
  %t730 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t728, %"compiler/source:Span" %t729)
  store { i64, ptr } %t730, ptr %l401
  br label %bb216
bb216:
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load i32, ptr %l10, !tbaa !23
  %t735 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s21, ptr %t731, i32 %t732)
  store { i64, ptr } %t735, ptr %l404
  br label %bb217
bb217:
  %t736 = load { i64, ptr }, ptr %l404, !tbaa !27
  store { i64, ptr } %t736, ptr %l405, !tbaa !27
  %t737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t737, ptr %l406, !tbaa !29
  %t738 = load ptr, ptr %l2, !tbaa !29
  %t740 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t738)
  store %"compiler/source:Span" %t740, ptr %l408
  br label %bb218
bb218:
  %t741 = load ptr, ptr %l406, !tbaa !29
  %t742 = load %"compiler/source:Span", ptr %l408
  %t743 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t741, %"compiler/source:Span" %t742)
  store { i64, ptr } %t743, ptr %l409
  br label %bb219
bb219:
  %t744 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t745 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s21, { i64, ptr } %t744)
  store { i64, ptr } %t745, ptr %l410
  br label %bb220
bb220:
  %t746 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 0
  store i64 %t747, ptr %l411, !tbaa !24
  %t748 = load i64, ptr %l411, !tbaa !24
  %t749 = mul i64 %t748, 1
  %t750 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t749)
  %t751 = insertvalue { i64, ptr } undef, i64 %t748, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t750, 1
  store { i64, ptr } %t752, ptr %l412, !tbaa !27
  %t753 = getelementptr { i64, ptr }, ptr %l412, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = getelementptr { i64, ptr }, ptr %l410, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !27
  %t757 = load i64, ptr %l411, !tbaa !24
  %t758 = mul i64 %t757, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t754, ptr %t756, i64 %t758, i1 false)
  %t759 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t760 = extractvalue { i64, ptr } %t759, 0
  %t761 = extractvalue { i64, ptr } %t759, 1
  %t762 = mul i64 %t760, 1
  %t763 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t762)
  call void @llvm.memcpy.p0.p0.i64(ptr %t763, ptr %t761, i64 %t762, i1 false)
  %t764 = insertvalue { i64, ptr } undef, i64 %t760, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  store { i64, ptr } %t765, ptr %l413, !tbaa !27
  %t766 = call ptr @__olang_scope_hold(ptr %v0)
  %t767 = ptrtoint ptr %t766 to i64
  store i64 %t767, ptr %l414, !tbaa !24
  %t768 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t768, label %bb221, label %bb222
bb221:
  %t770 = call ptr @__olang_region_make(ptr %v0)
  %t771 = ptrtoint ptr %t770 to i64
  store i64 %t771, ptr %l414, !tbaa !24
  br label %bb222
bb222:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l416, !tbaa !29
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l417, !tbaa !29
  %t774 = load ptr, ptr %l2, !tbaa !29
  %t776 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t774)
  store %"compiler/source:Span" %t776, ptr %l419
  br label %bb223
bb223:
  %t777 = load ptr, ptr %l417, !tbaa !29
  %t778 = load %"compiler/source:Span", ptr %l419
  %t779 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t777, %"compiler/source:Span" %t778)
  store { i64, ptr } %t779, ptr %l420
  br label %bb224
bb224:
  %t780 = load i64, ptr %l414
  %t781 = inttoptr i64 %t780 to ptr
  %t782 = load i64, ptr %l414
  %t783 = inttoptr i64 %t782 to ptr
  %t784 = load ptr, ptr %l416, !tbaa !29
  %t785 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t786 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eendedWhy(ptr %v0, ptr %t781, ptr %t783, ptr %t784, { i64, ptr } %t785)
  store { i64, ptr } %t786, ptr %l421
  br label %bb225
bb225:
  %t787 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t788 = load i64, ptr %l414
  %t789 = inttoptr i64 %t788 to ptr
  %t790 = extractvalue { i64, ptr } %t787, 0
  %t791 = extractvalue { i64, ptr } %t787, 1
  %t792 = mul i64 %t790, 1
  %t793 = call ptr @__olang_held_alloc(ptr %t789, i64 %t792)
  call void @llvm.memcpy.p0.p0.i64(ptr %t793, ptr %t791, i64 %t792, i1 false)
  %t794 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t795 = insertvalue { i64, ptr } %t794, ptr %t793, 1
  %t796 = load { i64, ptr }, ptr %l401, !tbaa !27
  %t797 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t798 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t800 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s21, ptr %s21, ptr %v0, ptr %v0, { i64, ptr } %t796, { i64, ptr } %t797, { i64, ptr } %t798, { i64, ptr } %t795)
  store %"compiler/diagmsg:Msg" %t800, ptr %l423
  br label %bb226
bb226:
  %t801 = load ptr, ptr %l395, !tbaa !29
  %t802 = load %"compiler/source:Span", ptr %l397
  %t803 = load %"compiler/diagmsg:Msg", ptr %l423
  %t804 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t801, %"compiler/source:Span" %t802, %"compiler/diagmsg:Msg" %t803)
  store i64 %t804, ptr %l424
  br label %bb227
bb227:
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t807 = getelementptr %"compiler/check:Checker", ptr %t805, i32 0, i32 1
  %t808 = load ptr, ptr %t807, !tbaa !29
  %t810 = getelementptr %"compiler/generic:Program", ptr %t808, i32 0, i32 2
  %t811 = load i32, ptr %l10, !tbaa !23
  %t814 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t810, i32 %t811)
  store i32 %t814, ptr %l429
  br label %bb228
bb228:
  %t815 = load i32, ptr %l429, !tbaa !23
  store i32 %t815, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s21)
  br label %bb229
bb229:
  %t816 = load i64, ptr %l19, !tbaa !24
  %t818 = icmp slt i64 %t816, 0
  br i1 %t818, label %bb230, label %bb231
bb230:
  %t820 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t822 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t820, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t822, ptr %l434
  br label %bb232
bb231:
  store i1 false, ptr %l432, !tbaa !21
  br label %bb233
bb232:
  %t823 = load i1, ptr %l434, !tbaa !21
  store i1 %t823, ptr %l432, !tbaa !21
  br label %bb233
bb233:
  %t824 = load i1, ptr %l432, !tbaa !21
  br i1 %t824, label %bb234, label %bb235
bb234:
  %t825 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t827 = extractvalue { i64, ptr } %t825, 0
  %t829 = icmp eq i64 %t827, 0
  store i1 %t829, ptr %l435, !tbaa !21
  br label %bb236
bb235:
  store i1 false, ptr %l435, !tbaa !21
  br label %bb236
bb236:
  %t831 = load i1, ptr %l435, !tbaa !21
  br i1 %t831, label %bb237, label %bb238
bb237:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load i32, ptr %l10, !tbaa !23
  %t836 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t832, i32 %t833)
  store i32 %t836, ptr %l442
  br label %bb239
bb238:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb240
bb239:
  %t837 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t838 = load i32, ptr %l442, !tbaa !23
  %t840 = icmp ne i32 %t838, %t837
  store i1 %t840, ptr %l439, !tbaa !21
  br label %bb240
bb240:
  %t842 = load i1, ptr %l439, !tbaa !21
  br i1 %t842, label %bb241, label %bb242
bb241:
  %t843 = load ptr, ptr %l0, !tbaa !29
  store ptr %t843, ptr %l445, !tbaa !29
  %t844 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t844, ptr %l446
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t845)
  store i32 %t847, ptr %l448
  br label %bb243
bb242:
  br label %bb245
bb243:
  %t848 = load ptr, ptr %l9, !tbaa !29
  %t849 = load ptr, ptr %l445, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l446
  %t851 = load i32, ptr %l448, !tbaa !23
  %t854 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t849, %"compiler/source:Span" %t850, i32 %t851, i32 22, ptr %t848, ptr null)
  store ptr %t854, ptr %l451
  br label %bb244
bb244:
  call void @__olang_scope_close(ptr %s0)
  %t855 = load ptr, ptr %l451, !tbaa !29
  store ptr %t855, ptr %rv
  br label %ret
bb245:
  %t856 = load i64, ptr %l19, !tbaa !24
  %t858 = icmp slt i64 %t856, 0
  br i1 %t858, label %bb246, label %bb247
bb246:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load i32, ptr %l10, !tbaa !23
  %t864 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t860, i32 %t861)
  store i32 %t864, ptr %l457
  br label %bb248
bb247:
  store i1 false, ptr %l454, !tbaa !21
  br label %bb254
bb248:
  %t865 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t866 = load i32, ptr %l457, !tbaa !23
  %t868 = icmp eq i32 %t866, %t865
  br i1 %t868, label %bb249, label %bb250
bb249:
  store i1 true, ptr %l460, !tbaa !21
  br label %bb253
bb250:
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l461, !tbaa !29
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t872 = load i32, ptr %l10, !tbaa !23
  %t875 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t871, i32 %t872)
  store i32 %t875, ptr %l464
  br label %bb251
bb251:
  %t876 = load ptr, ptr %l461, !tbaa !29
  %t877 = load i32, ptr %l464, !tbaa !23
  %t878 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t876, i32 %t877)
  store i1 %t878, ptr %l465
  br label %bb252
bb252:
  %t879 = load i1, ptr %l465, !tbaa !21
  store i1 %t879, ptr %l460, !tbaa !21
  br label %bb253
bb253:
  %t880 = load i1, ptr %l460, !tbaa !21
  store i1 %t880, ptr %l454, !tbaa !21
  br label %bb254
bb254:
  %t881 = load i1, ptr %l454, !tbaa !21
  br i1 %t881, label %bb255, label %bb256
bb255:
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t883 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t882, { i64, ptr } %t883)
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t886 = load ptr, ptr %l0, !tbaa !29
  %t887 = load %"compiler/source:Span", ptr %l1
  %t890 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t886, %"compiler/source:Span" %t887)
  store ptr %t890, ptr %l470
  br label %bb258
bb258:
  call void @__olang_scope_close(ptr %s0)
  %t891 = load ptr, ptr %l470, !tbaa !29
  store ptr %t891, ptr %rv
  br label %ret
bb259:
  %t892 = load i64, ptr %l19, !tbaa !24
  %t894 = icmp slt i64 %t892, 0
  br i1 %t894, label %bb260, label %bb261
bb260:
  %t896 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t898 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t896, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t898, ptr %l475
  br label %bb262
bb261:
  store i1 false, ptr %l473, !tbaa !21
  br label %bb263
bb262:
  %t899 = load i1, ptr %l475, !tbaa !21
  %t900 = xor i1 %t899, true
  store i1 %t900, ptr %l473, !tbaa !21
  br label %bb263
bb263:
  %t902 = load i1, ptr %l473, !tbaa !21
  br i1 %t902, label %bb264, label %bb265
bb264:
  %t903 = load ptr, ptr %l0, !tbaa !29
  store ptr %t903, ptr %l478, !tbaa !29
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t905 = load i32, ptr %l10, !tbaa !23
  %t908 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t904, i32 %t905)
  store i32 %t908, ptr %l481
  br label %bb266
bb265:
  store i1 false, ptr %l477, !tbaa !21
  br label %bb268
bb266:
  %t909 = load ptr, ptr %l478, !tbaa !29
  %t910 = load i32, ptr %l481, !tbaa !23
  %t911 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t909, i32 %t910)
  store i1 %t911, ptr %l482
  br label %bb267
bb267:
  %t912 = load i1, ptr %l482, !tbaa !21
  store i1 %t912, ptr %l477, !tbaa !21
  br label %bb268
bb268:
  %t913 = load i1, ptr %l477, !tbaa !21
  br i1 %t913, label %bb269, label %bb270
bb269:
  %t914 = load ptr, ptr %l0, !tbaa !29
  store ptr %t914, ptr %l484, !tbaa !29
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t916 = load i32, ptr %l10, !tbaa !23
  %t919 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t915, i32 %t916)
  store i32 %t919, ptr %l487
  br label %bb271
bb270:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb273
bb271:
  %t920 = load ptr, ptr %l484, !tbaa !29
  %t921 = load i32, ptr %l487, !tbaa !23
  %t922 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t920, i32 %t921)
  store i1 %t922, ptr %l488
  br label %bb272
bb272:
  %t923 = load i1, ptr %l488, !tbaa !21
  store i1 %t923, ptr %l483, !tbaa !21
  br label %bb273
bb273:
  %t924 = load i1, ptr %l483, !tbaa !21
  br i1 %t924, label %bb274, label %bb275
bb274:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t927 = getelementptr %"compiler/check:Checker", ptr %t925, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !29
  store ptr %t928, ptr %l491, !tbaa !29
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t930 = load i32, ptr %l10, !tbaa !23
  %t933 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t929, i32 %t930)
  store i32 %t933, ptr %l494
  br label %bb276
bb275:
  store i1 false, ptr %l489, !tbaa !21
  br label %bb278
bb276:
  %t934 = load ptr, ptr %l491, !tbaa !29
  %t935 = load i32, ptr %l494, !tbaa !23
  %t936 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t934, i32 %t935)
  store i1 %t936, ptr %l495
  br label %bb277
bb277:
  %t937 = load i1, ptr %l495, !tbaa !21
  %t938 = xor i1 %t937, true
  store i1 %t938, ptr %l489, !tbaa !21
  br label %bb278
bb278:
  %t940 = load i1, ptr %l489, !tbaa !21
  br i1 %t940, label %bb279, label %bb280
bb279:
  %t941 = load ptr, ptr %l0, !tbaa !29
  store ptr %t941, ptr %l498, !tbaa !29
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t943 = load i32, ptr %l10, !tbaa !23
  %t946 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t942, i32 %t943)
  store i32 %t946, ptr %l501
  br label %bb281
bb280:
  store i1 false, ptr %l497, !tbaa !21
  br label %bb283
bb281:
  %t947 = load i32, ptr %l3, !tbaa !23
  %t948 = load ptr, ptr %l498, !tbaa !29
  %t949 = load i32, ptr %l501, !tbaa !23
  %t951 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %t948, i32 %t949, i32 %t947)
  store i1 %t951, ptr %l503
  br label %bb282
bb282:
  %t952 = load i1, ptr %l503, !tbaa !21
  store i1 %t952, ptr %l497, !tbaa !21
  br label %bb283
bb283:
  %t953 = load i1, ptr %l497, !tbaa !21
  br i1 %t953, label %bb284, label %bb285
bb284:
  store %olang.scope zeroinitializer, ptr %s24
  %t954 = load ptr, ptr %l0, !tbaa !29
  store ptr %t954, ptr %l504, !tbaa !29
  %t955 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t955, ptr %l505
  %t956 = load ptr, ptr %l0, !tbaa !29
  store ptr %t956, ptr %l506, !tbaa !29
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t958 = load i32, ptr %l10, !tbaa !23
  %t961 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t957, i32 %t958)
  store i32 %t961, ptr %l509
  br label %bb286
bb285:
  br label %bb293
bb286:
  %t962 = load ptr, ptr %l506, !tbaa !29
  %t963 = load i32, ptr %l509, !tbaa !23
  %t964 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t962, i32 %t963)
  store { i64, ptr } %t964, ptr %l510
  br label %bb287
bb287:
  %t965 = load { i64, ptr }, ptr %l510, !tbaa !27
  store { i64, ptr } %t965, ptr %l511, !tbaa !27
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load i32, ptr %l3, !tbaa !23
  %t970 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s24, ptr %t966, i32 %t967)
  store { i64, ptr } %t970, ptr %l514
  br label %bb288
bb288:
  %t971 = load { i64, ptr }, ptr %l514, !tbaa !27
  %t972 = load { i64, ptr }, ptr %l511, !tbaa !27
  %t974 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %s24, ptr %s24, ptr %v0, { i64, ptr } %t972, { i64, ptr } %t971)
  store %"compiler/diagmsg:Msg" %t974, ptr %l516
  br label %bb289
bb289:
  %t975 = load ptr, ptr %l504, !tbaa !29
  %t976 = load %"compiler/source:Span", ptr %l505
  %t977 = load %"compiler/diagmsg:Msg", ptr %l516
  %t978 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t975, %"compiler/source:Span" %t976, %"compiler/diagmsg:Msg" %t977)
  store i64 %t978, ptr %l517
  br label %bb290
bb290:
  %t979 = load ptr, ptr %l0, !tbaa !29
  %t980 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t979, { i64, ptr } %t980)
  br label %bb291
bb291:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load %"compiler/source:Span", ptr %l1
  %t987 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t983, %"compiler/source:Span" %t984)
  store ptr %t987, ptr %l522
  br label %bb292
bb292:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t988 = load ptr, ptr %l522, !tbaa !29
  store ptr %t988, ptr %rv
  br label %ret
bb293:
  %t989 = load i64, ptr %l19, !tbaa !24
  %t991 = icmp slt i64 %t989, 0
  br i1 %t991, label %bb294, label %bb295
bb294:
  store %olang.scope zeroinitializer, ptr %s25
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load %"compiler/source:Span", ptr %l1
  %t995 = load %"compiler/source:Span", ptr %l4
  %t996 = load ptr, ptr %l2, !tbaa !29
  %t997 = load ptr, ptr %l9, !tbaa !29
  %t998 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t999 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1007 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t993, %"compiler/source:Span" %t994, %"compiler/source:Span" %t995, ptr %t996, ptr %t997, { i64, ptr } %t998, { i64, ptr } %t999)
  store ptr %t1007, ptr %l532
  br label %bb296
bb295:
  br label %bb370
bb296:
  %t1008 = load ptr, ptr %l532, !tbaa !29
  store ptr %t1008, ptr %l22, !tbaa !29
  %t1009 = load ptr, ptr %l22, !tbaa !29
  %t1011 = icmp eq ptr %t1009, null
  %t1013 = xor i1 %t1011, true
  br i1 %t1013, label %bb297, label %bb298
bb297:
  %t1015 = load ptr, ptr %l22, !tbaa !29
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1015, ptr %rv
  br label %ret
bb298:
  br label %bb299
bb299:
  %t1017 = load ptr, ptr %l0, !tbaa !29
  %t1018 = load i32, ptr %l10, !tbaa !23
  %t1021 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1017, i32 %t1018)
  store i32 %t1021, ptr %l539
  br label %bb300
bb300:
  %t1022 = load i32, ptr %l539, !tbaa !23
  store i32 %t1022, ptr %l23, !tbaa !23
  %t1023 = load ptr, ptr %l0, !tbaa !29
  %t1024 = load i32, ptr %l23, !tbaa !23
  %t1027 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1023, i32 %t1024)
  store i1 %t1027, ptr %l542
  br label %bb301
bb301:
  %t1028 = load i1, ptr %l542, !tbaa !21
  br i1 %t1028, label %bb302, label %bb303
bb302:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l23, !tbaa !23
  %t1031 = load i32, ptr %l3, !tbaa !23
  %t1035 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t1029, i32 %t1030, i32 %t1031)
  store i64 %t1035, ptr %l547
  br label %bb304
bb303:
  store i1 false, ptr %l543, !tbaa !21
  br label %bb305
bb304:
  %t1036 = load i64, ptr %l547, !tbaa !24
  %t1037 = icmp sge i64 %t1036, 0
  store i1 %t1037, ptr %l543, !tbaa !21
  br label %bb305
bb305:
  %t1039 = load i1, ptr %l543, !tbaa !21
  br i1 %t1039, label %bb306, label %bb307
bb306:
  store %olang.scope zeroinitializer, ptr %s27
  %t1040 = load ptr, ptr %l9, !tbaa !29
  %t1042 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v4, ptr %v4, ptr %t1040)
  store ptr %t1042, ptr %l550
  br label %bb308
bb307:
  br label %bb327
bb308:
  %t1043 = load ptr, ptr %l550, !tbaa !29
  store ptr %t1043, ptr %l24, !tbaa !29
  %t1044 = load ptr, ptr %l24, !tbaa !29
  %t1046 = icmp eq ptr %t1044, null
  br i1 %t1046, label %bb309, label %bb310
bb309:
  %t1048 = load ptr, ptr %l2, !tbaa !29
  %t1050 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1048)
  store %"compiler/source:Span" %t1050, ptr %l554
  br label %bb311
bb310:
  br label %bb314
bb311:
  %t1051 = load i32, ptr %l10, !tbaa !23
  store i32 %t1051, ptr %l555, !tbaa !23
  %t1052 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1052, ptr %l556, !tbaa !29
  %t1053 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1053, ptr %l557, !tbaa !29
  store i32 8, ptr %l558
  %t1054 = load ptr, ptr %l2, !tbaa !29
  %t1056 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1054)
  store %"compiler/source:Span" %t1056, ptr %l560
  br label %bb312
bb312:
  %t1057 = load ptr, ptr %l557, !tbaa !29
  %t1058 = load i32, ptr %l558, !range !{i32 0, i32 9}
  %t1059 = load %"compiler/source:Span", ptr %l560
  %t1060 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1057, i32 %t1058, %"compiler/source:Span" %t1059)
  store i32 %t1060, ptr %l561
  br label %bb313
bb313:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1061
  %t1062 = getelementptr { i64, [4 x i64] }, ptr %t1061, i32 0, i32 0
  store i64 6, ptr %t1062
  %t1063 = load %"compiler/source:Span", ptr %l554
  %t1064 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t1063, 0
  %t1065 = load i32, ptr %l555, !tbaa !23
  %t1066 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t1064, i32 %t1065, 1
  %t1067 = load ptr, ptr %l556, !tbaa !29
  %t1068 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t1066, ptr %t1067, 2
  %t1069 = load i32, ptr %l561, !tbaa !23
  %t1070 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t1068, i32 %t1069, 3
  %t1071 = getelementptr { i64, [4 x i64] }, ptr %t1061, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t1070, ptr %t1071
  %t1072 = load { i64, [4 x i64] }, ptr %t1061
  %t1074 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t1072, ptr %t1074
  store ptr %t1074, ptr %l24, !tbaa !29
  br label %bb314
bb314:
  %t1076 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1076, ptr %l564, !tbaa !29
  %t1077 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1077, ptr %l565
  %t1078 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1078, ptr %l566
  %t1079 = load ptr, ptr %l24, !tbaa !29
  %t1081 = icmp eq ptr %t1079, null
  br i1 %t1081, label %bb315, label %bb316
bb315:
  call void @__olang_check_failed(ptr @olang_loc_897998a95b9e5e2e_e7f90bd867c953f2)
  unreachable
bb316:
  br label %bb317
bb317:
  %t1083 = load ptr, ptr %l24, !tbaa !29
  %t1084 = load i32, ptr %l3, !tbaa !23
  %t1085 = load ptr, ptr %l564, !tbaa !29
  %t1086 = load %"compiler/source:Span", ptr %l565
  %t1087 = load %"compiler/source:Span", ptr %l566
  %t1090 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v4, ptr %v4, ptr %t1085, %"compiler/source:Span" %t1086, %"compiler/source:Span" %t1087, ptr %t1083, i32 %t1084)
  store ptr %t1090, ptr %l571
  br label %bb318
bb318:
  %t1091 = load ptr, ptr %l571, !tbaa !29
  store ptr %t1091, ptr %l25, !tbaa !29
  %t1092 = load ptr, ptr %l2, !tbaa !29
  %t1094 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1092)
  store %"compiler/source:Span" %t1094, ptr %l573
  br label %bb319
bb319:
  %t1095 = getelementptr %"compiler/source:Span", ptr %l573, i32 0, i32 0
  %t1096 = load i32, ptr %t1095, !tbaa !23
  %t1097 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t1098 = load i32, ptr %t1097, !tbaa !23
  %t1101 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s27, i32 %t1096, i32 %t1098)
  store %"compiler/source:Span" %t1101, ptr %l576
  br label %bb320
bb320:
  %t1102 = load %"compiler/source:Span", ptr %l576
  store %"compiler/source:Span" %t1102, ptr %l26
  %t1103 = load ptr, ptr %l25, !tbaa !29
  %t1105 = icmp eq ptr %t1103, null
  %t1107 = xor i1 %t1105, true
  br i1 %t1107, label %bb321, label %bb322
bb321:
  %t1109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1109, ptr %l580, !tbaa !29
  %t1110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1110, ptr %l581
  %t1111 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1111, ptr %l582
  %t1112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1112, ptr %l583, !tbaa !29
  %t1113 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t1113, ptr %l584
  %t1114 = load ptr, ptr %l0, !tbaa !29
  %t1115 = load %"compiler/source:Span", ptr %l26
  %t1116 = load ptr, ptr %l2, !tbaa !29
  %t1117 = load i32, ptr %l3, !tbaa !23
  %t1118 = load ptr, ptr %l25, !tbaa !29
  %t1124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedPlace(ptr %v0, ptr %v1, ptr %v4, ptr %v4, ptr %t1114, %"compiler/source:Span" %t1115, ptr %t1116, i32 %t1117, ptr %t1118)
  store ptr %t1124, ptr %l590
  br label %bb323
bb322:
  br label %bb326
bb323:
  %t1125 = load ptr, ptr %l583, !tbaa !29
  %t1126 = load %"compiler/source:Span", ptr %l584
  %t1127 = load ptr, ptr %l590, !tbaa !29
  %t1128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v4, ptr %v4, ptr %t1125, %"compiler/source:Span" %t1126, ptr %t1127)
  store ptr %t1128, ptr %l591
  br label %bb324
bb324:
  %t1129 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1130 = load ptr, ptr %l580, !tbaa !29
  %t1131 = load %"compiler/source:Span", ptr %l581
  %t1132 = load %"compiler/source:Span", ptr %l582
  %t1133 = load ptr, ptr %l591, !tbaa !29
  %t1135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v4, ptr %v2, ptr %v4, ptr %t1130, %"compiler/source:Span" %t1131, %"compiler/source:Span" %t1132, ptr %t1133, { i64, ptr } %t1129)
  store ptr %t1135, ptr %l593
  br label %bb325
bb325:
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t1136 = load ptr, ptr %l593, !tbaa !29
  store ptr %t1136, ptr %rv
  br label %ret
bb326:
  call void @__olang_scope_close(ptr %s27)
  br label %bb327
bb327:
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1138 = load i32, ptr %l23, !tbaa !23
  %t1141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1137, i32 %t1138)
  store i1 %t1141, ptr %l596
  br label %bb328
bb328:
  %t1142 = load i1, ptr %l596, !tbaa !21
  br i1 %t1142, label %bb329, label %bb330
bb329:
  %t1143 = load ptr, ptr %l0, !tbaa !29
  %t1144 = load i32, ptr %l23, !tbaa !23
  %t1147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t1143, i32 %t1144)
  store i32 %t1147, ptr %l600
  br label %bb331
bb330:
  store i1 false, ptr %l597, !tbaa !21
  br label %bb332
bb331:
  %t1148 = load i32, ptr %l600, !range !{i32 0, i32 6}
  %t1150 = trunc i64 3 to i32
  %t1151 = icmp eq i32 %t1148, %t1150
  store i1 %t1151, ptr %l597, !tbaa !21
  br label %bb332
bb332:
  %t1153 = load i1, ptr %l597, !tbaa !21
  br i1 %t1153, label %bb333, label %bb334
bb333:
  %t1154 = load ptr, ptr %l0, !tbaa !29
  %t1155 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t1154, { i64, ptr } %t1155)
  br label %bb335
bb334:
  br label %bb337
bb335:
  %t1158 = load ptr, ptr %l0, !tbaa !29
  %t1159 = load %"compiler/source:Span", ptr %l1
  %t1162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t1158, %"compiler/source:Span" %t1159)
  store ptr %t1162, ptr %l607
  br label %bb336
bb336:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t1163 = load ptr, ptr %l607, !tbaa !29
  store ptr %t1163, ptr %rv
  br label %ret
bb337:
  %t1164 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s25, { i64, ptr } %t1164, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t1166, ptr %l609
  br label %bb338
bb338:
  %t1167 = load i1, ptr %l609, !tbaa !21
  br i1 %t1167, label %bb339, label %bb340
bb339:
  store i1 true, ptr %l610, !tbaa !21
  br label %bb342
bb340:
  %t1168 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s25, { i64, ptr } %t1168, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t1170, ptr %l612
  br label %bb341
bb341:
  %t1171 = load i1, ptr %l612, !tbaa !21
  store i1 %t1171, ptr %l610, !tbaa !21
  br label %bb342
bb342:
  %t1172 = load i1, ptr %l610, !tbaa !21
  br i1 %t1172, label %bb343, label %bb344
bb343:
  %t1173 = load ptr, ptr %l0, !tbaa !29
  %t1174 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t1173, %"compiler/source:Span" %t1174, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb345
bb344:
  store %olang.scope zeroinitializer, ptr %s32
  %t1177 = load i32, ptr %l23, !tbaa !23
  store i32 %t1177, ptr %l615, !tbaa !23
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1180 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t1178)
  store i32 %t1180, ptr %l617
  br label %bb346
bb345:
  br label %bb367
bb346:
  %t1181 = load i32, ptr %l615, !tbaa !23
  %t1182 = load i32, ptr %l617, !tbaa !23
  %t1183 = icmp eq i32 %t1181, %t1182
  br i1 %t1183, label %bb347, label %bb348
bb347:
  %t1185 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s32, { i64, ptr } %t1185, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t1187, ptr %l621
  br label %bb349
bb348:
  store i1 false, ptr %l619, !tbaa !21
  br label %bb354
bb349:
  %t1188 = load i1, ptr %l621, !tbaa !21
  br i1 %t1188, label %bb350, label %bb351
bb350:
  store i1 true, ptr %l622, !tbaa !21
  br label %bb353
bb351:
  %t1189 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s32, { i64, ptr } %t1189, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t1191, ptr %l624
  br label %bb352
bb352:
  %t1192 = load i1, ptr %l624, !tbaa !21
  store i1 %t1192, ptr %l622, !tbaa !21
  br label %bb353
bb353:
  %t1193 = load i1, ptr %l622, !tbaa !21
  store i1 %t1193, ptr %l619, !tbaa !21
  br label %bb354
bb354:
  %t1194 = load i1, ptr %l619, !tbaa !21
  br i1 %t1194, label %bb355, label %bb356
bb355:
  store %olang.scope zeroinitializer, ptr %s33
  %t1195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1195, ptr %l625, !tbaa !29
  %t1196 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1196, ptr %l626
  %t1197 = load ptr, ptr %l0, !tbaa !29
  %t1198 = load i32, ptr %l3, !tbaa !23
  %t1201 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s33, ptr %t1197, i32 %t1198)
  store { i64, ptr } %t1201, ptr %l629
  br label %bb357
bb356:
  store %olang.scope zeroinitializer, ptr %s34
  %t1202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1202, ptr %l634, !tbaa !29
  %t1203 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1203, ptr %l635
  %t1204 = load i32, ptr %l10, !tbaa !23
  store i32 %t1204, ptr %l636, !tbaa !23
  %t1205 = load ptr, ptr %l0, !tbaa !29
  %t1206 = load i32, ptr %l3, !tbaa !23
  %t1209 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s34, ptr %t1205, i32 %t1206)
  store { i64, ptr } %t1209, ptr %l639
  br label %bb360
bb357:
  %t1210 = load { i64, ptr }, ptr %l629, !tbaa !27
  %t1211 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1214 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %s33, ptr %v4, ptr %v0, { i64, ptr } %t1210, { i64, ptr } %t1211)
  store %"compiler/diagmsg:Msg" %t1214, ptr %l632
  br label %bb358
bb358:
  %t1215 = load ptr, ptr %l625, !tbaa !29
  %t1216 = load %"compiler/source:Span", ptr %l626
  %t1217 = load %"compiler/diagmsg:Msg", ptr %l632
  %t1218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1215, %"compiler/source:Span" %t1216, %"compiler/diagmsg:Msg" %t1217)
  store i64 %t1218, ptr %l633
  br label %bb359
bb359:
  call void @__olang_scope_close(ptr %s33)
  br label %bb366
bb360:
  %t1219 = load { i64, ptr }, ptr %l639, !tbaa !27
  %t1220 = extractvalue { i64, ptr } %t1219, 1
  %t1221 = extractvalue { i64, ptr } %t1219, 0
  %t1222 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t1221)
  call void @olang_textcopy(ptr %t1222, ptr %t1220, i64 %t1221)
  %t1223 = insertvalue { i64, ptr } undef, i64 %t1221, 0
  %t1224 = insertvalue { i64, ptr } %t1223, ptr %t1222, 1
  store { i64, ptr } %t1224, ptr %l641, !tbaa !27
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1227 = load i32, ptr %l10, !tbaa !23
  %t1230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s34, ptr %t1226, i32 %t1227)
  store { i64, ptr } %t1230, ptr %l644
  br label %bb361
bb361:
  %t1231 = load { i64, ptr }, ptr %l644, !tbaa !27
  store { i64, ptr } %t1231, ptr %l645, !tbaa !27
  %t1232 = load ptr, ptr %l0, !tbaa !29
  %t1233 = load i32, ptr %l3, !tbaa !23
  %t1236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s34, ptr %t1232, i32 %t1233)
  store { i64, ptr } %t1236, ptr %l648
  br label %bb362
bb362:
  %t1237 = load { i64, ptr }, ptr %l648, !tbaa !27
  store { i64, ptr } %t1237, ptr %l649, !tbaa !27
  %t1238 = load ptr, ptr %l0, !tbaa !29
  %t1239 = load i32, ptr %l10, !tbaa !23
  %t1240 = load i32, ptr %l3, !tbaa !23
  %t1244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %s34, ptr %t1238, i32 %t1239, i32 %t1240, i1 true)
  store { i64, ptr } %t1244, ptr %l653
  br label %bb363
bb363:
  %t1245 = load { i64, ptr }, ptr %l653, !tbaa !27
  %t1246 = load { i64, ptr }, ptr %l645, !tbaa !27
  %t1247 = load { i64, ptr }, ptr %l649, !tbaa !27
  %t1249 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %s34, ptr %s34, ptr %s34, ptr %v0, { i64, ptr } %t1246, { i64, ptr } %t1247, { i64, ptr } %t1245)
  store %"compiler/diagmsg:Msg" %t1249, ptr %l655
  br label %bb364
bb364:
  %t1250 = load ptr, ptr %l634, !tbaa !29
  %t1251 = load %"compiler/source:Span", ptr %l635
  %t1252 = load i32, ptr %l636, !tbaa !23
  %t1253 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1254 = load %"compiler/diagmsg:Msg", ptr %l655
  %t1255 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s34, ptr %v0, ptr %t1250, %"compiler/source:Span" %t1251, i32 %t1252, { i64, ptr } %t1253, %"compiler/diagmsg:Msg" %t1254)
  store i64 %t1255, ptr %l656
  br label %bb365
bb365:
  call void @__olang_scope_close(ptr %s34)
  br label %bb366
bb366:
  call void @__olang_scope_close(ptr %s32)
  br label %bb367
bb367:
  %t1256 = load ptr, ptr %l0, !tbaa !29
  %t1257 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t1256, { i64, ptr } %t1257)
  br label %bb368
bb368:
  %t1260 = load ptr, ptr %l0, !tbaa !29
  %t1261 = load %"compiler/source:Span", ptr %l1
  %t1264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t1260, %"compiler/source:Span" %t1261)
  store ptr %t1264, ptr %l661
  br label %bb369
bb369:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t1265 = load ptr, ptr %l661, !tbaa !29
  store ptr %t1265, ptr %rv
  br label %ret
bb370:
  %t1266 = load ptr, ptr %l0, !tbaa !29
  %t1267 = load i64, ptr %l19, !tbaa !24
  %t1268 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t1272 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateMethod(ptr %v0, ptr %v4, ptr %t1266, i64 %t1267, { i64, ptr } %t1268)
  store i1 %t1272, ptr %l665
  br label %bb371
bb371:
  %t1273 = load i1, ptr %l665, !tbaa !21
  br i1 %t1273, label %bb372, label %bb373
bb372:
  store %olang.scope zeroinitializer, ptr %s36
  %t1274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1274, ptr %l666, !tbaa !29
  %t1275 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1275, ptr %l667
  %t1276 = load ptr, ptr %l0, !tbaa !29
  %t1277 = load i32, ptr %l3, !tbaa !23
  %t1280 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s36, ptr %t1276, i32 %t1277)
  store { i64, ptr } %t1280, ptr %l670
  br label %bb374
bb373:
  br label %bb377
bb374:
  %t1281 = load { i64, ptr }, ptr %l670, !tbaa !27
  %t1283 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s36, ptr %v0, { i64, ptr } %t1281)
  store %"compiler/diagmsg:Msg" %t1283, ptr %l672
  br label %bb375
bb375:
  %t1284 = load ptr, ptr %l666, !tbaa !29
  %t1285 = load %"compiler/source:Span", ptr %l667
  %t1286 = load %"compiler/diagmsg:Msg", ptr %l672
  %t1287 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1284, %"compiler/source:Span" %t1285, %"compiler/diagmsg:Msg" %t1286)
  store i64 %t1287, ptr %l673
  br label %bb376
bb376:
  call void @__olang_scope_close(ptr %s36)
  br label %bb377
bb377:
  %t1288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1288, ptr %l674, !tbaa !29
  %t1289 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1289, ptr %l675
  %t1290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1290, ptr %l676, !tbaa !29
  %t1291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1291, ptr %l677
  %t1292 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1292, ptr %l678
  %t1293 = load i64, ptr %l19, !tbaa !24
  store i64 %t1293, ptr %l679, !tbaa !24
  %t1294 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1294, ptr %l681, !tbaa !29
  %t1296 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1296, ptr %l682, !tbaa !27
  %t1297 = icmp sge i64 0, 0
  br i1 %t1297, label %bb378, label %bb379
bb378:
  %t1299 = icmp sle i64 0, 1152921504606846975
  br i1 %t1299, label %bb380, label %bb381
bb379:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb380:
  %t1301 = mul i64 0, 8
  %t1302 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1303 = insertvalue { i64, ptr } %t1302, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1303, ptr %l685, !tbaa !27
  %t1304 = icmp sge i64 0, 0
  br i1 %t1304, label %bb382, label %bb383
bb381:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb382:
  %t1306 = icmp sle i64 0, 2305843009213693951
  br i1 %t1306, label %bb384, label %bb385
bb383:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb384:
  %t1308 = mul i64 0, 4
  %t1309 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1310 = insertvalue { i64, ptr } %t1309, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1311 = load ptr, ptr %l676, !tbaa !29
  %t1312 = load %"compiler/source:Span", ptr %l677
  %t1313 = load %"compiler/source:Span", ptr %l678
  %t1314 = load i64, ptr %l679, !tbaa !24
  %t1315 = load ptr, ptr %l681, !tbaa !29
  %t1316 = load { i64, ptr }, ptr %l682, !tbaa !27
  %t1317 = load { i64, ptr }, ptr %l685, !tbaa !27
  %t1319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %t1311, %"compiler/source:Span" %t1312, %"compiler/source:Span" %t1313, i64 %t1314, ptr %t1315, { i64, ptr } %t1316, { i64, ptr } %t1317, { i64, ptr } %t1310)
  store ptr %t1319, ptr %l689
  br label %bb386
bb385:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb386:
  %t1320 = load ptr, ptr %l674, !tbaa !29
  %t1321 = load %"compiler/source:Span", ptr %l675
  %t1322 = load ptr, ptr %l689, !tbaa !29
  %t1323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v0, ptr %v4, ptr %t1320, %"compiler/source:Span" %t1321, ptr %t1322)
  store ptr %t1323, ptr %l690
  br label %bb387
bb387:
  call void @__olang_scope_close(ptr %s0)
  %t1324 = load ptr, ptr %l690, !tbaa !29
  store ptr %t1324, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Nearest"
  %l22 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca %"compiler/diagmsg:Msg"
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/diagmsg:Msg"
  %l64 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store %"compiler/msgs:Nearest" %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load %"compiler/msgs:Nearest", ptr %l13
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t8, ptr %t9
  store ptr %t9, ptr %l5, !tbaa !29
  store { i64, ptr } %a3, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l22, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l9, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Param", ptr %t44, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t47)
  store { i64, ptr } %t50, ptr %l33
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t51, { i64, ptr } %t52)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l7, !tbaa !24
  br label %bb3
bb13:
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t60 = getelementptr %"compiler/msgs:Nearest", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l41, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t68, ptr %l42
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l54, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l55
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t76, i32 %t77)
  store { i64, ptr } %t80, ptr %l58
  br label %bb20
bb16:
  %t81 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t81, ptr %l46, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s5, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l48
  br label %bb17
bb17:
  %t85 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/msgs:Nearest", ptr %t86, i32 0, i32 1
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %s5, ptr %s5, ptr %s0, ptr %v0, { i64, ptr } %t90, { i64, ptr } %t85, { i64, ptr } %t89)
  store %"compiler/diagmsg:Msg" %t93, ptr %l52
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l42
  %t96 = load %"compiler/diagmsg:Msg", ptr %l52
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t94, %"compiler/source:Span" %t95, %"compiler/diagmsg:Msg" %t96)
  store i64 %t97, ptr %l53
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb20:
  %t98 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t98, ptr %l59, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s6, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l61
  br label %bb21
bb21:
  %t102 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t105 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t103, { i64, ptr } %t102)
  store %"compiler/diagmsg:Msg" %t105, ptr %l63
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l55
  %t108 = load %"compiler/diagmsg:Msg", ptr %l63
  %t109 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t106, %"compiler/source:Span" %t107, %"compiler/diagmsg:Msg" %t108)
  store i64 %t109, ptr %l64
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %lp36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i1
  %l129 = alloca { i64, ptr }
  %l139 = alloca i32
  %l140 = alloca i32
  %l143 = alloca { i64, ptr }
  %l147 = alloca %"compiler/source:Span"
  %l155 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l166 = alloca %"compiler/diagmsg:Msg"
  %l167 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca %"compiler/source:Span"
  %l176 = alloca %"compiler/diagmsg:Msg"
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"compiler/diagmsg:Msg"
  %l184 = alloca { i64, ptr }
  %l186 = alloca %"compiler/diagmsg:Msg"
  %l187 = alloca i64
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca %"compiler/diagmsg:Msg"
  %l199 = alloca i64
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca i64
  %l225 = alloca { i64, ptr }
  %l227 = alloca %"compiler/diagmsg:Msg"
  %l228 = alloca i64
  %l236 = alloca i64
  %l239 = alloca i64
  %l248 = alloca i64
  %l251 = alloca i1
  %l269 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l277 = alloca i64
  %l280 = alloca i64
  %l302 = alloca ptr
  %l303 = alloca { i64, ptr }
  %l305 = alloca %"compiler/source:Span"
  %l318 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t38 = alloca i64
  %t586 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v2, { i64, ptr } %t1)
  store i1 %t3, ptr %l45
  br label %bb1
bb1:
  %t4 = load i1, ptr %l45, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l50, !tbaa !24
  %t14 = load i64, ptr %l50, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l50, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb7:
  %t20 = load i64, ptr %l50, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t25, ptr %lp8
  %t27 = load ptr, ptr %lp8
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l54, !tbaa !24
  %t29 = load i64, ptr %l54, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb9:
  %t32 = load i64, ptr %l54, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb11:
  %t35 = load i64, ptr %l54, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, %t35
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i64, ptr %t37, i64 %t42
  store i64 -1, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l58, !tbaa !24
  %t50 = load i64, ptr %l58, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb13:
  %t53 = load i64, ptr %l58, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210)
  unreachable
bb15:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb20
bb17:
  %t73 = load i64, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l69, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l69, !tbaa !24
  store i64 %t89, ptr %l66, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l66, !tbaa !24
  store i64 %t90, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l15, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb22, label %bb23
bb22:
  br label %bb84
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l16, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t109, ptr %l87, !tbaa !27
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l17, !tbaa !29
  %t117 = load ptr, ptr %l17, !tbaa !29
  store ptr %t117, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t118 = load ptr, ptr %l90, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l90, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 28}
  %t124 = icmp eq i64 %t122, 24
  store i1 %t124, ptr %l91, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l91, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l17, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l18
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l19, !tbaa !23
  %t138 = load ptr, ptr %l17, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l20, !tbaa !29
  br label %bb29
bb28:
  br label %bb68
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l6, !tbaa !21
  store i64 -1, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  store i64 %t144, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t146 = load i64, ptr %l23, !tbaa !24
  %t147 = load i64, ptr %l22, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb30, label %bb31
bb30:
  %t152 = load i64, ptr %l24, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb35
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l24, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l24, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l107, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb34
bb34:
  %t172 = load i64, ptr %l107, !tbaa !24
  store i64 %t172, ptr %l104, !tbaa !24
  br label %bb35
bb35:
  %t173 = load i64, ptr %l104, !tbaa !24
  store i64 %t173, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t174 = load i64, ptr %l25, !tbaa !24
  %t175 = sub i64 %t174, 1
  store i64 %t175, ptr %l116, !tbaa !24
  %t176 = load i64, ptr %l25, !tbaa !24
  %t177 = icmp slt i64 %t176, 2147483648
  %t178 = load i64, ptr %l26, !tbaa !24
  %t179 = icmp sge i64 %t178, 0
  %t182 = and i1 %t177, %t179
  store i1 %t182, ptr %l119, !tbaa !21
  br label %bb36
bb36:
  %t183 = load i64, ptr %l26, !tbaa !24
  %t184 = load i64, ptr %l25, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t191 = load i64, ptr %l22, !tbaa !24
  %t192 = load i64, ptr %l26, !tbaa !24
  %t193 = load i64, ptr %l24, !tbaa !24
  %t196 = mul i64 %t192, %t193
  %t199 = add i64 %t191, %t196
  store i64 %t199, ptr %l27, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t201, ptr %l129, !tbaa !27
  %t202 = load i64, ptr %l27, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr ptr, ptr %t205, i64 %t202
  %t207 = load ptr, ptr %t206, !tbaa !39
  %t209 = getelementptr %"compiler/ast:Param", ptr %t207, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t211 = load i32, ptr %l19, !tbaa !23
  %t214 = icmp eq i32 %t210, %t211
  br i1 %t214, label %bb40, label %bb41
bb40:
  %t216 = load i64, ptr %l27, !tbaa !24
  store i64 %t216, ptr %l21, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t218 = load i64, ptr %l26, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l26, !tbaa !24
  br label %bb36
bb44:
  %t223 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t224 = load i32, ptr %t223, !tbaa !23
  store i32 %t224, ptr %l139, !tbaa !23
  %t225 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t226 = load i32, ptr %t225, !tbaa !23
  store i32 %t226, ptr %l140, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l19, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t227, i32 %t228)
  store { i64, ptr } %t231, ptr %l143
  br label %bb45
bb45:
  %t232 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 0
  %t235 = trunc i64 %t233 to i32
  %t236 = load i32, ptr %l140, !tbaa !23
  %t238 = add i32 %t236, %t235
  %t239 = load i32, ptr %l139, !tbaa !23
  %t241 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t239, i32 %t238)
  store %"compiler/source:Span" %t241, ptr %l147
  br label %bb46
bb46:
  %t242 = load %"compiler/source:Span", ptr %l147
  store %"compiler/source:Span" %t242, ptr %l28
  %t243 = load i64, ptr %l21, !tbaa !24
  %t245 = icmp slt i64 %t243, 0
  br i1 %t245, label %bb47, label %bb48
bb47:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l28
  %t249 = load i32, ptr %l19, !tbaa !23
  %t250 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v3, ptr %t247, %"compiler/source:Span" %t248, i32 %t249, { i64, ptr } %t250, { i64, ptr } %a3)
  br label %bb49
bb48:
  %t257 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t257, ptr %l155, !tbaa !27
  %t258 = load i64, ptr %l21, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  %t265 = getelementptr %"compiler/ast:Param", ptr %t263, i32 0, i32 3
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = icmp eq ptr %t266, null
  br i1 %t268, label %bb50, label %bb51
bb49:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb67
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l160, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t271, ptr %l161
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l19, !tbaa !23
  %t276 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t272, i32 %t273)
  store { i64, ptr } %t276, ptr %l164
  br label %bb52
bb51:
  %t277 = load i64, ptr %l21, !tbaa !24
  %t278 = load ptr, ptr %lp8
  %t280 = getelementptr { i64, ptr }, ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr ptr, ptr %t281, i64 %t277
  %t283 = load ptr, ptr %t282, !tbaa !39
  %t285 = icmp eq ptr %t283, null
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb55, label %bb56
bb52:
  %t289 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t291 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %s11, ptr %v0, { i64, ptr } %t289)
  store %"compiler/diagmsg:Msg" %t291, ptr %l166
  br label %bb53
bb53:
  %t292 = load ptr, ptr %l160, !tbaa !29
  %t293 = load %"compiler/source:Span", ptr %l161
  %t294 = load %"compiler/diagmsg:Msg", ptr %l166
  %t295 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t292, %"compiler/source:Span" %t293, %"compiler/diagmsg:Msg" %t294)
  store i64 %t295, ptr %l167
  br label %bb54
bb54:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l172, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t297, ptr %l173
  %t298 = load i64, ptr %l21, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t298
  %t303 = load i1, ptr %t302, !tbaa !31
  br i1 %t303, label %bb57, label %bb58
bb56:
  %t305 = load i64, ptr %l21, !tbaa !24
  %t306 = load ptr, ptr %l20, !tbaa !29
  %t309 = load ptr, ptr %lp8
  %t311 = getelementptr { i64, ptr }, ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr ptr, ptr %t312, i64 %t305
  store ptr %t306, ptr %t313, !tbaa !39
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l16, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t314
  store i64 %t315, ptr %t320, !tbaa !34
  %t321 = load i64, ptr %l21, !tbaa !24
  %t323 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i1, ptr %t324, i64 %t321
  store i1 true, ptr %t325, !tbaa !31
  br label %bb65
bb57:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l19, !tbaa !23
  %t330 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t326, i32 %t327)
  store { i64, ptr } %t330, ptr %l179
  br label %bb59
bb58:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l19, !tbaa !23
  %t335 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t331, i32 %t332)
  store { i64, ptr } %t335, ptr %l184
  br label %bb61
bb59:
  %t336 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t338 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %s13, ptr %v0, { i64, ptr } %t336)
  store %"compiler/diagmsg:Msg" %t338, ptr %l181
  br label %bb60
bb60:
  %t339 = load %"compiler/diagmsg:Msg", ptr %l181
  store %"compiler/diagmsg:Msg" %t339, ptr %l176
  br label %bb63
bb61:
  %t340 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t342 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %s13, ptr %v0, { i64, ptr } %t340)
  store %"compiler/diagmsg:Msg" %t342, ptr %l186
  br label %bb62
bb62:
  %t343 = load %"compiler/diagmsg:Msg", ptr %l186
  store %"compiler/diagmsg:Msg" %t343, ptr %l176
  br label %bb63
bb63:
  %t344 = load ptr, ptr %l172, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l173
  %t346 = load %"compiler/diagmsg:Msg", ptr %l176
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t344, %"compiler/source:Span" %t345, %"compiler/diagmsg:Msg" %t346)
  store i64 %t347, ptr %l187
  br label %bb64
bb64:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb82
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t348 = load i1, ptr %l6, !tbaa !21
  br i1 %t348, label %bb72, label %bb73
bb72:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l195, !tbaa !29
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t351)
  store %"compiler/source:Span" %t353, ptr %l197
  br label %bb74
bb73:
  %t354 = load i64, ptr %l5, !tbaa !24
  %t355 = load i64, ptr %l4, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  br i1 %t358, label %bb77, label %bb78
bb74:
  %t360 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
  store %"compiler/diagmsg:Msg" %t360, ptr %l198
  br label %bb75
bb75:
  %t361 = load ptr, ptr %l195, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l197
  %t363 = load %"compiler/diagmsg:Msg", ptr %l198
  %t364 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t361, %"compiler/source:Span" %t362, %"compiler/diagmsg:Msg" %t363)
  store i64 %t364, ptr %l199
  br label %bb76
bb76:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb80
bb77:
  %t365 = load i64, ptr %l5, !tbaa !24
  %t366 = load ptr, ptr %l17, !tbaa !29
  %t369 = load ptr, ptr %lp8
  %t371 = getelementptr { i64, ptr }, ptr %t369, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr ptr, ptr %t372, i64 %t365
  store ptr %t366, ptr %t373, !tbaa !39
  %t374 = load i64, ptr %l5, !tbaa !24
  %t375 = load i64, ptr %l16, !tbaa !24
  %t378 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = getelementptr i64, ptr %t379, i64 %t374
  store i64 %t375, ptr %t380, !tbaa !34
  br label %bb79
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t381 = load i64, ptr %l5, !tbaa !24
  %t384 = add i64 %t381, 1
  store i64 %t384, ptr %l5, !tbaa !24
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e)
  unreachable
bb82:
  br label %bb83
bb83:
  %t386 = load i64, ptr %l15, !tbaa !24
  %t389 = add i64 %t386, 1
  store i64 %t389, ptr %l15, !tbaa !24
  br label %bb21
bb84:
  %t391 = load i64, ptr %l5, !tbaa !24
  %t392 = load i64, ptr %l4, !tbaa !24
  %t395 = icmp sgt i64 %t391, %t392
  br i1 %t395, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l217, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t398, ptr %l218, !tbaa !27
  %t399 = load i64, ptr %l4, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr ptr, ptr %t402, i64 %t399
  %t404 = load ptr, ptr %t403, !tbaa !39
  %t406 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t404)
  store %"compiler/source:Span" %t406, ptr %l221
  br label %bb87
bb86:
  br label %bb93
bb87:
  %t407 = load i64, ptr %l4, !tbaa !24
  store i64 %t407, ptr %l222, !tbaa !24
  %t408 = load i64, ptr %l4, !tbaa !24
  %t410 = icmp eq i64 %t408, 1
  br i1 %t410, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l225, !tbaa !27
  br label %bb90
bb89:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l225, !tbaa !27
  br label %bb90
bb90:
  %t412 = load i64, ptr %l5, !tbaa !24
  %t413 = load i64, ptr %l222, !tbaa !24
  %t414 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t416 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s20, ptr %v0, i64 %t413, { i64, ptr } %t414, i64 %t412)
  store %"compiler/diagmsg:Msg" %t416, ptr %l227
  br label %bb91
bb91:
  %t417 = load ptr, ptr %l217, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l221
  %t419 = load %"compiler/diagmsg:Msg", ptr %l227
  %t420 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t417, %"compiler/source:Span" %t418, %"compiler/diagmsg:Msg" %t419)
  store i64 %t420, ptr %l228
  br label %bb92
bb92:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s20)
  br label %bb93
bb93:
  %t421 = load i1, ptr %l7, !tbaa !21
  br i1 %t421, label %bb94, label %bb95
bb94:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 177
  store i1 true, ptr %t425, !tbaa !21
  %t426 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t426, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  store i64 -1, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t428 = load i64, ptr %l4, !tbaa !24
  store i64 %t428, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t430 = load i64, ptr %l31, !tbaa !24
  %t431 = load i64, ptr %l30, !tbaa !24
  %t434 = icmp sgt i64 %t430, %t431
  br i1 %t434, label %bb97, label %bb98
bb97:
  %t436 = load i64, ptr %l32, !tbaa !24
  %t438 = icmp sgt i64 %t436, 0
  br i1 %t438, label %bb99, label %bb100
bb98:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb102
bb99:
  %t440 = load i64, ptr %l31, !tbaa !24
  %t441 = load i64, ptr %l30, !tbaa !24
  %t444 = sub i64 %t440, %t441
  %t445 = load i64, ptr %l32, !tbaa !24
  %t448 = add i64 %t444, %t445
  %t450 = sub i64 %t448, 1
  %t451 = load i64, ptr %l32, !tbaa !24
  %t454 = sdiv i64 %t450, %t451
  store i64 %t454, ptr %l239, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb101
bb101:
  %t456 = load i64, ptr %l239, !tbaa !24
  store i64 %t456, ptr %l236, !tbaa !24
  br label %bb102
bb102:
  %t457 = load i64, ptr %l236, !tbaa !24
  store i64 %t457, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t458 = load i64, ptr %l33, !tbaa !24
  %t459 = sub i64 %t458, 1
  store i64 %t459, ptr %l248, !tbaa !24
  %t460 = load i64, ptr %l33, !tbaa !24
  %t461 = icmp slt i64 %t460, 2147483648
  %t462 = load i64, ptr %l34, !tbaa !24
  %t463 = icmp sge i64 %t462, 0
  %t466 = and i1 %t461, %t463
  store i1 %t466, ptr %l251, !tbaa !21
  br label %bb103
bb103:
  %t467 = load i64, ptr %l34, !tbaa !24
  %t468 = load i64, ptr %l33, !tbaa !24
  %t471 = icmp slt i64 %t467, %t468
  %t473 = xor i1 %t471, true
  br i1 %t473, label %bb104, label %bb105
bb104:
  br label %bb111
bb105:
  br label %bb106
bb106:
  %t475 = load i64, ptr %l30, !tbaa !24
  %t476 = load i64, ptr %l34, !tbaa !24
  %t477 = load i64, ptr %l32, !tbaa !24
  %t480 = mul i64 %t476, %t477
  %t483 = add i64 %t475, %t480
  store i64 %t483, ptr %l35, !tbaa !24
  %t485 = load i64, ptr %l35, !tbaa !24
  %t486 = load ptr, ptr %lp8
  %t488 = getelementptr { i64, ptr }, ptr %t486, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr ptr, ptr %t489, i64 %t485
  %t491 = load ptr, ptr %t490, !tbaa !39
  %t493 = icmp eq ptr %t491, null
  %t495 = xor i1 %t493, true
  br i1 %t495, label %bb107, label %bb108
bb107:
  %t497 = load i64, ptr %l35, !tbaa !24
  store i64 %t497, ptr %l29, !tbaa !24
  br label %bb109
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t499 = load i64, ptr %l34, !tbaa !24
  %t502 = add i64 %t499, 1
  store i64 %t502, ptr %l34, !tbaa !24
  br label %bb103
bb111:
  %t504 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, ptr %l269
  br label %bb112
bb112:
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t505, ptr %lp36
  %t506 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l269
  %t507 = load ptr, ptr %lp36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t506, ptr %t507
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/check:Checker", ptr %t508, i32 0, i32 178
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t510)
  br label %bb113
bb113:
  store i64 0, ptr %l37, !tbaa !24
  %t512 = load i64, ptr %l29, !tbaa !24
  %t514 = add i64 %t512, 1
  store i64 %t514, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t516 = load i64, ptr %l38, !tbaa !24
  %t517 = load i64, ptr %l37, !tbaa !24
  %t520 = icmp sgt i64 %t516, %t517
  br i1 %t520, label %bb114, label %bb115
bb114:
  %t522 = load i64, ptr %l39, !tbaa !24
  %t524 = icmp sgt i64 %t522, 0
  br i1 %t524, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l277, !tbaa !24
  br label %bb119
bb116:
  %t526 = load i64, ptr %l38, !tbaa !24
  %t527 = load i64, ptr %l37, !tbaa !24
  %t530 = sub i64 %t526, %t527
  %t531 = load i64, ptr %l39, !tbaa !24
  %t534 = add i64 %t530, %t531
  %t536 = sub i64 %t534, 1
  %t537 = load i64, ptr %l39, !tbaa !24
  %t540 = sdiv i64 %t536, %t537
  store i64 %t540, ptr %l280, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb118
bb118:
  %t542 = load i64, ptr %l280, !tbaa !24
  store i64 %t542, ptr %l277, !tbaa !24
  br label %bb119
bb119:
  %t543 = load i64, ptr %l277, !tbaa !24
  store i64 %t543, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb120
bb120:
  %t544 = load i64, ptr %l41, !tbaa !24
  %t545 = load i64, ptr %l40, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb121, label %bb122
bb121:
  br label %bb132
bb122:
  br label %bb123
bb123:
  %t552 = load i64, ptr %l37, !tbaa !24
  %t553 = load i64, ptr %l41, !tbaa !24
  %t554 = load i64, ptr %l39, !tbaa !24
  %t557 = mul i64 %t553, %t554
  %t560 = add i64 %t552, %t557
  store i64 %t560, ptr %l42, !tbaa !24
  %t562 = load i64, ptr %l42, !tbaa !24
  %t563 = load ptr, ptr %lp8
  %t565 = getelementptr { i64, ptr }, ptr %t563, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !27
  %t567 = getelementptr ptr, ptr %t566, i64 %t562
  %t568 = load ptr, ptr %t567, !tbaa !39
  store ptr %t568, ptr %l43, !tbaa !29
  %t570 = load ptr, ptr %l43, !tbaa !29
  %t572 = icmp eq ptr %t570, null
  br i1 %t572, label %bb124, label %bb125
bb124:
  %t574 = load ptr, ptr %lp36
  store ptr %t574, ptr %l302, !tbaa !29
  %t575 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t575, ptr %l303, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr ptr, ptr %t577, i64 0
  %t579 = load ptr, ptr %t578, !tbaa !39
  %t581 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t579)
  store %"compiler/source:Span" %t581, ptr %l305
  br label %bb126
bb125:
  %t582 = load ptr, ptr %lp36
  %t583 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t582, ptr %t583)
  br label %bb128
bb126:
  store { i64, [4 x i64] } zeroinitializer, ptr %t586
  %t587 = getelementptr { i64, [4 x i64] }, ptr %t586, i32 0, i32 0
  store i64 23, ptr %t587
  %t588 = load %"compiler/source:Span", ptr %l305
  %t589 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t588, 0
  %t590 = getelementptr { i64, [4 x i64] }, ptr %t586, i32 0, i32 1
  store { %"compiler/source:Span" } %t589, ptr %t590
  %t591 = load { i64, [4 x i64] }, ptr %t586
  %t593 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t591, ptr %t593
  %t594 = load ptr, ptr %l302, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t594, ptr %t593)
  br label %bb127
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/check:Checker", ptr %t596, i32 0, i32 178
  %t599 = load i64, ptr %l42, !tbaa !24
  %t601 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = getelementptr i64, ptr %t602, i64 %t599
  %t604 = load i64, ptr %t603, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t598, i64 %t604)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t607 = load i64, ptr %l41, !tbaa !24
  %t610 = add i64 %t607, 1
  store i64 %t610, ptr %l41, !tbaa !24
  br label %bb120
bb132:
  %t612 = load ptr, ptr %lp36
  %t614 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t612)
  store { i64, ptr } %t614, ptr %l318
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s0)
  %t615 = load { i64, ptr }, ptr %l318, !tbaa !27
  store { i64, ptr } %t615, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamespaceTaken(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t13, i32 %t14, i32 %t15)
  store i1 %t19, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l15, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l18, !tbaa !24
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t42 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v0, ptr %v1, ptr %t38, { i64, ptr } %t39)
  store { i64, ptr } %t42, ptr %l22
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l4, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t46, ptr %l24
  br label %bb11
bb11:
  %t47 = load i1, ptr %l24, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l29
  br label %bb15
bb15:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t60, ptr %l32
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb39
bb18:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb22
bb20:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t64, ptr %l35
  br label %bb21
bb21:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb26
bb24:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t69, ptr %l38
  br label %bb25
bb25:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l36, !tbaa !21
  br label %bb26
bb26:
  %t71 = load i1, ptr %l36, !tbaa !21
  br i1 %t71, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb30
bb28:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t74, ptr %l41
  br label %bb29
bb29:
  %t75 = load i1, ptr %l41, !tbaa !21
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb34
bb32:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t79, ptr %l44
  br label %bb33
bb33:
  %t80 = load i1, ptr %l44, !tbaa !21
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb34
bb34:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb38
bb36:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t82, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t84, ptr %l47
  br label %bb37
bb37:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %l45, !tbaa !21
  br label %bb38
bb38:
  %t86 = load i1, ptr %l45, !tbaa !21
  store i1 %t86, ptr %l30, !tbaa !21
  br label %bb39
bb39:
  %t87 = load i1, ptr %l30, !tbaa !21
  br i1 %t87, label %bb40, label %bb41
bb40:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t88, ptr %l49, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l50, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l51, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t102, ptr %l49, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t106, ptr %l53
  br label %bb43
bb43:
  %t107 = load i1, ptr %l53, !tbaa !21
  br i1 %t107, label %bb44, label %bb45
bb44:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l1, !tbaa !23
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t112, ptr %l57
  br label %bb46
bb45:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb47
bb46:
  %t113 = load i1, ptr %l57, !tbaa !21
  store i1 %t113, ptr %l54, !tbaa !21
  br label %bb47
bb47:
  %t114 = load i1, ptr %l54, !tbaa !21
  br i1 %t114, label %bb48, label %bb49
bb48:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v0, ptr %t115, i32 %t116)
  store ptr %t119, ptr %l61
  br label %bb50
bb49:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb51
bb50:
  %t120 = load ptr, ptr %l61, !tbaa !29
  %t122 = getelementptr %"compiler/check:rawTable", ptr %t120, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t127 = icmp ne i32 %t123, %t124
  store i1 %t127, ptr %l58, !tbaa !21
  br label %bb51
bb51:
  %t129 = load i1, ptr %l58, !tbaa !21
  br i1 %t129, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t130, ptr %l67, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l68, !tbaa !24
  %t133 = load i64, ptr %l68, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l69, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l68, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t144, ptr %l67, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t145 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t146, ptr %l71, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l72, !tbaa !24
  %t149 = load i64, ptr %l72, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l73, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l72, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t160, ptr %l71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t161, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAst(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  store ptr %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t3 = trunc i64 68 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l11, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t7)
  store i32 %t10, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb3:
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = load i32, ptr %l14, !tbaa !23
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisText(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t13, ptr %l15
  br label %bb4
bb4:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i32, ptr %l20, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisText(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l21, !tbaa !21
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l16, !tbaa !21
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValues(ptr %v0, ptr %v3, ptr %v1, ptr %v4, ptr %v2, ptr %v5, ptr %t26, %"compiler/source:Span" %t27, ptr %t28, ptr %t29, ptr %t30, ptr %t31)
  store ptr %t38, ptr %l28
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t39 = load ptr, ptr %l28, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l30
  store %"compiler/source:Span" %a2, ptr %l31
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 116}
  store i32 %t43, ptr %l32
  %t44 = load ptr, ptr %l4, !tbaa !29
  store ptr %t44, ptr %l33, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l36
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l38
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l29, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l30
  %t54 = load %"compiler/source:Span", ptr %l31
  %t55 = load i32, ptr %l32, !range !{i32 0, i32 116}
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l36
  %t59 = load %"compiler/source:Span", ptr %l38
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v5, ptr %t52, %"compiler/source:Span" %t53, %"compiler/source:Span" %t54, i32 %t55, ptr %t56, ptr %t57, %"compiler/source:Span" %t58, %"compiler/source:Span" %t59)
  store ptr %t60, ptr %l39
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l39, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2elaneTok(i32 %a1)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 52
  store i1 %t5, ptr %t7, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t8, ptr %a2, i32 %a3)
  store ptr %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l11, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epower(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l46 = alloca i32
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l101 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l12
  %t10 = load %"compiler/source:Span", ptr %l14
  %t11 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t8, %"compiler/source:Span" %t9, %"compiler/source:Span" %t10, i64 2)
  store %"compiler/source:Span" %t11, ptr %l15
  br label %bb3
bb3:
  %t12 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t12, ptr %l5
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l22
  br label %bb6
bb5:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %l19, !tbaa !23
  br label %bb7
bb6:
  %t26 = load i32, ptr %l22, !tbaa !23
  store i32 %t26, ptr %l19, !tbaa !23
  br label %bb7
bb7:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l30
  br label %bb8
bb8:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l34
  br label %bb11
bb10:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l34, !tbaa !21
  store i1 %t43, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l31, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l38
  br label %bb15
bb14:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l35, !tbaa !23
  br label %bb16
bb15:
  %t52 = load i32, ptr %l38, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t53, ptr %t54, i32 %t55)
  store ptr %t56, ptr %l40
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t57)
  store %"compiler/source:Span" %t59, ptr %l42
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l42
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t60, ptr %t61, %"compiler/source:Span" %t62)
  store ptr %t63, ptr %l43
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l43, !tbaa !29
  store ptr %t64, ptr %l7, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t65)
  store i32 %t68, ptr %l46
  br label %bb20
bb20:
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = load i32, ptr %l46, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t74, ptr %t75, i32 %t77)
  store ptr %t81, ptr %l53
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t82, %"compiler/source:Span" %t83)
  store ptr %t86, ptr %l56
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l56, !tbaa !29
  store ptr %t87, ptr %rv
  br label %ret
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v3, ptr %t88, ptr %t89)
  store i64 %t92, ptr %l59
  br label %bb26
bb26:
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb31
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l62, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t97)
  store i32 %t100, ptr %l65
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = load i32, ptr %l65, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t103, ptr %l66
  br label %bb30
bb30:
  %t104 = load i1, ptr %l66, !tbaa !21
  store i1 %t104, ptr %l61, !tbaa !21
  br label %bb31
bb31:
  %t105 = load i1, ptr %l61, !tbaa !21
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l69, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v3, ptr %t109, ptr %t110)
  store i32 %t114, ptr %l73
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = load i32, ptr %l73, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l74
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l67, !tbaa !29
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = load i32, ptr %l74, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v3, ptr %t118, ptr %t119, i32 %t120)
  store ptr %t121, ptr %l75
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l75, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load %"compiler/source:Span", ptr %l5
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t123, %"compiler/source:Span" %t124, %"compiler/source:Span" %t125, i32 71, ptr %t126, ptr %t122)
  store ptr %t134, ptr %l82
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l82, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
bb38:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  store ptr %t138, ptr %l86, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l87, !tbaa !29
  %t141 = load ptr, ptr %l7, !tbaa !29
  %t144 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t141)
  store i32 %t144, ptr %l90
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l87, !tbaa !29
  %t146 = load i32, ptr %l90, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t147, ptr %l91
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l84, !tbaa !29
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load i32, ptr %l91, !tbaa !23
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t148, ptr %t149, i32 %t150)
  store ptr %t151, ptr %l92
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t152)
  store %"compiler/source:Span" %t154, ptr %l94
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load ptr, ptr %l92, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l94
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t155, ptr %t156, %"compiler/source:Span" %t157)
  store ptr %t158, ptr %l95
  br label %bb43
bb43:
  %t159 = load ptr, ptr %l95, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t162 = load %"compiler/source:Span", ptr %l5
  %t163 = load ptr, ptr %l7, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t160, %"compiler/source:Span" %t161, %"compiler/source:Span" %t162, ptr %t163, ptr %t159)
  store ptr %t170, ptr %l101
  br label %bb44
bb44:
  %t171 = load ptr, ptr %l101, !tbaa !29
  store ptr %t171, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateMethod(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %a1)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store { i64, ptr } %a2, ptr %l8, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i8, ptr %t12, i64 0
  %t14 = load i8, ptr %t13, !tbaa !32
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t14)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t30 = icmp ne i64 %t28, %t27
  store i1 %t30, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l12, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 10
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t46 = load ptr, ptr %l25, !tbaa !29
  %t48 = getelementptr %"compiler/load:Module", ptr %t46, i32 0, i32 33
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t53 = load i1, ptr %l19, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprogramOrigin(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/generic:Origin"
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca i64
  %l15 = alloca i32
  %l18 = alloca %"compiler/generic:Origin"
  %l22 = alloca %"compiler/generic:Origin"
  %l26 = alloca %"compiler/generic:Origin"
  %l31 = alloca i64
  %l34 = alloca i64
  %l65 = alloca i1
  %l73 = alloca %"compiler/generic:Origin"
  %l80 = alloca %"compiler/generic:Origin"
  %rv = alloca { i64, [3 x i64] }
  %t32 = alloca { i64, [3 x i64] }, align 8
  %t99 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i32, ptr %l15, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/generic:Origin" %t20, ptr %l22
  br label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t24, i32 %t25)
  store %"compiler/generic:Origin" %t28, ptr %l26
  br label %bb6
bb5:
  %t29 = load %"compiler/generic:Origin", ptr %l22
  store %"compiler/generic:Origin" %t29, ptr %l18
  br label %bb7
bb6:
  %t30 = load %"compiler/generic:Origin", ptr %l26
  store %"compiler/generic:Origin" %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load %"compiler/generic:Origin", ptr %l18
  store %"compiler/generic:Origin" %t31, ptr %l3
  store { i64, [3 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [3 x i64] }, ptr %t32
  store { i64, [3 x i64] } %t34, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i64 64, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l34, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t62 = load i64, ptr %l34, !tbaa !24
  store i64 %t62, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb15, label %bb16
bb15:
  br label %bb34
bb16:
  br label %bb17
bb17:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l10, !tbaa !24
  %t82 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t87 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t90 = getelementptr %"compiler/source:Span", ptr %t89, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 1
  %t95 = getelementptr %"compiler/source:Span", ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t98 = sext i32 %t96 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 0
  store i64 3, ptr %t100
  %t102 = insertvalue { i64, i64, i64 } undef, i64 %t88, 0
  %t104 = insertvalue { i64, i64, i64 } %t102, i64 %t93, 1
  %t106 = insertvalue { i64, i64, i64 } %t104, i64 %t98, 2
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  store { i64, i64, i64 } %t106, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t99
  store { i64, [3 x i64] } %t108, ptr %l11
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 4
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load { i64, [3 x i64] }, ptr %l11
  %t123 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsLibrary(ptr %v0, ptr %t119, { i64, [3 x i64] } %t120)
  store i1 %t123, ptr %l65
  br label %bb21
bb21:
  %t124 = load i1, ptr %l65, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb22, label %bb23
bb22:
  %t127 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t127, ptr %l4
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t129 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp sge i64 %t130, 0
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 2
  %t139 = load i64, ptr %t138, !tbaa !24
  %t142 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t137, i64 %t139)
  store %"compiler/generic:Origin" %t142, ptr %l73
  br label %bb27
bb26:
  %t143 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 3
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t148 = icmp ne i32 %t144, %t145
  br i1 %t148, label %bb28, label %bb29
bb27:
  %t150 = load %"compiler/generic:Origin", ptr %l73
  store %"compiler/generic:Origin" %t150, ptr %l3
  br label %bb32
bb28:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Origin", ptr %l3, i32 0, i32 3
  %t156 = load i32, ptr %t155, !tbaa !23
  %t159 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t154, i32 %t156)
  store %"compiler/generic:Origin" %t159, ptr %l80
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t160 = load %"compiler/generic:Origin", ptr %l80
  store %"compiler/generic:Origin" %t160, ptr %l3
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t161, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb14
bb34:
  %t166 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t166, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/generic:Desc"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/check:narrowed"
  %l22 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %l28 = alloca %"compiler/generic:Desc"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/diagmsg:Msg"
  %l43 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/diagmsg:Msg"
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca i1
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l115 = alloca i32
  %l128 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca %"compiler/diagmsg:Msg"
  %l143 = alloca i64
  %l148 = alloca { i32, { i64, ptr } }
  %l152 = alloca i1
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l167 = alloca i64
  %l169 = alloca i64
  %l174 = alloca %"compiler/check:narrowed"
  %l178 = alloca i1
  %l181 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i1
  %l198 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca { i64, ptr }
  %l202 = alloca %"compiler/source:Span"
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l218 = alloca i64
  %l222 = alloca ptr
  %l227 = alloca i32
  %l228 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l232 = alloca %"compiler/source:Span"
  %l233 = alloca i32
  %l237 = alloca %"compiler/typed:Payload"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t164 = alloca { i64, [4 x i64] }, align 8
  %t268 = alloca { i64, [4 x i64] }, align 8
  %t459 = alloca { i64, [4 x i64] }, align 8
  %t477 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t4, i32 %a3)
  store %"compiler/generic:Desc" %t8, ptr %l28
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Desc", ptr %l28
  store %"compiler/generic:Desc" %t9, ptr %l5
  %t10 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t15 = icmp ne i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t19 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb4, label %bb5
bb3:
  br label %bb13
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb9
bb5:
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t33, ptr %l37, !tbaa !27
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t35 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %s1, ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t35, ptr %l42
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l32, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l33
  %t38 = load %"compiler/diagmsg:Msg", ptr %l42
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t36, %"compiler/source:Span" %t37, %"compiler/diagmsg:Msg" %t38)
  store i64 %t39, ptr %l43
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t41)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp ne i64 %t47, 1
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l50, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l51
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %t55)
  store %"compiler/diagmsg:Msg" %t57, ptr %l54
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t58 = load ptr, ptr %l50, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l51
  %t60 = load %"compiler/diagmsg:Msg", ptr %l54
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t58, %"compiler/source:Span" %t59, %"compiler/diagmsg:Msg" %t60)
  store i64 %t61, ptr %l55
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %t63)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l60, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t67, ptr %t72)
  store ptr %t75, ptr %l62
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l62, !tbaa !29
  store ptr %t76, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l7, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t84)
  store i32 %t86, ptr %l68
  br label %bb24
bb24:
  %t87 = load i32, ptr %l68, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb30
bb27:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb30
bb30:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l95
  br label %bb35
bb35:
  %t139 = load i1, ptr %l95, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v2, ptr %t142, ptr %t143)
  br label %bb39
bb39:
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l99
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l104
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t157, %"compiler/source:Span" %t158, ptr %t159)
  store ptr %t163, ptr %l108
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 0
  store i64 2, ptr %t165
  %t166 = load %"compiler/source:Span", ptr %l99
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t166, 0
  %t168 = load i32, ptr %l104, !tbaa !23
  %t169 = insertvalue { %"compiler/source:Span", i32, ptr } %t167, i32 %t168, 1
  %t170 = load ptr, ptr %l108, !tbaa !29
  %t171 = insertvalue { %"compiler/source:Span", i32, ptr } %t169, ptr %t170, 2
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t171, ptr %t172
  %t173 = load { i64, [4 x i64] }, ptr %t164
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t173, ptr %t175
  store ptr %t175, ptr %l7, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l8, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l115
  br label %bb42
bb42:
  %t187 = load i32, ptr %l115, !tbaa !23
  store i32 %t187, ptr %l8, !tbaa !23
  br label %bb43
bb43:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l13, !tbaa !24
  br label %bb31
bb44:
  %t193 = load i32, ptr %l8, !tbaa !23
  %t194 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t197 = icmp eq i32 %t193, %t194
  br i1 %t197, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l8, !tbaa !23
  %t207 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t212 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t205, i32 %t206, i32 %t208)
  store i1 %t212, ptr %l128
  br label %bb48
bb48:
  %t213 = load i1, ptr %l128, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l130, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t217, ptr %l131, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 0
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t223 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t221)
  store %"compiler/source:Span" %t223, ptr %l133
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t226 = load i32, ptr %t225, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t224, i32 %t226)
  store { i64, ptr } %t229, ptr %l136
  br label %bb52
bb52:
  %t230 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t230, ptr %l137, !tbaa !27
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i32, ptr %l8, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t231, i32 %t232)
  store { i64, ptr } %t235, ptr %l140
  br label %bb53
bb53:
  %t236 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t239 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflOfType(ptr %s9, ptr %s9, ptr %v0, { i64, ptr } %t237, { i64, ptr } %t236)
  store %"compiler/diagmsg:Msg" %t239, ptr %l142
  br label %bb54
bb54:
  %t240 = load ptr, ptr %l130, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l133
  %t242 = load %"compiler/diagmsg:Msg", ptr %l142
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t240, %"compiler/source:Span" %t241, %"compiler/diagmsg:Msg" %t242)
  store i64 %t243, ptr %l143
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb56:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load %"compiler/generic:Desc", ptr %l5
  %t252 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t248, %"compiler/generic:Desc" %t249)
  store { i32, { i64, ptr } } %t252, ptr %l148
  br label %bb57
bb57:
  %t253 = load { i32, { i64, ptr } }, ptr %l148
  store { i32, { i64, ptr } } %t253, ptr %l15
  %t254 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t255 = load i32, ptr %t254, !tbaa !23
  store i32 %t255, ptr %l16, !tbaa !23
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l8, !tbaa !23
  %t261 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t257, i32 %t258)
  store i1 %t261, ptr %l152
  br label %bb58
bb58:
  %t262 = load i1, ptr %l152, !tbaa !21
  br i1 %t262, label %bb59, label %bb60
bb59:
  %t263 = load %"compiler/source:Span", ptr %l1
  %t264 = load i32, ptr %l16, !tbaa !23
  %t265 = load ptr, ptr %l7, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t267 = load i64, ptr %t266, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 0
  store i64 3, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t263, 0
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t271, i32 %t264, 1
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t273, ptr %t265, 2
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t275, i64 %t267, 3
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t277, ptr %t278
  %t279 = load { i64, [4 x i64] }, ptr %t268
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t279, ptr %t281
  call void @__olang_scope_close(ptr %s0)
  store ptr %t281, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t284, ptr %l160, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr ptr, ptr %t286, i64 0
  %t288 = load ptr, ptr %t287, !tbaa !39
  %t291 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %s0, ptr %t283, ptr %t288)
  store { i64, ptr } %t291, ptr %l162
  br label %bb62
bb62:
  %t292 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t292, ptr %l17, !tbaa !27
  store i1 false, ptr %l18, !tbaa !21
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t293)
  store ptr %t295, ptr %l164
  br label %bb63
bb63:
  %t296 = load ptr, ptr %l164, !tbaa !29
  %t298 = getelementptr %"compiler/check:frame", ptr %t296, i32 0, i32 46
  store ptr %t298, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  %t300 = load i64, ptr %l20, !tbaa !24
  store i64 %t300, ptr %l167, !tbaa !24
  %t301 = load ptr, ptr %l19, !tbaa !29
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t301)
  store i64 %t303, ptr %l169
  br label %bb65
bb65:
  %t304 = load i64, ptr %l167, !tbaa !24
  %t305 = load i64, ptr %l169, !tbaa !24
  %t306 = icmp slt i64 %t304, %t305
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb66, label %bb67
bb66:
  br label %bb84
bb67:
  br label %bb68
bb68:
  %t310 = load ptr, ptr %l19, !tbaa !29
  %t311 = load i64, ptr %l20, !tbaa !24
  %t314 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t310, i64 %t311)
  store %"compiler/check:narrowed" %t314, ptr %l174
  br label %bb69
bb69:
  %t315 = load %"compiler/check:narrowed", ptr %l174
  store %"compiler/check:narrowed" %t315, ptr %l21
  %t316 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t320 = icmp sgt i64 %t318, 0
  br i1 %t320, label %bb70, label %bb71
bb70:
  %t322 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 5
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t327 = call i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %s0, { i64, ptr } %t323, { i64, ptr } %t324)
  store i1 %t327, ptr %l181
  br label %bb72
bb71:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb73
bb72:
  %t328 = load i1, ptr %l181, !tbaa !21
  store i1 %t328, ptr %l178, !tbaa !21
  br label %bb73
bb73:
  %t329 = load i1, ptr %l178, !tbaa !21
  br i1 %t329, label %bb74, label %bb75
bb74:
  %t330 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 1
  %t331 = load i64, ptr %t330, !tbaa !24
  %t332 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t333 = load i64, ptr %t332, !tbaa !24
  %t336 = icmp eq i64 %t331, %t333
  store i1 %t336, ptr %l182, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb76
bb76:
  %t338 = load i1, ptr %l182, !tbaa !21
  br i1 %t338, label %bb77, label %bb78
bb77:
  %t339 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 7
  %t340 = load i1, ptr %t339, !tbaa !21
  %t342 = xor i1 %t340, true
  store i1 %t342, ptr %l186, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb79
bb79:
  %t344 = load i1, ptr %l186, !tbaa !21
  br i1 %t344, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t345 = load i64, ptr %l20, !tbaa !24
  %t348 = add i64 %t345, 1
  store i64 %t348, ptr %l20, !tbaa !24
  br label %bb64
bb84:
  %t350 = load i1, ptr %l18, !tbaa !21
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s15
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t354, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = getelementptr %"compiler/generic:Program", ptr %t357, i32 0, i32 2
  %t360 = load i32, ptr %l8, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s15, ptr %t359, i32 %t360)
  store { i64, ptr } %t363, ptr %l198
  br label %bb87
bb86:
  br label %bb94
bb87:
  %t364 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t364, ptr %l22, !tbaa !27
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l199, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t366, ptr %l200, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr ptr, ptr %t368, i64 0
  %t370 = load ptr, ptr %t369, !tbaa !39
  %t372 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t370)
  store %"compiler/source:Span" %t372, ptr %l202
  br label %bb88
bb88:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l8, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l205
  br label %bb89
bb89:
  %t378 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t378, ptr %l206, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t380, ptr %l208, !tbaa !27
  %t381 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t382 = load i64, ptr %t381, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr i32, ptr %t385, i64 %t382
  %t387 = load i32, ptr %t386, !tbaa !33
  %t390 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s15, ptr %t379, i32 %t387)
  store { i64, ptr } %t390, ptr %l211
  br label %bb90
bb90:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load %"compiler/generic:Desc", ptr %l5
  %t395 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s15, ptr %t391, %"compiler/generic:Desc" %t392)
  store { i64, ptr } %t395, ptr %l214
  br label %bb91
bb91:
  %t396 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t400 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t401 = add i64 %t398, %t400
  %t402 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 1
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t405 = add i64 %t401, %t404
  %t406 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t397, i64 %t398)
  %t407 = getelementptr i8, ptr %t406, i64 %t398
  call void @olang_textcopy(ptr %t407, ptr %t399, i64 %t400)
  %t408 = getelementptr i8, ptr %t407, i64 %t400
  call void @olang_textcopy(ptr %t408, ptr %t403, i64 %t404)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t406, 1
  %t412 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t414 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s15, ptr %s15, ptr %v0, ptr %v0, { i64, ptr } %t412, { i64, ptr } %t410, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t414, ptr %l217
  br label %bb92
bb92:
  %t415 = load ptr, ptr %l199, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l202
  %t417 = load %"compiler/diagmsg:Msg", ptr %l217
  %t418 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t415, %"compiler/source:Span" %t416, %"compiler/diagmsg:Msg" %t417)
  store i64 %t418, ptr %l218
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb94:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t420, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = getelementptr %"compiler/generic:Program", ptr %t423, i32 0, i32 2
  store ptr %t425, ptr %l222, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/generic:Program", ptr %t429, i32 0, i32 2
  %t432 = load i32, ptr %l8, !tbaa !23
  %t435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t431, i32 %t432)
  store i32 %t435, ptr %l227
  br label %bb95
bb95:
  %t436 = load ptr, ptr %l222, !tbaa !29
  %t437 = load i32, ptr %l227, !tbaa !23
  %t438 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t436, i32 %t437)
  store { i64, ptr } %t438, ptr %l228
  br label %bb96
bb96:
  %t439 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t439, ptr %l229, !tbaa !27
  %t440 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t441 = load i64, ptr %t440, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i32, ptr %t444, i64 %t441
  %t446 = load i32, ptr %t445, !tbaa !33
  %t448 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t448, ptr %l232
  store i32 %t446, ptr %l233, !tbaa !23
  %t450 = load ptr, ptr %l7, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t452 = load i64, ptr %t451, !tbaa !24
  %t456 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v2, ptr %v2, ptr %t450, i64 %t452, i32 0)
  store %"compiler/typed:Payload" %t456, ptr %l237
  br label %bb97
bb97:
  %t457 = load %"compiler/typed:Payload", ptr %l237
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Payload" %t457, ptr %t458
  store { i64, [4 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [4 x i64] }, ptr %t459, i32 0, i32 0
  store i64 5, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l232
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t463 = load i32, ptr %l233, !tbaa !23
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t463, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [4 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [4 x i64] }, ptr %t459
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store ptr %t469, ptr %lp24
  %t471 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t468, ptr %t471
  %t472 = load %"compiler/source:Span", ptr %l1
  %t473 = load i32, ptr %l16, !tbaa !23
  %t474 = load ptr, ptr %lp24
  %t475 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t476 = load i64, ptr %t475, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t477
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 0
  store i64 3, ptr %t478
  %t480 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t472, 0
  %t482 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t480, i32 %t473, 1
  %t484 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t482, ptr %t474, 2
  %t486 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t484, i64 %t476, 3
  %t487 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t486, ptr %t487
  %t488 = load { i64, [4 x i64] }, ptr %t477
  %t490 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t488, ptr %t490
  call void @__olang_scope_close(ptr %s0)
  store ptr %t490, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 171
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 171
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %t9, ptr %a1)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l11
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb2, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l10
  br label %bb1
bb1:
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  br label %bb4
bb2:
  %t19 = load i32, ptr %l11, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 171
  %t27 = load i1, ptr %t26, !tbaa !21
  %t30 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 172
  store i1 %t27, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i1, ptr %l2, !tbaa !21
  %t35 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 171
  store i1 %t32, ptr %t35, !tbaa !21
  %t37 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t37, ptr %rv
  br label %ret
bb4:
  %t38 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 171
  %t43 = load i1, ptr %t42, !tbaa !21
  %t46 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 172
  store i1 %t43, ptr %t46, !tbaa !21
  store { i64, ptr } %t38, ptr %l23, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l24, !tbaa !24
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l25, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t61, ptr %l23, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i1, ptr %l2, !tbaa !21
  %t66 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 171
  store i1 %t63, ptr %t66, !tbaa !21
  %t67 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t68 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t67, 1
  store { i32, { i64, ptr } } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 165
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l17 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i32
  %l35 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l78 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t18 = alloca i64
  %t45 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l17, !tbaa !29
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l15, !tbaa !24
  %t12 = icmp sle i64 %t11, 1152921504606846975
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_efc3d234eb1501de_4d27d8d6a326f0a)
  unreachable
bb3:
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t15)
  %t17 = load ptr, ptr %l17, !tbaa !29
  store i64 0, ptr %t18
  br label %fill.19
fill.19:
  %t22 = load i64, ptr %t18
  %t23 = icmp slt i64 %t22, %t14
  br i1 %t23, label %fillb.20, label %filld.21
fillb.20:
  %t24 = getelementptr ptr, ptr %t16, i64 %t22
  store ptr %t17, ptr %t24
  %t25 = add i64 %t22, 1
  store i64 %t25, ptr %t18
  br label %fill.19
filld.21:
  %t26 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t16, 1
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t28, ptr %lp4
  %t30 = load ptr, ptr %lp4
  store { i64, ptr } %t27, ptr %t30, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l22, !tbaa !24
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t34, ptr %l23, !tbaa !23
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_efc3d234eb1501de_4d27d8d6a326f0a)
  unreachable
bb5:
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = icmp sle i64 %t38, 2305843009213693951
  br i1 %t39, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7655d192ba63d713_67a9153eaa817cdf)
  unreachable
bb7:
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = mul i64 %t41, 4
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  %t44 = load i32, ptr %l23, !tbaa !23
  store i64 0, ptr %t45
  br label %fill.46
fill.46:
  %t49 = load i64, ptr %t45
  %t50 = icmp slt i64 %t49, %t41
  br i1 %t50, label %fillb.47, label %filld.48
fillb.47:
  %t51 = getelementptr i32, ptr %t43, i64 %t49
  store i32 %t44, ptr %t51
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %t45
  br label %fill.46
filld.48:
  %t53 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_7655d192ba63d713_67a9153eaa817cdf)
  unreachable
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t70 = load i64, ptr %l7, !tbaa !24
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t72, ptr %l35, !tbaa !27
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l10, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t80, ptr %t81, i32 %t83)
  store ptr %t87, ptr %l42
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l42, !tbaa !29
  store ptr %t88, ptr %l11, !tbaa !29
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load ptr, ptr %l11, !tbaa !29
  %t92 = load ptr, ptr %lp4
  %t94 = getelementptr { i64, ptr }, ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t89
  store ptr %t90, ptr %t96, !tbaa !39
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l45, !tbaa !29
  %t98 = load ptr, ptr %l11, !tbaa !29
  %t101 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t98)
  store i32 %t101, ptr %l48
  br label %bb14
bb14:
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t103 = load i32, ptr %l48, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l49
  br label %bb15
bb15:
  %t105 = load i32, ptr %l49, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load i32, ptr %l12, !tbaa !23
  %t107 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t110 = icmp eq i32 %t106, %t107
  br i1 %t110, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb18
bb17:
  %t112 = load i32, ptr %l12, !tbaa !23
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t116 = icmp eq i32 %t112, %t113
  store i1 %t116, ptr %l53, !tbaa !21
  br label %bb18
bb18:
  %t118 = load i1, ptr %l53, !tbaa !21
  br i1 %t118, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb20:
  br label %bb21
bb21:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l12, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadBad(ptr %v0, ptr %s2, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l59
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t124, ptr %l13, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t125, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t127, ptr %l61
  br label %bb23
bb23:
  %t128 = load i1, ptr %l61, !tbaa !21
  %t129 = xor i1 %t128, true
  br i1 %t129, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l63, !tbaa !29
  %t132 = load ptr, ptr %l10, !tbaa !29
  %t134 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t132)
  store %"compiler/source:Span" %t134, ptr %l65
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %a3, ptr %l67, !tbaa !27
  %t137 = load i64, ptr %l9, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr ptr, ptr %t140, i64 %t137
  %t142 = load ptr, ptr %t141, !tbaa !39
  %t144 = getelementptr %"compiler/ast:Param", ptr %t142, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t135, i32 %t145)
  store { i64, ptr } %t148, ptr %l71
  br label %bb27
bb27:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l12, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l74
  br label %bb28
bb28:
  %t154 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t159 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadHoldsRef(ptr %v0, ptr %s4, ptr %s2, ptr %v0, { i64, ptr } %t156, { i64, ptr } %t154, { i64, ptr } %t155)
  store %"compiler/diagmsg:Msg" %t159, ptr %l77
  br label %bb29
bb29:
  %t160 = load ptr, ptr %l63, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l65
  %t162 = load %"compiler/diagmsg:Msg", ptr %l77
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t160, %"compiler/source:Span" %t161, %"compiler/diagmsg:Msg" %t162)
  store i64 %t163, ptr %l78
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb31:
  %t164 = load i64, ptr %l9, !tbaa !24
  %t165 = load i32, ptr %l12, !tbaa !23
  %t168 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t164
  store i32 %t165, ptr %t170, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t171 = load i64, ptr %l7, !tbaa !24
  %t174 = add i64 %t171, 1
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb9
bb33:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSettleRaised(ptr %v0, ptr %s0, ptr %t179, i32 %a1, { i64, ptr } %t181)
  br label %bb34
bb34:
  %t185 = load ptr, ptr %lp4
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t186, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:Ask"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/check:AssertAsk"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/check:fixedProof"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca %"compiler/check:Ask"
  %l54 = alloca i1
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l100 = alloca %"compiler/check:AssertAsk"
  %l104 = alloca i1
  %l109 = alloca %"compiler/check:AssertAsk"
  %l125 = alloca i64
  %l127 = alloca i64
  %l132 = alloca %"compiler/check:fixedProof"
  %l136 = alloca i1
  %t156 = alloca %"compiler/check:AssertAsk", align 8
  %t177 = alloca %"compiler/check:AssertAsk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 123
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l29, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l29, !tbaa !24
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l26, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 123
  %t59 = call %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t51)
  store %"compiler/check:Ask" %t59, ptr %l50
  br label %bb12
bb12:
  %t60 = load %"compiler/check:Ask", ptr %l50
  store %"compiler/check:Ask" %t60, ptr %l8
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 4
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 5
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t61, i64 %t63, { i64, ptr } %t65)
  store i1 %t69, ptr %l54
  br label %bb13
bb13:
  %t70 = load i1, ptr %l54, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v0, ptr %t71, ptr %t73)
  br label %bb16
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 123
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load %"compiler/check:Ask", ptr %l8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79, %"compiler/check:Ask" %t80)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l1, !tbaa !24
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 123
  %t97 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t96, i64 %t97)
  br label %bb21
bb21:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 125
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t102)
  store i64 %t104, ptr %l72
  br label %bb22
bb22:
  %t105 = load i64, ptr %l72, !tbaa !24
  store i64 %t105, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = icmp sgt i64 %t106, %t107
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t112 = load i64, ptr %l11, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb28
bb25:
  %t116 = load i64, ptr %l10, !tbaa !24
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = sub i64 %t116, %t117
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t126 = sub i64 %t124, 1
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = sdiv i64 %t126, %t127
  store i64 %t130, ptr %l79, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb27
bb27:
  %t132 = load i64, ptr %l79, !tbaa !24
  store i64 %t132, ptr %l76, !tbaa !24
  br label %bb28
bb28:
  %t133 = load i64, ptr %l76, !tbaa !24
  store i64 %t133, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t144 = load i64, ptr %l11, !tbaa !24
  %t147 = mul i64 %t143, %t144
  %t150 = add i64 %t142, %t147
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %t156, ptr %v0, ptr %v0, ptr %t154, i64 %t150)
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t156, i64 184, i1 false)
  br label %bb33
bb33:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l100, i64 184, i1 false)
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  %t162 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 10
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t159, i64 %t161, { i64, ptr } %t163)
  store i1 %t167, ptr %l104
  br label %bb34
bb34:
  %t168 = load i1, ptr %l104, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb35, label %bb36
bb35:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 125
  %t174 = load i64, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %l15, i64 184, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t177, ptr %l109, i64 184, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eSetA_H2f2d9e3b51ec05f25dc2320ca6b31566(ptr %v0, ptr %v0, ptr %t173, i64 %t174, ptr %t177)
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l1, !tbaa !24
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t183 = load i64, ptr %l13, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 125
  %t191 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eTrun_Heefffe1e944651b1941f34d83e014b00(ptr %v0, ptr %t190, i64 %t191)
  br label %bb41
bb41:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/load:Loader", ptr %t200, i32 0, i32 4
  %t203 = load ptr, ptr %t202, !tbaa !29
  store ptr %t203, ptr %l16, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 45
  store ptr %t207, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb42
bb42:
  %t209 = load i64, ptr %l18, !tbaa !24
  store i64 %t209, ptr %l125, !tbaa !24
  %t210 = load ptr, ptr %l17, !tbaa !29
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afixedProof_3e_2eLen_He15a40c7f29502b6f30dac9a9c5a943c(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l127
  br label %bb43
bb43:
  %t213 = load i64, ptr %l125, !tbaa !24
  %t214 = load i64, ptr %l127, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb44, label %bb45
bb44:
  br label %bb55
bb45:
  br label %bb46
bb46:
  %t219 = load ptr, ptr %l17, !tbaa !29
  %t220 = load i64, ptr %l18, !tbaa !24
  %t223 = call %"compiler/check:fixedProof" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afixedProof_3e_2eAt__Hbf13be1060118ce2e34b50179c0ccd6f(ptr %v0, ptr %v0, ptr %t219, i64 %t220)
  store %"compiler/check:fixedProof" %t223, ptr %l132
  br label %bb47
bb47:
  %t224 = load %"compiler/check:fixedProof", ptr %l132
  store %"compiler/check:fixedProof" %t224, ptr %l19
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:fixedProof", ptr %l19, i32 0, i32 0
  %t227 = load i64, ptr %t226, !tbaa !24
  %t228 = getelementptr %"compiler/check:fixedProof", ptr %l19, i32 0, i32 1
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  %t233 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t225, i64 %t227, { i64, ptr } %t229)
  store i1 %t233, ptr %l136
  br label %bb48
bb48:
  %t234 = load i1, ptr %l136, !tbaa !21
  br i1 %t234, label %bb49, label %bb50
bb49:
  %t235 = load ptr, ptr %l16, !tbaa !29
  %t236 = getelementptr %"compiler/check:fixedProof", ptr %l19, i32 0, i32 2
  %t237 = load i64, ptr %t236, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t235, i64 %t237)
  br label %bb51
bb50:
  %t240 = load ptr, ptr %l16, !tbaa !29
  %t241 = getelementptr %"compiler/check:fixedProof", ptr %l19, i32 0, i32 2
  %t242 = load i64, ptr %t241, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t240, i64 %t242)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t245 = load i64, ptr %l18, !tbaa !24
  %t248 = add i64 %t245, 1
  store i64 %t248, ptr %l18, !tbaa !24
  br label %bb42
bb55:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l28 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %l71 = alloca ptr
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca i64
  %l108 = alloca %"compiler/check:nullNarrow"
  %l110 = alloca %"compiler/check:nullNarrow"
  %l115 = alloca i64
  %l117 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i64
  %l134 = alloca %"compiler/check:narrowed"
  %l136 = alloca %"compiler/check:narrowed"
  %l144 = alloca ptr
  %l145 = alloca i64
  %l152 = alloca { i64, ptr }
  %l153 = alloca i64
  %l158 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l168 = alloca i64
  %l173 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l28
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l28, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 56
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 57
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l41, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l41, !tbaa !24
  store i64 %t51, ptr %l38, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l38, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 56
  store { i64, ptr } %t72, ptr %t75, !tbaa !27
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  %t82 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 57
  store i64 %t79, ptr %t82, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t84, ptr %l65, !tbaa !27
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t93 = call { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigning(ptr %v0, ptr %v1, ptr %s3, ptr %t83, ptr %t90)
  store { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t93, ptr %l68
  br label %bb15
bb15:
  %t94 = load { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %l68
  store { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t94, ptr %l11
  %t95 = getelementptr { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %l11, i32 0, i32 0
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l12
  %t98 = getelementptr { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %l11, i32 0, i32 1
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l13
  %t101 = load ptr, ptr %l2, !tbaa !29
  store ptr %t101, ptr %l71, !tbaa !29
  %t102 = call ptr @__olang_scope_hold(ptr %v0)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l72, !tbaa !24
  %t104 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e48
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = call ptr @__olang_region_make(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l72, !tbaa !24
  br label %bb17
bb17:
  %t108 = icmp sge i64 0, 0
  br i1 %t108, label %bb18, label %bb19
bb18:
  %t110 = icmp sle i64 0, 2305843009213693951
  br i1 %t110, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb20:
  %t112 = mul i64 0, 4
  %t113 = load i64, ptr %l72
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = insertvalue { i64, ptr } undef, i64 0, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t117 = load ptr, ptr %l71, !tbaa !29
  %t118 = getelementptr %"compiler/check:frame", ptr %t117, i32 0, i32 48
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l77, !tbaa !27
  %t121 = load ptr, ptr %l71, !tbaa !29
  %t122 = getelementptr %"compiler/check:frame", ptr %t121, i32 0, i32 48
  store { i64, ptr } %t116, ptr %t122, !tbaa !27
  %t123 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e48
  br i1 %t123, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb22:
  %t125 = load { i64, ptr }, ptr %l77
  %t126 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release(ptr %t126)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb23
bb23:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 49
  store i1 false, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t131, ptr %l81, !tbaa !27
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 %t132
  %t137 = load ptr, ptr %t136, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t130, ptr %t137)
  br label %bb24
bb24:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 49
  %t144 = load i1, ptr %t143, !tbaa !21
  br i1 %t144, label %bb25, label %bb26
bb25:
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 49
  store i1 false, ptr %t148, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb26:
  br label %bb27
bb27:
  store ptr %l12, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb28
bb28:
  %t150 = load i64, ptr %l15, !tbaa !24
  store i64 %t150, ptr %l89, !tbaa !24
  %t151 = load ptr, ptr %l14, !tbaa !29
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t151)
  store i64 %t153, ptr %l91
  br label %bb29
bb29:
  %t154 = load i64, ptr %l89, !tbaa !24
  %t155 = load i64, ptr %l91, !tbaa !24
  %t156 = icmp slt i64 %t154, %t155
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb30, label %bb31
bb30:
  br label %bb42
bb31:
  br label %bb32
bb32:
  %t160 = load ptr, ptr %l14, !tbaa !29
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l96
  br label %bb33
bb33:
  %t165 = load i64, ptr %l96, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  store i64 %t166, ptr %l97, !tbaa !24
  %t167 = load ptr, ptr %l2, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 50
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l100
  br label %bb34
bb34:
  %t172 = load i64, ptr %l97, !tbaa !24
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  br i1 %t174, label %bb35, label %bb36
bb35:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr %"compiler/check:frame", ptr %t176, i32 0, i32 50
  store ptr %t178, ptr %l103, !tbaa !29
  %t179 = load i64, ptr %l16, !tbaa !24
  store i64 %t179, ptr %l104, !tbaa !24
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = getelementptr %"compiler/check:frame", ptr %t180, i32 0, i32 50
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t182, i64 %t183)
  store %"compiler/check:nullNarrow" %t186, ptr %l108
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t187 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyAssigned, !tbaa !24
  %t188 = load %"compiler/check:nullNarrow", ptr %l108
  %t190 = call %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:nullNarrow" %t188, i64 %t187)
  store %"compiler/check:nullNarrow" %t190, ptr %l110
  br label %bb38
bb38:
  %t191 = load ptr, ptr %l103, !tbaa !29
  %t192 = load i64, ptr %l104, !tbaa !24
  %t193 = load %"compiler/check:nullNarrow", ptr %l110
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t191, i64 %t192, %"compiler/check:nullNarrow" %t193)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t194 = load i64, ptr %l15, !tbaa !24
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %l15, !tbaa !24
  br label %bb28
bb42:
  store ptr %l13, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb43
bb43:
  %t200 = load i64, ptr %l18, !tbaa !24
  store i64 %t200, ptr %l115, !tbaa !24
  %t201 = load ptr, ptr %l17, !tbaa !29
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t201)
  store i64 %t203, ptr %l117
  br label %bb44
bb44:
  %t204 = load i64, ptr %l115, !tbaa !24
  %t205 = load i64, ptr %l117, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb45, label %bb46
bb45:
  br label %bb57
bb46:
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l17, !tbaa !29
  %t211 = load i64, ptr %l18, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l122
  br label %bb48
bb48:
  %t215 = load i64, ptr %l122, !tbaa !24
  store i64 %t215, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l19, !tbaa !24
  store i64 %t216, ptr %l123, !tbaa !24
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 46
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t219)
  store i64 %t221, ptr %l126
  br label %bb49
bb49:
  %t222 = load i64, ptr %l123, !tbaa !24
  %t223 = load i64, ptr %l126, !tbaa !24
  %t224 = icmp slt i64 %t222, %t223
  br i1 %t224, label %bb50, label %bb51
bb50:
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = getelementptr %"compiler/check:frame", ptr %t226, i32 0, i32 46
  store ptr %t228, ptr %l129, !tbaa !29
  %t229 = load i64, ptr %l19, !tbaa !24
  store i64 %t229, ptr %l130, !tbaa !24
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t232 = getelementptr %"compiler/check:frame", ptr %t230, i32 0, i32 46
  %t233 = load i64, ptr %l19, !tbaa !24
  %t236 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t232, i64 %t233)
  store %"compiler/check:narrowed" %t236, ptr %l134
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t237 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyAssigned, !tbaa !24
  %t238 = load %"compiler/check:narrowed", ptr %l134
  %t240 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v0, %"compiler/check:narrowed" %t238, i64 %t237)
  store %"compiler/check:narrowed" %t240, ptr %l136
  br label %bb53
bb53:
  %t241 = load ptr, ptr %l129, !tbaa !29
  %t242 = load i64, ptr %l130, !tbaa !24
  %t243 = load %"compiler/check:narrowed", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v0, ptr %t241, i64 %t242, %"compiler/check:narrowed" %t243)
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t244 = load i64, ptr %l18, !tbaa !24
  %t247 = add i64 %t244, 1
  store i64 %t247, ptr %l18, !tbaa !24
  br label %bb43
bb57:
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t251 = getelementptr %"compiler/check:frame", ptr %t249, i32 0, i32 48
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb58, label %bb59
bb58:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l144, !tbaa !29
  %t259 = call ptr @__olang_scope_hold(ptr %v0)
  %t260 = ptrtoint ptr %t259 to i64
  store i64 %t260, ptr %l145, !tbaa !24
  %t261 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3anullNarrow_2e0
  br i1 %t261, label %bb60, label %bb61
bb59:
  br label %bb77
bb60:
  %t263 = call ptr @__olang_region_make(ptr %v0)
  %t264 = ptrtoint ptr %t263 to i64
  store i64 %t264, ptr %l145, !tbaa !24
  br label %bb61
bb61:
  %t265 = load ptr, ptr %l2, !tbaa !29
  %t267 = getelementptr %"compiler/check:frame", ptr %t265, i32 0, i32 48
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  store i64 %t272, ptr %l22, !tbaa !24
  %t274 = load i64, ptr %l22, !tbaa !24
  %t276 = mul i64 %t274, 4
  %t277 = load i64, ptr %l145
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = call ptr @__olang_held_alloc(ptr %t278, i64 %t276)
  %t280 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  store { i64, ptr } %t281, ptr %l152, !tbaa !27
  store i64 0, ptr %l153, !tbaa !24
  br label %bb62
bb62:
  %t282 = load i64, ptr %l21, !tbaa !24
  %t283 = load i64, ptr %l22, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t290 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t290, ptr %l158, !tbaa !27
  %t291 = load i64, ptr %l21, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr i32, ptr %t294, i64 %t291
  %t296 = load i32, ptr %t295, !tbaa !33
  %t300 = load i64, ptr %l153, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i32, ptr %t302, i64 %t300
  store i32 %t296, ptr %t303, !tbaa !33
  %t304 = load i64, ptr %l153, !tbaa !24
  %t305 = add i64 %t304, 1
  store i64 %t305, ptr %l153, !tbaa !24
  br label %bb66
bb66:
  %t306 = load i64, ptr %l21, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l21, !tbaa !24
  br label %bb62
bb67:
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t313 = getelementptr %"compiler/check:frame", ptr %t311, i32 0, i32 7
  %t314 = load i64, ptr %t313, !tbaa !24
  %t315 = load ptr, ptr %l144, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l152, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNull(ptr %v0, ptr %v0, ptr %t315, { i64, ptr } %t316, i64 %t314)
  br label %bb68
bb68:
  %t318 = load ptr, ptr %l2, !tbaa !29
  store ptr %t318, ptr %l167, !tbaa !29
  %t319 = call ptr @__olang_scope_hold(ptr %v0)
  %t320 = ptrtoint ptr %t319 to i64
  store i64 %t320, ptr %l168, !tbaa !24
  %t321 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e48
  br i1 %t321, label %bb69, label %bb70
bb69:
  %t323 = call ptr @__olang_region_make(ptr %v0)
  %t324 = ptrtoint ptr %t323 to i64
  store i64 %t324, ptr %l168, !tbaa !24
  br label %bb70
bb70:
  %t325 = icmp sge i64 0, 0
  br i1 %t325, label %bb71, label %bb72
bb71:
  %t327 = icmp sle i64 0, 2305843009213693951
  br i1 %t327, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb73:
  %t329 = mul i64 0, 4
  %t330 = load i64, ptr %l168
  %t331 = inttoptr i64 %t330 to ptr
  %t332 = insertvalue { i64, ptr } undef, i64 0, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t334 = load ptr, ptr %l167, !tbaa !29
  %t335 = getelementptr %"compiler/check:frame", ptr %t334, i32 0, i32 48
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l173, !tbaa !27
  %t338 = load ptr, ptr %l167, !tbaa !29
  %t339 = getelementptr %"compiler/check:frame", ptr %t338, i32 0, i32 48
  store { i64, ptr } %t333, ptr %t339, !tbaa !27
  %t340 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e48
  br i1 %t340, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb75:
  %t342 = load { i64, ptr }, ptr %l173
  %t343 = extractvalue { i64, ptr } %t342, 1
  call void @__olang_region_release(ptr %t343)
  store { i64, ptr } zeroinitializer, ptr %l173
  br label %bb76
bb76:
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb78:
  %t344 = load i64, ptr %l9, !tbaa !24
  %t347 = add i64 %t344, 1
  store i64 %t347, ptr %l9, !tbaa !24
  br label %bb11
bb79:
  %t349 = load ptr, ptr %l2, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t353 = getelementptr %"compiler/check:frame", ptr %t349, i32 0, i32 56
  store { i64, ptr } %t350, ptr %t353, !tbaa !27
  %t354 = load ptr, ptr %l2, !tbaa !29
  %t355 = load i64, ptr %l4, !tbaa !24
  %t358 = getelementptr %"compiler/check:frame", ptr %t354, i32 0, i32 57
  store i64 %t355, ptr %t358, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructPatOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l44 = alloca i32
  %l48 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i1
  %rv = alloca i1
  %t68 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l18
  br label %bb4
bb4:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t22 = icmp ne i32 %t20, %a2
  store i1 %t22, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 28}
  %t33 = icmp eq i64 %t31, 11
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l4
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t49, i32 0, i32 2
  %t51 = load { i64, ptr }, ptr %t50
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %v0, ptr %t53)
  store { i64, ptr } %t55, ptr %l33
  br label %bb14
bb14:
  %t56 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t56, ptr %l7, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t61 = icmp eq i64 %t59, 0
  br i1 %t61, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l4
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t65, 0
  %t73 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t71, { i64, ptr } %t66, 1
  %t75 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t73, { i64, ptr } %t67, 2
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t75, ptr %t76
  %t77 = load { i64, [5 x i64] }, ptr %t68
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t77, ptr %t79
  %t82 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v0, ptr %t64, ptr %t79)
  store i32 %t82, ptr %l44
  br label %bb18
bb18:
  %t83 = load i32, ptr %l44, !tbaa !23
  store i32 %t83, ptr %l8, !tbaa !23
  %t84 = load i32, ptr %l8, !tbaa !23
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t88 = icmp eq i32 %t84, %t85
  br i1 %t88, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb24
bb20:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l51, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l8, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l56
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l61
  br label %bb22
bb22:
  %t116 = load ptr, ptr %l51, !tbaa !29
  %t117 = load i32, ptr %l56, !tbaa !23
  %t118 = load i32, ptr %l61, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t116, i32 %t117, i32 %t118)
  store i1 %t119, ptr %l62
  br label %bb23
bb23:
  %t120 = load i1, ptr %l62, !tbaa !21
  store i1 %t120, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t121 = load i1, ptr %l48, !tbaa !21
  store i1 %t121, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 true, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_43a48225da0bb134_ea32de8827419df8)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, i32 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i32
  %l68 = alloca i1
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l91 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l116 = alloca i64
  %l119 = alloca i64
  %l137 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca { i64, ptr }
  %l144 = alloca %"compiler/source:Span"
  %l148 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l170 = alloca i32
  %l173 = alloca ptr
  %l174 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t169 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l6, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i32, ptr %l24, !tbaa !23
  store i32 %t6, ptr %l9, !tbaa !23
  %t7 = load i32, ptr %l9, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t13, %"compiler/source:Span" %t14, i32 %t15, i64 0)
  store ptr %t19, ptr %l31
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load ptr, ptr %l31, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l9, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructPatOf(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i32 %a3, i32 %t24)
  store i1 %t29, ptr %l36
  br label %bb6
bb6:
  %t30 = load i1, ptr %l36, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l38, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t34)
  store %"compiler/source:Span" %t36, ptr %l40
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l9, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l43
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t42, ptr %l44, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l45, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t44)
  store %"compiler/source:Span" %t46, ptr %l47
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l45, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l47
  %t49 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t49, ptr %l48
  br label %bb12
bb12:
  %t50 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s2, { i64, ptr } %t50)
  store { i64, ptr } %t51, ptr %l49
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t55 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatType(ptr %s2, ptr %s2, ptr %v0, { i64, ptr } %t53, { i64, ptr } %t52)
  store %"compiler/diagmsg:Msg" %t55, ptr %l51
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l38, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l40
  %t58 = load %"compiler/diagmsg:Msg", ptr %l51
  %t59 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t56, %"compiler/source:Span" %t57, %"compiler/diagmsg:Msg" %t58)
  store i64 %t59, ptr %l52
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t60, %"compiler/source:Span" %t61, i32 %t62, i64 0)
  store ptr %t66, ptr %l56
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load ptr, ptr %l56, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l9, !tbaa !23
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %s0, ptr %t68, i32 %t69)
  store ptr %t72, ptr %l59
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l59, !tbaa !29
  store ptr %t73, ptr %l10, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  %t77 = load ptr, ptr %l10, !tbaa !29
  %t82 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v2, ptr %s0, ptr %v5, ptr %t74, %"compiler/source:Span" %t75, { i64, ptr } %a4, ptr %t77, i1 true)
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l66
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb20, label %ok.86, !prof !99
ok.86:
  store { i64, ptr } %t83, ptr %l65
  br label %bb19
bb19:
  %t87 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t87, ptr %l60, !tbaa !27
  br label %bb23
bb20:
  %t88 = load i32, ptr %l66, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  store i1 %t91, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l1
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t92, %"compiler/source:Span" %t93, i32 %t94, i64 0)
  store ptr %t98, ptr %l72
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load ptr, ptr %l72, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
bb23:
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t100, ptr %l11, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t101, %"compiler/source:Span" %t102, i32 %t103, i64 1)
  store ptr %t107, ptr %l76
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l76, !tbaa !29
  store ptr %t108, ptr %l12, !tbaa !29
  %t109 = load ptr, ptr %l5, !tbaa !29
  store ptr %t109, ptr %l13, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l80
  br label %bb25
bb25:
  %t116 = load i1, ptr %l80, !tbaa !21
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l6, !tbaa !23
  %t126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t122, i32 %t123)
  store i1 %t126, ptr %l85
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t127 = load i1, ptr %l85, !tbaa !21
  br i1 %t127, label %bb29, label %bb30
bb29:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l86, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l87
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l88, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t131, ptr %l89
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t132, ptr %l90, !tbaa !23
  store i32 19, ptr %l91
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l1
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t133, %"compiler/source:Span" %t134, ptr %t135)
  store ptr %t139, ptr %l95
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l1
  %t142 = load i32, ptr %l6, !tbaa !23
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t140, %"compiler/source:Span" %t141, i32 %t142)
  store ptr %t146, ptr %l99
  br label %bb32
bb32:
  %t147 = load ptr, ptr %l99, !tbaa !29
  %t148 = load ptr, ptr %l88, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l89
  %t150 = load i32, ptr %l90, !tbaa !23
  %t151 = load i32, ptr %l91, !range !{i32 0, i32 54}
  %t152 = load ptr, ptr %l95, !tbaa !29
  %t154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t148, %"compiler/source:Span" %t149, i32 %t150, i32 %t151, ptr %t152, ptr %t147)
  store ptr %t154, ptr %l101
  br label %bb33
bb33:
  %t155 = load ptr, ptr %l86, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l87
  %t157 = load ptr, ptr %l101, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v0, ptr %v5, ptr %t155, %"compiler/source:Span" %t156, ptr %t157)
  store ptr %t158, ptr %l102
  br label %bb34
bb34:
  %t159 = load ptr, ptr %l102, !tbaa !29
  store ptr %t159, ptr %l12, !tbaa !29
  br label %bb35
bb35:
  %t160 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t160, ptr %l103
  %t161 = load i32, ptr %l9, !tbaa !23
  store i32 %t161, ptr %l104, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v5, ptr %t162, %"compiler/source:Span" %t163, ptr %t164)
  store ptr %t168, ptr %l108
  br label %bb36
bb36:
  store { i64, [4 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 0
  store i64 2, ptr %t170
  %t171 = load %"compiler/source:Span", ptr %l103
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t171, 0
  %t173 = load i32, ptr %l104, !tbaa !23
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } %t172, i32 %t173, 1
  %t175 = load ptr, ptr %l108, !tbaa !29
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, ptr %t175, 2
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t176, ptr %t177
  %t178 = load { i64, [4 x i64] }, ptr %t169
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store { i64, [4 x i64] } %t178, ptr %t180
  store ptr %t180, ptr %l13, !tbaa !29
  br label %bb37
bb37:
  store i64 0, ptr %l14, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb38, label %bb39
bb38:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb43
bb40:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i64, ptr %l14, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l119, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb42
bb42:
  %t212 = load i64, ptr %l119, !tbaa !24
  store i64 %t212, ptr %l116, !tbaa !24
  br label %bb43
bb43:
  %t213 = load i64, ptr %l116, !tbaa !24
  store i64 %t213, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb45, label %bb46
bb45:
  br label %bb62
bb46:
  br label %bb47
bb47:
  %t222 = load i64, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l18, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l19, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t232, ptr %l137, !tbaa !27
  %t233 = load i64, ptr %l19, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr ptr, ptr %t236, i64 %t233
  %t238 = load ptr, ptr %t237, !tbaa !39
  %t240 = call i1 @compiler_2fcheck_2eisWild(ptr %v5, ptr %t238)
  store i1 %t240, ptr %l140
  br label %bb48
bb48:
  %t241 = load i1, ptr %l140, !tbaa !21
  br i1 %t241, label %bb49, label %bb50
bb49:
  br label %bb61
bb50:
  br label %bb51
bb51:
  %t242 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t242, ptr %l141, !tbaa !27
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t250 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v5, ptr %t248)
  store %"compiler/source:Span" %t250, ptr %l144
  br label %bb52
bb52:
  %t251 = load %"compiler/source:Span", ptr %l144
  store %"compiler/source:Span" %t251, ptr %l20
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l20
  %t254 = load %"compiler/source:Span", ptr %l20
  %t255 = load ptr, ptr %l13, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l10, !tbaa !29
  %t258 = getelementptr %"compiler/check:fieldSet", ptr %t256, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l150, !tbaa !27
  %t260 = load i64, ptr %l19, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  %t266 = load ptr, ptr %l148, !tbaa !29
  %t267 = call ptr @__olang_scope_of(ptr %t266, ptr null)
  %t268 = call ptr @__olang_scope_hold(ptr %t267)
  %t269 = ptrtoint ptr %t268 to i64
  %t271 = inttoptr i64 %t269 to ptr
  %t275 = load ptr, ptr %l148, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t271, ptr %v5, ptr %t252, %"compiler/source:Span" %t253, %"compiler/source:Span" %t254, ptr %t275, i32 %t265)
  store ptr %t277, ptr %l154
  br label %bb53
bb53:
  %t278 = load ptr, ptr %l154, !tbaa !29
  store ptr %t278, ptr %l21, !tbaa !29
  %t279 = load ptr, ptr %l21, !tbaa !29
  %t281 = icmp eq ptr %t279, null
  br i1 %t281, label %bb54, label %bb55
bb54:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l1
  %t285 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t283, %"compiler/source:Span" %t284, i32 %t285, i64 0)
  store ptr %t289, ptr %l160
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t290 = load ptr, ptr %l160, !tbaa !29
  store ptr %t290, ptr %rv
  br label %ret
bb57:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l161, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t292, ptr %l162
  %t293 = load ptr, ptr %l12, !tbaa !29
  store ptr %t293, ptr %l163, !tbaa !29
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l164, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t295, ptr %l165, !tbaa !27
  %t296 = load i64, ptr %l19, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr ptr, ptr %t299, i64 %t296
  %t301 = load ptr, ptr %t300, !tbaa !39
  store ptr %t301, ptr %l167, !tbaa !29
  %t302 = load ptr, ptr %l21, !tbaa !29
  store ptr %t302, ptr %l168, !tbaa !29
  %t303 = load ptr, ptr %l21, !tbaa !29
  %t305 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v5, ptr %t303)
  store i32 %t305, ptr %l170
  br label %bb58
bb58:
  %t308 = load ptr, ptr %l164, !tbaa !29
  %t309 = load ptr, ptr %l167, !tbaa !29
  %t310 = load ptr, ptr %l168, !tbaa !29
  %t311 = load i32, ptr %l170, !tbaa !23
  %t314 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v5, ptr %v5, ptr %v4, ptr %v5, ptr %t308, ptr %t309, ptr %t310, i32 %t311, ptr %a7, i64 %a8)
  store ptr %t314, ptr %l173
  br label %bb59
bb59:
  %t315 = load ptr, ptr %l161, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l162
  %t317 = load ptr, ptr %l163, !tbaa !29
  %t318 = load ptr, ptr %l173, !tbaa !29
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v5, ptr %v5, ptr %v5, ptr %t315, %"compiler/source:Span" %t316, ptr %t317, ptr %t318)
  store ptr %t319, ptr %l174
  br label %bb60
bb60:
  %t320 = load ptr, ptr %l174, !tbaa !29
  store ptr %t320, ptr %l12, !tbaa !29
  br label %bb61
bb61:
  %t321 = load i64, ptr %l18, !tbaa !24
  %t324 = add i64 %t321, 1
  store i64 %t324, ptr %l18, !tbaa !24
  br label %bb44
bb62:
  %t326 = load ptr, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t326, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextPlus(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextPieces(ptr %v0, ptr %v1, ptr %v3, ptr %t5, ptr %a2, ptr %t7)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextPieces(ptr %v0, ptr %v2, ptr %v3, ptr %t11, ptr %a3, ptr %t13)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v3, ptr %v3, ptr %t17, %"compiler/source:Span" %a1, ptr %t19)
  store ptr %t23, ptr %l16
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l16, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v1, ptr %v2, ptr %v5, ptr %t5, ptr %a2, ptr %a3, ptr %t8)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v3, ptr %v4, ptr %v5, ptr %t13, ptr %a4, ptr %a5, ptr %t16)
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v5, ptr %v5, ptr %t21, %"compiler/source:Span" %a1, ptr %t23)
  store ptr %t27, ptr %l20
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l20, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %lp16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/diagmsg:Msg"
  %l43 = alloca i64
  %l46 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca i32
  %l95 = alloca i1
  %l97 = alloca i1
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l111 = alloca i64
  %l116 = alloca i64
  %l125 = alloca i32
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l138 = alloca i1
  %l143 = alloca i1
  %l148 = alloca i32
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l174 = alloca ptr
  %l183 = alloca i1
  %l184 = alloca i1
  %l188 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca i32
  %l207 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l212 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t391 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 58
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  store i1 %t6, ptr %l5, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 58
  store i1 false, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l28
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l28, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 28
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l31
  br label %bb2
bb2:
  %t20 = load i64, ptr %l31, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load ptr, ptr %l6, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 16
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t27 = load ptr, ptr %l34, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load ptr, ptr %l34, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 28}
  %t33 = icmp eq i64 %t31, 2
  store i1 %t33, ptr %l35, !tbaa !21
  br label %bb4
bb4:
  %t34 = load i1, ptr %l35, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l9
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l40, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t42, ptr %l41
  %t43 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryParens(ptr %v0)
  store %"compiler/diagmsg:Msg" %t43, ptr %l42
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l40, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l41
  %t46 = load %"compiler/diagmsg:Msg", ptr %l42
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t44, %"compiler/source:Span" %t45, %"compiler/diagmsg:Msg" %t46)
  store i64 %t47, ptr %l43
  br label %bb9
bb9:
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fd60765d84d8653f_8f5cfc6948292c73)
  unreachable
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i64 %t52, ptr %l46
  br label %bb16
bb16:
  %t53 = load i64, ptr %l46, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t57)
  store %"compiler/source:Span" %t59, ptr %l50
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l51, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t61)
  store %"compiler/source:Span" %t63, ptr %l53
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l51, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l53
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store { i64, ptr } %t66, ptr %l54
  br label %bb21
bb21:
  %t67 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryOnCaught(ptr %v0, ptr %v0, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t68, ptr %l55
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l50
  %t71 = load %"compiler/diagmsg:Msg", ptr %l55
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t69, %"compiler/source:Span" %t70, %"compiler/diagmsg:Msg" %t71)
  store i64 %t72, ptr %l56
  br label %bb23
bb23:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l59
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load ptr, ptr %l59, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 151
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l62
  br label %bb26
bb26:
  %t84 = load i64, ptr %l62, !tbaa !24
  store i64 %t84, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l67
  br label %bb27
bb27:
  %t97 = load i64, ptr %l67, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %l68, !tbaa !29
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t100 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 15
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = add i64 %t101, 1
  %t106 = load ptr, ptr %l68, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 15
  store i64 %t104, ptr %t107, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = load i32, ptr %l4, !tbaa !23
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t108, ptr %t109, i32 %t111)
  store ptr %t115, ptr %l76
  br label %bb28
bb28:
  %t116 = load ptr, ptr %l76, !tbaa !29
  store ptr %t116, ptr %l12, !tbaa !29
  %t117 = load ptr, ptr %l6, !tbaa !29
  store ptr %t117, ptr %l77, !tbaa !29
  %t118 = load ptr, ptr %l77, !tbaa !29
  %t119 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 15
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = sub i64 %t120, 1
  %t125 = load ptr, ptr %l77, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t125, i32 0, i32 15
  store i64 %t123, ptr %t126, !tbaa !24
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 16
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t134 = icmp ne i64 %t130, %t131
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 16
  store i64 %t137, ptr %t140, !tbaa !24
  %t143 = xor i1 %t134, true
  br i1 %t143, label %bb29, label %bb30
bb29:
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t148 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t145)
  store i32 %t148, ptr %l92
  br label %bb31
bb30:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb32
bb31:
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t150 = load i32, ptr %l92, !tbaa !23
  %t152 = icmp ne i32 %t150, %t149
  store i1 %t152, ptr %l89, !tbaa !21
  br label %bb32
bb32:
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t155)
  store i1 %t157, ptr %l97
  br label %bb35
bb34:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb36
bb35:
  %t158 = load i1, ptr %l97, !tbaa !21
  %t159 = xor i1 %t158, true
  store i1 %t159, ptr %l95, !tbaa !21
  br label %bb36
bb36:
  %t161 = load i1, ptr %l95, !tbaa !21
  br i1 %t161, label %bb37, label %bb38
bb37:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %t162, %"compiler/source:Span" %t163)
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb40, label %bb41
bb40:
  %t172 = load ptr, ptr %l12, !tbaa !29
  store ptr %t172, ptr %l104, !tbaa !29
  br label %bb43
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l1
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t174, %"compiler/source:Span" %t175)
  store ptr %t178, ptr %l108
  br label %bb42
bb42:
  %t179 = load ptr, ptr %l108, !tbaa !29
  store ptr %t179, ptr %l104, !tbaa !29
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t180 = load ptr, ptr %l104, !tbaa !29
  store ptr %t180, ptr %rv
  br label %ret
bb44:
  %t181 = load ptr, ptr %l6, !tbaa !29
  %t183 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 28
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l111
  br label %bb45
bb45:
  %t186 = load i64, ptr %l111, !tbaa !24
  store i64 %t186, ptr %l14, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/load:Loader", ptr %t193, i32 0, i32 4
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l116
  br label %bb46
bb46:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t200 = load i64, ptr %l116, !tbaa !24
  %t202 = icmp eq i64 %t200, %t199
  br i1 %t202, label %bb47, label %bb48
bb47:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t206 = load i64, ptr %l7, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t204, { i64, ptr } %t205, i64 %t206, i64 %t207)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  %t212 = load ptr, ptr %l12, !tbaa !29
  %t215 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t212)
  store i32 %t215, ptr %l125
  br label %bb51
bb51:
  %t216 = load i32, ptr %l125, !tbaa !23
  store i32 %t216, ptr %l15, !tbaa !23
  %t217 = load i1, ptr %l5, !tbaa !21
  br i1 %t217, label %bb52, label %bb53
bb52:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l15, !tbaa !23
  %t223 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t219, i32 %t220)
  store i1 %t223, ptr %l130
  br label %bb54
bb53:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb55
bb54:
  %t224 = load i1, ptr %l130, !tbaa !21
  store i1 %t224, ptr %l127, !tbaa !21
  br label %bb55
bb55:
  %t225 = load i1, ptr %l127, !tbaa !21
  br i1 %t225, label %bb56, label %bb57
bb56:
  %t226 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t228 = call i1 @compiler_2fcheck_2enullDefault(ptr %v2, { i64, ptr } %t226)
  store i1 %t228, ptr %l133
  br label %bb58
bb57:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb59
bb58:
  %t229 = load i1, ptr %l133, !tbaa !21
  store i1 %t229, ptr %l131, !tbaa !21
  br label %bb59
bb59:
  %t230 = load i1, ptr %l131, !tbaa !21
  br i1 %t230, label %bb60, label %bb61
bb60:
  %t231 = load i32, ptr %l4, !tbaa !23
  %t232 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t235 = icmp eq i32 %t231, %t232
  br i1 %t235, label %bb62, label %bb63
bb61:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb66
bb62:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb65
bb63:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  %t243 = load i32, ptr %l4, !tbaa !23
  %t246 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t242, i32 %t243)
  store i1 %t246, ptr %l143
  br label %bb64
bb64:
  %t247 = load i1, ptr %l143, !tbaa !21
  store i1 %t247, ptr %l138, !tbaa !21
  br label %bb65
bb65:
  %t248 = load i1, ptr %l138, !tbaa !21
  store i1 %t248, ptr %l134, !tbaa !21
  br label %bb66
bb66:
  %t249 = load i1, ptr %l134, !tbaa !21
  br i1 %t249, label %bb67, label %bb68
bb67:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = load i32, ptr %l15, !tbaa !23
  %t259 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t255, i32 %t256)
  store i32 %t259, ptr %l148
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t260 = load i32, ptr %l148, !tbaa !23
  store i32 %t260, ptr %l15, !tbaa !23
  br label %bb70
bb70:
  %t261 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %l149
  br label %bb71
bb71:
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t262, ptr %lp16
  %t263 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  %t264 = load ptr, ptr %lp16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %t264
  %t265 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb72, label %bb73
bb72:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i64, ptr %l7, !tbaa !24
  %t273 = load i64, ptr %l14, !tbaa !24
  %t277 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v3, ptr %t271, i64 %t272, i64 %t273)
  store { i64, ptr } %t277, ptr %l156
  br label %bb74
bb73:
  br label %bb83
bb74:
  %t278 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t278, ptr %l17, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t279, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t281, 0
  store i64 %t283, ptr %l20, !tbaa !24
  br label %bb75
bb75:
  %t285 = load i64, ptr %l19, !tbaa !24
  %t286 = load i64, ptr %l20, !tbaa !24
  %t289 = icmp slt i64 %t285, %t286
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb76, label %bb77
bb76:
  br label %bb82
bb77:
  br label %bb78
bb78:
  %t293 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t293, ptr %l164, !tbaa !27
  %t294 = load i64, ptr %l19, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 %t294
  %t299 = load ptr, ptr %t298, !tbaa !39
  %t301 = load ptr, ptr %lp16
  store ptr %t301, ptr %l167, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l15, !tbaa !23
  %t305 = load i1, ptr %l5, !tbaa !21
  %t306 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t307 = load ptr, ptr %lp16
  %t314 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %v0, ptr %t302, ptr %t299, i32 %t304, i1 %t305, { i64, ptr } %t306, ptr %t307)
  store ptr %t314, ptr %l174
  br label %bb79
bb79:
  %t315 = load ptr, ptr %l167, !tbaa !29
  %t316 = load ptr, ptr %l174, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v3, ptr %v0, ptr %t315, ptr %t316)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = add i64 %t317, 1
  store i64 %t320, ptr %l19, !tbaa !24
  br label %bb75
bb82:
  br label %bb83
bb83:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t324 = load ptr, ptr %lp16
  %t325 = load i1, ptr %l5, !tbaa !21
  %t326 = load i32, ptr %l15, !tbaa !23
  %t332 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v2, ptr %v3, ptr %t322, { i64, ptr } %t323, ptr %t324, i1 %t325, i32 %t326)
  store i1 %t332, ptr %l183
  br label %bb84
bb84:
  %t333 = load i1, ptr %l183, !tbaa !21
  br i1 %t333, label %bb85, label %bb86
bb85:
  %t334 = load i1, ptr %l5, !tbaa !21
  store i1 %t334, ptr %l184, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb87
bb87:
  %t336 = load i1, ptr %l184, !tbaa !21
  br i1 %t336, label %bb88, label %bb89
bb88:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t337, %"compiler/source:Span" %t338)
  store ptr %t341, ptr %l188
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t342 = load ptr, ptr %l188, !tbaa !29
  store ptr %t342, ptr %rv
  br label %ret
bb91:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i64, ptr %l10, !tbaa !24
  %t345 = load ptr, ptr %lp16
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v3, ptr %t343, i64 %t344, ptr %t345)
  br label %bb92
bb92:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i64, ptr %l7, !tbaa !24
  %t351 = load i64, ptr %l14, !tbaa !24
  %t352 = load ptr, ptr %lp16
  %t357 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v3, ptr %t349, i64 %t350, i64 %t351, ptr %t352)
  store i64 %t357, ptr %l196
  br label %bb93
bb93:
  %t358 = load i64, ptr %l196, !tbaa !24
  store i64 %t358, ptr %l22, !tbaa !24
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l197, !tbaa !29
  %t360 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t361 = load i32, ptr %t360, !tbaa !23
  %t362 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = add i32 %t363, 3
  %t368 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t361, i32 %t365)
  store %"compiler/source:Span" %t368, ptr %l201
  br label %bb94
bb94:
  %t369 = load i64, ptr %l7, !tbaa !24
  %t370 = load i64, ptr %l22, !tbaa !24
  %t371 = load ptr, ptr %l197, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l201
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t371, %"compiler/source:Span" %t372, i64 %t369, i64 %t370)
  br label %bb95
bb95:
  %t375 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t375, ptr %l204
  %t376 = load i32, ptr %l15, !tbaa !23
  store i32 %t376, ptr %l205, !tbaa !23
  %t377 = load ptr, ptr %l12, !tbaa !29
  store ptr %t377, ptr %l207, !tbaa !29
  %t379 = load ptr, ptr %lp16
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v3, ptr %v3, ptr %t379)
  store { i64, ptr } %t381, ptr %l209
  br label %bb96
bb96:
  %t382 = load i64, ptr %l22, !tbaa !24
  %t384 = icmp sgt i64 %t382, 0
  %t385 = load ptr, ptr %l207, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t388 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %t385, { i64, ptr } %t386, i1 false, i1 false, i1 %t384)
  store %"compiler/typed:Try" %t388, ptr %l212
  br label %bb97
bb97:
  %t389 = load %"compiler/typed:Try", ptr %l212
  %t390 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Try" %t389, ptr %t390
  store { i64, [5 x i64] } zeroinitializer, ptr %t391
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t391, i32 0, i32 0
  store i64 14, ptr %t392
  %t393 = load %"compiler/source:Span", ptr %l204
  %t394 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t393, 0
  %t395 = load i32, ptr %l205, !tbaa !23
  %t396 = insertvalue { %"compiler/source:Span", i32, ptr } %t394, i32 %t395, 1
  %t398 = insertvalue { %"compiler/source:Span", i32, ptr } %t396, ptr %t390, 2
  %t399 = getelementptr { i64, [5 x i64] }, ptr %t391, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t398, ptr %t399
  %t400 = load { i64, [5 x i64] }, ptr %t391
  %t402 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t400, ptr %t402
  call void @__olang_scope_close(ptr %s0)
  store ptr %t402, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l71 = alloca i32
  %l78 = alloca i32
  %l84 = alloca i1
  %l85 = alloca i32
  %l92 = alloca i32
  %l95 = alloca i1
  %l96 = alloca i1
  %l101 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l112 = alloca ptr
  %l117 = alloca i32
  %l119 = alloca i32
  %l123 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l131 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i32
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l163 = alloca i32
  %l164 = alloca i64
  %l165 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l173 = alloca i32
  %l174 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l180 = alloca i32
  %l181 = alloca i64
  %l182 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l186 = alloca i32
  %l187 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l190 = alloca i32
  %l191 = alloca i32
  %l195 = alloca ptr
  %l196 = alloca ptr
  %l202 = alloca i1
  %l207 = alloca i32
  %l209 = alloca i1
  %l212 = alloca ptr
  %l217 = alloca i32
  %l218 = alloca i32
  %l221 = alloca ptr
  %l224 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca i64
  %l243 = alloca ptr
  %l252 = alloca i32
  %l257 = alloca i32
  %l261 = alloca ptr
  %l266 = alloca i32
  %l267 = alloca { i64, ptr }
  %l273 = alloca i64
  %l276 = alloca i64
  %l295 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca i1
  %l300 = alloca i1
  %l303 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l310 = alloca i32
  %l311 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l329 = alloca %"compiler/source:Span"
  %l332 = alloca { i64, ptr }
  %l334 = alloca %"compiler/diagmsg:Msg"
  %l335 = alloca i64
  %l340 = alloca i64
  %l344 = alloca i64
  %l347 = alloca i1
  %l350 = alloca i1
  %l354 = alloca i1
  %l378 = alloca i64
  %l386 = alloca i64
  %l389 = alloca i1
  %l390 = alloca ptr
  %l394 = alloca ptr
  %l397 = alloca { i64, ptr }
  %l398 = alloca i1
  %l399 = alloca ptr
  %l400 = alloca %"compiler/source:Span"
  %l403 = alloca %"compiler/source:Span"
  %l406 = alloca i64
  %l410 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l416 = alloca { i64, ptr }
  %l420 = alloca ptr
  %l421 = alloca ptr
  %l422 = alloca ptr
  %l425 = alloca i32
  %l426 = alloca i32
  %l427 = alloca i64
  %l430 = alloca ptr
  %l433 = alloca %"compiler/source:Span"
  %l447 = alloca i64
  %l450 = alloca i64
  %l453 = alloca i1
  %l456 = alloca ptr
  %l459 = alloca ptr
  %l463 = alloca i32
  %l464 = alloca i32
  %l465 = alloca { i64, ptr }
  %l469 = alloca ptr
  %l470 = alloca ptr
  %l476 = alloca i1
  %l491 = alloca i1
  %l493 = alloca ptr
  %l496 = alloca %"compiler/source:Span"
  %l497 = alloca i32
  %l500 = alloca { i64, ptr }
  %l502 = alloca %"compiler/diagmsg:Msg"
  %l503 = alloca i64
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t252 = alloca { i64, [3 x i64] }, align 8
  %t291 = alloca { i64, [3 x i64] }, align 8
  %t339 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t7 = load ptr, ptr %l34, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l34, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 28}
  %t13 = icmp eq i64 %t11, 22
  store i1 %t13, ptr %l35, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l35, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l46
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l46, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68)
  unreachable
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l50
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l50, !tbaa !29
  store ptr %t43, ptr %l51, !tbaa !29
  %t44 = load ptr, ptr %l51, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = add i64 %t46, 1
  %t51 = load ptr, ptr %l51, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 15
  store i64 %t49, ptr %t52, !tbaa !24
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/ast:ForIn", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t53, ptr %t57, i32 %t59)
  store ptr %t63, ptr %l60
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l60, !tbaa !29
  store ptr %t64, ptr %l7, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:ForIn", ptr %t65, i32 0, i32 3
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l64
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t73 = load ptr, ptr %l64, !tbaa !29
  store ptr %t73, ptr %l65, !tbaa !29
  %t74 = load ptr, ptr %l65, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 15
  %t76 = load i64, ptr %t75, !tbaa !24
  %t79 = sub i64 %t76, 1
  %t81 = load ptr, ptr %l65, !tbaa !29
  %t82 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 15
  store i64 %t79, ptr %t82, !tbaa !24
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t83)
  store i32 %t86, ptr %l71
  br label %bb22
bb22:
  %t87 = load i32, ptr %l71, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load i32, ptr %l8, !tbaa !23
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = icmp eq i32 %t88, %t89
  br i1 %t92, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l8, !tbaa !23
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l78
  br label %bb26
bb26:
  %t100 = load i32, ptr %l78, !tbaa !23
  store i32 %t100, ptr %l9, !tbaa !23
  %t101 = load i32, ptr %l9, !tbaa !23
  %t102 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t105 = icmp ne i32 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l8, !tbaa !23
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l84
  br label %bb29
bb28:
  br label %bb89
bb29:
  %t112 = load i1, ptr %l84, !tbaa !21
  br i1 %t112, label %bb30, label %bb31
bb30:
  %t113 = load i32, ptr %l8, !tbaa !23
  store i32 %t113, ptr %l85, !tbaa !23
  br label %bb33
bb31:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l8, !tbaa !23
  %t122 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t120, i32 %t121, i64 %t122)
  store i32 %t126, ptr %l92
  br label %bb32
bb32:
  %t127 = load i32, ptr %l92, !tbaa !23
  store i32 %t127, ptr %l85, !tbaa !23
  br label %bb33
bb33:
  %t128 = load i32, ptr %l85, !tbaa !23
  store i32 %t128, ptr %l10, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l8, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l95
  br label %bb34
bb34:
  %t134 = load i1, ptr %l95, !tbaa !21
  br i1 %t134, label %bb35, label %bb36
bb35:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l8, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t140, i32 %t141)
  store i64 %t144, ptr %l101
  br label %bb37
bb36:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb38
bb37:
  %t145 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t146 = load i64, ptr %l101, !tbaa !24
  %t148 = and i64 %t146, %t145
  %t150 = icmp ne i64 %t148, 0
  store i1 %t150, ptr %l96, !tbaa !21
  br label %bb38
bb38:
  %t152 = load i1, ptr %l96, !tbaa !21
  br i1 %t152, label %bb39, label %bb40
bb39:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l7, !tbaa !29
  %t158 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t153, ptr %t154)
  store i1 %t158, ptr %l109
  br label %bb41
bb40:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb42
bb41:
  %t159 = load i1, ptr %l109, !tbaa !21
  store i1 %t159, ptr %l105, !tbaa !21
  br label %bb42
bb42:
  %t160 = load i1, ptr %l105, !tbaa !21
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  store ptr %t166, ptr %l112, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l8, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l117
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t177 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t178 = load ptr, ptr %l112, !tbaa !29
  %t179 = load i32, ptr %l117, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t178, i32 %t179, i64 %t177)
  store i32 %t181, ptr %l119
  br label %bb46
bb46:
  %t182 = load i32, ptr %l119, !tbaa !23
  store i32 %t182, ptr %l10, !tbaa !23
  br label %bb47
bb47:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l1
  %t185 = load i32, ptr %l10, !tbaa !23
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t183, %"compiler/source:Span" %t184, i32 %t185)
  store i64 %t189, ptr %l123
  br label %bb48
bb48:
  %t190 = load i64, ptr %l123, !tbaa !24
  store i64 %t190, ptr %l11, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 97
  store ptr %t193, ptr %l125, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i64, ptr %l11, !tbaa !24
  %t198 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t194, i64 %t195)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t198, ptr %l128
  br label %bb49
bb49:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l8, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t203, ptr %l131
  br label %bb50
bb50:
  %t204 = load i1, ptr %l131, !tbaa !21
  br i1 %t204, label %bb51, label %bb52
bb51:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t210 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t205, ptr %t206)
  store i1 %t210, ptr %l136
  br label %bb53
bb52:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l137, !tbaa !29
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t214 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t212)
  store ptr %t214, ptr %l139
  br label %bb54
bb53:
  %t215 = load i1, ptr %l136, !tbaa !21
  store i1 %t215, ptr %l132, !tbaa !21
  br label %bb56
bb54:
  %t216 = load ptr, ptr %l137, !tbaa !29
  %t217 = load ptr, ptr %l139, !tbaa !29
  %t218 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t216, ptr %t217)
  store i1 %t218, ptr %l140
  br label %bb55
bb55:
  %t219 = load i1, ptr %l140, !tbaa !21
  store i1 %t219, ptr %l132, !tbaa !21
  br label %bb56
bb56:
  %t220 = load ptr, ptr %l125, !tbaa !29
  %t221 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l128
  %t222 = load i1, ptr %l132, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t220, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t221, i1 %t222)
  br label %bb57
bb57:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l141, !tbaa !29
  %t224 = load ptr, ptr %l7, !tbaa !29
  store ptr %t224, ptr %l142, !tbaa !29
  %t225 = load i32, ptr %l10, !tbaa !23
  store i32 %t225, ptr %l143, !tbaa !23
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = getelementptr %"compiler/ast:ForIn", ptr %t226, i32 0, i32 2
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t229)
  store %"compiler/source:Span" %t231, ptr %l146
  br label %bb58
bb58:
  %t232 = load ptr, ptr %l141, !tbaa !29
  %t233 = load ptr, ptr %l142, !tbaa !29
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load %"compiler/source:Span", ptr %l146
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t232, ptr %t233, i32 %t234, %"compiler/source:Span" %t235)
  store ptr %t236, ptr %l147
  br label %bb59
bb59:
  %t237 = load ptr, ptr %l147, !tbaa !29
  store ptr %t237, ptr %l12, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t240 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t238, i64 %t239, ptr %t240)
  br label %bb60
bb60:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l1
  %t247 = load i64, ptr %l11, !tbaa !24
  %t249 = trunc i64 %t247 to i32
  %t251 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t252, i32 0, i32 0
  store i64 0, ptr %t253
  %t255 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t246, 0
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } %t255, i32 %t249, 1
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, ptr %t251, 2
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t252, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t259, ptr %t260
  %t261 = load { i64, [3 x i64] }, ptr %t252
  %t263 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t261, ptr %t263
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t245, ptr %t263)
  br label %bb61
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l160, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t267, ptr %l161
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t268)
  store i32 %t270, ptr %l163
  br label %bb62
bb62:
  %t271 = load ptr, ptr %l160, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l161
  %t273 = load i32, ptr %l163, !tbaa !23
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t271, %"compiler/source:Span" %t272, i32 %t273)
  store i64 %t274, ptr %l164
  br label %bb63
bb63:
  %t275 = load i64, ptr %l164, !tbaa !24
  store i64 %t275, ptr %l13, !tbaa !24
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l165, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t277, ptr %l166
  %t278 = load i64, ptr %l13, !tbaa !24
  %t280 = trunc i64 %t278 to i32
  store i32 %t280, ptr %l169, !tbaa !23
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l170, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t283, ptr %l171
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t284)
  store i32 %t286, ptr %l173
  br label %bb64
bb64:
  %t287 = load ptr, ptr %l170, !tbaa !29
  %t288 = load %"compiler/source:Span", ptr %l171
  %t289 = load i32, ptr %l173, !tbaa !23
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t287, %"compiler/source:Span" %t288, i32 %t289, i64 0)
  store ptr %t290, ptr %l174
  br label %bb65
bb65:
  store { i64, [3 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 0
  store i64 0, ptr %t292
  %t293 = load %"compiler/source:Span", ptr %l166
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t293, 0
  %t295 = load i32, ptr %l169, !tbaa !23
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } %t294, i32 %t295, 1
  %t297 = load ptr, ptr %l174, !tbaa !29
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr } %t296, ptr %t297, 2
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t298, ptr %t299
  %t300 = load { i64, [3 x i64] }, ptr %t291
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t300, ptr %t302
  %t303 = load ptr, ptr %l165, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t303, ptr %t302)
  br label %bb66
bb66:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l177, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t306, ptr %l178
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t307)
  store i32 %t309, ptr %l180
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l177, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l178
  %t312 = load i32, ptr %l180, !tbaa !23
  %t313 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t310, %"compiler/source:Span" %t311, i32 %t312)
  store i64 %t313, ptr %l181
  br label %bb68
bb68:
  %t314 = load i64, ptr %l181, !tbaa !24
  store i64 %t314, ptr %l14, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l182, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t316, ptr %l183
  %t317 = load i64, ptr %l14, !tbaa !24
  %t319 = trunc i64 %t317 to i32
  store i32 %t319, ptr %l186, !tbaa !23
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l187, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t322, ptr %l188
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t323)
  store i32 %t325, ptr %l190
  br label %bb69
bb69:
  store i32 22, ptr %l191
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load i64, ptr %l11, !tbaa !24
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t326, %"compiler/source:Span" %t327, i64 %t328)
  store ptr %t332, ptr %l195
  br label %bb70
bb70:
  %t333 = load ptr, ptr %l187, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l188
  %t335 = load i32, ptr %l190, !tbaa !23
  %t336 = load i32, ptr %l191, !range !{i32 0, i32 54}
  %t337 = load ptr, ptr %l195, !tbaa !29
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t333, %"compiler/source:Span" %t334, i32 %t335, i32 %t336, ptr %t337, ptr null)
  store ptr %t338, ptr %l196
  br label %bb71
bb71:
  store { i64, [3 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 0
  store i64 0, ptr %t340
  %t341 = load %"compiler/source:Span", ptr %l183
  %t342 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t341, 0
  %t343 = load i32, ptr %l186, !tbaa !23
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr } %t342, i32 %t343, 1
  %t345 = load ptr, ptr %l196, !tbaa !29
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } %t344, ptr %t345, 2
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t346, ptr %t347
  %t348 = load { i64, [3 x i64] }, ptr %t339
  %t350 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t348, ptr %t350
  %t351 = load ptr, ptr %l182, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t351, ptr %t350)
  br label %bb72
bb72:
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t355 = icmp eq ptr %t353, null
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb73, label %bb74
bb73:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/check:Checker", ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t364 = getelementptr %"compiler/generic:Program", ptr %t362, i32 0, i32 2
  %t365 = load i32, ptr %l9, !tbaa !23
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t364, i32 %t365)
  store i32 %t368, ptr %l207
  br label %bb75
bb74:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb76
bb75:
  %t369 = load i32, ptr %l207, !tbaa !23
  %t370 = icmp ne i32 %t369, 0
  store i1 %t370, ptr %l202, !tbaa !21
  br label %bb76
bb76:
  %t372 = load i1, ptr %l202, !tbaa !21
  br i1 %t372, label %bb77, label %bb78
bb77:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  store ptr %t378, ptr %l212, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/check:Checker", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t384 = getelementptr %"compiler/generic:Program", ptr %t382, i32 0, i32 2
  %t385 = load i32, ptr %l9, !tbaa !23
  %t388 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t384, i32 %t385)
  store i32 %t388, ptr %l217
  br label %bb79
bb78:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb81
bb79:
  %t389 = load ptr, ptr %l212, !tbaa !29
  %t390 = load i32, ptr %l217, !tbaa !23
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t389, i32 %t390)
  store i32 %t391, ptr %l218
  br label %bb80
bb80:
  %t392 = load i32, ptr %l218, !range !{i32 0, i32 33}
  %t394 = trunc i64 26 to i32
  %t395 = icmp eq i32 %t392, %t394
  store i1 %t395, ptr %l209, !tbaa !21
  br label %bb81
bb81:
  %t397 = load i1, ptr %l209, !tbaa !21
  br i1 %t397, label %bb82, label %bb83
bb82:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l221, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = getelementptr %"compiler/generic:Program", ptr %t402, i32 0, i32 2
  store ptr %t404, ptr %l224, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/generic:Program", ptr %t408, i32 0, i32 2
  %t411 = load i32, ptr %l9, !tbaa !23
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t410, i32 %t411)
  store i32 %t414, ptr %l229
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t415 = load ptr, ptr %l224, !tbaa !29
  %t416 = load i32, ptr %l229, !tbaa !23
  %t417 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t415, i32 %t416)
  store i64 %t417, ptr %l230
  br label %bb85
bb85:
  %t418 = load i64, ptr %l230, !tbaa !24
  %t419 = load ptr, ptr %l221, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t419, i32 0, i32 141
  store i64 %t418, ptr %t420, !tbaa !24
  br label %bb86
bb86:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l1
  %t423 = load ptr, ptr %l2, !tbaa !29
  %t424 = load i64, ptr %l13, !tbaa !24
  %t425 = load i64, ptr %l14, !tbaa !24
  %t426 = load i64, ptr %l11, !tbaa !24
  %t427 = load i32, ptr %l9, !tbaa !23
  %t428 = load ptr, ptr %l3, !tbaa !29
  %t429 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t421, %"compiler/source:Span" %t422, ptr %t423, i64 %t424, i64 %t425, i64 %t426, i32 %t427, i64 -1, i64 -1, ptr %t428, i32 %t429)
  br label %bb87
bb87:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load %"compiler/source:Span", ptr %l1
  %t441 = load i64, ptr %l14, !tbaa !24
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t439, %"compiler/source:Span" %t440, i64 %t441)
  store ptr %t445, ptr %l243
  br label %bb88
bb88:
  %t446 = load ptr, ptr %l243, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t446, ptr %rv
  br label %ret
bb89:
  %t448 = load ptr, ptr %l3, !tbaa !29
  %t450 = icmp eq ptr %t448, null
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb90, label %bb91
bb90:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t454, %"compiler/source:Span" %t455)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i32, ptr %l8, !tbaa !23
  %t462 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l252
  br label %bb94
bb94:
  %t463 = load i32, ptr %l252, !tbaa !23
  store i32 %t463, ptr %l15, !tbaa !23
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/check:Checker", ptr %t464, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t469 = getelementptr %"compiler/generic:Program", ptr %t467, i32 0, i32 2
  %t470 = load i32, ptr %l15, !tbaa !23
  %t473 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t469, i32 %t470)
  store i32 %t473, ptr %l257
  br label %bb95
bb95:
  %t474 = load i32, ptr %l257, !range !{i32 0, i32 33}
  %t476 = trunc i64 29 to i32
  %t477 = icmp eq i32 %t474, %t476
  br i1 %t477, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s10
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  store ptr %t482, ptr %l261, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/check:Checker", ptr %t483, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t488 = getelementptr %"compiler/generic:Program", ptr %t486, i32 0, i32 2
  %t489 = load i32, ptr %l15, !tbaa !23
  %t492 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t488, i32 %t489)
  store i32 %t492, ptr %l266
  br label %bb98
bb97:
  br label %bb127
bb98:
  %t493 = load ptr, ptr %l261, !tbaa !29
  %t494 = load i32, ptr %l266, !tbaa !23
  %t495 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t493, i32 %t494)
  store { i64, ptr } %t495, ptr %l267
  br label %bb99
bb99:
  %t496 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t496, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t497 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t497, 0
  store i64 %t499, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t501 = load i64, ptr %l18, !tbaa !24
  %t502 = load i64, ptr %l17, !tbaa !24
  %t505 = icmp sgt i64 %t501, %t502
  br i1 %t505, label %bb100, label %bb101
bb100:
  %t507 = load i64, ptr %l19, !tbaa !24
  %t509 = icmp sgt i64 %t507, 0
  br i1 %t509, label %bb102, label %bb103
bb101:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb105
bb102:
  %t511 = load i64, ptr %l18, !tbaa !24
  %t512 = load i64, ptr %l17, !tbaa !24
  %t515 = sub i64 %t511, %t512
  %t516 = load i64, ptr %l19, !tbaa !24
  %t519 = add i64 %t515, %t516
  %t521 = sub i64 %t519, 1
  %t522 = load i64, ptr %l19, !tbaa !24
  %t525 = sdiv i64 %t521, %t522
  store i64 %t525, ptr %l276, !tbaa !24
  br label %bb104
bb103:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb104
bb104:
  %t527 = load i64, ptr %l276, !tbaa !24
  store i64 %t527, ptr %l273, !tbaa !24
  br label %bb105
bb105:
  %t528 = load i64, ptr %l273, !tbaa !24
  store i64 %t528, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s12
  %t529 = load i64, ptr %l21, !tbaa !24
  %t530 = load i64, ptr %l20, !tbaa !24
  %t533 = icmp slt i64 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s12)
  br label %bb122
bb108:
  br label %bb109
bb109:
  %t537 = load i64, ptr %l17, !tbaa !24
  %t538 = load i64, ptr %l21, !tbaa !24
  %t539 = load i64, ptr %l19, !tbaa !24
  %t542 = mul i64 %t538, %t539
  %t545 = add i64 %t537, %t542
  store i64 %t545, ptr %l22, !tbaa !24
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t548, ptr %l295, !tbaa !27
  %t549 = load i64, ptr %l22, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr %"compiler/generic:AnySlot", ptr %t552, i64 %t549
  %t554 = getelementptr %"compiler/generic:AnySlot", ptr %t553, i32 0, i32 0
  %t555 = load i32, ptr %t554, !tbaa !23
  %t558 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t547, i32 %t555)
  store { i64, ptr } %t558, ptr %l298
  br label %bb110
bb110:
  %t559 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t560 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t559, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t560, ptr %l299
  br label %bb111
bb111:
  %t561 = load i1, ptr %l299, !tbaa !21
  br i1 %t561, label %bb112, label %bb113
bb112:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/check:Checker", ptr %t562, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !29
  %t567 = getelementptr %"compiler/generic:Program", ptr %t565, i32 0, i32 2
  store ptr %t567, ptr %l303, !tbaa !29
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/check:Checker", ptr %t568, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !29
  %t573 = getelementptr %"compiler/generic:Program", ptr %t571, i32 0, i32 2
  %t574 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t574, ptr %l307, !tbaa !27
  %t575 = load i64, ptr %l22, !tbaa !24
  %t577 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr %"compiler/generic:AnySlot", ptr %t578, i64 %t575
  %t580 = getelementptr %"compiler/generic:AnySlot", ptr %t579, i32 0, i32 5
  %t581 = load i32, ptr %t580, !tbaa !23
  %t584 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t573, i32 %t581)
  store i32 %t584, ptr %l310
  br label %bb114
bb113:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb116
bb114:
  %t585 = load ptr, ptr %l303, !tbaa !29
  %t586 = load i32, ptr %l310, !tbaa !23
  %t587 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s12, ptr %t585, i32 %t586)
  store { i64, ptr } %t587, ptr %l311
  br label %bb115
bb115:
  %t588 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 0
  %t591 = icmp eq i64 %t589, 1
  store i1 %t591, ptr %l300, !tbaa !21
  br label %bb116
bb116:
  %t593 = load i1, ptr %l300, !tbaa !21
  br i1 %t593, label %bb117, label %bb118
bb117:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l1
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t597 = load ptr, ptr %l7, !tbaa !29
  %t598 = load i64, ptr %l22, !tbaa !24
  %t600 = sub i64 -2, %t598
  %t601 = load ptr, ptr %l3, !tbaa !29
  %t602 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t594, %"compiler/source:Span" %t595, ptr %t596, ptr %t597, i64 %t600, ptr %t601, i32 %t602, i1 false)
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb120:
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb121:
  %t611 = load i64, ptr %l21, !tbaa !24
  %t614 = add i64 %t611, 1
  store i64 %t614, ptr %l21, !tbaa !24
  br label %bb106
bb122:
  %t616 = load ptr, ptr %l0, !tbaa !29
  store ptr %t616, ptr %l326, !tbaa !29
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:ForIn", ptr %t617, i32 0, i32 2
  %t620 = load ptr, ptr %t619, !tbaa !29
  %t622 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t620)
  store %"compiler/source:Span" %t622, ptr %l329
  br label %bb123
bb123:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load i32, ptr %l8, !tbaa !23
  %t627 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t623, i32 %t624)
  store { i64, ptr } %t627, ptr %l332
  br label %bb124
bb124:
  %t628 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t630 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s10, ptr %v0, { i64, ptr } %t628)
  store %"compiler/diagmsg:Msg" %t630, ptr %l334
  br label %bb125
bb125:
  %t631 = load ptr, ptr %l326, !tbaa !29
  %t632 = load %"compiler/source:Span", ptr %l329
  %t633 = load %"compiler/diagmsg:Msg", ptr %l334
  %t634 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t631, %"compiler/source:Span" %t632, %"compiler/diagmsg:Msg" %t633)
  store i64 %t634, ptr %l335
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb127:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load i32, ptr %l15, !tbaa !23
  %t638 = load %"compiler/source:Span", ptr %l1
  %t642 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t636, i32 %t637, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t638, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i64 %t642, ptr %l340
  br label %bb128
bb128:
  %t643 = load i64, ptr %l340, !tbaa !24
  store i64 %t643, ptr %l23, !tbaa !24
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load i32, ptr %l15, !tbaa !23
  %t646 = load %"compiler/source:Span", ptr %l1
  %t650 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t644, i32 %t645, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t646, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i64 %t650, ptr %l344
  br label %bb129
bb129:
  %t651 = load i64, ptr %l344, !tbaa !24
  store i64 %t651, ptr %l24, !tbaa !24
  %t652 = load i64, ptr %l24, !tbaa !24
  %t654 = icmp sge i64 %t652, 0
  br i1 %t654, label %bb130, label %bb131
bb130:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load i64, ptr %l24, !tbaa !24
  %t660 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t656, i64 %t657)
  store i1 %t660, ptr %l350
  br label %bb132
bb131:
  store i1 false, ptr %l347, !tbaa !21
  br label %bb133
bb132:
  %t661 = load i1, ptr %l350, !tbaa !21
  %t662 = xor i1 %t661, true
  store i1 %t662, ptr %l347, !tbaa !21
  br label %bb133
bb133:
  %t664 = load i1, ptr %l347, !tbaa !21
  br i1 %t664, label %bb134, label %bb135
bb134:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t665 = load i64, ptr %l23, !tbaa !24
  %t667 = icmp sge i64 %t665, 0
  br i1 %t667, label %bb137, label %bb138
bb137:
  %t669 = load i64, ptr %l24, !tbaa !24
  %t671 = icmp slt i64 %t669, 0
  store i1 %t671, ptr %l354, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l354, !tbaa !21
  br label %bb139
bb139:
  %t673 = load i1, ptr %l354, !tbaa !21
  br i1 %t673, label %bb140, label %bb141
bb140:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t675 = load %"compiler/source:Span", ptr %l1
  %t676 = load ptr, ptr %l2, !tbaa !29
  %t677 = load ptr, ptr %l7, !tbaa !29
  %t678 = load i64, ptr %l23, !tbaa !24
  %t679 = load ptr, ptr %l3, !tbaa !29
  %t680 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t674, %"compiler/source:Span" %t675, ptr %t676, ptr %t677, i64 %t678, ptr %t679, i32 %t680)
  br label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb143:
  %t689 = load i64, ptr %l24, !tbaa !24
  %t691 = icmp sge i64 %t689, 0
  br i1 %t691, label %bb144, label %bb145
bb144:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load %"compiler/source:Span", ptr %l1
  %t695 = load ptr, ptr %l2, !tbaa !29
  %t696 = load ptr, ptr %l7, !tbaa !29
  %t697 = load i64, ptr %l24, !tbaa !24
  %t698 = load ptr, ptr %l3, !tbaa !29
  %t699 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t693, %"compiler/source:Span" %t694, ptr %t695, ptr %t696, i64 %t697, ptr %t698, i32 %t699, i1 false)
  br label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb147:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = load i32, ptr %l15, !tbaa !23
  %t710 = load %"compiler/source:Span", ptr %l1
  %t714 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t708, i32 %t709, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d63, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t710, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i64 %t714, ptr %l378
  br label %bb148
bb148:
  %t715 = load i64, ptr %l378, !tbaa !24
  store i64 %t715, ptr %l25, !tbaa !24
  %t716 = load i64, ptr %l25, !tbaa !24
  %t718 = icmp sge i64 %t716, 0
  br i1 %t718, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s18
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t721 = load i32, ptr %l15, !tbaa !23
  %t722 = load ptr, ptr %l7, !tbaa !29
  %t723 = load i64, ptr %l25, !tbaa !24
  %t724 = load %"compiler/source:Span", ptr %l1
  %t730 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldWalk(ptr %v0, ptr %v0, ptr %t720, i32 %t721, ptr %t722, i64 %t723, %"compiler/source:Span" %t724)
  store i64 %t730, ptr %l386
  br label %bb151
bb150:
  br label %bb184
bb151:
  %t731 = load i64, ptr %l386, !tbaa !24
  store i64 %t731, ptr %l26, !tbaa !24
  %t732 = load i64, ptr %l26, !tbaa !24
  %t734 = icmp sge i64 %t732, 0
  br i1 %t734, label %bb152, label %bb153
bb152:
  %t736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t736, ptr %l390, !tbaa !29
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/check:Checker", ptr %t737, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !29
  %t741 = load i64, ptr %l26, !tbaa !24
  %t744 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s18, ptr %t740, i64 %t741)
  store ptr %t744, ptr %l394
  br label %bb154
bb153:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb157
bb154:
  %t745 = load ptr, ptr %l394, !tbaa !29
  %t747 = getelementptr %"compiler/ast:Func", ptr %t745, i32 0, i32 2
  %t748 = load i32, ptr %t747, !tbaa !23
  %t749 = load ptr, ptr %l390, !tbaa !29
  %t751 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t749, i32 %t748)
  store { i64, ptr } %t751, ptr %l397
  br label %bb155
bb155:
  %t752 = load { i64, ptr }, ptr %l397, !tbaa !27
  %t753 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s18, { i64, ptr } %t752, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t753, ptr %l398
  br label %bb156
bb156:
  %t754 = load i1, ptr %l398, !tbaa !21
  store i1 %t754, ptr %l389, !tbaa !21
  br label %bb157
bb157:
  %t755 = load i1, ptr %l389, !tbaa !21
  store i1 %t755, ptr %l27, !tbaa !21
  %t756 = load ptr, ptr %l0, !tbaa !29
  store ptr %t756, ptr %l399, !tbaa !29
  %t757 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t757, ptr %l400
  %t758 = load ptr, ptr %l2, !tbaa !29
  %t760 = getelementptr %"compiler/ast:ForIn", ptr %t758, i32 0, i32 2
  %t761 = load ptr, ptr %t760, !tbaa !29
  %t763 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t761)
  store %"compiler/source:Span" %t763, ptr %l403
  br label %bb158
bb158:
  %t764 = load i64, ptr %l26, !tbaa !24
  %t766 = icmp slt i64 %t764, 0
  br i1 %t766, label %bb159, label %bb160
bb159:
  %t768 = load i64, ptr %l25, !tbaa !24
  store i64 %t768, ptr %l406, !tbaa !24
  br label %bb161
bb160:
  %t770 = load i64, ptr %l26, !tbaa !24
  store i64 %t770, ptr %l406, !tbaa !24
  br label %bb161
bb161:
  %t772 = load ptr, ptr %l7, !tbaa !29
  store ptr %t772, ptr %l410, !tbaa !29
  %t774 = icmp sge i64 0, 0
  br i1 %t774, label %bb162, label %bb163
bb162:
  %t776 = icmp sle i64 0, 1152921504606846975
  br i1 %t776, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb164:
  %t778 = mul i64 0, 8
  %t779 = insertvalue { i64, ptr } undef, i64 0, 0
  %t780 = insertvalue { i64, ptr } %t779, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t780, ptr %l413, !tbaa !27
  %t781 = icmp sge i64 0, 0
  br i1 %t781, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb166:
  %t783 = icmp sle i64 0, 1152921504606846975
  br i1 %t783, label %bb168, label %bb169
bb167:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb168:
  %t785 = mul i64 0, 8
  %t786 = insertvalue { i64, ptr } undef, i64 0, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t787, ptr %l416, !tbaa !27
  %t788 = icmp sge i64 0, 0
  br i1 %t788, label %bb170, label %bb171
bb169:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb170:
  %t790 = icmp sle i64 0, 2305843009213693951
  br i1 %t790, label %bb172, label %bb173
bb171:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb172:
  %t792 = mul i64 0, 4
  %t793 = insertvalue { i64, ptr } undef, i64 0, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t795 = load ptr, ptr %l399, !tbaa !29
  %t796 = load %"compiler/source:Span", ptr %l400
  %t797 = load %"compiler/source:Span", ptr %l403
  %t798 = load i64, ptr %l406, !tbaa !24
  %t799 = load ptr, ptr %l410, !tbaa !29
  %t800 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t801 = load { i64, ptr }, ptr %l416, !tbaa !27
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t795, %"compiler/source:Span" %t796, %"compiler/source:Span" %t797, i64 %t798, ptr %t799, { i64, ptr } %t800, { i64, ptr } %t801, { i64, ptr } %t794)
  store ptr %t803, ptr %l420
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb174:
  %t804 = load ptr, ptr %l420, !tbaa !29
  store ptr %t804, ptr %l28, !tbaa !29
  %t805 = load ptr, ptr %l0, !tbaa !29
  store ptr %t805, ptr %l421, !tbaa !29
  %t806 = load ptr, ptr %l0, !tbaa !29
  store ptr %t806, ptr %l422, !tbaa !29
  %t807 = load ptr, ptr %l28, !tbaa !29
  %t810 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t807)
  store i32 %t810, ptr %l425
  br label %bb175
bb175:
  %t811 = load ptr, ptr %l422, !tbaa !29
  %t812 = load i32, ptr %l425, !tbaa !23
  %t813 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t811, i32 %t812)
  store i32 %t813, ptr %l426
  br label %bb176
bb176:
  %t814 = load ptr, ptr %l421, !tbaa !29
  %t815 = load i32, ptr %l426, !tbaa !23
  %t816 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s18, ptr %t814, i32 %t815, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) }, i64 0)
  store i64 %t816, ptr %l427
  br label %bb177
bb177:
  %t817 = load i64, ptr %l427, !tbaa !24
  store i64 %t817, ptr %l29, !tbaa !24
  %t818 = load i64, ptr %l29, !tbaa !24
  %t820 = icmp slt i64 %t818, 0
  br i1 %t820, label %bb178, label %bb179
bb178:
  %t822 = load ptr, ptr %l0, !tbaa !29
  store ptr %t822, ptr %l430, !tbaa !29
  %t823 = load ptr, ptr %l2, !tbaa !29
  %t825 = getelementptr %"compiler/ast:ForIn", ptr %t823, i32 0, i32 2
  %t826 = load ptr, ptr %t825, !tbaa !29
  %t828 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t826)
  store %"compiler/source:Span" %t828, ptr %l433
  br label %bb180
bb179:
  br label %bb182
bb180:
  %t829 = load ptr, ptr %l430, !tbaa !29
  %t830 = load %"compiler/source:Span", ptr %l433
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t829, %"compiler/source:Span" %t830, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb182:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l1
  %t834 = load ptr, ptr %l2, !tbaa !29
  %t835 = load ptr, ptr %l28, !tbaa !29
  %t836 = load i64, ptr %l29, !tbaa !24
  %t837 = load ptr, ptr %l3, !tbaa !29
  %t838 = load i32, ptr %l4, !tbaa !23
  %t839 = load i1, ptr %l27, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t832, %"compiler/source:Span" %t833, ptr %t834, ptr %t835, i64 %t836, ptr %t837, i32 %t838, i1 %t839)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb184:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load i32, ptr %l15, !tbaa !23
  %t851 = load %"compiler/source:Span", ptr %l1
  %t855 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t849, i32 %t850, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t851, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i64 %t855, ptr %l447
  br label %bb185
bb185:
  %t856 = load i64, ptr %l447, !tbaa !24
  store i64 %t856, ptr %l30, !tbaa !24
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load i32, ptr %l15, !tbaa !23
  %t861 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t857, i32 %t858, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d70, i32 0, i32 1) }, i64 0)
  store i64 %t861, ptr %l450
  br label %bb186
bb186:
  %t862 = load i64, ptr %l450, !tbaa !24
  store i64 %t862, ptr %l31, !tbaa !24
  %t863 = load i64, ptr %l30, !tbaa !24
  %t865 = icmp sge i64 %t863, 0
  br i1 %t865, label %bb187, label %bb188
bb187:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t869 = getelementptr %"compiler/check:Checker", ptr %t867, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !29
  %t872 = getelementptr %"compiler/generic:Program", ptr %t870, i32 0, i32 2
  store ptr %t872, ptr %l456, !tbaa !29
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t875 = getelementptr %"compiler/check:Checker", ptr %t873, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !29
  %t878 = getelementptr %"compiler/generic:Program", ptr %t876, i32 0, i32 2
  store ptr %t878, ptr %l459, !tbaa !29
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/check:Checker", ptr %t879, i32 0, i32 1
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t883 = load i64, ptr %l30, !tbaa !24
  %t886 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t882, i64 %t883)
  store i32 %t886, ptr %l463
  br label %bb189
bb188:
  store i1 false, ptr %l453, !tbaa !21
  br label %bb192
bb189:
  %t887 = load ptr, ptr %l459, !tbaa !29
  %t888 = load i32, ptr %l463, !tbaa !23
  %t889 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t887, i32 %t888)
  store i32 %t889, ptr %l464
  br label %bb190
bb190:
  %t890 = load ptr, ptr %l456, !tbaa !29
  %t891 = load i32, ptr %l464, !tbaa !23
  %t892 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t890, i32 %t891)
  store { i64, ptr } %t892, ptr %l465
  br label %bb191
bb191:
  %t893 = load { i64, ptr }, ptr %l465, !tbaa !27
  %t894 = extractvalue { i64, ptr } %t893, 0
  %t896 = icmp sgt i64 %t894, 0
  store i1 %t896, ptr %l453, !tbaa !21
  br label %bb192
bb192:
  %t898 = load i1, ptr %l453, !tbaa !21
  br i1 %t898, label %bb193, label %bb194
bb193:
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t901 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t899)
  store ptr %t901, ptr %l469
  br label %bb195
bb194:
  br label %bb196
bb195:
  %t902 = load ptr, ptr %l469, !tbaa !29
  store ptr %t902, ptr %l470, !tbaa !29
  %t903 = load ptr, ptr %l470, !tbaa !29
  %t904 = getelementptr %"compiler/check:frame", ptr %t903, i32 0, i32 17
  %t905 = load i64, ptr %t904, !tbaa !24
  %t908 = add i64 %t905, 1
  %t910 = load ptr, ptr %l470, !tbaa !29
  %t911 = getelementptr %"compiler/check:frame", ptr %t910, i32 0, i32 17
  store i64 %t908, ptr %t911, !tbaa !24
  br label %bb196
bb196:
  %t912 = load i64, ptr %l30, !tbaa !24
  %t914 = icmp sge i64 %t912, 0
  br i1 %t914, label %bb197, label %bb198
bb197:
  %t916 = load i64, ptr %l31, !tbaa !24
  %t918 = icmp sge i64 %t916, 0
  store i1 %t918, ptr %l476, !tbaa !21
  br label %bb199
bb198:
  store i1 false, ptr %l476, !tbaa !21
  br label %bb199
bb199:
  %t920 = load i1, ptr %l476, !tbaa !21
  br i1 %t920, label %bb200, label %bb201
bb200:
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l1
  %t923 = load ptr, ptr %l2, !tbaa !29
  %t924 = load ptr, ptr %l7, !tbaa !29
  %t925 = load i64, ptr %l30, !tbaa !24
  %t926 = load i64, ptr %l31, !tbaa !24
  %t927 = load ptr, ptr %l3, !tbaa !29
  %t928 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t921, %"compiler/source:Span" %t922, ptr %t923, ptr %t924, i64 %t925, i64 %t926, ptr %t927, i32 %t928)
  br label %bb202
bb201:
  br label %bb203
bb202:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb203:
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t939 = load i32, ptr %l15, !tbaa !23
  %t940 = load %"compiler/source:Span", ptr %l1
  %t944 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t938, i32 %t939, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, %"compiler/source:Span" %t940, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d72, i32 0, i32 1) }, i64 0, i1 false)
  store i1 %t944, ptr %l491
  br label %bb204
bb204:
  %t945 = load i1, ptr %l491, !tbaa !21
  br i1 %t945, label %bb205, label %bb206
bb205:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb206:
  br label %bb207
bb207:
  %t947 = load ptr, ptr %l0, !tbaa !29
  store ptr %t947, ptr %l493, !tbaa !29
  %t948 = load ptr, ptr %l2, !tbaa !29
  %t950 = getelementptr %"compiler/ast:ForIn", ptr %t948, i32 0, i32 2
  %t951 = load ptr, ptr %t950, !tbaa !29
  %t953 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t951)
  store %"compiler/source:Span" %t953, ptr %l496
  br label %bb208
bb208:
  %t954 = load i32, ptr %l8, !tbaa !23
  store i32 %t954, ptr %l497, !tbaa !23
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t956 = load i32, ptr %l8, !tbaa !23
  %t959 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t955, i32 %t956)
  store { i64, ptr } %t959, ptr %l500
  br label %bb209
bb209:
  %t960 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t962 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %v0, { i64, ptr } %t960)
  store %"compiler/diagmsg:Msg" %t962, ptr %l502
  br label %bb210
bb210:
  %t963 = load ptr, ptr %l493, !tbaa !29
  %t964 = load %"compiler/source:Span", ptr %l496
  %t965 = load i32, ptr %l497, !tbaa !23
  %t966 = load %"compiler/diagmsg:Msg", ptr %l502
  %t967 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %v0, ptr %t963, %"compiler/source:Span" %t964, i32 %t965, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d73, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t966)
  store i64 %t967, ptr %l503
  br label %bb211
bb211:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkedWritably(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca i1
  %l14 = alloca i64
  %l18 = alloca i1
  %l22 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb2
bb2:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l14
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t25 = and i64 %t23, %t22
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i1 %t34, ptr %l22
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t39)
  store ptr %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l25, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb19
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i1 %t51, ptr %l31
  br label %bb14
bb14:
  %t52 = load i1, ptr %l31, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i1 %t58, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l36, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l32, !tbaa !21
  store i1 %t62, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l28, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 1
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t13 = load i1, ptr %l7, !tbaa !21
  store i1 %t13, ptr %l2, !tbaa !21
  br label %bb40
bb8:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t16, ptr %l11
  br label %bb9
bb9:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t20, ptr %l13
  br label %bb12
bb12:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t24, ptr %l15
  br label %bb15
bb15:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t28, ptr %l17
  br label %bb18
bb18:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb40
bb22:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb23
bb23:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t40, ptr %l23
  br label %bb26
bb26:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l2, !tbaa !21
  br label %bb40
bb30:
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t48, ptr %l27
  br label %bb31
bb31:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l2, !tbaa !21
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_679df2ab066560af_73bde1caf560602b)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i1, ptr %l2, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enullDefault(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb22
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l4, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Catch", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t66 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t62)
  store i1 %t66, ptr %l39
  br label %bb15
bb15:
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  br label %bb21
bb21:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l2, !tbaa !24
  br label %bb4
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_3aAssertAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, i1 %a9, { i64, ptr } %a10, { i64, ptr } %a11, { i64, [3 x i64] } %a12) #0 {
entry:
  %l39 = alloca %"compiler/check:AssertAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t27 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 0
  store i64 %a0, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 1
  store i64 %a1, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 2
  store %"compiler/source:Span" %a2, ptr %t31
  %t33 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 3
  store %"compiler/source:Span" %a3, ptr %t33
  %t35 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 4
  store i64 %a4, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 5
  store i64 %a5, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 6
  store i1 %a9, ptr %t39, !tbaa !21
  %t41 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 7
  store { i64, ptr } %a10, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 8
  store { i64, ptr } %a11, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 9
  store { i64, [3 x i64] } %a12, ptr %t45
  %t47 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 10
  store { i64, ptr } %a6, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 11
  store { i64, [3 x i64] } %a7, ptr %t49
  %t51 = getelementptr %"compiler/check:AssertAsk", ptr %l39, i32 0, i32 12
  store { i64, ptr } %a8, ptr %t51, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l39, i64 184, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %v0, i32 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, [3 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:ValueAsk"
  %t13 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 0
  store i64 0, ptr %t14
  %t15 = load { i64, [3 x i64] }, ptr %t13
  %t18 = insertvalue %"compiler/check:ValueAsk" undef, i32 %a0, 0
  %t20 = insertvalue %"compiler/check:ValueAsk" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/check:ValueAsk" %t20, %"compiler/source:Span" %a2, 2
  %t24 = insertvalue %"compiler/check:ValueAsk" %t22, i32 %a3, 3
  %t26 = insertvalue %"compiler/check:ValueAsk" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/check:ValueAsk" %t26, { i64, [3 x i64] } %a5, 5
  %t30 = insertvalue %"compiler/check:ValueAsk" %t28, i1 false, 6
  %t32 = insertvalue %"compiler/check:ValueAsk" %t30, { i64, [3 x i64] } %t15, 7
  store %"compiler/check:ValueAsk" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ValueAsk", ptr %rv
  ret %"compiler/check:ValueAsk" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"it introduces a type variable, which no zero binds" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e3 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e14 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e16 = weak hidden constant i1 false
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eassertStmt_2elocal_2e22 = weak hidden constant i1 false
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 4}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 4}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  br label %bb3
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i64 }, ptr %t47, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i64 }, ptr %t51, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64, i64 }, ptr %t71, i32 0, i32 2
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb12, label %bb1
bb12:
  br label %bb3
bb13:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@olang_2esole_2ecompiler_2fcheck_3aAssertAsk_2e10 = weak hidden constant i1 false
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Atomic" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\22" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">(0)" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"IterMut" }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"IterRef" }>, align 8
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PadStart" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"PadEnd" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"vacate" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"occupy" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d33 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a method the compiler supplies (E10b, E11c)" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PadStart" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"PadEnd" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a case" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inf" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"NaN" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Epsilon" }>, align 8
@.d45 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"SmallestNormal" }>, align 8
@.d46 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"a limit of the number type" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"From" }>, align 8
@.d48 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the raw value's reverse" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d51 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d54 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its Name and Type" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aframe_2e48 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3anullNarrow_2e0 = weak hidden constant i1 false
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d62 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d63 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d64 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d65 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"IterRef" }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d67 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an Iter() whose result is no iterator (S9c)" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d70 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d72 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"'for ... in'" }>, align 8
@.d73 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a walk ('for ... in': Next, Iter, or At and Len)" }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d77 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d78 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d79 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"LanesLess" }>, align 8
@.d81 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Select" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ePush_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0, %"compiler/check:ValueAsk" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsLibrary(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_7a7e3734e2ac5540_e5e6042583167994 = external constant [0 x i8]
@olang_loc_299e8d70417dba6d_28fb9bcaf3f636a1 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2etextWritten(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %a0, %"compiler/check:factsMark" %a1)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0)
declare i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_65fe1e2545381fa4_5766bfa4307d0508 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderKey(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerElsewhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerWritten(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_f6b13c9d74679e52_66e9acddac9b88a6 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeDefaultUnmet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2eintOnly(i32 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneGroupSize(ptr %v0)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaccumulator(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneWorksIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fcheck_2eLaneGroup = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10, i64 %a11)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4, { i64, ptr } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4, i32 %a5, %"compiler/source:Span" %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d23330c3ef7ea91b_34477ea00961dc87 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eendedWhy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_897998a95b9e5e2e_e7f90bd867c953f2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
@olang_loc_97297cf958301a5_897be3a3c1a33231 = external constant [0 x i8]
@olang_loc_f4ec2e4bc4870738_831a294d3dfd1224 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
@olang_loc_2a22705e3675cc6a_15625908cbc104fe = external constant [0 x i8]
@olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33 = external constant [0 x i8]
@olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
@olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflOfType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_efc3d234eb1501de_4d27d8d6a326f0a = external constant [0 x i8]
@olang_loc_7655d192ba63d713_67a9153eaa817cdf = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadBad(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadHoldsRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSettleRaised(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Ask" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eSetA_H2f2d9e3b51ec05f25dc2320ca6b31566(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eTrun_Heefffe1e944651b1941f34d83e014b00(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afixedProof_3e_2eLen_He15a40c7f29502b6f30dac9a9c5a943c(ptr %v0, ptr %a0)
declare %"compiler/check:fixedProof" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afixedProof_3e_2eAt__Hbf13be1060118ce2e34b50179c0ccd6f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigning(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_f0430e4b284237b0_c6243626a46be64 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eWhyAssigned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:nullNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v1, %"compiler/check:narrowed" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNull(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_28ca8569d2f90b5d_c88a44871853971 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_43a48225da0bb134_ea32de8827419df8 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextPieces(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryParens(ptr %v0)
@olang_loc_fd60765d84d8653f_8f5cfc6948292c73 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryOnCaught(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
@olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6, i1 %a7)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
@olang_loc_a734531b29123b5_def2307fb88201b9 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_679df2ab066560af_73bde1caf560602b = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
