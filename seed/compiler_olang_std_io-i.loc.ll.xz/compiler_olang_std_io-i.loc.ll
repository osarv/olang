; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3e9148f9e0e46869_5b7400af9745fccd = weak_odr constant [55 x i8] c"std/prelude/text.olang:490: slice bounds out of range\0A\00"
@olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4 = weak_odr constant [55 x i8] c"std/prelude/text.olang:490: slice bounds out of range\0A\00"
@olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be = weak_odr constant [55 x i8] c"std/prelude/text.olang:490: slice bounds out of range\0A\00"
@olang_loc_ca892011aac17b75_e14eaf889df4b399 = weak_odr constant [55 x i8] c"std/prelude/text.olang:490: slice bounds out of range\0A\00"
