; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_30658a5658f210fa_fff31b25b1b9b2ae = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_bfd170d67c148287_6b9cefc6aaef3f93 = weak_odr constant [56 x i8] c"std/prelude/array.olang:178: array length out of range\0A\00"
@olang_loc_f8ccfd7eecf7db25_4255e8bc5856fa11 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:169: slice bounds out of range\0A\00"
