; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3d095a6c1ac57479_6498550596051dfd = weak_odr constant [45 x i8] c"std/prelude/print.olang:16: unhandled error\0A\00"
@olang_loc_b147773ca651a0d5_4138a7003fad1dc1 = weak_odr constant [29 x i8] c"std/prelude/print.olang:16: \00"
