; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4e49736324d3bb36_f99ee932a7b32ce2 = weak_odr constant [47 x i8] c"std/prelude/print.olang:15: assertion failed: \00"
