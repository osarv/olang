; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1c0679980ce0635d_576d548db3c71a49 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_2cb364153a5e7b95_455e2860b99f2a99 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_592d764de97735f1_d3aaf4c300051df5 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_65af9071fdc5824b_96d01d23471a31f = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_92db2dae18cb5dcf_b539c852ccec06b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_9930722cf2f3dfbf_bfc4660725d0d37b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_bb79e8b122f59003_2c555d3622a1f2df = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_dd0bdcf2b4b37995_119bfb09f480a89 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_f6d9322d5b5099ad_6dbb11040e80dfd9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
