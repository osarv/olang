; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_131edaf087805d6d_f0172ba6a7174a79 = weak_odr constant [41 x i8] c"std/chan.olang:455: unreachable reached\0A\00"
@olang_loc_145e16a295540880_36111fc3573e18dc = weak_odr constant [84 x i8] c"std/chan.olang:358: ChanError.CLOSED\0A(build with -debug to see where it came from)\0A\00"
@olang_loc_1cc0429d2186324_90f082d137ce1aa8 = weak_odr constant [83 x i8] c"std/chan.olang:250: unhandled error\0A(build with -debug to see where it came from)\0A\00"
@olang_loc_2a2fbd67b0b02d98_a1bf4b72498d5e4c = weak_odr constant [41 x i8] c"std/chan.olang:477: unreachable reached\0A\00"
@olang_loc_6835b37da0ed3954_626a467cc9ad1178 = weak_odr constant [84 x i8] c"std/chan.olang:250: ChanError.CLOSED\0A(build with -debug to see where it came from)\0A\00"
@olang_loc_726c4b10f44d9e91_b01389f65b0e732d = weak_odr constant [41 x i8] c"std/chan.olang:437: unreachable reached\0A\00"
@olang_loc_b7735a89bbc06110_23f6663a0de6d42c = weak_odr constant [83 x i8] c"std/chan.olang:358: unhandled error\0A(build with -debug to see where it came from)\0A\00"
