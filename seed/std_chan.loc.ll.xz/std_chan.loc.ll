; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_131edaf087805d6d_f0172ba6a7174a79 = weak_odr constant [41 x i8] c"std/chan.olang:434: unreachable reached\0A\00"
@olang_loc_2a2fbd67b0b02d98_a1bf4b72498d5e4c = weak_odr constant [41 x i8] c"std/chan.olang:456: unreachable reached\0A\00"
@olang_loc_4acda35dc97a8041_dd5e97031313014d = weak_odr constant [37 x i8] c"std/chan.olang:229: unhandled error\0A\00"
@olang_loc_726c4b10f44d9e91_b01389f65b0e732d = weak_odr constant [41 x i8] c"std/chan.olang:416: unreachable reached\0A\00"
@olang_loc_7bd8d406daeaa501_bb299c58f9e594a5 = weak_odr constant [39 x i8] c"std/chan.olang:337: chan.Error.CLOSED\0A\00"
@olang_loc_d16d2f12d2d21c95_5a6f2cc315fae0a9 = weak_odr constant [37 x i8] c"std/chan.olang:337: unhandled error\0A\00"
@olang_loc_e5bd40b731c84bfd_92cb7e9bdec0c99 = weak_odr constant [39 x i8] c"std/chan.olang:229: chan.Error.CLOSED\0A\00"
