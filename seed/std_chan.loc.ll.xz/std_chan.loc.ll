; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2a2fbd67b0b02d98_a1bf4b72498d5e4c = weak_odr constant [41 x i8] c"std/chan.olang:463: unreachable reached\0A\00"
@olang_loc_4acda35dc97a8041_dd5e97031313014d = weak_odr constant [37 x i8] c"std/chan.olang:225: unhandled error\0A\00"
@olang_loc_a1af0d6c4dd8cd1d_1e212d48f267dbf9 = weak_odr constant [39 x i8] c"std/chan.olang:225: chan.Error.Closed\0A\00"
@olang_loc_b97360bfa7248521_cee0e6fafdf7db85 = weak_odr constant [39 x i8] c"std/chan.olang:351: chan.Error.Closed\0A\00"
@olang_loc_d16d2f12d2d21c95_5a6f2cc315fae0a9 = weak_odr constant [37 x i8] c"std/chan.olang:351: unhandled error\0A\00"
@olang_loc_ecbc31e72b17a73d_50a1e37baf4f24c1 = weak_odr constant [47 x i8] c"std/chan.olang:246: array length out of range\0A\00"
