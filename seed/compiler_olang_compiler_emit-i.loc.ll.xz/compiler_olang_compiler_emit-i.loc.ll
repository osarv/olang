; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_107ea1d5f6b7ae7e_97e8142bbca38122 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_24917fff6b0dbf12_3e480d1ddf3b6c6 = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_57be641a3add5a07_268bdd2689f05f43 = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_770927d2495b2877_f8495f0b6d3874b3 = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
@olang_loc_965034e81055f42a_393c3a88a69cf1e6 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
@olang_loc_b0a182e5ba72b608_8bd4b05b5ee8ea4c = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_cd1a6553288b106c_15d27d0457903e90 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_d79a0cf81f399b53_d96976f8112a56a7 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
