; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4f1df543f3a9d5d6_52ca55d2bae1c42 = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
@olang_loc_510300a68d24b187_a40f397f218622f3 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_82ac87139d06d166_65a8d9c1ddbd7c02 = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
@olang_loc_af8034ed03be0e1e_77ba30c04ab1555a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ba1670151c71c77c_9b542833caacf870 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_bb654f3dfc8b68f9_aa55ccc79857fd5d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_e064e3c3b0e0e177_29b38c2a680f58db = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
