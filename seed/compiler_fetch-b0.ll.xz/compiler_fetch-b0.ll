; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
define dso_local i1 @compiler_2ffetch_2eNamePart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 46
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } %t28)
  store i1 %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i1, ptr %l20, !tbaa !21
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  store i8 %t53, ptr %l4, !tbaa !22
  %t55 = load i8, ptr %l4, !tbaa !22
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t55)
  store i1 %t57, ptr %l33
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb22
bb20:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t59)
  store i1 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  %t64 = load i8, ptr %l4, !tbaa !22
  %t66 = icmp eq i8 %t64, 46
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb28
bb27:
  %t69 = load i8, ptr %l4, !tbaa !22
  %t71 = icmp eq i8 %t69, 95
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb30:
  %t74 = load i8, ptr %l4, !tbaa !22
  %t76 = icmp eq i8 %t74, 45
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t78 = load i1, ptr %l43, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t82 = load i64, ptr %l2, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb14
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ecommitAgain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t35 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t29, { i64, ptr } %a2)
  store i32 %t35, ptr %l13
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb2, label %ok.37, !prof !99
ok.37:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t38 = load i32, ptr %l13, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l15, !tbaa !21
  %t42 = load i32, ptr %l13, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %l19, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l20, !tbaa !24
  %t50 = load i64, ptr %l20, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l21, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t61, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb6:
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x { i64, ptr }] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t65, ptr %l23
  br label %bb7
bb7:
  %t66 = load i1, ptr %l23, !tbaa !21
  br i1 %t66, label %bb8, label %bb9
bb8:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t69)
  store { i64, ptr } %t71, ptr %l27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t72, ptr %l25, !tbaa !27
  br label %bb11
bb10:
  %t74 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t74, ptr %l25, !tbaa !27
  br label %bb11
bb11:
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l30, !tbaa !24
  %t77 = load i64, ptr %l30, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l31, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l30, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t88, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %lp20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l107 = alloca { i64, ptr }
  %l110 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l130 = alloca i1
  %l132 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i32
  %l145 = alloca i1
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i32
  %l154 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca i1
  %l180 = alloca i1
  %l184 = alloca { i64, ptr }
  %l185 = alloca i1
  %l186 = alloca i1
  %l188 = alloca { i64, ptr }
  %l189 = alloca i1
  %l193 = alloca i32
  %l195 = alloca i1
  %l200 = alloca { i64, ptr }
  %l201 = alloca i1
  %l204 = alloca { i64, ptr }
  %l205 = alloca i1
  %l207 = alloca { i64, ptr }
  %l210 = alloca i1
  %l213 = alloca i32
  %l215 = alloca i1
  %l218 = alloca i32
  %l220 = alloca i1
  %l224 = alloca i32
  %l226 = alloca i1
  %l230 = alloca i32
  %l232 = alloca i1
  %l235 = alloca i32
  %l237 = alloca i32
  %l239 = alloca i1
  %l242 = alloca { i64, ptr }
  %l243 = alloca i64
  %l244 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l246 = alloca i64
  %l256 = alloca { i64, ptr }
  %l261 = alloca i32
  %l263 = alloca i1
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l272 = alloca i1
  %l274 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l278 = alloca i1
  %l280 = alloca i32
  %l282 = alloca i1
  %l285 = alloca i32
  %l290 = alloca i1
  %l292 = alloca i32
  %l294 = alloca i1
  %l299 = alloca i32
  %l301 = alloca i1
  %l305 = alloca i32
  %l307 = alloca i1
  %l310 = alloca i32
  %l318 = alloca i1
  %l320 = alloca i1
  %l322 = alloca i1
  %l323 = alloca ptr
  %l324 = alloca i64
  %l326 = alloca { i64, ptr }
  %l327 = alloca i64
  %l335 = alloca i1
  %l338 = alloca i1
  %l340 = alloca ptr
  %l341 = alloca i64
  %l343 = alloca { i64, ptr }
  %l344 = alloca i64
  %l348 = alloca { i64, ptr }
  %l349 = alloca i64
  %l357 = alloca ptr
  %l358 = alloca i64
  %l360 = alloca { i64, ptr }
  %l361 = alloca i64
  %l368 = alloca { i64, ptr }
  %l369 = alloca i64
  %l370 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v3, { i64, ptr } %t1, i8 64)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l26
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l22, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l22, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l30, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l30, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb7:
  %t24 = load i64, ptr %l30, !tbaa !24
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  br i1 %t26, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l41, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l43, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t48, 0
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l52, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l54, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t61, 0
  store i64 %t64, ptr %l57, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l58, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb15:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l40, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb19:
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l57, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb21:
  %t91 = load i64, ptr %l57, !tbaa !24
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l57, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l40, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t104, ptr %l6, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2ffetch_2eNamePart(ptr %v1, { i64, ptr } %t105)
  store i1 %t107, ptr %l64
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t113 = call i1 @compiler_2ffetch_2eNamePart(ptr %v2, { i64, ptr } %t111)
  store i1 %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = load i1, ptr %l68, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb34
bb32:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t118)
  store i1 %t120, ptr %l72
  br label %bb33
bb33:
  %t121 = load i1, ptr %l72, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb36:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = icmp slt i64 %t125, %t128
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t133 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = call i1 @compiler_2ffetch_2eNamePart(ptr %v3, { i64, ptr } %t133)
  store i1 %t135, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t136 = load i1, ptr %l81, !tbaa !21
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l79, !tbaa !21
  store i1 %t139, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t140 = load i1, ptr %l74, !tbaa !21
  br i1 %t140, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/fetch:Fetcher", ptr %t143, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t148, 1
  %t153 = extractvalue { i64, ptr } %t148, 0
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t149, 1
  %t159 = extractvalue { i64, ptr } %t149, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t150, 1
  %t166 = extractvalue { i64, ptr } %t150, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t152, i64 %t153)
  %t169 = getelementptr i8, ptr %t168, i64 %t153
  call void @olang_textcopy(ptr %t169, ptr %t154, i64 %t155)
  %t170 = getelementptr i8, ptr %t169, i64 %t155
  call void @olang_textcopy(ptr %t170, ptr %t158, i64 %t159)
  %t171 = getelementptr i8, ptr %t170, i64 %t159
  call void @olang_textcopy(ptr %t171, ptr %t161, i64 %t162)
  %t172 = getelementptr i8, ptr %t171, i64 %t162
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t175, ptr %lp8
  %t177 = load ptr, ptr %lp8
  store { i64, ptr } %t174, ptr %t177, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/fetch:Fetcher", ptr %t178, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t181, 1
  %t187 = extractvalue { i64, ptr } %t181, 0
  %t189 = extractvalue { i64, ptr } %t182, 1
  %t190 = extractvalue { i64, ptr } %t182, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = extractvalue { i64, ptr } %t183, 1
  %t197 = extractvalue { i64, ptr } %t183, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t184, 1
  %t204 = extractvalue { i64, ptr } %t184, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t186, i64 %t187)
  %t207 = getelementptr i8, ptr %t206, i64 %t187
  call void @olang_textcopy(ptr %t207, ptr %t189, i64 %t190)
  %t208 = getelementptr i8, ptr %t207, i64 %t190
  call void @olang_textcopy(ptr %t208, ptr %t192, i64 %t193)
  %t209 = getelementptr i8, ptr %t208, i64 %t193
  call void @olang_textcopy(ptr %t209, ptr %t196, i64 %t197)
  %t210 = getelementptr i8, ptr %t209, i64 %t197
  call void @olang_textcopy(ptr %t210, ptr %t199, i64 %t200)
  %t211 = getelementptr i8, ptr %t210, i64 %t200
  call void @olang_textcopy(ptr %t211, ptr %t203, i64 %t204)
  %t212 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t206, 1
  store { i64, ptr } %t213, ptr %l9, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t215, 1
  %t221 = extractvalue { i64, ptr } %t215, 0
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t226 = extractvalue { i64, ptr } %t216, 1
  %t227 = extractvalue { i64, ptr } %t216, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t233 = extractvalue { i64, ptr } %t217, 1
  %t234 = extractvalue { i64, ptr } %t217, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t218, 1
  %t241 = extractvalue { i64, ptr } %t218, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t220, i64 %t221)
  %t244 = getelementptr i8, ptr %t243, i64 %t221
  call void @olang_textcopy(ptr %t244, ptr %t222, i64 %t223)
  %t245 = getelementptr i8, ptr %t244, i64 %t223
  call void @olang_textcopy(ptr %t245, ptr %t226, i64 %t227)
  %t246 = getelementptr i8, ptr %t245, i64 %t227
  call void @olang_textcopy(ptr %t246, ptr %t229, i64 %t230)
  %t247 = getelementptr i8, ptr %t246, i64 %t230
  call void @olang_textcopy(ptr %t247, ptr %t233, i64 %t234)
  %t248 = getelementptr i8, ptr %t247, i64 %t234
  call void @olang_textcopy(ptr %t248, ptr %t236, i64 %t237)
  %t249 = getelementptr i8, ptr %t248, i64 %t237
  call void @olang_textcopy(ptr %t249, ptr %t240, i64 %t241)
  %t250 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t243, 1
  store { i64, ptr } %t251, ptr %l10, !tbaa !27
  store i1 true, ptr %l11, !tbaa !21
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %lp8
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t258 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v0, ptr %s0, ptr %t253, { i64, ptr } %t255)
  %t259 = extractvalue { i32, { i64, ptr } } %t258, 1
  %t260 = extractvalue { i32, { i64, ptr } } %t258, 0
  store i32 %t260, ptr %l105
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb46, label %ok.262, !prof !99
ok.262:
  store { i64, ptr } %t259, ptr %l104
  br label %bb45
bb45:
  %t263 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t263, ptr %l101, !tbaa !27
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l101, !tbaa !27
  br label %bb48
bb48:
  %t264 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t265, i64 %t266)
  %t268 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  store { i64, ptr } %t269, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l107, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t271, ptr %l13, !tbaa !27
  store i1 false, ptr %l14, !tbaa !21
  %t273 = load i1, ptr %l11, !tbaa !21
  br i1 %t273, label %bb49, label %bb50
bb49:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/fetch:Fetcher", ptr %t275, i32 0, i32 3
  %t278 = load i1, ptr %t277, !tbaa !21
  store i1 %t278, ptr %l110, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb51
bb51:
  %t280 = load i1, ptr %l110, !tbaa !21
  br i1 %t280, label %bb52, label %bb53
bb52:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %lp8
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  %t286 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v0, ptr %t281, { i64, ptr } %t283, i1 false)
  store i1 %t286, ptr %l116
  br label %bb54
bb53:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb55
bb54:
  %t287 = load i1, ptr %l116, !tbaa !21
  %t288 = xor i1 %t287, true
  store i1 %t288, ptr %l113, !tbaa !21
  br label %bb55
bb55:
  %t290 = load i1, ptr %l113, !tbaa !21
  br i1 %t290, label %bb56, label %bb57
bb56:
  %t291 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t293 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t291)
  store i1 %t293, ptr %l119
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t294 = load i1, ptr %l119, !tbaa !21
  br i1 %t294, label %bb59, label %bb60
bb59:
  %t295 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 1
  %t298 = extractvalue { i64, ptr } %t295, 0
  %t299 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t298)
  call void @olang_textcopy(ptr %t299, ptr %t297, i64 %t298)
  %t300 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l120, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l123, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t303, ptr %l120, !tbaa !27
  br label %bb61
bb61:
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t305, ptr %l125, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  store i64 %t307, ptr %l126, !tbaa !24
  %t308 = load i64, ptr %l126, !tbaa !24
  %t309 = mul i64 %t308, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l127, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = load i64, ptr %l126, !tbaa !24
  %t318 = mul i64 %t317, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t314, ptr %t316, i64 %t318, i1 false)
  %t319 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t319, ptr %l13, !tbaa !27
  %t320 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eFetch_2elocal_2e13
  br i1 %t320, label %bb62, label %bb63
bb62:
  %t322 = load { i64, ptr }, ptr %l125
  %t323 = extractvalue { i64, ptr } %t322, 1
  call void @__olang_region_release(ptr %t323)
  store { i64, ptr } zeroinitializer, ptr %l125
  br label %bb63
bb63:
  store i1 true, ptr %l14, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  br label %bb64
bb64:
  %t324 = load i1, ptr %l11, !tbaa !21
  br i1 %t324, label %bb65, label %bb66
bb65:
  %t326 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t328 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t326)
  store i1 %t328, ptr %l132
  br label %bb67
bb66:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb68
bb67:
  %t329 = load i1, ptr %l132, !tbaa !21
  %t330 = xor i1 %t329, true
  store i1 %t330, ptr %l130, !tbaa !21
  br label %bb68
bb68:
  %t332 = load i1, ptr %l130, !tbaa !21
  br i1 %t332, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t334 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t334, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t335 = load i1, ptr %l11, !tbaa !21
  br i1 %t335, label %bb72, label %bb73
bb72:
  %t337 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = extractvalue { i64, ptr } %t337, 0
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t343 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t344 = add i64 %t341, %t343
  %t346 = extractvalue { i64, ptr } %t338, 1
  %t347 = extractvalue { i64, ptr } %t338, 0
  %t348 = add i64 %t344, %t347
  %t349 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t340, i64 %t341)
  %t350 = getelementptr i8, ptr %t349, i64 %t341
  call void @olang_textcopy(ptr %t350, ptr %t342, i64 %t343)
  %t351 = getelementptr i8, ptr %t350, i64 %t343
  call void @olang_textcopy(ptr %t351, ptr %t346, i64 %t347)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t349, 1
  store { i64, ptr } %t353, ptr %l15, !tbaa !27
  %t355 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t357 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t355)
  store i1 %t357, ptr %l140
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t358 = load i1, ptr %l140, !tbaa !21
  br i1 %t358, label %bb75, label %bb76
bb75:
  %t359 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t361 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t359, 1
  store { i32, { i64, ptr } } %t361, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t362 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t364 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t362)
  store i32 %t364, ptr %l143
  %t365 = icmp ne i32 %t364, 0
  br i1 %t365, label %bb80, label %ok.366, !prof !99
ok.366:
  br label %bb79
bb79:
  br label %bb84
bb80:
  %t367 = load i32, ptr %l143, !tbaa !23
  %t368 = ashr i32 %t367, 16
  %t370 = icmp eq i32 %t368, 1
  store i1 %t370, ptr %l145, !tbaa !21
  %t371 = load i32, ptr %l143, !tbaa !23
  %t372 = ashr i32 %t371, 16
  %t374 = icmp eq i32 %t372, 1
  br i1 %t374, label %bb81, label %bb82
bb81:
  call void @__olang_errpay_pop()
  br label %bb82
bb82:
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t377 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t377, ptr %rv
  br label %ret
bb84:
  %t378 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t380 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t378, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) })
  %t381 = extractvalue { i32, { i64, ptr } } %t380, 1
  %t382 = extractvalue { i32, { i64, ptr } } %t380, 0
  store i32 %t382, ptr %l152
  %t383 = icmp ne i32 %t382, 0
  br i1 %t383, label %bb86, label %ok.384, !prof !99
ok.384:
  store { i64, ptr } %t381, ptr %l151
  br label %bb85
bb85:
  %t385 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t385, ptr %l149, !tbaa !27
  br label %bb90
bb86:
  %t386 = load i32, ptr %l152, !tbaa !23
  %t387 = ashr i32 %t386, 16
  %t389 = icmp eq i32 %t387, 1
  store i1 %t389, ptr %l154, !tbaa !21
  %t390 = load i32, ptr %l152, !tbaa !23
  %t391 = ashr i32 %t390, 16
  %t393 = icmp eq i32 %t391, 1
  br i1 %t393, label %bb87, label %bb88
bb87:
  call void @__olang_errpay_pop()
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s0)
  %t396 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65538, 0
  store { i32, { i64, ptr } } %t396, ptr %rv
  br label %ret
bb90:
  %t397 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t397, ptr %l16, !tbaa !27
  %t398 = load ptr, ptr %lp8
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  %t400 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t403 = extractvalue { i64, ptr } %t399, 1
  %t404 = extractvalue { i64, ptr } %t399, 0
  %t405 = add i64 %t401, %t404
  %t406 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t400, i64 %t401)
  %t407 = getelementptr i8, ptr %t406, i64 %t401
  call void @olang_textcopy(ptr %t407, ptr %t403, i64 %t404)
  %t408 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t406, 1
  call void @compiler_2fspin_2eRetitle(ptr %s0, { i64, ptr } %t409)
  br label %bb91
bb91:
  %t412 = load i1, ptr %l11, !tbaa !21
  br i1 %t412, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s16
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l162, !tbaa !29
  %t415 = call ptr @__olang_scope_hold(ptr %v0)
  %t416 = ptrtoint ptr %t415 to i64
  store i64 %t416, ptr %l163, !tbaa !24
  %t417 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t417, label %bb94, label %bb95
bb93:
  br label %bb162
bb94:
  %t419 = call ptr @__olang_region_make(ptr %v0)
  %t420 = ptrtoint ptr %t419 to i64
  store i64 %t420, ptr %l163, !tbaa !24
  br label %bb95
bb95:
  %t421 = load ptr, ptr %lp8
  %t422 = load { i64, ptr }, ptr %t421, !tbaa !27
  store { i64, ptr } %t422, ptr %l165, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t423, ptr %l166, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  store i64 %t425, ptr %l167, !tbaa !24
  %t426 = icmp sge i64 0, 0
  br i1 %t426, label %bb96, label %bb97
bb96:
  %t428 = icmp sle i64 0, 12
  br i1 %t428, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb98:
  %t430 = load i64, ptr %l167, !tbaa !24
  %t431 = icmp sle i64 12, %t430
  br i1 %t431, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb100:
  %t433 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr i8, ptr %t434, i64 0
  %t436 = sub i64 12, 0
  %t437 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t435, 1
  %t439 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t440 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t441 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t448 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t448, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = add i64 %t447, %t450
  %t452 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t454 = add i64 %t451, %t453
  %t456 = extractvalue { i64, ptr } %t438, 1
  %t457 = extractvalue { i64, ptr } %t438, 0
  %t458 = add i64 %t454, %t457
  %t459 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t461 = add i64 %t458, %t460
  %t462 = load i64, ptr %l163
  %t463 = inttoptr i64 %t462 to ptr
  %t464 = call ptr @__olang_held_alloc(ptr %t463, i64 %t461)
  call void @olang_textcopy(ptr %t464, ptr %t439, i64 %t440)
  %t465 = getelementptr i8, ptr %t464, i64 %t440
  call void @olang_textcopy(ptr %t465, ptr %t442, i64 %t443)
  %t466 = getelementptr i8, ptr %t465, i64 %t443
  call void @olang_textcopy(ptr %t466, ptr %t445, i64 %t446)
  %t467 = getelementptr i8, ptr %t466, i64 %t446
  call void @olang_textcopy(ptr %t467, ptr %t449, i64 %t450)
  %t468 = getelementptr i8, ptr %t467, i64 %t450
  call void @olang_textcopy(ptr %t468, ptr %t452, i64 %t453)
  %t469 = getelementptr i8, ptr %t468, i64 %t453
  call void @olang_textcopy(ptr %t469, ptr %t456, i64 %t457)
  %t470 = getelementptr i8, ptr %t469, i64 %t457
  call void @olang_textcopy(ptr %t470, ptr %t459, i64 %t460)
  %t471 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t464, 1
  %t474 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v0, ptr %t474, { i64, ptr } %t472)
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_45f2c25416d44418_72b8f662ae75c904)
  unreachable
bb102:
  %t476 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t477 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t476, 1
  %t480 = extractvalue { i64, ptr } %t476, 0
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t483 = add i64 %t480, %t482
  %t485 = extractvalue { i64, ptr } %t477, 1
  %t486 = extractvalue { i64, ptr } %t477, 0
  %t487 = add i64 %t483, %t486
  %t488 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t487)
  call void @olang_textcopy(ptr %t488, ptr %t479, i64 %t480)
  %t489 = getelementptr i8, ptr %t488, i64 %t480
  call void @olang_textcopy(ptr %t489, ptr %t481, i64 %t482)
  %t490 = getelementptr i8, ptr %t489, i64 %t482
  call void @olang_textcopy(ptr %t490, ptr %t485, i64 %t486)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t488, 1
  store { i64, ptr } %t492, ptr %l17, !tbaa !27
  %t494 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t495 = mul i64 4, 16
  %t496 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t495)
  %t497 = insertvalue { i64, ptr } undef, i64 4, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t496, 1
  store { i64, ptr } %t498, ptr %l178, !tbaa !27
  %t499 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = getelementptr { i64, ptr }, ptr %t500, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %t501, !tbaa !37
  %t502 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr { i64, ptr }, ptr %t503, i64 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %t504, !tbaa !37
  %t505 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = getelementptr { i64, ptr }, ptr %t506, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %t507, !tbaa !37
  %t509 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr { i64, ptr }, ptr %t510, i64 3
  store { i64, ptr } %t494, ptr %t511, !tbaa !37
  %t512 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t513 = call i1 @compiler_2ffetch_2egit(ptr %s16, { i64, ptr } %t512)
  store i1 %t513, ptr %l179
  br label %bb103
bb103:
  %t514 = load i1, ptr %l179, !tbaa !21
  br i1 %t514, label %bb104, label %bb105
bb104:
  %t515 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t516 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t517 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t518 = mul i64 10, 16
  %t519 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t518)
  %t520 = insertvalue { i64, ptr } undef, i64 10, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  store { i64, ptr } %t521, ptr %l184, !tbaa !27
  %t522 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr { i64, ptr }, ptr %t523, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %t524, !tbaa !37
  %t525 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %t526, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t527, !tbaa !37
  %t529 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %t530, i64 2
  store { i64, ptr } %t515, ptr %t531, !tbaa !37
  %t532 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr { i64, ptr }, ptr %t533, i64 3
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t534, !tbaa !37
  %t535 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr { i64, ptr }, ptr %t536, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t537, !tbaa !37
  %t538 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr { i64, ptr }, ptr %t539, i64 5
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %t540, !tbaa !37
  %t541 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %t542, i64 6
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t543, !tbaa !37
  %t544 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr { i64, ptr }, ptr %t545, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t546, !tbaa !37
  %t548 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr { i64, ptr }, ptr %t549, i64 8
  store { i64, ptr } %t516, ptr %t550, !tbaa !37
  %t552 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr { i64, ptr }, ptr %t553, i64 9
  store { i64, ptr } %t517, ptr %t554, !tbaa !37
  %t555 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t556 = call i1 @compiler_2ffetch_2egit(ptr %s16, { i64, ptr } %t555)
  store i1 %t556, ptr %l185
  br label %bb106
bb105:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb107
bb106:
  %t557 = load i1, ptr %l185, !tbaa !21
  store i1 %t557, ptr %l180, !tbaa !21
  br label %bb107
bb107:
  %t558 = load i1, ptr %l180, !tbaa !21
  br i1 %t558, label %bb108, label %bb109
bb108:
  %t559 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t560 = mul i64 6, 16
  %t561 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t560)
  %t562 = insertvalue { i64, ptr } undef, i64 6, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t561, 1
  store { i64, ptr } %t563, ptr %l188, !tbaa !27
  %t564 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %t565, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t566, !tbaa !37
  %t567 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr { i64, ptr }, ptr %t568, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t569, !tbaa !37
  %t571 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t572 = load ptr, ptr %t571, !tbaa !27
  %t573 = getelementptr { i64, ptr }, ptr %t572, i64 2
  store { i64, ptr } %t559, ptr %t573, !tbaa !37
  %t574 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %t575, i64 3
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t576, !tbaa !37
  %t577 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr { i64, ptr }, ptr %t578, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t579, !tbaa !37
  %t580 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr { i64, ptr }, ptr %t581, i64 5
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t582, !tbaa !37
  %t583 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t584 = call i1 @compiler_2ffetch_2egit(ptr %s16, { i64, ptr } %t583)
  store i1 %t584, ptr %l189
  br label %bb110
bb109:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb111
bb110:
  %t585 = load i1, ptr %l189, !tbaa !21
  store i1 %t585, ptr %l186, !tbaa !21
  br label %bb111
bb111:
  %t586 = load i1, ptr %l186, !tbaa !21
  %t589 = xor i1 %t586, true
  br i1 %t589, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s19
  %t591 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t593 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t591)
  store i32 %t593, ptr %l193
  %t594 = icmp ne i32 %t593, 0
  br i1 %t594, label %bb115, label %ok.595, !prof !99
ok.595:
  br label %bb114
bb113:
  br label %bb125
bb114:
  br label %bb119
bb115:
  %t596 = load i32, ptr %l193, !tbaa !23
  %t597 = ashr i32 %t596, 16
  %t599 = icmp eq i32 %t597, 1
  store i1 %t599, ptr %l195, !tbaa !21
  %t600 = load i32, ptr %l193, !tbaa !23
  %t601 = ashr i32 %t600, 16
  %t603 = icmp eq i32 %t601, 1
  br i1 %t603, label %bb116, label %bb117
bb116:
  call void @__olang_errpay_pop()
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t605 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t606 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t607 = mul i64 6, 16
  %t608 = call ptr @__olang_scope_alloc_zeroed(ptr %s19, i64 %t607)
  %t609 = insertvalue { i64, ptr } undef, i64 6, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t608, 1
  store { i64, ptr } %t610, ptr %l200, !tbaa !27
  %t611 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t612 = load ptr, ptr %t611, !tbaa !27
  %t613 = getelementptr { i64, ptr }, ptr %t612, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t613, !tbaa !37
  %t614 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t615 = load ptr, ptr %t614, !tbaa !27
  %t616 = getelementptr { i64, ptr }, ptr %t615, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t616, !tbaa !37
  %t617 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t618 = load ptr, ptr %t617, !tbaa !27
  %t619 = getelementptr { i64, ptr }, ptr %t618, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t619, !tbaa !37
  %t620 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !27
  %t622 = getelementptr { i64, ptr }, ptr %t621, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t622, !tbaa !37
  %t624 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t625 = load ptr, ptr %t624, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %t625, i64 4
  store { i64, ptr } %t605, ptr %t626, !tbaa !37
  %t628 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = getelementptr { i64, ptr }, ptr %t629, i64 5
  store { i64, ptr } %t606, ptr %t630, !tbaa !37
  %t631 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t632 = call i1 @compiler_2ffetch_2egit(ptr %s19, { i64, ptr } %t631)
  store i1 %t632, ptr %l201
  br label %bb120
bb120:
  %t633 = load i1, ptr %l201, !tbaa !21
  br i1 %t633, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s21
  %t634 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t635 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t636 = mul i64 6, 16
  %t637 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t636)
  %t638 = insertvalue { i64, ptr } undef, i64 6, 0
  %t639 = insertvalue { i64, ptr } %t638, ptr %t637, 1
  store { i64, ptr } %t639, ptr %l204, !tbaa !27
  %t640 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t641 = load ptr, ptr %t640, !tbaa !27
  %t642 = getelementptr { i64, ptr }, ptr %t641, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t642, !tbaa !37
  %t643 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !27
  %t645 = getelementptr { i64, ptr }, ptr %t644, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t645, !tbaa !37
  %t647 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t648 = load ptr, ptr %t647, !tbaa !27
  %t649 = getelementptr { i64, ptr }, ptr %t648, i64 2
  store { i64, ptr } %t634, ptr %t649, !tbaa !37
  %t650 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr { i64, ptr }, ptr %t651, i64 3
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t652, !tbaa !37
  %t653 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !27
  %t655 = getelementptr { i64, ptr }, ptr %t654, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t655, !tbaa !37
  %t657 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !27
  %t659 = getelementptr { i64, ptr }, ptr %t658, i64 5
  store { i64, ptr } %t635, ptr %t659, !tbaa !37
  %t660 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t661 = call i1 @compiler_2ffetch_2egit(ptr %s21, { i64, ptr } %t660)
  store i1 %t661, ptr %l205
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_scope_close(ptr %s21)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s19)
  br label %bb125
bb125:
  %t662 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t664 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %s16, { i64, ptr } %t662)
  store { i64, ptr } %t664, ptr %l207
  br label %bb126
bb126:
  %t665 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t666 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t669 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s16, ptr %s0, { i64, ptr } %t665, { i64, ptr } %t666)
  store i1 %t669, ptr %l210
  br label %bb127
bb127:
  %t670 = load i1, ptr %l210, !tbaa !21
  %t671 = xor i1 %t670, true
  br i1 %t671, label %bb128, label %bb129
bb128:
  %t673 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t675 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t673)
  store i32 %t675, ptr %l213
  %t676 = icmp ne i32 %t675, 0
  br i1 %t676, label %bb131, label %ok.677, !prof !99
ok.677:
  br label %bb130
bb129:
  br label %bb137
bb130:
  br label %bb135
bb131:
  %t678 = load i32, ptr %l213, !tbaa !23
  %t679 = ashr i32 %t678, 16
  %t681 = icmp eq i32 %t679, 1
  store i1 %t681, ptr %l215, !tbaa !21
  %t682 = load i32, ptr %l213, !tbaa !23
  %t683 = ashr i32 %t682, 16
  %t685 = icmp eq i32 %t683, 1
  br i1 %t685, label %bb132, label %bb133
bb132:
  call void @__olang_errpay_pop()
  br label %bb133
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  store i32 65539, ptr %l218, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  store %olang.scope zeroinitializer, ptr %s24
  call void @compiler_2fspin_2eRetitle(ptr %s24, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t687 = load i32, ptr %l218, !tbaa !23
  %t688 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t687, 0
  store { i32, { i64, ptr } } %t688, ptr %rv
  br label %ret
bb137:
  %t689 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t691 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t689)
  store i1 %t691, ptr %l220
  br label %bb138
bb138:
  %t692 = load i1, ptr %l220, !tbaa !21
  %t693 = xor i1 %t692, true
  br i1 %t693, label %bb139, label %bb140
bb139:
  %t695 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t696 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t699 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t695, { i64, ptr } %t696)
  store i32 %t699, ptr %l224
  %t700 = icmp ne i32 %t699, 0
  br i1 %t700, label %bb142, label %ok.701, !prof !99
ok.701:
  br label %bb141
bb140:
  br label %bb154
bb141:
  br label %bb153
bb142:
  %t702 = load i32, ptr %l224, !tbaa !23
  %t703 = ashr i32 %t702, 16
  %t705 = icmp eq i32 %t703, 1
  store i1 %t705, ptr %l226, !tbaa !21
  %t706 = load i32, ptr %l224, !tbaa !23
  %t707 = ashr i32 %t706, 16
  %t709 = icmp eq i32 %t707, 1
  br i1 %t709, label %bb143, label %bb144
bb143:
  call void @__olang_errpay_pop()
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t711 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t713 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t711)
  store i32 %t713, ptr %l230
  %t714 = icmp ne i32 %t713, 0
  br i1 %t714, label %bb147, label %ok.715, !prof !99
ok.715:
  br label %bb146
bb146:
  br label %bb151
bb147:
  %t716 = load i32, ptr %l230, !tbaa !23
  %t717 = ashr i32 %t716, 16
  %t719 = icmp eq i32 %t717, 1
  store i1 %t719, ptr %l232, !tbaa !21
  %t720 = load i32, ptr %l230, !tbaa !23
  %t721 = ashr i32 %t720, 16
  %t723 = icmp eq i32 %t721, 1
  br i1 %t723, label %bb148, label %bb149
bb148:
  call void @__olang_errpay_pop()
  br label %bb149
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  store i32 65539, ptr %l235, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  store %olang.scope zeroinitializer, ptr %s28
  call void @compiler_2fspin_2eRetitle(ptr %s28, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t725 = load i32, ptr %l235, !tbaa !23
  %t726 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t725, 0
  store { i32, { i64, ptr } } %t726, ptr %rv
  br label %ret
bb153:
  br label %bb154
bb154:
  %t727 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t729 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t727)
  store i32 %t729, ptr %l237
  %t730 = icmp ne i32 %t729, 0
  br i1 %t730, label %bb156, label %ok.731, !prof !99
ok.731:
  br label %bb155
bb155:
  br label %bb160
bb156:
  %t732 = load i32, ptr %l237, !tbaa !23
  %t733 = ashr i32 %t732, 16
  %t735 = icmp eq i32 %t733, 1
  store i1 %t735, ptr %l239, !tbaa !21
  %t736 = load i32, ptr %l237, !tbaa !23
  %t737 = ashr i32 %t736, 16
  %t739 = icmp eq i32 %t737, 1
  br i1 %t739, label %bb157, label %bb158
bb157:
  call void @__olang_errpay_pop()
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t741 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t741, ptr %l242, !tbaa !27
  %t742 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t743 = extractvalue { i64, ptr } %t742, 0
  store i64 %t743, ptr %l243, !tbaa !24
  %t744 = load i64, ptr %l243, !tbaa !24
  %t745 = mul i64 %t744, 1
  %t746 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t745)
  %t747 = insertvalue { i64, ptr } undef, i64 %t744, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t746, 1
  store { i64, ptr } %t748, ptr %l244, !tbaa !27
  %t749 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t750 = load ptr, ptr %t749, !tbaa !27
  %t751 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t752 = load ptr, ptr %t751, !tbaa !27
  %t753 = load i64, ptr %l243, !tbaa !24
  %t754 = mul i64 %t753, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t750, ptr %t752, i64 %t754, i1 false)
  %t755 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t755, ptr %l242, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  store %olang.scope zeroinitializer, ptr %s30
  call void @compiler_2fspin_2eRetitle(ptr %s30, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t756 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t757 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t756, 1
  store { i32, { i64, ptr } } %t757, ptr %rv
  br label %ret
bb162:
  %t758 = load ptr, ptr %l0, !tbaa !29
  store ptr %t758, ptr %l245, !tbaa !29
  %t759 = call ptr @__olang_scope_hold(ptr %v0)
  %t760 = ptrtoint ptr %t759 to i64
  store i64 %t760, ptr %l246, !tbaa !24
  %t761 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t761, label %bb163, label %bb164
bb163:
  %t763 = call ptr @__olang_region_make(ptr %v0)
  %t764 = ptrtoint ptr %t763 to i64
  store i64 %t764, ptr %l246, !tbaa !24
  br label %bb164
bb164:
  %t765 = load ptr, ptr %lp8
  %t766 = load { i64, ptr }, ptr %t765, !tbaa !27
  %t767 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t768 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t769 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t771 = extractvalue { i64, ptr } %t766, 1
  %t772 = extractvalue { i64, ptr } %t766, 0
  %t773 = add i64 %t769, %t772
  %t774 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t775 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t776 = add i64 %t773, %t775
  %t778 = extractvalue { i64, ptr } %t767, 1
  %t779 = extractvalue { i64, ptr } %t767, 0
  %t780 = add i64 %t776, %t779
  %t781 = load i64, ptr %l246
  %t782 = inttoptr i64 %t781 to ptr
  %t783 = call ptr @__olang_held_alloc(ptr %t782, i64 %t780)
  call void @olang_textcopy(ptr %t783, ptr %t768, i64 %t769)
  %t784 = getelementptr i8, ptr %t783, i64 %t769
  call void @olang_textcopy(ptr %t784, ptr %t771, i64 %t772)
  %t785 = getelementptr i8, ptr %t784, i64 %t772
  call void @olang_textcopy(ptr %t785, ptr %t774, i64 %t775)
  %t786 = getelementptr i8, ptr %t785, i64 %t775
  call void @olang_textcopy(ptr %t786, ptr %t778, i64 %t779)
  %t787 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t788 = insertvalue { i64, ptr } %t787, ptr %t783, 1
  %t790 = load ptr, ptr %l245, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v0, ptr %t790, { i64, ptr } %t788)
  br label %bb165
bb165:
  %t792 = load i64, ptr %l4, !tbaa !24
  %t793 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t798 = icmp slt i64 %t792, %t795
  br i1 %t798, label %bb166, label %bb167
bb166:
  %t800 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t801 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t802 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t804 = extractvalue { i64, ptr } %t800, 1
  %t805 = extractvalue { i64, ptr } %t800, 0
  %t806 = add i64 %t802, %t805
  %t807 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t806)
  call void @olang_textcopy(ptr %t807, ptr %t801, i64 %t802)
  %t808 = getelementptr i8, ptr %t807, i64 %t802
  call void @olang_textcopy(ptr %t808, ptr %t804, i64 %t805)
  %t809 = insertvalue { i64, ptr } undef, i64 %t806, 0
  %t810 = insertvalue { i64, ptr } %t809, ptr %t807, 1
  store { i64, ptr } %t810, ptr %l256, !tbaa !27
  br label %bb168
bb167:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l256, !tbaa !27
  br label %bb168
bb168:
  %t813 = load { i64, ptr }, ptr %l256, !tbaa !27
  store { i64, ptr } %t813, ptr %l19, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t816 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t814)
  store i32 %t816, ptr %l261
  %t817 = icmp ne i32 %t816, 0
  br i1 %t817, label %bb170, label %ok.818, !prof !99
ok.818:
  br label %bb169
bb169:
  br label %bb174
bb170:
  %t819 = load i32, ptr %l261, !tbaa !23
  %t820 = ashr i32 %t819, 16
  %t822 = icmp eq i32 %t820, 1
  store i1 %t822, ptr %l263, !tbaa !21
  %t823 = load i32, ptr %l261, !tbaa !23
  %t824 = ashr i32 %t823, 16
  %t826 = icmp eq i32 %t824, 1
  br i1 %t826, label %bb171, label %bb172
bb171:
  call void @__olang_errpay_pop()
  br label %bb172
bb172:
  br label %bb173
bb173:
  br label %bb174
bb174:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l266, !tbaa !27
  %t828 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t829 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t829, ptr %lp20
  %t831 = load ptr, ptr %lp20
  store { i64, ptr } %t828, ptr %t831, !tbaa !27
  %t832 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t833 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t834 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t835 = mul i64 9, 16
  %t836 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t835)
  %t837 = insertvalue { i64, ptr } undef, i64 9, 0
  %t838 = insertvalue { i64, ptr } %t837, ptr %t836, 1
  store { i64, ptr } %t838, ptr %l271, !tbaa !27
  %t839 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t840 = load ptr, ptr %t839, !tbaa !27
  %t841 = getelementptr { i64, ptr }, ptr %t840, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t841, !tbaa !37
  %t842 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t843 = load ptr, ptr %t842, !tbaa !27
  %t844 = getelementptr { i64, ptr }, ptr %t843, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t844, !tbaa !37
  %t845 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t846 = load ptr, ptr %t845, !tbaa !27
  %t847 = getelementptr { i64, ptr }, ptr %t846, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t847, !tbaa !37
  %t848 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t849 = load ptr, ptr %t848, !tbaa !27
  %t850 = getelementptr { i64, ptr }, ptr %t849, i64 3
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t850, !tbaa !37
  %t851 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t852 = load ptr, ptr %t851, !tbaa !27
  %t853 = getelementptr { i64, ptr }, ptr %t852, i64 4
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t853, !tbaa !37
  %t855 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !27
  %t857 = getelementptr { i64, ptr }, ptr %t856, i64 5
  store { i64, ptr } %t832, ptr %t857, !tbaa !37
  %t858 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !27
  %t860 = getelementptr { i64, ptr }, ptr %t859, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t860, !tbaa !37
  %t862 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = getelementptr { i64, ptr }, ptr %t863, i64 7
  store { i64, ptr } %t833, ptr %t864, !tbaa !37
  %t866 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t867 = load ptr, ptr %t866, !tbaa !27
  %t868 = getelementptr { i64, ptr }, ptr %t867, i64 8
  store { i64, ptr } %t834, ptr %t868, !tbaa !37
  %t869 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t870 = call i1 @compiler_2ffetch_2egit(ptr %s0, { i64, ptr } %t869)
  store i1 %t870, ptr %l272
  br label %bb175
bb175:
  %t871 = load i1, ptr %l272, !tbaa !21
  br i1 %t871, label %bb176, label %bb177
bb176:
  %t872 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t874 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v0, { i64, ptr } %t872)
  store { i64, ptr } %t874, ptr %l274
  br label %bb178
bb177:
  br label %bb181
bb178:
  %t875 = load ptr, ptr %lp20
  %t876 = load { i64, ptr }, ptr %t875, !tbaa !27
  store { i64, ptr } %t876, ptr %l275, !tbaa !27
  %t877 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t878 = load ptr, ptr %lp20
  store { i64, ptr } %t877, ptr %t878, !tbaa !27
  %t879 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eFetch_2elocal_2e20
  br i1 %t879, label %bb179, label %bb180
bb179:
  %t881 = load { i64, ptr }, ptr %l275
  %t882 = extractvalue { i64, ptr } %t881, 1
  call void @__olang_region_release(ptr %t882)
  store { i64, ptr } zeroinitializer, ptr %l275
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t883 = load ptr, ptr %lp20
  %t884 = load { i64, ptr }, ptr %t883, !tbaa !27
  %t886 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t884, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t886, ptr %l278
  br label %bb182
bb182:
  %t887 = load i1, ptr %l278, !tbaa !21
  br i1 %t887, label %bb183, label %bb184
bb183:
  %t888 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t890 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t888)
  store i32 %t890, ptr %l280
  %t891 = icmp ne i32 %t890, 0
  br i1 %t891, label %bb186, label %ok.892, !prof !99
ok.892:
  br label %bb185
bb184:
  br label %bb192
bb185:
  br label %bb190
bb186:
  %t893 = load i32, ptr %l280, !tbaa !23
  %t894 = ashr i32 %t893, 16
  %t896 = icmp eq i32 %t894, 1
  store i1 %t896, ptr %l282, !tbaa !21
  %t897 = load i32, ptr %l280, !tbaa !23
  %t898 = ashr i32 %t897, 16
  %t900 = icmp eq i32 %t898, 1
  br i1 %t900, label %bb187, label %bb188
bb187:
  call void @__olang_errpay_pop()
  br label %bb188
bb188:
  br label %bb189
bb189:
  br label %bb190
bb190:
  store i32 65538, ptr %l285, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s37
  call void @compiler_2fspin_2eRetitle(ptr %s37, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s0)
  %t902 = load i32, ptr %l285, !tbaa !23
  %t903 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t902, 0
  store { i32, { i64, ptr } } %t903, ptr %rv
  br label %ret
bb192:
  %t904 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t905 = load ptr, ptr %lp20
  %t906 = load { i64, ptr }, ptr %t905, !tbaa !27
  %t908 = extractvalue { i64, ptr } %t904, 1
  %t909 = extractvalue { i64, ptr } %t904, 0
  %t910 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t911 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t912 = add i64 %t909, %t911
  %t914 = extractvalue { i64, ptr } %t906, 1
  %t915 = extractvalue { i64, ptr } %t906, 0
  %t916 = add i64 %t912, %t915
  %t917 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t916)
  call void @olang_textcopy(ptr %t917, ptr %t908, i64 %t909)
  %t918 = getelementptr i8, ptr %t917, i64 %t909
  call void @olang_textcopy(ptr %t918, ptr %t910, i64 %t911)
  %t919 = getelementptr i8, ptr %t918, i64 %t911
  call void @olang_textcopy(ptr %t919, ptr %t914, i64 %t915)
  %t920 = insertvalue { i64, ptr } undef, i64 %t916, 0
  %t921 = insertvalue { i64, ptr } %t920, ptr %t917, 1
  store { i64, ptr } %t921, ptr %l21, !tbaa !27
  %t923 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t925 = call i1 @std_2fos_2eIsDir(ptr %v4, { i64, ptr } %t923)
  store i1 %t925, ptr %l290
  br label %bb193
bb193:
  %t926 = load i1, ptr %l290, !tbaa !21
  br i1 %t926, label %bb194, label %bb195
bb194:
  %t927 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t929 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t927)
  store i32 %t929, ptr %l292
  %t930 = icmp ne i32 %t929, 0
  br i1 %t930, label %bb197, label %ok.931, !prof !99
ok.931:
  br label %bb196
bb195:
  %t932 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t933 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t936 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t932, { i64, ptr } %t933)
  store i32 %t936, ptr %l299
  %t937 = icmp ne i32 %t936, 0
  br i1 %t937, label %bb203, label %ok.938, !prof !99
ok.938:
  br label %bb202
bb196:
  br label %bb201
bb197:
  %t939 = load i32, ptr %l292, !tbaa !23
  %t940 = ashr i32 %t939, 16
  %t942 = icmp eq i32 %t940, 1
  store i1 %t942, ptr %l294, !tbaa !21
  %t943 = load i32, ptr %l292, !tbaa !23
  %t944 = ashr i32 %t943, 16
  %t946 = icmp eq i32 %t944, 1
  br i1 %t946, label %bb198, label %bb199
bb198:
  call void @__olang_errpay_pop()
  br label %bb199
bb199:
  br label %bb200
bb200:
  br label %bb201
bb201:
  br label %bb215
bb202:
  br label %bb214
bb203:
  %t948 = load i32, ptr %l299, !tbaa !23
  %t949 = ashr i32 %t948, 16
  %t951 = icmp eq i32 %t949, 1
  store i1 %t951, ptr %l301, !tbaa !21
  %t952 = load i32, ptr %l299, !tbaa !23
  %t953 = ashr i32 %t952, 16
  %t955 = icmp eq i32 %t953, 1
  br i1 %t955, label %bb204, label %bb205
bb204:
  call void @__olang_errpay_pop()
  br label %bb205
bb205:
  br label %bb206
bb206:
  %t957 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t959 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t957)
  store i32 %t959, ptr %l305
  %t960 = icmp ne i32 %t959, 0
  br i1 %t960, label %bb208, label %ok.961, !prof !99
ok.961:
  br label %bb207
bb207:
  br label %bb212
bb208:
  %t962 = load i32, ptr %l305, !tbaa !23
  %t963 = ashr i32 %t962, 16
  %t965 = icmp eq i32 %t963, 1
  store i1 %t965, ptr %l307, !tbaa !21
  %t966 = load i32, ptr %l305, !tbaa !23
  %t967 = ashr i32 %t966, 16
  %t969 = icmp eq i32 %t967, 1
  br i1 %t969, label %bb209, label %bb210
bb209:
  call void @__olang_errpay_pop()
  br label %bb210
bb210:
  br label %bb211
bb211:
  br label %bb212
bb212:
  store i32 65538, ptr %l310, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s44
  call void @compiler_2fspin_2eRetitle(ptr %s44, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s0)
  %t971 = load i32, ptr %l310, !tbaa !23
  %t972 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t971, 0
  store { i32, { i64, ptr } } %t972, ptr %rv
  br label %ret
bb214:
  br label %bb215
bb215:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t974 = load ptr, ptr %lp8
  %t975 = load { i64, ptr }, ptr %t974, !tbaa !27
  %t976 = load ptr, ptr %lp20
  %t977 = load { i64, ptr }, ptr %t976, !tbaa !27
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v0, ptr %v0, ptr %t973, { i64, ptr } %t975, { i64, ptr } %t977)
  br label %bb216
bb216:
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t983 = getelementptr %"compiler/fetch:Fetcher", ptr %t981, i32 0, i32 3
  %t984 = load i1, ptr %t983, !tbaa !21
  br i1 %t984, label %bb217, label %bb218
bb217:
  store %olang.scope zeroinitializer, ptr %s45
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t987 = load ptr, ptr %lp8
  %t988 = load { i64, ptr }, ptr %t987, !tbaa !27
  %t991 = call i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v0, ptr %t986, { i64, ptr } %t988, i1 true)
  store i1 %t991, ptr %l318
  br label %bb219
bb218:
  br label %bb270
bb219:
  %t992 = load i1, ptr %l14, !tbaa !21
  br i1 %t992, label %bb220, label %bb221
bb220:
  %t994 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t996 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s45, { i64, ptr } %t994, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t996, ptr %l322
  br label %bb222
bb221:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb223
bb222:
  %t997 = load i1, ptr %l322, !tbaa !21
  store i1 %t997, ptr %l320, !tbaa !21
  br label %bb223
bb223:
  %t998 = load i1, ptr %l320, !tbaa !21
  br i1 %t998, label %bb224, label %bb225
bb224:
  %t999 = load ptr, ptr %l0, !tbaa !29
  store ptr %t999, ptr %l323, !tbaa !29
  %t1000 = call ptr @__olang_scope_hold(ptr %v0)
  %t1001 = ptrtoint ptr %t1000 to i64
  store i64 %t1001, ptr %l324, !tbaa !24
  %t1002 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1002, label %bb226, label %bb227
bb225:
  %t1004 = load i1, ptr %l14, !tbaa !21
  br i1 %t1004, label %bb235, label %bb236
bb226:
  %t1006 = call ptr @__olang_region_make(ptr %v0)
  %t1007 = ptrtoint ptr %t1006 to i64
  store i64 %t1007, ptr %l324, !tbaa !24
  br label %bb227
bb227:
  %t1008 = load ptr, ptr %lp8
  %t1009 = load { i64, ptr }, ptr %t1008, !tbaa !27
  store { i64, ptr } %t1009, ptr %l326, !tbaa !27
  %t1010 = load ptr, ptr %lp20
  %t1011 = load { i64, ptr }, ptr %t1010, !tbaa !27
  %t1012 = extractvalue { i64, ptr } %t1011, 0
  store i64 %t1012, ptr %l327, !tbaa !24
  %t1013 = icmp sge i64 0, 0
  br i1 %t1013, label %bb228, label %bb229
bb228:
  %t1015 = icmp sle i64 0, 12
  br i1 %t1015, label %bb230, label %bb231
bb229:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb230:
  %t1017 = load i64, ptr %l327, !tbaa !24
  %t1018 = icmp sle i64 12, %t1017
  br i1 %t1018, label %bb232, label %bb233
bb231:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb232:
  %t1020 = load ptr, ptr %lp20
  %t1021 = getelementptr { i64, ptr }, ptr %t1020, i32 0, i32 1
  %t1022 = load ptr, ptr %t1021, !tbaa !27
  %t1023 = getelementptr i8, ptr %t1022, i64 0
  %t1024 = sub i64 12, 0
  %t1025 = insertvalue { i64, ptr } undef, i64 %t1024, 0
  %t1026 = insertvalue { i64, ptr } %t1025, ptr %t1023, 1
  %t1027 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t1028 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t1029 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t1030 = extractvalue { i64, ptr } %t1029, 1
  %t1031 = extractvalue { i64, ptr } %t1029, 0
  %t1032 = add i64 %t1028, %t1031
  %t1033 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t1034 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t1035 = add i64 %t1032, %t1034
  %t1037 = extractvalue { i64, ptr } %t1026, 1
  %t1038 = extractvalue { i64, ptr } %t1026, 0
  %t1039 = add i64 %t1035, %t1038
  %t1040 = load i64, ptr %l324
  %t1041 = inttoptr i64 %t1040 to ptr
  %t1042 = call ptr @__olang_held_alloc(ptr %t1041, i64 %t1039)
  call void @olang_textcopy(ptr %t1042, ptr %t1027, i64 %t1028)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1028
  call void @olang_textcopy(ptr %t1043, ptr %t1030, i64 %t1031)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1031
  call void @olang_textcopy(ptr %t1044, ptr %t1033, i64 %t1034)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1034
  call void @olang_textcopy(ptr %t1045, ptr %t1037, i64 %t1038)
  %t1046 = insertvalue { i64, ptr } undef, i64 %t1039, 0
  %t1047 = insertvalue { i64, ptr } %t1046, ptr %t1042, 1
  %t1049 = load ptr, ptr %l323, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v0, ptr %t1049, { i64, ptr } %t1047)
  br label %bb234
bb233:
  call void @__olang_check_failed(ptr @olang_loc_461a8d3078b45b75_287f37f9c7026b71)
  unreachable
bb234:
  br label %bb269
bb235:
  %t1051 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1052 = load ptr, ptr %lp20
  %t1053 = load { i64, ptr }, ptr %t1052, !tbaa !27
  %t1056 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v0, { i64, ptr } %t1051, { i64, ptr } %t1053)
  store i1 %t1056, ptr %l338
  br label %bb237
bb236:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb238
bb237:
  %t1057 = load i1, ptr %l338, !tbaa !21
  %t1058 = xor i1 %t1057, true
  store i1 %t1058, ptr %l335, !tbaa !21
  br label %bb238
bb238:
  %t1060 = load i1, ptr %l335, !tbaa !21
  br i1 %t1060, label %bb239, label %bb240
bb239:
  %t1061 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1061, ptr %l340, !tbaa !29
  %t1062 = call ptr @__olang_scope_hold(ptr %v0)
  %t1063 = ptrtoint ptr %t1062 to i64
  store i64 %t1063, ptr %l341, !tbaa !24
  %t1064 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1064, label %bb241, label %bb242
bb240:
  %t1066 = load i1, ptr %l14, !tbaa !21
  br i1 %t1066, label %bb256, label %bb257
bb241:
  %t1068 = call ptr @__olang_region_make(ptr %v0)
  %t1069 = ptrtoint ptr %t1068 to i64
  store i64 %t1069, ptr %l341, !tbaa !24
  br label %bb242
bb242:
  %t1070 = load ptr, ptr %lp8
  %t1071 = load { i64, ptr }, ptr %t1070, !tbaa !27
  store { i64, ptr } %t1071, ptr %l343, !tbaa !27
  %t1072 = load ptr, ptr %lp20
  %t1073 = load { i64, ptr }, ptr %t1072, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  store i64 %t1074, ptr %l344, !tbaa !24
  %t1075 = icmp sge i64 0, 0
  br i1 %t1075, label %bb243, label %bb244
bb243:
  %t1077 = icmp sle i64 0, 12
  br i1 %t1077, label %bb245, label %bb246
bb244:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb245:
  %t1079 = load i64, ptr %l344, !tbaa !24
  %t1080 = icmp sle i64 12, %t1079
  br i1 %t1080, label %bb247, label %bb248
bb246:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb247:
  %t1082 = load ptr, ptr %lp20
  %t1083 = getelementptr { i64, ptr }, ptr %t1082, i32 0, i32 1
  %t1084 = load ptr, ptr %t1083, !tbaa !27
  %t1085 = getelementptr i8, ptr %t1084, i64 0
  %t1086 = sub i64 12, 0
  %t1087 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1088 = insertvalue { i64, ptr } %t1087, ptr %t1085, 1
  store { i64, ptr } %t1088, ptr %l348, !tbaa !27
  %t1089 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1090 = extractvalue { i64, ptr } %t1089, 0
  store i64 %t1090, ptr %l349, !tbaa !24
  %t1091 = icmp sge i64 0, 0
  br i1 %t1091, label %bb249, label %bb250
bb248:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb249:
  %t1093 = icmp sle i64 0, 12
  br i1 %t1093, label %bb251, label %bb252
bb250:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb251:
  %t1095 = load i64, ptr %l349, !tbaa !24
  %t1096 = icmp sle i64 12, %t1095
  br i1 %t1096, label %bb253, label %bb254
bb252:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb253:
  %t1098 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t1099 = load ptr, ptr %t1098, !tbaa !27
  %t1100 = getelementptr i8, ptr %t1099, i64 0
  %t1101 = sub i64 12, 0
  %t1102 = insertvalue { i64, ptr } undef, i64 %t1101, 0
  %t1103 = insertvalue { i64, ptr } %t1102, ptr %t1100, 1
  %t1104 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t1105 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t1106 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t1107 = extractvalue { i64, ptr } %t1106, 1
  %t1108 = extractvalue { i64, ptr } %t1106, 0
  %t1109 = add i64 %t1105, %t1108
  %t1110 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t1111 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t1112 = add i64 %t1109, %t1111
  %t1113 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t1114 = extractvalue { i64, ptr } %t1113, 1
  %t1115 = extractvalue { i64, ptr } %t1113, 0
  %t1116 = add i64 %t1112, %t1115
  %t1117 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t1118 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t1119 = add i64 %t1116, %t1118
  %t1121 = extractvalue { i64, ptr } %t1103, 1
  %t1122 = extractvalue { i64, ptr } %t1103, 0
  %t1123 = add i64 %t1119, %t1122
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t1125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t1126 = add i64 %t1123, %t1125
  %t1127 = load i64, ptr %l341
  %t1128 = inttoptr i64 %t1127 to ptr
  %t1129 = call ptr @__olang_held_alloc(ptr %t1128, i64 %t1126)
  call void @olang_textcopy(ptr %t1129, ptr %t1104, i64 %t1105)
  %t1130 = getelementptr i8, ptr %t1129, i64 %t1105
  call void @olang_textcopy(ptr %t1130, ptr %t1107, i64 %t1108)
  %t1131 = getelementptr i8, ptr %t1130, i64 %t1108
  call void @olang_textcopy(ptr %t1131, ptr %t1110, i64 %t1111)
  %t1132 = getelementptr i8, ptr %t1131, i64 %t1111
  call void @olang_textcopy(ptr %t1132, ptr %t1114, i64 %t1115)
  %t1133 = getelementptr i8, ptr %t1132, i64 %t1115
  call void @olang_textcopy(ptr %t1133, ptr %t1117, i64 %t1118)
  %t1134 = getelementptr i8, ptr %t1133, i64 %t1118
  call void @olang_textcopy(ptr %t1134, ptr %t1121, i64 %t1122)
  %t1135 = getelementptr i8, ptr %t1134, i64 %t1122
  call void @olang_textcopy(ptr %t1135, ptr %t1124, i64 %t1125)
  %t1136 = insertvalue { i64, ptr } undef, i64 %t1126, 0
  %t1137 = insertvalue { i64, ptr } %t1136, ptr %t1129, 1
  %t1139 = load ptr, ptr %l340, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v0, ptr %t1139, { i64, ptr } %t1137)
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_64bbdb9c4083d73a_45ec4fce431b420e)
  unreachable
bb255:
  br label %bb268
bb256:
  %t1141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1141, ptr %l357, !tbaa !29
  %t1142 = call ptr @__olang_scope_hold(ptr %v0)
  %t1143 = ptrtoint ptr %t1142 to i64
  store i64 %t1143, ptr %l358, !tbaa !24
  %t1144 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t1144, label %bb258, label %bb259
bb257:
  br label %bb267
bb258:
  %t1146 = call ptr @__olang_region_make(ptr %v0)
  %t1147 = ptrtoint ptr %t1146 to i64
  store i64 %t1147, ptr %l358, !tbaa !24
  br label %bb259
bb259:
  %t1148 = load ptr, ptr %lp8
  %t1149 = load { i64, ptr }, ptr %t1148, !tbaa !27
  store { i64, ptr } %t1149, ptr %l360, !tbaa !27
  %t1150 = load ptr, ptr %lp20
  %t1151 = load { i64, ptr }, ptr %t1150, !tbaa !27
  %t1152 = extractvalue { i64, ptr } %t1151, 0
  store i64 %t1152, ptr %l361, !tbaa !24
  %t1153 = icmp sge i64 0, 0
  br i1 %t1153, label %bb260, label %bb261
bb260:
  %t1155 = icmp sle i64 0, 12
  br i1 %t1155, label %bb262, label %bb263
bb261:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb262:
  %t1157 = load i64, ptr %l361, !tbaa !24
  %t1158 = icmp sle i64 12, %t1157
  br i1 %t1158, label %bb264, label %bb265
bb263:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb264:
  %t1160 = load ptr, ptr %lp20
  %t1161 = getelementptr { i64, ptr }, ptr %t1160, i32 0, i32 1
  %t1162 = load ptr, ptr %t1161, !tbaa !27
  %t1163 = getelementptr i8, ptr %t1162, i64 0
  %t1164 = sub i64 12, 0
  %t1165 = insertvalue { i64, ptr } undef, i64 %t1164, 0
  %t1166 = insertvalue { i64, ptr } %t1165, ptr %t1163, 1
  %t1167 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t1168 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t1169 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t1170 = extractvalue { i64, ptr } %t1169, 1
  %t1171 = extractvalue { i64, ptr } %t1169, 0
  %t1172 = add i64 %t1168, %t1171
  %t1173 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t1174 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t1175 = add i64 %t1172, %t1174
  %t1177 = extractvalue { i64, ptr } %t1166, 1
  %t1178 = extractvalue { i64, ptr } %t1166, 0
  %t1179 = add i64 %t1175, %t1178
  %t1180 = load i64, ptr %l358
  %t1181 = inttoptr i64 %t1180 to ptr
  %t1182 = call ptr @__olang_held_alloc(ptr %t1181, i64 %t1179)
  call void @olang_textcopy(ptr %t1182, ptr %t1167, i64 %t1168)
  %t1183 = getelementptr i8, ptr %t1182, i64 %t1168
  call void @olang_textcopy(ptr %t1183, ptr %t1170, i64 %t1171)
  %t1184 = getelementptr i8, ptr %t1183, i64 %t1171
  call void @olang_textcopy(ptr %t1184, ptr %t1173, i64 %t1174)
  %t1185 = getelementptr i8, ptr %t1184, i64 %t1174
  call void @olang_textcopy(ptr %t1185, ptr %t1177, i64 %t1178)
  %t1186 = insertvalue { i64, ptr } undef, i64 %t1179, 0
  %t1187 = insertvalue { i64, ptr } %t1186, ptr %t1182, 1
  %t1189 = load ptr, ptr %l357, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v0, ptr %t1189, { i64, ptr } %t1187)
  br label %bb266
bb265:
  call void @__olang_check_failed(ptr @olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b)
  unreachable
bb266:
  br label %bb267
bb267:
  br label %bb268
bb268:
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s45)
  br label %bb270
bb270:
  %t1191 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t1191, ptr %l368, !tbaa !27
  %t1192 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t1193 = extractvalue { i64, ptr } %t1192, 0
  store i64 %t1193, ptr %l369, !tbaa !24
  %t1194 = load i64, ptr %l369, !tbaa !24
  %t1195 = mul i64 %t1194, 1
  %t1196 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t1195)
  %t1197 = insertvalue { i64, ptr } undef, i64 %t1194, 0
  %t1198 = insertvalue { i64, ptr } %t1197, ptr %t1196, 1
  store { i64, ptr } %t1198, ptr %l370, !tbaa !27
  %t1199 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t1200 = load ptr, ptr %t1199, !tbaa !27
  %t1201 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t1202 = load ptr, ptr %t1201, !tbaa !27
  %t1203 = load i64, ptr %l369, !tbaa !24
  %t1204 = mul i64 %t1203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1200, ptr %t1202, i64 %t1204, i1 false)
  %t1205 = load { i64, ptr }, ptr %l370, !tbaa !27
  store { i64, ptr } %t1205, ptr %l368, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s54
  call void @compiler_2fspin_2eRetitle(ptr %s54, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb271
bb271:
  call void @__olang_scope_close(ptr %s54)
  call void @__olang_scope_close(ptr %s0)
  %t1206 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t1207 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t1206, 1
  store { i32, { i64, ptr } } %t1207, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eLocked(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l18, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l39
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %a1)
  store i1 %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load i1, ptr %l41, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/fetch:Fetcher", ptr %t67, i32 0, i32 7
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v2, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t74, 1
  store { i32, { i64, ptr } } %t75, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  %t82 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l24 = alloca %"std/prelude/text:LineIter"
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i64
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l78 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/fetch:Fetcher", ptr %t6, i32 0, i32 5
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/fetch:Fetcher", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb5, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l17
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l20, !tbaa !21
  %t24 = load i32, ptr %l18, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t32 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t29)
  store %"std/prelude/text:LineIter" %t32, ptr %l24
  br label %bb10
bb10:
  %t33 = load %"std/prelude/text:LineIter", ptr %l24
  store %"std/prelude/text:LineIter" %t33, ptr %l2
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l2)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l28
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb13, label %ok.39, !prof !99
ok.39:
  store { i64, ptr } %t36, ptr %l27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t40, ptr %l25, !tbaa !27
  br label %bb15
bb13:
  %t41 = load i32, ptr %l28, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb63
bb15:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t46, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t48, ptr %l32
  br label %bb16
bb16:
  %t49 = load i1, ptr %l32, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb18:
  br label %bb19
bb19:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t50)
  store { i64, ptr } %t52, ptr %l34
  br label %bb20
bb20:
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t54 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t53, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l35
  br label %bb21
bb21:
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t57, ptr %lp5
  %t59 = load ptr, ptr %lp5
  store { i64, ptr } %t56, ptr %t59, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t61, ptr %lp6
  %t63 = load ptr, ptr %lp6
  store { i64, ptr } %t60, ptr %t63, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb24:
  br label %bb25
bb25:
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t78, ptr %l47, !tbaa !27
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %t82, i64 %t79
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !37
  store { i64, ptr } %t84, ptr %l10, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s7, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t88, ptr %l51
  br label %bb26
bb26:
  %t89 = load i1, ptr %l51, !tbaa !21
  br i1 %t89, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb28:
  br label %bb29
bb29:
  %t90 = load ptr, ptr %lp5
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t93, ptr %l53
  br label %bb30
bb30:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = call ptr @__olang_scope_hold(ptr %v0)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e5
  br i1 %t97, label %bb33, label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t99 = load ptr, ptr %lp6
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t100, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t102, ptr %l64
  br label %bb41
bb33:
  %t103 = call ptr @__olang_region_make(ptr %v0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l54, !tbaa !24
  br label %bb34
bb34:
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = load i64, ptr %l54
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_held_alloc(ptr %t110, i64 %t108)
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l57, !tbaa !27
  %t114 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e5
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t116 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t119 = icmp eq i64 %t117, 0
  br i1 %t119, label %bb37, label %bb38
bb36:
  %t121 = load ptr, ptr %lp5
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l61, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t124 = load ptr, ptr %lp5
  store { i64, ptr } %t123, ptr %t124, !tbaa !27
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e5
  br i1 %t125, label %bb39, label %bb40
bb37:
  store { i64, ptr } zeroinitializer, ptr %l57, !tbaa !27
  br label %bb38
bb38:
  %t127 = load i64, ptr %l54
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = load { i64, ptr }, ptr %l57
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr null
  call void @__olang_region_settle_in(ptr %t128, ptr %t133)
  br label %bb36
bb39:
  %t134 = load { i64, ptr }, ptr %l61
  %t135 = extractvalue { i64, ptr } %t134, 1
  call void @__olang_region_release(ptr %t135)
  store { i64, ptr } zeroinitializer, ptr %l61
  br label %bb40
bb40:
  br label %bb53
bb41:
  %t136 = load i1, ptr %l64, !tbaa !21
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t137 = call ptr @__olang_scope_hold(ptr %v0)
  %t138 = ptrtoint ptr %t137 to i64
  store i64 %t138, ptr %l65, !tbaa !24
  %t139 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e6
  br i1 %t139, label %bb44, label %bb45
bb43:
  br label %bb52
bb44:
  %t141 = call ptr @__olang_region_make(ptr %v0)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l65, !tbaa !24
  br label %bb45
bb45:
  %t143 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = load i64, ptr %l65
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l68, !tbaa !27
  %t152 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e6
  br i1 %t152, label %bb46, label %bb47
bb46:
  %t154 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t157 = icmp eq i64 %t155, 0
  br i1 %t157, label %bb48, label %bb49
bb47:
  %t159 = load ptr, ptr %lp6
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l72, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t162 = load ptr, ptr %lp6
  store { i64, ptr } %t161, ptr %t162, !tbaa !27
  %t163 = load i1, ptr @olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e6
  br i1 %t163, label %bb50, label %bb51
bb48:
  store { i64, ptr } zeroinitializer, ptr %l68, !tbaa !27
  br label %bb49
bb49:
  %t165 = load i64, ptr %l65
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = load { i64, ptr }, ptr %l68
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = call ptr @__olang_region_or(ptr %t168, ptr null)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_settle_in(ptr %t166, ptr %t171)
  br label %bb47
bb50:
  %t172 = load { i64, ptr }, ptr %l72
  %t173 = extractvalue { i64, ptr } %t172, 1
  call void @__olang_region_release(ptr %t173)
  store { i64, ptr } zeroinitializer, ptr %l72
  br label %bb51
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb54:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l8, !tbaa !24
  br label %bb22
bb55:
  %t179 = load ptr, ptr %lp6
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t180, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t182, ptr %l78
  br label %bb56
bb56:
  %t183 = load i1, ptr %l78, !tbaa !21
  br i1 %t183, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/fetch:Fetcher", ptr %t184, i32 0, i32 6
  %t187 = load ptr, ptr %lp5
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t186, { i64, ptr } %t188)
  br label %bb60
bb60:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/fetch:Fetcher", ptr %t191, i32 0, i32 7
  %t194 = load ptr, ptr %lp6
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t193, { i64, ptr } %t195)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb62:
  br label %bb11
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2elock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l62 = alloca i1
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i1
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l159 = alloca i32
  %l161 = alloca i1
  %s0 = alloca %olang.scope
  %t207 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eload(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/fetch:Fetcher", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l25
  br label %bb2
bb2:
  %t8 = load i64, ptr %l25, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l32, !tbaa !24
  store i64 %t35, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/fetch:Fetcher", ptr %t55, i32 0, i32 6
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l53
  br label %bb13
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t62)
  store i1 %t65, ptr %l55
  br label %bb14
bb14:
  %t66 = load i1, ptr %l55, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/fetch:Fetcher", ptr %t78, i32 0, i32 7
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store { i64, ptr } %t84, ptr %l66
  br label %bb22
bb21:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb24
bb22:
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t86, { i64, ptr } %t85)
  store i1 %t88, ptr %l68
  br label %bb23
bb23:
  %t89 = load i1, ptr %l68, !tbaa !21
  store i1 %t89, ptr %l62, !tbaa !21
  br label %bb24
bb24:
  %t90 = load i1, ptr %l62, !tbaa !21
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/fetch:Fetcher", ptr %t95, i32 0, i32 7
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v2, ptr %t97, i64 %t98, { i64, ptr } %t99)
  br label %bb30
bb29:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/fetch:Fetcher", ptr %t103, i32 0, i32 6
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t105, { i64, ptr } %t106)
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/fetch:Fetcher", ptr %t109, i32 0, i32 7
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v2, ptr %t111, { i64, ptr } %t112)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/fetch:Fetcher", ptr %t115, i32 0, i32 6
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l83
  br label %bb34
bb34:
  %t120 = load i64, ptr %l83, !tbaa !24
  %t121 = icmp sge i64 %t120, 0
  br i1 %t121, label %bb35, label %bb36
bb35:
  %t123 = load i64, ptr %l83, !tbaa !24
  %t124 = icmp sle i64 %t123, 1152921504606846975
  br i1 %t124, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb37:
  %t126 = load i64, ptr %l83, !tbaa !24
  %t127 = mul i64 %t126, 8
  %t128 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp sgt i64 %t136, %t137
  br i1 %t140, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ba721b6722bc57b1_efdace1c8e747995)
  unreachable
bb39:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  br i1 %t144, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb44
bb41:
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = sub i64 %t146, %t147
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t156 = sub i64 %t154, 1
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = sdiv i64 %t156, %t157
  store i64 %t160, ptr %l95, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb43
bb43:
  %t162 = load i64, ptr %l95, !tbaa !24
  store i64 %t162, ptr %l92, !tbaa !24
  br label %bb44
bb44:
  %t163 = load i64, ptr %l92, !tbaa !24
  store i64 %t163, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = sub i64 %t164, 1
  store i64 %t165, ptr %l104, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t167 = icmp slt i64 %t166, 2147483648
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp sge i64 %t168, 0
  %t172 = and i1 %t167, %t169
  store i1 %t172, ptr %l107, !tbaa !21
  br label %bb45
bb45:
  %t173 = load i64, ptr %l15, !tbaa !24
  %t174 = load i64, ptr %l14, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t183 = load i64, ptr %l13, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l16, !tbaa !24
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i64, ptr %t196, i64 %t191
  store i64 %t192, ptr %t197, !tbaa !34
  br label %bb49
bb49:
  %t198 = load i64, ptr %l15, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l15, !tbaa !24
  br label %bb45
bb50:
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t206 = ptrtoint ptr %t205 to i64
  %t208 = getelementptr { ptr, ptr }, ptr %t207, i32 0, i32 0
  store ptr %t204, ptr %t208, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t210 = call ptr @__olang_scope_hold(ptr %v0)
  %t211 = getelementptr { ptr, ptr }, ptr %t207, i32 0, i32 1
  store ptr %t210, ptr %t211, !tbaa !28
  %t212 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_74, 0
  %t213 = insertvalue { ptr, ptr } %t212, ptr %t207, 1
  %t216 = extractvalue { ptr, ptr } %t213, 0
  %t217 = extractvalue { ptr, ptr } %t213, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t203, ptr %t216, ptr %t217)
  br label %bb51
bb51:
  %t218 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t218, ptr %l125
  br label %bb52
bb52:
  %t219 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t219, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb53
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb54
bb54:
  %t222 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t222, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l20, !tbaa !24
  br label %bb55
bb55:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb56, label %bb57
bb56:
  br label %bb66
bb57:
  br label %bb58
bb58:
  %t236 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t236, ptr %l135, !tbaa !27
  %t237 = load i64, ptr %l19, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i64, ptr %t240, i64 %t237
  %t242 = load i64, ptr %t241, !tbaa !34
  store i64 %t242, ptr %l21, !tbaa !24
  store ptr %l17, ptr %l138, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/fetch:Fetcher", ptr %t244, i32 0, i32 6
  %t247 = load i64, ptr %l21, !tbaa !24
  %t250 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t246, i64 %t247)
  store { i64, ptr } %t250, ptr %l142
  br label %bb59
bb59:
  %t251 = load ptr, ptr %l138, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l142, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t251, { i64, ptr } %t252)
  br label %bb60
bb60:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 32)
  br label %bb61
bb61:
  store ptr %l17, ptr %l144, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/fetch:Fetcher", ptr %t254, i32 0, i32 7
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t256, i64 %t257)
  store { i64, ptr } %t260, ptr %l148
  br label %bb62
bb62:
  %t261 = load ptr, ptr %l144, !tbaa !29
  %t262 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t261, { i64, ptr } %t262)
  br label %bb63
bb63:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l17, i8 10)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t264 = load i64, ptr %l19, !tbaa !24
  %t267 = add i64 %t264, 1
  store i64 %t267, ptr %l19, !tbaa !24
  br label %bb55
bb66:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/fetch:Fetcher", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l154, !tbaa !27
  %t274 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t274, ptr %l156
  br label %bb67
bb67:
  %t275 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t285 = call i32 @std_2fos_2eWriteFile(ptr %v0, ptr %s0, { i64, ptr } %t283, { i64, ptr } %t282)
  store i32 %t285, ptr %l159
  %t286 = icmp ne i32 %t285, 0
  br i1 %t286, label %bb69, label %ok.287, !prof !99
ok.287:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t288 = load i32, ptr %l159, !tbaa !23
  %t289 = ashr i32 %t288, 16
  %t291 = icmp eq i32 %t289, 1
  store i1 %t291, ptr %l161, !tbaa !21
  %t292 = load i32, ptr %l159, !tbaa !23
  %t293 = ashr i32 %t292, 16
  %t295 = icmp eq i32 %t293, 1
  br i1 %t295, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2esay(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/fetch:Fetcher", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = getelementptr i8, ptr %t22, i64 %t18
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  call void @compiler_2fspin_2eSay(ptr %s1, i32 %t14, { i64, ptr } %t25)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eupdatedNow(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t20, { i64, ptr } %t22)
  store i1 %t25, ptr %l18
  br label %bb7
bb7:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb1
bb12:
  br i1 %a2, label %bb13, label %bb14
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/fetch:Fetcher", ptr %t35, i32 0, i32 8
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t37, { i64, ptr } %t38)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffetch_2egit(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l6 = alloca i32
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t4 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t3, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  %t5 = extractvalue { i32, %"std/os:Output" } %t4, 1
  %t6 = extractvalue { i32, %"std/os:Output" } %t4, 0
  store i32 %t6, ptr %l6
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store %"std/os:Output" %t5, ptr %l5
  br label %bb1
bb1:
  %t9 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t9, ptr %l2
  br label %bb6
bb2:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t20 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t20, ptr %l1
  %t21 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = icmp eq i32 %t22, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2ehead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca [5 x { i64, ptr }]
  %l3 = alloca %"std/os:Output"
  %l4 = alloca { i64, ptr }
  %l7 = alloca %"std/os:Output"
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/os:Output"
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t10 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t11 = insertvalue [5 x { i64, ptr }] %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t13 = insertvalue [5 x { i64, ptr }] %t11, { i64, ptr } %t7, 2
  %t14 = insertvalue [5 x { i64, ptr }] %t13, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d82, i32 0, i32 1) }, 3
  %t15 = insertvalue [5 x { i64, ptr }] %t14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) }, 4
  store [5 x { i64, ptr }] %t15, ptr %l2
  %t18 = insertvalue { i64, ptr } undef, i64 5, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l2, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t21, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  %t23 = extractvalue { i32, %"std/os:Output" } %t22, 1
  %t24 = extractvalue { i32, %"std/os:Output" } %t22, 0
  store i32 %t24, ptr %l14
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb2, label %ok.26, !prof !99
ok.26:
  store %"std/os:Output" %t23, ptr %l13
  br label %bb1
bb1:
  %t27 = load %"std/os:Output", ptr %l13
  store %"std/os:Output" %t27, ptr %l7
  br label %bb6
bb2:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l16, !tbaa !21
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l20, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l22, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t51, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb6:
  %t53 = load %"std/os:Output", ptr %l7
  store %"std/os:Output" %t53, ptr %l3
  %t54 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = icmp ne i32 %t55, 0
  br i1 %t57, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %l26, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l28, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l27, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t73, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t75 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t76)
  store { i64, ptr } %t78, ptr %l30
  br label %bb10
bb10:
  %t79 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t79, ptr %l4, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = call i1 @compiler_2ffetch_2eIsCommit(ptr %s0, { i64, ptr } %t80)
  store i1 %t82, ptr %l32
  br label %bb11
bb11:
  %t83 = load i1, ptr %l32, !tbaa !21
  br i1 %t83, label %bb12, label %bb13
bb12:
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l33, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t92, ptr %l33, !tbaa !27
  br label %bb14
bb14:
  %t94 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l38, !tbaa !24
  %t96 = load i64, ptr %l38, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l39, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l38, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t107, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffetch_2emakeRepo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t19)
  store i32 %t21, ptr %l9
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23, !prof !99
ok.23:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  store i1 %t27, ptr %l11, !tbaa !21
  %t28 = load i32, ptr %l9, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t33, ptr %l15, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l16, !tbaa !24
  %t36 = load i64, ptr %l16, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l17, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t47, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = getelementptr i8, ptr %t56, i64 %t52
  call void @olang_textcopy(ptr %t57, ptr %t53, i64 %t54)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t65 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t59, { i64, ptr } %a2)
  store i32 %t65, ptr %l23
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb8, label %ok.67, !prof !99
ok.67:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t68 = load i32, ptr %l23, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  store i1 %t71, ptr %l25, !tbaa !21
  %t72 = load i32, ptr %l23, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t77, ptr %l29, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l30, !tbaa !24
  %t80 = load i64, ptr %l30, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l31, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l30, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t91, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb12:
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t95 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x { i64, ptr }] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t95, ptr %l33
  br label %bb13
bb13:
  %t96 = load i1, ptr %l33, !tbaa !21
  br i1 %t96, label %bb14, label %bb15
bb14:
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x { i64, ptr }] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t99, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  %t100 = load i1, ptr %l36, !tbaa !21
  store i1 %t100, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t101 = load i1, ptr %l34, !tbaa !21
  br i1 %t101, label %bb18, label %bb19
bb18:
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = call i1 @compiler_2ffetch_2esh(ptr %s0, ptr %s0, { i64, ptr } %t102, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x { i64, ptr }] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t104, ptr %l39
  br label %bb20
bb19:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  %t105 = load i1, ptr %l39, !tbaa !21
  store i1 %t105, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t106 = load i1, ptr %l37, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t111 = call { i64, ptr } @compiler_2ffetch_2ehead(ptr %s0, ptr %v3, { i64, ptr } %t109)
  store { i64, ptr } %t111, ptr %l43
  br label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t112, ptr %l41, !tbaa !27
  br label %bb25
bb24:
  %t114 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t114, ptr %l41, !tbaa !27
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l46, !tbaa !24
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l47, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l46, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t128, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"compiler/fetch:Fetcher"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i1 %a3, ptr %l8, !tbaa !21
  store i1 %a4, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t11 = call ptr @__olang_scope_hold(ptr %v3)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l20, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e6
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = call ptr @__olang_region_make(ptr %v3)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l20, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l20
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l22
  br label %bb3
bb3:
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e6
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l20
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  call void @__olang_region_settle_in(ptr %t23, ptr %t30)
  br label %bb5
bb5:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l11
  %t32 = call ptr @__olang_scope_hold(ptr %v3)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l24, !tbaa !24
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e7
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = call ptr @__olang_region_make(ptr %v3)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l24
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t39, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l26
  br label %bb8
bb8:
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e7
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i64, ptr %l24
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = call ptr @__olang_region_or(ptr %t47, ptr null)
  %t49 = call ptr @__olang_region_home(ptr %t48)
  %t50 = icmp ne ptr %t49, null
  %t51 = select i1 %t50, ptr %t49, ptr null
  call void @__olang_region_settle_in(ptr %t44, ptr %t51)
  br label %bb10
bb10:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l12
  %t53 = call ptr @__olang_scope_hold(ptr %v3)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l28, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e8
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t57 = call ptr @__olang_region_make(ptr %v3)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t59 = load i64, ptr %l28
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t60, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l30
  br label %bb13
bb13:
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e8
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i64, ptr %l28
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = call ptr @__olang_region_home(ptr %t69)
  %t71 = icmp ne ptr %t70, null
  %t72 = select i1 %t71, ptr %t70, ptr null
  call void @__olang_region_settle_in(ptr %t65, ptr %t72)
  br label %bb15
bb15:
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l13
  %t74 = call ptr @__olang_scope_hold(ptr %v3)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l32, !tbaa !24
  %t76 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e9
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = call ptr @__olang_region_make(ptr %v3)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l32, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l32
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t81, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l34
  br label %bb18
bb18:
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e9
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = load i64, ptr %l32
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = call ptr @__olang_region_or(ptr %t89, ptr null)
  %t91 = call ptr @__olang_region_home(ptr %t90)
  %t92 = icmp ne ptr %t91, null
  %t93 = select i1 %t92, ptr %t91, ptr null
  call void @__olang_region_settle_in(ptr %t86, ptr %t93)
  br label %bb20
bb20:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t95 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %t95, !tbaa !27
  %t97 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %t97, !tbaa !27
  %t99 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t100, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 3
  %t102 = load i1, ptr %l8, !tbaa !21
  store i1 %t102, ptr %t101, !tbaa !21
  %t103 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 4
  %t104 = load i1, ptr %l9, !tbaa !21
  store i1 %t104, ptr %t103, !tbaa !21
  %t105 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 5
  %t106 = load i1, ptr %l10, !tbaa !21
  store i1 %t106, ptr %t105, !tbaa !21
  %t107 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 6
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %t107
  %t109 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 7
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t109
  %t111 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 8
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %t111
  %t113 = getelementptr %"compiler/fetch:Fetcher", ptr %l36, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t113
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l36, i64 184, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/example.com/me/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/lib.olang" }>, align 8
declare void @__olang_errpay_pop()
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [12 x { i64, ptr }] }> <{ i64 0, [12 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d97, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d99, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d102, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }] }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eFetch_2elocal_2e13 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d13 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".fetch-" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"fetching " }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d15 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang: fetching " }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" into " }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d18 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", as olang.lock says" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"init" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d25 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fetch" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d27 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--depth" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"checkout" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d34 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FETCH_HEAD" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clone" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"checkout" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d43 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiling" }>, align 8
@.d44 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang: fetching " }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" into " }>, align 8
@.d46 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--branch=" }>, align 8
@.d47 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--quiet" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d50 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"clone" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--quiet" }>, align 8
@.d52 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--depth" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
@olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eFetch_2elocal_2e20 = weak hidden constant i1 false
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang: updated " }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d60 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang: updated " }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" (was " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d65 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is already at " }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e5 = weak hidden constant i1 false
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler__2ffetch__2ecompiler__2ffetch__3aFetcher__2eload_2elocal_2e6 = weak hidden constant i1 false
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_74(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/fetch:Fetcher", ptr %t1, i32 0, i32 6
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/fetch:Fetcher", ptr %t8, i32 0, i32 6
  %t14 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t15, { i64, ptr } %t16)
  store i1 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d75 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"# olang.lock - the commit each remote repository is built from (M23b). Delete a line to update that\0A" }>, align 8
@.d76 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"# repository, or build with -u to update every one the build reaches (M23c).\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-C" }>, align 8
@.d82 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"rev-parse" }>, align 8
@.d83 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HEAD" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/example.com/me/" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/lib.olang" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [3 x { i64, ptr }] }> <{ i64 0, [3 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }] }>, align 8
@.d92 = private constant <{ i64, [9 x { i64, ptr }] }> <{ i64 0, [9 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d97, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d99, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }] }>, align 8
@.d93 = private constant <{ i64, [11 x { i64, ptr }] }> <{ i64 0, [11 x { i64, ptr }] [{ i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d97, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d99, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }] }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e6 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e9 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d95 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"git" }>, align 8
@.d96 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d97 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"user.name=t" }>, align 8
@.d98 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"user.email=t@t" }>, align 8
@.d99 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"commit.gpgsign=false" }>, align 8
@.d100 = private unnamed_addr constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"commit" }>, align 8
@.d101 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-q" }>, align 8
@.d102 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-a" }>, align 8
@.d103 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-m" }>, align 8
@.d104 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"y" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d105 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"init" }>, align 8
@.d106 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"add" }>, align 8
@.d107 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d108 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ffetch_2esh(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_9f3ee14a10c0b496_69afdf9d2434e8f2 = external constant [0 x i8]
@olang_loc_d9850676ba2c3cf3_f7e63cb27448ce6f = external constant [0 x i8]
declare i1 @compiler_2ffetch_2eIsCommit(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fspin_2eRetitle(ptr %v0, { i64, ptr } %a0)
@olang_loc_45f2c25416d44418_72b8f662ae75c904 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_461a8d3078b45b75_287f37f9c7026b71 = external constant [0 x i8]
@olang_loc_64bbdb9c4083d73a_45ec4fce431b420e = external constant [0 x i8]
@olang_loc_978ca0e68f8e7a17_d15c8fffad158e0b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_ba721b6722bc57b1_efdace1c8e747995 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@G_2estd_2fio_2eStderr = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare void @compiler_2fspin_2eSay(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
