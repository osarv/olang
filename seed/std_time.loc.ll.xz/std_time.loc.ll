; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_f63687bbaea10838_93db7057d6025df4 = weak_odr constant [47 x i8] c"std/time.olang:330: slice bounds out of range\0A\00"
