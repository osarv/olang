; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" = type { ptr, i64, ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.b119c4d290b22df64a2c62bbae4a2e95" = type { %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" = type { %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr }
%"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" = type { { i64, ptr }, i64 }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/bindgen:cMacro" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, i1, i64, i1, { i64, ptr }, i1, i64, i64 }
define dso_local { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca { i32, i64 }
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t28 = extractvalue { ptr, ptr } %pg1, 0
  %t29 = extractvalue { ptr, ptr } %pg1, 1
  %t31 = call i1 %t28(ptr %t29, ptr %v0, { i64, ptr } %t23)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = insertvalue { i32, i64 } zeroinitializer, i64 %t34, 1
  store { i32, i64 } %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t42 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H116ed76223103781f5a7340c80f3d0f3(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = icmp eq i64 %t15, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t38, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  store ptr %t46, ptr %l1, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l21, !tbaa !29
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  %t53 = add i64 %t51, 1
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t55, i32 0, i32 1
  store i64 %t53, ptr %t56, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"std/prelude/map:mapSlot.b119c4d290b22df64a2c62bbae4a2e95", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t64 = getelementptr %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %t57, i32 0, i32 2
  store ptr %t61, ptr %t64, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"std/prelude/map:mapSlot.b119c4d290b22df64a2c62bbae4a2e95", ptr %t65, i32 0, i32 0
  %t68 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %t67, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t69, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l19 = alloca i1
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t33, { i64, ptr } %t34)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t41, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l19 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t31, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t33, { i64, ptr } %t34)
  store i1 %t37, ptr %l19
  br label %bb6
bb6:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l22 = alloca i1
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t35, { i64, ptr } %t36)
  store i1 %t39, ptr %l22
  br label %bb6
bb6:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t45, i32 0, i32 1
  store i64 %t42, ptr %t46, !tbaa !24
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H6f8d5b6df875cf2fc8b35e7cf5ff7776(ptr %v0, ptr %v1, ptr %t52, i64 %t53, { i64, ptr } %t54, i64 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd80cb4cbc6ceb8a13686fbc19b8451b4(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450"
  %rv = alloca %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" @std_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, ptr %a0)
  store %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %l2
  store %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %rv
  ret %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__H6f8d5b6df875cf2fc8b35e7cf5ff7776(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, ptr %v0, { i64, ptr } %t15, i64 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v1, ptr %v0, { i64, ptr } %t40, i64 %t41)
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hc31e2d572160cad57b6a109d58d0b02b(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hc31e2d572160cad57b6a109d58d0b02b(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b509d27efc810532_83b2149f0073e7e)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b509d27efc810532_83b2149f0073e7e)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Hd4cb60f90614005908bf41efbf706214(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret i64 %r
}

define dso_local %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t6, i64 %a1, 1
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %rv
  ret %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %rr
}

define dso_local %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" @std_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = insertvalue %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" undef, ptr %t4, 0
  %t9 = insertvalue %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t7, i64 0, 1
  %t11 = insertvalue %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t9, ptr null, 2
  store %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %t11, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450", ptr %rv
  ret %"std/prelude/map:MapKeyIter.3b4c246f7ffc69d6a04211b5bc786450" %rr
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" @std_2fprelude_2fmap_3amapSlot_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381"
  %rv = alloca %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0, ptr %v2, { i64, ptr } %a0, i64 %a1)
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" undef, %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59", ptr %rv
  ret %"std/prelude/map:mapSlot.0638bc3dcd3122a93fd4087a1e720a59" %rr
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/bindgen:cFunc"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/bindgen:cFunc", ptr %t11, i64 %a1
  %t13 = load %"compiler/bindgen:cFunc", ptr %t12
  store %"compiler/bindgen:cFunc" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cFunc", ptr %rv
  ret %"compiler/bindgen:cFunc" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cFunc" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acFunc_3e_2er_Hf5c37cfc570078cbb18685db1082b502(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/bindgen:cFunc", ptr %t41, i64 %t36
  store %"compiler/bindgen:cFunc" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/bindgen:cMacro"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/bindgen:cMacro", ptr %t11, i64 %a1
  %t13 = load %"compiler/bindgen:cMacro", ptr %t12
  store %"compiler/bindgen:cMacro" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cMacro", ptr %rv
  ret %"compiler/bindgen:cMacro" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ePush_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cMacro" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acMacro_3e_2e_H850cd8a1228b2eddd8b01e4d125b6f2c(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/bindgen:cMacro", ptr %t41, i64 %t36
  store %"compiler/bindgen:cMacro" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eSetAt_H7935c3ba4e105e8cc692de439d360efe(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:cMacro" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/bindgen:cMacro", ptr %t13, i64 %a1
  store %"compiler/bindgen:cMacro" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/bindgen:ctype"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/bindgen:ctype", ptr %t11, i64 %a1
  %t13 = load %"compiler/bindgen:ctype", ptr %t12
  store %"compiler/bindgen:ctype" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:ctype", ptr %rv
  ret %"compiler/bindgen:ctype" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eLen_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ePush_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:ctype" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3actype_3e_2er_H840e98e168ed081b9a351fb921f86f51(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/bindgen:ctype", ptr %t41, i64 %t36
  store %"compiler/bindgen:ctype" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eSetAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:ctype" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/bindgen:ctype", ptr %t13, i64 %a1
  store %"compiler/bindgen:ctype" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/bindgen:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/bindgen:record"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/bindgen:record", ptr %t11, i64 %a1
  %t13 = load %"compiler/bindgen:record", ptr %t12
  store %"compiler/bindgen:record" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:record", ptr %rv
  ret %"compiler/bindgen:record" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ePush_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:record" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3arecord_3e_2e_H49f188fd7862ebf90a36e1e868aab099(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/bindgen:record", ptr %t41, i64 %t36
  store %"compiler/bindgen:record" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eSetAt_He3052a9143ec79bc6ca4e8eb9591767e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/bindgen:record" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/bindgen:record", ptr %t13, i64 %a1
  store %"compiler/bindgen:record" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t11, i64 %a1
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fprelude_2fvec_3aVec_3cstd_2_H1bdc9c3b2b69929dbc0b1b26b39ab5a3(ptr %v0, ptr %t20, i64 %t26)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t41, i64 %t36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %t42
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l20, !tbaa !29
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 1
  store i64 %t48, ptr %t51, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acFunc_3e_2er_Hf5c37cfc570078cbb18685db1082b502(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_23c8eb6b5132cbe2_3b0e5edcfcc030e6)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_23c8eb6b5132cbe2_3b0e5edcfcc030e6)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/bindgen:cFunc", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 88
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_23c8eb6b5132cbe2_3b0e5edcfcc030e6)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/bindgen:cFunc", ptr %t105, i64 %t102
  %t107 = load %"compiler/bindgen:cFunc", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/bindgen:cFunc", ptr %t111, i64 %t109
  store %"compiler/bindgen:cFunc" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acMacro_3e_2e_H850cd8a1228b2eddd8b01e4d125b6f2c(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6ce37f05eb0c64d6_6f75a881c851175a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6ce37f05eb0c64d6_6f75a881c851175a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/bindgen:cMacro", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 64
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6ce37f05eb0c64d6_6f75a881c851175a)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/bindgen:cMacro", ptr %t105, i64 %t102
  %t107 = load %"compiler/bindgen:cMacro", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/bindgen:cMacro", ptr %t111, i64 %t109
  store %"compiler/bindgen:cMacro" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3actype_3e_2er_H840e98e168ed081b9a351fb921f86f51(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_eb0847f457a345f5_fbf8f3f72a38a4d9)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_eb0847f457a345f5_fbf8f3f72a38a4d9)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/bindgen:ctype", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 56
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_eb0847f457a345f5_fbf8f3f72a38a4d9)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/bindgen:ctype", ptr %t105, i64 %t102
  %t107 = load %"compiler/bindgen:ctype", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/bindgen:ctype", ptr %t111, i64 %t109
  store %"compiler/bindgen:ctype" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3arecord_3e_2e_H49f188fd7862ebf90a36e1e868aab099(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_86ccc3f61edf147c_3db766ccbc4ab418)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_86ccc3f61edf147c_3db766ccbc4ab418)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/bindgen:record", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 128
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_86ccc3f61edf147c_3db766ccbc4ab418)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/bindgen:record", ptr %t105, i64 %t102
  %t107 = load %"compiler/bindgen:record", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/bindgen:record", ptr %t111, i64 %t109
  store %"compiler/bindgen:record" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fprelude_2fvec_3aVec_3cstd_2_H1bdc9c3b2b69929dbc0b1b26b39ab5a3(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_16f179d043db9f58_d8440366ea2e2974)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_16f179d043db9f58_d8440366ea2e2974)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 8
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_16f179d043db9f58_d8440366ea2e2974)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t105, i64 %t102
  %t107 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t111, i64 %t109
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acFunc_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3acMacro_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 144115188075855871
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b3c4295d5a3a1707_88e23a6a72a02653)
  unreachable
bb3:
  %t5 = mul i64 0, 64
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b3c4295d5a3a1707_88e23a6a72a02653)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3actype_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbindgen_3arecord_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 72057594037927935
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_aa1bfceb250db2c5_f866254b67f13159)
  unreachable
bb3:
  %t5 = mul i64 0, 128
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa1bfceb250db2c5_f866254b67f13159)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26__Haf761e1021963f81e906a55dd1cb418b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b509d27efc810532_83b2149f0073e7e = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
@olang_loc_23c8eb6b5132cbe2_3b0e5edcfcc030e6 = external constant [0 x i8]
@olang_loc_6ce37f05eb0c64d6_6f75a881c851175a = external constant [0 x i8]
@olang_loc_eb0847f457a345f5_fbf8f3f72a38a4d9 = external constant [0 x i8]
@olang_loc_86ccc3f61edf147c_3db766ccbc4ab418 = external constant [0 x i8]
@olang_loc_16f179d043db9f58_d8440366ea2e2974 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_b3c4295d5a3a1707_88e23a6a72a02653 = external constant [0 x i8]
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_aa1bfceb250db2c5_f866254b67f13159 = external constant [0 x i8]
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
