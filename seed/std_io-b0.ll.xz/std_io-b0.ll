; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Lines" = type { i32, %"std/prelude/input:InputBuffer" }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
%"std/io:Reader" = type { i32, %"std/prelude/input:InputBuffer" }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
define dso_local i32 @std_2fio_2eafterTheEnd(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Lines"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/io:Lines"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Lines" @std_2fio_2eLines_2esized(ptr %s0, i32 %a0, i64 2)
  store %"std/io:Lines" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/io:Lines", ptr %l10
  store %"std/io:Lines" %t4, ptr %l1
  %t6 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s0, ptr %s0, ptr %l1)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l14
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l13
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  br label %bb10
bb3:
  %t12 = load i32, ptr %l14, !tbaa !23
  %t13 = icmp eq i32 %t12, 65536
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d56021b6e5c3bdfa_44c4511adba970be)
  unreachable
bb5:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65537
  br i1 %t16, label %bb6, label %bb7
bb6:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t18, i64 %t19)
  %t20 = call ptr @__olang_errpay_top_get()
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t20, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  %t28 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t26)
  call void @__olang_sb_add(ptr %s1, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t30, i64 %t31)
  %t32 = load ptr, ptr %s1
  %t33 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t34 = load i64, ptr %t33
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call ptr @__olang_scope_alloc(ptr %t35, i64 %t34)
  call void @olang_textcopy(ptr %t36, ptr %t32, i64 %t34)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l19, !tbaa !27
  %t39 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t40 = load ptr, ptr %t39
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %sbgrew.42, label %sbdone.43
sbgrew.42:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.43
sbdone.43:
  %t44 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %t45, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_cfbfa2371b772a5c_479a03f314fcd8b8, { i64, ptr } %t56, i1 false)
  unreachable
bb7:
  %t57 = load i32, ptr %l14, !tbaa !23
  %t58 = icmp eq i32 %t57, 131072
  br i1 %t58, label %bb8, label %bb9
bb8:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ecfe7bc4e914c155_2facd670f5d599)
  unreachable
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_236626def65966f_f8ee7e95debf0f53)
  unreachable
bb10:
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t63, ptr %l23
  br label %bb11
bb11:
  %t64 = load i1, ptr %l23, !tbaa !21
  br i1 %t64, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l3, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8ace81b314be0ed6_98e2c78d06064582)
  unreachable
bb14:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb19
bb16:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l30, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb18
bb18:
  %t91 = load i64, ptr %l30, !tbaa !24
  store i64 %t91, ptr %l27, !tbaa !24
  br label %bb19
bb19:
  %t92 = load i64, ptr %l27, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load i64, ptr %l7, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb22:
  br label %bb23
bb23:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l5, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l8, !tbaa !24
  %t112 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s0, ptr %s3, ptr %l1)
  %t113 = extractvalue { i32, { i64, ptr } } %t112, 1
  %t114 = extractvalue { i32, { i64, ptr } } %t112, 0
  store i32 %t114, ptr %l51
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb25, label %ok.116, !prof !99
ok.116:
  store { i64, ptr } %t113, ptr %l50
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t117, ptr %l48, !tbaa !27
  br label %bb31
bb25:
  %t118 = load i32, ptr %l51, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 2
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load i32, ptr %l51, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  br i1 %t126, label %bb28, label %bb29
bb27:
  %t128 = load i32, ptr %l51, !tbaa !23
  %t129 = lshr i32 %t128, 16
  %t130 = and i32 %t128, 65535
  %t131 = icmp eq i32 %t129, 1
  %t132 = select i1 %t131, i32 1, i32 0
  %t133 = icmp eq i32 %t129, 2
  %t134 = select i1 %t133, i32 0, i32 %t132
  %t135 = icmp eq i32 %t128, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t130
  %t138 = select i1 %t135, i32 0, i32 %t137
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t138, ptr %rv
  br label %ret
bb28:
  call void @__olang_errpay_pop()
  br label %bb29
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_cdec8918cbf67d26_bc226afea482d74a)
  unreachable
bb32:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb20
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fio_2ebracketed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/io:Lines"
  %l7 = alloca i32
  %l10 = alloca %"std/io:Lines"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l20 = alloca i1
  %l28 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call %"std/io:Lines" @std_2fio_2eLines_2esized(ptr %s1, i32 %t5, i64 %a1)
  store %"std/io:Lines" %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load %"std/io:Lines", ptr %l10
  store %"std/io:Lines" %t10, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %s1, ptr %s2, ptr %l4)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l14
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb14
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 2
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l20, !tbaa !21
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb11, label %bb12
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  call void @__olang_check_failed(ptr @olang_loc_19a3a555e0bc0672_a80c148e75e56d4e)
  unreachable
bb14:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = extractvalue { i64, ptr } %t38, 0
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t47 = extractvalue { i64, ptr } %t37, 1
  %t48 = extractvalue { i64, ptr } %t37, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t41, i64 %t42)
  %t54 = getelementptr i8, ptr %t53, i64 %t42
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t47, i64 %t48)
  %t56 = getelementptr i8, ptr %t55, i64 %t48
  call void @olang_textcopy(ptr %t56, ptr %t50, i64 %t51)
  %t57 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t53, 1
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb3
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t61 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @close(i32 %t61)
  store i32 %t63, ptr %l28
  br label %bb18
bb18:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fio_2enumbers(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Reader"
  %l3 = alloca %"std/io:Reader"
  %l4 = alloca i1
  %l6 = alloca i8
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i128
  %l19 = alloca i32
  %l22 = alloca i1
  %l24 = alloca double
  %l25 = alloca i32
  %l28 = alloca i1
  %l30 = alloca float
  %l31 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Reader" @std_2fio_2eReader_2esized(ptr %s0, i32 %a0, i64 4)
  store %"std/io:Reader" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/io:Reader", ptr %l3
  store %"std/io:Reader" %t4, ptr %l1
  %t6 = call { i32, i8 } @std_2fio_2estd_2fio_3aReader_2eNext_3cU8_3e(ptr %s0, ptr %l1)
  %t7 = extractvalue { i32, i8 } %t6, 1
  %t8 = extractvalue { i32, i8 } %t6, 0
  store i32 %t8, ptr %l7
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t11 = load i8, ptr %l6, !tbaa !22
  %t12 = icmp eq i8 %t11, -1
  store i1 %t12, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t15, 2
  %t20 = select i1 %t19, i32 2, i32 %t18
  %t21 = icmp eq i32 %t15, 3
  %t22 = select i1 %t21, i32 3, i32 %t20
  %t23 = icmp eq i32 %t14, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t16
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s0)
  store i32 %t26, ptr %rv
  br label %ret
bb4:
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = call { i32, i32 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI32_3e(ptr %s0, ptr %l1)
  %t31 = extractvalue { i32, i32 } %t30, 1
  %t32 = extractvalue { i32, i32 } %t30, 0
  store i32 %t32, ptr %l13
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb8, label %ok.34, !prof !99
ok.34:
  store i32 %t31, ptr %l12
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_612705f1948f190e_71b8b9d16e0467f2)
  unreachable
bb7:
  %t35 = load i32, ptr %l12, !tbaa !23
  %t36 = icmp eq i32 %t35, -17
  store i1 %t36, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t38 = load i32, ptr %l13, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t39, 2
  %t44 = select i1 %t43, i32 2, i32 %t42
  %t45 = icmp eq i32 %t39, 3
  %t46 = select i1 %t45, i32 3, i32 %t44
  %t47 = icmp eq i32 %t38, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t40
  %t50 = select i1 %t47, i32 0, i32 %t49
  call void @__olang_scope_close(ptr %s0)
  store i32 %t50, ptr %rv
  br label %ret
bb9:
  %t52 = load i1, ptr %l10, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = call { i32, i128 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI128_3e(ptr %s0, ptr %l1)
  %t55 = extractvalue { i32, i128 } %t54, 1
  %t56 = extractvalue { i32, i128 } %t54, 0
  store i32 %t56, ptr %l19
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb13, label %ok.58, !prof !99
ok.58:
  store i128 %t55, ptr %l18
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4a594c2f681aabb9_bd69a22d92cb3bcd)
  unreachable
bb12:
  %t59 = load i128, ptr %l18
  %t60 = icmp eq i128 %t59, -5
  store i1 %t60, ptr %l16, !tbaa !21
  br label %bb14
bb13:
  %t62 = load i32, ptr %l19, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t63, 2
  %t68 = select i1 %t67, i32 2, i32 %t66
  %t69 = icmp eq i32 %t63, 3
  %t70 = select i1 %t69, i32 3, i32 %t68
  %t71 = icmp eq i32 %t62, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t64
  %t74 = select i1 %t71, i32 0, i32 %t73
  call void @__olang_scope_close(ptr %s0)
  store i32 %t74, ptr %rv
  br label %ret
bb14:
  %t76 = load i1, ptr %l16, !tbaa !21
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = call { i32, double } @std_2fio_2estd_2fio_3aReader_2eNext_3cF64_3e(ptr %s0, ptr %l1)
  %t79 = extractvalue { i32, double } %t78, 1
  %t80 = extractvalue { i32, double } %t78, 0
  store i32 %t80, ptr %l25
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb18, label %ok.82, !prof !99
ok.82:
  store double %t79, ptr %l24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3d43254fa316b040_4a708859c9385124)
  unreachable
bb17:
  %t83 = load double, ptr %l24, !tbaa !26
  %t84 = fcmp oeq double %t83, 0x4004000000000000
  store i1 %t84, ptr %l22, !tbaa !21
  br label %bb19
bb18:
  %t86 = load i32, ptr %l25, !tbaa !23
  %t87 = lshr i32 %t86, 16
  %t88 = and i32 %t86, 65535
  %t89 = icmp eq i32 %t87, 1
  %t90 = select i1 %t89, i32 1, i32 0
  %t91 = icmp eq i32 %t87, 2
  %t92 = select i1 %t91, i32 2, i32 %t90
  %t93 = icmp eq i32 %t87, 3
  %t94 = select i1 %t93, i32 3, i32 %t92
  %t95 = icmp eq i32 %t86, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t88
  %t98 = select i1 %t95, i32 0, i32 %t97
  call void @__olang_scope_close(ptr %s0)
  store i32 %t98, ptr %rv
  br label %ret
bb19:
  %t100 = load i1, ptr %l22, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t102 = call { i32, float } @std_2fio_2estd_2fio_3aReader_2eNext_3cF32_3e(ptr %s0, ptr %l1)
  %t103 = extractvalue { i32, float } %t102, 1
  %t104 = extractvalue { i32, float } %t102, 0
  store i32 %t104, ptr %l31
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb23, label %ok.106, !prof !99
ok.106:
  store float %t103, ptr %l30
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3fe2750bd507e55b_453e8b296fa12c7f)
  unreachable
bb22:
  %t107 = load float, ptr %l30, !tbaa !25
  %t108 = fcmp oeq float %t107, 0x408f400000000000
  store i1 %t108, ptr %l28, !tbaa !21
  br label %bb24
bb23:
  %t110 = load i32, ptr %l31, !tbaa !23
  %t111 = lshr i32 %t110, 16
  %t112 = and i32 %t110, 65535
  %t113 = icmp eq i32 %t111, 1
  %t114 = select i1 %t113, i32 1, i32 0
  %t115 = icmp eq i32 %t111, 2
  %t116 = select i1 %t115, i32 2, i32 %t114
  %t117 = icmp eq i32 %t111, 3
  %t118 = select i1 %t117, i32 3, i32 %t116
  %t119 = icmp eq i32 %t110, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t112
  %t122 = select i1 %t119, i32 0, i32 %t121
  call void @__olang_scope_close(ptr %s0)
  store i32 %t122, ptr %rv
  br label %ret
bb24:
  %t124 = load i1, ptr %l28, !tbaa !21
  br i1 %t124, label %bb25, label %bb26
bb25:
  %t126 = call { i32, i1 } @std_2fio_2estd_2fio_3aReader_2eNext_3cBool_3e(ptr %s0, ptr %l1)
  %t127 = extractvalue { i32, i1 } %t126, 1
  %t128 = extractvalue { i32, i1 } %t126, 0
  store i32 %t128, ptr %l37
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb28, label %ok.130, !prof !99
ok.130:
  store i1 %t127, ptr %l36
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_829a796ec59bc43a_895c30d24d72a7e6)
  unreachable
bb27:
  %t131 = load i1, ptr %l36, !tbaa !21
  store i1 %t131, ptr %l34, !tbaa !21
  br label %bb29
bb28:
  %t132 = load i32, ptr %l37, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t133, 2
  %t138 = select i1 %t137, i32 2, i32 %t136
  %t139 = icmp eq i32 %t133, 3
  %t140 = select i1 %t139, i32 3, i32 %t138
  %t141 = icmp eq i32 %t132, 0
  %t142 = shl i32 %t140, 16
  %t143 = or i32 %t142, %t134
  %t144 = select i1 %t141, i32 0, i32 %t143
  call void @__olang_scope_close(ptr %s0)
  store i32 %t144, ptr %rv
  br label %ret
bb29:
  %t146 = load i1, ptr %l34, !tbaa !21
  br i1 %t146, label %bb30, label %bb31
bb30:
  %t148 = call { i32, i1 } @std_2fio_2estd_2fio_3aReader_2eNext_3cBool_3e(ptr %s0, ptr %l1)
  %t149 = extractvalue { i32, i1 } %t148, 1
  %t150 = extractvalue { i32, i1 } %t148, 0
  store i32 %t150, ptr %l42
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb33, label %ok.152, !prof !99
ok.152:
  store i1 %t149, ptr %l41
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_77d1d43e26afb955_a5c9cf46a69b0b31)
  unreachable
bb32:
  %t153 = load i1, ptr %l41, !tbaa !21
  store i1 %t153, ptr %l39, !tbaa !21
  br label %bb34
bb33:
  %t154 = load i32, ptr %l42, !tbaa !23
  %t155 = lshr i32 %t154, 16
  %t156 = and i32 %t154, 65535
  %t157 = icmp eq i32 %t155, 1
  %t158 = select i1 %t157, i32 1, i32 0
  %t159 = icmp eq i32 %t155, 2
  %t160 = select i1 %t159, i32 2, i32 %t158
  %t161 = icmp eq i32 %t155, 3
  %t162 = select i1 %t161, i32 3, i32 %t160
  %t163 = icmp eq i32 %t154, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t156
  %t166 = select i1 %t163, i32 0, i32 %t165
  call void @__olang_scope_close(ptr %s0)
  store i32 %t166, ptr %rv
  br label %ret
bb34:
  %t168 = load i1, ptr %l39, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_3ede013c1f353b0c_63e44ae0aad90078)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2epipe(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call i32 @pipe(ptr %t3)
  store i32 %t5, ptr %l2
  br label %bb1
bb1:
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ereading(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [2 x i32]
  %l5 = alloca i32
  %l10 = alloca i32
  %l15 = alloca { i64, ptr }
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x i32] undef, i32 0, 0
  %t2 = insertvalue [2 x i32] %t1, i32 0, 1
  store [2 x i32] %t2, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t8 = call i32 @std_2fio_2epipe(ptr %s0, { i64, ptr } %t6)
  store i32 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = icmp eq i32 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr [2 x i32], ptr %l1, i64 0, i64 1
  %t13 = load i32, ptr %t12, !tbaa !33
  %t18 = call i32 @std_2fio_2eWrite(ptr %v0, i32 %t13, { i64, ptr } %a0)
  store i32 %t18, ptr %l10
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20, !prof !99
ok.20:
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_48f9082997753888_a240ae8e5e29a0c)
  unreachable
bb4:
  br label %bb10
bb5:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = icmp eq i32 %t21, 65536
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6ee02aeeb4b82e91_bbd4c13499124615)
  unreachable
bb7:
  %t24 = load i32, ptr %l10, !tbaa !23
  %t25 = icmp eq i32 %t24, 65537
  br i1 %t25, label %bb8, label %bb9
bb8:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t27 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = call ptr @__olang_errpay_top_get()
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t30, i64 %t31)
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t29, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  %t37 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t35)
  call void @__olang_sb_add(ptr %s1, i64 %t38)
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t39, i64 %t40)
  %t41 = load ptr, ptr %s1
  %t42 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t43 = load i64, ptr %t42
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call ptr @__olang_scope_alloc(ptr %t44, i64 %t43)
  call void @olang_textcopy(ptr %t45, ptr %t41, i64 %t43)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l15, !tbaa !27
  %t48 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t49 = load ptr, ptr %t48
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %sbgrew.51, label %sbdone.52
sbgrew.51:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.52
sbdone.52:
  %t53 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %t54, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = extractvalue { i64, ptr } %t60, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_d370e8755f65b4b1_c6fa620c8a8d5d7d, { i64, ptr } %t65, i1 false)
  unreachable
bb9:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6b542447dc4d89ad_116b4d1aefb73901)
  unreachable
bb10:
  %t66 = getelementptr [2 x i32], ptr %l1, i64 0, i64 1
  %t67 = load i32, ptr %t66, !tbaa !33
  %t69 = call i32 @close(i32 %t67)
  store i32 %t69, ptr %l18
  br label %bb11
bb11:
  %t70 = getelementptr [2 x i32], ptr %l1, i64 0, i64 0
  %t71 = load i32, ptr %t70, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ereportTo(i32 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/io:Writer"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca %"std/io:Writer"
  %l17 = alloca i64
  %l20 = alloca i64
  %l44 = alloca i32
  %l46 = alloca i32
  %l51 = alloca { i64, ptr }
  %l62 = alloca i32
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %rv = alloca i32
  %t65 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %a0, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t8, i64 65536)
  store %"std/io:Writer" %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load %"std/io:Writer", ptr %l12
  store %"std/io:Writer" %t11, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l17, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp eq i64 %t60, 3
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = load i64, ptr %l8, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [1 x i64] }, ptr %t65, i32 0, i32 0
  store i64 1, ptr %t66
  %t68 = insertvalue { i64 } undef, i64 %t64, 0
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t65, i32 0, i32 1
  store { i64 } %t68, ptr %t69
  %t70 = load { i64, [1 x i64] }, ptr %t65
  %t71 = call ptr @__olang_errpay_push()
  %t72 = ptrtoint ptr %t71 to i64
  %t75 = inttoptr i64 %t72 to ptr
  %t76 = call ptr @__olang_scope_alloc_a(ptr %t75, i64 16, i64 8)
  store { i64, [1 x i64] } %t70, ptr %t76
  call void @__olang_errpay_set(ptr %t76)
  store i32 65537, ptr %l44, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  %t79 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l2)
  store i32 %t79, ptr %l46
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb15, label %ok.81, !prof !99
ok.81:
  br label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb20
bb15:
  %t82 = load i32, ptr %l46, !tbaa !23
  %t83 = icmp eq i32 %t82, 65536
  br i1 %t83, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_82463fd07313b343_899050d6bae42837)
  unreachable
bb17:
  %t85 = load i32, ptr %l46, !tbaa !23
  %t86 = icmp eq i32 %t85, 65537
  br i1 %t86, label %bb18, label %bb19
bb18:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t88 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t88, i64 %t89)
  %t90 = call ptr @__olang_errpay_top_get()
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t91, i64 %t92)
  %t94 = getelementptr { i64, [1 x i64] }, ptr %t90, i32 0, i32 1
  %t95 = getelementptr { i64 }, ptr %t94, i32 0, i32 0
  %t96 = load i64, ptr %t95
  %t98 = call ptr @__olang_sb_room(ptr %s5, i64 24)
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t96)
  call void @__olang_sb_add(ptr %s5, i64 %t99)
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t100, i64 %t101)
  %t102 = load ptr, ptr %s5
  %t103 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t104 = load i64, ptr %t103
  %t105 = load ptr, ptr @__olang_prog_scope
  %t106 = call ptr @__olang_scope_alloc(ptr %t105, i64 %t104)
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t104)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l51, !tbaa !27
  %t109 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t110 = load ptr, ptr %t109
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %sbgrew.112, label %sbdone.113
sbgrew.112:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.113
sbdone.113:
  %t114 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t115 = load ptr, ptr @__olang_prog_scope
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %t115, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = extractvalue { i64, ptr } %t121, 0
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f4311b0505de9da9_3272b36637f70495, { i64, ptr } %t126, i1 false)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6949e6a237530b_4c14899758e8fd2f)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t127 = load i32, ptr %l44, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb21:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t129 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t132 = call i64 @__olang_fmt_i64(ptr null, i64 %t128)
  %t133 = add i64 %t130, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t129, i64 %t130)
  %t138 = getelementptr i8, ptr %t137, i64 %t130
  %t139 = call i64 @__olang_fmt_i64(ptr %t138, i64 %t128)
  %t140 = getelementptr i8, ptr %t138, i64 %t132
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t137, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = extractvalue { i64, ptr } %t142, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t150)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t153 = load i64, ptr %l7, !tbaa !24
  %t156 = add i64 %t153, 1
  store i64 %t156, ptr %l7, !tbaa !24
  br label %bb8
bb24:
  %t159 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l2)
  store i32 %t159, ptr %l62
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb26, label %ok.161, !prof !99
ok.161:
  br label %bb25
bb25:
  br label %bb31
bb26:
  %t162 = load i32, ptr %l62, !tbaa !23
  %t163 = icmp eq i32 %t162, 65536
  br i1 %t163, label %bb27, label %bb28
bb27:
  call void @__olang_bang_failed_plain(ptr @olang_loc_82463fd07313b343_899050d6bae42837)
  unreachable
bb28:
  %t165 = load i32, ptr %l62, !tbaa !23
  %t166 = icmp eq i32 %t165, 65537
  br i1 %t166, label %bb29, label %bb30
bb29:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t168 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t168, i64 %t169)
  %t170 = call ptr @__olang_errpay_top_get()
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t171, i64 %t172)
  %t174 = getelementptr { i64, [1 x i64] }, ptr %t170, i32 0, i32 1
  %t175 = getelementptr { i64 }, ptr %t174, i32 0, i32 0
  %t176 = load i64, ptr %t175
  %t178 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t176)
  call void @__olang_sb_add(ptr %s9, i64 %t179)
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t180, i64 %t181)
  %t182 = load ptr, ptr %s9
  %t183 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t184 = load i64, ptr %t183
  %t185 = load ptr, ptr @__olang_prog_scope
  %t186 = call ptr @__olang_scope_alloc(ptr %t185, i64 %t184)
  call void @olang_textcopy(ptr %t186, ptr %t182, i64 %t184)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l67, !tbaa !27
  %t189 = getelementptr %olang.builder, ptr %s9, i32 0, i32 3
  %t190 = load ptr, ptr %t189
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %sbgrew.192, label %sbdone.193
sbgrew.192:
  call void @__olang_sb_done(ptr %s9)
  br label %sbdone.193
sbdone.193:
  %t194 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t195 = load ptr, ptr @__olang_prog_scope
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %t195, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t203 = extractvalue { i64, ptr } %t201, 1
  %t204 = extractvalue { i64, ptr } %t201, 0
  %t205 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t203, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f4311b0505de9da9_3272b36637f70495, { i64, ptr } %t206, i1 false)
  unreachable
bb30:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6949e6a237530b_4c14899758e8fd2f)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Lines", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l6
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l5
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb8
bb4:
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i32, ptr %l6, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 0, i32 0
  %t24 = icmp eq i32 %t20, 2
  %t25 = select i1 %t24, i32 2, i32 %t23
  %t26 = icmp eq i32 %t19, 0
  %t27 = shl i32 %t25, 16
  %t28 = or i32 %t27, %t21
  %t29 = select i1 %t26, i32 0, i32 %t28
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t29, 0
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  %t35 = call ptr @__olang_errpay_push()
  %t36 = ptrtoint ptr %t35 to i64
  %t39 = inttoptr i64 %t36 to ptr
  %t40 = call ptr @__olang_scope_alloc_a(ptr %t39, i64 16, i64 8)
  store { i64, [1 x i64] } %t34, ptr %t40
  call void @__olang_errpay_set(ptr %t40)
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb8:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/io:Lines", ptr %t46, i32 0, i32 1
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %t48)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l18
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l17
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t55, ptr %l14, !tbaa !27
  br label %bb15
bb11:
  %t56 = load i32, ptr %l18, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  %t61 = load i32, ptr %l18, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 0, i32 0
  %t66 = icmp eq i32 %t62, 2
  %t67 = select i1 %t66, i32 2, i32 %t65
  %t68 = icmp eq i32 %t61, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t63
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t73, ptr %rv
  br label %ret
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 0, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  %t77 = call ptr @__olang_errpay_push()
  %t78 = ptrtoint ptr %t77 to i64
  %t81 = inttoptr i64 %t78 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 16, i64 8)
  store { i64, [1 x i64] } %t76, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eAvailable(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Reader", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAvailable(ptr %v1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l6
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l5
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb8
bb4:
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i32, ptr %l6, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 0, i32 0
  %t24 = icmp eq i32 %t20, 2
  %t25 = select i1 %t24, i32 2, i32 %t23
  %t26 = icmp eq i32 %t19, 0
  %t27 = shl i32 %t25, 16
  %t28 = or i32 %t27, %t21
  %t29 = select i1 %t26, i32 0, i32 %t28
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t29, 0
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  %t35 = call ptr @__olang_errpay_push()
  %t36 = ptrtoint ptr %t35 to i64
  %t39 = inttoptr i64 %t36 to ptr
  %t40 = call ptr @__olang_scope_alloc_a(ptr %t39, i64 16, i64 8)
  store { i64, [1 x i64] } %t34, ptr %t40
  call void @__olang_errpay_set(ptr %t40)
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb8:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/io:Reader", ptr %t46, i32 0, i32 1
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %v0, ptr %v1, ptr %t48)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l18
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l17
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t55, ptr %l14, !tbaa !27
  br label %bb15
bb11:
  %t56 = load i32, ptr %l18, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  %t61 = load i32, ptr %l18, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 0, i32 0
  %t66 = icmp eq i32 %t62, 2
  %t67 = select i1 %t66, i32 2, i32 %t65
  %t68 = icmp eq i32 %t61, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t63
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t73, ptr %rv
  br label %ret
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 0, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  %t77 = call ptr @__olang_errpay_push()
  %t78 = ptrtoint ptr %t77 to i64
  %t81 = inttoptr i64 %t78 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 16, i64 8)
  store { i64, [1 x i64] } %t76, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t34 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Reader", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinBytes(ptr %v1, i64 %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l8
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb4, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l7
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  br label %bb8
bb4:
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t21 = load i32, ptr %l8, !tbaa !23
  %t22 = lshr i32 %t21, 16
  %t23 = and i32 %t21, 65535
  %t24 = icmp eq i32 %t22, 1
  %t25 = select i1 %t24, i32 0, i32 0
  %t26 = icmp eq i32 %t22, 2
  %t27 = select i1 %t26, i32 2, i32 %t25
  %t28 = icmp eq i32 %t21, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t23
  %t31 = select i1 %t28, i32 0, i32 %t30
  %t33 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t31, 0
  store { i32, { i64, ptr } } %t33, ptr %rv
  br label %ret
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load { i64, [1 x i64] }, ptr %t34
  %t37 = call ptr @__olang_errpay_push()
  %t38 = ptrtoint ptr %t37 to i64
  %t41 = inttoptr i64 %t38 to ptr
  %t42 = call ptr @__olang_scope_alloc_a(ptr %t41, i64 16, i64 8)
  store { i64, [1 x i64] } %t36, ptr %t42
  call void @__olang_errpay_set(ptr %t42)
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb8:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t46, 1
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/io:Reader", ptr %t48, i32 0, i32 1
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %v0, ptr %v1, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l21
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb11, label %ok.58, !prof !99
ok.58:
  store { i64, ptr } %t55, ptr %l20
  br label %bb10
bb10:
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t59, ptr %l16, !tbaa !27
  br label %bb15
bb11:
  %t60 = load i32, ptr %l21, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  %t65 = load i32, ptr %l21, !tbaa !23
  %t66 = lshr i32 %t65, 16
  %t67 = and i32 %t65, 65535
  %t68 = icmp eq i32 %t66, 1
  %t69 = select i1 %t68, i32 0, i32 0
  %t70 = icmp eq i32 %t66, 2
  %t71 = select i1 %t70, i32 2, i32 %t69
  %t72 = icmp eq i32 %t65, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t67
  %t75 = select i1 %t72, i32 0, i32 %t74
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t75, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  %t81 = call ptr @__olang_errpay_push()
  %t82 = ptrtoint ptr %t81 to i64
  %t85 = inttoptr i64 %t82 to ptr
  %t86 = call ptr @__olang_scope_alloc_a(ptr %t85, i64 16, i64 8)
  store { i64, [1 x i64] } %t80, ptr %t86
  call void @__olang_errpay_set(ptr %t86)
  %t89 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t89, ptr %rv
  br label %ret
bb15:
  %t90 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Reader", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l6
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l5
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb8
bb4:
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i32, ptr %l6, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 0, i32 0
  %t24 = icmp eq i32 %t20, 2
  %t25 = select i1 %t24, i32 2, i32 %t23
  %t26 = icmp eq i32 %t19, 0
  %t27 = shl i32 %t25, 16
  %t28 = or i32 %t27, %t21
  %t29 = select i1 %t26, i32 0, i32 %t28
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t29, 0
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  %t35 = call ptr @__olang_errpay_push()
  %t36 = ptrtoint ptr %t35 to i64
  %t39 = inttoptr i64 %t36 to ptr
  %t40 = call ptr @__olang_scope_alloc_a(ptr %t39, i64 16, i64 8)
  store { i64, [1 x i64] } %t34, ptr %t40
  call void @__olang_errpay_set(ptr %t40)
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb8:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/io:Reader", ptr %t46, i32 0, i32 1
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %t48)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l18
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l17
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t55, ptr %l14, !tbaa !27
  br label %bb15
bb11:
  %t56 = load i32, ptr %l18, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  %t61 = load i32, ptr %l18, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 0, i32 0
  %t66 = icmp eq i32 %t62, 2
  %t67 = select i1 %t66, i32 2, i32 %t65
  %t68 = icmp eq i32 %t61, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t63
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t73, ptr %rv
  br label %ret
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 0, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  %t77 = call ptr @__olang_errpay_push()
  %t78 = ptrtoint ptr %t77 to i64
  %t81 = inttoptr i64 %t78 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 16, i64 8)
  store { i64, [1 x i64] } %t76, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/io:Reader", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp eq i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinWord(ptr %v1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l6
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l5
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  br label %bb8
bb4:
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i32, ptr %l6, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 0, i32 0
  %t24 = icmp eq i32 %t20, 2
  %t25 = select i1 %t24, i32 2, i32 %t23
  %t26 = icmp eq i32 %t19, 0
  %t27 = shl i32 %t25, 16
  %t28 = or i32 %t27, %t21
  %t29 = select i1 %t26, i32 0, i32 %t28
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t29, 0
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  %t35 = call ptr @__olang_errpay_push()
  %t36 = ptrtoint ptr %t35 to i64
  %t39 = inttoptr i64 %t36 to ptr
  %t40 = call ptr @__olang_scope_alloc_a(ptr %t39, i64 16, i64 8)
  store { i64, [1 x i64] } %t34, ptr %t40
  call void @__olang_errpay_set(ptr %t40)
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb8:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t44, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/io:Reader", ptr %t46, i32 0, i32 1
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %v0, ptr %v1, ptr %t48)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l18
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l17
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t55, ptr %l14, !tbaa !27
  br label %bb15
bb11:
  %t56 = load i32, ptr %l18, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  %t61 = load i32, ptr %l18, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 0, i32 0
  %t66 = icmp eq i32 %t62, 2
  %t67 = select i1 %t66, i32 2, i32 %t65
  %t68 = icmp eq i32 %t61, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t63
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t73, ptr %rv
  br label %ret
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 0, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  %t77 = call ptr @__olang_errpay_push()
  %t78 = ptrtoint ptr %t77 to i64
  %t81 = inttoptr i64 %t78 to ptr
  %t82 = call ptr @__olang_scope_alloc_a(ptr %t81, i64 16, i64 8)
  store { i64, [1 x i64] } %t76, ptr %t82
  call void @__olang_errpay_set(ptr %t82)
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fio_2esumOf(i32 %a0) #0 {
entry:
  %l1 = alloca %"std/io:Reader"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/io:Reader"
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/io:Reader" @std_2fio_2eReader_2esized(ptr %s0, i32 %a0, i64 2)
  store %"std/io:Reader" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"std/io:Reader", ptr %l11
  store %"std/io:Reader" %t4, ptr %l1
  %t6 = call { i32, i64 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI64_3e(ptr %s0, ptr %l1)
  %t7 = extractvalue { i32, i64 } %t6, 1
  %t8 = extractvalue { i32, i64 } %t6, 0
  store i32 %t8, ptr %l15
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  store i64 %t7, ptr %l14
  br label %bb2
bb2:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l12, !tbaa !24
  br label %bb4
bb3:
  %t12 = load i32, ptr %l15, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t13, 2
  %t18 = select i1 %t17, i32 2, i32 %t16
  %t19 = icmp eq i32 %t13, 3
  %t20 = select i1 %t19, i32 3, i32 %t18
  %t21 = icmp eq i32 %t12, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t14
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, i64 } zeroinitializer, i32 %t24, 0
  store { i32, i64 } %t26, ptr %rv
  br label %ret
bb4:
  %t27 = load i64, ptr %l12, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l24, !tbaa !24
  store i64 %t56, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l21, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l42, !tbaa !24
  %t78 = call { i32, i64 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI64_3e(ptr %s0, ptr %l1)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l46
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb16, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l45
  br label %bb15
bb15:
  %t83 = load i64, ptr %l45, !tbaa !24
  store i64 %t83, ptr %l43, !tbaa !24
  br label %bb17
bb16:
  %t84 = load i32, ptr %l46, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t85, 2
  %t90 = select i1 %t89, i32 2, i32 %t88
  %t91 = icmp eq i32 %t85, 3
  %t92 = select i1 %t91, i32 3, i32 %t90
  %t93 = icmp eq i32 %t84, 0
  %t94 = shl i32 %t92, 16
  %t95 = or i32 %t94, %t86
  %t96 = select i1 %t93, i32 0, i32 %t95
  call void @__olang_scope_close(ptr %s0)
  %t98 = insertvalue { i32, i64 } zeroinitializer, i32 %t96, 0
  store { i32, i64 } %t98, ptr %rv
  br label %ret
bb17:
  %t99 = load i64, ptr %l42, !tbaa !24
  %t100 = load i64, ptr %l43, !tbaa !24
  %t101 = add i64 %t99, %t100
  store i64 %t101, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t103, 1
  store i64 %t106, ptr %l8, !tbaa !24
  br label %bb11
bb19:
  %t108 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t110 = insertvalue { i32, i64 } zeroinitializer, i64 %t108, 1
  store { i32, i64 } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d0 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"io.Error.Partial" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
declare ptr @__olang_errpay_top_get()
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_text(ptr, { i64, ptr }, i1) cold noreturn
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"only" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_errpay_pop()
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
declare i32 @close(i32)
declare i32 @pipe(ptr)
@.d7 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"io.Error.Partial" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
declare ptr @__olang_errpay_push() cold
declare void @__olang_errpay_set(ptr) cold
@.d10 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"io.Error.Partial" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"line " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

declare %"std/io:Lines" @std_2fio_2eLines_2esized(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_d56021b6e5c3bdfa_44c4511adba970be = external constant [0 x i8]
@olang_loc_cfbfa2371b772a5c_479a03f314fcd8b8 = external constant [0 x i8]
@olang_loc_ecfe7bc4e914c155_2facd670f5d599 = external constant [0 x i8]
@olang_loc_236626def65966f_f8ee7e95debf0f53 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8ace81b314be0ed6_98e2c78d06064582 = external constant [0 x i8]
@olang_loc_cdec8918cbf67d26_bc226afea482d74a = external constant [0 x i8]
@olang_loc_19a3a555e0bc0672_a80c148e75e56d4e = external constant [0 x i8]
declare %"std/io:Reader" @std_2fio_2eReader_2esized(ptr %v0, i32 %a0, i64 %a1)
declare { i32, i8 } @std_2fio_2estd_2fio_3aReader_2eNext_3cU8_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI32_3e(ptr %v0, ptr %a0)
@olang_loc_612705f1948f190e_71b8b9d16e0467f2 = external constant [0 x i8]
declare { i32, i128 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI128_3e(ptr %v0, ptr %a0)
@olang_loc_4a594c2f681aabb9_bd69a22d92cb3bcd = external constant [0 x i8]
declare { i32, double } @std_2fio_2estd_2fio_3aReader_2eNext_3cF64_3e(ptr %v0, ptr %a0)
@olang_loc_3d43254fa316b040_4a708859c9385124 = external constant [0 x i8]
declare { i32, float } @std_2fio_2estd_2fio_3aReader_2eNext_3cF32_3e(ptr %v0, ptr %a0)
@olang_loc_3fe2750bd507e55b_453e8b296fa12c7f = external constant [0 x i8]
declare { i32, i1 } @std_2fio_2estd_2fio_3aReader_2eNext_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_829a796ec59bc43a_895c30d24d72a7e6 = external constant [0 x i8]
@olang_loc_77d1d43e26afb955_a5c9cf46a69b0b31 = external constant [0 x i8]
@olang_loc_3ede013c1f353b0c_63e44ae0aad90078 = external constant [0 x i8]
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_48f9082997753888_a240ae8e5e29a0c = external constant [0 x i8]
@olang_loc_6ee02aeeb4b82e91_bbd4c13499124615 = external constant [0 x i8]
@olang_loc_d370e8755f65b4b1_c6fa620c8a8d5d7d = external constant [0 x i8]
@olang_loc_6b542447dc4d89ad_116b4d1aefb73901 = external constant [0 x i8]
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0, i64 %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
@olang_loc_82463fd07313b343_899050d6bae42837 = external constant [0 x i8]
@olang_loc_f4311b0505de9da9_3272b36637f70495 = external constant [0 x i8]
@olang_loc_b6949e6a237530b_4c14899758e8fd2f = external constant [0 x i8]
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinAvailable(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eAvailable(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinBytes(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinWord(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
