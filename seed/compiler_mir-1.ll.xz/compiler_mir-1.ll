; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"compiler/mir:Task" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span" }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
define dso_local i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1, i32 %t2, i64 %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l1
  %t11 = trunc i64 0 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb7
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t18 = mul i64 2, 4
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 2, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 0
  store i32 %t16, ptr %t25, !tbaa !33
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 1
  store i32 %t17, ptr %t29, !tbaa !33
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } %t31)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t34 = load ptr, ptr %l11, !tbaa !29
  %t35 = load i32, ptr %l16, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t34, i32 %t35, i32 %t33, i32 0, i32 0, i64 0)
  store i32 %t37, ptr %l18
  br label %bb6
bb6:
  %t38 = load i32, ptr %l18, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb7:
  %t39 = load i32, ptr %l1
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = mul i64 2, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 2, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t46, ptr %t55, !tbaa !33
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 1
  store i32 %t47, ptr %t59, !tbaa !33
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t45, { i64, ptr } %t61)
  store i32 %t62, ptr %l26
  br label %bb11
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t64 = load ptr, ptr %l21, !tbaa !29
  %t65 = load i32, ptr %l26, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t64, i32 %t65, i32 %t63, i32 0, i32 0, i64 0)
  store i32 %t67, ptr %l28
  br label %bb12
bb12:
  %t68 = load i32, ptr %l28, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb13:
  %t69 = load i32, ptr %l1
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l31, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l34
  br label %bb17
bb17:
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load ptr, ptr %l31, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t81, i32 %t82, i32 %t80, i32 0, i32 0, i64 0)
  store i32 %t84, ptr %l36
  br label %bb18
bb18:
  %t85 = load i32, ptr %l36, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  br label %bb25
bb19:
  %t86 = load i32, ptr %l1
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t91, i32 0, i32 %t92, i32 0, i32 0, i64 0)
  store i32 %t95, ptr %l41
  br label %bb23
bb23:
  %t96 = load i32, ptr %l41, !tbaa !23
  store i32 %t96, ptr %l8, !tbaa !23
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f3abe41a98405543_7d26227a2bded35f)
  unreachable
bb25:
  %t97 = load i32, ptr %l8, !tbaa !23
  store i32 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2eI32T_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0) #0 {
entry:
  %l4 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Place"
  %t2 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 1, ptr %t3
  %t5 = insertvalue { i32 } undef, i32 %a0, 0
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 1
  store { i32 } %t5, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t2
  %t8 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t11 = call %"compiler/mir:Place" @compiler_2fmir_3aPlace_2ector(ptr %s0, { i64, [2 x i64] } %t7, %"compiler/mir:Range" %t8)
  store %"compiler/mir:Place" %t11, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/mir:Place", ptr %l4
  store %"compiler/mir:Place" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local void @compiler_2fmir_2eNoBlock_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -1, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eNoLocal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -1, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eNoPlace_2einit() #0 {
entry:
  %l2 = alloca %"compiler/mir:Place"
  %t1 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = load { i64, [2 x i64] }, ptr %t1
  %t4 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t5 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"compiler/mir:Place" @compiler_2fmir_3aPlace_2ector(ptr %t5, { i64, [2 x i64] } %t3, %"compiler/mir:Range" %t4)
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb1
bb1:
  %t9 = load %"compiler/mir:Place", ptr %l2
  store %"compiler/mir:Place" %t9, ptr @G_2ecompiler_2fmir_2eNoPlace
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l3 = alloca %"compiler/mir:BasicBlock"
  %l8 = alloca %"compiler/mir:BasicBlock"
  %l11 = alloca { i64, [21 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/mir:BasicBlock" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load %"compiler/mir:BasicBlock", ptr %l8
  store %"compiler/mir:BasicBlock" %t10, ptr %l3
  %t11 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %a2, i64 176, i1 false)
  %t15 = load { i64, [21 x i64] }, ptr %l11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t11, { i64, [21 x i64] } %t15)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t3, %"compiler/mir:Call" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 14
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 18
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/typed:Item", ptr %t25, i64 %t22
  %t27 = load %"compiler/typed:Item", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 18
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t31, %"compiler/typed:Item" %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l13 = alloca %"compiler/mir:ScopeInfo"
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l7, !tbaa !29
  %t14 = call %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %s0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
  store %"compiler/mir:ScopeInfo" %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/mir:ScopeInfo", ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2ePus_H9ddd7aec2adc172d235e28f53f6a7179(ptr %v0, ptr %t15, %"compiler/mir:ScopeInfo" %t16)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 8
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t25 = trunc i64 %t23 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t4 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [1 x i64] }, ptr %t4, i32 0, i32 0
  store i64 3, ptr %t5
  %t6 = load { i64, [1 x i64] }, ptr %t4
  %t11 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 0, %"compiler/source:Span" %a2, i32 %a1, i32 3, { i64, [1 x i64] } %t6)
  store %"compiler/mir:Local" %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load %"compiler/mir:Local", ptr %l8
  %t14 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t12, %"compiler/mir:Local" %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [4 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t31, { i64, [4 x i64] } %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [7 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/mir:BasicBlock"
  %l10 = alloca %"compiler/mir:BasicBlock"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Fn", ptr %t5, i32 0, i32 9
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/mir:BasicBlock" %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load %"compiler/mir:BasicBlock", ptr %l10
  store %"compiler/mir:BasicBlock" %t12, ptr %l4
  %t15 = getelementptr %"compiler/mir:BasicBlock", ptr %l4, i32 0, i32 1
  store { i64, [7 x i64] } %a2, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/mir:Fn", ptr %t16, i32 0, i32 9
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load %"compiler/mir:BasicBlock", ptr %l4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eSe_H8a8a2f028839a4663a36aa3d32dfaacb(ptr %v0, ptr %v0, ptr %t18, i64 %t19, %"compiler/mir:BasicBlock" %t20)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:BasicBlock"
  %l6 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %v0)
  store %"compiler/mir:BasicBlock" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/mir:BasicBlock", ptr %l3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2ePu_H0f7fa7a3bad59b258cdb456f0cf1ac35(ptr %v0, ptr %v0, ptr %t5, %"compiler/mir:BasicBlock" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 9
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Place"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb8:
  store { i64, [2 x i64] } %a1, ptr %l26
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = trunc i64 %t45 to i32
  %t50 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t42, i32 %t47)
  store %"compiler/mir:Range" %t50, ptr %l32
  br label %bb9
bb9:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  %t52 = load %"compiler/mir:Range", ptr %l32
  %t53 = call %"compiler/mir:Place" @compiler_2fmir_3aPlace_2ector(ptr %s0, { i64, [2 x i64] } %t51, %"compiler/mir:Range" %t52)
  store %"compiler/mir:Place" %t53, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/mir:Place", ptr %l33
  store %"compiler/mir:Place" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local { i64, [7 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/mir:BasicBlock"
  %rv = alloca { i64, [7 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/mir:BasicBlock" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 1
  %t11 = load { i64, [7 x i64] }, ptr %t10
  store { i64, [7 x i64] } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [7 x i64] }, ptr %rv
  ret { i64, [7 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:verifier"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/mir:verifier", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmir_3averifier_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %v1, ptr %a0, ptr %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %t3, i64 232, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l5, i64 232, i1 false)
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %v1, ptr %t8)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 2
  %t14 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t12)
  store { i64, ptr } %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t8 = load %"compiler/mir:Place", ptr %t7
  %t11 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t6, %"compiler/mir:Place" %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } { i64 3, ptr @.d0 }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr @.d0 }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  call void @olang_textcopy(ptr %t19, ptr %t15, i64 %t16)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t29 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t29, { i64, ptr } %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  store ptr %l2, ptr %l11, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t33 = load { i64, [5 x i64] }, ptr %t32
  %t36 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t31, { i64, [5 x i64] } %t33)
  store { i64, ptr } %t36, ptr %l14
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t39 = load %"compiler/mir:Range", ptr %t38
  %t42 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t37, %"compiler/mir:Range" %t39)
  store { i64, ptr } %t42, ptr %l17
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 5, ptr @.d1 }, 1
  %t44 = extractvalue { i64, ptr } { i64 5, ptr @.d1 }, 0
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t43, i64 %t44)
  %t60 = getelementptr i8, ptr %t59, i64 %t44
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t49, i64 %t50)
  %t62 = getelementptr i8, ptr %t61, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t59, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t73, { i64, ptr } %t72)
  br label %bb9
bb9:
  %t75 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = icmp sgt i32 %t77, 0
  br i1 %t79, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l22, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t83 = load %"compiler/mir:Range", ptr %t82
  %t86 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s4, ptr %t81, %"compiler/mir:Range" %t83)
  store { i64, ptr } %t86, ptr %l25
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t87 = extractvalue { i64, ptr } { i64 2, ptr @.d4 }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr @.d4 }, 0
  %t89 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t108, { i64, ptr } %t107)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t110 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = extractvalue { i64, ptr } { i64 8, ptr @.d6 }, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr @.d6 }, 0
  %t115 = sext i32 %t111 to i64
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t113, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t112, i64 %t113)
  %t119 = getelementptr i8, ptr %t118, i64 %t113
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t115)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t129)
  br label %bb15
bb15:
  %t132 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t137 = icmp ne i32 %t133, %t134
  br i1 %t137, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t140 = load i32, ptr %t139, !tbaa !23
  %t141 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 6, ptr @.d7 }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr @.d7 }, 0
  %t146 = sext i32 %t140 to i64
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 1
  %t150 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t146)
  %t159 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t159, ptr %t149, i64 %t150)
  %t160 = getelementptr i8, ptr %t159, i64 %t150
  %t161 = call i64 @__olang_fmt_i64(ptr %t160, i64 %t153)
  %t162 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t156, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t170)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb19
bb19:
  %t174 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t174, ptr %l41
  br label %bb20
bb20:
  %t175 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t175, ptr %l42, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l43, !tbaa !24
  %t178 = load i64, ptr %l43, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l44, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l43, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t189, ptr %l42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t190 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [1 x i64] }, ptr %t7
  store { i64, [1 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [1 x i64] }, ptr %l2
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %t10, { i64, [1 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  br label %bb15
bb5:
  %t16 = load { i64, [5 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [5 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { i64, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 1
  %t27 = extractvalue { i64, ptr } { i64 7, ptr @.d9 }, 0
  %t29 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  br label %bb15
bb9:
  %t37 = load { i64, [5 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [5 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 2
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [4 x i64] } }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l4
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l4
  %t50 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t46, { i64, [4 x i64] } %t47)
  store { i64, ptr } %t50, ptr %l22
  br label %bb13
bb13:
  %t51 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t53 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267)
  unreachable
bb15:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/mir:Range"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 19
  %t9 = sext i32 %a1 to i64
  %t12 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t6, i64 %t9)
  store { i64, [1 x i64] } %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t13, ptr %l2
  %t14 = load { i64, [1 x i64] }, ptr %l2
  %t16 = extractvalue { i64, [1 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t20 = getelementptr { i64 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l12, !tbaa !27
  br label %bb15
bb5:
  %t31 = load { i64, [1 x i64] }, ptr %l2
  %t33 = extractvalue { i64, [1 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t37 = getelementptr { %"compiler/mir:Range" }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/mir:Range", ptr %t37
  store %"compiler/mir:Range" %t38, ptr %l4
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t40 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = extractvalue { i64, ptr } { i64 5, ptr @.d12 }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr @.d12 }, 0
  %t45 = sext i32 %t41 to i64
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  %t50 = call i64 @__olang_fmt_i64(ptr %t49, i64 %t45)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t48, 1
  store { i64, ptr } %t52, ptr %l12, !tbaa !27
  br label %bb15
bb9:
  %t54 = load { i64, [1 x i64] }, ptr %l2
  %t56 = extractvalue { i64, [1 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 2
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t60 = getelementptr { %"compiler/mir:Range" }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l5
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/mir:Range", ptr %l5
  %t67 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %t63, %"compiler/mir:Range" %t64)
  store { i64, ptr } %t67, ptr %l28
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t68, ptr %l12, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dca1ca4acf899191_a3a5645eac28d4dd)
  unreachable
bb15:
  %t69 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/mir:dumper", ptr %t49, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr @.d13 })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:dumper", ptr %t63, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:dumper", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l23, !tbaa !24
  store i64 %t42, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l20, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  store ptr %l2, ptr %l41, !tbaa !29
  %t62 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr @.d14 }, ptr %l44, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l44, !tbaa !27
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/mir:dumper", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l47, !tbaa !27
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t69, i32 %t76)
  store { i64, ptr } %t79, ptr %l50
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t105, ptr %l56
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t106, ptr %l57, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l58, !tbaa !24
  %t109 = load i64, ptr %l58, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l59, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = mul i64 %t118, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %t117, i64 %t119, i1 false)
  %t120 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t120, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr @.d16 }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d17 }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 11
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t75 = call { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t62, i64 %t72)
  store { i64, [4 x i64] } %t75, ptr %l48
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load { i64, [4 x i64] }, ptr %l48
  %t78 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s2, ptr %t76, { i64, [4 x i64] } %t77)
  store { i64, ptr } %t78, ptr %l49
  br label %bb16
bb16:
  %t79 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  call void @olang_textcopy(ptr %t87, ptr %t83, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t97, { i64, ptr } %t96)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t99 = load i32, ptr %l7, !tbaa !23
  %t101 = add i32 %t99, 1
  store i32 %t101, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t104 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t104, ptr %l55
  br label %bb20
bb20:
  %t105 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t105, ptr %l56, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l57, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t119, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [1 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr @.d18 }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d19 }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 12
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t75 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t62, i64 %t72)
  store { i64, [1 x i64] } %t75, ptr %l48
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load { i64, [1 x i64] }, ptr %l48
  %t78 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s2, ptr %t76, { i64, [1 x i64] } %t77)
  store { i64, ptr } %t78, ptr %l49
  br label %bb16
bb16:
  %t79 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  call void @olang_textcopy(ptr %t87, ptr %t83, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t97, { i64, ptr } %t96)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t99 = load i32, ptr %l7, !tbaa !23
  %t101 = add i32 %t99, 1
  store i32 %t101, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t104 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t104, ptr %l55
  br label %bb20
bb20:
  %t105 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t105, ptr %l56, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l57, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t119, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca %"compiler/mir:Place"
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca %"compiler/mir:Place"
  %l19 = alloca %"compiler/mir:Place"
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca i1
  %l125 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca i1
  %l137 = alloca i32
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l177 = alloca i32
  %l178 = alloca ptr
  %l184 = alloca %"compiler/mir:Task"
  %l185 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l188 = alloca i1
  %l191 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca i32
  %l205 = alloca { i64, ptr }
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t2 = load ptr, ptr %l26, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l26, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l27, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l27, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Place", ptr %t13
  store %"compiler/mir:Place" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Place", ptr %l2
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t22, %"compiler/mir:Place" %t23)
  store { i64, ptr } %t26, ptr %l36
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l3
  %t31 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %s1, ptr %t27, { i64, [15 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l39
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } { i64 3, ptr @.d20 }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr @.d20 }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = getelementptr i8, ptr %t43, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  store { i64, ptr } %t46, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb105
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l42, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l42, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [21 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 6, ptr @.d21 }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr @.d21 }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = getelementptr i8, ptr %t70, i64 %t65
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t67)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  store { i64, ptr } %t74, ptr %l25, !tbaa !27
  br label %bb105
bb14:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l49, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t91 = load i32, ptr %l5, !tbaa !23
  %t92 = extractvalue { i64, ptr } { i64 6, ptr @.d22 }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr @.d22 }, 0
  %t95 = sext i32 %t91 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t92, i64 %t93)
  %t99 = getelementptr i8, ptr %t98, i64 %t93
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t95)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l25, !tbaa !27
  br label %bb105
bb20:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t105 = load ptr, ptr %l57, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 3
  store i1 %t111, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t112 = load i1, ptr %l58, !tbaa !21
  br i1 %t112, label %bb23, label %bb24
bb23:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32 }, ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l6, !tbaa !23
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 1
  %t121 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 0
  %t123 = sext i32 %t119 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  %t128 = call i64 @__olang_fmt_i64(ptr %t127, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l25, !tbaa !27
  br label %bb105
bb26:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i64, ptr %t136
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t140 = load i1, ptr %l66, !tbaa !21
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32 }, ptr %t143, i32 0, i32 1
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l7, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t147 = load i32, ptr %l7, !tbaa !23
  %t148 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 1
  %t149 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 0
  %t151 = sext i32 %t147 to i64
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t151)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l25, !tbaa !27
  br label %bb105
bb32:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t161 = load ptr, ptr %l73, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = load ptr, ptr %l73, !tbaa !29
  %t165 = load i64, ptr %t164
  %t167 = icmp eq i64 %t165, 5
  store i1 %t167, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l74, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32 }, ptr %t171, i32 0, i32 1
  %t173 = load i32, ptr %t172
  store i32 %t173, ptr %l8, !tbaa !23
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t175 = load i32, ptr %l8, !tbaa !23
  %t176 = extractvalue { i64, ptr } { i64 6, ptr @.d25 }, 1
  %t177 = extractvalue { i64, ptr } { i64 6, ptr @.d25 }, 0
  %t179 = sext i32 %t175 to i64
  %t180 = call i64 @__olang_fmt_i64(ptr null, i64 %t179)
  %t181 = add i64 %t177, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = getelementptr i8, ptr %t182, i64 %t177
  %t184 = call i64 @__olang_fmt_i64(ptr %t183, i64 %t179)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  store { i64, ptr } %t186, ptr %l25, !tbaa !27
  br label %bb105
bb38:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t189 = load ptr, ptr %l81, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load ptr, ptr %l81, !tbaa !29
  %t193 = load i64, ptr %t192
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t196 = load i1, ptr %l82, !tbaa !21
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [21 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t199, i32 0, i32 1
  %t201 = load { i64, [1 x i64] }, ptr %t200
  store { i64, [1 x i64] } %t201, ptr %l9
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [21 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t205, i32 0, i32 2
  %t207 = load i32, ptr %t206
  store i32 %t207, ptr %l10, !tbaa !23
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [21 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t211, i32 0, i32 3
  %t213 = load { i64, [4 x i64] }, ptr %t212
  store { i64, [4 x i64] } %t213, ptr %l11
  br label %bb43
bb42:
  br label %bb47
bb43:
  store %olang.scope zeroinitializer, ptr %s13
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/mir:dumper", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t219 = load i32, ptr %l10, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s13, ptr %t218, i32 %t219)
  store { i64, ptr } %t222, ptr %l94
  br label %bb44
bb44:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load { i64, [4 x i64] }, ptr %l11
  %t227 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s13, ptr %t223, { i64, [4 x i64] } %t224)
  store { i64, ptr } %t227, ptr %l97
  br label %bb45
bb45:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load { i64, [1 x i64] }, ptr %l9
  %t232 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s13, ptr %t228, { i64, [1 x i64] } %t229)
  store { i64, ptr } %t232, ptr %l100
  br label %bb46
bb46:
  %t233 = extractvalue { i64, ptr } { i64 14, ptr @.d26 }, 1
  %t234 = extractvalue { i64, ptr } { i64 14, ptr @.d26 }, 0
  %t235 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 0
  %t241 = add i64 %t238, %t240
  %t242 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 1
  %t247 = extractvalue { i64, ptr } { i64 4, ptr @.d28 }, 0
  %t248 = add i64 %t245, %t247
  %t249 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t252)
  call void @olang_textcopy(ptr %t253, ptr %t233, i64 %t234)
  %t254 = getelementptr i8, ptr %t253, i64 %t234
  call void @olang_textcopy(ptr %t254, ptr %t236, i64 %t237)
  %t255 = getelementptr i8, ptr %t254, i64 %t237
  call void @olang_textcopy(ptr %t255, ptr %t239, i64 %t240)
  %t256 = getelementptr i8, ptr %t255, i64 %t240
  call void @olang_textcopy(ptr %t256, ptr %t243, i64 %t244)
  %t257 = getelementptr i8, ptr %t256, i64 %t244
  call void @olang_textcopy(ptr %t257, ptr %t246, i64 %t247)
  %t258 = getelementptr i8, ptr %t257, i64 %t247
  call void @olang_textcopy(ptr %t258, ptr %t250, i64 %t251)
  %t259 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t253, 1
  store { i64, ptr } %t260, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb105
bb47:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t263 = load ptr, ptr %l102, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb48, label %bb49
bb48:
  %t266 = load ptr, ptr %l102, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 7
  store i1 %t269, ptr %l103, !tbaa !21
  br label %bb49
bb49:
  %t270 = load i1, ptr %l103, !tbaa !21
  br i1 %t270, label %bb50, label %bb51
bb50:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [21 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t273, i32 0, i32 1
  %t275 = load { i64, [1 x i64] }, ptr %t274
  store { i64, [1 x i64] } %t275, ptr %l12
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr { i64, [21 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t279, i32 0, i32 2
  %t281 = load %"compiler/mir:Place", ptr %t280
  store %"compiler/mir:Place" %t281, ptr %l13
  br label %bb52
bb51:
  br label %bb55
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load %"compiler/mir:Place", ptr %l13
  %t287 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s15, ptr %t283, %"compiler/mir:Place" %t284)
  store { i64, ptr } %t287, ptr %l112
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load { i64, [1 x i64] }, ptr %l12
  %t292 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s15, ptr %t288, { i64, [1 x i64] } %t289)
  store { i64, ptr } %t292, ptr %l115
  br label %bb54
bb54:
  %t293 = extractvalue { i64, ptr } { i64 15, ptr @.d29 }, 1
  %t294 = extractvalue { i64, ptr } { i64 15, ptr @.d29 }, 0
  %t295 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = add i64 %t294, %t297
  %t299 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 1
  %t300 = extractvalue { i64, ptr } { i64 4, ptr @.d30 }, 0
  %t301 = add i64 %t298, %t300
  %t302 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = add i64 %t301, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t293, i64 %t294)
  %t307 = getelementptr i8, ptr %t306, i64 %t294
  call void @olang_textcopy(ptr %t307, ptr %t296, i64 %t297)
  %t308 = getelementptr i8, ptr %t307, i64 %t297
  call void @olang_textcopy(ptr %t308, ptr %t299, i64 %t300)
  %t309 = getelementptr i8, ptr %t308, i64 %t300
  call void @olang_textcopy(ptr %t309, ptr %t303, i64 %t304)
  %t310 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t306, 1
  store { i64, ptr } %t311, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb105
bb55:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t314 = load ptr, ptr %l117, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb56, label %bb57
bb56:
  %t317 = load ptr, ptr %l117, !tbaa !29
  %t318 = load i64, ptr %t317
  %t320 = icmp eq i64 %t318, 8
  store i1 %t320, ptr %l118, !tbaa !21
  br label %bb57
bb57:
  %t321 = load i1, ptr %l118, !tbaa !21
  br i1 %t321, label %bb58, label %bb59
bb58:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [21 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t324, i32 0, i32 1
  %t326 = load %"compiler/mir:Place", ptr %t325
  store %"compiler/mir:Place" %t326, ptr %l14
  br label %bb60
bb59:
  br label %bb62
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load %"compiler/mir:Place", ptr %l14
  %t332 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s17, ptr %t328, %"compiler/mir:Place" %t329)
  store { i64, ptr } %t332, ptr %l125
  br label %bb61
bb61:
  %t333 = extractvalue { i64, ptr } { i64 8, ptr @.d31 }, 1
  %t334 = extractvalue { i64, ptr } { i64 8, ptr @.d31 }, 0
  %t335 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t333, i64 %t334)
  %t340 = getelementptr i8, ptr %t339, i64 %t334
  call void @olang_textcopy(ptr %t340, ptr %t336, i64 %t337)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t339, 1
  store { i64, ptr } %t342, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb105
bb62:
  %t344 = load ptr, ptr %l1, !tbaa !29
  store ptr %t344, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t345 = load ptr, ptr %l127, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb63, label %bb64
bb63:
  %t348 = load ptr, ptr %l127, !tbaa !29
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 9
  store i1 %t351, ptr %l128, !tbaa !21
  br label %bb64
bb64:
  %t352 = load i1, ptr %l128, !tbaa !21
  br i1 %t352, label %bb65, label %bb66
bb65:
  %t353 = load ptr, ptr %l1, !tbaa !29
  %t355 = getelementptr { i64, [21 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t355, i32 0, i32 1
  %t357 = load { i64, [1 x i64] }, ptr %t356
  store { i64, [1 x i64] } %t357, ptr %l15
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [21 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t361, i32 0, i32 2
  %t363 = load i32, ptr %t362
  store i32 %t363, ptr %l16
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [21 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t367, i32 0, i32 3
  %t369 = load { i64, [4 x i64] }, ptr %t368
  store { i64, [4 x i64] } %t369, ptr %l17
  br label %bb67
bb66:
  br label %bb72
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t371 = load i32, ptr %l16
  store i32 %t371, ptr %l137
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s20, ptr %l137, i64 0)
  br label %bb68
bb68:
  %t373 = load ptr, ptr %s20
  %t374 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t375 = load i64, ptr %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t373, i64 %t375)
  %t377 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  store { i64, ptr } %t378, ptr %l139, !tbaa !27
  %t379 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t380 = load ptr, ptr %t379
  %t381 = icmp ne ptr %t380, null
  br i1 %t381, label %sbgrew.382, label %sbdone.383
sbgrew.382:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.383
sbdone.383:
  %t384 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t384, 0
  %t386 = extractvalue { i64, ptr } %t384, 1
  %t387 = mul i64 %t385, 1
  %t388 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t388, ptr %t386, i64 %t387, i1 false)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  %t392 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s19, { i64, ptr } %t390)
  store { i64, ptr } %t392, ptr %l141
  br label %bb69
bb69:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load { i64, [4 x i64] }, ptr %l17
  %t397 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s19, ptr %t393, { i64, [4 x i64] } %t394)
  store { i64, ptr } %t397, ptr %l144
  br label %bb70
bb70:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load { i64, [1 x i64] }, ptr %l15
  %t402 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s19, ptr %t398, { i64, [1 x i64] } %t399)
  store { i64, ptr } %t402, ptr %l147
  br label %bb71
bb71:
  %t403 = extractvalue { i64, ptr } { i64 6, ptr @.d32 }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr @.d32 }, 0
  %t405 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = add i64 %t404, %t407
  %t409 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t410 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t411 = add i64 %t408, %t410
  %t412 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = add i64 %t411, %t414
  %t416 = extractvalue { i64, ptr } { i64 4, ptr @.d34 }, 1
  %t417 = extractvalue { i64, ptr } { i64 4, ptr @.d34 }, 0
  %t418 = add i64 %t415, %t417
  %t419 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = add i64 %t418, %t421
  %t423 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t422)
  call void @olang_textcopy(ptr %t423, ptr %t403, i64 %t404)
  %t424 = getelementptr i8, ptr %t423, i64 %t404
  call void @olang_textcopy(ptr %t424, ptr %t406, i64 %t407)
  %t425 = getelementptr i8, ptr %t424, i64 %t407
  call void @olang_textcopy(ptr %t425, ptr %t409, i64 %t410)
  %t426 = getelementptr i8, ptr %t425, i64 %t410
  call void @olang_textcopy(ptr %t426, ptr %t413, i64 %t414)
  %t427 = getelementptr i8, ptr %t426, i64 %t414
  call void @olang_textcopy(ptr %t427, ptr %t416, i64 %t417)
  %t428 = getelementptr i8, ptr %t427, i64 %t417
  call void @olang_textcopy(ptr %t428, ptr %t420, i64 %t421)
  %t429 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t423, 1
  store { i64, ptr } %t430, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb72:
  %t432 = load ptr, ptr %l1, !tbaa !29
  store ptr %t432, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t433 = load ptr, ptr %l149, !tbaa !29
  %t434 = icmp ne ptr %t433, null
  br i1 %t434, label %bb73, label %bb74
bb73:
  %t436 = load ptr, ptr %l149, !tbaa !29
  %t437 = load i64, ptr %t436
  %t439 = icmp eq i64 %t437, 10
  store i1 %t439, ptr %l150, !tbaa !21
  br label %bb74
bb74:
  %t440 = load i1, ptr %l150, !tbaa !21
  br i1 %t440, label %bb75, label %bb76
bb75:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [21 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t443, i32 0, i32 1
  %t445 = load %"compiler/mir:Place", ptr %t444
  store %"compiler/mir:Place" %t445, ptr %l18
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [21 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t449, i32 0, i32 2
  %t451 = load %"compiler/mir:Place", ptr %t450
  store %"compiler/mir:Place" %t451, ptr %l19
  %t453 = load ptr, ptr %l1, !tbaa !29
  %t455 = getelementptr { i64, [21 x i64] }, ptr %t453, i32 0, i32 1
  %t456 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t455, i32 0, i32 3
  %t457 = load { i64, [4 x i64] }, ptr %t456
  store { i64, [4 x i64] } %t457, ptr %l20
  br label %bb77
bb76:
  br label %bb81
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load { i64, [4 x i64] }, ptr %l20
  %t463 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s22, ptr %t459, { i64, [4 x i64] } %t460)
  store { i64, ptr } %t463, ptr %l161
  br label %bb78
bb78:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load %"compiler/mir:Place", ptr %l19
  %t468 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s22, ptr %t464, %"compiler/mir:Place" %t465)
  store { i64, ptr } %t468, ptr %l164
  br label %bb79
bb79:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load %"compiler/mir:Place", ptr %l18
  %t473 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s22, ptr %t469, %"compiler/mir:Place" %t470)
  store { i64, ptr } %t473, ptr %l167
  br label %bb80
bb80:
  %t474 = extractvalue { i64, ptr } { i64 5, ptr @.d35 }, 1
  %t475 = extractvalue { i64, ptr } { i64 5, ptr @.d35 }, 0
  %t476 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 1
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t479 = add i64 %t475, %t478
  %t480 = extractvalue { i64, ptr } { i64 6, ptr @.d36 }, 1
  %t481 = extractvalue { i64, ptr } { i64 6, ptr @.d36 }, 0
  %t482 = add i64 %t479, %t481
  %t483 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t483, 1
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t486 = add i64 %t482, %t485
  %t487 = extractvalue { i64, ptr } { i64 4, ptr @.d37 }, 1
  %t488 = extractvalue { i64, ptr } { i64 4, ptr @.d37 }, 0
  %t489 = add i64 %t486, %t488
  %t490 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = add i64 %t489, %t492
  %t494 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t493)
  call void @olang_textcopy(ptr %t494, ptr %t474, i64 %t475)
  %t495 = getelementptr i8, ptr %t494, i64 %t475
  call void @olang_textcopy(ptr %t495, ptr %t477, i64 %t478)
  %t496 = getelementptr i8, ptr %t495, i64 %t478
  call void @olang_textcopy(ptr %t496, ptr %t480, i64 %t481)
  %t497 = getelementptr i8, ptr %t496, i64 %t481
  call void @olang_textcopy(ptr %t497, ptr %t484, i64 %t485)
  %t498 = getelementptr i8, ptr %t497, i64 %t485
  call void @olang_textcopy(ptr %t498, ptr %t487, i64 %t488)
  %t499 = getelementptr i8, ptr %t498, i64 %t488
  call void @olang_textcopy(ptr %t499, ptr %t491, i64 %t492)
  %t500 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t494, 1
  store { i64, ptr } %t501, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb81:
  %t503 = load ptr, ptr %l1, !tbaa !29
  store ptr %t503, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t504 = load ptr, ptr %l169, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb82, label %bb83
bb82:
  %t507 = load ptr, ptr %l169, !tbaa !29
  %t508 = load i64, ptr %t507
  %t510 = icmp eq i64 %t508, 11
  store i1 %t510, ptr %l170, !tbaa !21
  br label %bb83
bb83:
  %t511 = load i1, ptr %l170, !tbaa !21
  br i1 %t511, label %bb84, label %bb85
bb84:
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t514 = getelementptr { i64, [21 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t514, i32 0, i32 1
  %t516 = load i32, ptr %t515
  store i32 %t516, ptr %l21, !tbaa !23
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr { i64, [21 x i64] }, ptr %t518, i32 0, i32 1
  %t521 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t520, i32 0, i32 2
  %t522 = load i32, ptr %t521
  store i32 %t522, ptr %l22, !tbaa !23
  br label %bb86
bb85:
  br label %bb89
bb86:
  store %olang.scope zeroinitializer, ptr %s24
  %t524 = load i32, ptr %l21, !tbaa !23
  store i32 %t524, ptr %l177, !tbaa !23
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l178, !tbaa !29
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/mir:dumper", ptr %t526, i32 0, i32 0
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = getelementptr %"compiler/mir:Fn", ptr %t529, i32 0, i32 16
  %t532 = load i32, ptr %l22, !tbaa !23
  %t534 = sext i32 %t532 to i64
  %t537 = call %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t531, i64 %t534)
  store %"compiler/mir:Task" %t537, ptr %l184
  br label %bb87
bb87:
  %t538 = load ptr, ptr %l178, !tbaa !29
  %t539 = load %"compiler/mir:Task", ptr %l184
  %t540 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %s24, ptr %t538, %"compiler/mir:Task" %t539)
  store { i64, ptr } %t540, ptr %l185
  br label %bb88
bb88:
  %t541 = extractvalue { i64, ptr } { i64 10, ptr @.d38 }, 1
  %t542 = extractvalue { i64, ptr } { i64 10, ptr @.d38 }, 0
  %t543 = load i32, ptr %l177, !tbaa !23
  %t544 = sext i32 %t543 to i64
  %t545 = call i64 @__olang_fmt_i64(ptr null, i64 %t544)
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 1
  %t548 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 0
  %t549 = add i64 %t546, %t548
  %t550 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = add i64 %t549, %t552
  %t554 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t553)
  call void @olang_textcopy(ptr %t554, ptr %t541, i64 %t542)
  %t555 = getelementptr i8, ptr %t554, i64 %t542
  %t556 = call i64 @__olang_fmt_i64(ptr %t555, i64 %t544)
  %t557 = getelementptr i8, ptr %t555, i64 %t545
  call void @olang_textcopy(ptr %t557, ptr %t547, i64 %t548)
  %t558 = getelementptr i8, ptr %t557, i64 %t548
  call void @olang_textcopy(ptr %t558, ptr %t551, i64 %t552)
  %t559 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t554, 1
  store { i64, ptr } %t560, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  br label %bb105
bb89:
  %t562 = load ptr, ptr %l1, !tbaa !29
  store ptr %t562, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t563 = load ptr, ptr %l187, !tbaa !29
  %t564 = icmp ne ptr %t563, null
  br i1 %t564, label %bb90, label %bb91
bb90:
  %t566 = load ptr, ptr %l187, !tbaa !29
  %t567 = load i64, ptr %t566
  %t569 = icmp eq i64 %t567, 12
  store i1 %t569, ptr %l188, !tbaa !21
  br label %bb91
bb91:
  %t570 = load i1, ptr %l188, !tbaa !21
  br i1 %t570, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  store { i64, ptr } { i64 6, ptr @.d40 }, ptr %l191, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t571, ptr %l25, !tbaa !27
  br label %bb105
bb95:
  %t573 = load ptr, ptr %l1, !tbaa !29
  store ptr %t573, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t574 = load ptr, ptr %l193, !tbaa !29
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %bb96, label %bb97
bb96:
  %t577 = load ptr, ptr %l193, !tbaa !29
  %t578 = load i64, ptr %t577
  %t580 = icmp eq i64 %t578, 13
  store i1 %t580, ptr %l194, !tbaa !21
  br label %bb97
bb97:
  %t581 = load i1, ptr %l194, !tbaa !21
  br i1 %t581, label %bb98, label %bb99
bb98:
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [21 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t584, i32 0, i32 1
  %t586 = load i32, ptr %t585
  store i32 %t586, ptr %l23, !tbaa !23
  %t588 = load ptr, ptr %l1, !tbaa !29
  %t590 = getelementptr { i64, [21 x i64] }, ptr %t588, i32 0, i32 1
  %t591 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t590, i32 0, i32 2
  %t592 = load i32, ptr %t591
  store i32 %t592, ptr %l24, !tbaa !23
  br label %bb100
bb99:
  br label %bb104
bb100:
  store %olang.scope zeroinitializer, ptr %s27
  %t594 = load i32, ptr %l23, !tbaa !23
  store i32 %t594, ptr %l201, !tbaa !23
  %t595 = load i32, ptr %l24, !tbaa !23
  %t596 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t599 = icmp ne i32 %t595, %t596
  br i1 %t599, label %bb101, label %bb102
bb101:
  %t601 = load i32, ptr %l24, !tbaa !23
  %t602 = extractvalue { i64, ptr } { i64 11, ptr @.d41 }, 1
  %t603 = extractvalue { i64, ptr } { i64 11, ptr @.d41 }, 0
  %t605 = sext i32 %t601 to i64
  %t606 = call i64 @__olang_fmt_i64(ptr null, i64 %t605)
  %t607 = add i64 %t603, %t606
  %t608 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t607)
  call void @olang_textcopy(ptr %t608, ptr %t602, i64 %t603)
  %t609 = getelementptr i8, ptr %t608, i64 %t603
  %t610 = call i64 @__olang_fmt_i64(ptr %t609, i64 %t605)
  %t611 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t608, 1
  %t614 = extractvalue { i64, ptr } %t612, 0
  %t615 = extractvalue { i64, ptr } %t612, 1
  %t616 = mul i64 %t614, 1
  %t617 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t616)
  call void @llvm.memcpy.p0.p0.i64(ptr %t617, ptr %t615, i64 %t616, i1 false)
  %t618 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  store { i64, ptr } %t619, ptr %l205, !tbaa !27
  br label %bb103
bb102:
  store { i64, ptr } { i64 5, ptr @.d42 }, ptr %l205, !tbaa !27
  br label %bb103
bb103:
  %t621 = extractvalue { i64, ptr } { i64 13, ptr @.d43 }, 1
  %t622 = extractvalue { i64, ptr } { i64 13, ptr @.d43 }, 0
  %t623 = load i32, ptr %l201, !tbaa !23
  %t624 = sext i32 %t623 to i64
  %t625 = call i64 @__olang_fmt_i64(ptr null, i64 %t624)
  %t626 = add i64 %t622, %t625
  %t627 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t627, 1
  %t629 = extractvalue { i64, ptr } %t627, 0
  %t630 = add i64 %t626, %t629
  %t631 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t630)
  call void @olang_textcopy(ptr %t631, ptr %t621, i64 %t622)
  %t632 = getelementptr i8, ptr %t631, i64 %t622
  %t633 = call i64 @__olang_fmt_i64(ptr %t632, i64 %t624)
  %t634 = getelementptr i8, ptr %t632, i64 %t625
  call void @olang_textcopy(ptr %t634, ptr %t628, i64 %t629)
  %t635 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t631, 1
  store { i64, ptr } %t636, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_63d4bc85d5a0ee63_941776bd89ba250f)
  unreachable
bb105:
  %t638 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t639 = extractvalue { i64, ptr } %t638, 0
  store i64 %t639, ptr %l210, !tbaa !24
  %t640 = load i64, ptr %l210, !tbaa !24
  %t641 = mul i64 %t640, 1
  %t642 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t641)
  %t643 = insertvalue { i64, ptr } undef, i64 %t640, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  store { i64, ptr } %t644, ptr %l211, !tbaa !27
  %t645 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t648 = load ptr, ptr %t647, !tbaa !27
  %t649 = load i64, ptr %l210, !tbaa !24
  %t650 = mul i64 %t649, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t646, ptr %t648, i64 %t650, i1 false)
  %t651 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t651, ptr %l25, !tbaa !27
  %t652 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t652, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l63 = alloca %"compiler/mir:Call"
  %l64 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l91 = alloca i32
  %l92 = alloca i32
  %l96 = alloca { i64, ptr }
  %l106 = alloca i32
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [7 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [7 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr @.d44 }, ptr %l24, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t11, ptr %l21, !tbaa !27
  br label %bb60
bb4:
  %t13 = load { i64, [7 x i64] }, ptr %l1
  %t15 = extractvalue { i64, [7 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 7, ptr @.d45 }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr @.d45 }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  br label %bb60
bb8:
  %t35 = load { i64, [7 x i64] }, ptr %l1
  %t37 = extractvalue { i64, [7 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 2
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t40, i32 0, i32 0
  %t42 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t42, ptr %l4
  %t44 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l4
  %t56 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t52, { i64, [4 x i64] } %t53)
  store { i64, ptr } %t56, ptr %l38
  br label %bb12
bb12:
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 7, ptr @.d46 }, 1
  %t60 = extractvalue { i64, ptr } { i64 7, ptr @.d46 }, 0
  %t61 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 1
  %t66 = extractvalue { i64, ptr } { i64 3, ptr @.d47 }, 0
  %t67 = add i64 %t64, %t66
  %t69 = sext i32 %t57 to i64
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 3, ptr @.d48 }, 1
  %t73 = extractvalue { i64, ptr } { i64 3, ptr @.d48 }, 0
  %t74 = add i64 %t71, %t73
  %t76 = sext i32 %t58 to i64
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t59, i64 %t60)
  %t80 = getelementptr i8, ptr %t79, i64 %t60
  call void @olang_textcopy(ptr %t80, ptr %t62, i64 %t63)
  %t81 = getelementptr i8, ptr %t80, i64 %t63
  call void @olang_textcopy(ptr %t81, ptr %t65, i64 %t66)
  %t82 = getelementptr i8, ptr %t81, i64 %t66
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t69)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t76)
  %t87 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t79, 1
  store { i64, ptr } %t88, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb13:
  %t90 = load { i64, [7 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [7 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb14, label %bb15
bb14:
  %t95 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t95, i32 0, i32 0
  %t97 = load { i64, [4 x i64] }, ptr %t96
  store { i64, [4 x i64] } %t97, ptr %l7
  %t99 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t99, i32 0, i32 1
  %t101 = load %"compiler/mir:Range", ptr %t100
  store %"compiler/mir:Range" %t101, ptr %l8
  %t103 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t104 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t103, i32 0, i32 2
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l9, !tbaa !23
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, [4 x i64] }, ptr %l7
  %t111 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %t107, { i64, [4 x i64] } %t108)
  store { i64, ptr } %t111, ptr %l49
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/mir:Range", ptr %l8
  %t116 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %s6, ptr %t112, %"compiler/mir:Range" %t113)
  store { i64, ptr } %t116, ptr %l52
  br label %bb18
bb18:
  %t117 = load i32, ptr %l9, !tbaa !23
  %t118 = extractvalue { i64, ptr } { i64 7, ptr @.d49 }, 1
  %t119 = extractvalue { i64, ptr } { i64 7, ptr @.d49 }, 0
  %t120 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr @.d50 }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr @.d50 }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 1
  %t132 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t117 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t121, i64 %t122)
  %t140 = getelementptr i8, ptr %t139, i64 %t122
  call void @olang_textcopy(ptr %t140, ptr %t124, i64 %t125)
  %t141 = getelementptr i8, ptr %t140, i64 %t125
  call void @olang_textcopy(ptr %t141, ptr %t128, i64 %t129)
  %t142 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t135)
  %t145 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t138, 1
  store { i64, ptr } %t146, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb19:
  %t148 = load { i64, [7 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [7 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb20, label %bb21
bb20:
  %t153 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32 }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l10, !tbaa !23
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l58, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/mir:Fn", ptr %t158, i32 0, i32 14
  %t161 = load i32, ptr %l10, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t166 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t160, i64 %t163)
  store %"compiler/mir:Call" %t166, ptr %l63
  br label %bb23
bb23:
  %t167 = load ptr, ptr %l58, !tbaa !29
  %t168 = load %"compiler/mir:Call", ptr %l63
  %t169 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %t167, %"compiler/mir:Call" %t168)
  store { i64, ptr } %t169, ptr %l64
  br label %bb24
bb24:
  %t170 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t170, ptr %l21, !tbaa !27
  br label %bb60
bb25:
  %t171 = load { i64, [7 x i64] }, ptr %l1
  %t173 = extractvalue { i64, [7 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 5
  br i1 %t174, label %bb26, label %bb27
bb26:
  %t176 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t176, i32 0, i32 1
  %t178 = load { i64, [4 x i64] }, ptr %t177
  store { i64, [4 x i64] } %t178, ptr %l11
  br label %bb28
bb27:
  br label %bb33
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t180 = load { i64, [4 x i64] }, ptr %l11
  %t182 = extractvalue { i64, [4 x i64] } %t180, 0
  %t183 = icmp eq i64 %t182, 0
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb29, label %bb30
bb29:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [4 x i64] }, ptr %l11
  %t191 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s9, ptr %t187, { i64, [4 x i64] } %t188)
  store { i64, ptr } %t191, ptr %l74
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr @.d52 }, ptr %l71, !tbaa !27
  br label %bb32
bb31:
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  %t194 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = add i64 %t193, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = getelementptr i8, ptr %t198, i64 %t193
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l71, !tbaa !27
  br label %bb32
bb32:
  %t210 = extractvalue { i64, ptr } { i64 6, ptr @.d54 }, 1
  %t211 = extractvalue { i64, ptr } { i64 6, ptr @.d54 }, 0
  %t212 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = add i64 %t211, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t210, i64 %t211)
  %t217 = getelementptr i8, ptr %t216, i64 %t211
  call void @olang_textcopy(ptr %t217, ptr %t213, i64 %t214)
  %t218 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t216, 1
  store { i64, ptr } %t219, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb33:
  %t221 = load { i64, [7 x i64] }, ptr %l1
  %t223 = extractvalue { i64, [7 x i64] } %t221, 0
  %t224 = icmp eq i64 %t223, 6
  br i1 %t224, label %bb34, label %bb35
bb34:
  %t226 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t226, i32 0, i32 1
  %t228 = load { i64, [4 x i64] }, ptr %t227
  store { i64, [4 x i64] } %t228, ptr %l12
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s12
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, [4 x i64] }, ptr %l12
  %t234 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s12, ptr %t230, { i64, [4 x i64] } %t231)
  store { i64, ptr } %t234, ptr %l83
  br label %bb37
bb37:
  %t235 = extractvalue { i64, ptr } { i64 6, ptr @.d55 }, 1
  %t236 = extractvalue { i64, ptr } { i64 6, ptr @.d55 }, 0
  %t237 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = getelementptr i8, ptr %t241, i64 %t236
  call void @olang_textcopy(ptr %t242, ptr %t238, i64 %t239)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  store { i64, ptr } %t244, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb38:
  %t246 = load { i64, [7 x i64] }, ptr %l1
  %t248 = extractvalue { i64, [7 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 7
  br i1 %t249, label %bb39, label %bb40
bb39:
  %t251 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t251, i32 0, i32 1
  %t253 = load i32, ptr %t252
  store i32 %t253, ptr %l13, !tbaa !23
  %t255 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t255, i32 0, i32 2
  %t257 = load i32, ptr %t256
  store i32 %t257, ptr %l14, !tbaa !23
  %t259 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t259, i32 0, i32 3
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l15, !tbaa !23
  %t263 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t263, i32 0, i32 4
  %t265 = load i32, ptr %t264
  store i32 %t265, ptr %l16, !tbaa !23
  br label %bb41
bb40:
  br label %bb45
bb41:
  store %olang.scope zeroinitializer, ptr %s14
  %t267 = load i32, ptr %l13, !tbaa !23
  store i32 %t267, ptr %l91, !tbaa !23
  %t268 = load i32, ptr %l14, !tbaa !23
  store i32 %t268, ptr %l92, !tbaa !23
  %t269 = load i32, ptr %l16, !tbaa !23
  %t270 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t273 = icmp ne i32 %t269, %t270
  br i1 %t273, label %bb42, label %bb43
bb42:
  %t275 = load i32, ptr %l15, !tbaa !23
  %t276 = load i32, ptr %l16, !tbaa !23
  %t277 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 1
  %t278 = extractvalue { i64, ptr } { i64 9, ptr @.d56 }, 0
  %t280 = sext i32 %t275 to i64
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 3, ptr @.d57 }, 1
  %t284 = extractvalue { i64, ptr } { i64 3, ptr @.d57 }, 0
  %t285 = add i64 %t282, %t284
  %t287 = sext i32 %t276 to i64
  %t288 = call i64 @__olang_fmt_i64(ptr null, i64 %t287)
  %t289 = add i64 %t285, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t277, i64 %t278)
  %t291 = getelementptr i8, ptr %t290, i64 %t278
  %t292 = call i64 @__olang_fmt_i64(ptr %t291, i64 %t280)
  %t293 = getelementptr i8, ptr %t291, i64 %t281
  call void @olang_textcopy(ptr %t293, ptr %t283, i64 %t284)
  %t294 = getelementptr i8, ptr %t293, i64 %t284
  %t295 = call i64 @__olang_fmt_i64(ptr %t294, i64 %t287)
  %t296 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t290, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  store { i64, ptr } %t304, ptr %l96, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr @.d58 }, ptr %l96, !tbaa !27
  br label %bb44
bb44:
  %t306 = extractvalue { i64, ptr } { i64 6, ptr @.d59 }, 1
  %t307 = extractvalue { i64, ptr } { i64 6, ptr @.d59 }, 0
  %t308 = load i32, ptr %l91, !tbaa !23
  %t309 = sext i32 %t308 to i64
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t309)
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 8, ptr @.d60 }, 1
  %t313 = extractvalue { i64, ptr } { i64 8, ptr @.d60 }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load i32, ptr %l92, !tbaa !23
  %t316 = sext i32 %t315 to i64
  %t317 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t318 = add i64 %t314, %t317
  %t319 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t306, i64 %t307)
  %t324 = getelementptr i8, ptr %t323, i64 %t307
  %t325 = call i64 @__olang_fmt_i64(ptr %t324, i64 %t309)
  %t326 = getelementptr i8, ptr %t324, i64 %t310
  call void @olang_textcopy(ptr %t326, ptr %t312, i64 %t313)
  %t327 = getelementptr i8, ptr %t326, i64 %t313
  %t328 = call i64 @__olang_fmt_i64(ptr %t327, i64 %t316)
  %t329 = getelementptr i8, ptr %t327, i64 %t317
  call void @olang_textcopy(ptr %t329, ptr %t320, i64 %t321)
  %t330 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t323, 1
  store { i64, ptr } %t331, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb60
bb45:
  %t333 = load { i64, [7 x i64] }, ptr %l1
  %t335 = extractvalue { i64, [7 x i64] } %t333, 0
  %t336 = icmp eq i64 %t335, 8
  br i1 %t336, label %bb46, label %bb47
bb46:
  %t338 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t338, i32 0, i32 1
  %t340 = load i32, ptr %t339
  store i32 %t340, ptr %l17
  %t342 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t342, i32 0, i32 2
  %t344 = load { i64, [4 x i64] }, ptr %t343
  store { i64, [4 x i64] } %t344, ptr %l18
  br label %bb48
bb47:
  br label %bb55
bb48:
  store %olang.scope zeroinitializer, ptr %s17
  %t346 = load i32, ptr %l17
  store i32 %t346, ptr %l106
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s18, ptr %l106, i64 0)
  br label %bb49
bb49:
  %t348 = load ptr, ptr %s18
  %t349 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t350 = load i64, ptr %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t348, i64 %t350)
  %t352 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  store { i64, ptr } %t353, ptr %l108, !tbaa !27
  %t354 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t355 = load ptr, ptr %t354
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %sbgrew.357, label %sbdone.358
sbgrew.357:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.358
sbdone.358:
  %t359 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t361 = extractvalue { i64, ptr } %t359, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t367 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s17, { i64, ptr } %t365)
  store { i64, ptr } %t367, ptr %l110
  br label %bb50
bb50:
  %t368 = load { i64, [4 x i64] }, ptr %l18
  %t370 = extractvalue { i64, [4 x i64] } %t368, 0
  %t371 = icmp eq i64 %t370, 0
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb51, label %bb52
bb51:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load { i64, [4 x i64] }, ptr %l18
  %t379 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t375, { i64, [4 x i64] } %t376)
  store { i64, ptr } %t379, ptr %l117
  br label %bb53
bb52:
  store { i64, ptr } { i64 0, ptr @.d61 }, ptr %l114, !tbaa !27
  br label %bb54
bb53:
  %t380 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  %t382 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = add i64 %t381, %t384
  %t386 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t380, i64 %t381)
  %t387 = getelementptr i8, ptr %t386, i64 %t381
  call void @olang_textcopy(ptr %t387, ptr %t383, i64 %t384)
  %t388 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t386, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  store { i64, ptr } %t396, ptr %l114, !tbaa !27
  br label %bb54
bb54:
  %t398 = extractvalue { i64, ptr } { i64 5, ptr @.d63 }, 1
  %t399 = extractvalue { i64, ptr } { i64 5, ptr @.d63 }, 0
  %t400 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = add i64 %t399, %t402
  %t404 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = add i64 %t403, %t406
  %t408 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t407)
  call void @olang_textcopy(ptr %t408, ptr %t398, i64 %t399)
  %t409 = getelementptr i8, ptr %t408, i64 %t399
  call void @olang_textcopy(ptr %t409, ptr %t401, i64 %t402)
  %t410 = getelementptr i8, ptr %t409, i64 %t402
  call void @olang_textcopy(ptr %t410, ptr %t405, i64 %t406)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t408, 1
  store { i64, ptr } %t412, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb60
bb55:
  %t414 = load { i64, [7 x i64] }, ptr %l1
  %t416 = extractvalue { i64, [7 x i64] } %t414, 0
  %t417 = icmp eq i64 %t416, 9
  br i1 %t417, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store { i64, ptr } { i64 6, ptr @.d64 }, ptr %l123, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t419, ptr %l21, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_8b20d2ead933ce67_842549c98b36ec43)
  unreachable
bb60:
  %t421 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l125, !tbaa !24
  %t423 = load i64, ptr %l125, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l126, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l125, !tbaa !24
  %t433 = mul i64 %t432, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t434, ptr %l21, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t435, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i32, i1 }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i32, i1 }
  %l20 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i1
  %l45 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l92 = alloca { i64, [4 x i64] }
  %l93 = alloca i32
  %l96 = alloca i32
  %l105 = alloca { i32, i1 }
  %l110 = alloca { i64, ptr }
  %l114 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l133 = alloca i32
  %l135 = alloca { i64, ptr }
  %l138 = alloca i32
  %l143 = alloca { i32, i1 }
  %l148 = alloca ptr
  %l151 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  store ptr %t11, ptr %l26, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l29
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load i32, ptr %l29, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l30
  br label %bb2
bb2:
  %t20 = load i32, ptr %l30
  store i32 %t20, ptr %l6
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l33
  br label %bb3
bb3:
  %t26 = load i32, ptr %l33, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp ne i32 %t27, %t28
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l39
  br label %bb6
bb5:
  br label %bb36
bb6:
  %t38 = load i32, ptr %l39, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  %t39 = load i32, ptr %l8, !tbaa !23
  %t41 = icmp eq i32 %t39, 0
  br i1 %t41, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb10
bb8:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = load i32, ptr %l8, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l45
  br label %bb9
bb9:
  %t48 = load i32, ptr %l45
  %t50 = trunc i64 26 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  store i1 %t53, ptr %l42, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l42, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb14
bb12:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t56, i32 %t57)
  store i64 %t60, ptr %l52
  br label %bb13
bb13:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l52, !tbaa !24
  %t64 = icmp ne i64 %t62, %t61
  store i1 %t64, ptr %l49, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l49, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l55, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l58
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = extractvalue { i64, ptr } { i64 2, ptr @.d65 }, 1
  %t75 = extractvalue { i64, ptr } { i64 2, ptr @.d65 }, 0
  %t76 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 9, ptr @.d66 }, 1
  %t81 = extractvalue { i64, ptr } { i64 9, ptr @.d66 }, 0
  %t82 = add i64 %t79, %t81
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t73)
  %t85 = add i64 %t82, %t84
  %t86 = extractvalue { i64, ptr } { i64 9, ptr @.d67 }, 1
  %t87 = extractvalue { i64, ptr } { i64 9, ptr @.d67 }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t74, i64 %t75)
  %t90 = getelementptr i8, ptr %t89, i64 %t75
  call void @olang_textcopy(ptr %t90, ptr %t77, i64 %t78)
  %t91 = getelementptr i8, ptr %t90, i64 %t78
  call void @olang_textcopy(ptr %t91, ptr %t80, i64 %t81)
  %t92 = getelementptr i8, ptr %t91, i64 %t81
  %t93 = call i64 @__olang_fmt_i64(ptr %t92, i64 %t73)
  %t94 = getelementptr i8, ptr %t92, i64 %t84
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t89, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t104, { i64, ptr } %t103)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l5, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb20, label %bb21
bb20:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb22:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l69, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb24
bb24:
  %t134 = load i64, ptr %l69, !tbaa !24
  store i64 %t134, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t135 = load i64, ptr %l66, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t136 = load i64, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  store i64 %t152, ptr %l14, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l87, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l88, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/mir:Range", ptr %l3
  %t158 = load i64, ptr %l14, !tbaa !24
  %t162 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t156, %"compiler/mir:Range" %t157, i64 %t158)
  store { i64, [4 x i64] } %t162, ptr %l92
  br label %bb30
bb30:
  %t163 = load ptr, ptr %l88, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l92
  %t165 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t163, { i64, [4 x i64] } %t164)
  store i32 %t165, ptr %l93
  br label %bb31
bb31:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t167 = load i32, ptr %l7, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t170, ptr %l96
  br label %bb32
bb32:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 1
  %t173 = extractvalue { i64, ptr } { i64 8, ptr @.d68 }, 0
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t172, i64 %t173)
  %t178 = getelementptr i8, ptr %t177, i64 %t173
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t171)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load ptr, ptr %l87, !tbaa !29
  %t190 = load i32, ptr %l93, !tbaa !23
  %t191 = load i32, ptr %l96, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s5, ptr %t189, i32 %t190, i32 %t191, { i64, ptr } %t188)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t193 = load i64, ptr %l13, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l13, !tbaa !24
  br label %bb26
bb35:
  %t197 = load i32, ptr %l1, !tbaa !23
  store i32 %t197, ptr %rv
  br label %ret
bb36:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l1, !tbaa !23
  %t203 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t199, i32 %t200)
  store { i32, i1 } %t203, ptr %l105
  br label %bb37
bb37:
  %t204 = load { i32, i1 }, ptr %l105
  store { i32, i1 } %t204, ptr %l15
  %t205 = getelementptr { i32, i1 }, ptr %l15, i32 0, i32 0
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = getelementptr { i32, i1 }, ptr %l15, i32 0, i32 1
  %t209 = load i1, ptr %t208, !tbaa !21
  store i1 %t209, ptr %l17, !tbaa !21
  %t211 = load ptr, ptr %l4, !tbaa !29
  %t215 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t211, i32 %t206)
  store { i64, ptr } %t215, ptr %l110
  br label %bb38
bb38:
  %t216 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t216, ptr %l18, !tbaa !27
  %t217 = load i1, ptr %l17, !tbaa !21
  br i1 %t217, label %bb39, label %bb40
bb39:
  %t219 = load i64, ptr %l2, !tbaa !24
  %t221 = icmp slt i64 %t219, 0
  br i1 %t221, label %bb41, label %bb42
bb40:
  br label %bb54
bb41:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb43
bb42:
  %t223 = load i64, ptr %l2, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t229 = icmp sge i64 %t223, %t226
  store i1 %t229, ptr %l114, !tbaa !21
  br label %bb43
bb43:
  %t231 = load i1, ptr %l114, !tbaa !21
  br i1 %t231, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l119, !tbaa !29
  %t233 = load i64, ptr %l2, !tbaa !24
  store i64 %t233, ptr %l120, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l1, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %t234, i32 %t235)
  store { i64, ptr } %t238, ptr %l123
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t239 = extractvalue { i64, ptr } { i64 8, ptr @.d69 }, 1
  %t240 = extractvalue { i64, ptr } { i64 8, ptr @.d69 }, 0
  %t241 = load i64, ptr %l120, !tbaa !24
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t241)
  %t243 = add i64 %t240, %t242
  %t244 = extractvalue { i64, ptr } { i64 6, ptr @.d70 }, 1
  %t245 = extractvalue { i64, ptr } { i64 6, ptr @.d70 }, 0
  %t246 = add i64 %t243, %t245
  %t247 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t239, i64 %t240)
  %t252 = getelementptr i8, ptr %t251, i64 %t240
  %t253 = call i64 @__olang_fmt_i64(ptr %t252, i64 %t241)
  %t254 = getelementptr i8, ptr %t252, i64 %t242
  call void @olang_textcopy(ptr %t254, ptr %t244, i64 %t245)
  %t255 = getelementptr i8, ptr %t254, i64 %t245
  call void @olang_textcopy(ptr %t255, ptr %t248, i64 %t249)
  %t256 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t251, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t265 = load ptr, ptr %l119, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t265, { i64, ptr } %t264)
  br label %bb47
bb47:
  %t267 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t267, ptr %rv
  br label %ret
bb48:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l127, !tbaa !29
  %t270 = load i32, ptr %l1, !tbaa !23
  store i32 %t270, ptr %l128, !tbaa !23
  %t271 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t271, ptr %l129, !tbaa !27
  %t272 = load i64, ptr %l2, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr i32, ptr %t275, i64 %t272
  %t277 = load i32, ptr %t276, !tbaa !33
  %t279 = icmp ne i32 %t277, 0
  br i1 %t279, label %bb49, label %bb50
bb49:
  %t281 = load ptr, ptr %l4, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t282, ptr %l135, !tbaa !27
  %t283 = load i64, ptr %l2, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t283
  %t288 = load i32, ptr %t287, !tbaa !33
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t281, i32 %t288)
  store i32 %t291, ptr %l138
  br label %bb51
bb50:
  store i32 0, ptr %l133, !tbaa !23
  br label %bb52
bb51:
  %t292 = load i32, ptr %l138, !tbaa !23
  store i32 %t292, ptr %l133, !tbaa !23
  br label %bb52
bb52:
  %t293 = load %"compiler/mir:Range", ptr %l3
  %t294 = load ptr, ptr %l127, !tbaa !29
  %t295 = load i32, ptr %l128, !tbaa !23
  %t296 = load i32, ptr %l133, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t294, i32 %t295, i32 %t296, %"compiler/mir:Range" %t293)
  br label %bb53
bb53:
  %t298 = load i32, ptr %l1, !tbaa !23
  store i32 %t298, ptr %rv
  br label %ret
bb54:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l1, !tbaa !23
  %t304 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2efieldsOf(ptr %v0, ptr %t300, i32 %t301)
  store { i32, i1 } %t304, ptr %l143
  br label %bb55
bb55:
  %t305 = load { i32, i1 }, ptr %l143
  store { i32, i1 } %t305, ptr %l19
  %t306 = getelementptr { i32, i1 }, ptr %l19, i32 0, i32 0
  %t307 = load i32, ptr %t306, !tbaa !23
  store i32 %t307, ptr %l20, !tbaa !23
  %t309 = getelementptr { i32, i1 }, ptr %l19, i32 0, i32 1
  %t310 = load i1, ptr %t309, !tbaa !21
  %t314 = xor i1 %t310, true
  br i1 %t314, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l148, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l1, !tbaa !23
  %t321 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t317, i32 %t318)
  store { i64, ptr } %t321, ptr %l151
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t322 = extractvalue { i64, ptr } { i64 2, ptr @.d71 }, 1
  %t323 = extractvalue { i64, ptr } { i64 2, ptr @.d71 }, 0
  %t324 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 14, ptr @.d72 }, 1
  %t329 = extractvalue { i64, ptr } { i64 14, ptr @.d72 }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t325, i64 %t326)
  %t333 = getelementptr i8, ptr %t332, i64 %t326
  call void @olang_textcopy(ptr %t333, ptr %t328, i64 %t329)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t331, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t343, { i64, ptr } %t342)
  br label %bb59
bb59:
  %t345 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  store i32 %t345, ptr %rv
  br label %ret
bb60:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i32, ptr %l1, !tbaa !23
  %t349 = load i32, ptr %l20, !tbaa !23
  %t350 = load %"compiler/mir:Range", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t347, i32 %t348, i32 %t349, %"compiler/mir:Range" %t350)
  br label %bb61
bb61:
  %t355 = load i32, ptr %l1, !tbaa !23
  store i32 %t355, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca { i64, [4 x i64] }
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l82 = alloca i64
  %l96 = alloca i32
  %l99 = alloca i32
  %l125 = alloca { i64, [1 x i64] }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l22, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l25
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l22, !tbaa !29
  %t13 = load i32, ptr %l25, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t14, ptr %l26
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t15, ptr %l6, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t25 = icmp ne i64 %t18, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } { i64 10, ptr @.d73 }, 1
  %t34 = extractvalue { i64, ptr } { i64 10, ptr @.d73 }, 0
  %t36 = sext i32 %t29 to i64
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 28, ptr @.d74 }, 1
  %t40 = extractvalue { i64, ptr } { i64 28, ptr @.d74 }, 0
  %t41 = add i64 %t38, %t40
  %t43 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 11, ptr @.d75 }, 1
  %t46 = extractvalue { i64, ptr } { i64 11, ptr @.d75 }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t33, i64 %t34)
  %t49 = getelementptr i8, ptr %t48, i64 %t34
  %t50 = call i64 @__olang_fmt_i64(ptr %t49, i64 %t36)
  %t51 = getelementptr i8, ptr %t49, i64 %t37
  call void @olang_textcopy(ptr %t51, ptr %t39, i64 %t40)
  %t52 = getelementptr i8, ptr %t51, i64 %t40
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t32)
  %t54 = getelementptr i8, ptr %t52, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t48, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t27, { i64, ptr } %t63)
  br label %bb5
bb4:
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l46, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %l43, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l43, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l64, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load %"compiler/mir:Range", ptr %l3
  %t120 = load i64, ptr %l12, !tbaa !24
  %t124 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t118, %"compiler/mir:Range" %t119, i64 %t120)
  store { i64, [4 x i64] } %t124, ptr %l69
  br label %bb16
bb16:
  %t125 = load ptr, ptr %l65, !tbaa !29
  %t126 = load { i64, [4 x i64] }, ptr %l69
  %t127 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t125, { i64, [4 x i64] } %t126)
  store i32 %t127, ptr %l70
  br label %bb17
bb17:
  %t128 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t128, ptr %l71, !tbaa !27
  %t129 = load i64, ptr %l12, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 %t129
  %t134 = load i32, ptr %t133, !tbaa !33
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = extractvalue { i64, ptr } { i64 9, ptr @.d76 }, 1
  %t137 = extractvalue { i64, ptr } { i64 9, ptr @.d76 }, 0
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t136, i64 %t137)
  %t142 = getelementptr i8, ptr %t141, i64 %t137
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t135)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l64, !tbaa !29
  %t154 = load i32, ptr %l70, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s5, ptr %t153, i32 %t154, i32 %t134, { i64, ptr } %t152)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb19:
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l11, !tbaa !24
  br label %bb12
bb20:
  br label %bb21
bb21:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t163 = load i32, ptr %l2, !tbaa !23
  %t167 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t161, { i64, [5 x i64] } %a1, i32 %t163)
  store i64 %t167, ptr %l82
  br label %bb22
bb22:
  %t168 = load i64, ptr %l82, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t171 = load i32, ptr %t170, !tbaa !23
  %t173 = sext i32 %t171 to i64
  %t176 = icmp ne i64 %t169, %t173
  br i1 %t176, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  %t181 = load i64, ptr %l13, !tbaa !24
  %t182 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 1
  %t183 = extractvalue { i64, ptr } { i64 15, ptr @.d77 }, 0
  %t185 = sext i32 %t180 to i64
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 25, ptr @.d78 }, 1
  %t189 = extractvalue { i64, ptr } { i64 25, ptr @.d78 }, 0
  %t190 = add i64 %t187, %t189
  %t192 = call i64 @__olang_fmt_i64(ptr null, i64 %t181)
  %t193 = add i64 %t190, %t192
  %t194 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t182, i64 %t183)
  %t195 = getelementptr i8, ptr %t194, i64 %t183
  %t196 = call i64 @__olang_fmt_i64(ptr %t195, i64 %t185)
  %t197 = getelementptr i8, ptr %t195, i64 %t186
  call void @olang_textcopy(ptr %t197, ptr %t188, i64 %t189)
  %t198 = getelementptr i8, ptr %t197, i64 %t189
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t181)
  %t200 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t194, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t178, { i64, ptr } %t208)
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb26
bb26:
  store i32 0, ptr %l14, !tbaa !23
  %t211 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t212 = load i32, ptr %t211, !tbaa !23
  store i32 %t212, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t214 = load i32, ptr %l15, !tbaa !23
  %t215 = load i32, ptr %l14, !tbaa !23
  %t218 = icmp sgt i32 %t214, %t215
  br i1 %t218, label %bb27, label %bb28
bb27:
  %t220 = load i32, ptr %l16, !tbaa !23
  %t222 = icmp sgt i32 %t220, 0
  br i1 %t222, label %bb29, label %bb30
bb28:
  store i32 0, ptr %l96, !tbaa !23
  br label %bb32
bb29:
  %t224 = load i32, ptr %l15, !tbaa !23
  %t225 = load i32, ptr %l14, !tbaa !23
  %t228 = sub i32 %t224, %t225
  %t229 = load i32, ptr %l16, !tbaa !23
  %t232 = add i32 %t228, %t229
  %t234 = sub i32 %t232, 1
  %t235 = load i32, ptr %l16, !tbaa !23
  %t238 = sdiv i32 %t234, %t235
  store i32 %t238, ptr %l99, !tbaa !23
  br label %bb31
bb30:
  store i32 0, ptr %l99, !tbaa !23
  br label %bb31
bb31:
  %t240 = load i32, ptr %l99, !tbaa !23
  store i32 %t240, ptr %l96, !tbaa !23
  br label %bb32
bb32:
  %t241 = load i32, ptr %l96, !tbaa !23
  store i32 %t241, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s11
  %t242 = load i32, ptr %l18, !tbaa !23
  %t243 = load i32, ptr %l17, !tbaa !23
  %t246 = icmp slt i32 %t242, %t243
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s11)
  br label %bb43
bb35:
  br label %bb36
bb36:
  %t250 = load i32, ptr %l14, !tbaa !23
  %t251 = load i32, ptr %l18, !tbaa !23
  %t252 = load i32, ptr %l16, !tbaa !23
  %t255 = mul i32 %t251, %t252
  %t258 = add i32 %t250, %t255
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/mir:verifier", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/mir:Fn", ptr %t263, i32 0, i32 12
  %t266 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t272 = sext i32 %t258 to i64
  %t275 = add i64 %t269, %t272
  %t278 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t265, i64 %t275)
  store { i64, [1 x i64] } %t278, ptr %l125
  br label %bb37
bb37:
  %t279 = load { i64, [1 x i64] }, ptr %l125
  %t281 = extractvalue { i64, [1 x i64] } %t279, 0
  %t282 = icmp eq i64 %t281, 3
  br i1 %t282, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s12
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s12, ptr %t284, { i64, ptr } { i64 45, ptr @.d79 })
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  %t286 = load i32, ptr %l18, !tbaa !23
  %t288 = add i32 %t286, 1
  store i32 %t288, ptr %l18, !tbaa !23
  br label %bb33
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:verifier", ptr %t15, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t17, { i64, ptr } { i64 4, ptr @.d80 })
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t19, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:verifier", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 2, ptr @.d81 }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr @.d81 }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = extractvalue { i64, ptr } { i64 8, ptr @.d82 }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr @.d82 }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t33, i64 %t34)
  %t42 = getelementptr i8, ptr %t41, i64 %t34
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t32)
  %t44 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t38, i64 %t39)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t41, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t28, { i64, ptr } %t53)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:verifier", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/mir:verifier", ptr %t59, i32 0, i32 3
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 4
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = extractvalue { i64, ptr } { i64 2, ptr @.d83 }, 1
  %t68 = extractvalue { i64, ptr } { i64 2, ptr @.d83 }, 0
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 0
  %t74 = add i64 %t71, %t73
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t66)
  %t77 = add i64 %t74, %t76
  %t78 = extractvalue { i64, ptr } { i64 3, ptr @.d85 }, 1
  %t79 = extractvalue { i64, ptr } { i64 3, ptr @.d85 }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t67, i64 %t68)
  %t82 = getelementptr i8, ptr %t81, i64 %t68
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t62)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t66)
  %t87 = getelementptr i8, ptr %t85, i64 %t76
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t81, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t58, { i64, ptr } %t96)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/mir:verifier", ptr %t99, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %a1)
  br label %bb13
bb13:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t107, i8 10)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 11, ptr @.d86 }, 1
  %t24 = extractvalue { i64, ptr } { i64 11, ptr @.d86 }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l14 = alloca %"compiler/mir:ScopeInfo"
  %l24 = alloca { i64, [1 x i64] }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 8
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:ScopeInfo" %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:ScopeInfo", ptr %l14, i32 0, i32 0
  %t23 = load i32, ptr %t22
  %t25 = trunc i64 6 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l5, !tbaa !21
  br label %bb15
bb5:
  %t28 = load { i64, [1 x i64] }, ptr %l1
  %t30 = extractvalue { i64, [1 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/mir:Fn", ptr %t40, i32 0, i32 6
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t42, i64 %t43)
  store { i64, [1 x i64] } %t46, ptr %l24
  br label %bb9
bb9:
  %t47 = load { i64, [1 x i64] }, ptr %l24
  %t49 = extractvalue { i64, [1 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 5
  store i1 %t50, ptr %l5, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9c289c76542078e7_53d9d4aa9af07973)
  unreachable
bb15:
  %t52 = load i1, ptr %l5, !tbaa !21
  %t55 = xor i1 %t52, true
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } { i64 27, ptr @.d87 })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i32
  %rv = alloca i32
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i1, ptr %l9, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t20 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t14, i32 %a1, i64 %a2)
  store i64 %t20, ptr %l15
  br label %bb4
bb4:
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t22 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp ne i64 %t22, %t21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l11, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l22
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l25
  br label %bb10
bb10:
  %t40 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t43 = or i64 %t41, %t40
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i32, ptr %l22, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t44, i32 %t45, i64 %t43)
  store i32 %t47, ptr %l28
  br label %bb11
bb11:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_62f33ceaa6d0d243_a40627fd170062cf)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i32, ptr %l5
  %t11 = trunc i64 21 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l12
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = extractvalue { i64, ptr } { i64 23, ptr @.d88 }, 1
  %t23 = extractvalue { i64, ptr } { i64 23, ptr @.d88 }, 0
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t39, { i64, ptr } %t38)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l76 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load i32, ptr %l19
  %t19 = trunc i64 22 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l25
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = load i32, ptr %l25, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l26
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l28, !tbaa !24
  %t35 = load i64, ptr %l28, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = icmp sle i64 %t38, 2305843009213693951
  br i1 %t39, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb9:
  %t41 = load i64, ptr %l28, !tbaa !24
  %t42 = mul i64 %t41, 4
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb11:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb16
bb13:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l40, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb15
bb15:
  %t77 = load i64, ptr %l40, !tbaa !24
  store i64 %t77, ptr %l37, !tbaa !24
  br label %bb16
bb16:
  %t78 = load i64, ptr %l37, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l1, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l62, !tbaa !27
  %t102 = load i64, ptr %l11, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t98, i32 %t99, i64 %t100, i32 %t107)
  store i32 %t112, ptr %l65
  br label %bb21
bb21:
  %t113 = load i32, ptr %l65, !tbaa !23
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t114
  store i32 %t113, ptr %t117, !tbaa !33
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l10, !tbaa !24
  br label %bb17
bb23:
  %t122 = load ptr, ptr %l2, !tbaa !29
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t123, { i64, ptr } %t124)
  store i32 %t127, ptr %l71
  br label %bb24
bb24:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load i32, ptr %l71, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l72
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t131 = load i32, ptr %l72, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i32, ptr %l3, !tbaa !23
  %t138 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t132, i32 %t133, i64 0, i32 %t134)
  store i32 %t138, ptr %l76
  br label %bb27
bb27:
  %t139 = load i32, ptr %l76, !tbaa !23
  store i32 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l16
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l12, !tbaa !23
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  %t28 = load i32, ptr %l12, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t33, ptr %l21
  br label %bb8
bb8:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l4, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i32, ptr %l29, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l30
  br label %bb12
bb12:
  %t50 = load i32, ptr %l30, !tbaa !23
  %t51 = icmp eq i32 %t50, 7
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d89 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d89 }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca %"compiler/mir:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 7
  %t9 = sext i32 %a1 to i64
  %t12 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t6, i64 %t9)
  store %"compiler/mir:Local" %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/mir:Local", ptr %l7, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 4, ptr @.d90 }, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  %t13 = sext i32 %t9 to i64
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = getelementptr i8, ptr %t16, i64 %t11
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t13)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l11, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l18
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i32, ptr %l18, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t33, ptr %l23
  br label %bb8
bb8:
  %t34 = load i32, ptr %l23, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb12
bb10:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb11
bb11:
  %t46 = load i32, ptr %l30, !tbaa !23
  %t47 = icmp ne i32 %t46, 0
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l35
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d92 }, 1
  %t57 = extractvalue { i64, ptr } { i64 18, ptr @.d92 }, 0
  %t58 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 29, ptr @.d93 }, 1
  %t63 = extractvalue { i64, ptr } { i64 29, ptr @.d93 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t77, { i64, ptr } %t76)
  br label %bb16
bb16:
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t79, ptr %rv
  br label %ret
bb17:
  %t81 = load ptr, ptr %l4, !tbaa !29
  store ptr %t81, ptr %l39, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  store ptr %t82, ptr %l40, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t83, { i64, [4 x i64] } %a2)
  store i32 %t87, ptr %l43
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load i32, ptr %l43, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t90, ptr %l44
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t93, ptr %l45
  br label %bb20
bb20:
  %t94 = load i1, ptr %l45, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t97, { i64, ptr } { i64 39, ptr @.d94 })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l48, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t100, { i64, [4 x i64] } %a3)
  store i32 %t104, ptr %l51
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l4, !tbaa !29
  %t106 = load i32, ptr %l6, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l54
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l48, !tbaa !29
  %t111 = load i32, ptr %l51, !tbaa !23
  %t112 = load i32, ptr %l54, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s0, ptr %t110, i32 %t111, i32 %t112, { i64, ptr } { i64 18, ptr @.d95 })
  br label %bb27
bb27:
  %t113 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Place", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t10, %"compiler/mir:Place" %t11)
  br label %bb4
bb4:
  br label %bb22
bb5:
  %t14 = load { i64, [4 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [4 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 3
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = icmp slt i32 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb12
bb10:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:verifier", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/mir:Fn", ptr %t33, i32 0, i32 19
  %t37 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l20
  br label %bb11
bb11:
  %t38 = load i64, ptr %l16, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = icmp sge i64 %t38, %t39
  store i1 %t40, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l14, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t45 = extractvalue { i64, ptr } { i64 12, ptr @.d96 }, 1
  %t46 = extractvalue { i64, ptr } { i64 12, ptr @.d96 }, 0
  %t48 = sext i32 %t44 to i64
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = getelementptr i8, ptr %t51, i64 %t46
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t48)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t43, { i64, ptr } %t62)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_293fa35c34966465_23dfef653c6d5c71)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l4 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  br label %bb16
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Place" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Place", ptr %t14
  store %"compiler/mir:Place" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t18 = load %"compiler/mir:Place", ptr %l2
  %t21 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %t18)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb16
bb9:
  %t23 = load { i64, [4 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [4 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb14
bb11:
  %t32 = load { i64, [4 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [4 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 3
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9)
  unreachable
bb16:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l8 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l1
  %t8 = trunc i64 3 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l1
  %t13 = trunc i64 4 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 6 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp eq i32 %t27, 2
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb21
bb10:
  %t31 = load i32, ptr %l1
  %t33 = trunc i64 0 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l8, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97)
  unreachable
bb21:
  %t46 = load i1, ptr %l8, !tbaa !21
  %t49 = xor i1 %t46, true
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load i32, ptr %l1
  store i32 %t52, ptr %l28
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s5, ptr %l28, i64 0)
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t54 = load ptr, ptr %s5
  %t55 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l30, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.64
sbdone.64:
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s4, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l32
  br label %bb25
bb25:
  %t74 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t76 = extractvalue { i64, ptr } { i64 21, ptr @.d97 }, 1
  %t77 = extractvalue { i64, ptr } { i64 21, ptr @.d97 }, 0
  %t78 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 4, ptr @.d98 }, 1
  %t83 = extractvalue { i64, ptr } { i64 4, ptr @.d98 }, 0
  %t84 = add i64 %t81, %t83
  %t86 = sext i32 %t75 to i64
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 9, ptr @.d99 }, 1
  %t90 = extractvalue { i64, ptr } { i64 9, ptr @.d99 }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t76, i64 %t77)
  %t93 = getelementptr i8, ptr %t92, i64 %t77
  call void @olang_textcopy(ptr %t93, ptr %t79, i64 %t80)
  %t94 = getelementptr i8, ptr %t93, i64 %t80
  call void @olang_textcopy(ptr %t94, ptr %t82, i64 %t83)
  %t95 = getelementptr i8, ptr %t94, i64 %t83
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t86)
  %t97 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t89, i64 %t90)
  %t98 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t92, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } %t106)
  br label %bb26
bb26:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t109, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l4, !tbaa !29
  store ptr %t111, ptr %l37, !tbaa !29
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t113 = load i32, ptr %l2, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l40
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l37, !tbaa !29
  %t118 = load i32, ptr %l40, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t119, ptr %l41
  br label %bb29
bb29:
  %t120 = load i1, ptr %l41, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l43, !tbaa !29
  %t124 = load i32, ptr %l1
  store i32 %t124, ptr %l44
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l44, i64 0)
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t126 = load ptr, ptr %s8
  %t127 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t128 = load i64, ptr %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t126, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l46, !tbaa !27
  %t132 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t133 = load ptr, ptr %t132
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %sbgrew.135, label %sbdone.136
sbgrew.135:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.136
sbdone.136:
  %t137 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, { i64, ptr } %t143)
  store { i64, ptr } %t145, ptr %l48
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s7, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l51
  br label %bb34
bb34:
  %t151 = extractvalue { i64, ptr } { i64 20, ptr @.d100 }, 1
  %t152 = extractvalue { i64, ptr } { i64 20, ptr @.d100 }, 0
  %t153 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 6, ptr @.d101 }, 1
  %t158 = extractvalue { i64, ptr } { i64 6, ptr @.d101 }, 0
  %t159 = add i64 %t156, %t158
  %t160 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 16, ptr @.d102 }, 1
  %t165 = extractvalue { i64, ptr } { i64 16, ptr @.d102 }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t151, i64 %t152)
  %t168 = getelementptr i8, ptr %t167, i64 %t152
  call void @olang_textcopy(ptr %t168, ptr %t154, i64 %t155)
  %t169 = getelementptr i8, ptr %t168, i64 %t155
  call void @olang_textcopy(ptr %t169, ptr %t157, i64 %t158)
  %t170 = getelementptr i8, ptr %t169, i64 %t158
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t164, i64 %t165)
  %t172 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t167, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t181 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t181, { i64, ptr } %t180)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca %"compiler/mir:Range"
  %l19 = alloca i64
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l10
  br label %bb4
bb4:
  br label %bb15
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 20, ptr @.d103 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_70d66502dd431e07_8b33d36aabf56353)
  unreachable
bb15:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t27 = load %"compiler/mir:Range", ptr %t26
  store %"compiler/mir:Range" %t27, ptr %l15
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/mir:verifier", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/mir:Fn", ptr %t31, i32 0, i32 10
  %t35 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l19
  br label %bb16
bb16:
  %t36 = load ptr, ptr %l14, !tbaa !29
  %t37 = load %"compiler/mir:Range", ptr %l15
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t36, %"compiler/mir:Range" %t37, i64 %t38, { i64, ptr } { i64 11, ptr @.d104 })
  store i1 %t39, ptr %l20
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i64
  %l15 = alloca { i32, i1 }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca { i32, i1 }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i32
  %l38 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l83 = alloca { i64, [1 x i64] }
  %l89 = alloca { i32, i1 }
  %l94 = alloca { i64, ptr }
  %l97 = alloca i1
  %l100 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i64
  %l109 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca { i64, ptr }
  %l138 = alloca i32
  %l142 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l151 = alloca i32
  %l157 = alloca i32
  %l161 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l170 = alloca i32
  %l173 = alloca i1
  %l176 = alloca i1
  %l179 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i64
  %l186 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca i64
  %l192 = alloca { i64, ptr }
  %l197 = alloca i32
  %l202 = alloca i1
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l213 = alloca i32
  %l219 = alloca { i32, i1 }
  %l224 = alloca { i64, ptr }
  %l227 = alloca i1
  %l230 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i64
  %l239 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca i64
  %l251 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l3
  %t9 = load { i64, [2 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 1
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l38
  br label %bb4
bb4:
  %t23 = load i32, ptr %l38, !tbaa !23
  store i32 %t23, ptr %l32, !tbaa !23
  br label %bb14
bb5:
  %t24 = load { i64, [2 x i64] }, ptr %l3
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 2
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t30 = getelementptr { i64, i32, i32 }, ptr %t29, i32 0, i32 2
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t33 = load i32, ptr %l5, !tbaa !23
  store i32 %t33, ptr %l32, !tbaa !23
  br label %bb14
bb9:
  %t35 = load { i64, [2 x i64] }, ptr %l3
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t40, ptr %l32, !tbaa !23
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2986d82de8391aaf_d61db5ce8081183b)
  unreachable
bb14:
  %t42 = load i32, ptr %l32, !tbaa !23
  store i32 %t42, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  %t43 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t44 = getelementptr %"compiler/mir:Range", ptr %t43, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  store i32 %t45, ptr %l8, !tbaa !23
  store i32 1, ptr %l9, !tbaa !23
  %t47 = load i32, ptr %l8, !tbaa !23
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = icmp sgt i32 %t47, %t48
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load i32, ptr %l9, !tbaa !23
  %t55 = icmp sgt i32 %t53, 0
  br i1 %t55, label %bb17, label %bb18
bb16:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb20
bb17:
  %t57 = load i32, ptr %l8, !tbaa !23
  %t58 = load i32, ptr %l7, !tbaa !23
  %t61 = sub i32 %t57, %t58
  %t62 = load i32, ptr %l9, !tbaa !23
  %t65 = add i32 %t61, %t62
  %t67 = sub i32 %t65, 1
  %t68 = load i32, ptr %l9, !tbaa !23
  %t71 = sdiv i32 %t67, %t68
  store i32 %t71, ptr %l53, !tbaa !23
  br label %bb19
bb18:
  store i32 0, ptr %l53, !tbaa !23
  br label %bb19
bb19:
  %t73 = load i32, ptr %l53, !tbaa !23
  store i32 %t73, ptr %l50, !tbaa !23
  br label %bb20
bb20:
  %t74 = load i32, ptr %l50, !tbaa !23
  store i32 %t74, ptr %l10, !tbaa !23
  store i32 0, ptr %l11, !tbaa !23
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = load i32, ptr %l11, !tbaa !23
  %t76 = load i32, ptr %l10, !tbaa !23
  %t79 = icmp slt i32 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb129
bb23:
  br label %bb24
bb24:
  %t83 = load i32, ptr %l7, !tbaa !23
  %t84 = load i32, ptr %l11, !tbaa !23
  %t85 = load i32, ptr %l9, !tbaa !23
  %t88 = mul i32 %t84, %t85
  %t91 = add i32 %t83, %t88
  store i32 %t91, ptr %l12, !tbaa !23
  %t93 = load i32, ptr %l6, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t97 = icmp eq i32 %t93, %t94
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  store i32 %t99, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/mir:verifier", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/mir:Fn", ptr %t104, i32 0, i32 10
  %t107 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t108 = getelementptr %"compiler/mir:Range", ptr %t107, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t112 = load i32, ptr %l12, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t117 = add i64 %t111, %t114
  %t120 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t106, i64 %t117)
  store { i64, [1 x i64] } %t120, ptr %l83
  br label %bb28
bb28:
  %t121 = load { i64, [1 x i64] }, ptr %l83
  store { i64, [1 x i64] } %t121, ptr %l13
  %t122 = load { i64, [1 x i64] }, ptr %l13
  %t124 = extractvalue { i64, [1 x i64] } %t122, 0
  %t125 = icmp eq i64 %t124, 0
  br i1 %t125, label %bb29, label %bb30
bb29:
  %t127 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t128 = getelementptr { i64 }, ptr %t127, i32 0, i32 0
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l14, !tbaa !24
  br label %bb31
bb30:
  br label %bb45
bb31:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2efieldsOf(ptr %v0, ptr %t131, i32 %t132)
  store { i32, i1 } %t135, ptr %l89
  br label %bb32
bb32:
  %t136 = load { i32, i1 }, ptr %l89
  store { i32, i1 } %t136, ptr %l15
  %t137 = getelementptr { i32, i1 }, ptr %l15, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = getelementptr { i32, i1 }, ptr %l15, i32 0, i32 1
  %t141 = load i1, ptr %t140, !tbaa !21
  store i1 %t141, ptr %l17, !tbaa !21
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t147 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t143, i32 %t138)
  store { i64, ptr } %t147, ptr %l94
  br label %bb33
bb33:
  %t148 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t148, ptr %l18, !tbaa !27
  %t149 = load i1, ptr %l17, !tbaa !21
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb36
bb35:
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = icmp slt i64 %t153, 0
  store i1 %t155, ptr %l97, !tbaa !21
  br label %bb36
bb36:
  %t157 = load i1, ptr %l97, !tbaa !21
  br i1 %t157, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t158 = load i64, ptr %l14, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t164 = icmp sge i64 %t158, %t161
  store i1 %t164, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t166 = load i1, ptr %l100, !tbaa !21
  br i1 %t166, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l105, !tbaa !29
  %t168 = load i64, ptr %l14, !tbaa !24
  store i64 %t168, ptr %l106, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l6, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s8, ptr %t169, i32 %t170)
  store { i64, ptr } %t173, ptr %l109
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t174 = extractvalue { i64, ptr } { i64 9, ptr @.d105 }, 1
  %t175 = extractvalue { i64, ptr } { i64 9, ptr @.d105 }, 0
  %t176 = load i64, ptr %l106, !tbaa !24
  %t177 = call i64 @__olang_fmt_i64(ptr null, i64 %t176)
  %t178 = add i64 %t175, %t177
  %t179 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 1
  %t180 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t174, i64 %t175)
  %t187 = getelementptr i8, ptr %t186, i64 %t175
  %t188 = call i64 @__olang_fmt_i64(ptr %t187, i64 %t176)
  %t189 = getelementptr i8, ptr %t187, i64 %t177
  call void @olang_textcopy(ptr %t189, ptr %t179, i64 %t180)
  %t190 = getelementptr i8, ptr %t189, i64 %t180
  call void @olang_textcopy(ptr %t190, ptr %t183, i64 %t184)
  %t191 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t186, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t200, { i64, ptr } %t199)
  br label %bb43
bb43:
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t202, ptr %rv
  br label %ret
bb44:
  %t204 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t204, ptr %l113, !tbaa !27
  %t205 = load i64, ptr %l14, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i32, ptr %t208, i64 %t205
  %t210 = load i32, ptr %t209, !tbaa !33
  store i32 %t210, ptr %l6, !tbaa !23
  br label %bb127
bb45:
  %t212 = load { i64, [1 x i64] }, ptr %l13
  %t214 = extractvalue { i64, [1 x i64] } %t212, 0
  %t215 = icmp eq i64 %t214, 1
  br i1 %t215, label %bb46, label %bb47
bb46:
  %t217 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t218 = getelementptr { i32 }, ptr %t217, i32 0, i32 0
  %t219 = load i32, ptr %t218
  store i32 %t219, ptr %l19, !tbaa !23
  br label %bb48
bb47:
  br label %bb65
bb48:
  %t221 = load ptr, ptr %l2, !tbaa !29
  store ptr %t221, ptr %l119, !tbaa !29
  %t222 = load ptr, ptr %l2, !tbaa !29
  store ptr %t222, ptr %l120, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l19, !tbaa !23
  %t227 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l123
  br label %bb49
bb49:
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = load i32, ptr %l123, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t228, i32 %t229)
  store i32 %t230, ptr %l124
  br label %bb50
bb50:
  %t231 = load ptr, ptr %l119, !tbaa !29
  %t232 = load i32, ptr %l124, !tbaa !23
  %t233 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t231, i32 %t232)
  store i1 %t233, ptr %l125
  br label %bb51
bb51:
  %t234 = load i1, ptr %l125, !tbaa !21
  %t235 = xor i1 %t234, true
  br i1 %t235, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l127, !tbaa !29
  %t238 = load i32, ptr %l19, !tbaa !23
  store i32 %t238, ptr %l128, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l129, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l19, !tbaa !23
  %t244 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l132
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t245 = load ptr, ptr %l129, !tbaa !29
  %t246 = load i32, ptr %l132, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t245, i32 %t246)
  store { i64, ptr } %t247, ptr %l133
  br label %bb55
bb55:
  %t248 = extractvalue { i64, ptr } { i64 10, ptr @.d107 }, 1
  %t249 = extractvalue { i64, ptr } { i64 10, ptr @.d107 }, 0
  %t250 = load i32, ptr %l128, !tbaa !23
  %t251 = sext i32 %t250 to i64
  %t252 = call i64 @__olang_fmt_i64(ptr null, i64 %t251)
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 6, ptr @.d108 }, 1
  %t255 = extractvalue { i64, ptr } { i64 6, ptr @.d108 }, 0
  %t256 = add i64 %t253, %t255
  %t257 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t248, i64 %t249)
  %t262 = getelementptr i8, ptr %t261, i64 %t249
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t251)
  %t264 = getelementptr i8, ptr %t262, i64 %t252
  call void @olang_textcopy(ptr %t264, ptr %t254, i64 %t255)
  %t265 = getelementptr i8, ptr %t264, i64 %t255
  call void @olang_textcopy(ptr %t265, ptr %t258, i64 %t259)
  %t266 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t261, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = extractvalue { i64, ptr } %t267, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t275 = load ptr, ptr %l127, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t275, { i64, ptr } %t274)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i32, ptr %l6, !tbaa !23
  %t281 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t281, ptr %l138
  br label %bb58
bb58:
  %t282 = load i32, ptr %l138, !tbaa !23
  store i32 %t282, ptr %l20, !tbaa !23
  %t283 = load i32, ptr %l20, !tbaa !23
  %t284 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t287 = icmp eq i32 %t283, %t284
  br i1 %t287, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s13
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l142, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l6, !tbaa !23
  %t294 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s13, ptr %t290, i32 %t291)
  store { i64, ptr } %t294, ptr %l145
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t295 = extractvalue { i64, ptr } { i64 16, ptr @.d109 }, 1
  %t296 = extractvalue { i64, ptr } { i64 16, ptr @.d109 }, 0
  %t297 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 14, ptr @.d110 }, 1
  %t302 = extractvalue { i64, ptr } { i64 14, ptr @.d110 }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t316, { i64, ptr } %t315)
  br label %bb62
bb62:
  %t318 = load i32, ptr %l20, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t318, ptr %rv
  br label %ret
bb63:
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t321 = load i32, ptr %l20, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l151
  br label %bb64
bb64:
  %t325 = load i32, ptr %l151, !tbaa !23
  store i32 %t325, ptr %l6, !tbaa !23
  br label %bb127
bb65:
  %t326 = load { i64, [1 x i64] }, ptr %l13
  %t328 = extractvalue { i64, [1 x i64] } %t326, 0
  %t329 = icmp eq i64 %t328, 2
  br i1 %t329, label %bb66, label %bb67
bb66:
  %t331 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t332 = getelementptr { i64 }, ptr %t331, i32 0, i32 0
  %t333 = load i64, ptr %t332
  store i64 %t333, ptr %l21, !tbaa !24
  br label %bb68
bb67:
  br label %bb93
bb68:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l6, !tbaa !23
  %t339 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t339, ptr %l157
  br label %bb69
bb69:
  %t340 = load i32, ptr %l157, !tbaa !23
  store i32 %t340, ptr %l22, !tbaa !23
  %t341 = load i32, ptr %l22, !tbaa !23
  %t342 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t345 = icmp eq i32 %t341, %t342
  br i1 %t345, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l161, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l6, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s16, ptr %t348, i32 %t349)
  store { i64, ptr } %t352, ptr %l164
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t353 = extractvalue { i64, ptr } { i64 16, ptr @.d111 }, 1
  %t354 = extractvalue { i64, ptr } { i64 16, ptr @.d111 }, 0
  %t355 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = add i64 %t354, %t357
  %t359 = extractvalue { i64, ptr } { i64 14, ptr @.d112 }, 1
  %t360 = extractvalue { i64, ptr } { i64 14, ptr @.d112 }, 0
  %t361 = add i64 %t358, %t360
  %t362 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t353, i64 %t354)
  %t363 = getelementptr i8, ptr %t362, i64 %t354
  call void @olang_textcopy(ptr %t363, ptr %t356, i64 %t357)
  %t364 = getelementptr i8, ptr %t363, i64 %t357
  call void @olang_textcopy(ptr %t364, ptr %t359, i64 %t360)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t362, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = extractvalue { i64, ptr } %t366, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  %t374 = load ptr, ptr %l161, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s16, ptr %t374, { i64, ptr } %t373)
  br label %bb73
bb73:
  %t376 = load i32, ptr %l22, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t376, ptr %rv
  br label %ret
bb74:
  %t378 = load ptr, ptr %l2, !tbaa !29
  %t379 = load i32, ptr %l22, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l170
  br label %bb75
bb75:
  %t383 = load i32, ptr %l170, !tbaa !23
  store i32 %t383, ptr %l23, !tbaa !23
  %t384 = load i64, ptr %l21, !tbaa !24
  %t386 = icmp slt i64 %t384, 0
  br i1 %t386, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb86
bb77:
  %t388 = load i32, ptr %l23, !tbaa !23
  %t390 = icmp ne i32 %t388, 0
  br i1 %t390, label %bb78, label %bb79
bb78:
  %t392 = load ptr, ptr %l2, !tbaa !29
  %t393 = load i32, ptr %l23, !tbaa !23
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t392, i32 %t393)
  store i32 %t396, ptr %l179
  br label %bb80
bb79:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb81
bb80:
  %t397 = load i32, ptr %l179
  %t399 = trunc i64 26 to i32
  %t400 = icmp eq i32 %t397, %t399
  store i1 %t400, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t402 = load i1, ptr %l176, !tbaa !21
  br i1 %t402, label %bb82, label %bb83
bb82:
  %t403 = load i64, ptr %l21, !tbaa !24
  store i64 %t403, ptr %l183, !tbaa !24
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t405 = load i32, ptr %l23, !tbaa !23
  %t408 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t404, i32 %t405)
  store i64 %t408, ptr %l186
  br label %bb84
bb83:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb85
bb84:
  %t409 = load i64, ptr %l183, !tbaa !24
  %t410 = load i64, ptr %l186, !tbaa !24
  %t411 = icmp sge i64 %t409, %t410
  store i1 %t411, ptr %l182, !tbaa !21
  br label %bb85
bb85:
  %t413 = load i1, ptr %l182, !tbaa !21
  store i1 %t413, ptr %l173, !tbaa !21
  br label %bb86
bb86:
  %t414 = load i1, ptr %l173, !tbaa !21
  br i1 %t414, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l188, !tbaa !29
  %t416 = load i64, ptr %l21, !tbaa !24
  store i64 %t416, ptr %l189, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l6, !tbaa !23
  %t421 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s18, ptr %t417, i32 %t418)
  store { i64, ptr } %t421, ptr %l192
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t422 = extractvalue { i64, ptr } { i64 15, ptr @.d113 }, 1
  %t423 = extractvalue { i64, ptr } { i64 15, ptr @.d113 }, 0
  %t424 = load i64, ptr %l189, !tbaa !24
  %t425 = call i64 @__olang_fmt_i64(ptr null, i64 %t424)
  %t426 = add i64 %t423, %t425
  %t427 = extractvalue { i64, ptr } { i64 11, ptr @.d114 }, 1
  %t428 = extractvalue { i64, ptr } { i64 11, ptr @.d114 }, 0
  %t429 = add i64 %t426, %t428
  %t430 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = add i64 %t429, %t432
  %t434 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t433)
  call void @olang_textcopy(ptr %t434, ptr %t422, i64 %t423)
  %t435 = getelementptr i8, ptr %t434, i64 %t423
  %t436 = call i64 @__olang_fmt_i64(ptr %t435, i64 %t424)
  %t437 = getelementptr i8, ptr %t435, i64 %t425
  call void @olang_textcopy(ptr %t437, ptr %t427, i64 %t428)
  %t438 = getelementptr i8, ptr %t437, i64 %t428
  call void @olang_textcopy(ptr %t438, ptr %t431, i64 %t432)
  %t439 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t434, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = extractvalue { i64, ptr } %t440, 1
  %t444 = mul i64 %t442, 1
  %t445 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t443, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  %t448 = load ptr, ptr %l188, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t448, { i64, ptr } %t447)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb91:
  %t450 = load ptr, ptr %l2, !tbaa !29
  %t451 = load i32, ptr %l22, !tbaa !23
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t450, i32 %t451)
  store i32 %t454, ptr %l197
  br label %bb92
bb92:
  %t455 = load i32, ptr %l197, !tbaa !23
  store i32 %t455, ptr %l6, !tbaa !23
  br label %bb127
bb93:
  %t456 = load { i64, [1 x i64] }, ptr %l13
  %t458 = extractvalue { i64, [1 x i64] } %t456, 0
  %t459 = icmp eq i64 %t458, 3
  br i1 %t459, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb104
bb96:
  %t461 = load ptr, ptr %l2, !tbaa !29
  %t462 = load i32, ptr %l6, !tbaa !23
  %t465 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t461, i32 %t462)
  store i1 %t465, ptr %l202
  br label %bb97
bb97:
  %t466 = load i1, ptr %l202, !tbaa !21
  %t467 = xor i1 %t466, true
  br i1 %t467, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s21
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l204, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i32, ptr %l6, !tbaa !23
  %t474 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s21, ptr %t470, i32 %t471)
  store { i64, ptr } %t474, ptr %l207
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t475 = extractvalue { i64, ptr } { i64 13, ptr @.d115 }, 1
  %t476 = extractvalue { i64, ptr } { i64 13, ptr @.d115 }, 0
  %t477 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 1
  %t479 = extractvalue { i64, ptr } %t477, 0
  %t480 = add i64 %t476, %t479
  %t481 = extractvalue { i64, ptr } { i64 17, ptr @.d116 }, 1
  %t482 = extractvalue { i64, ptr } { i64 17, ptr @.d116 }, 0
  %t483 = add i64 %t480, %t482
  %t484 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t483)
  call void @olang_textcopy(ptr %t484, ptr %t475, i64 %t476)
  %t485 = getelementptr i8, ptr %t484, i64 %t476
  call void @olang_textcopy(ptr %t485, ptr %t478, i64 %t479)
  %t486 = getelementptr i8, ptr %t485, i64 %t479
  call void @olang_textcopy(ptr %t486, ptr %t481, i64 %t482)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t484, 1
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  %t496 = load ptr, ptr %l204, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t496, { i64, ptr } %t495)
  br label %bb101
bb101:
  %t498 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t498, ptr %rv
  br label %ret
bb102:
  %t500 = load ptr, ptr %l2, !tbaa !29
  %t501 = load i32, ptr %l6, !tbaa !23
  %t504 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l213
  br label %bb103
bb103:
  %t505 = load i32, ptr %l213, !tbaa !23
  store i32 %t505, ptr %l6, !tbaa !23
  br label %bb127
bb104:
  %t506 = load { i64, [1 x i64] }, ptr %l13
  %t508 = extractvalue { i64, [1 x i64] } %t506, 0
  %t509 = icmp eq i64 %t508, 4
  br i1 %t509, label %bb105, label %bb106
bb105:
  %t511 = getelementptr { i64, [1 x i64] }, ptr %l13, i32 0, i32 1
  %t512 = getelementptr { i64 }, ptr %t511, i32 0, i32 0
  %t513 = load i64, ptr %t512
  store i64 %t513, ptr %l24, !tbaa !24
  br label %bb107
bb106:
  br label %bb126
bb107:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i32, ptr %l6, !tbaa !23
  %t519 = call { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %t515, i32 %t516)
  store { i32, i1 } %t519, ptr %l219
  br label %bb108
bb108:
  %t520 = load { i32, i1 }, ptr %l219
  store { i32, i1 } %t520, ptr %l25
  %t521 = getelementptr { i32, i1 }, ptr %l25, i32 0, i32 0
  %t522 = load i32, ptr %t521, !tbaa !23
  %t524 = getelementptr { i32, i1 }, ptr %l25, i32 0, i32 1
  %t525 = load i1, ptr %t524, !tbaa !21
  store i1 %t525, ptr %l27, !tbaa !21
  %t527 = load ptr, ptr %l2, !tbaa !29
  %t531 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t527, i32 %t522)
  store { i64, ptr } %t531, ptr %l224
  br label %bb109
bb109:
  %t532 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t532, ptr %l28, !tbaa !27
  %t533 = load i1, ptr %l27, !tbaa !21
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l227, !tbaa !21
  br label %bb112
bb111:
  %t537 = load i64, ptr %l24, !tbaa !24
  %t539 = icmp slt i64 %t537, 0
  store i1 %t539, ptr %l227, !tbaa !21
  br label %bb112
bb112:
  %t541 = load i1, ptr %l227, !tbaa !21
  br i1 %t541, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb115
bb114:
  %t542 = load i64, ptr %l24, !tbaa !24
  %t543 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t548 = icmp sge i64 %t542, %t545
  store i1 %t548, ptr %l230, !tbaa !21
  br label %bb115
bb115:
  %t550 = load i1, ptr %l230, !tbaa !21
  br i1 %t550, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s24
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l235, !tbaa !29
  %t552 = load i64, ptr %l24, !tbaa !24
  store i64 %t552, ptr %l236, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load i32, ptr %l6, !tbaa !23
  %t557 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s24, ptr %t553, i32 %t554)
  store { i64, ptr } %t557, ptr %l239
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t558 = extractvalue { i64, ptr } { i64 8, ptr @.d117 }, 1
  %t559 = extractvalue { i64, ptr } { i64 8, ptr @.d117 }, 0
  %t560 = load i64, ptr %l236, !tbaa !24
  %t561 = call i64 @__olang_fmt_i64(ptr null, i64 %t560)
  %t562 = add i64 %t559, %t561
  %t563 = extractvalue { i64, ptr } { i64 6, ptr @.d118 }, 1
  %t564 = extractvalue { i64, ptr } { i64 6, ptr @.d118 }, 0
  %t565 = add i64 %t562, %t564
  %t566 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t566, 1
  %t568 = extractvalue { i64, ptr } %t566, 0
  %t569 = add i64 %t565, %t568
  %t570 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t569)
  call void @olang_textcopy(ptr %t570, ptr %t558, i64 %t559)
  %t571 = getelementptr i8, ptr %t570, i64 %t559
  %t572 = call i64 @__olang_fmt_i64(ptr %t571, i64 %t560)
  %t573 = getelementptr i8, ptr %t571, i64 %t561
  call void @olang_textcopy(ptr %t573, ptr %t563, i64 %t564)
  %t574 = getelementptr i8, ptr %t573, i64 %t564
  call void @olang_textcopy(ptr %t574, ptr %t567, i64 %t568)
  %t575 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t570, 1
  %t578 = extractvalue { i64, ptr } %t576, 0
  %t579 = extractvalue { i64, ptr } %t576, 1
  %t580 = mul i64 %t578, 1
  %t581 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t580)
  call void @llvm.memcpy.p0.p0.i64(ptr %t581, ptr %t579, i64 %t580, i1 false)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t581, 1
  %t584 = load ptr, ptr %l235, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t584, { i64, ptr } %t583)
  br label %bb119
bb119:
  %t586 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t586, ptr %rv
  br label %ret
bb120:
  %t588 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t588, ptr %l243, !tbaa !27
  %t589 = load i64, ptr %l24, !tbaa !24
  %t591 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !27
  %t593 = getelementptr i32, ptr %t592, i64 %t589
  %t594 = load i32, ptr %t593, !tbaa !33
  %t596 = icmp eq i32 %t594, 0
  br i1 %t596, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s26
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l247, !tbaa !29
  %t599 = load i64, ptr %l24, !tbaa !24
  store i64 %t599, ptr %l248, !tbaa !24
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load i32, ptr %l6, !tbaa !23
  %t604 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t600, i32 %t601)
  store { i64, ptr } %t604, ptr %l251
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t605 = extractvalue { i64, ptr } { i64 5, ptr @.d119 }, 1
  %t606 = extractvalue { i64, ptr } { i64 5, ptr @.d119 }, 0
  %t607 = load i64, ptr %l248, !tbaa !24
  %t608 = call i64 @__olang_fmt_i64(ptr null, i64 %t607)
  %t609 = add i64 %t606, %t608
  %t610 = extractvalue { i64, ptr } { i64 6, ptr @.d120 }, 1
  %t611 = extractvalue { i64, ptr } { i64 6, ptr @.d120 }, 0
  %t612 = add i64 %t609, %t611
  %t613 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = add i64 %t612, %t615
  %t617 = extractvalue { i64, ptr } { i64 15, ptr @.d121 }, 1
  %t618 = extractvalue { i64, ptr } { i64 15, ptr @.d121 }, 0
  %t619 = add i64 %t616, %t618
  %t620 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t619)
  call void @olang_textcopy(ptr %t620, ptr %t605, i64 %t606)
  %t621 = getelementptr i8, ptr %t620, i64 %t606
  %t622 = call i64 @__olang_fmt_i64(ptr %t621, i64 %t607)
  %t623 = getelementptr i8, ptr %t621, i64 %t608
  call void @olang_textcopy(ptr %t623, ptr %t610, i64 %t611)
  %t624 = getelementptr i8, ptr %t623, i64 %t611
  call void @olang_textcopy(ptr %t624, ptr %t614, i64 %t615)
  %t625 = getelementptr i8, ptr %t624, i64 %t615
  call void @olang_textcopy(ptr %t625, ptr %t617, i64 %t618)
  %t626 = insertvalue { i64, ptr } undef, i64 %t619, 0
  %t627 = insertvalue { i64, ptr } %t626, ptr %t620, 1
  %t629 = extractvalue { i64, ptr } %t627, 0
  %t630 = extractvalue { i64, ptr } %t627, 1
  %t631 = mul i64 %t629, 1
  %t632 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t632, ptr %t630, i64 %t631, i1 false)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t632, 1
  %t635 = load ptr, ptr %l247, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t635, { i64, ptr } %t634)
  br label %bb124
bb124:
  %t637 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s5)
  store i32 %t637, ptr %rv
  br label %ret
bb125:
  %t639 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t639, ptr %l255, !tbaa !27
  %t640 = load i64, ptr %l24, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i32, ptr %t643, i64 %t640
  %t645 = load i32, ptr %t644, !tbaa !33
  store i32 %t645, ptr %l6, !tbaa !23
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_b3d4ae2f12f779ee_96af6ec666a78bba)
  unreachable
bb127:
  call void @__olang_scope_close(ptr %s5)
  br label %bb128
bb128:
  %t647 = load i32, ptr %l11, !tbaa !23
  %t649 = add i32 %t647, 1
  store i32 %t649, ptr %l11, !tbaa !23
  br label %bb21
bb129:
  %t651 = load i32, ptr %l6, !tbaa !23
  store i32 %t651, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/mir:verifier", ptr %t9, i32 0, i32 17
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t19, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %t22
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 17
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/mir:verifier", ptr %t40, i32 0, i32 17
  %t44 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l27
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 1, ptr @.d122 }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr @.d122 }, 0
  %t51 = sext i32 %t46 to i64
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t47, 1
  %t59 = extractvalue { i64, ptr } %t47, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 20, ptr @.d124 }, 1
  %t62 = extractvalue { i64, ptr } { i64 20, ptr @.d124 }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t51)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } %t78)
  br label %bb15
bb12:
  %t81 = load i64, ptr %l27, !tbaa !24
  %t82 = sub i64 %t81, 1
  %t83 = load ptr, ptr %l24, !tbaa !29
  %t85 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t83, i64 %t82)
  store i32 %t85, ptr %l29
  br label %bb13
bb13:
  %t86 = extractvalue { i64, ptr } { i64 1, ptr @.d125 }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d125 }, 0
  %t88 = load i32, ptr %l21, !tbaa !23
  %t89 = sext i32 %t88 to i64
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 8, ptr @.d127 }, 1
  %t100 = extractvalue { i64, ptr } { i64 8, ptr @.d127 }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load i32, ptr %l29, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 23, ptr @.d128 }, 1
  %t107 = extractvalue { i64, ptr } { i64 23, ptr @.d128 }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t86, i64 %t87)
  %t110 = getelementptr i8, ptr %t109, i64 %t87
  %t111 = call i64 @__olang_fmt_i64(ptr %t110, i64 %t89)
  %t112 = getelementptr i8, ptr %t110, i64 %t90
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t96, i64 %t97)
  %t114 = getelementptr i8, ptr %t113, i64 %t97
  call void @olang_textcopy(ptr %t114, ptr %t99, i64 %t100)
  %t115 = getelementptr i8, ptr %t114, i64 %t100
  %t116 = call i64 @__olang_fmt_i64(ptr %t115, i64 %t103)
  %t117 = getelementptr i8, ptr %t115, i64 %t104
  call void @olang_textcopy(ptr %t117, ptr %t106, i64 %t107)
  %t118 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t109, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t127, { i64, ptr } %t126)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/mir:verifier", ptr %t129, i32 0, i32 17
  %t133 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t131)
  %t134 = extractvalue { i32, i32 } %t133, 1
  %t135 = extractvalue { i32, i32 } %t133, 0
  store i32 %t135, ptr %l41
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb19, label %ok.137
ok.137:
  store i32 %t134, ptr %l40
  br label %bb18
bb18:
  %t138 = load i32, ptr %l40, !tbaa !23
  store i32 %t138, ptr %l37, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_check_failed(ptr @olang_loc_525ae97147cf6b9b_c46e40fbd793c77f)
  unreachable
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [21 x i64] }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca ptr
  %l55 = alloca %"compiler/mir:BasicBlock"
  %l57 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l77 = alloca %"compiler/mir:BasicBlock"
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, [21 x i64] }
  %l95 = alloca { i64, [21 x i64] }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l122 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l147 = alloca i64
  %l150 = alloca i64
  %l169 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l31
  br label %bb1
bb1:
  %t9 = load i64, ptr %l31, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l33, !tbaa !24
  %t12 = load i64, ptr %l33, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l33, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = load ptr, ptr %l32, !tbaa !29
  %t22 = getelementptr %"compiler/mir:verifier", ptr %t21, i32 0, i32 13
  store { i64, ptr } %t19, ptr %t22, !tbaa !27
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l36
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608)
  unreachable
bb4:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 0)
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/mir:verifier", ptr %t27, i32 0, i32 13
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l39, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i1, ptr %t32, i64 0
  store i1 true, ptr %t33, !tbaa !31
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  store i64 %t35, ptr %l41
  br label %bb7
bb7:
  %t36 = load i64, ptr %l41, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb74
bb9:
  br label %bb10
bb10:
  %t42 = call { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  %t43 = extractvalue { i32, i32 } %t42, 1
  %t44 = extractvalue { i32, i32 } %t42, 0
  store i32 %t44, ptr %l47
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb12, label %ok.46
ok.46:
  store i32 %t43, ptr %l46
  br label %bb11
bb11:
  %t47 = load i32, ptr %l46, !tbaa !23
  store i32 %t47, ptr %l44, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_check_failed(ptr @olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6)
  unreachable
bb14:
  %t48 = load i32, ptr %l44, !tbaa !23
  store i32 %t48, ptr %l3, !tbaa !23
  %t49 = load ptr, ptr @__olang_prog_scope
  %t50 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %t49)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l48
  br label %bb15
bb15:
  %t51 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l49, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/mir:verifier", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/mir:Fn", ptr %t56, i32 0, i32 9
  %t59 = load i32, ptr %l3, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t64 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t58, i64 %t61)
  store %"compiler/mir:BasicBlock" %t64, ptr %l55
  br label %bb16
bb16:
  %t65 = getelementptr %"compiler/mir:BasicBlock", ptr %l55, i32 0, i32 1
  %t66 = load { i64, [7 x i64] }, ptr %t65
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t69 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %s3, ptr %t67, { i64, [7 x i64] } %t66)
  store { i64, ptr } %t69, ptr %l57
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 4
  %t74 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t96)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb18
bb24:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 9
  %t111 = load i32, ptr %l3, !tbaa !23
  %t113 = sext i32 %t111 to i64
  %t116 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t110, i64 %t113)
  store %"compiler/mir:BasicBlock" %t116, ptr %l77
  br label %bb25
bb25:
  %t117 = getelementptr %"compiler/mir:BasicBlock", ptr %l77, i32 0, i32 0
  store ptr %t117, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %s6, ptr %t119, i64 %t120)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l83
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb28, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l82
  br label %bb27
bb27:
  %t128 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t128, ptr %l79, !tbaa !27
  br label %bb32
bb28:
  %t129 = load i32, ptr %l83, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_7127dab5ce57c749_b077692428e4994d)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb32:
  %t134 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t134, ptr %l11, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t147 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t147, ptr %l92, !tbaa !27
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, [21 x i64] }, ptr %t151, i64 %t148
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t152, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l94, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %l14, i64 176, i1 false)
  %t153 = load { i64, [21 x i64] }, ptr %l95
  %t154 = extractvalue { i64, [21 x i64] } %t153, 0
  %t155 = icmp eq i64 %t154, 13
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t157 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l15, !tbaa !23
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t161 = load i32, ptr %l15, !tbaa !23
  %t162 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t165 = icmp ne i32 %t161, %t162
  br i1 %t165, label %bb40, label %bb41
bb40:
  %t167 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t167)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_76a99ae981c91c78_ffe52510b3cdb11c)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb33
bb51:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t175 = load i64, ptr %l12, !tbaa !24
  %t178 = add i64 %t174, %t175
  store i64 %t178, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  br label %bb26
bb53:
  call void @__olang_scope_close(ptr %s6)
  store ptr %l4, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s14
  %t181 = load ptr, ptr %l16, !tbaa !29
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t181, i64 %t182)
  %t186 = extractvalue { i32, { i64, ptr } } %t185, 1
  %t187 = extractvalue { i32, { i64, ptr } } %t185, 0
  store i32 %t187, ptr %l113
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb56, label %ok.189
ok.189:
  store { i64, ptr } %t186, ptr %l112
  br label %bb55
bb55:
  %t190 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t190, ptr %l109, !tbaa !27
  br label %bb60
bb56:
  %t191 = load i32, ptr %l113, !tbaa !23
  %t192 = ashr i32 %t191, 16
  %t194 = icmp eq i32 %t192, 1
  br i1 %t194, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_18d9829ba3f5a2af_a05952e551f4e6bb)
  unreachable
bb59:
  call void @__olang_scope_close(ptr %s14)
  br label %bb72
bb60:
  %t196 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t196, ptr %l18, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t201 = load i64, ptr %l20, !tbaa !24
  %t202 = load i64, ptr %l19, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s15)
  br label %bb70
bb63:
  br label %bb64
bb64:
  %t209 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t209, ptr %l122, !tbaa !27
  %t210 = load i64, ptr %l20, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  store i32 %t215, ptr %l21, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/mir:verifier", ptr %t217, i32 0, i32 13
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l126, !tbaa !27
  %t221 = load i32, ptr %l21, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t225 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i1, ptr %t226, i64 %t223
  %t228 = load i1, ptr %t227, !tbaa !31
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb65, label %bb66
bb65:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/mir:verifier", ptr %t232, i32 0, i32 13
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l132, !tbaa !27
  %t236 = load i32, ptr %l21, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t240 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i1, ptr %t241, i64 %t238
  store i1 true, ptr %t242, !tbaa !31
  %t243 = load i32, ptr %l21, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 %t243)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb69:
  %t246 = load i64, ptr %l20, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l20, !tbaa !24
  br label %bb61
bb70:
  %t250 = load i64, ptr %l17, !tbaa !24
  %t251 = load i64, ptr %l19, !tbaa !24
  %t254 = add i64 %t250, %t251
  store i64 %t254, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb71:
  br label %bb54
bb72:
  call void @__olang_scope_close(ptr %s1)
  br label %bb73
bb73:
  br label %bb6
bb74:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/mir:verifier", ptr %t256, i32 0, i32 4
  store i64 -1, ptr %t258, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l1, !tbaa !24
  store i64 %t259, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t261 = load i64, ptr %l23, !tbaa !24
  %t262 = load i64, ptr %l22, !tbaa !24
  %t265 = icmp sgt i64 %t261, %t262
  br i1 %t265, label %bb75, label %bb76
bb75:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb80
bb77:
  %t271 = load i64, ptr %l23, !tbaa !24
  %t272 = load i64, ptr %l22, !tbaa !24
  %t275 = sub i64 %t271, %t272
  %t276 = load i64, ptr %l24, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = sub i64 %t279, 1
  %t282 = load i64, ptr %l24, !tbaa !24
  %t285 = sdiv i64 %t281, %t282
  store i64 %t285, ptr %l150, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb79
bb79:
  %t287 = load i64, ptr %l150, !tbaa !24
  store i64 %t287, ptr %l147, !tbaa !24
  br label %bb80
bb80:
  %t288 = load i64, ptr %l147, !tbaa !24
  store i64 %t288, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t289 = load i64, ptr %l26, !tbaa !24
  %t290 = load i64, ptr %l25, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s19)
  br label %bb90
bb83:
  br label %bb84
bb84:
  %t297 = load i64, ptr %l22, !tbaa !24
  %t298 = load i64, ptr %l26, !tbaa !24
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = mul i64 %t298, %t299
  %t305 = add i64 %t297, %t302
  store i64 %t305, ptr %l27, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/mir:verifier", ptr %t307, i32 0, i32 13
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l169, !tbaa !27
  %t311 = load i64, ptr %l27, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i1, ptr %t314, i64 %t311
  %t316 = load i1, ptr %t315, !tbaa !31
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i64, ptr %l27, !tbaa !24
  %t324 = getelementptr %"compiler/mir:verifier", ptr %t320, i32 0, i32 3
  store i64 %t321, ptr %t324, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t325, { i64, ptr } { i64 35, ptr @.d129 })
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s20)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s19)
  br label %bb89
bb89:
  %t327 = load i64, ptr %l26, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l26, !tbaa !24
  br label %bb81
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l12, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %l12, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l12, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load i32, ptr %l6, !tbaa !23
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l1
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = add i32 %t62, 1
  store i32 %t64, ptr %l6, !tbaa !23
  br label %bb7
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t13, i32 %t14)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b)
  unreachable
bb10:
  store i32 0, ptr %l4, !tbaa !23
  %t17 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t18 = getelementptr %"compiler/mir:Range", ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l5, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = icmp sgt i32 %t21, %t22
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  br i1 %t29, label %bb13, label %bb14
bb12:
  store i32 0, ptr %l22, !tbaa !23
  br label %bb16
bb13:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = sub i32 %t31, %t32
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = add i32 %t35, %t36
  %t41 = sub i32 %t39, 1
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = sdiv i32 %t41, %t42
  store i32 %t45, ptr %l25, !tbaa !23
  br label %bb15
bb14:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb15
bb15:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %l22, !tbaa !23
  br label %bb16
bb16:
  %t48 = load i32, ptr %l22, !tbaa !23
  store i32 %t48, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load i32, ptr %l8, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = icmp slt i32 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t58 = load i32, ptr %l8, !tbaa !23
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = mul i32 %t58, %t59
  %t65 = add i32 %t57, %t62
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/mir:Fn", ptr %t70, i32 0, i32 10
  %t73 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t74 = getelementptr %"compiler/mir:Range", ptr %t73, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = sext i32 %t65 to i64
  %t83 = add i64 %t77, %t80
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t72, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l51
  br label %bb21
bb21:
  %t87 = load { i64, [1 x i64] }, ptr %l51
  store { i64, [1 x i64] } %t87, ptr %l10
  %t88 = load { i64, [1 x i64] }, ptr %l10
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l11, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t97, i32 %t98)
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t101 = load i32, ptr %l8, !tbaa !23
  %t103 = add i32 %t101, 1
  store i32 %t103, ptr %l8, !tbaa !23
  br label %bb17
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load %"compiler/mir:Place", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a5f83820f05cb9f9_5f257facca4b96a5)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l32 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l10
  br label %bb4
bb4:
  br label %bb27
bb5:
  %t15 = load { i64, [1 x i64] }, ptr %l1
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 1
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb12
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/mir:Fn", ptr %t32, i32 0, i32 6
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load i64, ptr %l17, !tbaa !24
  %t38 = load i64, ptr %l21, !tbaa !24
  %t39 = icmp sge i64 %t37, %t38
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l16, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = extractvalue { i64, ptr } { i64 19, ptr @.d130 }, 1
  %t45 = extractvalue { i64, ptr } { i64 19, ptr @.d130 }, 0
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t48 = add i64 %t45, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = getelementptr i8, ptr %t49, i64 %t45
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t60)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t63 = load { i64, [1 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [1 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32 }, ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l4, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l4, !tbaa !23
  %t76 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6be72733009cb689_7eadbfb9b429b955)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i1, ptr %l8, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l13
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = extractvalue { i64, ptr } { i64 18, ptr @.d131 }, 1
  %t21 = extractvalue { i64, ptr } { i64 18, ptr @.d131 }, 0
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = getelementptr i8, ptr %t26, i64 %t21
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t37 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t37, { i64, ptr } %t36)
  br label %bb5
bb5:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t39, ptr %rv
  br label %ret
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp ne i32 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  store i32 %t48, ptr %l22, !tbaa !23
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t55 = load i32, ptr %l22, !tbaa !23
  %t56 = load i32, ptr %l25, !tbaa !23
  %t57 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t54, i32 %t55, i32 %t56)
  store i1 %t57, ptr %l26
  br label %bb10
bb10:
  %t58 = load i1, ptr %l26, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l20, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l28, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l31
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l34
  br label %bb15
bb15:
  %t73 = extractvalue { i64, ptr } { i64 12, ptr @.d132 }, 1
  %t74 = extractvalue { i64, ptr } { i64 12, ptr @.d132 }, 0
  %t75 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 6, ptr @.d133 }, 1
  %t80 = extractvalue { i64, ptr } { i64 6, ptr @.d133 }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t73, i64 %t74)
  %t87 = getelementptr i8, ptr %t86, i64 %t74
  call void @olang_textcopy(ptr %t87, ptr %t76, i64 %t77)
  %t88 = getelementptr i8, ptr %t87, i64 %t77
  call void @olang_textcopy(ptr %t88, ptr %t79, i64 %t80)
  %t89 = getelementptr i8, ptr %t88, i64 %t80
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t86, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t99 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t99, { i64, ptr } %t98)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t101 = load i32, ptr %l2, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %t7)
  br label %bb5
bb5:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %t9)
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %t11)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Place"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca { i64, [1 x i64] }
  %l99 = alloca i32
  %l102 = alloca i32
  %l120 = alloca ptr
  %l129 = alloca { i64, [1 x i64] }
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb5
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 11
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t19, { i64, [4 x i64] } %t20)
  br label %bb6
bb6:
  br label %bb75
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Place", ptr %t29
  store %"compiler/mir:Place" %t30, ptr %l3
  br label %bb14
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 2
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Place" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Place", ptr %t38
  store %"compiler/mir:Place" %t39, ptr %l3
  br label %bb14
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 5
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Place" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Place", ptr %t47
  store %"compiler/mir:Place" %t48, ptr %l3
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/mir:Place", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t50, %"compiler/mir:Place" %t51)
  br label %bb15
bb15:
  br label %bb75
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 3
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb23
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb23
bb20:
  %t72 = load { i64, [15 x i64] }, ptr %l1
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 6
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/mir:Range", ptr %t78
  store %"compiler/mir:Range" %t79, ptr %l4
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t81, %"compiler/mir:Range" %t82)
  br label %bb24
bb24:
  br label %bb75
bb25:
  %t85 = load { i64, [15 x i64] }, ptr %l1
  %t87 = extractvalue { i64, [15 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 7
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t91 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, [1 x i64] }, ptr %t91
  store { i64, [1 x i64] } %t92, ptr %l5
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t94, i32 0, i32 1
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l6
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t98, { i64, [4 x i64] } %t99)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t102, { i64, [1 x i64] } %t103)
  br label %bb30
bb30:
  br label %bb75
bb31:
  %t106 = load { i64, [15 x i64] }, ptr %l1
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 8
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t112 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 0
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l7
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t116 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t115, i32 0, i32 2
  %t117 = load { i64, [4 x i64] }, ptr %t116
  store { i64, [4 x i64] } %t117, ptr %l8
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t120 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t119, i32 0, i32 3
  %t121 = load { i64, [4 x i64] }, ptr %t120
  store { i64, [4 x i64] } %t121, ptr %l9
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t123, { i64, [4 x i64] } %t124)
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t127, { i64, [4 x i64] } %t128)
  br label %bb36
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t131, { i64, [1 x i64] } %t132)
  br label %bb37
bb37:
  br label %bb75
bb38:
  %t135 = load { i64, [15 x i64] }, ptr %l1
  %t137 = extractvalue { i64, [15 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 9
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t141 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/mir:Place", ptr %t141
  store %"compiler/mir:Place" %t142, ptr %l10
  %t144 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t145 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t144, i32 0, i32 1
  %t146 = load { i64, [4 x i64] }, ptr %t145
  store { i64, [4 x i64] } %t146, ptr %l11
  %t148 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t149 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t148, i32 0, i32 2
  %t150 = load { i64, [4 x i64] }, ptr %t149
  store { i64, [4 x i64] } %t150, ptr %l12
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/mir:Place", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t152, %"compiler/mir:Place" %t153)
  br label %bb42
bb42:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t156, { i64, [4 x i64] } %t157)
  br label %bb43
bb43:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t160, { i64, [4 x i64] } %t161)
  br label %bb44
bb44:
  br label %bb75
bb45:
  %t164 = load { i64, [15 x i64] }, ptr %l1
  %t166 = extractvalue { i64, [15 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 10
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t169, i32 0, i32 2
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l13
  %t173 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t174 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t173, i32 0, i32 3
  %t175 = load %"compiler/mir:Range", ptr %t174
  store %"compiler/mir:Range" %t175, ptr %l14
  %t177 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t178 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t177, i32 0, i32 4
  %t179 = load %"compiler/mir:Range", ptr %t178
  store %"compiler/mir:Range" %t179, ptr %l15
  br label %bb48
bb47:
  br label %bb68
bb48:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t181, %"compiler/mir:Range" %t182)
  br label %bb49
bb49:
  %t185 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t186 = load i32, ptr %t185, !tbaa !23
  %t188 = icmp sgt i32 %t186, 0
  br i1 %t188, label %bb50, label %bb51
bb50:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t190, { i64, [1 x i64] } %t191)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  store i32 0, ptr %l16, !tbaa !23
  %t194 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  store i32 %t195, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t197 = load i32, ptr %l17, !tbaa !23
  %t198 = load i32, ptr %l16, !tbaa !23
  %t201 = icmp sgt i32 %t197, %t198
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t203 = load i32, ptr %l18, !tbaa !23
  %t205 = icmp sgt i32 %t203, 0
  br i1 %t205, label %bb56, label %bb57
bb55:
  store i32 0, ptr %l99, !tbaa !23
  br label %bb59
bb56:
  %t207 = load i32, ptr %l17, !tbaa !23
  %t208 = load i32, ptr %l16, !tbaa !23
  %t211 = sub i32 %t207, %t208
  %t212 = load i32, ptr %l18, !tbaa !23
  %t215 = add i32 %t211, %t212
  %t217 = sub i32 %t215, 1
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = sdiv i32 %t217, %t218
  store i32 %t221, ptr %l102, !tbaa !23
  br label %bb58
bb57:
  store i32 0, ptr %l102, !tbaa !23
  br label %bb58
bb58:
  %t223 = load i32, ptr %l102, !tbaa !23
  store i32 %t223, ptr %l99, !tbaa !23
  br label %bb59
bb59:
  %t224 = load i32, ptr %l99, !tbaa !23
  store i32 %t224, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load i32, ptr %l20, !tbaa !23
  %t226 = load i32, ptr %l19, !tbaa !23
  %t229 = icmp slt i32 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t233 = load i32, ptr %l16, !tbaa !23
  %t234 = load i32, ptr %l20, !tbaa !23
  %t235 = load i32, ptr %l18, !tbaa !23
  %t238 = mul i32 %t234, %t235
  %t241 = add i32 %t233, %t238
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l120, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/mir:verifier", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/mir:Fn", ptr %t247, i32 0, i32 12
  %t250 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  %t256 = sext i32 %t241 to i64
  %t259 = add i64 %t253, %t256
  %t262 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t249, i64 %t259)
  store { i64, [1 x i64] } %t262, ptr %l129
  br label %bb64
bb64:
  %t263 = load ptr, ptr %l120, !tbaa !29
  %t264 = load { i64, [1 x i64] }, ptr %l129
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t263, { i64, [1 x i64] } %t264)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb66:
  %t265 = load i32, ptr %l20, !tbaa !23
  %t267 = add i32 %t265, 1
  store i32 %t267, ptr %l20, !tbaa !23
  br label %bb60
bb67:
  br label %bb75
bb68:
  %t269 = load { i64, [15 x i64] }, ptr %l1
  %t271 = extractvalue { i64, [15 x i64] } %t269, 0
  %t272 = icmp eq i64 %t271, 12
  br i1 %t272, label %bb69, label %bb70
bb69:
  %t274 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t275 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t274, i32 0, i32 0
  %t276 = load { i64, [1 x i64] }, ptr %t275
  store { i64, [1 x i64] } %t276, ptr %l22
  %t278 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t279 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t278, i32 0, i32 1
  %t280 = load { i64, [1 x i64] }, ptr %t279
  store { i64, [1 x i64] } %t280, ptr %l23
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, [1 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t282, { i64, [1 x i64] } %t283)
  br label %bb72
bb72:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load { i64, [1 x i64] }, ptr %l23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t286, { i64, [1 x i64] } %t287)
  br label %bb73
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f)
  unreachable
bb75:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Place"
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Place"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca %"compiler/mir:Place"
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l32 = alloca i32
  %l38 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l66 = alloca i32
  %l76 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l94 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca i32
  %l104 = alloca i32
  %l114 = alloca i32
  %l121 = alloca ptr
  %l124 = alloca i32
  %l128 = alloca i32
  %l134 = alloca i32
  %l138 = alloca ptr
  %l141 = alloca i32
  %l143 = alloca i32
  %l151 = alloca i32
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [15 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [15 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { { i64, [4 x i64] } }, ptr %t11, i32 0, i32 0
  %t13 = load { i64, [4 x i64] }, ptr %t12
  store { i64, [4 x i64] } %t13, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [4 x i64] }, ptr %l3
  %t19 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t15, { i64, [4 x i64] } %t16)
  store i32 %t19, ptr %l38
  br label %bb4
bb4:
  %t20 = load i32, ptr %l38, !tbaa !23
  store i32 %t20, ptr %l32, !tbaa !23
  br label %bb72
bb5:
  %t21 = load { i64, [15 x i64] }, ptr %l1
  %t23 = extractvalue { i64, [15 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t27 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t26, i32 0, i32 0
  %t28 = load %"compiler/mir:Place", ptr %t27
  store %"compiler/mir:Place" %t28, ptr %l4
  %t30 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l43, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/mir:Place", ptr %l4
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t35, %"compiler/mir:Place" %t36)
  store i32 %t39, ptr %l46
  br label %bb9
bb9:
  %t40 = load i32, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l43, !tbaa !29
  %t42 = load i32, ptr %l46, !tbaa !23
  %t44 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t41, i32 %t42, i32 %t40)
  store i32 %t44, ptr %l48
  br label %bb10
bb10:
  %t45 = load i32, ptr %l48, !tbaa !23
  store i32 %t45, ptr %l32, !tbaa !23
  br label %bb72
bb11:
  %t46 = load { i64, [15 x i64] }, ptr %l1
  %t48 = extractvalue { i64, [15 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 2
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t52 = getelementptr { %"compiler/mir:Place" }, ptr %t51, i32 0, i32 0
  %t53 = load %"compiler/mir:Place", ptr %t52
  store %"compiler/mir:Place" %t53, ptr %l6
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l52, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/mir:Place", ptr %l6
  %t60 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t56, %"compiler/mir:Place" %t57)
  store i32 %t60, ptr %l55
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l52, !tbaa !29
  %t62 = load i32, ptr %l55, !tbaa !23
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t63, ptr %l56
  br label %bb16
bb16:
  %t64 = load i32, ptr %l56, !tbaa !23
  store i32 %t64, ptr %l32, !tbaa !23
  br label %bb72
bb17:
  %t65 = load { i64, [15 x i64] }, ptr %l1
  %t67 = extractvalue { i64, [15 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 3
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l7
  %t74 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l8, !tbaa !23
  %t78 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t79 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t78, i32 0, i32 2
  %t80 = load %"compiler/mir:Range", ptr %t79
  store %"compiler/mir:Range" %t80, ptr %l9
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l7
  %t84 = load i32, ptr %l8, !tbaa !23
  %t85 = load %"compiler/mir:Range", ptr %l9
  %t90 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %t82, i32 %t83, i32 %t84, %"compiler/mir:Range" %t85)
  store i32 %t90, ptr %l66
  br label %bb21
bb21:
  %t91 = load i32, ptr %l66, !tbaa !23
  store i32 %t91, ptr %l32, !tbaa !23
  br label %bb72
bb22:
  %t92 = load { i64, [15 x i64] }, ptr %l1
  %t94 = extractvalue { i64, [15 x i64] } %t92, 0
  %t95 = icmp eq i64 %t94, 4
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t98 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l10
  %t101 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l11, !tbaa !23
  %t105 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t106 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t105, i32 0, i32 2
  %t107 = load %"compiler/mir:Range", ptr %t106
  store %"compiler/mir:Range" %t107, ptr %l12
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l10
  %t111 = load i32, ptr %l11, !tbaa !23
  %t112 = load %"compiler/mir:Range", ptr %l12
  %t117 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %t109, i32 %t110, i32 %t111, %"compiler/mir:Range" %t112)
  store i32 %t117, ptr %l76
  br label %bb26
bb26:
  %t118 = load i32, ptr %l76, !tbaa !23
  store i32 %t118, ptr %l32, !tbaa !23
  br label %bb72
bb27:
  %t119 = load { i64, [15 x i64] }, ptr %l1
  %t121 = extractvalue { i64, [15 x i64] } %t119, 0
  %t122 = icmp eq i64 %t121, 5
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t124 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t125 = getelementptr { %"compiler/mir:Place" }, ptr %t124, i32 0, i32 0
  %t126 = load %"compiler/mir:Place", ptr %t125
  store %"compiler/mir:Place" %t126, ptr %l13
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l80, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load %"compiler/mir:Place", ptr %l13
  %t133 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t129, %"compiler/mir:Place" %t130)
  store i32 %t133, ptr %l83
  br label %bb31
bb31:
  %t134 = load ptr, ptr %l80, !tbaa !29
  %t135 = load i32, ptr %l83, !tbaa !23
  %t136 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t136, ptr %l84
  br label %bb32
bb32:
  %t137 = load i32, ptr %l84, !tbaa !23
  store i32 %t137, ptr %l32, !tbaa !23
  br label %bb72
bb33:
  %t138 = load { i64, [15 x i64] }, ptr %l1
  %t140 = extractvalue { i64, [15 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 6
  br i1 %t141, label %bb34, label %bb35
bb34:
  %t143 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t144 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l14, !tbaa !23
  %t147 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t147, i32 0, i32 1
  %t149 = load i64, ptr %t148
  store i64 %t149, ptr %l15, !tbaa !24
  %t151 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t152 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t151, i32 0, i32 2
  %t153 = load %"compiler/mir:Range", ptr %t152
  store %"compiler/mir:Range" %t153, ptr %l16
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load %"compiler/mir:Range", ptr %l16
  %t163 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %t155, i32 %t156, i64 %t157, %"compiler/mir:Range" %t158)
  store i32 %t163, ptr %l94
  br label %bb37
bb37:
  %t164 = load i32, ptr %l94, !tbaa !23
  store i32 %t164, ptr %l32, !tbaa !23
  br label %bb72
bb38:
  %t165 = load { i64, [15 x i64] }, ptr %l1
  %t167 = extractvalue { i64, [15 x i64] } %t165, 0
  %t168 = icmp eq i64 %t167, 7
  br i1 %t168, label %bb39, label %bb40
bb39:
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t171 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t170, i32 0, i32 1
  %t172 = load { i64, [4 x i64] }, ptr %t171
  store { i64, [4 x i64] } %t172, ptr %l17
  %t174 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t175 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t174, i32 0, i32 2
  %t176 = load i32, ptr %t175
  store i32 %t176, ptr %l18, !tbaa !23
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l99, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, [4 x i64] }, ptr %l17
  %t183 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t179, { i64, [4 x i64] } %t180)
  store i32 %t183, ptr %l102
  br label %bb42
bb42:
  %t184 = load i32, ptr %l18, !tbaa !23
  %t185 = load ptr, ptr %l99, !tbaa !29
  %t186 = load i32, ptr %l102, !tbaa !23
  %t188 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t185, i32 %t186, i32 %t184)
  store i32 %t188, ptr %l104
  br label %bb43
bb43:
  %t189 = load i32, ptr %l104, !tbaa !23
  store i32 %t189, ptr %l32, !tbaa !23
  br label %bb72
bb44:
  %t190 = load { i64, [15 x i64] }, ptr %l1
  %t192 = extractvalue { i64, [15 x i64] } %t190, 0
  %t193 = icmp eq i64 %t192, 8
  br i1 %t193, label %bb45, label %bb46
bb45:
  %t195 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t196 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t195, i32 0, i32 1
  %t197 = load i32, ptr %t196
  store i32 %t197, ptr %l19, !tbaa !23
  %t199 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t200 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t199, i32 0, i32 2
  %t201 = load { i64, [4 x i64] }, ptr %t200
  store { i64, [4 x i64] } %t201, ptr %l20
  %t203 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t204 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t203, i32 0, i32 3
  %t205 = load { i64, [4 x i64] }, ptr %t204
  store { i64, [4 x i64] } %t205, ptr %l21
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l19, !tbaa !23
  %t209 = load { i64, [4 x i64] }, ptr %l20
  %t210 = load { i64, [4 x i64] }, ptr %l21
  %t215 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %t207, i32 %t208, { i64, [4 x i64] } %t209, { i64, [4 x i64] } %t210)
  store i32 %t215, ptr %l114
  br label %bb48
bb48:
  %t216 = load i32, ptr %l114, !tbaa !23
  store i32 %t216, ptr %l32, !tbaa !23
  br label %bb72
bb49:
  %t217 = load { i64, [15 x i64] }, ptr %l1
  %t219 = extractvalue { i64, [15 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 9
  br i1 %t220, label %bb50, label %bb51
bb50:
  %t222 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t223 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t222, i32 0, i32 0
  %t224 = load %"compiler/mir:Place", ptr %t223
  store %"compiler/mir:Place" %t224, ptr %l22
  %t226 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t227 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t226, i32 0, i32 1
  %t228 = load { i64, [4 x i64] }, ptr %t227
  store { i64, [4 x i64] } %t228, ptr %l23
  %t230 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t231 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t230, i32 0, i32 2
  %t232 = load { i64, [4 x i64] }, ptr %t231
  store { i64, [4 x i64] } %t232, ptr %l24
  %t234 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t235 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t234, i32 0, i32 3
  %t236 = load i32, ptr %t235
  store i32 %t236, ptr %l25, !tbaa !23
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l121, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load %"compiler/mir:Place", ptr %l22
  %t243 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t239, %"compiler/mir:Place" %t240)
  store i32 %t243, ptr %l124
  br label %bb53
bb53:
  %t244 = load { i64, [4 x i64] }, ptr %l23
  %t245 = load { i64, [4 x i64] }, ptr %l24
  %t246 = load i32, ptr %l25, !tbaa !23
  %t247 = load ptr, ptr %l121, !tbaa !29
  %t248 = load i32, ptr %l124, !tbaa !23
  %t252 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %t247, i32 %t248, { i64, [4 x i64] } %t244, { i64, [4 x i64] } %t245, i32 %t246)
  store i32 %t252, ptr %l128
  br label %bb54
bb54:
  %t253 = load i32, ptr %l128, !tbaa !23
  store i32 %t253, ptr %l32, !tbaa !23
  br label %bb72
bb55:
  %t254 = load { i64, [15 x i64] }, ptr %l1
  %t256 = extractvalue { i64, [15 x i64] } %t254, 0
  %t257 = icmp eq i64 %t256, 10
  br i1 %t257, label %bb56, label %bb57
bb56:
  %t259 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t260 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t259, i32 0, i32 1
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l26, !tbaa !23
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i32, ptr %l26, !tbaa !23
  %t267 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %t263, i32 %t264)
  store i32 %t267, ptr %l134
  br label %bb59
bb59:
  %t268 = load i32, ptr %l134, !tbaa !23
  store i32 %t268, ptr %l32, !tbaa !23
  br label %bb72
bb60:
  %t269 = load { i64, [15 x i64] }, ptr %l1
  %t271 = extractvalue { i64, [15 x i64] } %t269, 0
  %t272 = icmp eq i64 %t271, 11
  br i1 %t272, label %bb61, label %bb62
bb61:
  %t274 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t275 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t274, i32 0, i32 0
  %t276 = load { i64, [4 x i64] }, ptr %t275
  store { i64, [4 x i64] } %t276, ptr %l27
  br label %bb63
bb62:
  br label %bb66
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l138, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load { i64, [4 x i64] }, ptr %l27
  %t283 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t279, { i64, [4 x i64] } %t280)
  store i32 %t283, ptr %l141
  br label %bb64
bb64:
  %t284 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t285 = load ptr, ptr %l138, !tbaa !29
  %t286 = load i32, ptr %l141, !tbaa !23
  %t288 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s12, ptr %t285, i32 %t286, i32 %t284, { i64, ptr } { i64 13, ptr @.d134 })
  store i32 %t288, ptr %l143
  br label %bb65
bb65:
  %t289 = load i32, ptr %l143, !tbaa !23
  store i32 %t289, ptr %l32, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb66:
  %t290 = load { i64, [15 x i64] }, ptr %l1
  %t292 = extractvalue { i64, [15 x i64] } %t290, 0
  %t293 = icmp eq i64 %t292, 12
  br i1 %t293, label %bb67, label %bb68
bb67:
  %t295 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t296 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t295, i32 0, i32 0
  %t297 = load { i64, [1 x i64] }, ptr %t296
  store { i64, [1 x i64] } %t297, ptr %l28
  %t299 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t300 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t299, i32 0, i32 2
  %t301 = load i32, ptr %t300
  store i32 %t301, ptr %l29, !tbaa !23
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load { i64, [1 x i64] }, ptr %l28
  %t305 = load i32, ptr %l29, !tbaa !23
  %t309 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %t303, { i64, [1 x i64] } %t304, i32 %t305)
  store i32 %t309, ptr %l151
  br label %bb70
bb70:
  %t310 = load i32, ptr %l151, !tbaa !23
  store i32 %t310, ptr %l32, !tbaa !23
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_3d9554dfcf1aeb63_1386be72809b2127)
  unreachable
bb72:
  %t311 = load i32, ptr %l32, !tbaa !23
  store i32 %t311, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l2
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l41
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l41
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  store i32 %t62, ptr %l42
  br label %bb12
bb12:
  %t63 = load i32, ptr %l42, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:verifier", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i32, ptr %l10, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l48
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l52
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load i32, ptr %l48, !tbaa !23
  %t86 = load i32, ptr %l52, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t87, ptr %l53
  br label %bb15
bb15:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  store i32 %a1, ptr %l56
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s4, ptr %l56, i64 0)
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t94 = load ptr, ptr %s4
  %t95 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t94, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %sbgrew.103, label %sbdone.104
sbgrew.103:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.104
sbdone.104:
  %t105 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s3, { i64, ptr } %t111)
  store { i64, ptr } %t113, ptr %l60
  br label %bb19
bb19:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l3, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t114, i32 %t115)
  store { i64, ptr } %t118, ptr %l63
  br label %bb20
bb20:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l10, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l66
  br label %bb21
bb21:
  %t124 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } { i64 7, ptr @.d135 }, 1
  %t128 = extractvalue { i64, ptr } { i64 7, ptr @.d135 }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 6, ptr @.d136 }, 1
  %t135 = extractvalue { i64, ptr } { i64 6, ptr @.d136 }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t125, i64 %t126)
  %t142 = getelementptr i8, ptr %t141, i64 %t126
  call void @olang_textcopy(ptr %t142, ptr %t127, i64 %t128)
  %t143 = getelementptr i8, ptr %t142, i64 %t128
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = getelementptr i8, ptr %t143, i64 %t132
  call void @olang_textcopy(ptr %t144, ptr %t134, i64 %t135)
  %t145 = getelementptr i8, ptr %t144, i64 %t135
  call void @olang_textcopy(ptr %t145, ptr %t138, i64 %t139)
  %t146 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t141, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } %t147, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t155 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t155, { i64, ptr } %t154)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t157 = load i32, ptr %l8, !tbaa !23
  %t159 = add i32 %t157, 1
  store i32 %t159, ptr %l8, !tbaa !23
  br label %bb7
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t20 = load i32, ptr %l5, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i1 %t24, ptr %l17
  br label %bb3
bb3:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i32, ptr %l21
  %t34 = trunc i64 19 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i32, ptr %l27
  %t44 = trunc i64 19 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l24, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l32
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l5, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l35
  br label %bb15
bb15:
  %t58 = load i32, ptr %l32, !tbaa !23
  %t59 = load i32, ptr %l35, !tbaa !23
  %t60 = icmp eq i32 %t58, %t59
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l41
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb18:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l44
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l41, !tbaa !23
  %t75 = load i32, ptr %l44, !tbaa !23
  %t76 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i1 %t76, ptr %l45
  br label %bb20
bb20:
  %t77 = load i1, ptr %l45, !tbaa !21
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l37, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/mir:Local"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/mir:Call"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/mir:Case"
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"compiler/mir:Task"
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i32
  %l63 = alloca %"compiler/mir:TaskClause"
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca { i64, [1 x i64] }
  %l82 = alloca i32
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, [1 x i64] }
  %l90 = alloca %"compiler/mir:Range"
  %l91 = alloca %"compiler/mir:Range"
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca %"compiler/mir:BasicBlock"
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l118 = alloca i64
  %l125 = alloca i64
  %l133 = alloca i32
  %l140 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca { i64, ptr }
  %l148 = alloca i64
  %l151 = alloca i64
  %l153 = alloca ptr
  %l155 = alloca i64
  %l158 = alloca i64
  %l163 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i64
  %l188 = alloca ptr
  %l192 = alloca i32
  %l193 = alloca i1
  %l195 = alloca ptr
  %l199 = alloca i32
  %l201 = alloca %"compiler/mir:Local"
  %l205 = alloca ptr
  %l206 = alloca i64
  %l210 = alloca i32
  %l217 = alloca i1
  %l221 = alloca { i64, ptr }
  %l224 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i64
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i32
  %l257 = alloca { i64, ptr }
  %l262 = alloca i1
  %l263 = alloca i1
  %l268 = alloca %"compiler/mir:Local"
  %l283 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l311 = alloca %"compiler/mir:Local"
  %l325 = alloca i64
  %l329 = alloca i64
  %l332 = alloca i64
  %l353 = alloca %"compiler/mir:ScopeInfo"
  %l360 = alloca i1
  %l373 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l377 = alloca i32
  %l386 = alloca { i64, ptr }
  %l400 = alloca i1
  %l406 = alloca i1
  %l409 = alloca i1
  %l417 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l421 = alloca i32
  %l430 = alloca { i64, ptr }
  %l435 = alloca i1
  %l443 = alloca { i64, ptr }
  %l446 = alloca { i64, ptr }
  %l447 = alloca i32
  %l456 = alloca { i64, ptr }
  %l467 = alloca ptr
  %l468 = alloca %"compiler/mir:Range"
  %l471 = alloca i64
  %l472 = alloca i1
  %l477 = alloca i32
  %l480 = alloca i32
  %l498 = alloca ptr
  %l506 = alloca %"compiler/mir:Place"
  %l509 = alloca ptr
  %l510 = alloca %"compiler/mir:Range"
  %l513 = alloca i64
  %l514 = alloca i1
  %l519 = alloca i32
  %l522 = alloca i32
  %l547 = alloca %"compiler/mir:TaskClause"
  %l548 = alloca ptr
  %l549 = alloca %"compiler/mir:Range"
  %l552 = alloca i64
  %l553 = alloca i1
  %l565 = alloca { i64, ptr }
  %l568 = alloca { i64, ptr }
  %l569 = alloca i32
  %l578 = alloca { i64, ptr }
  %l590 = alloca { i64, ptr }
  %l593 = alloca { i64, ptr }
  %l594 = alloca i32
  %l603 = alloca { i64, ptr }
  %l615 = alloca { i64, ptr }
  %l618 = alloca { i64, ptr }
  %l619 = alloca i32
  %l628 = alloca { i64, ptr }
  %l636 = alloca i1
  %l644 = alloca i64
  %l648 = alloca i64
  %l651 = alloca i64
  %l672 = alloca { i64, [1 x i64] }
  %l676 = alloca ptr
  %l677 = alloca %"compiler/mir:Range"
  %l680 = alloca i64
  %l681 = alloca i1
  %l685 = alloca ptr
  %l686 = alloca %"compiler/mir:Range"
  %l689 = alloca i64
  %l690 = alloca i1
  %l695 = alloca i32
  %l698 = alloca i32
  %l723 = alloca i32
  %l726 = alloca i1
  %l742 = alloca i64
  %l746 = alloca i64
  %l749 = alloca i64
  %l772 = alloca %"compiler/mir:BasicBlock"
  %l774 = alloca i64
  %l778 = alloca i64
  %l781 = alloca i64
  %l801 = alloca ptr
  %l804 = alloca { i64, [21 x i64] }
  %l819 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s67 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s78 = alloca %olang.scope
  %s80 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l118
  br label %bb1
bb1:
  %t11 = load i64, ptr %l118, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 3
  store i64 -1, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t17, i32 0, i32 4
  store i64 -1, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/mir:Fn", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l125
  br label %bb2
bb2:
  %t27 = load i64, ptr %l125, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t30, { i64, ptr } { i64 9, ptr @.d137 })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/mir:verifier", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t40)
  store i32 %t43, ptr %l133
  br label %bb7
bb7:
  %t44 = load i32, ptr %l133
  %t46 = trunc i64 21 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 28, ptr @.d138 })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/mir:verifier", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l140, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:verifier", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/mir:Fn", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t61, i32 %t65)
  store i32 %t68, ptr %l145
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l140, !tbaa !29
  %t70 = load i32, ptr %l145, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l146
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l148, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/mir:Fn", ptr %t76, i32 0, i32 4
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l151
  br label %bb14
bb14:
  %t81 = load i64, ptr %l148, !tbaa !24
  %t82 = load i64, ptr %l151, !tbaa !24
  %t83 = icmp ne i64 %t81, %t82
  br i1 %t83, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l153, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l155, !tbaa !24
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/mir:Fn", ptr %t89, i32 0, i32 4
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l158
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t94 = extractvalue { i64, ptr } { i64 13, ptr @.d139 }, 1
  %t95 = extractvalue { i64, ptr } { i64 13, ptr @.d139 }, 0
  %t96 = load i64, ptr %l155, !tbaa !24
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t95, %t97
  %t99 = extractvalue { i64, ptr } { i64 24, ptr @.d140 }, 1
  %t100 = extractvalue { i64, ptr } { i64 24, ptr @.d140 }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load i64, ptr %l158, !tbaa !24
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t102)
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t94, i64 %t95)
  %t106 = getelementptr i8, ptr %t105, i64 %t95
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t96)
  %t108 = getelementptr i8, ptr %t106, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t102)
  %t111 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t105, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } %t112, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t120, { i64, ptr } %t119)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 4
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l163
  br label %bb20
bb20:
  %t127 = load i64, ptr %l163, !tbaa !24
  store i64 %t127, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load i64, ptr %l6, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb21, label %bb22
bb21:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb26
bb23:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l170, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb25
bb25:
  %t154 = load i64, ptr %l170, !tbaa !24
  store i64 %t154, ptr %l167, !tbaa !24
  br label %bb26
bb26:
  %t155 = load i64, ptr %l167, !tbaa !24
  store i64 %t155, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb29:
  br label %bb30
bb30:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t165 = load i64, ptr %l10, !tbaa !24
  %t166 = load i64, ptr %l8, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l11, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l188, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/mir:Fn", ptr %t175, i32 0, i32 4
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l192
  br label %bb31
bb31:
  %t182 = load ptr, ptr %l188, !tbaa !29
  %t183 = load i32, ptr %l192, !tbaa !23
  %t184 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t184, ptr %l193
  br label %bb32
bb32:
  %t185 = load i1, ptr %l193, !tbaa !21
  br i1 %t185, label %bb33, label %bb34
bb33:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/mir:Fn", ptr %t186, i32 0, i32 7
  store ptr %t188, ptr %l195, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/mir:Fn", ptr %t189, i32 0, i32 4
  %t192 = load i64, ptr %l11, !tbaa !24
  %t195 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t191, i64 %t192)
  store i32 %t195, ptr %l199
  br label %bb35
bb34:
  br label %bb52
bb35:
  %t196 = load i32, ptr %l199, !tbaa !23
  %t197 = sext i32 %t196 to i64
  %t198 = load ptr, ptr %l195, !tbaa !29
  %t200 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t198, i64 %t197)
  store %"compiler/mir:Local" %t200, ptr %l201
  br label %bb36
bb36:
  %t201 = load %"compiler/mir:Local", ptr %l201
  store %"compiler/mir:Local" %t201, ptr %l12
  %t202 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t203 = load i32, ptr %t202
  %t205 = trunc i64 0 to i32
  %t206 = icmp eq i32 %t203, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l205, !tbaa !29
  %t211 = load i64, ptr %l11, !tbaa !24
  store i64 %t211, ptr %l206, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/mir:Fn", ptr %t212, i32 0, i32 4
  %t215 = load i64, ptr %l11, !tbaa !24
  %t218 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l210
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t219 = extractvalue { i64, ptr } { i64 10, ptr @.d141 }, 1
  %t220 = extractvalue { i64, ptr } { i64 10, ptr @.d141 }, 0
  %t221 = load i64, ptr %l206, !tbaa !24
  %t222 = call i64 @__olang_fmt_i64(ptr null, i64 %t221)
  %t223 = add i64 %t220, %t222
  %t224 = extractvalue { i64, ptr } { i64 11, ptr @.d142 }, 1
  %t225 = extractvalue { i64, ptr } { i64 11, ptr @.d142 }, 0
  %t226 = add i64 %t223, %t225
  %t227 = load i32, ptr %l210, !tbaa !23
  %t228 = sext i32 %t227 to i64
  %t229 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 13, ptr @.d143 }, 1
  %t232 = extractvalue { i64, ptr } { i64 13, ptr @.d143 }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t219, i64 %t220)
  %t235 = getelementptr i8, ptr %t234, i64 %t220
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t221)
  %t237 = getelementptr i8, ptr %t235, i64 %t222
  call void @olang_textcopy(ptr %t237, ptr %t224, i64 %t225)
  %t238 = getelementptr i8, ptr %t237, i64 %t225
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t228)
  %t240 = getelementptr i8, ptr %t238, i64 %t229
  call void @olang_textcopy(ptr %t240, ptr %t231, i64 %t232)
  %t241 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t234, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t250 = load ptr, ptr %l205, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t250, { i64, ptr } %t249)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t258 = icmp slt i64 %t252, %t255
  br i1 %t258, label %bb42, label %bb43
bb42:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/mir:verifier", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t265 = load i32, ptr %t264, !tbaa !23
  %t266 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t266, ptr %l221, !tbaa !27
  %t267 = load i64, ptr %l11, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i32, ptr %t270, i64 %t267
  %t272 = load i32, ptr %t271, !tbaa !33
  %t276 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t263, i32 %t265, i32 %t272)
  store i1 %t276, ptr %l224
  br label %bb44
bb43:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb45
bb44:
  %t277 = load i1, ptr %l224, !tbaa !21
  %t278 = xor i1 %t277, true
  store i1 %t278, ptr %l217, !tbaa !21
  br label %bb45
bb45:
  %t280 = load i1, ptr %l217, !tbaa !21
  br i1 %t280, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l226, !tbaa !29
  %t282 = load i64, ptr %l11, !tbaa !24
  store i64 %t282, ptr %l227, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/mir:verifier", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t287 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t288 = load i32, ptr %t287, !tbaa !23
  %t291 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s10, ptr %t286, i32 %t288)
  store { i64, ptr } %t291, ptr %l231
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/mir:verifier", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t296, ptr %l234, !tbaa !27
  %t297 = load i64, ptr %l11, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i32, ptr %t300, i64 %t297
  %t302 = load i32, ptr %t301, !tbaa !33
  %t305 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s10, ptr %t295, i32 %t302)
  store { i64, ptr } %t305, ptr %l237
  br label %bb49
bb49:
  %t306 = extractvalue { i64, ptr } { i64 10, ptr @.d144 }, 1
  %t307 = extractvalue { i64, ptr } { i64 10, ptr @.d144 }, 0
  %t308 = load i64, ptr %l227, !tbaa !24
  %t309 = call i64 @__olang_fmt_i64(ptr null, i64 %t308)
  %t310 = add i64 %t307, %t309
  %t311 = extractvalue { i64, ptr } { i64 6, ptr @.d145 }, 1
  %t312 = extractvalue { i64, ptr } { i64 6, ptr @.d145 }, 0
  %t313 = add i64 %t310, %t312
  %t314 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 16, ptr @.d146 }, 1
  %t319 = extractvalue { i64, ptr } { i64 16, ptr @.d146 }, 0
  %t320 = add i64 %t317, %t319
  %t321 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t306, i64 %t307)
  %t326 = getelementptr i8, ptr %t325, i64 %t307
  %t327 = call i64 @__olang_fmt_i64(ptr %t326, i64 %t308)
  %t328 = getelementptr i8, ptr %t326, i64 %t309
  call void @olang_textcopy(ptr %t328, ptr %t311, i64 %t312)
  %t329 = getelementptr i8, ptr %t328, i64 %t312
  call void @olang_textcopy(ptr %t329, ptr %t315, i64 %t316)
  %t330 = getelementptr i8, ptr %t329, i64 %t316
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t325, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = extractvalue { i64, ptr } %t333, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t341 = load ptr, ptr %l226, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t341, { i64, ptr } %t340)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb53:
  %t343 = load i64, ptr %l10, !tbaa !24
  %t345 = add i64 %t343, 1
  store i64 %t345, ptr %l10, !tbaa !24
  br label %bb27
bb54:
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr %"compiler/mir:Fn", ptr %t347, i32 0, i32 5
  store ptr %t349, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  %t351 = load ptr, ptr %l13, !tbaa !29
  %t352 = load i64, ptr %l14, !tbaa !24
  %t355 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eRunFrom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t351, i64 %t352)
  %t356 = extractvalue { i32, { i64, ptr } } %t355, 1
  %t357 = extractvalue { i32, { i64, ptr } } %t355, 0
  store i32 %t357, ptr %l248
  %t358 = icmp ne i32 %t357, 0
  br i1 %t358, label %bb57, label %ok.359
ok.359:
  store { i64, ptr } %t356, ptr %l247
  br label %bb56
bb56:
  %t360 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t360, ptr %l244, !tbaa !27
  br label %bb61
bb57:
  %t361 = load i32, ptr %l248, !tbaa !23
  %t362 = ashr i32 %t361, 16
  %t364 = icmp eq i32 %t362, 1
  br i1 %t364, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_729af306d1a375bd_3b9d78bce782a851)
  unreachable
bb60:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb61:
  %t366 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t366, ptr %l15, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t367, 0
  store i64 %t369, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s15
  %t371 = load i64, ptr %l17, !tbaa !24
  %t372 = load i64, ptr %l16, !tbaa !24
  %t375 = icmp slt i64 %t371, %t372
  %t377 = xor i1 %t375, true
  br i1 %t377, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t379 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t379, ptr %l257, !tbaa !27
  %t380 = load i64, ptr %l17, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr i32, ptr %t383, i64 %t380
  %t385 = load i32, ptr %t384, !tbaa !33
  store i32 %t385, ptr %l18, !tbaa !23
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l18, !tbaa !23
  %t391 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t387, i32 %t388)
  store i1 %t391, ptr %l262
  br label %bb66
bb66:
  %t392 = load i1, ptr %l262, !tbaa !21
  br i1 %t392, label %bb67, label %bb68
bb67:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr %"compiler/mir:Fn", ptr %t393, i32 0, i32 7
  %t396 = load i32, ptr %l18, !tbaa !23
  %t398 = sext i32 %t396 to i64
  %t401 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t395, i64 %t398)
  store %"compiler/mir:Local" %t401, ptr %l268
  br label %bb69
bb68:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb70
bb69:
  %t402 = getelementptr %"compiler/mir:Local", ptr %l268, i32 0, i32 3
  %t403 = load i32, ptr %t402
  %t405 = trunc i64 1 to i32
  %t406 = icmp eq i32 %t403, %t405
  %t408 = xor i1 %t406, true
  store i1 %t408, ptr %l263, !tbaa !21
  br label %bb70
bb70:
  %t410 = load i1, ptr %l263, !tbaa !21
  br i1 %t410, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s16
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i32, ptr %l18, !tbaa !23
  %t413 = extractvalue { i64, ptr } { i64 9, ptr @.d147 }, 1
  %t414 = extractvalue { i64, ptr } { i64 9, ptr @.d147 }, 0
  %t416 = sext i32 %t412 to i64
  %t417 = call i64 @__olang_fmt_i64(ptr null, i64 %t416)
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 20, ptr @.d148 }, 1
  %t420 = extractvalue { i64, ptr } { i64 20, ptr @.d148 }, 0
  %t421 = add i64 %t418, %t420
  %t422 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t421)
  call void @olang_textcopy(ptr %t422, ptr %t413, i64 %t414)
  %t423 = getelementptr i8, ptr %t422, i64 %t414
  %t424 = call i64 @__olang_fmt_i64(ptr %t423, i64 %t416)
  %t425 = getelementptr i8, ptr %t423, i64 %t417
  call void @olang_textcopy(ptr %t425, ptr %t419, i64 %t420)
  %t426 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t422, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = extractvalue { i64, ptr } %t427, 1
  %t431 = mul i64 %t429, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t432, ptr %t430, i64 %t431, i1 false)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s16, ptr %t411, { i64, ptr } %t434)
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s16)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s15)
  br label %bb75
bb75:
  %t437 = load i64, ptr %l17, !tbaa !24
  %t439 = add i64 %t437, 1
  store i64 %t439, ptr %l17, !tbaa !24
  br label %bb62
bb76:
  %t441 = load i64, ptr %l14, !tbaa !24
  %t442 = load i64, ptr %l16, !tbaa !24
  %t445 = add i64 %t441, %t442
  store i64 %t445, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb77:
  br label %bb55
bb78:
  store i64 0, ptr %l19, !tbaa !24
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr %"compiler/mir:Fn", ptr %t447, i32 0, i32 7
  %t451 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t449)
  store i64 %t451, ptr %l283
  br label %bb79
bb79:
  %t452 = load i64, ptr %l283, !tbaa !24
  store i64 %t452, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t453 = load i64, ptr %l20, !tbaa !24
  %t454 = load i64, ptr %l19, !tbaa !24
  %t457 = icmp sgt i64 %t453, %t454
  br i1 %t457, label %bb80, label %bb81
bb80:
  %t459 = load i64, ptr %l21, !tbaa !24
  %t461 = icmp sgt i64 %t459, 0
  br i1 %t461, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb85
bb82:
  %t463 = load i64, ptr %l20, !tbaa !24
  %t464 = load i64, ptr %l19, !tbaa !24
  %t467 = sub i64 %t463, %t464
  %t468 = load i64, ptr %l21, !tbaa !24
  %t471 = add i64 %t467, %t468
  %t473 = sub i64 %t471, 1
  %t474 = load i64, ptr %l21, !tbaa !24
  %t477 = sdiv i64 %t473, %t474
  store i64 %t477, ptr %l290, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb84
bb84:
  %t479 = load i64, ptr %l290, !tbaa !24
  store i64 %t479, ptr %l287, !tbaa !24
  br label %bb85
bb85:
  %t480 = load i64, ptr %l287, !tbaa !24
  store i64 %t480, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s20
  %t481 = load i64, ptr %l23, !tbaa !24
  %t482 = load i64, ptr %l22, !tbaa !24
  %t485 = icmp slt i64 %t481, %t482
  %t487 = xor i1 %t485, true
  br i1 %t487, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s20)
  br label %bb97
bb88:
  br label %bb89
bb89:
  %t489 = load i64, ptr %l19, !tbaa !24
  %t490 = load i64, ptr %l23, !tbaa !24
  %t491 = load i64, ptr %l21, !tbaa !24
  %t494 = mul i64 %t490, %t491
  %t497 = add i64 %t489, %t494
  store i64 %t497, ptr %l24, !tbaa !24
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr %"compiler/mir:Fn", ptr %t499, i32 0, i32 7
  %t502 = load i64, ptr %l24, !tbaa !24
  %t505 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t501, i64 %t502)
  store %"compiler/mir:Local" %t505, ptr %l311
  br label %bb90
bb90:
  %t506 = load %"compiler/mir:Local", ptr %l311
  store %"compiler/mir:Local" %t506, ptr %l25
  %t507 = getelementptr %"compiler/mir:Local", ptr %l25, i32 0, i32 2
  %t508 = load i32, ptr %t507, !tbaa !23
  %t509 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t512 = icmp eq i32 %t508, %t509
  br i1 %t512, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s21
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l24, !tbaa !24
  %t516 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 1
  %t517 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 0
  %t519 = call i64 @__olang_fmt_i64(ptr null, i64 %t515)
  %t520 = add i64 %t517, %t519
  %t521 = extractvalue { i64, ptr } { i64 21, ptr @.d150 }, 1
  %t522 = extractvalue { i64, ptr } { i64 21, ptr @.d150 }, 0
  %t523 = add i64 %t520, %t522
  %t524 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t523)
  call void @olang_textcopy(ptr %t524, ptr %t516, i64 %t517)
  %t525 = getelementptr i8, ptr %t524, i64 %t517
  %t526 = call i64 @__olang_fmt_i64(ptr %t525, i64 %t515)
  %t527 = getelementptr i8, ptr %t525, i64 %t519
  call void @olang_textcopy(ptr %t527, ptr %t521, i64 %t522)
  %t528 = insertvalue { i64, ptr } undef, i64 %t523, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t524, 1
  %t531 = extractvalue { i64, ptr } %t529, 0
  %t532 = extractvalue { i64, ptr } %t529, 1
  %t533 = mul i64 %t531, 1
  %t534 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t533)
  call void @llvm.memcpy.p0.p0.i64(ptr %t534, ptr %t532, i64 %t533, i1 false)
  %t535 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t534, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t514, { i64, ptr } %t536)
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s21)
  br label %bb94
bb94:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/mir:Local", ptr %l25, i32 0, i32 4
  %t541 = load { i64, [1 x i64] }, ptr %t540
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t539, { i64, [1 x i64] } %t541)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s20)
  br label %bb96
bb96:
  %t544 = load i64, ptr %l23, !tbaa !24
  %t546 = add i64 %t544, 1
  store i64 %t546, ptr %l23, !tbaa !24
  br label %bb86
bb97:
  store i64 0, ptr %l26, !tbaa !24
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr %"compiler/mir:Fn", ptr %t548, i32 0, i32 8
  %t552 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t550)
  store i64 %t552, ptr %l325
  br label %bb98
bb98:
  %t553 = load i64, ptr %l325, !tbaa !24
  store i64 %t553, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t554 = load i64, ptr %l27, !tbaa !24
  %t555 = load i64, ptr %l26, !tbaa !24
  %t558 = icmp sgt i64 %t554, %t555
  br i1 %t558, label %bb99, label %bb100
bb99:
  %t560 = load i64, ptr %l28, !tbaa !24
  %t562 = icmp sgt i64 %t560, 0
  br i1 %t562, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l329, !tbaa !24
  br label %bb104
bb101:
  %t564 = load i64, ptr %l27, !tbaa !24
  %t565 = load i64, ptr %l26, !tbaa !24
  %t568 = sub i64 %t564, %t565
  %t569 = load i64, ptr %l28, !tbaa !24
  %t572 = add i64 %t568, %t569
  %t574 = sub i64 %t572, 1
  %t575 = load i64, ptr %l28, !tbaa !24
  %t578 = sdiv i64 %t574, %t575
  store i64 %t578, ptr %l332, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l332, !tbaa !24
  br label %bb103
bb103:
  %t580 = load i64, ptr %l332, !tbaa !24
  store i64 %t580, ptr %l329, !tbaa !24
  br label %bb104
bb104:
  %t581 = load i64, ptr %l329, !tbaa !24
  store i64 %t581, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s25
  %t582 = load i64, ptr %l30, !tbaa !24
  %t583 = load i64, ptr %l29, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s25)
  br label %bb118
bb107:
  br label %bb108
bb108:
  %t590 = load i64, ptr %l26, !tbaa !24
  %t591 = load i64, ptr %l30, !tbaa !24
  %t592 = load i64, ptr %l28, !tbaa !24
  %t595 = mul i64 %t591, %t592
  %t598 = add i64 %t590, %t595
  store i64 %t598, ptr %l31, !tbaa !24
  %t600 = load ptr, ptr %l1, !tbaa !29
  %t602 = getelementptr %"compiler/mir:Fn", ptr %t600, i32 0, i32 8
  %t603 = load i64, ptr %l31, !tbaa !24
  %t606 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t602, i64 %t603)
  store %"compiler/mir:ScopeInfo" %t606, ptr %l353
  br label %bb109
bb109:
  %t607 = getelementptr %"compiler/mir:ScopeInfo", ptr %l353, i32 0, i32 1
  %t608 = load i32, ptr %t607, !tbaa !23
  store i32 %t608, ptr %l32, !tbaa !23
  %t610 = load i32, ptr %l32, !tbaa !23
  %t611 = load i64, ptr %l31, !tbaa !24
  %t613 = trunc i64 %t611 to i32
  %t617 = icmp sge i32 %t610, %t613
  br i1 %t617, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l360, !tbaa !21
  br label %bb112
bb111:
  %t619 = load i32, ptr %l32, !tbaa !23
  %t620 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t623 = icmp slt i32 %t619, %t620
  store i1 %t623, ptr %l360, !tbaa !21
  br label %bb112
bb112:
  %t625 = load i1, ptr %l360, !tbaa !21
  br i1 %t625, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s26
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i64, ptr %l31, !tbaa !24
  %t628 = load i32, ptr %l32, !tbaa !23
  %t629 = extractvalue { i64, ptr } { i64 1, ptr @.d151 }, 1
  %t630 = extractvalue { i64, ptr } { i64 1, ptr @.d151 }, 0
  %t632 = call i64 @__olang_fmt_i64(ptr null, i64 %t627)
  %t633 = add i64 %t630, %t632
  %t634 = extractvalue { i64, ptr } { i64 11, ptr @.d152 }, 1
  %t635 = extractvalue { i64, ptr } { i64 11, ptr @.d152 }, 0
  %t636 = add i64 %t633, %t635
  %t638 = sext i32 %t628 to i64
  %t639 = call i64 @__olang_fmt_i64(ptr null, i64 %t638)
  %t640 = add i64 %t636, %t639
  %t641 = extractvalue { i64, ptr } { i64 24, ptr @.d153 }, 1
  %t642 = extractvalue { i64, ptr } { i64 24, ptr @.d153 }, 0
  %t643 = add i64 %t640, %t642
  %t644 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t643)
  call void @olang_textcopy(ptr %t644, ptr %t629, i64 %t630)
  %t645 = getelementptr i8, ptr %t644, i64 %t630
  %t646 = call i64 @__olang_fmt_i64(ptr %t645, i64 %t627)
  %t647 = getelementptr i8, ptr %t645, i64 %t632
  call void @olang_textcopy(ptr %t647, ptr %t634, i64 %t635)
  %t648 = getelementptr i8, ptr %t647, i64 %t635
  %t649 = call i64 @__olang_fmt_i64(ptr %t648, i64 %t638)
  %t650 = getelementptr i8, ptr %t648, i64 %t639
  call void @olang_textcopy(ptr %t650, ptr %t641, i64 %t642)
  %t651 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t644, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = extractvalue { i64, ptr } %t652, 1
  %t656 = mul i64 %t654, 1
  %t657 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t656)
  call void @llvm.memcpy.p0.p0.i64(ptr %t657, ptr %t655, i64 %t656, i1 false)
  %t658 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t626, { i64, ptr } %t659)
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s26)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s25)
  br label %bb117
bb117:
  %t662 = load i64, ptr %l30, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l30, !tbaa !24
  br label %bb105
bb118:
  %t666 = load ptr, ptr %l1, !tbaa !29
  %t668 = getelementptr %"compiler/mir:Fn", ptr %t666, i32 0, i32 14
  store ptr %t668, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s30
  %t670 = load ptr, ptr %l33, !tbaa !29
  %t671 = load i64, ptr %l34, !tbaa !24
  %t674 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t670, i64 %t671)
  %t675 = extractvalue { i32, { i64, ptr } } %t674, 1
  %t676 = extractvalue { i32, { i64, ptr } } %t674, 0
  store i32 %t676, ptr %l377
  %t677 = icmp ne i32 %t676, 0
  br i1 %t677, label %bb121, label %ok.678
ok.678:
  store { i64, ptr } %t675, ptr %l376
  br label %bb120
bb120:
  %t679 = load { i64, ptr }, ptr %l376, !tbaa !27
  store { i64, ptr } %t679, ptr %l373, !tbaa !27
  br label %bb125
bb121:
  %t680 = load i32, ptr %l377, !tbaa !23
  %t681 = ashr i32 %t680, 16
  %t683 = icmp eq i32 %t681, 1
  br i1 %t683, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0)
  unreachable
bb124:
  call void @__olang_scope_close(ptr %s30)
  br label %bb146
bb125:
  %t685 = load { i64, ptr }, ptr %l373, !tbaa !27
  store { i64, ptr } %t685, ptr %l35, !tbaa !27
  %t686 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t688 = extractvalue { i64, ptr } %t686, 0
  store i64 %t688, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s31
  %t690 = load i64, ptr %l37, !tbaa !24
  %t691 = load i64, ptr %l36, !tbaa !24
  %t694 = icmp slt i64 %t690, %t691
  %t696 = xor i1 %t694, true
  br i1 %t696, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb128:
  br label %bb129
bb129:
  %t698 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t698, ptr %l386, !tbaa !27
  %t699 = load i64, ptr %l37, !tbaa !24
  %t701 = getelementptr { i64, ptr }, ptr %l386, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = getelementptr %"compiler/mir:Call", ptr %t702, i64 %t699
  %t704 = load %"compiler/mir:Call", ptr %t703
  store %"compiler/mir:Call" %t704, ptr %l38
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t707 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 0
  %t708 = load { i64, [5 x i64] }, ptr %t707
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t706, { i64, [5 x i64] } %t708)
  br label %bb130
bb130:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 1
  %t713 = load %"compiler/mir:Range", ptr %t712
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t711, %"compiler/mir:Range" %t713)
  br label %bb131
bb131:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 2
  %t718 = load %"compiler/mir:Range", ptr %t717
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t716, %"compiler/mir:Range" %t718)
  br label %bb132
bb132:
  %t721 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 4
  %t722 = load i1, ptr %t721, !tbaa !21
  br i1 %t722, label %bb133, label %bb134
bb133:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 3
  %t726 = load %"compiler/mir:Place", ptr %t725
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t724, %"compiler/mir:Place" %t726)
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 5
  %t731 = load i32, ptr %t730, !tbaa !23
  %t734 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t729, i32 %t731)
  store i1 %t734, ptr %l400
  br label %bb137
bb137:
  %t735 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 7
  %t736 = load i32, ptr %t735, !tbaa !23
  %t737 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t740 = icmp ne i32 %t736, %t737
  br i1 %t740, label %bb138, label %bb139
bb138:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 7
  %t744 = load i32, ptr %t743, !tbaa !23
  %t747 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t742, i32 %t744)
  store i1 %t747, ptr %l406
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 6
  %t750 = load i32, ptr %t749, !tbaa !23
  %t753 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t748, i32 %t750)
  store i1 %t753, ptr %l409
  br label %bb141
bb141:
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb143:
  %t754 = load i64, ptr %l37, !tbaa !24
  %t756 = add i64 %t754, 1
  store i64 %t756, ptr %l37, !tbaa !24
  br label %bb126
bb144:
  %t758 = load i64, ptr %l34, !tbaa !24
  %t759 = load i64, ptr %l36, !tbaa !24
  %t762 = add i64 %t758, %t759
  store i64 %t762, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb145
bb145:
  br label %bb119
bb146:
  %t764 = load ptr, ptr %l1, !tbaa !29
  %t766 = getelementptr %"compiler/mir:Fn", ptr %t764, i32 0, i32 15
  store ptr %t766, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb147
bb147:
  store %olang.scope zeroinitializer, ptr %s36
  %t768 = load ptr, ptr %l39, !tbaa !29
  %t769 = load i64, ptr %l40, !tbaa !24
  %t772 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eRunFrom_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t768, i64 %t769)
  %t773 = extractvalue { i32, { i64, ptr } } %t772, 1
  %t774 = extractvalue { i32, { i64, ptr } } %t772, 0
  store i32 %t774, ptr %l421
  %t775 = icmp ne i32 %t774, 0
  br i1 %t775, label %bb149, label %ok.776
ok.776:
  store { i64, ptr } %t773, ptr %l420
  br label %bb148
bb148:
  %t777 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t777, ptr %l417, !tbaa !27
  br label %bb153
bb149:
  %t778 = load i32, ptr %l421, !tbaa !23
  %t779 = ashr i32 %t778, 16
  %t781 = icmp eq i32 %t779, 1
  br i1 %t781, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_ebd53c5cd6069b87_f80775eded979a3b)
  unreachable
bb152:
  call void @__olang_scope_close(ptr %s36)
  br label %bb162
bb153:
  %t783 = load { i64, ptr }, ptr %l417, !tbaa !27
  store { i64, ptr } %t783, ptr %l41, !tbaa !27
  %t784 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t784, 0
  store i64 %t786, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb154
bb154:
  store %olang.scope zeroinitializer, ptr %s37
  %t788 = load i64, ptr %l43, !tbaa !24
  %t789 = load i64, ptr %l42, !tbaa !24
  %t792 = icmp slt i64 %t788, %t789
  %t794 = xor i1 %t792, true
  br i1 %t794, label %bb155, label %bb156
bb155:
  call void @__olang_scope_close(ptr %s37)
  br label %bb160
bb156:
  br label %bb157
bb157:
  %t796 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t796, ptr %l430, !tbaa !27
  %t797 = load i64, ptr %l43, !tbaa !24
  %t799 = getelementptr { i64, ptr }, ptr %l430, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !27
  %t801 = getelementptr %"compiler/mir:Case", ptr %t800, i64 %t797
  %t802 = load %"compiler/mir:Case", ptr %t801
  store %"compiler/mir:Case" %t802, ptr %l44
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/mir:Case", ptr %l44, i32 0, i32 1
  %t806 = load i32, ptr %t805, !tbaa !23
  %t809 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t804, i32 %t806)
  store i1 %t809, ptr %l435
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s37)
  br label %bb159
bb159:
  %t810 = load i64, ptr %l43, !tbaa !24
  %t812 = add i64 %t810, 1
  store i64 %t812, ptr %l43, !tbaa !24
  br label %bb154
bb160:
  %t814 = load i64, ptr %l40, !tbaa !24
  %t815 = load i64, ptr %l42, !tbaa !24
  %t818 = add i64 %t814, %t815
  store i64 %t818, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s36)
  br label %bb161
bb161:
  br label %bb147
bb162:
  %t820 = load ptr, ptr %l1, !tbaa !29
  %t822 = getelementptr %"compiler/mir:Fn", ptr %t820, i32 0, i32 16
  store ptr %t822, ptr %l45, !tbaa !29
  store i64 0, ptr %l46, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s40
  %t824 = load ptr, ptr %l45, !tbaa !29
  %t825 = load i64, ptr %l46, !tbaa !24
  %t828 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t824, i64 %t825)
  %t829 = extractvalue { i32, { i64, ptr } } %t828, 1
  %t830 = extractvalue { i32, { i64, ptr } } %t828, 0
  store i32 %t830, ptr %l447
  %t831 = icmp ne i32 %t830, 0
  br i1 %t831, label %bb165, label %ok.832
ok.832:
  store { i64, ptr } %t829, ptr %l446
  br label %bb164
bb164:
  %t833 = load { i64, ptr }, ptr %l446, !tbaa !27
  store { i64, ptr } %t833, ptr %l443, !tbaa !27
  br label %bb169
bb165:
  %t834 = load i32, ptr %l447, !tbaa !23
  %t835 = ashr i32 %t834, 16
  %t837 = icmp eq i32 %t835, 1
  br i1 %t837, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_ba49393f26523c26_b8992ee5d3be0dba)
  unreachable
bb168:
  call void @__olang_scope_close(ptr %s40)
  br label %bb221
bb169:
  %t839 = load { i64, ptr }, ptr %l443, !tbaa !27
  store { i64, ptr } %t839, ptr %l47, !tbaa !27
  %t840 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t842 = extractvalue { i64, ptr } %t840, 0
  store i64 %t842, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb170
bb170:
  store %olang.scope zeroinitializer, ptr %s41
  %t844 = load i64, ptr %l49, !tbaa !24
  %t845 = load i64, ptr %l48, !tbaa !24
  %t848 = icmp slt i64 %t844, %t845
  %t850 = xor i1 %t848, true
  br i1 %t850, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s41)
  br label %bb219
bb172:
  br label %bb173
bb173:
  %t852 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t852, ptr %l456, !tbaa !27
  %t853 = load i64, ptr %l49, !tbaa !24
  %t855 = getelementptr { i64, ptr }, ptr %l456, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !27
  %t857 = getelementptr %"compiler/mir:Task", ptr %t856, i64 %t853
  %t858 = load %"compiler/mir:Task", ptr %t857
  store %"compiler/mir:Task" %t858, ptr %l50
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 0
  %t862 = load { i64, [5 x i64] }, ptr %t861
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t860, { i64, [5 x i64] } %t862)
  br label %bb174
bb174:
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 1
  %t867 = load %"compiler/mir:Range", ptr %t866
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t865, %"compiler/mir:Range" %t867)
  br label %bb175
bb175:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 5
  %t872 = load %"compiler/mir:Range", ptr %t871
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t870, %"compiler/mir:Range" %t872)
  br label %bb176
bb176:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t876 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 2
  %t877 = load %"compiler/mir:Range", ptr %t876
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t875, %"compiler/mir:Range" %t877)
  br label %bb177
bb177:
  %t880 = load ptr, ptr %l0, !tbaa !29
  store ptr %t880, ptr %l467, !tbaa !29
  %t881 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 3
  %t882 = load %"compiler/mir:Range", ptr %t881
  store %"compiler/mir:Range" %t882, ptr %l468
  %t883 = load ptr, ptr %l1, !tbaa !29
  %t885 = getelementptr %"compiler/mir:Fn", ptr %t883, i32 0, i32 13
  %t887 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t885)
  store i64 %t887, ptr %l471
  br label %bb178
bb178:
  %t888 = load ptr, ptr %l467, !tbaa !29
  %t889 = load %"compiler/mir:Range", ptr %l468
  %t890 = load i64, ptr %l471, !tbaa !24
  %t891 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s41, ptr %t888, %"compiler/mir:Range" %t889, i64 %t890, { i64, ptr } { i64 7, ptr @.d154 })
  store i1 %t891, ptr %l472
  br label %bb179
bb179:
  %t892 = load i1, ptr %l472, !tbaa !21
  br i1 %t892, label %bb180, label %bb181
bb180:
  store i32 0, ptr %l51, !tbaa !23
  %t893 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 3
  %t894 = getelementptr %"compiler/mir:Range", ptr %t893, i32 0, i32 1
  %t895 = load i32, ptr %t894, !tbaa !23
  store i32 %t895, ptr %l52, !tbaa !23
  store i32 1, ptr %l53, !tbaa !23
  %t897 = load i32, ptr %l52, !tbaa !23
  %t898 = load i32, ptr %l51, !tbaa !23
  %t901 = icmp sgt i32 %t897, %t898
  br i1 %t901, label %bb182, label %bb183
bb181:
  br label %bb196
bb182:
  %t903 = load i32, ptr %l53, !tbaa !23
  %t905 = icmp sgt i32 %t903, 0
  br i1 %t905, label %bb184, label %bb185
bb183:
  store i32 0, ptr %l477, !tbaa !23
  br label %bb187
bb184:
  %t907 = load i32, ptr %l52, !tbaa !23
  %t908 = load i32, ptr %l51, !tbaa !23
  %t911 = sub i32 %t907, %t908
  %t912 = load i32, ptr %l53, !tbaa !23
  %t915 = add i32 %t911, %t912
  %t917 = sub i32 %t915, 1
  %t918 = load i32, ptr %l53, !tbaa !23
  %t921 = sdiv i32 %t917, %t918
  store i32 %t921, ptr %l480, !tbaa !23
  br label %bb186
bb185:
  store i32 0, ptr %l480, !tbaa !23
  br label %bb186
bb186:
  %t923 = load i32, ptr %l480, !tbaa !23
  store i32 %t923, ptr %l477, !tbaa !23
  br label %bb187
bb187:
  %t924 = load i32, ptr %l477, !tbaa !23
  store i32 %t924, ptr %l54, !tbaa !23
  store i32 0, ptr %l55, !tbaa !23
  br label %bb188
bb188:
  store %olang.scope zeroinitializer, ptr %s44
  %t925 = load i32, ptr %l55, !tbaa !23
  %t926 = load i32, ptr %l54, !tbaa !23
  %t929 = icmp slt i32 %t925, %t926
  %t931 = xor i1 %t929, true
  br i1 %t931, label %bb189, label %bb190
bb189:
  call void @__olang_scope_close(ptr %s44)
  br label %bb195
bb190:
  br label %bb191
bb191:
  %t933 = load i32, ptr %l51, !tbaa !23
  %t934 = load i32, ptr %l55, !tbaa !23
  %t935 = load i32, ptr %l53, !tbaa !23
  %t938 = mul i32 %t934, %t935
  %t941 = add i32 %t933, %t938
  %t943 = load ptr, ptr %l0, !tbaa !29
  store ptr %t943, ptr %l498, !tbaa !29
  %t944 = load ptr, ptr %l1, !tbaa !29
  %t946 = getelementptr %"compiler/mir:Fn", ptr %t944, i32 0, i32 13
  %t947 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 3
  %t948 = getelementptr %"compiler/mir:Range", ptr %t947, i32 0, i32 0
  %t949 = load i32, ptr %t948, !tbaa !23
  %t951 = sext i32 %t949 to i64
  %t954 = sext i32 %t941 to i64
  %t957 = add i64 %t951, %t954
  %t960 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t946, i64 %t957)
  store %"compiler/mir:Place" %t960, ptr %l506
  br label %bb192
bb192:
  %t961 = load ptr, ptr %l498, !tbaa !29
  %t962 = load %"compiler/mir:Place", ptr %l506
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t961, %"compiler/mir:Place" %t962)
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s44)
  br label %bb194
bb194:
  %t963 = load i32, ptr %l55, !tbaa !23
  %t965 = add i32 %t963, 1
  store i32 %t965, ptr %l55, !tbaa !23
  br label %bb188
bb195:
  br label %bb196
bb196:
  %t967 = load ptr, ptr %l0, !tbaa !29
  store ptr %t967, ptr %l509, !tbaa !29
  %t968 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 4
  %t969 = load %"compiler/mir:Range", ptr %t968
  store %"compiler/mir:Range" %t969, ptr %l510
  %t970 = load ptr, ptr %l1, !tbaa !29
  %t972 = getelementptr %"compiler/mir:Fn", ptr %t970, i32 0, i32 17
  %t974 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eLe_Ha29d98bd5fca0556754225de6d8edaab(ptr %v0, ptr %t972)
  store i64 %t974, ptr %l513
  br label %bb197
bb197:
  %t975 = load ptr, ptr %l509, !tbaa !29
  %t976 = load %"compiler/mir:Range", ptr %l510
  %t977 = load i64, ptr %l513, !tbaa !24
  %t978 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s41, ptr %t975, %"compiler/mir:Range" %t976, i64 %t977, { i64, ptr } { i64 7, ptr @.d155 })
  store i1 %t978, ptr %l514
  br label %bb198
bb198:
  %t979 = load i1, ptr %l514, !tbaa !21
  br i1 %t979, label %bb199, label %bb200
bb199:
  store i32 0, ptr %l57, !tbaa !23
  %t980 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 4
  %t981 = getelementptr %"compiler/mir:Range", ptr %t980, i32 0, i32 1
  %t982 = load i32, ptr %t981, !tbaa !23
  store i32 %t982, ptr %l58, !tbaa !23
  store i32 1, ptr %l59, !tbaa !23
  %t984 = load i32, ptr %l58, !tbaa !23
  %t985 = load i32, ptr %l57, !tbaa !23
  %t988 = icmp sgt i32 %t984, %t985
  br i1 %t988, label %bb201, label %bb202
bb200:
  br label %bb217
bb201:
  %t990 = load i32, ptr %l59, !tbaa !23
  %t992 = icmp sgt i32 %t990, 0
  br i1 %t992, label %bb203, label %bb204
bb202:
  store i32 0, ptr %l519, !tbaa !23
  br label %bb206
bb203:
  %t994 = load i32, ptr %l58, !tbaa !23
  %t995 = load i32, ptr %l57, !tbaa !23
  %t998 = sub i32 %t994, %t995
  %t999 = load i32, ptr %l59, !tbaa !23
  %t1002 = add i32 %t998, %t999
  %t1004 = sub i32 %t1002, 1
  %t1005 = load i32, ptr %l59, !tbaa !23
  %t1008 = sdiv i32 %t1004, %t1005
  store i32 %t1008, ptr %l522, !tbaa !23
  br label %bb205
bb204:
  store i32 0, ptr %l522, !tbaa !23
  br label %bb205
bb205:
  %t1010 = load i32, ptr %l522, !tbaa !23
  store i32 %t1010, ptr %l519, !tbaa !23
  br label %bb206
bb206:
  %t1011 = load i32, ptr %l519, !tbaa !23
  store i32 %t1011, ptr %l60, !tbaa !23
  store i32 0, ptr %l61, !tbaa !23
  br label %bb207
bb207:
  store %olang.scope zeroinitializer, ptr %s48
  %t1012 = load i32, ptr %l61, !tbaa !23
  %t1013 = load i32, ptr %l60, !tbaa !23
  %t1016 = icmp slt i32 %t1012, %t1013
  %t1018 = xor i1 %t1016, true
  br i1 %t1018, label %bb208, label %bb209
bb208:
  call void @__olang_scope_close(ptr %s48)
  br label %bb216
bb209:
  br label %bb210
bb210:
  %t1020 = load i32, ptr %l57, !tbaa !23
  %t1021 = load i32, ptr %l61, !tbaa !23
  %t1022 = load i32, ptr %l59, !tbaa !23
  %t1025 = mul i32 %t1021, %t1022
  %t1028 = add i32 %t1020, %t1025
  %t1030 = load ptr, ptr %l1, !tbaa !29
  %t1032 = getelementptr %"compiler/mir:Fn", ptr %t1030, i32 0, i32 17
  %t1033 = getelementptr %"compiler/mir:Task", ptr %l50, i32 0, i32 4
  %t1034 = getelementptr %"compiler/mir:Range", ptr %t1033, i32 0, i32 0
  %t1035 = load i32, ptr %t1034, !tbaa !23
  %t1037 = sext i32 %t1035 to i64
  %t1040 = sext i32 %t1028 to i64
  %t1043 = add i64 %t1037, %t1040
  %t1046 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t1032, i64 %t1043)
  store %"compiler/mir:TaskClause" %t1046, ptr %l547
  br label %bb211
bb211:
  %t1047 = load %"compiler/mir:TaskClause", ptr %l547
  store %"compiler/mir:TaskClause" %t1047, ptr %l63
  %t1048 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1048, ptr %l548, !tbaa !29
  %t1049 = getelementptr %"compiler/mir:TaskClause", ptr %l63, i32 0, i32 0
  %t1050 = load %"compiler/mir:Range", ptr %t1049
  store %"compiler/mir:Range" %t1050, ptr %l549
  %t1051 = load ptr, ptr %l1, !tbaa !29
  %t1053 = getelementptr %"compiler/mir:Fn", ptr %t1051, i32 0, i32 18
  %t1055 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t1053)
  store i64 %t1055, ptr %l552
  br label %bb212
bb212:
  %t1056 = load ptr, ptr %l548, !tbaa !29
  %t1057 = load %"compiler/mir:Range", ptr %l549
  %t1058 = load i64, ptr %l552, !tbaa !24
  %t1059 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s48, ptr %t1056, %"compiler/mir:Range" %t1057, i64 %t1058, { i64, ptr } { i64 5, ptr @.d156 })
  store i1 %t1059, ptr %l553
  br label %bb213
bb213:
  %t1060 = load ptr, ptr %l0, !tbaa !29
  %t1061 = getelementptr %"compiler/mir:TaskClause", ptr %l63, i32 0, i32 2
  %t1062 = load { i64, [4 x i64] }, ptr %t1061
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1060, { i64, [4 x i64] } %t1062)
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s48)
  br label %bb215
bb215:
  %t1065 = load i32, ptr %l61, !tbaa !23
  %t1067 = add i32 %t1065, 1
  store i32 %t1067, ptr %l61, !tbaa !23
  br label %bb207
bb216:
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s41)
  br label %bb218
bb218:
  %t1069 = load i64, ptr %l49, !tbaa !24
  %t1071 = add i64 %t1069, 1
  store i64 %t1071, ptr %l49, !tbaa !24
  br label %bb170
bb219:
  %t1073 = load i64, ptr %l46, !tbaa !24
  %t1074 = load i64, ptr %l48, !tbaa !24
  %t1077 = add i64 %t1073, %t1074
  store i64 %t1077, ptr %l46, !tbaa !24
  call void @__olang_scope_close(ptr %s40)
  br label %bb220
bb220:
  br label %bb163
bb221:
  %t1079 = load ptr, ptr %l1, !tbaa !29
  %t1081 = getelementptr %"compiler/mir:Fn", ptr %t1079, i32 0, i32 11
  store ptr %t1081, ptr %l64, !tbaa !29
  store i64 0, ptr %l65, !tbaa !24
  br label %bb222
bb222:
  store %olang.scope zeroinitializer, ptr %s52
  %t1083 = load ptr, ptr %l64, !tbaa !29
  %t1084 = load i64, ptr %l65, !tbaa !24
  %t1087 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eRunFrom_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1083, i64 %t1084)
  %t1088 = extractvalue { i32, { i64, ptr } } %t1087, 1
  %t1089 = extractvalue { i32, { i64, ptr } } %t1087, 0
  store i32 %t1089, ptr %l569
  %t1090 = icmp ne i32 %t1089, 0
  br i1 %t1090, label %bb224, label %ok.1091
ok.1091:
  store { i64, ptr } %t1088, ptr %l568
  br label %bb223
bb223:
  %t1092 = load { i64, ptr }, ptr %l568, !tbaa !27
  store { i64, ptr } %t1092, ptr %l565, !tbaa !27
  br label %bb228
bb224:
  %t1093 = load i32, ptr %l569, !tbaa !23
  %t1094 = ashr i32 %t1093, 16
  %t1096 = icmp eq i32 %t1094, 1
  br i1 %t1096, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_ecf51586bea1aa81_8258c2cc4874ccd)
  unreachable
bb227:
  call void @__olang_scope_close(ptr %s52)
  br label %bb237
bb228:
  %t1098 = load { i64, ptr }, ptr %l565, !tbaa !27
  store { i64, ptr } %t1098, ptr %l66, !tbaa !27
  %t1099 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1101 = extractvalue { i64, ptr } %t1099, 0
  store i64 %t1101, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb229
bb229:
  store %olang.scope zeroinitializer, ptr %s53
  %t1103 = load i64, ptr %l68, !tbaa !24
  %t1104 = load i64, ptr %l67, !tbaa !24
  %t1107 = icmp slt i64 %t1103, %t1104
  %t1109 = xor i1 %t1107, true
  br i1 %t1109, label %bb230, label %bb231
bb230:
  call void @__olang_scope_close(ptr %s53)
  br label %bb235
bb231:
  br label %bb232
bb232:
  %t1111 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1111, ptr %l578, !tbaa !27
  %t1112 = load i64, ptr %l68, !tbaa !24
  %t1114 = getelementptr { i64, ptr }, ptr %l578, i32 0, i32 1
  %t1115 = load ptr, ptr %t1114, !tbaa !27
  %t1116 = getelementptr { i64, [4 x i64] }, ptr %t1115, i64 %t1112
  %t1117 = load { i64, [4 x i64] }, ptr %t1116
  %t1119 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1119, { i64, [4 x i64] } %t1117)
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s53)
  br label %bb234
bb234:
  %t1123 = load i64, ptr %l68, !tbaa !24
  %t1125 = add i64 %t1123, 1
  store i64 %t1125, ptr %l68, !tbaa !24
  br label %bb229
bb235:
  %t1127 = load i64, ptr %l65, !tbaa !24
  %t1128 = load i64, ptr %l67, !tbaa !24
  %t1131 = add i64 %t1127, %t1128
  store i64 %t1131, ptr %l65, !tbaa !24
  call void @__olang_scope_close(ptr %s52)
  br label %bb236
bb236:
  br label %bb222
bb237:
  %t1133 = load ptr, ptr %l1, !tbaa !29
  %t1135 = getelementptr %"compiler/mir:Fn", ptr %t1133, i32 0, i32 12
  store ptr %t1135, ptr %l70, !tbaa !29
  store i64 0, ptr %l71, !tbaa !24
  br label %bb238
bb238:
  store %olang.scope zeroinitializer, ptr %s56
  %t1137 = load ptr, ptr %l70, !tbaa !29
  %t1138 = load i64, ptr %l71, !tbaa !24
  %t1141 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %t1137, i64 %t1138)
  %t1142 = extractvalue { i32, { i64, ptr } } %t1141, 1
  %t1143 = extractvalue { i32, { i64, ptr } } %t1141, 0
  store i32 %t1143, ptr %l594
  %t1144 = icmp ne i32 %t1143, 0
  br i1 %t1144, label %bb240, label %ok.1145
ok.1145:
  store { i64, ptr } %t1142, ptr %l593
  br label %bb239
bb239:
  %t1146 = load { i64, ptr }, ptr %l593, !tbaa !27
  store { i64, ptr } %t1146, ptr %l590, !tbaa !27
  br label %bb244
bb240:
  %t1147 = load i32, ptr %l594, !tbaa !23
  %t1148 = ashr i32 %t1147, 16
  %t1150 = icmp eq i32 %t1148, 1
  br i1 %t1150, label %bb241, label %bb242
bb241:
  br label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_eee257eb13f606f0_579348194f70649c)
  unreachable
bb243:
  call void @__olang_scope_close(ptr %s56)
  br label %bb253
bb244:
  %t1152 = load { i64, ptr }, ptr %l590, !tbaa !27
  store { i64, ptr } %t1152, ptr %l72, !tbaa !27
  %t1153 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t1155 = extractvalue { i64, ptr } %t1153, 0
  store i64 %t1155, ptr %l73, !tbaa !24
  store i64 0, ptr %l74, !tbaa !24
  br label %bb245
bb245:
  store %olang.scope zeroinitializer, ptr %s57
  %t1157 = load i64, ptr %l74, !tbaa !24
  %t1158 = load i64, ptr %l73, !tbaa !24
  %t1161 = icmp slt i64 %t1157, %t1158
  %t1163 = xor i1 %t1161, true
  br i1 %t1163, label %bb246, label %bb247
bb246:
  call void @__olang_scope_close(ptr %s57)
  br label %bb251
bb247:
  br label %bb248
bb248:
  %t1165 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t1165, ptr %l603, !tbaa !27
  %t1166 = load i64, ptr %l74, !tbaa !24
  %t1168 = getelementptr { i64, ptr }, ptr %l603, i32 0, i32 1
  %t1169 = load ptr, ptr %t1168, !tbaa !27
  %t1170 = getelementptr { i64, [1 x i64] }, ptr %t1169, i64 %t1166
  %t1171 = load { i64, [1 x i64] }, ptr %t1170
  %t1173 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t1173, { i64, [1 x i64] } %t1171)
  br label %bb249
bb249:
  call void @__olang_scope_close(ptr %s57)
  br label %bb250
bb250:
  %t1177 = load i64, ptr %l74, !tbaa !24
  %t1179 = add i64 %t1177, 1
  store i64 %t1179, ptr %l74, !tbaa !24
  br label %bb245
bb251:
  %t1181 = load i64, ptr %l71, !tbaa !24
  %t1182 = load i64, ptr %l73, !tbaa !24
  %t1185 = add i64 %t1181, %t1182
  store i64 %t1185, ptr %l71, !tbaa !24
  call void @__olang_scope_close(ptr %s56)
  br label %bb252
bb252:
  br label %bb238
bb253:
  %t1187 = load ptr, ptr %l1, !tbaa !29
  %t1189 = getelementptr %"compiler/mir:Fn", ptr %t1187, i32 0, i32 10
  store ptr %t1189, ptr %l76, !tbaa !29
  store i64 0, ptr %l77, !tbaa !24
  br label %bb254
bb254:
  store %olang.scope zeroinitializer, ptr %s60
  %t1191 = load ptr, ptr %l76, !tbaa !29
  %t1192 = load i64, ptr %l77, !tbaa !24
  %t1195 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t1191, i64 %t1192)
  %t1196 = extractvalue { i32, { i64, ptr } } %t1195, 1
  %t1197 = extractvalue { i32, { i64, ptr } } %t1195, 0
  store i32 %t1197, ptr %l619
  %t1198 = icmp ne i32 %t1197, 0
  br i1 %t1198, label %bb256, label %ok.1199
ok.1199:
  store { i64, ptr } %t1196, ptr %l618
  br label %bb255
bb255:
  %t1200 = load { i64, ptr }, ptr %l618, !tbaa !27
  store { i64, ptr } %t1200, ptr %l615, !tbaa !27
  br label %bb260
bb256:
  %t1201 = load i32, ptr %l619, !tbaa !23
  %t1202 = ashr i32 %t1201, 16
  %t1204 = icmp eq i32 %t1202, 1
  br i1 %t1204, label %bb257, label %bb258
bb257:
  br label %bb259
bb258:
  call void @__olang_check_failed(ptr @olang_loc_4fb7743b938ffb2b_98c233616dbed9d7)
  unreachable
bb259:
  call void @__olang_scope_close(ptr %s60)
  br label %bb278
bb260:
  %t1206 = load { i64, ptr }, ptr %l615, !tbaa !27
  store { i64, ptr } %t1206, ptr %l78, !tbaa !27
  %t1207 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1209 = extractvalue { i64, ptr } %t1207, 0
  store i64 %t1209, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb261
bb261:
  store %olang.scope zeroinitializer, ptr %s61
  %t1211 = load i64, ptr %l80, !tbaa !24
  %t1212 = load i64, ptr %l79, !tbaa !24
  %t1215 = icmp slt i64 %t1211, %t1212
  %t1217 = xor i1 %t1215, true
  br i1 %t1217, label %bb262, label %bb263
bb262:
  call void @__olang_scope_close(ptr %s61)
  br label %bb276
bb263:
  br label %bb264
bb264:
  %t1219 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t1219, ptr %l628, !tbaa !27
  %t1220 = load i64, ptr %l80, !tbaa !24
  %t1222 = getelementptr { i64, ptr }, ptr %l628, i32 0, i32 1
  %t1223 = load ptr, ptr %t1222, !tbaa !27
  %t1224 = getelementptr { i64, [1 x i64] }, ptr %t1223, i64 %t1220
  %t1225 = load { i64, [1 x i64] }, ptr %t1224
  store { i64, [1 x i64] } %t1225, ptr %l81
  %t1227 = load { i64, [1 x i64] }, ptr %l81
  %t1229 = extractvalue { i64, [1 x i64] } %t1227, 0
  %t1230 = icmp eq i64 %t1229, 1
  br i1 %t1230, label %bb265, label %bb266
bb265:
  %t1232 = getelementptr { i64, [1 x i64] }, ptr %l81, i32 0, i32 1
  %t1233 = getelementptr { i32 }, ptr %t1232, i32 0, i32 0
  %t1234 = load i32, ptr %t1233
  store i32 %t1234, ptr %l82, !tbaa !23
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t1236 = load ptr, ptr %l0, !tbaa !29
  %t1237 = load i32, ptr %l82, !tbaa !23
  %t1240 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t1236, i32 %t1237)
  store i1 %t1240, ptr %l636
  br label %bb268
bb268:
  br label %bb274
bb269:
  br i1 true, label %bb270, label %bb271
bb270:
  br label %bb272
bb271:
  br label %bb273
bb272:
  br label %bb274
bb273:
  call void @__olang_check_failed(ptr @olang_loc_a7113f54b8427e6a_b5cb829958e44636)
  unreachable
bb274:
  call void @__olang_scope_close(ptr %s61)
  br label %bb275
bb275:
  %t1241 = load i64, ptr %l80, !tbaa !24
  %t1243 = add i64 %t1241, 1
  store i64 %t1243, ptr %l80, !tbaa !24
  br label %bb261
bb276:
  %t1245 = load i64, ptr %l77, !tbaa !24
  %t1246 = load i64, ptr %l79, !tbaa !24
  %t1249 = add i64 %t1245, %t1246
  store i64 %t1249, ptr %l77, !tbaa !24
  call void @__olang_scope_close(ptr %s60)
  br label %bb277
bb277:
  br label %bb254
bb278:
  store i64 0, ptr %l83, !tbaa !24
  %t1251 = load ptr, ptr %l1, !tbaa !29
  %t1253 = getelementptr %"compiler/mir:Fn", ptr %t1251, i32 0, i32 19
  %t1255 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t1253)
  store i64 %t1255, ptr %l644
  br label %bb279
bb279:
  %t1256 = load i64, ptr %l644, !tbaa !24
  store i64 %t1256, ptr %l84, !tbaa !24
  store i64 1, ptr %l85, !tbaa !24
  %t1257 = load i64, ptr %l84, !tbaa !24
  %t1258 = load i64, ptr %l83, !tbaa !24
  %t1261 = icmp sgt i64 %t1257, %t1258
  br i1 %t1261, label %bb280, label %bb281
bb280:
  %t1263 = load i64, ptr %l85, !tbaa !24
  %t1265 = icmp sgt i64 %t1263, 0
  br i1 %t1265, label %bb282, label %bb283
bb281:
  store i64 0, ptr %l648, !tbaa !24
  br label %bb285
bb282:
  %t1267 = load i64, ptr %l84, !tbaa !24
  %t1268 = load i64, ptr %l83, !tbaa !24
  %t1271 = sub i64 %t1267, %t1268
  %t1272 = load i64, ptr %l85, !tbaa !24
  %t1275 = add i64 %t1271, %t1272
  %t1277 = sub i64 %t1275, 1
  %t1278 = load i64, ptr %l85, !tbaa !24
  %t1281 = sdiv i64 %t1277, %t1278
  store i64 %t1281, ptr %l651, !tbaa !24
  br label %bb284
bb283:
  store i64 0, ptr %l651, !tbaa !24
  br label %bb284
bb284:
  %t1283 = load i64, ptr %l651, !tbaa !24
  store i64 %t1283, ptr %l648, !tbaa !24
  br label %bb285
bb285:
  %t1284 = load i64, ptr %l648, !tbaa !24
  store i64 %t1284, ptr %l86, !tbaa !24
  store i64 0, ptr %l87, !tbaa !24
  br label %bb286
bb286:
  store %olang.scope zeroinitializer, ptr %s66
  %t1285 = load i64, ptr %l87, !tbaa !24
  %t1286 = load i64, ptr %l86, !tbaa !24
  %t1289 = icmp slt i64 %t1285, %t1286
  %t1291 = xor i1 %t1289, true
  br i1 %t1291, label %bb287, label %bb288
bb287:
  call void @__olang_scope_close(ptr %s66)
  br label %bb332
bb288:
  br label %bb289
bb289:
  %t1293 = load i64, ptr %l83, !tbaa !24
  %t1294 = load i64, ptr %l87, !tbaa !24
  %t1295 = load i64, ptr %l85, !tbaa !24
  %t1298 = mul i64 %t1294, %t1295
  %t1301 = add i64 %t1293, %t1298
  store i64 %t1301, ptr %l88, !tbaa !24
  %t1303 = load ptr, ptr %l1, !tbaa !29
  %t1305 = getelementptr %"compiler/mir:Fn", ptr %t1303, i32 0, i32 19
  %t1306 = load i64, ptr %l88, !tbaa !24
  %t1309 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t1305, i64 %t1306)
  store { i64, [1 x i64] } %t1309, ptr %l672
  br label %bb290
bb290:
  %t1310 = load { i64, [1 x i64] }, ptr %l672
  store { i64, [1 x i64] } %t1310, ptr %l89
  %t1311 = load { i64, [1 x i64] }, ptr %l89
  %t1313 = extractvalue { i64, [1 x i64] } %t1311, 0
  %t1314 = icmp eq i64 %t1313, 1
  br i1 %t1314, label %bb291, label %bb292
bb291:
  %t1316 = getelementptr { i64, [1 x i64] }, ptr %l89, i32 0, i32 1
  %t1317 = getelementptr { %"compiler/mir:Range" }, ptr %t1316, i32 0, i32 0
  %t1318 = load %"compiler/mir:Range", ptr %t1317
  store %"compiler/mir:Range" %t1318, ptr %l90
  br label %bb293
bb292:
  br label %bb296
bb293:
  store %olang.scope zeroinitializer, ptr %s67
  %t1320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1320, ptr %l676, !tbaa !29
  %t1321 = load %"compiler/mir:Range", ptr %l90
  store %"compiler/mir:Range" %t1321, ptr %l677
  %t1322 = load ptr, ptr %l1, !tbaa !29
  %t1324 = getelementptr %"compiler/mir:Fn", ptr %t1322, i32 0, i32 21
  %t1326 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t1324)
  store i64 %t1326, ptr %l680
  br label %bb294
bb294:
  %t1327 = load ptr, ptr %l676, !tbaa !29
  %t1328 = load %"compiler/mir:Range", ptr %l677
  %t1329 = load i64, ptr %l680, !tbaa !24
  %t1330 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s67, ptr %t1327, %"compiler/mir:Range" %t1328, i64 %t1329, { i64, ptr } { i64 5, ptr @.d157 })
  store i1 %t1330, ptr %l681
  br label %bb295
bb295:
  call void @__olang_scope_close(ptr %s67)
  br label %bb330
bb296:
  %t1331 = load { i64, [1 x i64] }, ptr %l89
  %t1333 = extractvalue { i64, [1 x i64] } %t1331, 0
  %t1334 = icmp eq i64 %t1333, 2
  br i1 %t1334, label %bb297, label %bb298
bb297:
  %t1336 = getelementptr { i64, [1 x i64] }, ptr %l89, i32 0, i32 1
  %t1337 = getelementptr { %"compiler/mir:Range" }, ptr %t1336, i32 0, i32 0
  %t1338 = load %"compiler/mir:Range", ptr %t1337
  store %"compiler/mir:Range" %t1338, ptr %l91
  br label %bb299
bb298:
  br label %bb325
bb299:
  store %olang.scope zeroinitializer, ptr %s68
  %t1340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1340, ptr %l685, !tbaa !29
  %t1341 = load %"compiler/mir:Range", ptr %l91
  store %"compiler/mir:Range" %t1341, ptr %l686
  %t1342 = load ptr, ptr %l1, !tbaa !29
  %t1344 = getelementptr %"compiler/mir:Fn", ptr %t1342, i32 0, i32 20
  %t1346 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t1344)
  store i64 %t1346, ptr %l689
  br label %bb300
bb300:
  %t1347 = load ptr, ptr %l685, !tbaa !29
  %t1348 = load %"compiler/mir:Range", ptr %l686
  %t1349 = load i64, ptr %l689, !tbaa !24
  %t1350 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s68, ptr %t1347, %"compiler/mir:Range" %t1348, i64 %t1349, { i64, ptr } { i64 14, ptr @.d158 })
  store i1 %t1350, ptr %l690
  br label %bb301
bb301:
  %t1351 = load i1, ptr %l690, !tbaa !21
  br i1 %t1351, label %bb302, label %bb303
bb302:
  store i32 0, ptr %l92, !tbaa !23
  %t1352 = getelementptr %"compiler/mir:Range", ptr %l91, i32 0, i32 1
  %t1353 = load i32, ptr %t1352, !tbaa !23
  store i32 %t1353, ptr %l93, !tbaa !23
  store i32 1, ptr %l94, !tbaa !23
  %t1355 = load i32, ptr %l93, !tbaa !23
  %t1356 = load i32, ptr %l92, !tbaa !23
  %t1359 = icmp sgt i32 %t1355, %t1356
  br i1 %t1359, label %bb304, label %bb305
bb303:
  br label %bb324
bb304:
  %t1361 = load i32, ptr %l94, !tbaa !23
  %t1363 = icmp sgt i32 %t1361, 0
  br i1 %t1363, label %bb306, label %bb307
bb305:
  store i32 0, ptr %l695, !tbaa !23
  br label %bb309
bb306:
  %t1365 = load i32, ptr %l93, !tbaa !23
  %t1366 = load i32, ptr %l92, !tbaa !23
  %t1369 = sub i32 %t1365, %t1366
  %t1370 = load i32, ptr %l94, !tbaa !23
  %t1373 = add i32 %t1369, %t1370
  %t1375 = sub i32 %t1373, 1
  %t1376 = load i32, ptr %l94, !tbaa !23
  %t1379 = sdiv i32 %t1375, %t1376
  store i32 %t1379, ptr %l698, !tbaa !23
  br label %bb308
bb307:
  store i32 0, ptr %l698, !tbaa !23
  br label %bb308
bb308:
  %t1381 = load i32, ptr %l698, !tbaa !23
  store i32 %t1381, ptr %l695, !tbaa !23
  br label %bb309
bb309:
  %t1382 = load i32, ptr %l695, !tbaa !23
  store i32 %t1382, ptr %l95, !tbaa !23
  store i32 0, ptr %l96, !tbaa !23
  br label %bb310
bb310:
  store %olang.scope zeroinitializer, ptr %s71
  %t1383 = load i32, ptr %l96, !tbaa !23
  %t1384 = load i32, ptr %l95, !tbaa !23
  %t1387 = icmp slt i32 %t1383, %t1384
  %t1389 = xor i1 %t1387, true
  br i1 %t1389, label %bb311, label %bb312
bb311:
  call void @__olang_scope_close(ptr %s71)
  br label %bb323
bb312:
  br label %bb313
bb313:
  %t1391 = load i32, ptr %l92, !tbaa !23
  %t1392 = load i32, ptr %l96, !tbaa !23
  %t1393 = load i32, ptr %l94, !tbaa !23
  %t1396 = mul i32 %t1392, %t1393
  %t1399 = add i32 %t1391, %t1396
  %t1401 = load ptr, ptr %l1, !tbaa !29
  %t1403 = getelementptr %"compiler/mir:Fn", ptr %t1401, i32 0, i32 20
  %t1404 = getelementptr %"compiler/mir:Range", ptr %l91, i32 0, i32 0
  %t1405 = load i32, ptr %t1404, !tbaa !23
  %t1407 = sext i32 %t1405 to i64
  %t1410 = sext i32 %t1399 to i64
  %t1413 = add i64 %t1407, %t1410
  %t1416 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t1403, i64 %t1413)
  store i32 %t1416, ptr %l723
  br label %bb314
bb314:
  %t1417 = load i32, ptr %l723, !tbaa !23
  store i32 %t1417, ptr %l98, !tbaa !23
  %t1418 = load i32, ptr %l98, !tbaa !23
  %t1420 = icmp slt i32 %t1418, 0
  br i1 %t1420, label %bb315, label %bb316
bb315:
  store i1 true, ptr %l726, !tbaa !21
  br label %bb317
bb316:
  %t1422 = load i32, ptr %l98, !tbaa !23
  %t1423 = load i64, ptr %l88, !tbaa !24
  %t1425 = trunc i64 %t1423 to i32
  %t1428 = icmp sge i32 %t1422, %t1425
  store i1 %t1428, ptr %l726, !tbaa !21
  br label %bb317
bb317:
  %t1430 = load i1, ptr %l726, !tbaa !21
  br i1 %t1430, label %bb318, label %bb319
bb318:
  store %olang.scope zeroinitializer, ptr %s72
  %t1431 = load ptr, ptr %l0, !tbaa !29
  %t1432 = load i64, ptr %l88, !tbaa !24
  %t1433 = load i32, ptr %l98, !tbaa !23
  %t1434 = extractvalue { i64, ptr } { i64 9, ptr @.d159 }, 1
  %t1435 = extractvalue { i64, ptr } { i64 9, ptr @.d159 }, 0
  %t1437 = call i64 @__olang_fmt_i64(ptr null, i64 %t1432)
  %t1438 = add i64 %t1435, %t1437
  %t1439 = extractvalue { i64, ptr } { i64 16, ptr @.d160 }, 1
  %t1440 = extractvalue { i64, ptr } { i64 16, ptr @.d160 }, 0
  %t1441 = add i64 %t1438, %t1440
  %t1443 = sext i32 %t1433 to i64
  %t1444 = call i64 @__olang_fmt_i64(ptr null, i64 %t1443)
  %t1445 = add i64 %t1441, %t1444
  %t1446 = extractvalue { i64, ptr } { i64 20, ptr @.d161 }, 1
  %t1447 = extractvalue { i64, ptr } { i64 20, ptr @.d161 }, 0
  %t1448 = add i64 %t1445, %t1447
  %t1449 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1448)
  call void @olang_textcopy(ptr %t1449, ptr %t1434, i64 %t1435)
  %t1450 = getelementptr i8, ptr %t1449, i64 %t1435
  %t1451 = call i64 @__olang_fmt_i64(ptr %t1450, i64 %t1432)
  %t1452 = getelementptr i8, ptr %t1450, i64 %t1437
  call void @olang_textcopy(ptr %t1452, ptr %t1439, i64 %t1440)
  %t1453 = getelementptr i8, ptr %t1452, i64 %t1440
  %t1454 = call i64 @__olang_fmt_i64(ptr %t1453, i64 %t1443)
  %t1455 = getelementptr i8, ptr %t1453, i64 %t1444
  call void @olang_textcopy(ptr %t1455, ptr %t1446, i64 %t1447)
  %t1456 = insertvalue { i64, ptr } undef, i64 %t1448, 0
  %t1457 = insertvalue { i64, ptr } %t1456, ptr %t1449, 1
  %t1459 = extractvalue { i64, ptr } %t1457, 0
  %t1460 = extractvalue { i64, ptr } %t1457, 1
  %t1461 = mul i64 %t1459, 1
  %t1462 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1462, ptr %t1460, i64 %t1461, i1 false)
  %t1463 = insertvalue { i64, ptr } undef, i64 %t1459, 0
  %t1464 = insertvalue { i64, ptr } %t1463, ptr %t1462, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s72, ptr %t1431, { i64, ptr } %t1464)
  br label %bb320
bb319:
  br label %bb321
bb320:
  call void @__olang_scope_close(ptr %s72)
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s71)
  br label %bb322
bb322:
  %t1467 = load i32, ptr %l96, !tbaa !23
  %t1469 = add i32 %t1467, 1
  store i32 %t1469, ptr %l96, !tbaa !23
  br label %bb310
bb323:
  br label %bb324
bb324:
  call void @__olang_scope_close(ptr %s68)
  br label %bb330
bb325:
  br i1 true, label %bb326, label %bb327
bb326:
  br label %bb328
bb327:
  br label %bb329
bb328:
  br label %bb330
bb329:
  call void @__olang_check_failed(ptr @olang_loc_e78f424551ad49a5_ff41c7fa0d07ed9)
  unreachable
bb330:
  call void @__olang_scope_close(ptr %s66)
  br label %bb331
bb331:
  %t1471 = load i64, ptr %l87, !tbaa !24
  %t1473 = add i64 %t1471, 1
  store i64 %t1473, ptr %l87, !tbaa !24
  br label %bb286
bb332:
  store i64 0, ptr %l99, !tbaa !24
  %t1475 = load ptr, ptr %l1, !tbaa !29
  %t1477 = getelementptr %"compiler/mir:Fn", ptr %t1475, i32 0, i32 9
  %t1479 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t1477)
  store i64 %t1479, ptr %l742
  br label %bb333
bb333:
  %t1480 = load i64, ptr %l742, !tbaa !24
  store i64 %t1480, ptr %l100, !tbaa !24
  store i64 1, ptr %l101, !tbaa !24
  %t1481 = load i64, ptr %l100, !tbaa !24
  %t1482 = load i64, ptr %l99, !tbaa !24
  %t1485 = icmp sgt i64 %t1481, %t1482
  br i1 %t1485, label %bb334, label %bb335
bb334:
  %t1487 = load i64, ptr %l101, !tbaa !24
  %t1489 = icmp sgt i64 %t1487, 0
  br i1 %t1489, label %bb336, label %bb337
bb335:
  store i64 0, ptr %l746, !tbaa !24
  br label %bb339
bb336:
  %t1491 = load i64, ptr %l100, !tbaa !24
  %t1492 = load i64, ptr %l99, !tbaa !24
  %t1495 = sub i64 %t1491, %t1492
  %t1496 = load i64, ptr %l101, !tbaa !24
  %t1499 = add i64 %t1495, %t1496
  %t1501 = sub i64 %t1499, 1
  %t1502 = load i64, ptr %l101, !tbaa !24
  %t1505 = sdiv i64 %t1501, %t1502
  store i64 %t1505, ptr %l749, !tbaa !24
  br label %bb338
bb337:
  store i64 0, ptr %l749, !tbaa !24
  br label %bb338
bb338:
  %t1507 = load i64, ptr %l749, !tbaa !24
  store i64 %t1507, ptr %l746, !tbaa !24
  br label %bb339
bb339:
  %t1508 = load i64, ptr %l746, !tbaa !24
  store i64 %t1508, ptr %l102, !tbaa !24
  store i64 0, ptr %l103, !tbaa !24
  br label %bb340
bb340:
  store %olang.scope zeroinitializer, ptr %s78
  %t1509 = load i64, ptr %l103, !tbaa !24
  %t1510 = load i64, ptr %l102, !tbaa !24
  %t1513 = icmp slt i64 %t1509, %t1510
  %t1515 = xor i1 %t1513, true
  br i1 %t1515, label %bb341, label %bb342
bb341:
  call void @__olang_scope_close(ptr %s78)
  br label %bb362
bb342:
  br label %bb343
bb343:
  %t1517 = load i64, ptr %l99, !tbaa !24
  %t1518 = load i64, ptr %l103, !tbaa !24
  %t1519 = load i64, ptr %l101, !tbaa !24
  %t1522 = mul i64 %t1518, %t1519
  %t1525 = add i64 %t1517, %t1522
  store i64 %t1525, ptr %l104, !tbaa !24
  %t1527 = load ptr, ptr %l0, !tbaa !29
  %t1528 = load i64, ptr %l104, !tbaa !24
  %t1531 = getelementptr %"compiler/mir:verifier", ptr %t1527, i32 0, i32 3
  store i64 %t1528, ptr %t1531, !tbaa !24
  %t1532 = load ptr, ptr %l1, !tbaa !29
  %t1534 = getelementptr %"compiler/mir:Fn", ptr %t1532, i32 0, i32 9
  %t1535 = load i64, ptr %l104, !tbaa !24
  %t1538 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t1534, i64 %t1535)
  store %"compiler/mir:BasicBlock" %t1538, ptr %l772
  br label %bb344
bb344:
  %t1539 = load %"compiler/mir:BasicBlock", ptr %l772
  store %"compiler/mir:BasicBlock" %t1539, ptr %l105
  store i64 0, ptr %l106, !tbaa !24
  %t1540 = getelementptr %"compiler/mir:BasicBlock", ptr %l105, i32 0, i32 0
  %t1542 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t1540)
  store i64 %t1542, ptr %l774
  br label %bb345
bb345:
  %t1543 = load i64, ptr %l774, !tbaa !24
  store i64 %t1543, ptr %l107, !tbaa !24
  store i64 1, ptr %l108, !tbaa !24
  %t1544 = load i64, ptr %l107, !tbaa !24
  %t1545 = load i64, ptr %l106, !tbaa !24
  %t1548 = icmp sgt i64 %t1544, %t1545
  br i1 %t1548, label %bb346, label %bb347
bb346:
  %t1550 = load i64, ptr %l108, !tbaa !24
  %t1552 = icmp sgt i64 %t1550, 0
  br i1 %t1552, label %bb348, label %bb349
bb347:
  store i64 0, ptr %l778, !tbaa !24
  br label %bb351
bb348:
  %t1554 = load i64, ptr %l107, !tbaa !24
  %t1555 = load i64, ptr %l106, !tbaa !24
  %t1558 = sub i64 %t1554, %t1555
  %t1559 = load i64, ptr %l108, !tbaa !24
  %t1562 = add i64 %t1558, %t1559
  %t1564 = sub i64 %t1562, 1
  %t1565 = load i64, ptr %l108, !tbaa !24
  %t1568 = sdiv i64 %t1564, %t1565
  store i64 %t1568, ptr %l781, !tbaa !24
  br label %bb350
bb349:
  store i64 0, ptr %l781, !tbaa !24
  br label %bb350
bb350:
  %t1570 = load i64, ptr %l781, !tbaa !24
  store i64 %t1570, ptr %l778, !tbaa !24
  br label %bb351
bb351:
  %t1571 = load i64, ptr %l778, !tbaa !24
  store i64 %t1571, ptr %l109, !tbaa !24
  store i64 0, ptr %l110, !tbaa !24
  br label %bb352
bb352:
  store %olang.scope zeroinitializer, ptr %s80
  %t1572 = load i64, ptr %l110, !tbaa !24
  %t1573 = load i64, ptr %l109, !tbaa !24
  %t1576 = icmp slt i64 %t1572, %t1573
  %t1578 = xor i1 %t1576, true
  br i1 %t1578, label %bb353, label %bb354
bb353:
  call void @__olang_scope_close(ptr %s80)
  br label %bb359
bb354:
  br label %bb355
bb355:
  %t1580 = load i64, ptr %l106, !tbaa !24
  %t1581 = load i64, ptr %l110, !tbaa !24
  %t1582 = load i64, ptr %l108, !tbaa !24
  %t1585 = mul i64 %t1581, %t1582
  %t1588 = add i64 %t1580, %t1585
  store i64 %t1588, ptr %l111, !tbaa !24
  %t1590 = load ptr, ptr %l0, !tbaa !29
  %t1591 = load i64, ptr %l111, !tbaa !24
  %t1594 = getelementptr %"compiler/mir:verifier", ptr %t1590, i32 0, i32 4
  store i64 %t1591, ptr %t1594, !tbaa !24
  %t1595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1595, ptr %l801, !tbaa !29
  %t1596 = getelementptr %"compiler/mir:BasicBlock", ptr %l105, i32 0, i32 0
  %t1597 = load i64, ptr %l111, !tbaa !24
  %t1600 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t1596, i64 %t1597)
  store { i64, [21 x i64] } %t1600, ptr %l804
  br label %bb356
bb356:
  %t1601 = load { i64, [21 x i64] }, ptr %l804
  %t1602 = call ptr @__olang_scope_alloc_a(ptr %s80, i64 176, i64 8)
  store { i64, [21 x i64] } %t1601, ptr %t1602
  %t1603 = load ptr, ptr %l801, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %s80, ptr %t1603, ptr %t1602)
  br label %bb357
bb357:
  call void @__olang_scope_close(ptr %s80)
  br label %bb358
bb358:
  %t1605 = load i64, ptr %l110, !tbaa !24
  %t1607 = add i64 %t1605, 1
  store i64 %t1607, ptr %l110, !tbaa !24
  br label %bb352
bb359:
  %t1609 = load ptr, ptr %l0, !tbaa !29
  %t1611 = getelementptr %"compiler/mir:verifier", ptr %t1609, i32 0, i32 4
  store i64 -1, ptr %t1611, !tbaa !24
  %t1612 = load ptr, ptr %l0, !tbaa !29
  %t1613 = getelementptr %"compiler/mir:BasicBlock", ptr %l105, i32 0, i32 1
  %t1614 = load { i64, [7 x i64] }, ptr %t1613
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %t1612, { i64, [7 x i64] } %t1614)
  br label %bb360
bb360:
  call void @__olang_scope_close(ptr %s78)
  br label %bb361
bb361:
  %t1617 = load i64, ptr %l103, !tbaa !24
  %t1619 = add i64 %t1617, 1
  store i64 %t1619, ptr %l103, !tbaa !24
  br label %bb340
bb362:
  %t1621 = load ptr, ptr %l0, !tbaa !29
  %t1625 = getelementptr %"compiler/mir:verifier", ptr %t1621, i32 0, i32 3
  store i64 -1, ptr %t1625, !tbaa !24
  %t1626 = load ptr, ptr %l0, !tbaa !29
  %t1630 = getelementptr %"compiler/mir:verifier", ptr %t1626, i32 0, i32 4
  store i64 -1, ptr %t1630, !tbaa !24
  %t1631 = load ptr, ptr %l0, !tbaa !29
  %t1633 = getelementptr %"compiler/mir:verifier", ptr %t1631, i32 0, i32 2
  %t1635 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1633)
  store i64 %t1635, ptr %l819
  br label %bb363
bb363:
  %t1636 = load i64, ptr %l2, !tbaa !24
  %t1637 = load i64, ptr %l819, !tbaa !24
  %t1639 = icmp eq i64 %t1637, %t1636
  store i1 %t1639, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 11
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l19, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr @.d162 }, ptr %l43, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d163 }, ptr %l43, !tbaa !27
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 12
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 10
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = sext i32 %t74 to i64
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t88 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t69, i64 %t85)
  store i32 %t88, ptr %l53
  br label %bb16
bb16:
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } { i64 1, ptr @.d164 }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr @.d164 }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = sext i32 %t95 to i64
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t90, i64 %t91)
  %t100 = getelementptr i8, ptr %t99, i64 %t91
  call void @olang_textcopy(ptr %t100, ptr %t92, i64 %t93)
  %t101 = getelementptr i8, ptr %t100, i64 %t93
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t112 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t112, { i64, ptr } %t111)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb9
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb20
bb20:
  %t120 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t120, ptr %l60
  br label %bb21
bb21:
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t121, ptr %l61, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l62, !tbaa !24
  %t124 = load i64, ptr %l62, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l63, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l62, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t135, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 17
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l12
  br label %bb3
bb3:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb9
bb6:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l19, !tbaa !24
  store i64 %t36, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l16, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l37, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr @.d165 }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr @.d166 }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 17
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t62, i64 %t63)
  store i32 %t66, ptr %l44
  br label %bb17
bb17:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } { i64 1, ptr @.d167 }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr @.d167 }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load i32, ptr %l44, !tbaa !23
  %t74 = sext i32 %t73 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t70, i64 %t71)
  %t79 = getelementptr i8, ptr %t78, i64 %t71
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t74)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t98, ptr %l51
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t99, ptr %l52, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l53, !tbaa !24
  %t102 = load i64, ptr %l53, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t114 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca %"compiler/mir:Place"
  %l10 = alloca %"compiler/mir:Place"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca %"compiler/mir:Place"
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l138 = alloca i1
  %l141 = alloca i1
  %l143 = alloca i64
  %l147 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l167 = alloca i1
  %l173 = alloca i1
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Place", ptr %t13
  store %"compiler/mir:Place" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Place", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t22, %"compiler/mir:Place" %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [15 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %t26, { i64, [15 x i64] } %t27)
  br label %bb7
bb7:
  br label %bb107
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t31 = load ptr, ptr %l32, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l33, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t46 = load ptr, ptr %l38, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l39, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l46
  br label %bb18
bb18:
  br label %bb107
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t66 = load ptr, ptr %l47, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l48, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32 }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb32
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t81 = load ptr, ptr %l53, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l53, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 4
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l54, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb32
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t96 = load ptr, ptr %l59, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 5
  store i1 %t102, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l60, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l5, !tbaa !23
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l5, !tbaa !23
  %t114 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t110, i32 %t111)
  store i1 %t114, ptr %l67
  br label %bb33
bb33:
  br label %bb107
bb34:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t116 = load ptr, ptr %l68, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 6
  store i1 %t122, ptr %l69, !tbaa !21
  br label %bb36
bb36:
  %t123 = load i1, ptr %l69, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [21 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t126, i32 0, i32 1
  %t128 = load { i64, [1 x i64] }, ptr %t127
  store { i64, [1 x i64] } %t128, ptr %l6
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [21 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t132, i32 0, i32 3
  %t134 = load { i64, [4 x i64] }, ptr %t133
  store { i64, [4 x i64] } %t134, ptr %l7
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t136, { i64, [1 x i64] } %t137)
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t140, { i64, [4 x i64] } %t141)
  br label %bb41
bb41:
  br label %bb107
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l80, !tbaa !29
  %t149 = load i64, ptr %t148
  %t151 = icmp eq i64 %t149, 7
  store i1 %t151, ptr %l81, !tbaa !21
  br label %bb44
bb44:
  %t152 = load i1, ptr %l81, !tbaa !21
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [21 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t155, i32 0, i32 1
  %t157 = load { i64, [1 x i64] }, ptr %t156
  store { i64, [1 x i64] } %t157, ptr %l8
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [21 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t161, i32 0, i32 2
  %t163 = load %"compiler/mir:Place", ptr %t162
  store %"compiler/mir:Place" %t163, ptr %l9
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t165, { i64, [1 x i64] } %t166)
  br label %bb48
bb48:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"compiler/mir:Place", ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t169, %"compiler/mir:Place" %t170)
  br label %bb49
bb49:
  br label %bb107
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l92, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 8
  store i1 %t180, ptr %l93, !tbaa !21
  br label %bb52
bb52:
  %t181 = load i1, ptr %l93, !tbaa !21
  br i1 %t181, label %bb53, label %bb54
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t184, i32 0, i32 1
  %t186 = load %"compiler/mir:Place", ptr %t185
  store %"compiler/mir:Place" %t186, ptr %l10
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load %"compiler/mir:Place", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t188, %"compiler/mir:Place" %t189)
  br label %bb56
bb56:
  br label %bb107
bb57:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t193 = load ptr, ptr %l100, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb58, label %bb59
bb58:
  %t196 = load ptr, ptr %l100, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 9
  store i1 %t199, ptr %l101, !tbaa !21
  br label %bb59
bb59:
  %t200 = load i1, ptr %l101, !tbaa !21
  br i1 %t200, label %bb60, label %bb61
bb60:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [21 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t203, i32 0, i32 1
  %t205 = load { i64, [1 x i64] }, ptr %t204
  store { i64, [1 x i64] } %t205, ptr %l11
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [21 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t209, i32 0, i32 3
  %t211 = load { i64, [4 x i64] }, ptr %t210
  store { i64, [4 x i64] } %t211, ptr %l12
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load { i64, [1 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t213, { i64, [1 x i64] } %t214)
  br label %bb63
bb63:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t217, { i64, [4 x i64] } %t218)
  br label %bb64
bb64:
  br label %bb107
bb65:
  %t221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t221, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t222 = load ptr, ptr %l112, !tbaa !29
  %t223 = icmp ne ptr %t222, null
  br i1 %t223, label %bb66, label %bb67
bb66:
  %t225 = load ptr, ptr %l112, !tbaa !29
  %t226 = load i64, ptr %t225
  %t228 = icmp eq i64 %t226, 10
  store i1 %t228, ptr %l113, !tbaa !21
  br label %bb67
bb67:
  %t229 = load i1, ptr %l113, !tbaa !21
  br i1 %t229, label %bb68, label %bb69
bb68:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [21 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t232, i32 0, i32 1
  %t234 = load %"compiler/mir:Place", ptr %t233
  store %"compiler/mir:Place" %t234, ptr %l13
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [21 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t238, i32 0, i32 2
  %t240 = load %"compiler/mir:Place", ptr %t239
  store %"compiler/mir:Place" %t240, ptr %l14
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [21 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t244, i32 0, i32 3
  %t246 = load { i64, [4 x i64] }, ptr %t245
  store { i64, [4 x i64] } %t246, ptr %l15
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load %"compiler/mir:Place", ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t248, %"compiler/mir:Place" %t249)
  br label %bb71
bb71:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/mir:Place", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t252, %"compiler/mir:Place" %t253)
  br label %bb72
bb72:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load { i64, [4 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t256, { i64, [4 x i64] } %t257)
  br label %bb73
bb73:
  br label %bb107
bb74:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t261 = load ptr, ptr %l128, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb75, label %bb76
bb75:
  %t264 = load ptr, ptr %l128, !tbaa !29
  %t265 = load i64, ptr %t264
  %t267 = icmp eq i64 %t265, 11
  store i1 %t267, ptr %l129, !tbaa !21
  br label %bb76
bb76:
  %t268 = load i1, ptr %l129, !tbaa !21
  br i1 %t268, label %bb77, label %bb78
bb77:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [21 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t271, i32 0, i32 1
  %t273 = load i32, ptr %t272
  store i32 %t273, ptr %l16, !tbaa !23
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [21 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t277, i32 0, i32 2
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l17, !tbaa !23
  br label %bb79
bb78:
  br label %bb89
bb79:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l16, !tbaa !23
  %t285 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l138
  br label %bb80
bb80:
  %t286 = load i32, ptr %l17, !tbaa !23
  %t288 = icmp slt i32 %t286, 0
  br i1 %t288, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb84
bb82:
  %t290 = load i32, ptr %l17, !tbaa !23
  %t292 = sext i32 %t290 to i64
  store i64 %t292, ptr %l143, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/mir:verifier", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/mir:Fn", ptr %t296, i32 0, i32 16
  %t300 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t298)
  store i64 %t300, ptr %l147
  br label %bb83
bb83:
  %t301 = load i64, ptr %l143, !tbaa !24
  %t302 = load i64, ptr %l147, !tbaa !24
  %t303 = icmp sge i64 %t301, %t302
  store i1 %t303, ptr %l141, !tbaa !21
  br label %bb84
bb84:
  %t305 = load i1, ptr %l141, !tbaa !21
  br i1 %t305, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s10
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr %l17, !tbaa !23
  %t308 = extractvalue { i64, ptr } { i64 8, ptr @.d168 }, 1
  %t309 = extractvalue { i64, ptr } { i64 8, ptr @.d168 }, 0
  %t311 = sext i32 %t307 to i64
  %t312 = call i64 @__olang_fmt_i64(ptr null, i64 %t311)
  %t313 = add i64 %t309, %t312
  %t314 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t308, i64 %t309)
  %t315 = getelementptr i8, ptr %t314, i64 %t309
  %t316 = call i64 @__olang_fmt_i64(ptr %t315, i64 %t311)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t314, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = extractvalue { i64, ptr } %t318, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t306, { i64, ptr } %t325)
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb88:
  br label %bb107
bb89:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t329 = load ptr, ptr %l153, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb90, label %bb91
bb90:
  %t332 = load ptr, ptr %l153, !tbaa !29
  %t333 = load i64, ptr %t332
  %t335 = icmp eq i64 %t333, 12
  store i1 %t335, ptr %l154, !tbaa !21
  br label %bb91
bb91:
  %t336 = load i1, ptr %l154, !tbaa !21
  br i1 %t336, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb107
bb95:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t338 = load ptr, ptr %l157, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb96, label %bb97
bb96:
  %t341 = load ptr, ptr %l157, !tbaa !29
  %t342 = load i64, ptr %t341
  %t344 = icmp eq i64 %t342, 13
  store i1 %t344, ptr %l158, !tbaa !21
  br label %bb97
bb97:
  %t345 = load i1, ptr %l158, !tbaa !21
  br i1 %t345, label %bb98, label %bb99
bb98:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [21 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t348, i32 0, i32 1
  %t350 = load i32, ptr %t349
  store i32 %t350, ptr %l18, !tbaa !23
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [21 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t354, i32 0, i32 2
  %t356 = load i32, ptr %t355
  store i32 %t356, ptr %l19, !tbaa !23
  br label %bb100
bb99:
  br label %bb106
bb100:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l18, !tbaa !23
  %t362 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t358, i32 %t359)
  store i1 %t362, ptr %l167
  br label %bb101
bb101:
  %t363 = load i32, ptr %l19, !tbaa !23
  %t364 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t367 = icmp ne i32 %t363, %t364
  br i1 %t367, label %bb102, label %bb103
bb102:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr %l19, !tbaa !23
  %t373 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t369, i32 %t370)
  store i1 %t373, ptr %l173
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_145fd452f8e36c9b_ff9c6902187c9987)
  unreachable
bb107:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Place"
  %l11 = alloca i32
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca i32
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca %"compiler/mir:Place"
  %l19 = alloca %"compiler/mir:Place"
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Task"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca i32
  %l95 = alloca i1
  %l97 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l116 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l138 = alloca i32
  %l142 = alloca i1
  %l145 = alloca i1
  %l146 = alloca i1
  %l149 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca i1
  %l174 = alloca i32
  %l177 = alloca i32
  %l178 = alloca i1
  %l185 = alloca i1
  %l196 = alloca i1
  %l197 = alloca i1
  %l200 = alloca i1
  %l206 = alloca i1
  %l211 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i32
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l231 = alloca i1
  %l240 = alloca ptr
  %l243 = alloca i32
  %l244 = alloca i32
  %l245 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca i32
  %l253 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca ptr
  %l262 = alloca i32
  %l263 = alloca i32
  %l264 = alloca ptr
  %l267 = alloca i32
  %l268 = alloca i32
  %l269 = alloca i1
  %l271 = alloca ptr
  %l274 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l280 = alloca ptr
  %l281 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca i32
  %l286 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca i1
  %l302 = alloca %"compiler/mir:ScopeInfo"
  %l315 = alloca %"compiler/mir:Task"
  %l318 = alloca i32
  %l327 = alloca ptr
  %l328 = alloca ptr
  %l331 = alloca i32
  %l334 = alloca i32
  %l337 = alloca i32
  %l338 = alloca i32
  %l339 = alloca { i64, ptr }
  %l342 = alloca i1
  %l358 = alloca i32
  %l361 = alloca i32
  %l379 = alloca ptr
  %l381 = alloca i32
  %l382 = alloca ptr
  %l391 = alloca %"compiler/mir:Place"
  %l392 = alloca i32
  %l400 = alloca i1
  %l401 = alloca ptr
  %l404 = alloca i32
  %l405 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.builder
  %s21room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t7 = load ptr, ptr %l36, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l36, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l37, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l37, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Place", ptr %t18
  store %"compiler/mir:Place" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Place", ptr %l3
  %t31 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t27, %"compiler/mir:Place" %t28)
  store i32 %t31, ptr %l46
  br label %bb6
bb6:
  %t32 = load i32, ptr %l46, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [15 x i64] }, ptr %l4
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %t33, { i64, [15 x i64] } %t34)
  store i32 %t37, ptr %l49
  br label %bb7
bb7:
  %t38 = load i32, ptr %l49, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp ne i32 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load i32, ptr %l6, !tbaa !23
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = icmp ne i32 %t45, %t46
  store i1 %t49, ptr %l53, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l53, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t54 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s2, ptr %t52, i32 %t53, i32 %t54, { i64, ptr } { i64 16, ptr @.d169 })
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l5, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l62
  br label %bb15
bb15:
  %t63 = load i1, ptr %l62, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l66
  br label %bb18
bb17:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t70 = load i64, ptr %l66, !tbaa !24
  %t72 = and i64 %t70, %t69
  %t74 = icmp ne i64 %t72, 0
  store i1 %t74, ptr %l63, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l63, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l6, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l73
  br label %bb22
bb21:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb23
bb22:
  %t82 = load i1, ptr %l73, !tbaa !21
  store i1 %t82, ptr %l70, !tbaa !21
  br label %bb23
bb23:
  %t83 = load i1, ptr %l70, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t85 = load i32, ptr %l6, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l77
  br label %bb26
bb25:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb27
bb26:
  %t89 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t90 = load i64, ptr %l77, !tbaa !24
  %t92 = and i64 %t90, %t89
  %t94 = icmp eq i64 %t92, 0
  store i1 %t94, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l74, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t97, { i64, ptr } { i64 40, ptr @.d170 })
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  br label %bb227
bb32:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t100 = load ptr, ptr %l82, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l82, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l83, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l83, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [21 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t110, i32 0, i32 2
  %t112 = load i32, ptr %t111
  store i32 %t112, ptr %l7, !tbaa !23
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [21 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t116, i32 0, i32 3
  %t118 = load { i64, [4 x i64] }, ptr %t117
  store { i64, [4 x i64] } %t118, ptr %l8
  br label %bb37
bb36:
  br label %bb57
bb37:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, [4 x i64] }, ptr %l8
  %t124 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t120, { i64, [4 x i64] } %t121)
  store i32 %t124, ptr %l92
  br label %bb38
bb38:
  %t125 = load i32, ptr %l92, !tbaa !23
  store i32 %t125, ptr %l9, !tbaa !23
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t127 = load i32, ptr %l9, !tbaa !23
  %t130 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t130, ptr %l95
  br label %bb39
bb39:
  %t131 = load i1, ptr %l95, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb44
bb41:
  %t134 = load ptr, ptr %l2, !tbaa !29
  store ptr %t134, ptr %l98, !tbaa !29
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t136 = load i32, ptr %l9, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l101
  br label %bb42
bb42:
  %t140 = load i32, ptr %l7, !tbaa !23
  %t141 = load ptr, ptr %l98, !tbaa !29
  %t142 = load i32, ptr %l101, !tbaa !23
  %t144 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t141, i32 %t142, i32 %t140)
  store i1 %t144, ptr %l103
  br label %bb43
bb43:
  %t145 = load i1, ptr %l103, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l97, !tbaa !21
  br label %bb44
bb44:
  %t148 = load i1, ptr %l97, !tbaa !21
  br i1 %t148, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l105, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l9, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t150, i32 %t151)
  store { i64, ptr } %t154, ptr %l108
  br label %bb47
bb46:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t156 = load i32, ptr %l7, !tbaa !23
  %t159 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l116
  br label %bb50
bb47:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l7, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t160, i32 %t161)
  store { i64, ptr } %t164, ptr %l111
  br label %bb48
bb48:
  %t165 = extractvalue { i64, ptr } { i64 30, ptr @.d171 }, 1
  %t166 = extractvalue { i64, ptr } { i64 30, ptr @.d171 }, 0
  %t167 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 23, ptr @.d172 }, 1
  %t172 = extractvalue { i64, ptr } { i64 23, ptr @.d172 }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t165, i64 %t166)
  %t179 = getelementptr i8, ptr %t178, i64 %t166
  call void @olang_textcopy(ptr %t179, ptr %t168, i64 %t169)
  %t180 = getelementptr i8, ptr %t179, i64 %t169
  call void @olang_textcopy(ptr %t180, ptr %t171, i64 %t172)
  %t181 = getelementptr i8, ptr %t180, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t191, { i64, ptr } %t190)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb50:
  %t193 = load i1, ptr %l116, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l118, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l7, !tbaa !23
  %t201 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s8, ptr %t197, i32 %t198)
  store { i64, ptr } %t201, ptr %l121
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t202 = extractvalue { i64, ptr } { i64 30, ptr @.d173 }, 1
  %t203 = extractvalue { i64, ptr } { i64 30, ptr @.d173 }, 0
  %t204 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 21, ptr @.d174 }, 1
  %t209 = extractvalue { i64, ptr } { i64 21, ptr @.d174 }, 0
  %t210 = add i64 %t207, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t202, i64 %t203)
  %t212 = getelementptr i8, ptr %t211, i64 %t203
  call void @olang_textcopy(ptr %t212, ptr %t205, i64 %t206)
  %t213 = getelementptr i8, ptr %t212, i64 %t206
  call void @olang_textcopy(ptr %t213, ptr %t208, i64 %t209)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t211, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = extractvalue { i64, ptr } %t215, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  %t223 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t223, { i64, ptr } %t222)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb227
bb57:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t226 = load ptr, ptr %l124, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb58, label %bb59
bb58:
  %t229 = load ptr, ptr %l124, !tbaa !29
  %t230 = load i64, ptr %t229
  %t232 = icmp eq i64 %t230, 7
  store i1 %t232, ptr %l125, !tbaa !21
  br label %bb59
bb59:
  %t233 = load i1, ptr %l125, !tbaa !21
  br i1 %t233, label %bb60, label %bb61
bb60:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [21 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t236, i32 0, i32 2
  %t238 = load %"compiler/mir:Place", ptr %t237
  store %"compiler/mir:Place" %t238, ptr %l10
  br label %bb66
bb61:
  %t240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t240, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t241 = load ptr, ptr %l130, !tbaa !29
  %t242 = icmp ne ptr %t241, null
  br i1 %t242, label %bb62, label %bb63
bb62:
  %t244 = load ptr, ptr %l130, !tbaa !29
  %t245 = load i64, ptr %t244
  %t247 = icmp eq i64 %t245, 8
  store i1 %t247, ptr %l131, !tbaa !21
  br label %bb63
bb63:
  %t248 = load i1, ptr %l131, !tbaa !21
  br i1 %t248, label %bb64, label %bb65
bb64:
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = getelementptr { i64, [21 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t251, i32 0, i32 1
  %t253 = load %"compiler/mir:Place", ptr %t252
  store %"compiler/mir:Place" %t253, ptr %l10
  br label %bb66
bb65:
  br label %bb81
bb66:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/mir:Place", ptr %l10
  %t259 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t255, %"compiler/mir:Place" %t256)
  store i32 %t259, ptr %l138
  br label %bb67
bb67:
  %t260 = load i32, ptr %l138, !tbaa !23
  store i32 %t260, ptr %l11, !tbaa !23
  %t261 = load i32, ptr %l11, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t265 = icmp ne i32 %t261, %t262
  br i1 %t265, label %bb68, label %bb69
bb68:
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t268 = load i32, ptr %l11, !tbaa !23
  %t271 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l145
  br label %bb70
bb69:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb75
bb70:
  %t272 = load i1, ptr %l145, !tbaa !21
  br i1 %t272, label %bb71, label %bb72
bb71:
  %t273 = load ptr, ptr %l2, !tbaa !29
  %t274 = load i32, ptr %l11, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t273, i32 %t274)
  store i64 %t277, ptr %l149
  br label %bb73
bb72:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb74
bb73:
  %t278 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t279 = load i64, ptr %l149, !tbaa !24
  %t281 = and i64 %t279, %t278
  %t283 = icmp ne i64 %t281, 0
  store i1 %t283, ptr %l146, !tbaa !21
  br label %bb74
bb74:
  %t285 = load i1, ptr %l146, !tbaa !21
  %t286 = xor i1 %t285, true
  store i1 %t286, ptr %l142, !tbaa !21
  br label %bb75
bb75:
  %t288 = load i1, ptr %l142, !tbaa !21
  br i1 %t288, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s11
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l154, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l11, !tbaa !23
  %t294 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t290, i32 %t291)
  store { i64, ptr } %t294, ptr %l157
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t295 = extractvalue { i64, ptr } { i64 19, ptr @.d175 }, 1
  %t296 = extractvalue { i64, ptr } { i64 19, ptr @.d175 }, 0
  %t297 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 22, ptr @.d176 }, 1
  %t302 = extractvalue { i64, ptr } { i64 22, ptr @.d176 }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = extractvalue { i64, ptr } %t308, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %l154, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t316, { i64, ptr } %t315)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb80:
  br label %bb227
bb81:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t319 = load ptr, ptr %l160, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb82, label %bb83
bb82:
  %t322 = load ptr, ptr %l160, !tbaa !29
  %t323 = load i64, ptr %t322
  %t325 = icmp eq i64 %t323, 9
  store i1 %t325, ptr %l161, !tbaa !21
  br label %bb83
bb83:
  %t326 = load i1, ptr %l161, !tbaa !21
  br i1 %t326, label %bb84, label %bb85
bb84:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [21 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t329, i32 0, i32 1
  %t331 = load { i64, [1 x i64] }, ptr %t330
  store { i64, [1 x i64] } %t331, ptr %l12
  %t333 = load ptr, ptr %l1, !tbaa !29
  %t335 = getelementptr { i64, [21 x i64] }, ptr %t333, i32 0, i32 1
  %t336 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t335, i32 0, i32 2
  %t337 = load i32, ptr %t336
  store i32 %t337, ptr %l13
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [21 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t341, i32 0, i32 3
  %t343 = load { i64, [4 x i64] }, ptr %t342
  store { i64, [4 x i64] } %t343, ptr %l14
  br label %bb86
bb85:
  br label %bb134
bb86:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load { i64, [1 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t345, { i64, [1 x i64] } %t346)
  br label %bb87
bb87:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, [4 x i64] }, ptr %l14
  %t353 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t349, { i64, [4 x i64] } %t350)
  store i32 %t353, ptr %l174
  br label %bb88
bb88:
  %t354 = load i32, ptr %l174, !tbaa !23
  store i32 %t354, ptr %l15, !tbaa !23
  %t355 = load ptr, ptr %l2, !tbaa !29
  %t356 = load i32, ptr %l15, !tbaa !23
  %t359 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t359, ptr %l177
  br label %bb89
bb89:
  %t360 = load i32, ptr %l177, !tbaa !23
  store i32 %t360, ptr %l16, !tbaa !23
  %t361 = load i32, ptr %l13
  %t363 = trunc i64 0 to i32
  %t364 = icmp eq i32 %t361, %t363
  br i1 %t364, label %bb90, label %bb91
bb90:
  br label %bb94
bb91:
  %t366 = load i32, ptr %l13
  %t368 = trunc i64 1 to i32
  %t369 = icmp eq i32 %t366, %t368
  br i1 %t369, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l15, !tbaa !23
  %t375 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t371, i32 %t372)
  store i1 %t375, ptr %l185
  br label %bb95
bb95:
  %t376 = load i1, ptr %l185, !tbaa !21
  store i1 %t376, ptr %l178, !tbaa !21
  br label %bb126
bb96:
  %t377 = load i32, ptr %l13
  %t379 = trunc i64 2 to i32
  %t380 = icmp eq i32 %t377, %t379
  br i1 %t380, label %bb97, label %bb98
bb97:
  br label %bb101
bb98:
  %t382 = load i32, ptr %l13
  %t384 = trunc i64 3 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  %t387 = load i32, ptr %l16, !tbaa !23
  %t389 = icmp eq i32 %t387, 7
  store i1 %t389, ptr %l178, !tbaa !21
  br label %bb126
bb102:
  %t391 = load i32, ptr %l13
  %t393 = trunc i64 4 to i32
  %t394 = icmp eq i32 %t391, %t393
  br i1 %t394, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb111
bb105:
  %t396 = load ptr, ptr %l2, !tbaa !29
  %t397 = load i32, ptr %l16, !tbaa !23
  %t400 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t396, i32 %t397)
  store i1 %t400, ptr %l196
  br label %bb106
bb106:
  %t401 = load i1, ptr %l196, !tbaa !21
  br i1 %t401, label %bb107, label %bb108
bb107:
  %t402 = load ptr, ptr %l2, !tbaa !29
  %t403 = load i32, ptr %l16, !tbaa !23
  %t406 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t402, i32 %t403)
  store i1 %t406, ptr %l200
  br label %bb109
bb108:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb110
bb109:
  %t407 = load i1, ptr %l200, !tbaa !21
  %t408 = xor i1 %t407, true
  store i1 %t408, ptr %l197, !tbaa !21
  br label %bb110
bb110:
  %t410 = load i1, ptr %l197, !tbaa !21
  store i1 %t410, ptr %l178, !tbaa !21
  br label %bb126
bb111:
  %t411 = load i32, ptr %l13
  %t413 = trunc i64 5 to i32
  %t414 = icmp eq i32 %t411, %t413
  br i1 %t414, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t417 = load i32, ptr %l16, !tbaa !23
  %t420 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t416, i32 %t417)
  store i1 %t420, ptr %l206
  br label %bb115
bb115:
  %t421 = load i1, ptr %l206, !tbaa !21
  store i1 %t421, ptr %l178, !tbaa !21
  br label %bb126
bb116:
  %t422 = load i32, ptr %l13
  %t424 = trunc i64 6 to i32
  %t425 = icmp eq i32 %t422, %t424
  br i1 %t425, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb121
bb119:
  %t427 = load ptr, ptr %l2, !tbaa !29
  %t428 = load i32, ptr %l16, !tbaa !23
  %t431 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t427, i32 %t428)
  store i1 %t431, ptr %l211
  br label %bb120
bb120:
  %t432 = load i1, ptr %l211, !tbaa !21
  store i1 %t432, ptr %l178, !tbaa !21
  br label %bb126
bb121:
  %t433 = load i32, ptr %l13
  %t435 = trunc i64 7 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  %t438 = load i32, ptr %l16, !tbaa !23
  %t439 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t442 = icmp eq i32 %t438, %t439
  store i1 %t442, ptr %l178, !tbaa !21
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23)
  unreachable
bb126:
  %t444 = load i1, ptr %l178, !tbaa !21
  %t447 = xor i1 %t444, true
  br i1 %t447, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s20
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l219, !tbaa !29
  %t450 = load i32, ptr %l13
  store i32 %t450, ptr %l220
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s21
  store ptr %s21room, ptr %s21
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s21, ptr %l220, i64 0)
  br label %bb129
bb128:
  br label %bb133
bb129:
  %t452 = load ptr, ptr %s21
  %t453 = getelementptr %olang.builder, ptr %s21, i32 0, i32 1
  %t454 = load i64, ptr %t453
  %t455 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t454)
  call void @olang_textcopy(ptr %t455, ptr %t452, i64 %t454)
  %t456 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  store { i64, ptr } %t457, ptr %l222, !tbaa !27
  %t458 = getelementptr %olang.builder, ptr %s21, i32 0, i32 3
  %t459 = load ptr, ptr %t458
  %t460 = icmp ne ptr %t459, null
  br i1 %t460, label %sbgrew.461, label %sbdone.462
sbgrew.461:
  call void @__olang_sb_done(ptr %s21)
  br label %sbdone.462
sbdone.462:
  %t463 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 0
  %t465 = extractvalue { i64, ptr } %t463, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t471 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s20, { i64, ptr } %t469)
  store { i64, ptr } %t471, ptr %l224
  br label %bb130
bb130:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i32, ptr %l15, !tbaa !23
  %t476 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s20, ptr %t472, i32 %t473)
  store { i64, ptr } %t476, ptr %l227
  br label %bb131
bb131:
  %t477 = extractvalue { i64, ptr } { i64 2, ptr @.d177 }, 1
  %t478 = extractvalue { i64, ptr } { i64 2, ptr @.d177 }, 0
  %t479 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = add i64 %t478, %t481
  %t483 = extractvalue { i64, ptr } { i64 12, ptr @.d178 }, 1
  %t484 = extractvalue { i64, ptr } { i64 12, ptr @.d178 }, 0
  %t485 = add i64 %t482, %t484
  %t486 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = add i64 %t485, %t488
  %t490 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t489)
  call void @olang_textcopy(ptr %t490, ptr %t477, i64 %t478)
  %t491 = getelementptr i8, ptr %t490, i64 %t478
  call void @olang_textcopy(ptr %t491, ptr %t480, i64 %t481)
  %t492 = getelementptr i8, ptr %t491, i64 %t481
  call void @olang_textcopy(ptr %t492, ptr %t483, i64 %t484)
  %t493 = getelementptr i8, ptr %t492, i64 %t484
  call void @olang_textcopy(ptr %t493, ptr %t487, i64 %t488)
  %t494 = insertvalue { i64, ptr } undef, i64 %t489, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t490, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = extractvalue { i64, ptr } %t495, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t503 = load ptr, ptr %l219, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t503, { i64, ptr } %t502)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s20)
  br label %bb133
bb133:
  br label %bb227
bb134:
  %t505 = load ptr, ptr %l1, !tbaa !29
  store ptr %t505, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t506 = load ptr, ptr %l230, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb135, label %bb136
bb135:
  %t509 = load ptr, ptr %l230, !tbaa !29
  %t510 = load i64, ptr %t509
  %t512 = icmp eq i64 %t510, 10
  store i1 %t512, ptr %l231, !tbaa !21
  br label %bb136
bb136:
  %t513 = load i1, ptr %l231, !tbaa !21
  br i1 %t513, label %bb137, label %bb138
bb137:
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = getelementptr { i64, [21 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t516, i32 0, i32 1
  %t518 = load %"compiler/mir:Place", ptr %t517
  store %"compiler/mir:Place" %t518, ptr %l18
  %t520 = load ptr, ptr %l1, !tbaa !29
  %t522 = getelementptr { i64, [21 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t522, i32 0, i32 2
  %t524 = load %"compiler/mir:Place", ptr %t523
  store %"compiler/mir:Place" %t524, ptr %l19
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr { i64, [21 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t528, i32 0, i32 3
  %t530 = load { i64, [4 x i64] }, ptr %t529
  store { i64, [4 x i64] } %t530, ptr %l20
  br label %bb139
bb138:
  br label %bb169
bb139:
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l240, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load %"compiler/mir:Place", ptr %l18
  %t537 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t533, %"compiler/mir:Place" %t534)
  store i32 %t537, ptr %l243
  br label %bb140
bb140:
  %t538 = load ptr, ptr %l240, !tbaa !29
  %t539 = load i32, ptr %l243, !tbaa !23
  %t540 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t538, i32 %t539)
  store i32 %t540, ptr %l244
  br label %bb141
bb141:
  %t541 = load i32, ptr %l244, !tbaa !23
  store i32 %t541, ptr %l21, !tbaa !23
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l245, !tbaa !29
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load %"compiler/mir:Place", ptr %l19
  %t547 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t543, %"compiler/mir:Place" %t544)
  store i32 %t547, ptr %l248
  br label %bb142
bb142:
  %t548 = load ptr, ptr %l245, !tbaa !29
  %t549 = load i32, ptr %l248, !tbaa !23
  %t550 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t548, i32 %t549)
  store i32 %t550, ptr %l249
  br label %bb143
bb143:
  %t551 = load i32, ptr %l249, !tbaa !23
  store i32 %t551, ptr %l22, !tbaa !23
  %t552 = load i32, ptr %l21, !tbaa !23
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t556 = icmp eq i32 %t552, %t553
  br i1 %t556, label %bb144, label %bb145
bb144:
  store i1 true, ptr %l253, !tbaa !21
  br label %bb146
bb145:
  %t558 = load i32, ptr %l22, !tbaa !23
  %t559 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t562 = icmp eq i32 %t558, %t559
  store i1 %t562, ptr %l253, !tbaa !21
  br label %bb146
bb146:
  %t564 = load i1, ptr %l253, !tbaa !21
  br i1 %t564, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s24
  %t565 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t565, { i64, ptr } { i64 55, ptr @.d179 })
  br label %bb149
bb148:
  %t567 = load ptr, ptr %l2, !tbaa !29
  store ptr %t567, ptr %l258, !tbaa !29
  %t568 = load ptr, ptr %l2, !tbaa !29
  store ptr %t568, ptr %l259, !tbaa !29
  %t569 = load ptr, ptr %l2, !tbaa !29
  %t570 = load i32, ptr %l21, !tbaa !23
  %t573 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t569, i32 %t570)
  store i32 %t573, ptr %l262
  br label %bb150
bb149:
  call void @__olang_scope_close(ptr %s24)
  br label %bb161
bb150:
  %t574 = load ptr, ptr %l259, !tbaa !29
  %t575 = load i32, ptr %l262, !tbaa !23
  %t576 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t574, i32 %t575)
  store i32 %t576, ptr %l263
  br label %bb151
bb151:
  %t577 = load ptr, ptr %l2, !tbaa !29
  store ptr %t577, ptr %l264, !tbaa !29
  %t578 = load ptr, ptr %l2, !tbaa !29
  %t579 = load i32, ptr %l22, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t578, i32 %t579)
  store i32 %t582, ptr %l267
  br label %bb152
bb152:
  %t583 = load ptr, ptr %l264, !tbaa !29
  %t584 = load i32, ptr %l267, !tbaa !23
  %t585 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t583, i32 %t584)
  store i32 %t585, ptr %l268
  br label %bb153
bb153:
  %t586 = load ptr, ptr %l258, !tbaa !29
  %t587 = load i32, ptr %l263, !tbaa !23
  %t588 = load i32, ptr %l268, !tbaa !23
  %t589 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l269
  br label %bb154
bb154:
  %t590 = load i1, ptr %l269, !tbaa !21
  %t591 = xor i1 %t590, true
  br i1 %t591, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s26
  %t593 = load ptr, ptr %l0, !tbaa !29
  store ptr %t593, ptr %l271, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load i32, ptr %l22, !tbaa !23
  %t598 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t594, i32 %t595)
  store { i64, ptr } %t598, ptr %l274
  br label %bb157
bb156:
  br label %bb160
bb157:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i32, ptr %l21, !tbaa !23
  %t603 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s26, ptr %t599, i32 %t600)
  store { i64, ptr } %t603, ptr %l277
  br label %bb158
bb158:
  %t604 = extractvalue { i64, ptr } { i64 26, ptr @.d180 }, 1
  %t605 = extractvalue { i64, ptr } { i64 26, ptr @.d180 }, 0
  %t606 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t607 = extractvalue { i64, ptr } %t606, 1
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t609 = add i64 %t605, %t608
  %t610 = extractvalue { i64, ptr } { i64 7, ptr @.d181 }, 1
  %t611 = extractvalue { i64, ptr } { i64 7, ptr @.d181 }, 0
  %t612 = add i64 %t609, %t611
  %t613 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = add i64 %t612, %t615
  %t617 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t616)
  call void @olang_textcopy(ptr %t617, ptr %t604, i64 %t605)
  %t618 = getelementptr i8, ptr %t617, i64 %t605
  call void @olang_textcopy(ptr %t618, ptr %t607, i64 %t608)
  %t619 = getelementptr i8, ptr %t618, i64 %t608
  call void @olang_textcopy(ptr %t619, ptr %t610, i64 %t611)
  %t620 = getelementptr i8, ptr %t619, i64 %t611
  call void @olang_textcopy(ptr %t620, ptr %t614, i64 %t615)
  %t621 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t622 = insertvalue { i64, ptr } %t621, ptr %t617, 1
  %t624 = extractvalue { i64, ptr } %t622, 0
  %t625 = extractvalue { i64, ptr } %t622, 1
  %t626 = mul i64 %t624, 1
  %t627 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t626)
  call void @llvm.memcpy.p0.p0.i64(ptr %t627, ptr %t625, i64 %t626, i1 false)
  %t628 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  %t630 = load ptr, ptr %l271, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s26, ptr %t630, { i64, ptr } %t629)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s26)
  br label %bb160
bb160:
  br label %bb161
bb161:
  %t632 = load ptr, ptr %l2, !tbaa !29
  store ptr %t632, ptr %l280, !tbaa !29
  %t633 = load ptr, ptr %l2, !tbaa !29
  store ptr %t633, ptr %l281, !tbaa !29
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t635 = load { i64, [4 x i64] }, ptr %l20
  %t638 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t634, { i64, [4 x i64] } %t635)
  store i32 %t638, ptr %l284
  br label %bb162
bb162:
  %t639 = load ptr, ptr %l281, !tbaa !29
  %t640 = load i32, ptr %l284, !tbaa !23
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t639, i32 %t640)
  store i32 %t641, ptr %l285
  br label %bb163
bb163:
  %t642 = load ptr, ptr %l280, !tbaa !29
  %t643 = load i32, ptr %l285, !tbaa !23
  %t644 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t642, i32 %t643)
  store i1 %t644, ptr %l286
  br label %bb164
bb164:
  %t645 = load i1, ptr %l286, !tbaa !21
  %t646 = xor i1 %t645, true
  br i1 %t646, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s28
  %t648 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s28, ptr %t648, { i64, ptr } { i64 45, ptr @.d182 })
  br label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_scope_close(ptr %s28)
  br label %bb168
bb168:
  br label %bb227
bb169:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t651 = load ptr, ptr %l289, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb170, label %bb171
bb170:
  %t654 = load ptr, ptr %l289, !tbaa !29
  %t655 = load i64, ptr %t654
  %t657 = icmp eq i64 %t655, 11
  store i1 %t657, ptr %l290, !tbaa !21
  br label %bb171
bb171:
  %t658 = load i1, ptr %l290, !tbaa !21
  br i1 %t658, label %bb172, label %bb173
bb172:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [21 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t661, i32 0, i32 1
  %t663 = load i32, ptr %t662
  store i32 %t663, ptr %l23, !tbaa !23
  %t665 = load ptr, ptr %l1, !tbaa !29
  %t667 = getelementptr { i64, [21 x i64] }, ptr %t665, i32 0, i32 1
  %t668 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t667, i32 0, i32 2
  %t669 = load i32, ptr %t668
  store i32 %t669, ptr %l24, !tbaa !23
  br label %bb174
bb173:
  br label %bb222
bb174:
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t673 = getelementptr %"compiler/mir:verifier", ptr %t671, i32 0, i32 0
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t676 = getelementptr %"compiler/mir:Fn", ptr %t674, i32 0, i32 8
  %t677 = load i32, ptr %l23, !tbaa !23
  %t679 = sext i32 %t677 to i64
  %t682 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t676, i64 %t679)
  store %"compiler/mir:ScopeInfo" %t682, ptr %l302
  br label %bb175
bb175:
  %t683 = getelementptr %"compiler/mir:ScopeInfo", ptr %l302, i32 0, i32 0
  %t684 = load i32, ptr %t683
  %t686 = trunc i64 3 to i32
  %t687 = icmp eq i32 %t684, %t686
  %t689 = xor i1 %t687, true
  br i1 %t689, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s30
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load i32, ptr %l23, !tbaa !23
  %t693 = extractvalue { i64, ptr } { i64 14, ptr @.d183 }, 1
  %t694 = extractvalue { i64, ptr } { i64 14, ptr @.d183 }, 0
  %t696 = sext i32 %t692 to i64
  %t697 = call i64 @__olang_fmt_i64(ptr null, i64 %t696)
  %t698 = add i64 %t694, %t697
  %t699 = extractvalue { i64, ptr } { i64 18, ptr @.d184 }, 1
  %t700 = extractvalue { i64, ptr } { i64 18, ptr @.d184 }, 0
  %t701 = add i64 %t698, %t700
  %t702 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t701)
  call void @olang_textcopy(ptr %t702, ptr %t693, i64 %t694)
  %t703 = getelementptr i8, ptr %t702, i64 %t694
  %t704 = call i64 @__olang_fmt_i64(ptr %t703, i64 %t696)
  %t705 = getelementptr i8, ptr %t703, i64 %t697
  call void @olang_textcopy(ptr %t705, ptr %t699, i64 %t700)
  %t706 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t702, 1
  %t709 = extractvalue { i64, ptr } %t707, 0
  %t710 = extractvalue { i64, ptr } %t707, 1
  %t711 = mul i64 %t709, 1
  %t712 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t711)
  call void @llvm.memcpy.p0.p0.i64(ptr %t712, ptr %t710, i64 %t711, i1 false)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t712, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s30, ptr %t691, { i64, ptr } %t714)
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s30)
  br label %bb179
bb179:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/mir:verifier", ptr %t717, i32 0, i32 0
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/mir:Fn", ptr %t720, i32 0, i32 16
  %t723 = load i32, ptr %l24, !tbaa !23
  %t725 = sext i32 %t723 to i64
  %t728 = call %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t722, i64 %t725)
  store %"compiler/mir:Task" %t728, ptr %l315
  br label %bb180
bb180:
  %t729 = load %"compiler/mir:Task", ptr %l315
  store %"compiler/mir:Task" %t729, ptr %l25
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 0
  %t732 = load { i64, [5 x i64] }, ptr %t731
  %t735 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t730, { i64, [5 x i64] } %t732)
  store i32 %t735, ptr %l318
  br label %bb181
bb181:
  %t736 = load i32, ptr %l318, !tbaa !23
  store i32 %t736, ptr %l26, !tbaa !23
  %t737 = load i32, ptr %l26, !tbaa !23
  %t738 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t741 = icmp ne i32 %t737, %t738
  br i1 %t741, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s32
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 0
  %t745 = load { i64, [5 x i64] }, ptr %t744
  %t746 = load i32, ptr %l26, !tbaa !23
  %t747 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 1
  %t748 = load %"compiler/mir:Range", ptr %t747
  %t749 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 2
  %t750 = load %"compiler/mir:Range", ptr %t749
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t743, { i64, [5 x i64] } %t745, i32 %t746, %"compiler/mir:Range" %t748, %"compiler/mir:Range" %t750)
  br label %bb184
bb183:
  br label %bb221
bb184:
  %t756 = load ptr, ptr %l2, !tbaa !29
  store ptr %t756, ptr %l327, !tbaa !29
  %t757 = load ptr, ptr %l2, !tbaa !29
  store ptr %t757, ptr %l328, !tbaa !29
  %t758 = load ptr, ptr %l2, !tbaa !29
  %t759 = load i32, ptr %l26, !tbaa !23
  %t762 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t758, i32 %t759)
  store i32 %t762, ptr %l331
  br label %bb185
bb185:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t764 = load i32, ptr %l26, !tbaa !23
  %t767 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t763, i32 %t764)
  store i32 %t767, ptr %l334
  br label %bb186
bb186:
  %t768 = load ptr, ptr %l2, !tbaa !29
  %t769 = load i32, ptr %l26, !tbaa !23
  %t772 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t768, i32 %t769)
  store i32 %t772, ptr %l337
  br label %bb187
bb187:
  %t773 = load ptr, ptr %l328, !tbaa !29
  %t774 = load i32, ptr %l331, !tbaa !23
  %t775 = load i32, ptr %l334, !tbaa !23
  %t776 = load i32, ptr %l337, !tbaa !23
  %t777 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t773, i32 %t774, i32 %t775, i32 %t776, i32 0, i64 0)
  store i32 %t777, ptr %l338
  br label %bb188
bb188:
  %t778 = load ptr, ptr %l327, !tbaa !29
  %t779 = load i32, ptr %l338, !tbaa !23
  %t780 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s32, ptr %t778, i32 %t779)
  store { i64, ptr } %t780, ptr %l339
  br label %bb189
bb189:
  %t781 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t781, ptr %l27, !tbaa !27
  %t782 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t783 = getelementptr %"compiler/mir:Range", ptr %t782, i32 0, i32 1
  %t784 = load i32, ptr %t783, !tbaa !23
  %t786 = icmp sgt i32 %t784, 0
  br i1 %t786, label %bb190, label %bb191
bb190:
  %t788 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t789 = getelementptr %"compiler/mir:Range", ptr %t788, i32 0, i32 1
  %t790 = load i32, ptr %t789, !tbaa !23
  %t792 = sext i32 %t790 to i64
  %t793 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t798 = icmp ne i64 %t792, %t795
  store i1 %t798, ptr %l342, !tbaa !21
  br label %bb192
bb191:
  store i1 false, ptr %l342, !tbaa !21
  br label %bb192
bb192:
  %t800 = load i1, ptr %l342, !tbaa !21
  br i1 %t800, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s33
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t802 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t803 = getelementptr %"compiler/mir:Range", ptr %t802, i32 0, i32 1
  %t804 = load i32, ptr %t803, !tbaa !23
  %t805 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = extractvalue { i64, ptr } { i64 12, ptr @.d185 }, 1
  %t809 = extractvalue { i64, ptr } { i64 12, ptr @.d185 }, 0
  %t811 = sext i32 %t804 to i64
  %t812 = call i64 @__olang_fmt_i64(ptr null, i64 %t811)
  %t813 = add i64 %t809, %t812
  %t814 = extractvalue { i64, ptr } { i64 13, ptr @.d186 }, 1
  %t815 = extractvalue { i64, ptr } { i64 13, ptr @.d186 }, 0
  %t816 = add i64 %t813, %t815
  %t818 = call i64 @__olang_fmt_i64(ptr null, i64 %t807)
  %t819 = add i64 %t816, %t818
  %t820 = extractvalue { i64, ptr } { i64 8, ptr @.d187 }, 1
  %t821 = extractvalue { i64, ptr } { i64 8, ptr @.d187 }, 0
  %t822 = add i64 %t819, %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t808, i64 %t809)
  %t824 = getelementptr i8, ptr %t823, i64 %t809
  %t825 = call i64 @__olang_fmt_i64(ptr %t824, i64 %t811)
  %t826 = getelementptr i8, ptr %t824, i64 %t812
  call void @olang_textcopy(ptr %t826, ptr %t814, i64 %t815)
  %t827 = getelementptr i8, ptr %t826, i64 %t815
  %t828 = call i64 @__olang_fmt_i64(ptr %t827, i64 %t807)
  %t829 = getelementptr i8, ptr %t827, i64 %t818
  call void @olang_textcopy(ptr %t829, ptr %t820, i64 %t821)
  %t830 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t823, 1
  %t833 = extractvalue { i64, ptr } %t831, 0
  %t834 = extractvalue { i64, ptr } %t831, 1
  %t835 = mul i64 %t833, 1
  %t836 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t835)
  call void @llvm.memcpy.p0.p0.i64(ptr %t836, ptr %t834, i64 %t835, i1 false)
  %t837 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t838 = insertvalue { i64, ptr } %t837, ptr %t836, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t801, { i64, ptr } %t838)
  br label %bb195
bb194:
  store i32 0, ptr %l28, !tbaa !23
  %t841 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t842 = getelementptr %"compiler/mir:Range", ptr %t841, i32 0, i32 1
  %t843 = load i32, ptr %t842, !tbaa !23
  store i32 %t843, ptr %l29, !tbaa !23
  store i32 1, ptr %l30, !tbaa !23
  %t845 = load i32, ptr %l29, !tbaa !23
  %t846 = load i32, ptr %l28, !tbaa !23
  %t849 = icmp sgt i32 %t845, %t846
  br i1 %t849, label %bb196, label %bb197
bb195:
  call void @__olang_scope_close(ptr %s33)
  br label %bb211
bb196:
  %t851 = load i32, ptr %l30, !tbaa !23
  %t853 = icmp sgt i32 %t851, 0
  br i1 %t853, label %bb198, label %bb199
bb197:
  store i32 0, ptr %l358, !tbaa !23
  br label %bb201
bb198:
  %t855 = load i32, ptr %l29, !tbaa !23
  %t856 = load i32, ptr %l28, !tbaa !23
  %t859 = sub i32 %t855, %t856
  %t860 = load i32, ptr %l30, !tbaa !23
  %t863 = add i32 %t859, %t860
  %t865 = sub i32 %t863, 1
  %t866 = load i32, ptr %l30, !tbaa !23
  %t869 = sdiv i32 %t865, %t866
  store i32 %t869, ptr %l361, !tbaa !23
  br label %bb200
bb199:
  store i32 0, ptr %l361, !tbaa !23
  br label %bb200
bb200:
  %t871 = load i32, ptr %l361, !tbaa !23
  store i32 %t871, ptr %l358, !tbaa !23
  br label %bb201
bb201:
  %t872 = load i32, ptr %l358, !tbaa !23
  store i32 %t872, ptr %l31, !tbaa !23
  store i32 0, ptr %l32, !tbaa !23
  br label %bb202
bb202:
  store %olang.scope zeroinitializer, ptr %s37
  %t873 = load i32, ptr %l32, !tbaa !23
  %t874 = load i32, ptr %l31, !tbaa !23
  %t877 = icmp slt i32 %t873, %t874
  %t879 = xor i1 %t877, true
  br i1 %t879, label %bb203, label %bb204
bb203:
  call void @__olang_scope_close(ptr %s37)
  br label %bb210
bb204:
  br label %bb205
bb205:
  %t881 = load i32, ptr %l28, !tbaa !23
  %t882 = load i32, ptr %l32, !tbaa !23
  %t883 = load i32, ptr %l30, !tbaa !23
  %t886 = mul i32 %t882, %t883
  %t889 = add i32 %t881, %t886
  store i32 %t889, ptr %l33, !tbaa !23
  %t891 = load ptr, ptr %l0, !tbaa !29
  store ptr %t891, ptr %l379, !tbaa !29
  %t892 = load i32, ptr %l33, !tbaa !23
  %t894 = sext i32 %t892 to i64
  %t895 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t896 = load ptr, ptr %t895, !tbaa !27
  %t897 = getelementptr i32, ptr %t896, i64 %t894
  %t898 = load i32, ptr %t897, !tbaa !33
  store i32 %t898, ptr %l381, !tbaa !23
  %t899 = load ptr, ptr %l0, !tbaa !29
  store ptr %t899, ptr %l382, !tbaa !29
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t902 = getelementptr %"compiler/mir:verifier", ptr %t900, i32 0, i32 0
  %t903 = load ptr, ptr %t902, !tbaa !29
  %t905 = getelementptr %"compiler/mir:Fn", ptr %t903, i32 0, i32 13
  %t906 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 3
  %t907 = getelementptr %"compiler/mir:Range", ptr %t906, i32 0, i32 0
  %t908 = load i32, ptr %t907, !tbaa !23
  %t910 = sext i32 %t908 to i64
  %t911 = load i32, ptr %l33, !tbaa !23
  %t913 = sext i32 %t911 to i64
  %t916 = add i64 %t910, %t913
  %t919 = call %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %t905, i64 %t916)
  store %"compiler/mir:Place" %t919, ptr %l391
  br label %bb206
bb206:
  %t920 = load ptr, ptr %l382, !tbaa !29
  %t921 = load %"compiler/mir:Place", ptr %l391
  %t922 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t920, %"compiler/mir:Place" %t921)
  store i32 %t922, ptr %l392
  br label %bb207
bb207:
  %t923 = load i32, ptr %l33, !tbaa !23
  %t924 = extractvalue { i64, ptr } { i64 16, ptr @.d188 }, 1
  %t925 = extractvalue { i64, ptr } { i64 16, ptr @.d188 }, 0
  %t927 = sext i32 %t923 to i64
  %t928 = call i64 @__olang_fmt_i64(ptr null, i64 %t927)
  %t929 = add i64 %t925, %t928
  %t930 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t929)
  call void @olang_textcopy(ptr %t930, ptr %t924, i64 %t925)
  %t931 = getelementptr i8, ptr %t930, i64 %t925
  %t932 = call i64 @__olang_fmt_i64(ptr %t931, i64 %t927)
  %t933 = insertvalue { i64, ptr } undef, i64 %t929, 0
  %t934 = insertvalue { i64, ptr } %t933, ptr %t930, 1
  %t936 = extractvalue { i64, ptr } %t934, 0
  %t937 = extractvalue { i64, ptr } %t934, 1
  %t938 = mul i64 %t936, 1
  %t939 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t938)
  call void @llvm.memcpy.p0.p0.i64(ptr %t939, ptr %t937, i64 %t938, i1 false)
  %t940 = insertvalue { i64, ptr } undef, i64 %t936, 0
  %t941 = insertvalue { i64, ptr } %t940, ptr %t939, 1
  %t942 = load ptr, ptr %l379, !tbaa !29
  %t943 = load i32, ptr %l381, !tbaa !23
  %t944 = load i32, ptr %l392, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s37, ptr %t942, i32 %t943, i32 %t944, { i64, ptr } %t941)
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s37)
  br label %bb209
bb209:
  %t946 = load i32, ptr %l32, !tbaa !23
  %t948 = add i32 %t946, 1
  store i32 %t948, ptr %l32, !tbaa !23
  br label %bb202
bb210:
  br label %bb211
bb211:
  %t950 = getelementptr %"compiler/mir:Task", ptr %l25, i32 0, i32 4
  %t951 = getelementptr %"compiler/mir:Range", ptr %t950, i32 0, i32 1
  %t952 = load i32, ptr %t951, !tbaa !23
  %t954 = icmp sgt i32 %t952, 0
  br i1 %t954, label %bb212, label %bb213
bb212:
  %t956 = load ptr, ptr %l2, !tbaa !29
  store ptr %t956, ptr %l401, !tbaa !29
  %t957 = load ptr, ptr %l2, !tbaa !29
  %t958 = load i32, ptr %l26, !tbaa !23
  %t961 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t957, i32 %t958)
  store i32 %t961, ptr %l404
  br label %bb214
bb213:
  store i1 false, ptr %l400, !tbaa !21
  br label %bb216
bb214:
  %t962 = load ptr, ptr %l401, !tbaa !29
  %t963 = load i32, ptr %l404, !tbaa !23
  %t964 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t962, i32 %t963)
  store { i64, ptr } %t964, ptr %l405
  br label %bb215
bb215:
  %t965 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t966 = extractvalue { i64, ptr } %t965, 0
  %t968 = icmp eq i64 %t966, 0
  store i1 %t968, ptr %l400, !tbaa !21
  br label %bb216
bb216:
  %t970 = load i1, ptr %l400, !tbaa !21
  br i1 %t970, label %bb217, label %bb218
bb217:
  store %olang.scope zeroinitializer, ptr %s40
  %t971 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s40, ptr %t971, { i64, ptr } { i64 44, ptr @.d189 })
  br label %bb219
bb218:
  br label %bb220
bb219:
  call void @__olang_scope_close(ptr %s40)
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s32)
  br label %bb221
bb221:
  br label %bb227
bb222:
  br i1 true, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22)
  unreachable
bb227:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l41 = alloca %"compiler/mir:Call"
  %l45 = alloca { i64, ptr }
  %l50 = alloca %"compiler/mir:Call"
  %l52 = alloca { i64, ptr }
  %l57 = alloca %"compiler/mir:Call"
  %l58 = alloca i32
  %l63 = alloca %"compiler/mir:Call"
  %l65 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [7 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [7 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = mul i64 1, 4
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  store i32 %t15, ptr %t23, !tbaa !33
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  br label %bb36
bb4:
  %t25 = load { i64, [7 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [7 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l4, !tbaa !23
  %t34 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t38 = load i32, ptr %l4, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = mul i64 2, 4
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 2, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i32, ptr %t46, i64 0
  store i32 %t38, ptr %t47, !tbaa !33
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 1
  store i32 %t39, ptr %t51, !tbaa !33
  %t52 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t52, ptr %l13, !tbaa !27
  br label %bb36
bb8:
  %t53 = load { i64, [7 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [7 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb9, label %bb10
bb9:
  %t58 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 1
  %t60 = load %"compiler/mir:Range", ptr %t59
  store %"compiler/mir:Range" %t60, ptr %l6
  %t62 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 2
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Range", ptr %l6
  %t68 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %t66, %"compiler/mir:Range" %t67, i32 %t68)
  store { i64, ptr } %t72, ptr %l33
  br label %bb12
bb12:
  %t73 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t73, ptr %l13, !tbaa !27
  br label %bb36
bb13:
  %t74 = load { i64, [7 x i64] }, ptr %l1
  %t76 = extractvalue { i64, [7 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 4
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l8, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 14
  %t86 = load i32, ptr %l8, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t85, i64 %t88)
  store %"compiler/mir:Call" %t91, ptr %l41
  br label %bb17
bb17:
  %t92 = getelementptr %"compiler/mir:Call", ptr %l41, i32 0, i32 7
  %t93 = load i32, ptr %t92, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t97 = icmp eq i32 %t93, %t94
  br i1 %t97, label %bb18, label %bb19
bb18:
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/mir:Fn", ptr %t99, i32 0, i32 14
  %t102 = load i32, ptr %l8, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t101, i64 %t104)
  store %"compiler/mir:Call" %t107, ptr %l50
  br label %bb20
bb19:
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 14
  %t111 = load i32, ptr %l8, !tbaa !23
  %t113 = sext i32 %t111 to i64
  %t116 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t110, i64 %t113)
  store %"compiler/mir:Call" %t116, ptr %l57
  br label %bb21
bb20:
  %t117 = getelementptr %"compiler/mir:Call", ptr %l50, i32 0, i32 5
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = mul i64 1, 4
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 1, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l52, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  store i32 %t118, ptr %t126, !tbaa !33
  %t127 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t127, ptr %l45, !tbaa !27
  br label %bb23
bb21:
  %t128 = getelementptr %"compiler/mir:Call", ptr %l57, i32 0, i32 5
  %t129 = load i32, ptr %t128, !tbaa !23
  store i32 %t129, ptr %l58, !tbaa !23
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/mir:Fn", ptr %t130, i32 0, i32 14
  %t133 = load i32, ptr %l8, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t132, i64 %t135)
  store %"compiler/mir:Call" %t138, ptr %l63
  br label %bb22
bb22:
  %t139 = getelementptr %"compiler/mir:Call", ptr %l63, i32 0, i32 7
  %t140 = load i32, ptr %t139, !tbaa !23
  %t141 = mul i64 2, 4
  %t142 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 2, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l65, !tbaa !27
  %t145 = load i32, ptr %l58, !tbaa !23
  %t146 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 0
  store i32 %t145, ptr %t148, !tbaa !33
  %t150 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 1
  store i32 %t140, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t153, ptr %l45, !tbaa !27
  br label %bb23
bb23:
  %t154 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t154, ptr %l13, !tbaa !27
  br label %bb36
bb24:
  %t155 = load { i64, [7 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [7 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 7
  br i1 %t158, label %bb25, label %bb26
bb25:
  %t160 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l9, !tbaa !23
  %t164 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t164, i32 0, i32 4
  %t166 = load i32, ptr %t165
  store i32 %t166, ptr %l10, !tbaa !23
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t168 = load i32, ptr %l10, !tbaa !23
  %t169 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t172 = icmp eq i32 %t168, %t169
  br i1 %t172, label %bb28, label %bb29
bb28:
  %t174 = load i32, ptr %l9, !tbaa !23
  %t175 = mul i64 1, 4
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 1, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l75, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 0
  store i32 %t174, ptr %t182, !tbaa !33
  %t183 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t183, ptr %l73, !tbaa !27
  br label %bb30
bb29:
  %t184 = load i32, ptr %l9, !tbaa !23
  %t185 = load i32, ptr %l10, !tbaa !23
  %t186 = mul i64 2, 4
  %t187 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 2, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l78, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 0
  store i32 %t184, ptr %t193, !tbaa !33
  %t195 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 1
  store i32 %t185, ptr %t197, !tbaa !33
  %t198 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t198, ptr %l73, !tbaa !27
  br label %bb30
bb30:
  %t199 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t199, ptr %l13, !tbaa !27
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t200 = mul i64 0, 4
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 0, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l13, !tbaa !27
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7)
  unreachable
bb36:
  %t205 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t205, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i32 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i32
  %l41 = alloca i32
  %l50 = alloca %"compiler/mir:Case"
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sle i64 %t10, 2305843009213693951
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = mul i64 %t13, 4
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t18, ptr %lp3
  %t20 = load ptr, ptr %lp3
  store { i64, ptr } %t17, ptr %t20, !tbaa !27
  store i32 0, ptr %l4, !tbaa !23
  %t21 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = icmp sgt i32 %t24, %t25
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb5:
  %t30 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t30, 0
  br i1 %t32, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l20, !tbaa !23
  br label %bb10
bb7:
  %t34 = load i32, ptr %l5, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = sub i32 %t34, %t35
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = add i32 %t38, %t39
  %t44 = sub i32 %t42, 1
  %t45 = load i32, ptr %l6, !tbaa !23
  %t48 = sdiv i32 %t44, %t45
  store i32 %t48, ptr %l23, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb9
bb9:
  %t50 = load i32, ptr %l23, !tbaa !23
  store i32 %t50, ptr %l20, !tbaa !23
  br label %bb10
bb10:
  %t51 = load i32, ptr %l20, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i32, ptr %l8, !tbaa !23
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = icmp slt i32 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t60 = load i32, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l8, !tbaa !23
  %t62 = load i32, ptr %l6, !tbaa !23
  %t65 = mul i32 %t61, %t62
  %t68 = add i32 %t60, %t65
  store i32 %t68, ptr %l9, !tbaa !23
  %t70 = load i32, ptr %l9, !tbaa !23
  store i32 %t70, ptr %l41, !tbaa !23
  %t73 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/mir:Fn", ptr %t74, i32 0, i32 15
  %t77 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load i32, ptr %l9, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = add i64 %t80, %t83
  %t89 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t76, i64 %t86)
  store %"compiler/mir:Case" %t89, ptr %l50
  br label %bb15
bb15:
  %t90 = getelementptr %"compiler/mir:Case", ptr %l50, i32 0, i32 1
  %t91 = load i32, ptr %t90, !tbaa !23
  %t93 = load ptr, ptr %lp3
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = sext i32 %t94 to i64
  %t96 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t95
  store i32 %t91, ptr %t98, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t99 = load i32, ptr %l8, !tbaa !23
  %t101 = add i32 %t99, 1
  store i32 %t101, ptr %l8, !tbaa !23
  br label %bb11
bb17:
  %t103 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t104 = load i32, ptr %t103, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t109 = load ptr, ptr %lp3
  %t111 = getelementptr { i64, ptr }, ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t106
  store i32 %a2, ptr %t113, !tbaa !33
  %t114 = load ptr, ptr %lp3
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:verifier", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l9
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb8
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/mir:verifier", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t19, i32 %t20)
  store i64 %t23, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb6:
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  %t27 = and i64 %t25, %t24
  %t29 = icmp ne i64 %t27, 0
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l10, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l5, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l5, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l22
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t41 = extractvalue { i64, ptr } { i64 12, ptr @.d190 }, 1
  %t42 = extractvalue { i64, ptr } { i64 12, ptr @.d190 }, 0
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 22, ptr @.d191 }, 1
  %t48 = extractvalue { i64, ptr } { i64 22, ptr @.d191 }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = getelementptr i8, ptr %t51, i64 %t45
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t62 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t62, { i64, ptr } %t61)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t64 = load i32, ptr %l1, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l23 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca %"compiler/mir:Range"
  %l49 = alloca i64
  %l50 = alloca i1
  %l53 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i64
  %l65 = alloca i64
  %l90 = alloca i1
  %l93 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 13, ptr @.d192 })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb62
bb5:
  %t8 = load { i64, [7 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [7 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t13 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l23
  br label %bb9
bb9:
  br label %bb62
bb10:
  %t22 = load { i64, [7 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [7 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [4 x i64] } %t29, ptr %l3
  %t31 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t39, { i64, [4 x i64] } %t40)
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l33
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l36
  br label %bb16
bb16:
  br label %bb62
bb17:
  %t53 = load { i64, [7 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [7 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 0
  %t60 = load { i64, [4 x i64] }, ptr %t59
  store { i64, [4 x i64] } %t60, ptr %l6
  %t62 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 1
  %t64 = load %"compiler/mir:Range", ptr %t63
  store %"compiler/mir:Range" %t64, ptr %l7
  %t66 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l8, !tbaa !23
  br label %bb20
bb19:
  br label %bb25
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t70, { i64, [4 x i64] } %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l44, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l7
  store %"compiler/mir:Range" %t75, ptr %l45
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 15
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l49
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load %"compiler/mir:Range", ptr %l45
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s4, ptr %t84, %"compiler/mir:Range" %t85, i64 %t86, { i64, ptr } { i64 5, ptr @.d193 })
  store i1 %t87, ptr %l50
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l53
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb25:
  %t93 = load { i64, [7 x i64] }, ptr %l1
  %t95 = extractvalue { i64, [7 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 4
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t98 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32 }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l9, !tbaa !23
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t102 = load i32, ptr %l9, !tbaa !23
  %t104 = icmp slt i32 %t102, 0
  br i1 %t104, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb32
bb30:
  %t106 = load i32, ptr %l9, !tbaa !23
  %t108 = sext i32 %t106 to i64
  store i64 %t108, ptr %l61, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/mir:verifier", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/mir:Fn", ptr %t112, i32 0, i32 14
  %t116 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l65
  br label %bb31
bb31:
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = load i64, ptr %l65, !tbaa !24
  %t119 = icmp sge i64 %t117, %t118
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t121 = load i1, ptr %l59, !tbaa !21
  br i1 %t121, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l9, !tbaa !23
  %t124 = extractvalue { i64, ptr } { i64 8, ptr @.d194 }, 1
  %t125 = extractvalue { i64, ptr } { i64 8, ptr @.d194 }, 0
  %t127 = sext i32 %t123 to i64
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t125, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t124, i64 %t125)
  %t131 = getelementptr i8, ptr %t130, i64 %t125
  %t132 = call i64 @__olang_fmt_i64(ptr %t131, i64 %t127)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t130, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } %t134, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t122, { i64, ptr } %t141)
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  br label %bb62
bb37:
  %t144 = load { i64, [7 x i64] }, ptr %l1
  %t146 = extractvalue { i64, [7 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 5
  br i1 %t147, label %bb38, label %bb39
bb38:
  %t149 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t149, i32 0, i32 1
  %t151 = load { i64, [4 x i64] }, ptr %t150
  store { i64, [4 x i64] } %t151, ptr %l10
  br label %bb44
bb39:
  %t153 = load { i64, [7 x i64] }, ptr %l1
  %t155 = extractvalue { i64, [7 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 6
  br i1 %t156, label %bb40, label %bb41
bb40:
  %t158 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t158, i32 0, i32 1
  %t160 = load { i64, [4 x i64] }, ptr %t159
  store { i64, [4 x i64] } %t160, ptr %l10
  br label %bb44
bb41:
  %t162 = load { i64, [7 x i64] }, ptr %l1
  %t164 = extractvalue { i64, [7 x i64] } %t162, 0
  %t165 = icmp eq i64 %t164, 8
  br i1 %t165, label %bb42, label %bb43
bb42:
  %t167 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t167, i32 0, i32 2
  %t169 = load { i64, [4 x i64] }, ptr %t168
  store { i64, [4 x i64] } %t169, ptr %l10
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load { i64, [4 x i64] }, ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t171, { i64, [4 x i64] } %t172)
  br label %bb45
bb45:
  br label %bb62
bb46:
  %t175 = load { i64, [7 x i64] }, ptr %l1
  %t177 = extractvalue { i64, [7 x i64] } %t175, 0
  %t178 = icmp eq i64 %t177, 7
  br i1 %t178, label %bb47, label %bb48
bb47:
  %t180 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l11, !tbaa !23
  %t184 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t184, i32 0, i32 2
  %t186 = load i32, ptr %t185
  store i32 %t186, ptr %l12, !tbaa !23
  %t188 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t188, i32 0, i32 3
  %t190 = load i32, ptr %t189
  store i32 %t190, ptr %l13, !tbaa !23
  %t192 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t192, i32 0, i32 4
  %t194 = load i32, ptr %t193
  store i32 %t194, ptr %l14, !tbaa !23
  br label %bb49
bb48:
  br label %bb57
bb49:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l11, !tbaa !23
  %t200 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t200, ptr %l90
  br label %bb50
bb50:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l12, !tbaa !23
  %t205 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t201, i32 %t202)
  store i1 %t205, ptr %l93
  br label %bb51
bb51:
  %t206 = load i32, ptr %l14, !tbaa !23
  %t207 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t210 = icmp ne i32 %t206, %t207
  br i1 %t210, label %bb52, label %bb53
bb52:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l14, !tbaa !23
  %t216 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t212, i32 %t213)
  store i1 %t216, ptr %l99
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l13, !tbaa !23
  %t221 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l102
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb62
bb57:
  %t222 = load { i64, [7 x i64] }, ptr %l1
  %t224 = extractvalue { i64, [7 x i64] } %t222, 0
  %t225 = icmp eq i64 %t224, 9
  br i1 %t225, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_4fdb0c87eb50ced7_f9856407ece22343)
  unreachable
bb62:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca %"compiler/mir:Call"
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"compiler/mir:ScopeInfo"
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca { i64, [4 x i64] }
  %l45 = alloca i32
  %l48 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l63 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l80 = alloca i32
  %l83 = alloca i32
  %l105 = alloca i32
  %l108 = alloca i32
  %l133 = alloca %"compiler/mir:Case"
  %l134 = alloca i64
  %l142 = alloca %"compiler/mir:Case"
  %l145 = alloca ptr
  %l153 = alloca %"compiler/mir:Case"
  %l168 = alloca %"compiler/mir:Call"
  %l171 = alloca i32
  %l182 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca i32
  %l192 = alloca i32
  %l193 = alloca ptr
  %l196 = alloca i32
  %l197 = alloca { i64, ptr }
  %l201 = alloca i1
  %l208 = alloca i1
  %l216 = alloca ptr
  %l219 = alloca i32
  %l221 = alloca i32
  %l228 = alloca i32
  %l234 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l247 = alloca i32
  %l252 = alloca ptr
  %l256 = alloca i32
  %l257 = alloca { i64, ptr }
  %l261 = alloca ptr
  %l264 = alloca i32
  %l266 = alloca i32
  %l276 = alloca %"compiler/mir:ScopeInfo"
  %l286 = alloca { i64, ptr }
  %l290 = alloca i1
  %l297 = alloca i1
  %l305 = alloca ptr
  %l308 = alloca i32
  %l310 = alloca i32
  %l321 = alloca i1
  %l325 = alloca i1
  %l329 = alloca i1
  %l333 = alloca ptr
  %l334 = alloca i32
  %l336 = alloca { i64, ptr }
  %l338 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l344 = alloca i32
  %l345 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.builder
  %s41room = alloca [64 x i8], align 8
  %s43 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load { i64, [7 x i64] }, ptr %l1
  %t13 = extractvalue { i64, [7 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 2
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t17 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t18, ptr %l4
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t20, { i64, [4 x i64] } %t21)
  store i32 %t24, ptr %l45
  br label %bb4
bb4:
  %t25 = load i32, ptr %l45, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l48
  br label %bb5
bb5:
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t32 = load i32, ptr %l48, !tbaa !23
  %t34 = icmp ne i32 %t32, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l51, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l54
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t42 = extractvalue { i64, ptr } { i64 14, ptr @.d195 }, 1
  %t43 = extractvalue { i64, ptr } { i64 14, ptr @.d195 }, 0
  %t44 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t59, { i64, ptr } %t58)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb188
bb11:
  %t61 = load { i64, [7 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [7 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 3
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l6
  %t70 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t70, i32 0, i32 1
  %t72 = load %"compiler/mir:Range", ptr %t71
  store %"compiler/mir:Range" %t72, ptr %l7
  br label %bb14
bb13:
  br label %bb54
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l6
  %t78 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t74, { i64, [4 x i64] } %t75)
  store i32 %t78, ptr %l63
  br label %bb15
bb15:
  %t79 = load i32, ptr %l63, !tbaa !23
  store i32 %t79, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l64, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t82 = load i32, ptr %l8, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l67
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l64, !tbaa !29
  %t87 = load i32, ptr %l67, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l68
  br label %bb17
bb17:
  %t89 = load i1, ptr %l68, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l70, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l73
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t98 = extractvalue { i64, ptr } { i64 14, ptr @.d196 }, 1
  %t99 = extractvalue { i64, ptr } { i64 14, ptr @.d196 }, 0
  %t100 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t115 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t115, { i64, ptr } %t114)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  store i32 0, ptr %l9, !tbaa !23
  %t117 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 1
  %t118 = load i32, ptr %t117, !tbaa !23
  store i32 %t118, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t120 = load i32, ptr %l10, !tbaa !23
  %t121 = load i32, ptr %l9, !tbaa !23
  %t124 = icmp sgt i32 %t120, %t121
  br i1 %t124, label %bb23, label %bb24
bb23:
  %t126 = load i32, ptr %l11, !tbaa !23
  %t128 = icmp sgt i32 %t126, 0
  br i1 %t128, label %bb25, label %bb26
bb24:
  store i32 0, ptr %l80, !tbaa !23
  br label %bb28
bb25:
  %t130 = load i32, ptr %l10, !tbaa !23
  %t131 = load i32, ptr %l9, !tbaa !23
  %t134 = sub i32 %t130, %t131
  %t135 = load i32, ptr %l11, !tbaa !23
  %t138 = add i32 %t134, %t135
  %t140 = sub i32 %t138, 1
  %t141 = load i32, ptr %l11, !tbaa !23
  %t144 = sdiv i32 %t140, %t141
  store i32 %t144, ptr %l83, !tbaa !23
  br label %bb27
bb26:
  store i32 0, ptr %l83, !tbaa !23
  br label %bb27
bb27:
  %t146 = load i32, ptr %l83, !tbaa !23
  store i32 %t146, ptr %l80, !tbaa !23
  br label %bb28
bb28:
  %t147 = load i32, ptr %l80, !tbaa !23
  store i32 %t147, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t148 = load i32, ptr %l13, !tbaa !23
  %t149 = load i32, ptr %l12, !tbaa !23
  %t152 = icmp slt i32 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb31:
  br label %bb32
bb32:
  %t156 = load i32, ptr %l9, !tbaa !23
  %t157 = load i32, ptr %l13, !tbaa !23
  %t158 = load i32, ptr %l11, !tbaa !23
  %t161 = mul i32 %t157, %t158
  %t164 = add i32 %t156, %t161
  store i32 %t164, ptr %l14, !tbaa !23
  store i32 0, ptr %l15, !tbaa !23
  %t166 = load i32, ptr %l14, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  store i32 1, ptr %l17, !tbaa !23
  %t168 = load i32, ptr %l16, !tbaa !23
  %t169 = load i32, ptr %l15, !tbaa !23
  %t172 = icmp sgt i32 %t168, %t169
  br i1 %t172, label %bb33, label %bb34
bb33:
  %t174 = load i32, ptr %l17, !tbaa !23
  %t176 = icmp sgt i32 %t174, 0
  br i1 %t176, label %bb35, label %bb36
bb34:
  store i32 0, ptr %l105, !tbaa !23
  br label %bb38
bb35:
  %t178 = load i32, ptr %l16, !tbaa !23
  %t179 = load i32, ptr %l15, !tbaa !23
  %t182 = sub i32 %t178, %t179
  %t183 = load i32, ptr %l17, !tbaa !23
  %t186 = add i32 %t182, %t183
  %t188 = sub i32 %t186, 1
  %t189 = load i32, ptr %l17, !tbaa !23
  %t192 = sdiv i32 %t188, %t189
  store i32 %t192, ptr %l108, !tbaa !23
  br label %bb37
bb36:
  store i32 0, ptr %l108, !tbaa !23
  br label %bb37
bb37:
  %t194 = load i32, ptr %l108, !tbaa !23
  store i32 %t194, ptr %l105, !tbaa !23
  br label %bb38
bb38:
  %t195 = load i32, ptr %l105, !tbaa !23
  store i32 %t195, ptr %l18, !tbaa !23
  store i32 0, ptr %l19, !tbaa !23
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t196 = load i32, ptr %l19, !tbaa !23
  %t197 = load i32, ptr %l18, !tbaa !23
  %t200 = icmp slt i32 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t204 = load i32, ptr %l15, !tbaa !23
  %t205 = load i32, ptr %l19, !tbaa !23
  %t206 = load i32, ptr %l17, !tbaa !23
  %t209 = mul i32 %t205, %t206
  %t212 = add i32 %t204, %t209
  store i32 %t212, ptr %l20, !tbaa !23
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t216 = getelementptr %"compiler/mir:Fn", ptr %t214, i32 0, i32 15
  %t217 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 0
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  %t221 = load i32, ptr %l14, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t226 = add i64 %t220, %t223
  %t229 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t216, i64 %t226)
  store %"compiler/mir:Case" %t229, ptr %l133
  br label %bb43
bb43:
  %t230 = getelementptr %"compiler/mir:Case", ptr %l133, i32 0, i32 0
  %t231 = load i64, ptr %t230, !tbaa !24
  store i64 %t231, ptr %l134, !tbaa !24
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = getelementptr %"compiler/mir:Fn", ptr %t232, i32 0, i32 15
  %t235 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t239 = load i32, ptr %l20, !tbaa !23
  %t241 = sext i32 %t239 to i64
  %t244 = add i64 %t238, %t241
  %t247 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t234, i64 %t244)
  store %"compiler/mir:Case" %t247, ptr %l142
  br label %bb44
bb44:
  %t248 = getelementptr %"compiler/mir:Case", ptr %l142, i32 0, i32 0
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load i64, ptr %l134, !tbaa !24
  %t252 = icmp eq i64 %t250, %t249
  br i1 %t252, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l145, !tbaa !29
  %t255 = load ptr, ptr %l3, !tbaa !29
  %t257 = getelementptr %"compiler/mir:Fn", ptr %t255, i32 0, i32 15
  %t258 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  %t262 = load i32, ptr %l14, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t267 = add i64 %t261, %t264
  %t270 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t257, i64 %t267)
  store %"compiler/mir:Case" %t270, ptr %l153
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t271 = getelementptr %"compiler/mir:Case", ptr %l153, i32 0, i32 0
  %t272 = load i64, ptr %t271, !tbaa !24
  %t273 = extractvalue { i64, ptr } { i64 24, ptr @.d197 }, 1
  %t274 = extractvalue { i64, ptr } { i64 24, ptr @.d197 }, 0
  %t276 = call i64 @__olang_fmt_i64(ptr null, i64 %t272)
  %t277 = add i64 %t274, %t276
  %t278 = extractvalue { i64, ptr } { i64 6, ptr @.d198 }, 1
  %t279 = extractvalue { i64, ptr } { i64 6, ptr @.d198 }, 0
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t273, i64 %t274)
  %t282 = getelementptr i8, ptr %t281, i64 %t274
  %t283 = call i64 @__olang_fmt_i64(ptr %t282, i64 %t272)
  %t284 = getelementptr i8, ptr %t282, i64 %t276
  call void @olang_textcopy(ptr %t284, ptr %t278, i64 %t279)
  %t285 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t281, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t294 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t294, { i64, ptr } %t293)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb50:
  %t296 = load i32, ptr %l19, !tbaa !23
  %t298 = add i32 %t296, 1
  store i32 %t298, ptr %l19, !tbaa !23
  br label %bb39
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  %t300 = load i32, ptr %l13, !tbaa !23
  %t302 = add i32 %t300, 1
  store i32 %t302, ptr %l13, !tbaa !23
  br label %bb29
bb53:
  br label %bb188
bb54:
  %t304 = load { i64, [7 x i64] }, ptr %l1
  %t306 = extractvalue { i64, [7 x i64] } %t304, 0
  %t307 = icmp eq i64 %t306, 4
  br i1 %t307, label %bb55, label %bb56
bb55:
  %t309 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", i32 }, ptr %t309, i32 0, i32 1
  %t311 = load i32, ptr %t310
  store i32 %t311, ptr %l21, !tbaa !23
  br label %bb57
bb56:
  br label %bb95
bb57:
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/mir:Fn", ptr %t313, i32 0, i32 14
  %t316 = load i32, ptr %l21, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t321 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t315, i64 %t318)
  store %"compiler/mir:Call" %t321, ptr %l168
  br label %bb58
bb58:
  %t322 = load %"compiler/mir:Call", ptr %l168
  store %"compiler/mir:Call" %t322, ptr %l22
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 0
  %t325 = load { i64, [5 x i64] }, ptr %t324
  %t328 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t323, { i64, [5 x i64] } %t325)
  store i32 %t328, ptr %l171
  br label %bb59
bb59:
  %t329 = load i32, ptr %l171, !tbaa !23
  store i32 %t329, ptr %l23, !tbaa !23
  %t330 = load i32, ptr %l23, !tbaa !23
  %t331 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t334 = icmp eq i32 %t330, %t331
  br i1 %t334, label %bb60, label %bb61
bb60:
  br label %ret
bb61:
  br label %bb62
bb62:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 0
  %t338 = load { i64, [5 x i64] }, ptr %t337
  %t339 = load i32, ptr %l23, !tbaa !23
  %t340 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 1
  %t341 = load %"compiler/mir:Range", ptr %t340
  %t342 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 2
  %t343 = load %"compiler/mir:Range", ptr %t342
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t336, { i64, [5 x i64] } %t338, i32 %t339, %"compiler/mir:Range" %t341, %"compiler/mir:Range" %t343)
  br label %bb63
bb63:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l23, !tbaa !23
  %t353 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t349, i32 %t350)
  store i32 %t353, ptr %l182
  br label %bb64
bb64:
  %t354 = load i32, ptr %l182, !tbaa !23
  store i32 %t354, ptr %l24, !tbaa !23
  %t355 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 4
  %t356 = load i1, ptr %t355, !tbaa !21
  br i1 %t356, label %bb65, label %bb66
bb65:
  %t358 = load i32, ptr %l24, !tbaa !23
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t362 = icmp eq i32 %t358, %t359
  br i1 %t362, label %bb67, label %bb68
bb66:
  br label %bb73
bb67:
  store %olang.scope zeroinitializer, ptr %s18
  %t364 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t364, { i64, ptr } { i64 32, ptr @.d199 })
  br label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s19
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l188, !tbaa !29
  %t367 = load i32, ptr %l24, !tbaa !23
  store i32 %t367, ptr %l189, !tbaa !23
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 3
  %t370 = load %"compiler/mir:Place", ptr %t369
  %t373 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t368, %"compiler/mir:Place" %t370)
  store i32 %t373, ptr %l192
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s18)
  br label %bb72
bb70:
  %t374 = load ptr, ptr %l188, !tbaa !29
  %t375 = load i32, ptr %l189, !tbaa !23
  %t376 = load i32, ptr %l192, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s19, ptr %t374, i32 %t375, i32 %t376, { i64, ptr } { i64 17, ptr @.d200 })
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s19)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t377 = load ptr, ptr %l2, !tbaa !29
  store ptr %t377, ptr %l193, !tbaa !29
  %t378 = load ptr, ptr %l2, !tbaa !29
  %t379 = load i32, ptr %l23, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l196
  br label %bb74
bb74:
  %t383 = load ptr, ptr %l193, !tbaa !29
  %t384 = load i32, ptr %l196, !tbaa !23
  %t385 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t383, i32 %t384)
  store { i64, ptr } %t385, ptr %l197
  br label %bb75
bb75:
  %t386 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  %t389 = icmp sgt i64 %t387, 0
  store i1 %t389, ptr %l25, !tbaa !21
  %t391 = load i1, ptr %l25, !tbaa !21
  br i1 %t391, label %bb76, label %bb77
bb76:
  %t393 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 7
  %t394 = load i32, ptr %t393, !tbaa !23
  %t395 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t398 = icmp eq i32 %t394, %t395
  store i1 %t398, ptr %l201, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb78
bb78:
  %t400 = load i1, ptr %l201, !tbaa !21
  br i1 %t400, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s20
  %t401 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t401, { i64, ptr } { i64 39, ptr @.d201 })
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s20)
  br label %bb82
bb82:
  %t403 = load i1, ptr %l25, !tbaa !21
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb83, label %bb84
bb83:
  %t407 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 7
  %t408 = load i32, ptr %t407, !tbaa !23
  %t409 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t412 = icmp ne i32 %t408, %t409
  store i1 %t412, ptr %l208, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb85
bb85:
  %t414 = load i1, ptr %l208, !tbaa !21
  br i1 %t414, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s21
  %t415 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t415, { i64, ptr } { i64 41, ptr @.d202 })
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s21)
  br label %bb89
bb89:
  %t417 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 7
  %t418 = load i32, ptr %t417, !tbaa !23
  %t419 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t422 = icmp ne i32 %t418, %t419
  br i1 %t422, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s22
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l216, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/mir:Call", ptr %l22, i32 0, i32 6
  %t427 = load i32, ptr %t426, !tbaa !23
  %t430 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t425, i32 %t427)
  store i32 %t430, ptr %l219
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t431 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t432 = load ptr, ptr %l216, !tbaa !29
  %t433 = load i32, ptr %l219, !tbaa !23
  %t435 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s22, ptr %t432, i32 %t433, i32 %t431, { i64, ptr } { i64 21, ptr @.d203 })
  store i32 %t435, ptr %l221
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s22)
  br label %bb94
bb94:
  br label %bb188
bb95:
  %t436 = load { i64, [7 x i64] }, ptr %l1
  %t438 = extractvalue { i64, [7 x i64] } %t436, 0
  %t439 = icmp eq i64 %t438, 5
  br i1 %t439, label %bb96, label %bb97
bb96:
  %t441 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t441, i32 0, i32 1
  %t443 = load { i64, [4 x i64] }, ptr %t442
  store { i64, [4 x i64] } %t443, ptr %l26
  br label %bb98
bb97:
  br label %bb114
bb98:
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t446 = load ptr, ptr %l3, !tbaa !29
  %t448 = getelementptr %"compiler/mir:Fn", ptr %t446, i32 0, i32 1
  %t449 = load i32, ptr %t448, !tbaa !23
  %t452 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t445, i32 %t449)
  store i32 %t452, ptr %l228
  br label %bb99
bb99:
  %t453 = load i32, ptr %l228, !tbaa !23
  store i32 %t453, ptr %l27, !tbaa !23
  %t454 = load { i64, [4 x i64] }, ptr %l26
  %t456 = extractvalue { i64, [4 x i64] } %t454, 0
  %t457 = icmp eq i64 %t456, 0
  br i1 %t457, label %bb100, label %bb101
bb100:
  %t459 = load i32, ptr %l27, !tbaa !23
  %t460 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t463 = icmp ne i32 %t459, %t460
  br i1 %t463, label %bb102, label %bb103
bb101:
  %t465 = load i32, ptr %l27, !tbaa !23
  %t466 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t469 = icmp eq i32 %t465, %t466
  br i1 %t469, label %bb107, label %bb108
bb102:
  store %olang.scope zeroinitializer, ptr %s25
  %t471 = load ptr, ptr %l0, !tbaa !29
  store ptr %t471, ptr %l234, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i32, ptr %l27, !tbaa !23
  %t476 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s25, ptr %t472, i32 %t473)
  store { i64, ptr } %t476, ptr %l237
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t477 = extractvalue { i64, ptr } { i64 48, ptr @.d204 }, 1
  %t478 = extractvalue { i64, ptr } { i64 48, ptr @.d204 }, 0
  %t479 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = add i64 %t478, %t481
  %t483 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t482)
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = getelementptr i8, ptr %t483, i64 %t478
  call void @olang_textcopy(ptr %t484, ptr %t480, i64 %t481)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t483, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t494 = load ptr, ptr %l234, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t494, { i64, ptr } %t493)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s25)
  br label %bb106
bb106:
  br label %bb113
bb107:
  store %olang.scope zeroinitializer, ptr %s28
  %t496 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s28, ptr %t496, { i64, ptr } { i64 49, ptr @.d205 })
  br label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s29
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l244, !tbaa !29
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load { i64, [4 x i64] }, ptr %l26
  %t503 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t499, { i64, [4 x i64] } %t500)
  store i32 %t503, ptr %l247
  br label %bb110
bb109:
  call void @__olang_scope_close(ptr %s28)
  br label %bb112
bb110:
  %t504 = load i32, ptr %l27, !tbaa !23
  %t505 = load ptr, ptr %l244, !tbaa !29
  %t506 = load i32, ptr %l247, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s29, ptr %t505, i32 %t506, i32 %t504, { i64, ptr } { i64 18, ptr @.d206 })
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s29)
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb188
bb114:
  %t508 = load { i64, [7 x i64] }, ptr %l1
  %t510 = extractvalue { i64, [7 x i64] } %t508, 0
  %t511 = icmp eq i64 %t510, 6
  br i1 %t511, label %bb115, label %bb116
bb115:
  %t513 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t514 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t513, i32 0, i32 1
  %t515 = load { i64, [4 x i64] }, ptr %t514
  store { i64, [4 x i64] } %t515, ptr %l28
  br label %bb117
bb116:
  br label %bb126
bb117:
  store %olang.scope zeroinitializer, ptr %s30
  %t517 = load ptr, ptr %l2, !tbaa !29
  store ptr %t517, ptr %l252, !tbaa !29
  %t518 = load ptr, ptr %l2, !tbaa !29
  %t519 = load ptr, ptr %l3, !tbaa !29
  %t521 = getelementptr %"compiler/mir:Fn", ptr %t519, i32 0, i32 1
  %t522 = load i32, ptr %t521, !tbaa !23
  %t525 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t518, i32 %t522)
  store i32 %t525, ptr %l256
  br label %bb118
bb118:
  %t526 = load ptr, ptr %l252, !tbaa !29
  %t527 = load i32, ptr %l256, !tbaa !23
  %t528 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t526, i32 %t527)
  store { i64, ptr } %t528, ptr %l257
  br label %bb119
bb119:
  %t529 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t529, 0
  %t532 = icmp eq i64 %t530, 0
  br i1 %t532, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s31
  %t534 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t534, { i64, ptr } { i64 38, ptr @.d207 })
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_scope_close(ptr %s31)
  br label %bb123
bb123:
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l261, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load { i64, [4 x i64] }, ptr %l28
  %t541 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t537, { i64, [4 x i64] } %t538)
  store i32 %t541, ptr %l264
  br label %bb124
bb124:
  %t542 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t543 = load ptr, ptr %l261, !tbaa !29
  %t544 = load i32, ptr %l264, !tbaa !23
  %t546 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s30, ptr %t543, i32 %t544, i32 %t542, { i64, ptr } { i64 16, ptr @.d208 })
  store i32 %t546, ptr %l266
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s30)
  br label %bb188
bb126:
  %t547 = load { i64, [7 x i64] }, ptr %l1
  %t549 = extractvalue { i64, [7 x i64] } %t547, 0
  %t550 = icmp eq i64 %t549, 7
  br i1 %t550, label %bb127, label %bb128
bb127:
  %t552 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t553 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t552, i32 0, i32 1
  %t554 = load i32, ptr %t553
  store i32 %t554, ptr %l29, !tbaa !23
  %t556 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t556, i32 0, i32 3
  %t558 = load i32, ptr %t557
  store i32 %t558, ptr %l30, !tbaa !23
  %t560 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t561 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t560, i32 0, i32 4
  %t562 = load i32, ptr %t561
  store i32 %t562, ptr %l31, !tbaa !23
  br label %bb129
bb128:
  br label %bb155
bb129:
  %t564 = load ptr, ptr %l3, !tbaa !29
  %t566 = getelementptr %"compiler/mir:Fn", ptr %t564, i32 0, i32 8
  %t567 = load i32, ptr %l29, !tbaa !23
  %t569 = sext i32 %t567 to i64
  %t572 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t566, i64 %t569)
  store %"compiler/mir:ScopeInfo" %t572, ptr %l276
  br label %bb130
bb130:
  %t573 = load %"compiler/mir:ScopeInfo", ptr %l276
  store %"compiler/mir:ScopeInfo" %t573, ptr %l32
  %t574 = getelementptr %"compiler/mir:ScopeInfo", ptr %l32, i32 0, i32 0
  %t575 = load i32, ptr %t574
  %t577 = trunc i64 3 to i32
  %t578 = icmp eq i32 %t575, %t577
  %t580 = xor i1 %t578, true
  br i1 %t580, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s33
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load i32, ptr %l29, !tbaa !23
  %t584 = extractvalue { i64, ptr } { i64 12, ptr @.d209 }, 1
  %t585 = extractvalue { i64, ptr } { i64 12, ptr @.d209 }, 0
  %t587 = sext i32 %t583 to i64
  %t588 = call i64 @__olang_fmt_i64(ptr null, i64 %t587)
  %t589 = add i64 %t585, %t588
  %t590 = extractvalue { i64, ptr } { i64 18, ptr @.d210 }, 1
  %t591 = extractvalue { i64, ptr } { i64 18, ptr @.d210 }, 0
  %t592 = add i64 %t589, %t591
  %t593 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t592)
  call void @olang_textcopy(ptr %t593, ptr %t584, i64 %t585)
  %t594 = getelementptr i8, ptr %t593, i64 %t585
  %t595 = call i64 @__olang_fmt_i64(ptr %t594, i64 %t587)
  %t596 = getelementptr i8, ptr %t594, i64 %t588
  call void @olang_textcopy(ptr %t596, ptr %t590, i64 %t591)
  %t597 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t593, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } %t598, 1
  %t602 = mul i64 %t600, 1
  %t603 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t602)
  call void @llvm.memcpy.p0.p0.i64(ptr %t603, ptr %t601, i64 %t602, i1 false)
  %t604 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t603, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t582, { i64, ptr } %t605)
  br label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_scope_close(ptr %s33)
  br label %bb134
bb134:
  %t608 = load ptr, ptr %l2, !tbaa !29
  %t609 = getelementptr %"compiler/mir:ScopeInfo", ptr %l32, i32 0, i32 4
  %t610 = load i32, ptr %t609, !tbaa !23
  %t613 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t608, i32 %t610)
  store { i64, ptr } %t613, ptr %l286
  br label %bb135
bb135:
  %t614 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t615 = extractvalue { i64, ptr } %t614, 0
  %t617 = icmp sgt i64 %t615, 0
  store i1 %t617, ptr %l33, !tbaa !21
  %t619 = load i1, ptr %l33, !tbaa !21
  br i1 %t619, label %bb136, label %bb137
bb136:
  %t621 = load i32, ptr %l31, !tbaa !23
  %t622 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t625 = icmp eq i32 %t621, %t622
  store i1 %t625, ptr %l290, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb138
bb138:
  %t627 = load i1, ptr %l290, !tbaa !21
  br i1 %t627, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s35
  %t628 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s35, ptr %t628, { i64, ptr } { i64 51, ptr @.d211 })
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_scope_close(ptr %s35)
  br label %bb142
bb142:
  %t630 = load i1, ptr %l33, !tbaa !21
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb143, label %bb144
bb143:
  %t634 = load i32, ptr %l31, !tbaa !23
  %t635 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t638 = icmp ne i32 %t634, %t635
  store i1 %t638, ptr %l297, !tbaa !21
  br label %bb145
bb144:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb145
bb145:
  %t640 = load i1, ptr %l297, !tbaa !21
  br i1 %t640, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s36
  %t641 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t641, { i64, ptr } { i64 41, ptr @.d212 })
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_scope_close(ptr %s36)
  br label %bb149
bb149:
  %t643 = load i32, ptr %l31, !tbaa !23
  %t644 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t647 = icmp ne i32 %t643, %t644
  br i1 %t647, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s37
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l305, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load i32, ptr %l30, !tbaa !23
  %t654 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t650, i32 %t651)
  store i32 %t654, ptr %l308
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t655 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t656 = load ptr, ptr %l305, !tbaa !29
  %t657 = load i32, ptr %l308, !tbaa !23
  %t659 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s37, ptr %t656, i32 %t657, i32 %t655, { i64, ptr } { i64 21, ptr @.d213 })
  store i32 %t659, ptr %l310
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s37)
  br label %bb154
bb154:
  br label %bb188
bb155:
  %t660 = load { i64, [7 x i64] }, ptr %l1
  %t662 = extractvalue { i64, [7 x i64] } %t660, 0
  %t663 = icmp eq i64 %t662, 8
  br i1 %t663, label %bb156, label %bb157
bb156:
  %t665 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t665, i32 0, i32 1
  %t667 = load i32, ptr %t666
  store i32 %t667, ptr %l34
  %t669 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t670 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t669, i32 0, i32 2
  %t671 = load { i64, [4 x i64] }, ptr %t670
  store { i64, [4 x i64] } %t671, ptr %l35
  br label %bb158
bb157:
  br label %bb183
bb158:
  %t673 = load { i64, [4 x i64] }, ptr %l35
  %t675 = extractvalue { i64, [4 x i64] } %t673, 0
  %t676 = icmp eq i64 %t675, 0
  %t678 = xor i1 %t676, true
  br i1 %t678, label %bb159, label %bb160
bb159:
  %t680 = load i32, ptr %l34
  %t682 = trunc i64 5 to i32
  %t683 = icmp eq i32 %t680, %t682
  %t685 = xor i1 %t683, true
  br i1 %t685, label %bb161, label %bb162
bb160:
  br label %bb182
bb161:
  %t687 = load i32, ptr %l34
  %t689 = trunc i64 3 to i32
  %t690 = icmp eq i32 %t687, %t689
  %t692 = xor i1 %t690, true
  store i1 %t692, ptr %l321, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb163
bb163:
  %t694 = load i1, ptr %l321, !tbaa !21
  br i1 %t694, label %bb164, label %bb165
bb164:
  %t695 = load i32, ptr %l34
  %t697 = trunc i64 10 to i32
  %t698 = icmp eq i32 %t695, %t697
  %t700 = xor i1 %t698, true
  store i1 %t700, ptr %l325, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb166
bb166:
  %t702 = load i1, ptr %l325, !tbaa !21
  br i1 %t702, label %bb167, label %bb168
bb167:
  %t703 = load i32, ptr %l34
  %t705 = trunc i64 11 to i32
  %t706 = icmp eq i32 %t703, %t705
  %t708 = xor i1 %t706, true
  store i1 %t708, ptr %l329, !tbaa !21
  br label %bb169
bb168:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb169
bb169:
  %t710 = load i1, ptr %l329, !tbaa !21
  br i1 %t710, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s40
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l333, !tbaa !29
  %t712 = load i32, ptr %l34
  store i32 %t712, ptr %l334
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s41
  store ptr %s41room, ptr %s41
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s41, ptr %l334, i64 0)
  br label %bb172
bb171:
  br label %bb175
bb172:
  %t714 = load ptr, ptr %s41
  %t715 = getelementptr %olang.builder, ptr %s41, i32 0, i32 1
  %t716 = load i64, ptr %t715
  %t717 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t716)
  call void @olang_textcopy(ptr %t717, ptr %t714, i64 %t716)
  %t718 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t717, 1
  store { i64, ptr } %t719, ptr %l336, !tbaa !27
  %t720 = getelementptr %olang.builder, ptr %s41, i32 0, i32 3
  %t721 = load ptr, ptr %t720
  %t722 = icmp ne ptr %t721, null
  br i1 %t722, label %sbgrew.723, label %sbdone.724
sbgrew.723:
  call void @__olang_sb_done(ptr %s41)
  br label %sbdone.724
sbdone.724:
  %t725 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t725, 0
  %t727 = extractvalue { i64, ptr } %t725, 1
  %t728 = mul i64 %t726, 1
  %t729 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t728)
  call void @llvm.memcpy.p0.p0.i64(ptr %t729, ptr %t727, i64 %t728, i1 false)
  %t730 = insertvalue { i64, ptr } undef, i64 %t726, 0
  %t731 = insertvalue { i64, ptr } %t730, ptr %t729, 1
  %t733 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s40, { i64, ptr } %t731)
  store { i64, ptr } %t733, ptr %l338
  br label %bb173
bb173:
  %t734 = extractvalue { i64, ptr } { i64 16, ptr @.d214 }, 1
  %t735 = extractvalue { i64, ptr } { i64 16, ptr @.d214 }, 0
  %t736 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t737 = extractvalue { i64, ptr } %t736, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = add i64 %t735, %t738
  %t740 = extractvalue { i64, ptr } { i64 5, ptr @.d215 }, 1
  %t741 = extractvalue { i64, ptr } { i64 5, ptr @.d215 }, 0
  %t742 = add i64 %t739, %t741
  %t743 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t742)
  call void @olang_textcopy(ptr %t743, ptr %t734, i64 %t735)
  %t744 = getelementptr i8, ptr %t743, i64 %t735
  call void @olang_textcopy(ptr %t744, ptr %t737, i64 %t738)
  %t745 = getelementptr i8, ptr %t744, i64 %t738
  call void @olang_textcopy(ptr %t745, ptr %t740, i64 %t741)
  %t746 = insertvalue { i64, ptr } undef, i64 %t742, 0
  %t747 = insertvalue { i64, ptr } %t746, ptr %t743, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t750 = extractvalue { i64, ptr } %t747, 1
  %t751 = mul i64 %t749, 1
  %t752 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t751)
  call void @llvm.memcpy.p0.p0.i64(ptr %t752, ptr %t750, i64 %t751, i1 false)
  %t753 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t752, 1
  %t755 = load ptr, ptr %l333, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s40, ptr %t755, { i64, ptr } %t754)
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s40)
  br label %bb175
bb175:
  %t757 = load ptr, ptr %l0, !tbaa !29
  store ptr %t757, ptr %l341, !tbaa !29
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load { i64, [4 x i64] }, ptr %l35
  %t762 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t758, { i64, [4 x i64] } %t759)
  store i32 %t762, ptr %l344
  br label %bb176
bb176:
  %t763 = load ptr, ptr %l341, !tbaa !29
  %t764 = load i32, ptr %l344, !tbaa !23
  %t765 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t763, i32 %t764)
  store i1 %t765, ptr %l345
  br label %bb177
bb177:
  %t766 = load i1, ptr %l345, !tbaa !21
  %t767 = xor i1 %t766, true
  br i1 %t767, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s43
  %t769 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s43, ptr %t769, { i64, ptr } { i64 35, ptr @.d216 })
  br label %bb180
bb179:
  br label %bb181
bb180:
  call void @__olang_scope_close(ptr %s43)
  br label %bb181
bb181:
  br label %bb182
bb182:
  br label %bb188
bb183:
  br i1 true, label %bb184, label %bb185
bb184:
  br label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  call void @__olang_check_failed(ptr @olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7)
  unreachable
bb188:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t1, { i64, [1 x i64] } %a1)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l12
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = extractvalue { i64, ptr } { i64 11, ptr @.d217 }, 1
  %t20 = extractvalue { i64, ptr } { i64 11, ptr @.d217 }, 0
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t19, i64 %t20)
  %t26 = getelementptr i8, ptr %t25, i64 %t20
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t36, { i64, ptr } %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:BasicBlock"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca %"compiler/mir:BasicBlock"
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca { i64, [21 x i64] }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load i64, ptr %l21, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l28, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:verifier", ptr %t58, i32 0, i32 13
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l47, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i1, ptr %t65, i64 %t62
  %t67 = load i1, ptr %t66, !tbaa !31
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb13:
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = getelementptr %"compiler/mir:verifier", ptr %t71, i32 0, i32 3
  store i64 %t72, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/mir:Fn", ptr %t76, i32 0, i32 9
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/mir:BasicBlock" %t82, ptr %l56
  br label %bb15
bb15:
  %t83 = load %"compiler/mir:BasicBlock", ptr %l56
  store %"compiler/mir:BasicBlock" %t83, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t84 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 0
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l58
  br label %bb16
bb16:
  %t87 = load i64, ptr %l58, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb22
bb19:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l65, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb21
bb21:
  %t114 = load i64, ptr %l65, !tbaa !24
  store i64 %t114, ptr %l62, !tbaa !24
  br label %bb22
bb22:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = getelementptr %"compiler/mir:verifier", ptr %t134, i32 0, i32 4
  store i64 %t135, ptr %t138, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l85, !tbaa !29
  %t140 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 0
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t140, i64 %t141)
  store { i64, [21 x i64] } %t144, ptr %l88
  br label %bb27
bb27:
  %t145 = load { i64, [21 x i64] }, ptr %l88
  %t146 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t145, ptr %t146
  %t147 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %s5, ptr %t147, ptr %t146)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t149 = load i64, ptr %l13, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l13, !tbaa !24
  br label %bb23
bb30:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/mir:verifier", ptr %t153, i32 0, i32 4
  store i64 -1, ptr %t155, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 1
  %t158 = load { i64, [7 x i64] }, ptr %t157
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %t156, { i64, [7 x i64] } %t158)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t161 = load i64, ptr %l6, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l6, !tbaa !24
  br label %bb8
bb33:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/mir:verifier", ptr %t165, i32 0, i32 3
  store i64 -1, ptr %t169, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/mir:verifier", ptr %t170, i32 0, i32 4
  store i64 -1, ptr %t174, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i1, ptr %t10, i64 %t7
  %t12 = load i1, ptr %t11, !tbaa !31
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d218 }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d218 }, 0
  %t21 = sext i32 %t17 to i64
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 44, ptr @.d219 }, 1
  %t25 = extractvalue { i64, ptr } { i64 44, ptr @.d219 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t21)
  %t30 = getelementptr i8, ptr %t28, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t27, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } %t39)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca %"compiler/mir:BasicBlock"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca i64
  %l140 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l168 = alloca i32
  %l176 = alloca %"compiler/mir:BasicBlock"
  %l178 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l205 = alloca ptr
  %l208 = alloca { i64, [21 x i64] }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 8
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l38
  br label %bb2
bb2:
  %t17 = load i64, ptr %l38, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t20 = sext i32 %a1 to i64
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb8
bb5:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l48, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t50 = load i64, ptr %l48, !tbaa !24
  store i64 %t50, ptr %l45, !tbaa !24
  br label %bb8
bb8:
  %t51 = load i64, ptr %l45, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 14
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l67, !tbaa !27
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/mir:verifier", ptr %t75, i32 0, i32 7
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l70, !tbaa !27
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i1, ptr %t90, i64 %t87
  %t92 = load i1, ptr %t91, !tbaa !31
  %t95 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t74
  store i1 %t92, ptr %t97, !tbaa !31
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/mir:verifier", ptr %t98, i32 0, i32 15
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l78, !tbaa !27
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/mir:verifier", ptr %t103, i32 0, i32 8
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l81, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i1, ptr %t118, i64 %t115
  %t120 = load i1, ptr %t119, !tbaa !31
  %t123 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i1, ptr %t124, i64 %t102
  store i1 %t120, ptr %t125, !tbaa !31
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l10, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  store i64 %t130, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb15, label %bb16
bb15:
  %t138 = load i64, ptr %l14, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb20
bb17:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l14, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l97, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb19
bb19:
  %t158 = load i64, ptr %l97, !tbaa !24
  store i64 %t158, ptr %l94, !tbaa !24
  br label %bb20
bb20:
  %t159 = load i64, ptr %l94, !tbaa !24
  store i64 %t159, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t160 = load i64, ptr %l16, !tbaa !24
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l17, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/mir:verifier", ptr %t178, i32 0, i32 16
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l116, !tbaa !27
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/mir:verifier", ptr %t183, i32 0, i32 9
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l119, !tbaa !27
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load i64, ptr %l4, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t192 = load i64, ptr %l17, !tbaa !24
  %t195 = add i64 %t191, %t192
  %t197 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i1, ptr %t198, i64 %t195
  %t200 = load i1, ptr %t199, !tbaa !31
  %t203 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i1, ptr %t204, i64 %t182
  store i1 %t200, ptr %t205, !tbaa !31
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t206 = load i64, ptr %l16, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l16, !tbaa !24
  br label %bb21
bb26:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/mir:verifier", ptr %t210, i32 0, i32 17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t212)
  br label %bb27
bb27:
  store i64 0, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t214, i32 0, i32 11
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l131, !tbaa !27
  %t218 = load i64, ptr %l5, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i64, ptr %t221, i64 %t218
  %t223 = load i64, ptr %t222, !tbaa !34
  store i64 %t223, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l19, !tbaa !24
  %t226 = load i64, ptr %l18, !tbaa !24
  %t229 = icmp sgt i64 %t225, %t226
  br i1 %t229, label %bb28, label %bb29
bb28:
  %t231 = load i64, ptr %l20, !tbaa !24
  %t233 = icmp sgt i64 %t231, 0
  br i1 %t233, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb33
bb30:
  %t235 = load i64, ptr %l19, !tbaa !24
  %t236 = load i64, ptr %l18, !tbaa !24
  %t239 = sub i64 %t235, %t236
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = add i64 %t239, %t240
  %t245 = sub i64 %t243, 1
  %t246 = load i64, ptr %l20, !tbaa !24
  %t249 = sdiv i64 %t245, %t246
  store i64 %t249, ptr %l140, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb32
bb32:
  %t251 = load i64, ptr %l140, !tbaa !24
  store i64 %t251, ptr %l137, !tbaa !24
  br label %bb33
bb33:
  %t252 = load i64, ptr %l137, !tbaa !24
  store i64 %t252, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load i64, ptr %l22, !tbaa !24
  %t254 = load i64, ptr %l21, !tbaa !24
  %t257 = icmp slt i64 %t253, %t254
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t261 = load i64, ptr %l18, !tbaa !24
  %t262 = load i64, ptr %l22, !tbaa !24
  %t263 = load i64, ptr %l20, !tbaa !24
  %t266 = mul i64 %t262, %t263
  %t269 = add i64 %t261, %t266
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t271, i32 0, i32 17
  store ptr %t273, ptr %l159, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/mir:verifier", ptr %t274, i32 0, i32 12
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/mir:verifier", ptr %t277, i32 0, i32 10
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l163, !tbaa !27
  %t281 = load i64, ptr %l5, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i64, ptr %t284, i64 %t281
  %t286 = load i64, ptr %t285, !tbaa !34
  %t290 = add i64 %t286, %t269
  %t293 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t276, i64 %t290)
  store i32 %t293, ptr %l168
  br label %bb38
bb38:
  %t294 = load ptr, ptr %l159, !tbaa !29
  %t295 = load i32, ptr %l168, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t294, i32 %t295)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb40:
  %t296 = load i64, ptr %l22, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l22, !tbaa !24
  br label %bb34
bb41:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i64, ptr %l5, !tbaa !24
  %t304 = getelementptr %"compiler/mir:verifier", ptr %t300, i32 0, i32 3
  store i64 %t301, ptr %t304, !tbaa !24
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = getelementptr %"compiler/mir:Fn", ptr %t305, i32 0, i32 9
  %t308 = load i64, ptr %l5, !tbaa !24
  %t311 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t307, i64 %t308)
  store %"compiler/mir:BasicBlock" %t311, ptr %l176
  br label %bb42
bb42:
  %t312 = load %"compiler/mir:BasicBlock", ptr %l176
  store %"compiler/mir:BasicBlock" %t312, ptr %l24
  store i64 0, ptr %l25, !tbaa !24
  %t313 = getelementptr %"compiler/mir:BasicBlock", ptr %l24, i32 0, i32 0
  %t315 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t313)
  store i64 %t315, ptr %l178
  br label %bb43
bb43:
  %t316 = load i64, ptr %l178, !tbaa !24
  store i64 %t316, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t317 = load i64, ptr %l26, !tbaa !24
  %t318 = load i64, ptr %l25, !tbaa !24
  %t321 = icmp sgt i64 %t317, %t318
  br i1 %t321, label %bb44, label %bb45
bb44:
  %t323 = load i64, ptr %l27, !tbaa !24
  %t325 = icmp sgt i64 %t323, 0
  br i1 %t325, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb49
bb46:
  %t327 = load i64, ptr %l26, !tbaa !24
  %t328 = load i64, ptr %l25, !tbaa !24
  %t331 = sub i64 %t327, %t328
  %t332 = load i64, ptr %l27, !tbaa !24
  %t335 = add i64 %t331, %t332
  %t337 = sub i64 %t335, 1
  %t338 = load i64, ptr %l27, !tbaa !24
  %t341 = sdiv i64 %t337, %t338
  store i64 %t341, ptr %l185, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb48
bb48:
  %t343 = load i64, ptr %l185, !tbaa !24
  store i64 %t343, ptr %l182, !tbaa !24
  br label %bb49
bb49:
  %t344 = load i64, ptr %l182, !tbaa !24
  store i64 %t344, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t345 = load i64, ptr %l29, !tbaa !24
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = icmp slt i64 %t345, %t346
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t353 = load i64, ptr %l25, !tbaa !24
  %t354 = load i64, ptr %l29, !tbaa !24
  %t355 = load i64, ptr %l27, !tbaa !24
  %t358 = mul i64 %t354, %t355
  %t361 = add i64 %t353, %t358
  store i64 %t361, ptr %l30, !tbaa !24
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i64, ptr %l30, !tbaa !24
  %t367 = getelementptr %"compiler/mir:verifier", ptr %t363, i32 0, i32 4
  store i64 %t364, ptr %t367, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l205, !tbaa !29
  %t369 = getelementptr %"compiler/mir:BasicBlock", ptr %l24, i32 0, i32 0
  %t370 = load i64, ptr %l30, !tbaa !24
  %t373 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t369, i64 %t370)
  store { i64, [21 x i64] } %t373, ptr %l208
  br label %bb54
bb54:
  %t374 = load { i64, [21 x i64] }, ptr %l208
  %t375 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t374, ptr %t375
  %t376 = load ptr, ptr %l205, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %s11, ptr %t376, ptr %t375)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb56:
  %t378 = load i64, ptr %l29, !tbaa !24
  %t380 = add i64 %t378, 1
  store i64 %t380, ptr %l29, !tbaa !24
  br label %bb50
bb57:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/mir:verifier", ptr %t382, i32 0, i32 4
  store i64 -1, ptr %t384, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/mir:BasicBlock", ptr %l24, i32 0, i32 1
  %t387 = load { i64, [7 x i64] }, ptr %t386
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %t385, { i64, [7 x i64] } %t387)
  br label %bb58
bb58:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l6 = alloca i1
  %l9 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp slt i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = add i64 %t15, %t19
  %t26 = icmp sgt i64 %t22, %a2
  store i1 %t26, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l9, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = extractvalue { i64, ptr } { i64 11, ptr @.d220 }, 1
  %t32 = extractvalue { i64, ptr } { i64 11, ptr @.d220 }, 0
  %t34 = extractvalue { i64, ptr } %a3, 1
  %t35 = extractvalue { i64, ptr } %a3, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 14, ptr @.d221 }, 1
  %t38 = extractvalue { i64, ptr } { i64 14, ptr @.d221 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %a0, { i64, ptr } %t51)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2edeferFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Fn"
  %l13 = alloca ptr
  %l16 = alloca i32
  %l21 = alloca %"compiler/mir:Local"
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/mir:Place"
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/mir:Place"
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/mir:Place"
  %l71 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/mir:Place"
  %l91 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t11 = alloca %"compiler/mir:Fn", align 8
  %t25 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [4 x i64] }, align 8
  %t56 = alloca { i64, [15 x i64] }, align 8
  %t62 = alloca { i64, [21 x i64] }, align 8
  %t81 = alloca { i64, [21 x i64] }, align 8
  %t102 = alloca { i64, [4 x i64] }, align 8
  %t109 = alloca { i64, [15 x i64] }, align 8
  %t115 = alloca { i64, [21 x i64] }, align 8
  %t133 = alloca { i64, [7 x i64] }, align 8
  %t149 = alloca { i64, [4 x i64] }, align 8
  %t156 = alloca { i64, [15 x i64] }, align 8
  %t162 = alloca { i64, [21 x i64] }, align 8
  %t181 = alloca { i64, [21 x i64] }, align 8
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t209 = alloca { i64, [15 x i64] }, align 8
  %t215 = alloca { i64, [21 x i64] }, align 8
  %t233 = alloca { i64, [21 x i64] }, align 8
  %t248 = alloca { i64, [4 x i64] }, align 8
  %t251 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d222 })
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t6, i32 0, i32 %t7, i32 0, i32 0, i64 0)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t11, ptr %v0, ptr %v1, ptr %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t11, i64 192, i1 false)
  br label %bb3
bb3:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store ptr %t14, ptr %lp2
  %t15 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %l12, i64 192, i1 false)
  %t16 = load ptr, ptr %lp2
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 1, ptr @.d223 })
  store i32 %t22, ptr %l16
  br label %bb4
bb4:
  %t23 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t24 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i32 0, i32 0
  store i64 3, ptr %t26
  %t27 = load { i64, [1 x i64] }, ptr %t25
  %t28 = load i32, ptr %l16, !tbaa !23
  %t33 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t28, %"compiler/source:Span" %t23, i32 %t24, i32 2, { i64, [1 x i64] } %t27)
  store %"compiler/mir:Local" %t33, ptr %l21
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"compiler/mir:Local", ptr %l21
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t34, %"compiler/mir:Local" %t35)
  store i32 %t36, ptr %l22
  br label %bb6
bb6:
  %t37 = load i32, ptr %l22, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %lp2
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb7
bb7:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t42 = load ptr, ptr %lp2
  store ptr %t42, ptr %l25, !tbaa !29
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t44, ptr %l27
  %t45 = load i32, ptr %l3, !tbaa !23
  %t47 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t45)
  store %"compiler/mir:Place" %t47, ptr %l29
  br label %bb8
bb8:
  %t48 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i64 } undef, i32 %t48, 0
  %t53 = insertvalue { i32, i64 } %t52, i64 1, 1
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i64 } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t49
  store { i64, [15 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [15 x i64] }, ptr %t56, i32 0, i32 0
  store i64 0, ptr %t57
  %t59 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t55, 0
  %t60 = getelementptr { i64, [15 x i64] }, ptr %t56, i32 0, i32 1
  store { { i64, [4 x i64] } } %t59, ptr %t60
  %t61 = load { i64, [15 x i64] }, ptr %t56
  store { i64, [21 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l27
  %t65 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t64, 0
  %t66 = load %"compiler/mir:Place", ptr %l29
  %t67 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t65, %"compiler/mir:Place" %t66, 1
  %t69 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t67, { i64, [15 x i64] } %t61, 2
  %t70 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t69, ptr %t70
  %t71 = load { i64, [21 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t71, ptr %t73
  %t74 = load ptr, ptr %l25, !tbaa !29
  %t75 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t74, i32 %t75, ptr %t73)
  br label %bb9
bb9:
  %t77 = load ptr, ptr %lp2
  %t78 = load i32, ptr %l4, !tbaa !23
  %t79 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t80 = load i32, ptr %l5, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [21 x i64] }, ptr %t81, i32 0, i32 0
  store i64 13, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t79, 0
  %t85 = insertvalue { %"compiler/source:Span", i32, i32 } %t84, i32 0, 1
  %t87 = insertvalue { %"compiler/source:Span", i32, i32 } %t85, i32 %t80, 2
  %t88 = getelementptr { i64, [21 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t87, ptr %t88
  %t89 = load { i64, [21 x i64] }, ptr %t81
  %t91 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t89, ptr %t91
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t77, i32 %t78, ptr %t91)
  br label %bb10
bb10:
  %t95 = load ptr, ptr %lp2
  store ptr %t95, ptr %l41, !tbaa !29
  %t96 = load i32, ptr %l5, !tbaa !23
  store i32 %t96, ptr %l42, !tbaa !23
  %t97 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t97, ptr %l43
  %t98 = load i32, ptr %l3, !tbaa !23
  %t100 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t98)
  store %"compiler/mir:Place" %t100, ptr %l45
  br label %bb11
bb11:
  %t101 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 0
  store i64 2, ptr %t103
  %t105 = insertvalue { i32, i64 } undef, i32 %t101, 0
  %t106 = insertvalue { i32, i64 } %t105, i64 2, 1
  %t107 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  store { i32, i64 } %t106, ptr %t107
  %t108 = load { i64, [4 x i64] }, ptr %t102
  store { i64, [15 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t109, i32 0, i32 0
  store i64 0, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t108, 0
  %t113 = getelementptr { i64, [15 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] } } %t112, ptr %t113
  %t114 = load { i64, [15 x i64] }, ptr %t109
  store { i64, [21 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load %"compiler/source:Span", ptr %l43
  %t118 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t117, 0
  %t119 = load %"compiler/mir:Place", ptr %l45
  %t120 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t118, %"compiler/mir:Place" %t119, 1
  %t122 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t120, { i64, [15 x i64] } %t114, 2
  %t123 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t122, ptr %t123
  %t124 = load { i64, [21 x i64] }, ptr %t115
  %t126 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t124, ptr %t126
  %t127 = load ptr, ptr %l41, !tbaa !29
  %t128 = load i32, ptr %l42, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t127, i32 %t128, ptr %t126)
  br label %bb12
bb12:
  %t130 = load ptr, ptr %lp2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t132 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [7 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [7 x i64] }, ptr %t133, i32 0, i32 0
  store i64 9, ptr %t134
  %t136 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t132, 0
  %t137 = getelementptr { i64, [7 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span" } %t136, ptr %t137
  %t138 = load { i64, [7 x i64] }, ptr %t133
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t130, i32 %t131, { i64, [7 x i64] } %t138)
  br label %bb13
bb13:
  %t142 = load ptr, ptr %lp2
  store ptr %t142, ptr %l55, !tbaa !29
  %t143 = load i32, ptr %l4, !tbaa !23
  store i32 %t143, ptr %l56, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t144, ptr %l57
  %t145 = load i32, ptr %l3, !tbaa !23
  %t147 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t145)
  store %"compiler/mir:Place" %t147, ptr %l59
  br label %bb14
bb14:
  %t148 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 0
  store i64 2, ptr %t150
  %t152 = insertvalue { i32, i64 } undef, i32 %t148, 0
  %t153 = insertvalue { i32, i64 } %t152, i64 3, 1
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t149, i32 0, i32 1
  store { i32, i64 } %t153, ptr %t154
  %t155 = load { i64, [4 x i64] }, ptr %t149
  store { i64, [15 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [15 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t159 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t155, 0
  %t160 = getelementptr { i64, [15 x i64] }, ptr %t156, i32 0, i32 1
  store { { i64, [4 x i64] } } %t159, ptr %t160
  %t161 = load { i64, [15 x i64] }, ptr %t156
  store { i64, [21 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [21 x i64] }, ptr %t162, i32 0, i32 0
  store i64 0, ptr %t163
  %t164 = load %"compiler/source:Span", ptr %l57
  %t165 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t164, 0
  %t166 = load %"compiler/mir:Place", ptr %l59
  %t167 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t165, %"compiler/mir:Place" %t166, 1
  %t169 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t167, { i64, [15 x i64] } %t161, 2
  %t170 = getelementptr { i64, [21 x i64] }, ptr %t162, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [21 x i64] }, ptr %t162
  %t173 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t171, ptr %t173
  %t174 = load ptr, ptr %l55, !tbaa !29
  %t175 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t174, i32 %t175, ptr %t173)
  br label %bb15
bb15:
  %t177 = load ptr, ptr %lp2
  %t178 = load i32, ptr %l4, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t180 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 0
  store i64 13, ptr %t182
  %t184 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t179, 0
  %t185 = insertvalue { %"compiler/source:Span", i32, i32 } %t184, i32 0, 1
  %t187 = insertvalue { %"compiler/source:Span", i32, i32 } %t185, i32 %t180, 2
  %t188 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t187, ptr %t188
  %t189 = load { i64, [21 x i64] }, ptr %t181
  %t191 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t189, ptr %t191
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t177, i32 %t178, ptr %t191)
  br label %bb16
bb16:
  %t195 = load ptr, ptr %lp2
  store ptr %t195, ptr %l71, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  store i32 %t196, ptr %l72, !tbaa !23
  %t197 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t197, ptr %l73
  %t198 = load i32, ptr %l3, !tbaa !23
  %t200 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t198)
  store %"compiler/mir:Place" %t200, ptr %l75
  br label %bb17
bb17:
  %t201 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 2, ptr %t203
  %t205 = insertvalue { i32, i64 } undef, i32 %t201, 0
  %t206 = insertvalue { i32, i64 } %t205, i64 2, 1
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { i32, i64 } %t206, ptr %t207
  %t208 = load { i64, [4 x i64] }, ptr %t202
  store { i64, [15 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 0
  store i64 0, ptr %t210
  %t212 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t208, 0
  %t213 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 1
  store { { i64, [4 x i64] } } %t212, ptr %t213
  %t214 = load { i64, [15 x i64] }, ptr %t209
  store { i64, [21 x i64] } zeroinitializer, ptr %t215
  %t216 = getelementptr { i64, [21 x i64] }, ptr %t215, i32 0, i32 0
  store i64 0, ptr %t216
  %t217 = load %"compiler/source:Span", ptr %l73
  %t218 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t217, 0
  %t219 = load %"compiler/mir:Place", ptr %l75
  %t220 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t218, %"compiler/mir:Place" %t219, 1
  %t222 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t220, { i64, [15 x i64] } %t214, 2
  %t223 = getelementptr { i64, [21 x i64] }, ptr %t215, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t222, ptr %t223
  %t224 = load { i64, [21 x i64] }, ptr %t215
  %t226 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t224, ptr %t226
  %t227 = load ptr, ptr %l71, !tbaa !29
  %t228 = load i32, ptr %l72, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t227, i32 %t228, ptr %t226)
  br label %bb18
bb18:
  %t230 = load ptr, ptr %lp2
  %t231 = load i32, ptr %l4, !tbaa !23
  %t232 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t233
  %t234 = getelementptr { i64, [21 x i64] }, ptr %t233, i32 0, i32 0
  store i64 4, ptr %t234
  %t236 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t232, 0
  %t237 = insertvalue { %"compiler/source:Span", i32 } %t236, i32 0, 1
  %t238 = getelementptr { i64, [21 x i64] }, ptr %t233, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t237, ptr %t238
  %t239 = load { i64, [21 x i64] }, ptr %t233
  %t241 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t239, ptr %t241
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t230, i32 %t231, ptr %t241)
  br label %bb19
bb19:
  %t245 = load ptr, ptr %lp2
  %t246 = load i32, ptr %l4, !tbaa !23
  %t247 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [4 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 0
  store i64 0, ptr %t249
  %t250 = load { i64, [4 x i64] }, ptr %t248
  store { i64, [7 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [7 x i64] }, ptr %t251, i32 0, i32 0
  store i64 5, ptr %t252
  %t254 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t247, 0
  %t256 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t254, { i64, [4 x i64] } %t250, 1
  %t257 = getelementptr { i64, [7 x i64] }, ptr %t251, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t256, ptr %t257
  %t258 = load { i64, [7 x i64] }, ptr %t251
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t245, i32 %t246, { i64, [7 x i64] } %t258)
  br label %bb20
bb20:
  %t262 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t262, i64 192, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l91, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eloopFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca %"compiler/mir:Fn"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l47 = alloca %"compiler/mir:Local"
  %l48 = alloca i32
  %l52 = alloca i32
  %l56 = alloca i32
  %l60 = alloca i32
  %l64 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/mir:Place"
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/mir:Place"
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca ptr
  %l100 = alloca %"compiler/mir:Place"
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca %"compiler/mir:Place"
  %l105 = alloca { i64, ptr }
  %l106 = alloca %"compiler/mir:Range"
  %l110 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca %"compiler/mir:Place"
  %l124 = alloca ptr
  %l127 = alloca { i64, [5 x i64] }
  %l128 = alloca ptr
  %l130 = alloca %"compiler/mir:Place"
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/mir:Range"
  %l134 = alloca %"compiler/mir:Range"
  %l136 = alloca %"compiler/mir:Place"
  %l140 = alloca %"compiler/mir:Call"
  %l141 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca %"compiler/source:Span"
  %l151 = alloca %"compiler/mir:Place"
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca ptr
  %l156 = alloca %"compiler/mir:Place"
  %l160 = alloca { i64, ptr }
  %l161 = alloca %"compiler/mir:Range"
  %l180 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/mir:Place"
  %l187 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/mir:Place"
  %l193 = alloca %"compiler/mir:Place"
  %l211 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l215 = alloca %"compiler/mir:Place"
  %l218 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t25 = alloca %"compiler/mir:Fn", align 8
  %t53 = alloca { i64, [1 x i64] }, align 8
  %t131 = alloca { i64, [4 x i64] }, align 8
  %t138 = alloca { i64, [15 x i64] }, align 8
  %t144 = alloca { i64, [21 x i64] }, align 8
  %t160 = alloca { i64, [7 x i64] }, align 8
  %t179 = alloca { i64, [4 x i64] }, align 8
  %t188 = alloca { i64, [4 x i64] }, align 8
  %t209 = alloca { i64, [15 x i64] }, align 8
  %t219 = alloca { i64, [21 x i64] }, align 8
  %t239 = alloca { i64, [4 x i64] }, align 8
  %t247 = alloca { i64, [7 x i64] }, align 8
  %t264 = alloca { i64, [21 x i64] }, align 8
  %t278 = alloca { i64, [1 x i64] }, align 8
  %t284 = alloca { i64, [5 x i64] }, align 8
  %t296 = alloca { i64, [4 x i64] }, align 8
  %t336 = alloca { i64, [7 x i64] }, align 8
  %t358 = alloca { i64, [4 x i64] }, align 8
  %t365 = alloca { i64, [4 x i64] }, align 8
  %t387 = alloca { i64, [15 x i64] }, align 8
  %t397 = alloca { i64, [21 x i64] }, align 8
  %t416 = alloca { i64, [21 x i64] }, align 8
  %t432 = alloca { i64, [7 x i64] }, align 8
  %t444 = alloca { i64, [21 x i64] }, align 8
  %t462 = alloca { i64, [4 x i64] }, align 8
  %t468 = alloca { i64, [7 x i64] }, align 8
  %t488 = alloca { i64, [4 x i64] }, align 8
  %t496 = alloca { i64, [15 x i64] }, align 8
  %t506 = alloca { i64, [21 x i64] }, align 8
  %t525 = alloca { i64, [21 x i64] }, align 8
  %t541 = alloca { i64, [21 x i64] }, align 8
  %t559 = alloca { i64, [4 x i64] }, align 8
  %t565 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d224 })
  store i32 %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load i32, ptr %l19, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i32, ptr %l22, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l23, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l24, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l27
  br label %bb3
bb3:
  %t18 = load i32, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t20, i32 %t21, i32 %t18, i32 %t19, i32 0, i64 0)
  store i32 %t24, ptr %l30
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t25, ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t25, i64 192, i1 false)
  br label %bb5
bb5:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store ptr %t28, ptr %lp3
  %t29 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l31, i64 192, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l35
  br label %bb6
bb6:
  %t36 = load i32, ptr %l1, !tbaa !23
  %t37 = load i32, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l32, !tbaa !29
  %t39 = load i32, ptr %l35, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t38, i32 %t39, i32 %t36, i32 %t37, i32 0, i64 0)
  store i32 %t42, ptr %l38
  br label %bb7
bb7:
  %t43 = load i32, ptr %l38, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  store i32 0, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp3
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t48, { i64, ptr } { i64 1, ptr @.d225 })
  store i32 %t50, ptr %l42
  br label %bb8
bb8:
  %t51 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t52 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i32 0, i32 0
  store i64 3, ptr %t54
  %t55 = load { i64, [1 x i64] }, ptr %t53
  %t56 = load i32, ptr %l42, !tbaa !23
  %t61 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t56, %"compiler/source:Span" %t51, i32 %t52, i32 2, { i64, [1 x i64] } %t55)
  store %"compiler/mir:Local" %t61, ptr %l47
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t63 = load %"compiler/mir:Local", ptr %l47
  %t64 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t62, %"compiler/mir:Local" %t63)
  store i32 %t64, ptr %l48
  br label %bb10
bb10:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %lp3
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t72 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t66, i32 %t67, %"compiler/source:Span" %t68)
  store i32 %t72, ptr %l52
  br label %bb11
bb11:
  %t73 = load i32, ptr %l52, !tbaa !23
  store i32 %t73, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %lp3
  %t75 = load i32, ptr %l1, !tbaa !23
  %t76 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t80 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t74, i32 %t75, %"compiler/source:Span" %t76)
  store i32 %t80, ptr %l56
  br label %bb12
bb12:
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %l8, !tbaa !23
  %t82 = load ptr, ptr %lp3
  %t83 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t88 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t82, i32 %t83, %"compiler/source:Span" %t84)
  store i32 %t88, ptr %l60
  br label %bb13
bb13:
  %t89 = load i32, ptr %l60, !tbaa !23
  store i32 %t89, ptr %l9, !tbaa !23
  %t90 = load ptr, ptr %lp3
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t92 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t96 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t90, i32 %t91, %"compiler/source:Span" %t92)
  store i32 %t96, ptr %l64
  br label %bb14
bb14:
  %t97 = load i32, ptr %l64, !tbaa !23
  store i32 %t97, ptr %l10, !tbaa !23
  %t98 = load ptr, ptr %lp3
  %t99 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t98, i32 2, i32 0, i32 1, %"compiler/source:Span" %t99, i32 0)
  store i32 %t103, ptr %l68
  br label %bb15
bb15:
  %t104 = load i32, ptr %l68, !tbaa !23
  store i32 %t104, ptr %l11, !tbaa !23
  %t105 = load ptr, ptr %lp3
  %t107 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t105)
  store i32 %t107, ptr %l70
  br label %bb16
bb16:
  %t108 = load i32, ptr %l70, !tbaa !23
  store i32 %t108, ptr %l12, !tbaa !23
  %t109 = load ptr, ptr %lp3
  %t111 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t109)
  store i32 %t111, ptr %l72
  br label %bb17
bb17:
  %t112 = load i32, ptr %l72, !tbaa !23
  store i32 %t112, ptr %l13, !tbaa !23
  %t113 = load ptr, ptr %lp3
  %t115 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t113)
  store i32 %t115, ptr %l74
  br label %bb18
bb18:
  %t116 = load i32, ptr %l74, !tbaa !23
  store i32 %t116, ptr %l14, !tbaa !23
  %t117 = load ptr, ptr %lp3
  %t119 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t117)
  store i32 %t119, ptr %l76
  br label %bb19
bb19:
  %t120 = load i32, ptr %l76, !tbaa !23
  store i32 %t120, ptr %l15, !tbaa !23
  %t121 = load ptr, ptr %lp3
  %t123 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t121)
  store i32 %t123, ptr %l78
  br label %bb20
bb20:
  %t124 = load i32, ptr %l78, !tbaa !23
  store i32 %t124, ptr %l16, !tbaa !23
  %t125 = load ptr, ptr %lp3
  store ptr %t125, ptr %l79, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t126, ptr %l80
  %t127 = load i32, ptr %l6, !tbaa !23
  %t129 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t127)
  store %"compiler/mir:Place" %t129, ptr %l82
  br label %bb21
bb21:
  %t130 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 2, ptr %t132
  %t134 = insertvalue { i32, i64 } undef, i32 %t130, 0
  %t135 = insertvalue { i32, i64 } %t134, i64 0, 1
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { i32, i64 } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t131
  store { i64, [15 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [15 x i64] }, ptr %t138, i32 0, i32 0
  store i64 0, ptr %t139
  %t141 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t137, 0
  %t142 = getelementptr { i64, [15 x i64] }, ptr %t138, i32 0, i32 1
  store { { i64, [4 x i64] } } %t141, ptr %t142
  %t143 = load { i64, [15 x i64] }, ptr %t138
  store { i64, [21 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l80
  %t147 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t146, 0
  %t148 = load %"compiler/mir:Place", ptr %l82
  %t149 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t147, %"compiler/mir:Place" %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t149, { i64, [15 x i64] } %t143, 2
  %t152 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t151, ptr %t152
  %t153 = load { i64, [21 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t153, ptr %t155
  %t156 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t156, i32 0, ptr %t155)
  br label %bb22
bb22:
  %t158 = load ptr, ptr %lp3
  %t159 = load i32, ptr %l12, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [7 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t163 = insertvalue { i32 } undef, i32 %t159, 0
  %t164 = getelementptr { i64, [7 x i64] }, ptr %t160, i32 0, i32 1
  store { i32 } %t163, ptr %t164
  %t165 = load { i64, [7 x i64] }, ptr %t160
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t158, i32 0, { i64, [7 x i64] } %t165)
  br label %bb23
bb23:
  %t168 = load ptr, ptr %lp3
  store ptr %t168, ptr %l91, !tbaa !29
  %t169 = load i32, ptr %l12, !tbaa !23
  store i32 %t169, ptr %l92, !tbaa !23
  %t170 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t170, ptr %l93
  %t171 = load i32, ptr %l7, !tbaa !23
  %t173 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t171)
  store %"compiler/mir:Place" %t173, ptr %l95
  br label %bb24
bb24:
  store i32 15, ptr %l96
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t174, ptr %l97, !tbaa !23
  %t175 = load ptr, ptr %lp3
  store ptr %t175, ptr %l98, !tbaa !29
  %t176 = load i32, ptr %l6, !tbaa !23
  %t178 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t176)
  store %"compiler/mir:Place" %t178, ptr %l100
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/mir:Place", ptr %l100
  %t182 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t181, 0
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/mir:Place" } %t182, ptr %t183
  %t184 = load { i64, [4 x i64] }, ptr %t179
  store { i64, [4 x i64] } %t184, ptr %l101
  %t185 = load i32, ptr %l5, !tbaa !23
  %t187 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t185)
  store %"compiler/mir:Place" %t187, ptr %l103
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 0
  store i64 1, ptr %t189
  %t190 = load %"compiler/mir:Place", ptr %l103
  %t191 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t190, 0
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  store { %"compiler/mir:Place" } %t191, ptr %t192
  %t193 = load { i64, [4 x i64] }, ptr %t188
  %t194 = mul i64 2, 40
  %t195 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 2, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l105, !tbaa !27
  %t198 = load { i64, [4 x i64] }, ptr %l101
  %t199 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t200, i64 0
  store { i64, [4 x i64] } %t198, ptr %t201
  %t203 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t204, i64 1
  store { i64, [4 x i64] } %t193, ptr %t205
  %t206 = load ptr, ptr %l98, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t208 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t206, { i64, ptr } %t207)
  store %"compiler/mir:Range" %t208, ptr %l106
  br label %bb27
bb27:
  store { i64, [15 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 0
  store i64 3, ptr %t210
  %t211 = load i32, ptr %l96
  %t212 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t211, 0
  %t213 = load i32, ptr %l97, !tbaa !23
  %t214 = insertvalue { i32, i32, %"compiler/mir:Range" } %t212, i32 %t213, 1
  %t215 = load %"compiler/mir:Range", ptr %l106
  %t216 = insertvalue { i32, i32, %"compiler/mir:Range" } %t214, %"compiler/mir:Range" %t215, 2
  %t217 = getelementptr { i64, [15 x i64] }, ptr %t209, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t216, ptr %t217
  %t218 = load { i64, [15 x i64] }, ptr %t209
  store { i64, [21 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [21 x i64] }, ptr %t219, i32 0, i32 0
  store i64 0, ptr %t220
  %t221 = load %"compiler/source:Span", ptr %l93
  %t222 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t221, 0
  %t223 = load %"compiler/mir:Place", ptr %l95
  %t224 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t222, %"compiler/mir:Place" %t223, 1
  %t226 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t224, { i64, [15 x i64] } %t218, 2
  %t227 = getelementptr { i64, [21 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t226, ptr %t227
  %t228 = load { i64, [21 x i64] }, ptr %t219
  %t230 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t228, ptr %t230
  %t231 = load ptr, ptr %l91, !tbaa !29
  %t232 = load i32, ptr %l92, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t231, i32 %t232, ptr %t230)
  br label %bb28
bb28:
  %t234 = load ptr, ptr %lp3
  store ptr %t234, ptr %l110, !tbaa !29
  %t235 = load i32, ptr %l12, !tbaa !23
  store i32 %t235, ptr %l111, !tbaa !23
  %t236 = load i32, ptr %l7, !tbaa !23
  %t238 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t236)
  store %"compiler/mir:Place" %t238, ptr %l113
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 0
  store i64 1, ptr %t240
  %t241 = load %"compiler/mir:Place", ptr %l113
  %t242 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t241, 0
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/mir:Place" } %t242, ptr %t243
  %t244 = load { i64, [4 x i64] }, ptr %t239
  %t245 = load i32, ptr %l13, !tbaa !23
  %t246 = load i32, ptr %l15, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [7 x i64] }, ptr %t247, i32 0, i32 0
  store i64 2, ptr %t248
  %t250 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t244, 0
  %t252 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t250, i32 %t245, 1
  %t254 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t252, i32 %t246, 2
  %t255 = getelementptr { i64, [7 x i64] }, ptr %t247, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t254, ptr %t255
  %t256 = load { i64, [7 x i64] }, ptr %t247
  %t257 = load ptr, ptr %l110, !tbaa !29
  %t258 = load i32, ptr %l111, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t257, i32 %t258, { i64, [7 x i64] } %t256)
  br label %bb30
bb30:
  %t260 = load ptr, ptr %lp3
  %t261 = load i32, ptr %l13, !tbaa !23
  %t262 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t263 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t264
  %t265 = getelementptr { i64, [21 x i64] }, ptr %t264, i32 0, i32 0
  store i64 3, ptr %t265
  %t267 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t262, 0
  %t269 = insertvalue { %"compiler/source:Span", i32 } %t267, i32 %t263, 1
  %t270 = getelementptr { i64, [21 x i64] }, ptr %t264, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t269, ptr %t270
  %t271 = load { i64, [21 x i64] }, ptr %t264
  %t273 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t271, ptr %t273
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t260, i32 %t261, ptr %t273)
  br label %bb31
bb31:
  %t277 = load ptr, ptr %lp3
  store ptr %t277, ptr %l124, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [1 x i64] }, ptr %t278, i32 0, i32 0
  store i64 0, ptr %t279
  %t280 = insertvalue { i32 } undef, i32 1, 0
  %t281 = getelementptr { i64, [1 x i64] }, ptr %t278, i32 0, i32 1
  store { i32 } %t280, ptr %t281
  %t282 = load { i64, [1 x i64] }, ptr %t278
  %t283 = load i32, ptr %l4, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t284, i32 0, i32 0
  store i64 0, ptr %t285
  %t287 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t282, 0
  %t289 = insertvalue { { i64, [1 x i64] }, i32 } %t287, i32 %t283, 1
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t284, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t289, ptr %t290
  %t291 = load { i64, [5 x i64] }, ptr %t284
  store { i64, [5 x i64] } %t291, ptr %l127
  %t292 = load ptr, ptr %lp3
  store ptr %t292, ptr %l128, !tbaa !29
  %t293 = load i32, ptr %l6, !tbaa !23
  %t295 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t293)
  store %"compiler/mir:Place" %t295, ptr %l130
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t296
  %t297 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 0
  store i64 1, ptr %t297
  %t298 = load %"compiler/mir:Place", ptr %l130
  %t299 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t298, 0
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 1
  store { %"compiler/mir:Place" } %t299, ptr %t300
  %t301 = load { i64, [4 x i64] }, ptr %t296
  %t302 = mul i64 1, 40
  %t303 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 1, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l132, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i64 0
  store { i64, [4 x i64] } %t301, ptr %t309
  %t310 = load ptr, ptr %l128, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t312 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t310, { i64, ptr } %t311)
  store %"compiler/mir:Range" %t312, ptr %l133
  br label %bb33
bb33:
  %t313 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t313, ptr %l134
  %t314 = load i32, ptr %l8, !tbaa !23
  %t316 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t314)
  store %"compiler/mir:Place" %t316, ptr %l136
  br label %bb34
bb34:
  %t317 = load i32, ptr %l14, !tbaa !23
  %t318 = load i32, ptr %l9, !tbaa !23
  %t319 = load i32, ptr %l16, !tbaa !23
  %t320 = load { i64, [5 x i64] }, ptr %l127
  %t321 = load %"compiler/mir:Range", ptr %l133
  %t322 = load %"compiler/mir:Range", ptr %l134
  %t323 = load %"compiler/mir:Place", ptr %l136
  %t327 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [5 x i64] } %t320, %"compiler/mir:Range" %t321, %"compiler/mir:Range" %t322, %"compiler/mir:Place" %t323, i1 true, i32 %t317, i32 %t318, i32 %t319)
  store %"compiler/mir:Call" %t327, ptr %l140
  br label %bb35
bb35:
  %t328 = load ptr, ptr %l124, !tbaa !29
  %t329 = load %"compiler/mir:Call", ptr %l140
  %t330 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t328, %"compiler/mir:Call" %t329)
  store i32 %t330, ptr %l141
  br label %bb36
bb36:
  %t331 = load i32, ptr %l141, !tbaa !23
  %t332 = load ptr, ptr %lp3
  %t333 = load i32, ptr %l13, !tbaa !23
  %t334 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [7 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [7 x i64] }, ptr %t336, i32 0, i32 0
  store i64 4, ptr %t337
  %t339 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t334, 0
  %t341 = insertvalue { %"compiler/source:Span", i32 } %t339, i32 %t331, 1
  %t342 = getelementptr { i64, [7 x i64] }, ptr %t336, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t341, ptr %t342
  %t343 = load { i64, [7 x i64] }, ptr %t336
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t332, i32 %t333, { i64, [7 x i64] } %t343)
  br label %bb37
bb37:
  %t347 = load ptr, ptr %lp3
  store ptr %t347, ptr %l147, !tbaa !29
  %t348 = load i32, ptr %l14, !tbaa !23
  store i32 %t348, ptr %l148, !tbaa !23
  %t349 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t349, ptr %l149
  %t350 = load i32, ptr %l6, !tbaa !23
  %t352 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t350)
  store %"compiler/mir:Place" %t352, ptr %l151
  br label %bb38
bb38:
  store i32 3, ptr %l152
  %t353 = load i32, ptr %l1, !tbaa !23
  store i32 %t353, ptr %l153, !tbaa !23
  %t354 = load ptr, ptr %lp3
  store ptr %t354, ptr %l154, !tbaa !29
  %t355 = load i32, ptr %l6, !tbaa !23
  %t357 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t355)
  store %"compiler/mir:Place" %t357, ptr %l156
  br label %bb39
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 0
  store i64 1, ptr %t359
  %t360 = load %"compiler/mir:Place", ptr %l156
  %t361 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t360, 0
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/mir:Place" } %t361, ptr %t362
  %t363 = load { i64, [4 x i64] }, ptr %t358
  %t364 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 0
  store i64 2, ptr %t366
  %t368 = insertvalue { i32, i64 } undef, i32 %t364, 0
  %t369 = insertvalue { i32, i64 } %t368, i64 1, 1
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 1
  store { i32, i64 } %t369, ptr %t370
  %t371 = load { i64, [4 x i64] }, ptr %t365
  %t372 = mul i64 2, 40
  %t373 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 2, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l160, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t378, i64 0
  store { i64, [4 x i64] } %t363, ptr %t379
  %t381 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr { i64, [4 x i64] }, ptr %t382, i64 1
  store { i64, [4 x i64] } %t371, ptr %t383
  %t384 = load ptr, ptr %l154, !tbaa !29
  %t385 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t386 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t384, { i64, ptr } %t385)
  store %"compiler/mir:Range" %t386, ptr %l161
  br label %bb40
bb40:
  store { i64, [15 x i64] } zeroinitializer, ptr %t387
  %t388 = getelementptr { i64, [15 x i64] }, ptr %t387, i32 0, i32 0
  store i64 3, ptr %t388
  %t389 = load i32, ptr %l152
  %t390 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t389, 0
  %t391 = load i32, ptr %l153, !tbaa !23
  %t392 = insertvalue { i32, i32, %"compiler/mir:Range" } %t390, i32 %t391, 1
  %t393 = load %"compiler/mir:Range", ptr %l161
  %t394 = insertvalue { i32, i32, %"compiler/mir:Range" } %t392, %"compiler/mir:Range" %t393, 2
  %t395 = getelementptr { i64, [15 x i64] }, ptr %t387, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t394, ptr %t395
  %t396 = load { i64, [15 x i64] }, ptr %t387
  store { i64, [21 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [21 x i64] }, ptr %t397, i32 0, i32 0
  store i64 0, ptr %t398
  %t399 = load %"compiler/source:Span", ptr %l149
  %t400 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t399, 0
  %t401 = load %"compiler/mir:Place", ptr %l151
  %t402 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t400, %"compiler/mir:Place" %t401, 1
  %t404 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t402, { i64, [15 x i64] } %t396, 2
  %t405 = getelementptr { i64, [21 x i64] }, ptr %t397, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t404, ptr %t405
  %t406 = load { i64, [21 x i64] }, ptr %t397
  %t408 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t406, ptr %t408
  %t409 = load ptr, ptr %l147, !tbaa !29
  %t410 = load i32, ptr %l148, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t409, i32 %t410, ptr %t408)
  br label %bb41
bb41:
  %t412 = load ptr, ptr %lp3
  %t413 = load i32, ptr %l14, !tbaa !23
  %t414 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t415 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t416
  %t417 = getelementptr { i64, [21 x i64] }, ptr %t416, i32 0, i32 0
  store i64 4, ptr %t417
  %t419 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t414, 0
  %t421 = insertvalue { %"compiler/source:Span", i32 } %t419, i32 %t415, 1
  %t422 = getelementptr { i64, [21 x i64] }, ptr %t416, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t421, ptr %t422
  %t423 = load { i64, [21 x i64] }, ptr %t416
  %t425 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t423, ptr %t425
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t412, i32 %t413, ptr %t425)
  br label %bb42
bb42:
  %t429 = load ptr, ptr %lp3
  %t430 = load i32, ptr %l14, !tbaa !23
  %t431 = load i32, ptr %l12, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t432
  %t433 = getelementptr { i64, [7 x i64] }, ptr %t432, i32 0, i32 0
  store i64 1, ptr %t433
  %t435 = insertvalue { i32 } undef, i32 %t431, 0
  %t436 = getelementptr { i64, [7 x i64] }, ptr %t432, i32 0, i32 1
  store { i32 } %t435, ptr %t436
  %t437 = load { i64, [7 x i64] }, ptr %t432
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t429, i32 %t430, { i64, [7 x i64] } %t437)
  br label %bb43
bb43:
  %t441 = load ptr, ptr %lp3
  %t442 = load i32, ptr %l15, !tbaa !23
  %t443 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t444
  %t445 = getelementptr { i64, [21 x i64] }, ptr %t444, i32 0, i32 0
  store i64 4, ptr %t445
  %t447 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t443, 0
  %t448 = insertvalue { %"compiler/source:Span", i32 } %t447, i32 0, 1
  %t449 = getelementptr { i64, [21 x i64] }, ptr %t444, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t448, ptr %t449
  %t450 = load { i64, [21 x i64] }, ptr %t444
  %t452 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t450, ptr %t452
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t441, i32 %t442, ptr %t452)
  br label %bb44
bb44:
  %t456 = load ptr, ptr %lp3
  store ptr %t456, ptr %l180, !tbaa !29
  %t457 = load i32, ptr %l15, !tbaa !23
  store i32 %t457, ptr %l181, !tbaa !23
  %t458 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t458, ptr %l182
  %t459 = load i32, ptr %l6, !tbaa !23
  %t461 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t459)
  store %"compiler/mir:Place" %t461, ptr %l184
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 0
  store i64 1, ptr %t463
  %t464 = load %"compiler/mir:Place", ptr %l184
  %t465 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t464, 0
  %t466 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/mir:Place" } %t465, ptr %t466
  %t467 = load { i64, [4 x i64] }, ptr %t462
  store { i64, [7 x i64] } zeroinitializer, ptr %t468
  %t469 = getelementptr { i64, [7 x i64] }, ptr %t468, i32 0, i32 0
  store i64 5, ptr %t469
  %t470 = load %"compiler/source:Span", ptr %l182
  %t471 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t470, 0
  %t473 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t471, { i64, [4 x i64] } %t467, 1
  %t474 = getelementptr { i64, [7 x i64] }, ptr %t468, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t473, ptr %t474
  %t475 = load { i64, [7 x i64] }, ptr %t468
  %t476 = load ptr, ptr %l180, !tbaa !29
  %t477 = load i32, ptr %l181, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t476, i32 %t477, { i64, [7 x i64] } %t475)
  br label %bb46
bb46:
  %t479 = load ptr, ptr %lp3
  store ptr %t479, ptr %l187, !tbaa !29
  %t480 = load i32, ptr %l16, !tbaa !23
  store i32 %t480, ptr %l188, !tbaa !23
  %t481 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t481, ptr %l189
  %t482 = load i32, ptr %l10, !tbaa !23
  %t484 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t482)
  store %"compiler/mir:Place" %t484, ptr %l191
  br label %bb47
bb47:
  %t485 = load i32, ptr %l9, !tbaa !23
  %t487 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t485)
  store %"compiler/mir:Place" %t487, ptr %l193
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t488
  %t489 = getelementptr { i64, [4 x i64] }, ptr %t488, i32 0, i32 0
  store i64 1, ptr %t489
  %t490 = load %"compiler/mir:Place", ptr %l193
  %t491 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t490, 0
  %t492 = getelementptr { i64, [4 x i64] }, ptr %t488, i32 0, i32 1
  store { %"compiler/mir:Place" } %t491, ptr %t492
  %t493 = load { i64, [4 x i64] }, ptr %t488
  %t494 = load i32, ptr %l2, !tbaa !23
  %t495 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t496
  %t497 = getelementptr { i64, [15 x i64] }, ptr %t496, i32 0, i32 0
  store i64 11, ptr %t497
  %t499 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t493, 0
  %t501 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t499, i32 %t494, 1
  %t503 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t501, i32 %t495, 2
  %t504 = getelementptr { i64, [15 x i64] }, ptr %t496, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t503, ptr %t504
  %t505 = load { i64, [15 x i64] }, ptr %t496
  store { i64, [21 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [21 x i64] }, ptr %t506, i32 0, i32 0
  store i64 0, ptr %t507
  %t508 = load %"compiler/source:Span", ptr %l189
  %t509 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t508, 0
  %t510 = load %"compiler/mir:Place", ptr %l191
  %t511 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t509, %"compiler/mir:Place" %t510, 1
  %t513 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t511, { i64, [15 x i64] } %t505, 2
  %t514 = getelementptr { i64, [21 x i64] }, ptr %t506, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t513, ptr %t514
  %t515 = load { i64, [21 x i64] }, ptr %t506
  %t517 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t515, ptr %t517
  %t518 = load ptr, ptr %l187, !tbaa !29
  %t519 = load i32, ptr %l188, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t518, i32 %t519, ptr %t517)
  br label %bb49
bb49:
  %t521 = load ptr, ptr %lp3
  %t522 = load i32, ptr %l16, !tbaa !23
  %t523 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t524 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t525
  %t526 = getelementptr { i64, [21 x i64] }, ptr %t525, i32 0, i32 0
  store i64 4, ptr %t526
  %t528 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t523, 0
  %t530 = insertvalue { %"compiler/source:Span", i32 } %t528, i32 %t524, 1
  %t531 = getelementptr { i64, [21 x i64] }, ptr %t525, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t530, ptr %t531
  %t532 = load { i64, [21 x i64] }, ptr %t525
  %t534 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t532, ptr %t534
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t521, i32 %t522, ptr %t534)
  br label %bb50
bb50:
  %t538 = load ptr, ptr %lp3
  %t539 = load i32, ptr %l16, !tbaa !23
  %t540 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [21 x i64] }, ptr %t541, i32 0, i32 0
  store i64 4, ptr %t542
  %t544 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t540, 0
  %t545 = insertvalue { %"compiler/source:Span", i32 } %t544, i32 0, 1
  %t546 = getelementptr { i64, [21 x i64] }, ptr %t541, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t545, ptr %t546
  %t547 = load { i64, [21 x i64] }, ptr %t541
  %t549 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t547, ptr %t549
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t538, i32 %t539, ptr %t549)
  br label %bb51
bb51:
  %t553 = load ptr, ptr %lp3
  store ptr %t553, ptr %l211, !tbaa !29
  %t554 = load i32, ptr %l16, !tbaa !23
  store i32 %t554, ptr %l212, !tbaa !23
  %t555 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t555, ptr %l213
  %t556 = load i32, ptr %l10, !tbaa !23
  %t558 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t556)
  store %"compiler/mir:Place" %t558, ptr %l215
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [4 x i64] }, ptr %t559, i32 0, i32 0
  store i64 1, ptr %t560
  %t561 = load %"compiler/mir:Place", ptr %l215
  %t562 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t561, 0
  %t563 = getelementptr { i64, [4 x i64] }, ptr %t559, i32 0, i32 1
  store { %"compiler/mir:Place" } %t562, ptr %t563
  %t564 = load { i64, [4 x i64] }, ptr %t559
  store { i64, [7 x i64] } zeroinitializer, ptr %t565
  %t566 = getelementptr { i64, [7 x i64] }, ptr %t565, i32 0, i32 0
  store i64 6, ptr %t566
  %t567 = load %"compiler/source:Span", ptr %l213
  %t568 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t567, 0
  %t570 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t568, { i64, [4 x i64] } %t564, 1
  %t571 = getelementptr { i64, [7 x i64] }, ptr %t565, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t570, ptr %t571
  %t572 = load { i64, [7 x i64] }, ptr %t565
  %t573 = load ptr, ptr %l211, !tbaa !29
  %t574 = load i32, ptr %l212, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t573, i32 %t574, { i64, [7 x i64] } %t572)
  br label %bb53
bb53:
  %t576 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l218, ptr %t576, i64 192, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l218, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d226 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca %"compiler/mir:Fn"
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l42 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t1 = alloca { i64, [1 x i64] }, align 8
  %t8 = alloca %"compiler/mir:Fn", align 8
  %t68 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [1 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [1 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = insertvalue { i32 } undef, i32 9, 0
  %t4 = getelementptr { i64, [1 x i64] }, ptr %t1, i32 0, i32 1
  store { i32 } %t3, ptr %t4
  %t5 = load { i64, [1 x i64] }, ptr %t1
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  call void @compiler_2fmir_3aFn_2ector(ptr %t8, ptr %v1, { i64, [1 x i64] } %t5, i32 %t6, i64 0, %"compiler/source:Span" %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t8, i64 192, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store ptr %t12, ptr %lp2
  %t13 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %l10, i64 192, i1 false)
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  %t44 = load ptr, ptr %lp2
  %t45 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t50 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v1, ptr %t44, i32 0, %"compiler/source:Span" %t45, i32 %t42)
  store i32 %t50, ptr %l28
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  %t55 = load ptr, ptr %lp2
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t55, i32 0, i32 %t56, i32 0, %"compiler/source:Span" %t57, i32 0)
  store i32 %t62, ptr %l35
  br label %bb11
bb11:
  %t63 = load ptr, ptr %lp2
  %t65 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t63)
  store i32 %t65, ptr %l37
  br label %bb12
bb12:
  %t66 = load ptr, ptr %lp2
  %t67 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 0
  store i64 3, ptr %t69
  %t71 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t67, 0
  %t72 = insertvalue { %"compiler/source:Span", i32 } %t71, i32 0, 1
  %t73 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t72, ptr %t73
  %t74 = load { i64, [21 x i64] }, ptr %t68
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t74, ptr %t76
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t66, i32 0, ptr %t76)
  br label %bb13
bb13:
  %t79 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t79, i64 192, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l42, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %v0) #0 {
entry:
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/mir:BasicBlock"
  %t4 = alloca { i64, [7 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store { i64, [7 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [7 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [7 x i64] }, ptr %t4
  %t9 = insertvalue %"compiler/mir:BasicBlock" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, 0
  %t11 = insertvalue %"compiler/mir:BasicBlock" %t9, { i64, [7 x i64] } %t6, 1
  store %"compiler/mir:BasicBlock" %t11, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

define dso_local %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:Local" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:Local" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/mir:Local" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:Local" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/mir:Local" %t18, { i64, [1 x i64] } %a4, 4
  store %"compiler/mir:Local" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Local", ptr %rv
  ret %"compiler/mir:Local" %rr
}

define dso_local %"compiler/mir:Place" @compiler_2fmir_3aPlace_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Place"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Place" undef, { i64, [2 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/mir:Place" %t6, %"compiler/mir:Range" %a1, 1
  store %"compiler/mir:Place" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Range"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Range" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/mir:Range" %t6, i32 %a1, 1
  store %"compiler/mir:Range" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [5 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %rv = alloca %"compiler/mir:Task"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/mir:Task" undef, { i64, [5 x i64] } %a0, 0
  %t18 = insertvalue %"compiler/mir:Task" %t16, %"compiler/mir:Range" %a1, 1
  %t20 = insertvalue %"compiler/mir:Task" %t18, %"compiler/mir:Range" %a2, 2
  %t22 = insertvalue %"compiler/mir:Task" %t20, %"compiler/mir:Range" %a3, 3
  %t24 = insertvalue %"compiler/mir:Task" %t22, %"compiler/mir:Range" %a4, 4
  %t26 = insertvalue %"compiler/mir:Task" %t24, %"compiler/mir:Range" %a5, 5
  %t28 = insertvalue %"compiler/mir:Task" %t26, %"compiler/source:Span" %a6, 6
  store %"compiler/mir:Task" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Task", ptr %rv
  ret %"compiler/mir:Task" %rr
}

define dso_local %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/mir:dumper"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t5)
  store %"std/prelude/text:StringBuilder" %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l7
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = insertvalue %"compiler/mir:dumper" undef, ptr %t8, 0
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = insertvalue %"compiler/mir:dumper" %t9, ptr %t10, 1
  %t13 = insertvalue %"compiler/mir:dumper" %t11, %"std/prelude/text:StringBuilder" %t7, 2
  store %"compiler/mir:dumper" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:dumper", ptr %rv
  ret %"compiler/mir:dumper" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant [3 x i8] c" = "
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant [5 x i8] c"call "
@.d2 = private constant [1 x i8] c"("
@.d3 = private constant [1 x i8] c")"
@.d4 = private constant [2 x i8] c" ["
@.d5 = private constant [1 x i8] c"]"
@.d6 = private constant [8 x i8] c" then bb"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant [6 x i8] c" err L"
@.d8 = private constant [3 x i8] c" bb"
@.d9 = private constant [7 x i8] c"extern "
@.d10 = private constant [1 x i8] c"("
@.d11 = private constant [1 x i8] c")"
@.d12 = private constant [5 x i8] c"text "
@.d13 = private constant [2 x i8] c"  "
@.d14 = private constant [3 x i8] c" + "
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [2 x i8] c", "
@.d17 = private constant [0 x i8] c""
@.d18 = private constant [2 x i8] c", "
@.d19 = private constant [0 x i8] c""
@.d20 = private constant [3 x i8] c" = "
@.d21 = private constant [6 x i8] c"live L"
@.d22 = private constant [6 x i8] c"dead L"
@.d23 = private constant [6 x i8] c"open S"
@.d24 = private constant [7 x i8] c"close S"
@.d25 = private constant [6 x i8] c"give S"
@.d26 = private constant [14 x i8] c"register dtor "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [4 x i8] c" in "
@.d29 = private constant [15 x i8] c"register owner "
@.d30 = private constant [4 x i8] c" in "
@.d31 = private constant [8 x i8] c"release "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr @.d227 }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr @.d227 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d228 }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr @.d228 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d229 }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d229 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr @.d230 }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr @.d230 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 13, ptr @.d231 }, 1
  %t14 = extractvalue { i64, ptr } { i64 13, ptr @.d231 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 14, ptr @.d232 }, 1
  %t16 = extractvalue { i64, ptr } { i64 14, ptr @.d232 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 15, ptr @.d233 }, 1
  %t18 = extractvalue { i64, ptr } { i64 15, ptr @.d233 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 14, ptr @.d234 }, 1
  %t20 = extractvalue { i64, ptr } { i64 14, ptr @.d234 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d32 = private constant [6 x i8] c"write "
@.d33 = private constant [1 x i8] c" "
@.d34 = private constant [4 x i8] c" to "
@.d35 = private constant [5 x i8] c"copy "
@.d36 = private constant [6 x i8] c" from "
@.d37 = private constant [4 x i8] c" to "
@.d38 = private constant [10 x i8] c"spawn in S"
@.d39 = private constant [1 x i8] c" "
@.d40 = private constant [6 x i8] c"raised"
@.d41 = private constant [11 x i8] c" cleanup bb"
@.d42 = private constant [5 x i8] c" runs"
@.d43 = private constant [13 x i8] c"deferred at S"
@.d44 = private constant [15 x i8] c"(no terminator)"
@.d45 = private constant [7 x i8] c"goto bb"
@.d46 = private constant [7 x i8] c"branch "
@.d47 = private constant [3 x i8] c" bb"
@.d48 = private constant [3 x i8] c" bb"
@.d49 = private constant [7 x i8] c"switch "
@.d50 = private constant [2 x i8] c" ["
@.d51 = private constant [9 x i8] c"] else bb"
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [1 x i8] c" "
@.d54 = private constant [6 x i8] c"return"
@.d55 = private constant [6 x i8] c"raise "
@.d56 = private constant [9 x i8] c" failed L"
@.d57 = private constant [3 x i8] c" bb"
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [6 x i8] c"wait S"
@.d60 = private constant [8 x i8] c" then bb"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 13, ptr @.d235 }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr @.d235 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d236 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d236 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d237 }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d237 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr @.d238 }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr @.d238 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 20, ptr @.d239 }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr @.d239 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 15, ptr @.d240 }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr @.d240 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 20, ptr @.d241 }, 1
  %t18 = extractvalue { i64, ptr } { i64 20, ptr @.d241 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr @.d242 }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr @.d242 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 11, ptr @.d243 }, 1
  %t22 = extractvalue { i64, ptr } { i64 11, ptr @.d243 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 20, ptr @.d244 }, 1
  %t24 = extractvalue { i64, ptr } { i64 20, ptr @.d244 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 14, ptr @.d245 }, 1
  %t26 = extractvalue { i64, ptr } { i64 14, ptr @.d245 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 16, ptr @.d246 }, 1
  %t28 = extractvalue { i64, ptr } { i64 16, ptr @.d246 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 18, ptr @.d247 }, 1
  %t30 = extractvalue { i64, ptr } { i64 18, ptr @.d247 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
ret:
  ret void
}

@.d61 = private constant [0 x i8] c""
@.d62 = private constant [1 x i8] c" "
@.d63 = private constant [5 x i8] c"exit "
@.d64 = private constant [6 x i8] c"resume"
@.d65 = private constant [2 x i8] c"a "
@.d66 = private constant [9 x i8] c" made of "
@.d67 = private constant [9 x i8] c" elements"
@.d68 = private constant [8 x i8] c"element "
@.d69 = private constant [8 x i8] c"no case "
@.d70 = private constant [6 x i8] c" in a "
@.d71 = private constant [2 x i8] c"a "
@.d72 = private constant [14 x i8] c" made of parts"
@.d73 = private constant [10 x i8] c"a call of "
@.d74 = private constant [28 x i8] c" arguments to a function of "
@.d75 = private constant [11 x i8] c" parameters"
@.d76 = private constant [9 x i8] c"argument "
@.d77 = private constant [15 x i8] c"a call passing "
@.d78 = private constant [25 x i8] c" scopes for its callee's "
@.d79 = private constant [45 x i8] c"a call passing the frame for a scope variable"
@.d80 = private constant [4 x i8] c"fn: "
@.d81 = private constant [2 x i8] c"bb"
@.d82 = private constant [8 x i8] c"[term]: "
@.d83 = private constant [2 x i8] c"bb"
@.d84 = private constant [1 x i8] c"["
@.d85 = private constant [3 x i8] c"]: "
@.d86 = private constant [11 x i8] c"no block bb"
@.d87 = private constant [27 x i8] c"a text builder that is none"
@.d88 = private constant [23 x i8] c"a function value typed "
@.d89 = private constant [10 x i8] c"no local L"
@.d90 = private constant [4 x i8] c"none"
@.d91 = private constant [1 x i8] c"S"
@.d92 = private constant [18 x i8] c"a new array typed "
@.d93 = private constant [29 x i8] c", not a run-time-length array"
@.d94 = private constant [39 x i8] c"a new array's length that is no integer"
@.d95 = private constant [18 x i8] c"a new array's fill"
@.d96 = private constant [12 x i8] c"no constant "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d248 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d248 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d249 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d249 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d250 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d250 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d251 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d251 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d252 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d252 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d253 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d253 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d254 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d254 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d255 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d255 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d256 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d256 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d257 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d257 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d258 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d258 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d259 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d259 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d260 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d260 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d261 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d261 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d262 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d262 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d263 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d263 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d264 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d264 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d265 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d265 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d266 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d266 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d267 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d267 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d268 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d268 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d269 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d269 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d270 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d270 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d271 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d271 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 14, ptr @.d272 }, 1
  %t54 = extractvalue { i64, ptr } { i64 14, ptr @.d272 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d273 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d273 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 17, ptr @.d274 }, 1
  %t58 = extractvalue { i64, ptr } { i64 17, ptr @.d274 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 18, ptr @.d275 }, 1
  %t60 = extractvalue { i64, ptr } { i64 18, ptr @.d275 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 16, ptr @.d276 }, 1
  %t62 = extractvalue { i64, ptr } { i64 16, ptr @.d276 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 17, ptr @.d277 }, 1
  %t64 = extractvalue { i64, ptr } { i64 17, ptr @.d277 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 24, ptr @.d278 }, 1
  %t66 = extractvalue { i64, ptr } { i64 24, ptr @.d278 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 13, ptr @.d279 }, 1
  %t68 = extractvalue { i64, ptr } { i64 13, ptr @.d279 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 19, ptr @.d280 }, 1
  %t70 = extractvalue { i64, ptr } { i64 19, ptr @.d280 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 20, ptr @.d281 }, 1
  %t72 = extractvalue { i64, ptr } { i64 20, ptr @.d281 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 15, ptr @.d282 }, 1
  %t74 = extractvalue { i64, ptr } { i64 15, ptr @.d282 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 17, ptr @.d283 }, 1
  %t76 = extractvalue { i64, ptr } { i64 17, ptr @.d283 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 18, ptr @.d284 }, 1
  %t78 = extractvalue { i64, ptr } { i64 18, ptr @.d284 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 15, ptr @.d285 }, 1
  %t80 = extractvalue { i64, ptr } { i64 15, ptr @.d285 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 12, ptr @.d286 }, 1
  %t82 = extractvalue { i64, ptr } { i64 12, ptr @.d286 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
ret:
  ret void
}

@.d97 = private constant [21 x i8] c"no overflow test for "
@.d98 = private constant [4 x i8] c" of "
@.d99 = private constant [9 x i8] c" operands"
@.d100 = private constant [20 x i8] c"an overflow test of "
@.d101 = private constant [6 x i8] c" to a "
@.d102 = private constant [16 x i8] c", not an integer"
@.d103 = private constant [20 x i8] c"a place with no base"
@.d104 = private constant [11 x i8] c"projections"
@.d105 = private constant [9 x i8] c"no field "
@.d106 = private constant [6 x i8] c" in a "
@.d107 = private constant [10 x i8] c"an index L"
@.d108 = private constant [6 x i8] c" is a "
@.d109 = private constant [16 x i8] c"an index into a "
@.d110 = private constant [14 x i8] c", not an array"
@.d111 = private constant [16 x i8] c"an index into a "
@.d112 = private constant [14 x i8] c", not an array"
@.d113 = private constant [15 x i8] c"constant index "
@.d114 = private constant [11 x i8] c" outside a "
@.d115 = private constant [13 x i8] c"a deref of a "
@.d116 = private constant [17 x i8] c", not a reference"
@.d117 = private constant [8 x i8] c"no case "
@.d118 = private constant [6 x i8] c" in a "
@.d119 = private constant [5 x i8] c"case "
@.d120 = private constant [6 x i8] c" of a "
@.d121 = private constant [15 x i8] c" has no payload"
@.d122 = private constant [1 x i8] c"S"
@.d123 = private constant [1 x i8] c" "
@.d124 = private constant [20 x i8] c", but it is not open"
@.d125 = private constant [1 x i8] c"S"
@.d126 = private constant [1 x i8] c" "
@.d127 = private constant [8 x i8] c" while S"
@.d128 = private constant [23 x i8] c", opened in it, is open"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d129 = private constant [35 x i8] c"unreachable: no path from the entry"
@.d130 = private constant [19 x i8] c"no scope variable V"
@.d131 = private constant [18 x i8] c"a reference typed "
@.d132 = private constant [12 x i8] c"a reference "
@.d133 = private constant [6 x i8] c" to a "
@.d134 = private constant [13 x i8] c"an error code"
@.d135 = private constant [7 x i8] c" typed "
@.d136 = private constant [6 x i8] c" of a "
@.d137 = private constant [9 x i8] c"no blocks"
@.d138 = private constant [28 x i8] c"its type is no function type"
@.d139 = private constant [13 x i8] c"its type has "
@.d140 = private constant [24 x i8] c" parameters, its Params "
@.d141 = private constant [10 x i8] c"parameter "
@.d142 = private constant [11 x i8] c" is local L"
@.d143 = private constant [13 x i8] c", not a Param"
@.d144 = private constant [10 x i8] c"parameter "
@.d145 = private constant [6 x i8] c" is a "
@.d146 = private constant [16 x i8] c", its type says "
@.d147 = private constant [9 x i8] c"capture L"
@.d148 = private constant [20 x i8] c" is no Capture local"
@.d149 = private constant [1 x i8] c"L"
@.d150 = private constant [21 x i8] c" has the Unknown type"
@.d151 = private constant [1 x i8] c"S"
@.d152 = private constant [11 x i8] c"'s parent S"
@.d153 = private constant [24 x i8] c" is not opened before it"
@.d154 = private constant [7 x i8] c"targets"
@.d155 = private constant [7 x i8] c"clauses"
@.d156 = private constant [5 x i8] c"items"
@.d157 = private constant [5 x i8] c"bytes"
@.d158 = private constant [14 x i8] c"constant items"
@.d159 = private constant [9 x i8] c"constant "
@.d160 = private constant [16 x i8] c" holds constant "
@.d161 = private constant [20 x i8] c", not made before it"
@.d162 = private constant [1 x i8] c" "
@.d163 = private constant [0 x i8] c""
@.d164 = private constant [1 x i8] c"S"
@.d165 = private constant [1 x i8] c" "
@.d166 = private constant [0 x i8] c""
@.d167 = private constant [1 x i8] c"S"
@.d168 = private constant [8 x i8] c"no task "
@.d169 = private constant [16 x i8] c"the value stored"
@.d170 = private constant [40 x i8] c"an own slot given a borrow, not an owner"
@.d171 = private constant [30 x i8] c"a destructor registered for a "
@.d172 = private constant [23 x i8] c", not a reference to a "
@.d173 = private constant [30 x i8] c"a destructor registered for a "
@.d174 = private constant [21 x i8] c", which declares none"
@.d175 = private constant [19 x i8] c"an owner slot of a "
@.d176 = private constant [22 x i8] c", not an own reference"
@.d177 = private constant [2 x i8] c"a "
@.d178 = private constant [12 x i8] c" write of a "
@.d179 = private constant [55 x i8] c"elements copied between places that are not both arrays"
@.d180 = private constant [26 x i8] c"elements copied between a "
@.d181 = private constant [7 x i8] c" and a "
@.d182 = private constant [45 x i8] c"a count of copied elements that is no integer"
@.d183 = private constant [14 x i8] c"a spawn into S"
@.d184 = private constant [18 x i8] c", which is no join"
@.d185 = private constant [12 x i8] c"a task with "
@.d186 = private constant [13 x i8] c" targets for "
@.d187 = private constant [8 x i8] c" results"
@.d188 = private constant [16 x i8] c"a task's result "
@.d189 = private constant [44 x i8] c"a task's clauses for a call that cannot fail"
@.d190 = private constant [12 x i8] c"a take of a "
@.d191 = private constant [22 x i8] c", not an own reference"
@.d192 = private constant [13 x i8] c"no terminator"
@.d193 = private constant [5 x i8] c"cases"
@.d194 = private constant [8 x i8] c"no call "
@.d195 = private constant [14 x i8] c"a branch on a "
@.d196 = private constant [14 x i8] c"a switch on a "
@.d197 = private constant [24 x i8] c"a switch with the value "
@.d198 = private constant [6 x i8] c" twice"
@.d199 = private constant [32 x i8] c"a call with no result stores one"
@.d200 = private constant [17 x i8] c"the call's result"
@.d201 = private constant [39 x i8] c"a call that can fail with no error edge"
@.d202 = private constant [41 x i8] c"an error edge for a call that cannot fail"
@.d203 = private constant [21 x i8] c"the call's error code"
@.d204 = private constant [48 x i8] c"a return with no value from a function giving a "
@.d205 = private constant [49 x i8] c"a return with a value from a function giving none"
@.d206 = private constant [18 x i8] c"the value returned"
@.d207 = private constant [38 x i8] c"a raise in a function that cannot fail"
@.d208 = private constant [16 x i8] c"the error raised"
@.d209 = private constant [12 x i8] c"a wait for S"
@.d210 = private constant [18 x i8] c", which is no join"
@.d211 = private constant [51 x i8] c"a wait for a join that can fail with no failed edge"
@.d212 = private constant [41 x i8] c"a failed edge for a join that cannot fail"
@.d213 = private constant [21 x i8] c"the join's error code"
@.d214 = private constant [16 x i8] c"a message for a "
@.d215 = private constant [5 x i8] c" exit"
@.d216 = private constant [35 x i8] c"an assert's message that is no text"
@.d217 = private constant [11 x i8] c"text typed "
@.d218 = private constant [1 x i8] c"L"
@.d219 = private constant [44 x i8] c" read before it is initialized on every path"
@.d220 = private constant [11 x i8] c"a range of "
@.d221 = private constant [14 x i8] c" out of bounds"
@.d222 = private constant [3 x i8] c"I32"
@.d223 = private constant [1 x i8] c"x"
@.d224 = private constant [3 x i8] c"I64"
@.d225 = private constant [1 x i8] c"i"
@.d226 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d227 = private unnamed_addr constant [15 x i8] c"WriteKind.Bytes"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d228 = private unnamed_addr constant [16 x i8] c"WriteKind.Quoted"
@.d229 = private unnamed_addr constant [14 x i8] c"WriteKind.Char"
@.d230 = private unnamed_addr constant [20 x i8] c"WriteKind.QuotedChar"
@.d231 = private unnamed_addr constant [13 x i8] c"WriteKind.Int"
@.d232 = private unnamed_addr constant [14 x i8] c"WriteKind.Uint"
@.d233 = private unnamed_addr constant [15 x i8] c"WriteKind.Float"
@.d234 = private unnamed_addr constant [14 x i8] c"WriteKind.Bool"
@.d235 = private unnamed_addr constant [13 x i8] c"ExitKind.Done"
@.d236 = private unnamed_addr constant [13 x i8] c"ExitKind.Fail"
@.d237 = private unnamed_addr constant [14 x i8] c"ExitKind.Abort"
@.d238 = private unnamed_addr constant [20 x i8] c"ExitKind.Unreachable"
@.d239 = private unnamed_addr constant [20 x i8] c"ExitKind.NullReached"
@.d240 = private unnamed_addr constant [15 x i8] c"ExitKind.Assert"
@.d241 = private unnamed_addr constant [20 x i8] c"ExitKind.SliceBounds"
@.d242 = private unnamed_addr constant [20 x i8] c"ExitKind.ArrayLength"
@.d243 = private unnamed_addr constant [11 x i8] c"ExitKind.As"
@.d244 = private unnamed_addr constant [20 x i8] c"ExitKind.FixedLength"
@.d245 = private unnamed_addr constant [14 x i8] c"ExitKind.Error"
@.d246 = private unnamed_addr constant [16 x i8] c"ExitKind.Escaped"
@.d247 = private unnamed_addr constant [18 x i8] c"ExitKind.Guarantee"
@.d248 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d249 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d250 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d251 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d252 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d253 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d254 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d255 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d256 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d257 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d258 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d259 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d260 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d261 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d262 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d263 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d264 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d265 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d266 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d267 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d268 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d269 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d270 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d271 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d272 = private unnamed_addr constant [14 x i8] c"PrimOp.InRange"
@.d273 = private unnamed_addr constant [18 x i8] c"PrimOp.InRangeIncl"
@.d274 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d275 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d276 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d277 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d278 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d279 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d280 = private unnamed_addr constant [19 x i8] c"PrimOp.LeadingZeros"
@.d281 = private unnamed_addr constant [20 x i8] c"PrimOp.TrailingZeros"
@.d282 = private unnamed_addr constant [15 x i8] c"PrimOp.PopCount"
@.d283 = private unnamed_addr constant [17 x i8] c"PrimOp.RotateLeft"
@.d284 = private unnamed_addr constant [18 x i8] c"PrimOp.RotateRight"
@.d285 = private unnamed_addr constant [15 x i8] c"PrimOp.ByteSwap"
@.d286 = private unnamed_addr constant [12 x i8] c"PrimOp.Holds"
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f3abe41a98405543_7d26227a2bded35f = external constant [0 x i8]
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2ePus_H9ddd7aec2adc172d235e28f53f6a7179(ptr %v0, ptr %a0, %"compiler/mir:ScopeInfo" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eSe_H8a8a2f028839a4663a36aa3d32dfaacb(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/mir:BasicBlock" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2ePu_H0f7fa7a3bad59b258cdb456f0cf1ac35(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:BasicBlock" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_dca1ca4acf899191_a3a5645eac28d4dd = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1)
declare %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1)
@olang_loc_63d4bc85d5a0ee63_941776bd89ba250f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b20d2ead933ce67_842549c98b36ec43 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
declare { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i32, i1 } @compiler_2fmir_2ecompiler_2fmir_3averifier_2efieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c289c76542078e7_53d9d4aa9af07973 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_62f33ceaa6d0d243_a40627fd170062cf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f7be8aa76db69854_ffaa205b85e46cd8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
@olang_loc_293fa35c34966465_23dfef653c6d5c71 = external constant [0 x i8]
@olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9 = external constant [0 x i8]
@olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97 = external constant [0 x i8]
@olang_loc_70d66502dd431e07_8b33d36aabf56353 = external constant [0 x i8]
@olang_loc_2986d82de8391aaf_d61db5ce8081183b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b3d4ae2f12f779ee_96af6ec666a78bba = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
@olang_loc_525ae97147cf6b9b_c46e40fbd793c77f = external constant [0 x i8]
@olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7127dab5ce57c749_b077692428e4994d = external constant [0 x i8]
@olang_loc_76a99ae981c91c78_ffe52510b3cdb11c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_18d9829ba3f5a2af_a05952e551f4e6bb = external constant [0 x i8]
@olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b = external constant [0 x i8]
@olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a = external constant [0 x i8]
@olang_loc_a5f83820f05cb9f9_5f257facca4b96a5 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
@olang_loc_6be72733009cb689_7eadbfb9b429b955 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3d9554dfcf1aeb63_1386be72809b2127 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eRunFrom_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_729af306d1a375bd_3b9d78bce782a851 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eRunFrom_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ebd53c5cd6069b87_f80775eded979a3b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ba49393f26523c26_b8992ee5d3be0dba = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eLen_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aPlace_3e_2eAt_3ccompiler_2fmir_3aPlace_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eLe_Ha29d98bd5fca0556754225de6d8edaab(ptr %v0, ptr %a0)
declare %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eRunFrom_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ecf51586bea1aa81_8258c2cc4874ccd = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eee257eb13f606f0_579348194f70649c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eRunFrom_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4fb7743b938ffb2b_98c233616dbed9d7 = external constant [0 x i8]
@olang_loc_a7113f54b8427e6a_b5cb829958e44636 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e78f424551ad49a5_ff41c7fa0d07ed9 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
@olang_loc_145fd452f8e36c9b_ff9c6902187c9987 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22 = external constant [0 x i8]
@olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7 = external constant [0 x i8]
@olang_loc_4f65b4158cb36c84_7aab915b507980 = external constant [0 x i8]
declare %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
@olang_loc_4fdb0c87eb50ced7_f9856407ece22343 = external constant [0 x i8]
@olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [5 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_91402ead91eecd74_d65ac3d6c8116e0 = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [1 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
