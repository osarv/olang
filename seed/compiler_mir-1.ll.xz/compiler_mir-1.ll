; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [8 x i64] } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
define dso_local i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t23 = trunc i64 24 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb10
bb9:
  %t36 = load i32, ptr %l19, !tbaa !23
  store i32 %t36, ptr %l16, !tbaa !23
  br label %bb11
bb10:
  %t37 = load i32, ptr %l22, !tbaa !23
  store i32 %t37, ptr %l16, !tbaa !23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l16, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t23 = trunc i64 18 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb10
bb9:
  %t38 = load i32, ptr %l20, !tbaa !23
  store i32 %t38, ptr %l17, !tbaa !23
  br label %bb11
bb10:
  %t39 = load i32, ptr %l23, !tbaa !23
  store i32 %t39, ptr %l17, !tbaa !23
  br label %bb11
bb11:
  %t40 = load i32, ptr %l17, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1, i32 %t2, i64 %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t11 = trunc i64 0 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb7
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t18 = mul i64 2, 4
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 2, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 0
  store i32 %t16, ptr %t25, !tbaa !33
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 1
  store i32 %t17, ptr %t29, !tbaa !33
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } %t31)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t34 = load ptr, ptr %l11, !tbaa !29
  %t35 = load i32, ptr %l16, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t34, i32 %t35, i32 %t33, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t37, ptr %l18
  br label %bb6
bb6:
  %t38 = load i32, ptr %l18, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb7:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = mul i64 2, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 2, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t46, ptr %t55, !tbaa !33
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 1
  store i32 %t47, ptr %t59, !tbaa !33
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t45, { i64, ptr } %t61)
  store i32 %t62, ptr %l26
  br label %bb11
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t64 = load ptr, ptr %l21, !tbaa !29
  %t65 = load i32, ptr %l26, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t64, i32 %t65, i32 %t63, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t67, ptr %l28
  br label %bb12
bb12:
  %t68 = load i32, ptr %l28, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb13:
  %t69 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l31, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l34
  br label %bb17
bb17:
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load ptr, ptr %l31, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t81, i32 %t82, i32 %t80, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t84, ptr %l36
  br label %bb18
bb18:
  %t85 = load i32, ptr %l36, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  br label %bb33
bb19:
  %t86 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t91, i32 0, i32 %t92, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t95, ptr %l41
  br label %bb23
bb23:
  %t96 = load i32, ptr %l41, !tbaa !23
  store i32 %t96, ptr %l8, !tbaa !23
  br label %bb33
bb24:
  %t97 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t99 = trunc i64 4 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t102 = load i32, ptr %l1, !range !{i32 0, i32 6}
  %t104 = trunc i64 5 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l46, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l49
  br label %bb30
bb30:
  %t113 = load i32, ptr %l2, !tbaa !23
  %t114 = load ptr, ptr %l46, !tbaa !29
  %t115 = load i32, ptr %l49, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t114, i32 %t115, i32 %t113, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t117, ptr %l51
  br label %bb31
bb31:
  %t118 = load i32, ptr %l51, !tbaa !23
  store i32 %t118, ptr %l8, !tbaa !23
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f3abe41a98405543_7d26227a2bded35f)
  unreachable
bb33:
  %t119 = load i32, ptr %l8, !tbaa !23
  store i32 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %a0) #0 {
entry:
  %l4 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  %t2 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 1, ptr %t3
  %t5 = insertvalue { i32 } undef, i32 %a0, 0
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 1
  store { i32 } %t5, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t2
  %t8 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t11 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t7, %"compiler/mir:Range" %t8)
  store %"compiler/mir:Lvalue" %t11, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/mir:Lvalue", ptr %l4
  store %"compiler/mir:Lvalue" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l8 = alloca ptr
  %l12 = alloca { i64, [21 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t6 = sext i32 %a1 to i64
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store ptr %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"compiler/mir:BasicBlock", ptr %t10, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %a2, i64 176, i1 false)
  %t17 = load { i64, [21 x i64] }, ptr %l12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t13, { i64, [21 x i64] } %t17)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t3, %"compiler/mir:Call" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 14
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 18
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/typed:Item", ptr %t25, i64 %t22
  %t27 = load %"compiler/typed:Item", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t31, %"compiler/typed:Item" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l13 = alloca %"compiler/mir:ScopeInfo"
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l7, !tbaa !29
  %t14 = call %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %s0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
  store %"compiler/mir:ScopeInfo" %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/mir:ScopeInfo", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ePush_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t15, %"compiler/mir:ScopeInfo" %t16)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 8
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t25 = trunc i64 %t23 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t4 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [1 x i64] }, ptr %t4, i32 0, i32 0
  store i64 3, ptr %t5
  %t6 = load { i64, [1 x i64] }, ptr %t4
  %t11 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 0, %"compiler/source:Span" %a2, i32 %a1, i32 3, { i64, [1 x i64] } %t6)
  store %"compiler/mir:Local" %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load %"compiler/mir:Local", ptr %l8
  %t14 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t12, %"compiler/mir:Local" %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [4 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t31, { i64, [4 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2) #0 {
entry:
  %l10 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  %t7 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v0, ptr %t7, i64 %t3)
  store ptr %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t17 = getelementptr %"compiler/mir:BasicBlock", ptr %t12, i32 0, i32 1
  store { i64, [8 x i64] } %a2, ptr %t17
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:BasicBlock"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %s0)
  store %"compiler/mir:BasicBlock" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/mir:BasicBlock", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ePush_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s0, ptr %t5, %"compiler/mir:BasicBlock" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 9
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb8:
  store { i64, [2 x i64] } %a1, ptr %l26
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = trunc i64 %t45 to i32
  %t50 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t42, i32 %t47)
  store %"compiler/mir:Range" %t50, ptr %l32
  br label %bb9
bb9:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  %t52 = load %"compiler/mir:Range", ptr %l32
  %t53 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t51, %"compiler/mir:Range" %t52)
  store %"compiler/mir:Lvalue" %t53, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/mir:Lvalue", ptr %l33
  store %"compiler/mir:Lvalue" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 23
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 23
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t55, i64 %t56)
  store i32 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i32, ptr %l38, !tbaa !23
  %t64 = icmp eq i32 %t62, %t61
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l44
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t73 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:verifier"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/mir:verifier", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmir_3averifier_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %v1, ptr %a0, ptr %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %t3, i64 304, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 304, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l5, i64 304, i1 false)
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %v1, ptr %t8)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 2
  %t14 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t12)
  store { i64, ptr } %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  %t11 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t6, %"compiler/mir:Lvalue" %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  call void @olang_textcopy(ptr %t19, ptr %t15, i64 %t16)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t29 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t29, { i64, ptr } %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  store ptr %l2, ptr %l11, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t33 = load { i64, [7 x i64] }, ptr %t32
  %t36 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t31, { i64, [7 x i64] } %t33)
  store { i64, ptr } %t36, ptr %l14
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t39 = load %"compiler/mir:Range", ptr %t38
  %t42 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t37, %"compiler/mir:Range" %t39)
  store { i64, ptr } %t42, ptr %l17
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t43, i64 %t44)
  %t60 = getelementptr i8, ptr %t59, i64 %t44
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t49, i64 %t50)
  %t62 = getelementptr i8, ptr %t61, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t59, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t73, { i64, ptr } %t72)
  br label %bb9
bb9:
  %t75 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = icmp sgt i32 %t77, 0
  br i1 %t79, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l22, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t83 = load %"compiler/mir:Range", ptr %t82
  %t86 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s4, ptr %t81, %"compiler/mir:Range" %t83)
  store { i64, ptr } %t86, ptr %l25
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t89 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t108, { i64, ptr } %t107)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t110 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t115 = sext i32 %t111 to i64
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t113, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t112, i64 %t113)
  %t119 = getelementptr i8, ptr %t118, i64 %t113
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t115)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t129)
  br label %bb15
bb15:
  %t132 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t137 = icmp ne i32 %t133, %t134
  br i1 %t137, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t140 = load i32, ptr %t139, !tbaa !23
  %t141 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t146 = sext i32 %t140 to i64
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t146)
  %t159 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t159, ptr %t149, i64 %t150)
  %t160 = getelementptr i8, ptr %t159, i64 %t150
  %t161 = call i64 @__olang_fmt_i64(ptr %t160, i64 %t153)
  %t162 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t156, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t170)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb19
bb19:
  %t174 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t174, ptr %l41
  br label %bb20
bb20:
  %t175 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t175, ptr %l42, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l43, !tbaa !24
  %t178 = load i64, ptr %l43, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l44, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l43, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t189, ptr %l42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t190 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %t10, { i64, [2 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l13
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  br label %bb20
bb5:
  %t16 = load { i64, [7 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { i64, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t29 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %l7, !tbaa !27
  br label %bb20
bb9:
  %t37 = load { i64, [7 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [7 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 2
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [4 x i64] } }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l4
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l4
  %t50 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t46, { i64, [4 x i64] } %t47)
  store { i64, ptr } %t50, ptr %l24
  br label %bb13
bb13:
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t53 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb14:
  %t66 = load { i64, [7 x i64] }, ptr %l1
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 3
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t72 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t73, ptr %l5
  %t75 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t76 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l30, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, [4 x i64] }, ptr %l5
  %t84 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %t80, { i64, [4 x i64] } %t81)
  store { i64, ptr } %t84, ptr %l33
  br label %bb18
bb18:
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t87 = load i64, ptr %l30, !tbaa !24
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t85, i64 %t86)
  %t101 = getelementptr i8, ptr %t100, i64 %t86
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t87)
  %t103 = getelementptr i8, ptr %t101, i64 %t88
  call void @olang_textcopy(ptr %t103, ptr %t90, i64 %t91)
  %t104 = getelementptr i8, ptr %t103, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t94, i64 %t95)
  %t105 = getelementptr i8, ptr %t104, i64 %t95
  call void @olang_textcopy(ptr %t105, ptr %t97, i64 %t98)
  %t106 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t100, 1
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267)
  unreachable
bb20:
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/mir:Range"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 19
  %t9 = sext i32 %a1 to i64
  %t10 = load ptr, ptr @__olang_prog_scope
  %t13 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %t10, ptr %t6, i64 %t9)
  store { i64, [1 x i64] } %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t14, ptr %l2
  %t15 = load { i64, [1 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l12, !tbaa !27
  br label %bb15
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  %t34 = extractvalue { i64, [1 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 1
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Range" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Range", ptr %t38
  store %"compiler/mir:Range" %t39, ptr %l4
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t46 = sext i32 %t42 to i64
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t46)
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  store { i64, ptr } %t53, ptr %l12, !tbaa !27
  br label %bb15
bb9:
  %t55 = load { i64, [1 x i64] }, ptr %l2
  %t57 = extractvalue { i64, [1 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 2
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t61 = getelementptr { %"compiler/mir:Range" }, ptr %t60, i32 0, i32 0
  %t62 = load %"compiler/mir:Range", ptr %t61
  store %"compiler/mir:Range" %t62, ptr %l5
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/mir:Range", ptr %l5
  %t68 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %t64, %"compiler/mir:Range" %t65)
  store { i64, ptr } %t68, ptr %l28
  br label %bb13
bb13:
  %t69 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t69, ptr %l12, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dca1ca4acf899191_a3a5645eac28d4dd)
  unreachable
bb15:
  %t70 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/mir:dumper", ptr %t49, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:dumper", ptr %t63, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:dumper", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t8, ptr %s0, ptr %t6, i32 %a1)
  store { i64, ptr } %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l20, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  store ptr %l2, ptr %l41, !tbaa !29
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:dumper", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t78 = load ptr, ptr @__olang_prog_scope
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t78, ptr %s2, ptr %t70, i32 %t77)
  store { i64, ptr } %t81, ptr %l50
  br label %bb16
bb16:
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t100, { i64, ptr } %t99)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t107 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t107, ptr %l56
  br label %bb20
bb20:
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l58, !tbaa !24
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = mul i64 %t111, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l59, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l58, !tbaa !24
  %t121 = mul i64 %t120, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t122, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t123 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 11
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t73, ptr %t62, i64 %t72)
  store { i64, [4 x i64] } %t76, ptr %l48
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load { i64, [4 x i64] }, ptr %l48
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s2, ptr %t77, { i64, [4 x i64] } %t78)
  store { i64, ptr } %t79, ptr %l49
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t105, ptr %l55
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t106, ptr %l56, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l57, !tbaa !24
  %t119 = mul i64 %t118, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %t117, i64 %t119, i1 false)
  %t120 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t120, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [1 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 12
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t73, ptr %t62, i64 %t72)
  store { i64, [1 x i64] } %t76, ptr %l48
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load { i64, [1 x i64] }, ptr %l48
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s2, ptr %t77, { i64, [1 x i64] } %t78)
  store { i64, ptr } %t79, ptr %l49
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t105, ptr %l55
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t106, ptr %l56, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l57, !tbaa !24
  %t119 = mul i64 %t118, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %t117, i64 %t119, i1 false)
  %t120 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t120, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca %"compiler/mir:Lvalue"
  %l18 = alloca %"compiler/mir:Lvalue"
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca i1
  %l127 = alloca i32
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i1
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l160 = alloca i1
  %l167 = alloca i32
  %l168 = alloca ptr
  %l174 = alloca %"compiler/mir:Task"
  %l175 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca i1
  %l181 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca i1
  %l191 = alloca i32
  %l195 = alloca { i64, ptr }
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 13}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t22, %"compiler/mir:Lvalue" %t23)
  store { i64, ptr } %t26, ptr %l35
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l3
  %t31 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %s1, ptr %t27, { i64, [15 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l38
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = getelementptr i8, ptr %t43, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  store { i64, ptr } %t46, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb98
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %l40, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 13}
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l41, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [21 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = getelementptr i8, ptr %t70, i64 %t65
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t67)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  store { i64, ptr } %t74, ptr %l24, !tbaa !27
  br label %bb98
bb14:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 13}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t91 = load i32, ptr %l5, !tbaa !23
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t95 = sext i32 %t91 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t92, i64 %t93)
  %t99 = getelementptr i8, ptr %t98, i64 %t93
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t95)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l24, !tbaa !27
  br label %bb98
bb20:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 13}
  %t111 = icmp eq i64 %t109, 3
  store i1 %t111, ptr %l57, !tbaa !21
  br label %bb22
bb22:
  %t112 = load i1, ptr %l57, !tbaa !21
  br i1 %t112, label %bb23, label %bb24
bb23:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32 }, ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l6, !tbaa !23
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t123 = sext i32 %t119 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  %t128 = call i64 @__olang_fmt_i64(ptr %t127, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l24, !tbaa !27
  br label %bb98
bb26:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t133 = load ptr, ptr %l64, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 13}
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t140 = load i1, ptr %l65, !tbaa !21
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32 }, ptr %t143, i32 0, i32 1
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l7, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t147 = load i32, ptr %l7, !tbaa !23
  %t148 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t151 = sext i32 %t147 to i64
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t151)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l24, !tbaa !27
  br label %bb98
bb32:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t161 = load ptr, ptr %l72, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = load ptr, ptr %l72, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 13}
  %t167 = icmp eq i64 %t165, 5
  store i1 %t167, ptr %l73, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l73, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t171, i32 0, i32 1
  %t173 = load { i64, [1 x i64] }, ptr %t172
  store { i64, [1 x i64] } %t173, ptr %l8
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t177, i32 0, i32 2
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l9, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t183, i32 0, i32 3
  %t185 = load { i64, [4 x i64] }, ptr %t184
  store { i64, [4 x i64] } %t185, ptr %l10
  br label %bb37
bb36:
  br label %bb41
bb37:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/mir:dumper", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i32, ptr %l9, !tbaa !23
  %t192 = load ptr, ptr @__olang_prog_scope
  %t195 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t192, ptr %s11, ptr %t190, i32 %t191)
  store { i64, ptr } %t195, ptr %l85
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, [4 x i64] }, ptr %l10
  %t200 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %t196, { i64, [4 x i64] } %t197)
  store { i64, ptr } %t200, ptr %l88
  br label %bb39
bb39:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, [1 x i64] }, ptr %l8
  %t205 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s11, ptr %t201, { i64, [1 x i64] } %t202)
  store { i64, ptr } %t205, ptr %l91
  br label %bb40
bb40:
  %t206 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t208 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = add i64 %t207, %t210
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t215 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t206, i64 %t207)
  %t227 = getelementptr i8, ptr %t226, i64 %t207
  call void @olang_textcopy(ptr %t227, ptr %t209, i64 %t210)
  %t228 = getelementptr i8, ptr %t227, i64 %t210
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t216, i64 %t217)
  %t230 = getelementptr i8, ptr %t229, i64 %t217
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t223, i64 %t224)
  %t232 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t226, 1
  store { i64, ptr } %t233, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb41:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t236 = load ptr, ptr %l93, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb42, label %bb43
bb42:
  %t239 = load ptr, ptr %l93, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 13}
  %t242 = icmp eq i64 %t240, 6
  store i1 %t242, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t243 = load i1, ptr %l94, !tbaa !21
  br i1 %t243, label %bb44, label %bb45
bb44:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [21 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t246, i32 0, i32 1
  %t248 = load %"compiler/mir:Lvalue", ptr %t247
  store %"compiler/mir:Lvalue" %t248, ptr %l11
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/mir:Lvalue", ptr %l11
  %t254 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s13, ptr %t250, %"compiler/mir:Lvalue" %t251)
  store { i64, ptr } %t254, ptr %l101
  br label %bb47
bb47:
  %t255 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t255, i64 %t256)
  %t262 = getelementptr i8, ptr %t261, i64 %t256
  call void @olang_textcopy(ptr %t262, ptr %t258, i64 %t259)
  %t263 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t261, 1
  store { i64, ptr } %t264, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb48:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t267 = load ptr, ptr %l103, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb49, label %bb50
bb49:
  %t270 = load ptr, ptr %l103, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 13}
  %t273 = icmp eq i64 %t271, 7
  store i1 %t273, ptr %l104, !tbaa !21
  br label %bb50
bb50:
  %t274 = load i1, ptr %l104, !tbaa !21
  br i1 %t274, label %bb51, label %bb52
bb51:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [21 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t277, i32 0, i32 1
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l12, !tbaa !23
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [21 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t283, i32 0, i32 2
  %t285 = load %"compiler/mir:Lvalue", ptr %t284
  store %"compiler/mir:Lvalue" %t285, ptr %l13
  br label %bb53
bb52:
  br label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t287 = load i32, ptr %l12, !tbaa !23
  %t289 = sext i32 %t287 to i64
  store i64 %t289, ptr %l112, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/mir:Lvalue", ptr %l13
  %t294 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s15, ptr %t290, %"compiler/mir:Lvalue" %t291)
  store { i64, ptr } %t294, ptr %l115
  br label %bb54
bb54:
  %t295 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t297 = load i64, ptr %l112, !tbaa !24
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t299 = add i64 %t296, %t298
  %t300 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = add i64 %t302, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t295, i64 %t296)
  %t308 = getelementptr i8, ptr %t307, i64 %t296
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t297)
  %t310 = getelementptr i8, ptr %t308, i64 %t298
  call void @olang_textcopy(ptr %t310, ptr %t300, i64 %t301)
  %t311 = getelementptr i8, ptr %t310, i64 %t301
  call void @olang_textcopy(ptr %t311, ptr %t304, i64 %t305)
  %t312 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t307, 1
  store { i64, ptr } %t313, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb98
bb55:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t316 = load ptr, ptr %l117, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb56, label %bb57
bb56:
  %t319 = load ptr, ptr %l117, !tbaa !29
  %t320 = load i64, ptr %t319, !range !{i64 0, i64 13}
  %t322 = icmp eq i64 %t320, 8
  store i1 %t322, ptr %l118, !tbaa !21
  br label %bb57
bb57:
  %t323 = load i1, ptr %l118, !tbaa !21
  br i1 %t323, label %bb58, label %bb59
bb58:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [21 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t326, i32 0, i32 1
  %t328 = load { i64, [1 x i64] }, ptr %t327
  store { i64, [1 x i64] } %t328, ptr %l14
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [21 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t332, i32 0, i32 2
  %t334 = load i32, ptr %t333, !range !{i32 0, i32 8}
  store i32 %t334, ptr %l15
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [21 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t338, i32 0, i32 3
  %t340 = load { i64, [4 x i64] }, ptr %t339
  store { i64, [4 x i64] } %t340, ptr %l16
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  %t342 = load i32, ptr %l15, !range !{i32 0, i32 8}
  store i32 %t342, ptr %l127
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s18, ptr %l127, i64 0)
  br label %bb61
bb61:
  %t344 = load ptr, ptr %s18
  %t345 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t346 = load i64, ptr %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t344, i64 %t346)
  %t348 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l129, !tbaa !27
  %t350 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t351 = load ptr, ptr %t350
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %sbgrew.353, label %sbdone.354
sbgrew.353:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.354
sbdone.354:
  %t355 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t363 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s17, ptr %s17, { i64, ptr } %t361)
  store { i64, ptr } %t363, ptr %l131
  br label %bb62
bb62:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, [4 x i64] }, ptr %l16
  %t368 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t364, { i64, [4 x i64] } %t365)
  store { i64, ptr } %t368, ptr %l134
  br label %bb63
bb63:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load { i64, [1 x i64] }, ptr %l14
  %t373 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s17, ptr %t369, { i64, [1 x i64] } %t370)
  store { i64, ptr } %t373, ptr %l137
  br label %bb64
bb64:
  %t374 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t376 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = add i64 %t389, %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t374, i64 %t375)
  %t395 = getelementptr i8, ptr %t394, i64 %t375
  call void @olang_textcopy(ptr %t395, ptr %t377, i64 %t378)
  %t396 = getelementptr i8, ptr %t395, i64 %t378
  call void @olang_textcopy(ptr %t396, ptr %t380, i64 %t381)
  %t397 = getelementptr i8, ptr %t396, i64 %t381
  call void @olang_textcopy(ptr %t397, ptr %t384, i64 %t385)
  %t398 = getelementptr i8, ptr %t397, i64 %t385
  call void @olang_textcopy(ptr %t398, ptr %t387, i64 %t388)
  %t399 = getelementptr i8, ptr %t398, i64 %t388
  call void @olang_textcopy(ptr %t399, ptr %t391, i64 %t392)
  %t400 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t394, 1
  store { i64, ptr } %t401, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb98
bb65:
  %t403 = load ptr, ptr %l1, !tbaa !29
  store ptr %t403, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t404 = load ptr, ptr %l139, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb66, label %bb67
bb66:
  %t407 = load ptr, ptr %l139, !tbaa !29
  %t408 = load i64, ptr %t407, !range !{i64 0, i64 13}
  %t410 = icmp eq i64 %t408, 9
  store i1 %t410, ptr %l140, !tbaa !21
  br label %bb67
bb67:
  %t411 = load i1, ptr %l140, !tbaa !21
  br i1 %t411, label %bb68, label %bb69
bb68:
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [21 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t414, i32 0, i32 1
  %t416 = load %"compiler/mir:Lvalue", ptr %t415
  store %"compiler/mir:Lvalue" %t416, ptr %l17
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t420 = getelementptr { i64, [21 x i64] }, ptr %t418, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t420, i32 0, i32 2
  %t422 = load %"compiler/mir:Lvalue", ptr %t421
  store %"compiler/mir:Lvalue" %t422, ptr %l18
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [21 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t426, i32 0, i32 3
  %t428 = load { i64, [4 x i64] }, ptr %t427
  store { i64, [4 x i64] } %t428, ptr %l19
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s20
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load { i64, [4 x i64] }, ptr %l19
  %t434 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s20, ptr %t430, { i64, [4 x i64] } %t431)
  store { i64, ptr } %t434, ptr %l151
  br label %bb71
bb71:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load %"compiler/mir:Lvalue", ptr %l18
  %t439 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s20, ptr %t435, %"compiler/mir:Lvalue" %t436)
  store { i64, ptr } %t439, ptr %l154
  br label %bb72
bb72:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/mir:Lvalue", ptr %l17
  %t444 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s20, ptr %t440, %"compiler/mir:Lvalue" %t441)
  store { i64, ptr } %t444, ptr %l157
  br label %bb73
bb73:
  %t445 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t447 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t461 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = add i64 %t460, %t463
  %t465 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t445, i64 %t446)
  %t466 = getelementptr i8, ptr %t465, i64 %t446
  call void @olang_textcopy(ptr %t466, ptr %t448, i64 %t449)
  %t467 = getelementptr i8, ptr %t466, i64 %t449
  call void @olang_textcopy(ptr %t467, ptr %t451, i64 %t452)
  %t468 = getelementptr i8, ptr %t467, i64 %t452
  call void @olang_textcopy(ptr %t468, ptr %t455, i64 %t456)
  %t469 = getelementptr i8, ptr %t468, i64 %t456
  call void @olang_textcopy(ptr %t469, ptr %t458, i64 %t459)
  %t470 = getelementptr i8, ptr %t469, i64 %t459
  call void @olang_textcopy(ptr %t470, ptr %t462, i64 %t463)
  %t471 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t465, 1
  store { i64, ptr } %t472, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  br label %bb98
bb74:
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t475 = load ptr, ptr %l159, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb75, label %bb76
bb75:
  %t478 = load ptr, ptr %l159, !tbaa !29
  %t479 = load i64, ptr %t478, !range !{i64 0, i64 13}
  %t481 = icmp eq i64 %t479, 10
  store i1 %t481, ptr %l160, !tbaa !21
  br label %bb76
bb76:
  %t482 = load i1, ptr %l160, !tbaa !21
  br i1 %t482, label %bb77, label %bb78
bb77:
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [21 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t485, i32 0, i32 1
  %t487 = load i32, ptr %t486
  store i32 %t487, ptr %l20, !tbaa !23
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr { i64, [21 x i64] }, ptr %t489, i32 0, i32 1
  %t492 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t491, i32 0, i32 2
  %t493 = load i32, ptr %t492
  store i32 %t493, ptr %l21, !tbaa !23
  br label %bb79
bb78:
  br label %bb82
bb79:
  store %olang.scope zeroinitializer, ptr %s22
  %t495 = load i32, ptr %l20, !tbaa !23
  store i32 %t495, ptr %l167, !tbaa !23
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l168, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/mir:dumper", ptr %t497, i32 0, i32 0
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = getelementptr %"compiler/mir:Fn", ptr %t500, i32 0, i32 16
  %t503 = load i32, ptr %l21, !tbaa !23
  %t505 = sext i32 %t503 to i64
  %t506 = load ptr, ptr @__olang_prog_scope
  %t509 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t506, ptr %t502, i64 %t505)
  store %"compiler/mir:Task" %t509, ptr %l174
  br label %bb80
bb80:
  %t510 = load ptr, ptr %l168, !tbaa !29
  %t511 = load %"compiler/mir:Task", ptr %l174
  %t512 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %s22, ptr %t510, %"compiler/mir:Task" %t511)
  store { i64, ptr } %t512, ptr %l175
  br label %bb81
bb81:
  %t513 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t515 = load i32, ptr %l167, !tbaa !23
  %t516 = sext i32 %t515 to i64
  %t517 = call i64 @__olang_fmt_i64(ptr null, i64 %t516)
  %t518 = add i64 %t514, %t517
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = add i64 %t521, %t524
  %t526 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t525)
  call void @olang_textcopy(ptr %t526, ptr %t513, i64 %t514)
  %t527 = getelementptr i8, ptr %t526, i64 %t514
  %t528 = call i64 @__olang_fmt_i64(ptr %t527, i64 %t516)
  %t529 = getelementptr i8, ptr %t527, i64 %t517
  call void @olang_textcopy(ptr %t529, ptr %t519, i64 %t520)
  %t530 = getelementptr i8, ptr %t529, i64 %t520
  call void @olang_textcopy(ptr %t530, ptr %t523, i64 %t524)
  %t531 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t526, 1
  store { i64, ptr } %t532, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb98
bb82:
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t535 = load ptr, ptr %l177, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb83, label %bb84
bb83:
  %t538 = load ptr, ptr %l177, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 13}
  %t541 = icmp eq i64 %t539, 11
  store i1 %t541, ptr %l178, !tbaa !21
  br label %bb84
bb84:
  %t542 = load i1, ptr %l178, !tbaa !21
  br i1 %t542, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l181, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t543, ptr %l24, !tbaa !27
  br label %bb98
bb88:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t546 = load ptr, ptr %l183, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb89, label %bb90
bb89:
  %t549 = load ptr, ptr %l183, !tbaa !29
  %t550 = load i64, ptr %t549, !range !{i64 0, i64 13}
  %t552 = icmp eq i64 %t550, 12
  store i1 %t552, ptr %l184, !tbaa !21
  br label %bb90
bb90:
  %t553 = load i1, ptr %l184, !tbaa !21
  br i1 %t553, label %bb91, label %bb92
bb91:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [21 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t556, i32 0, i32 1
  %t558 = load i32, ptr %t557
  store i32 %t558, ptr %l22, !tbaa !23
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [21 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t562, i32 0, i32 2
  %t564 = load i32, ptr %t563
  store i32 %t564, ptr %l23, !tbaa !23
  br label %bb93
bb92:
  br label %bb97
bb93:
  store %olang.scope zeroinitializer, ptr %s25
  %t566 = load i32, ptr %l22, !tbaa !23
  store i32 %t566, ptr %l191, !tbaa !23
  %t567 = load i32, ptr %l23, !tbaa !23
  %t568 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t571 = icmp ne i32 %t567, %t568
  br i1 %t571, label %bb94, label %bb95
bb94:
  %t573 = load i32, ptr %l23, !tbaa !23
  %t574 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t577 = sext i32 %t573 to i64
  %t578 = call i64 @__olang_fmt_i64(ptr null, i64 %t577)
  %t579 = add i64 %t575, %t578
  %t580 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t579)
  call void @olang_textcopy(ptr %t580, ptr %t574, i64 %t575)
  %t581 = getelementptr i8, ptr %t580, i64 %t575
  %t582 = call i64 @__olang_fmt_i64(ptr %t581, i64 %t577)
  %t583 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t580, 1
  %t586 = extractvalue { i64, ptr } %t584, 0
  %t587 = extractvalue { i64, ptr } %t584, 1
  %t588 = mul i64 %t586, 1
  %t589 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t588)
  call void @llvm.memcpy.p0.p0.i64(ptr %t589, ptr %t587, i64 %t588, i1 false)
  %t590 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t589, 1
  store { i64, ptr } %t591, ptr %l195, !tbaa !27
  br label %bb96
bb95:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l195, !tbaa !27
  br label %bb96
bb96:
  %t593 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t595 = load i32, ptr %l191, !tbaa !23
  %t596 = sext i32 %t595 to i64
  %t597 = call i64 @__olang_fmt_i64(ptr null, i64 %t596)
  %t598 = add i64 %t594, %t597
  %t599 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t599, 1
  %t601 = extractvalue { i64, ptr } %t599, 0
  %t602 = add i64 %t598, %t601
  %t603 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t602)
  call void @olang_textcopy(ptr %t603, ptr %t593, i64 %t594)
  %t604 = getelementptr i8, ptr %t603, i64 %t594
  %t605 = call i64 @__olang_fmt_i64(ptr %t604, i64 %t596)
  %t606 = getelementptr i8, ptr %t604, i64 %t597
  call void @olang_textcopy(ptr %t606, ptr %t600, i64 %t601)
  %t607 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t603, 1
  store { i64, ptr } %t608, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s25)
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_63d4bc85d5a0ee63_941776bd89ba250f)
  unreachable
bb98:
  %t610 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  store i64 %t611, ptr %l200, !tbaa !24
  %t612 = load i64, ptr %l200, !tbaa !24
  %t613 = mul i64 %t612, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t613)
  %t615 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  store { i64, ptr } %t616, ptr %l201, !tbaa !27
  %t617 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t618 = load ptr, ptr %t617, !tbaa !27
  %t619 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = load i64, ptr %l200, !tbaa !24
  %t622 = mul i64 %t621, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t618, ptr %t620, i64 %t622, i1 false)
  %t623 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t623, ptr %l24, !tbaa !27
  %t624 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t624, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l67 = alloca %"compiler/mir:Call"
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l77 = alloca %"compiler/mir:Call"
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l117 = alloca i32
  %l118 = alloca i32
  %l122 = alloca { i64, ptr }
  %l132 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t11, ptr %l25, !tbaa !27
  br label %bb71
bb4:
  %t13 = load { i64, [8 x i64] }, ptr %l1
  %t15 = extractvalue { i64, [8 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  br label %bb71
bb8:
  %t35 = load { i64, [8 x i64] }, ptr %l1
  %t37 = extractvalue { i64, [8 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 2
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t40, i32 0, i32 0
  %t42 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t42, ptr %l4
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l4
  %t56 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t52, { i64, [4 x i64] } %t53)
  store { i64, ptr } %t56, ptr %l42
  br label %bb12
bb12:
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t69 = sext i32 %t57 to i64
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = sext i32 %t58 to i64
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t59, i64 %t60)
  %t80 = getelementptr i8, ptr %t79, i64 %t60
  call void @olang_textcopy(ptr %t80, ptr %t62, i64 %t63)
  %t81 = getelementptr i8, ptr %t80, i64 %t63
  call void @olang_textcopy(ptr %t81, ptr %t65, i64 %t66)
  %t82 = getelementptr i8, ptr %t81, i64 %t66
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t69)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t76)
  %t87 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t79, 1
  store { i64, ptr } %t88, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb13:
  %t90 = load { i64, [8 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [8 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb14, label %bb15
bb14:
  %t95 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t95, i32 0, i32 0
  %t97 = load { i64, [4 x i64] }, ptr %t96
  store { i64, [4 x i64] } %t97, ptr %l7
  %t99 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t99, i32 0, i32 1
  %t101 = load %"compiler/mir:Range", ptr %t100
  store %"compiler/mir:Range" %t101, ptr %l8
  %t103 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t104 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t103, i32 0, i32 2
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l9, !tbaa !23
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, [4 x i64] }, ptr %l7
  %t111 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %t107, { i64, [4 x i64] } %t108)
  store { i64, ptr } %t111, ptr %l53
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/mir:Range", ptr %l8
  %t116 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %s6, ptr %t112, %"compiler/mir:Range" %t113)
  store { i64, ptr } %t116, ptr %l56
  br label %bb18
bb18:
  %t117 = load i32, ptr %l9, !tbaa !23
  %t118 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t117 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t121, i64 %t122)
  %t140 = getelementptr i8, ptr %t139, i64 %t122
  call void @olang_textcopy(ptr %t140, ptr %t124, i64 %t125)
  %t141 = getelementptr i8, ptr %t140, i64 %t125
  call void @olang_textcopy(ptr %t141, ptr %t128, i64 %t129)
  %t142 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t135)
  %t145 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t138, 1
  store { i64, ptr } %t146, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb19:
  %t148 = load { i64, [8 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [8 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb20, label %bb21
bb20:
  %t153 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32 }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l10, !tbaa !23
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l62, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/mir:Fn", ptr %t158, i32 0, i32 14
  %t161 = load i32, ptr %l10, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t164 = load ptr, ptr @__olang_prog_scope
  %t167 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t164, ptr %t160, i64 %t163)
  store %"compiler/mir:Call" %t167, ptr %l67
  br label %bb23
bb23:
  %t168 = load ptr, ptr %l62, !tbaa !29
  %t169 = load %"compiler/mir:Call", ptr %l67
  %t170 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %t168, %"compiler/mir:Call" %t169)
  store { i64, ptr } %t170, ptr %l68
  br label %bb24
bb24:
  %t171 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t171, ptr %l25, !tbaa !27
  br label %bb71
bb25:
  %t172 = load { i64, [8 x i64] }, ptr %l1
  %t174 = extractvalue { i64, [8 x i64] } %t172, 0
  %t175 = icmp eq i64 %t174, 6
  br i1 %t175, label %bb26, label %bb27
bb26:
  %t177 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32 }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l11, !tbaa !23
  br label %bb28
bb27:
  br label %bb31
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l72, !tbaa !29
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr %"compiler/mir:Fn", ptr %t182, i32 0, i32 14
  %t185 = load i32, ptr %l11, !tbaa !23
  %t187 = sext i32 %t185 to i64
  %t188 = load ptr, ptr @__olang_prog_scope
  %t191 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t188, ptr %t184, i64 %t187)
  store %"compiler/mir:Call" %t191, ptr %l77
  br label %bb29
bb29:
  %t192 = load ptr, ptr %l72, !tbaa !29
  %t193 = load %"compiler/mir:Call", ptr %l77
  %t194 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %s9, ptr %t192, %"compiler/mir:Call" %t193)
  store { i64, ptr } %t194, ptr %l78
  br label %bb30
bb30:
  %t195 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t197 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t195, i64 %t196)
  %t202 = getelementptr i8, ptr %t201, i64 %t196
  call void @olang_textcopy(ptr %t202, ptr %t198, i64 %t199)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t201, 1
  store { i64, ptr } %t204, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb31:
  %t206 = load { i64, [8 x i64] }, ptr %l1
  %t208 = extractvalue { i64, [8 x i64] } %t206, 0
  %t209 = icmp eq i64 %t208, 5
  br i1 %t209, label %bb32, label %bb33
bb32:
  %t211 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t211, i32 0, i32 1
  %t213 = load { i64, [4 x i64] }, ptr %t212
  store { i64, [4 x i64] } %t213, ptr %l12
  br label %bb34
bb33:
  br label %bb39
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load { i64, [4 x i64] }, ptr %l12
  %t217 = extractvalue { i64, [4 x i64] } %t215, 0
  %t218 = icmp eq i64 %t217, 0
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb35, label %bb36
bb35:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load { i64, [4 x i64] }, ptr %l12
  %t226 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %t222, { i64, [4 x i64] } %t223)
  store { i64, ptr } %t226, ptr %l89
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb38
bb37:
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t229 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t227, i64 %t228)
  %t234 = getelementptr i8, ptr %t233, i64 %t228
  call void @olang_textcopy(ptr %t234, ptr %t230, i64 %t231)
  %t235 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t233, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l86, !tbaa !27
  br label %bb38
bb38:
  %t245 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t247 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  store { i64, ptr } %t254, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb39:
  %t256 = load { i64, [8 x i64] }, ptr %l1
  %t258 = extractvalue { i64, [8 x i64] } %t256, 0
  %t259 = icmp eq i64 %t258, 7
  br i1 %t259, label %bb40, label %bb41
bb40:
  %t261 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t261, i32 0, i32 1
  %t263 = load { i64, [4 x i64] }, ptr %t262
  store { i64, [4 x i64] } %t263, ptr %l13
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s14
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, [4 x i64] }, ptr %l13
  %t269 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s14, ptr %t265, { i64, [4 x i64] } %t266)
  store { i64, ptr } %t269, ptr %l98
  br label %bb43
bb43:
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t272 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = add i64 %t271, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t270, i64 %t271)
  %t277 = getelementptr i8, ptr %t276, i64 %t271
  call void @olang_textcopy(ptr %t277, ptr %t273, i64 %t274)
  %t278 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t276, 1
  store { i64, ptr } %t279, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb44:
  %t281 = load { i64, [8 x i64] }, ptr %l1
  %t283 = extractvalue { i64, [8 x i64] } %t281, 0
  %t284 = icmp eq i64 %t283, 11
  br i1 %t284, label %bb45, label %bb46
bb45:
  %t286 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t287 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t286, i32 0, i32 1
  %t288 = load { i64, [4 x i64] }, ptr %t287
  store { i64, [4 x i64] } %t288, ptr %l14
  %t290 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t290, i32 0, i32 2
  %t292 = load i32, ptr %t291
  store i32 %t292, ptr %l15, !tbaa !23
  %t294 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t294, i32 0, i32 3
  %t296 = load %"compiler/mir:Range", ptr %t295
  store %"compiler/mir:Range" %t296, ptr %l16
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s16
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, [4 x i64] }, ptr %l14
  %t302 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s16, ptr %t298, { i64, [4 x i64] } %t299)
  store { i64, ptr } %t302, ptr %l107
  br label %bb48
bb48:
  %t303 = load i32, ptr %l15, !tbaa !23
  %t304 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 1
  %t305 = load i32, ptr %t304, !tbaa !23
  %t306 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t308 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t316 = sext i32 %t303 to i64
  %t317 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t318 = add i64 %t314, %t317
  %t319 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t323 = sext i32 %t305 to i64
  %t324 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t325 = add i64 %t321, %t324
  %t326 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t325)
  call void @olang_textcopy(ptr %t326, ptr %t306, i64 %t307)
  %t327 = getelementptr i8, ptr %t326, i64 %t307
  call void @olang_textcopy(ptr %t327, ptr %t309, i64 %t310)
  %t328 = getelementptr i8, ptr %t327, i64 %t310
  call void @olang_textcopy(ptr %t328, ptr %t312, i64 %t313)
  %t329 = getelementptr i8, ptr %t328, i64 %t313
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t316)
  %t331 = getelementptr i8, ptr %t329, i64 %t317
  call void @olang_textcopy(ptr %t331, ptr %t319, i64 %t320)
  %t332 = getelementptr i8, ptr %t331, i64 %t320
  %t333 = call i64 @__olang_fmt_i64(ptr %t332, i64 %t323)
  %t334 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t326, 1
  store { i64, ptr } %t335, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb71
bb49:
  %t337 = load { i64, [8 x i64] }, ptr %l1
  %t339 = extractvalue { i64, [8 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 8
  br i1 %t340, label %bb50, label %bb51
bb50:
  %t342 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t342, i32 0, i32 1
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l17, !tbaa !23
  %t346 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t347 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t346, i32 0, i32 2
  %t348 = load i32, ptr %t347
  store i32 %t348, ptr %l18, !tbaa !23
  %t350 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t350, i32 0, i32 3
  %t352 = load i32, ptr %t351
  store i32 %t352, ptr %l19, !tbaa !23
  %t354 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t354, i32 0, i32 4
  %t356 = load i32, ptr %t355
  store i32 %t356, ptr %l20, !tbaa !23
  br label %bb52
bb51:
  br label %bb56
bb52:
  store %olang.scope zeroinitializer, ptr %s18
  %t358 = load i32, ptr %l17, !tbaa !23
  store i32 %t358, ptr %l117, !tbaa !23
  %t359 = load i32, ptr %l18, !tbaa !23
  store i32 %t359, ptr %l118, !tbaa !23
  %t360 = load i32, ptr %l20, !tbaa !23
  %t361 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t364 = icmp ne i32 %t360, %t361
  br i1 %t364, label %bb53, label %bb54
bb53:
  %t366 = load i32, ptr %l19, !tbaa !23
  %t367 = load i32, ptr %l20, !tbaa !23
  %t368 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t371 = sext i32 %t366 to i64
  %t372 = call i64 @__olang_fmt_i64(ptr null, i64 %t371)
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t378 = sext i32 %t367 to i64
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t378)
  %t380 = add i64 %t376, %t379
  %t381 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t380)
  call void @olang_textcopy(ptr %t381, ptr %t368, i64 %t369)
  %t382 = getelementptr i8, ptr %t381, i64 %t369
  %t383 = call i64 @__olang_fmt_i64(ptr %t382, i64 %t371)
  %t384 = getelementptr i8, ptr %t382, i64 %t372
  call void @olang_textcopy(ptr %t384, ptr %t374, i64 %t375)
  %t385 = getelementptr i8, ptr %t384, i64 %t375
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t378)
  %t387 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t381, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  store { i64, ptr } %t395, ptr %l122, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l122, !tbaa !27
  br label %bb55
bb55:
  %t397 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t399 = load i32, ptr %l117, !tbaa !23
  %t400 = sext i32 %t399 to i64
  %t401 = call i64 @__olang_fmt_i64(ptr null, i64 %t400)
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = load i32, ptr %l118, !tbaa !23
  %t407 = sext i32 %t406 to i64
  %t408 = call i64 @__olang_fmt_i64(ptr null, i64 %t407)
  %t409 = add i64 %t405, %t408
  %t410 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t413)
  call void @olang_textcopy(ptr %t414, ptr %t397, i64 %t398)
  %t415 = getelementptr i8, ptr %t414, i64 %t398
  %t416 = call i64 @__olang_fmt_i64(ptr %t415, i64 %t400)
  %t417 = getelementptr i8, ptr %t415, i64 %t401
  call void @olang_textcopy(ptr %t417, ptr %t403, i64 %t404)
  %t418 = getelementptr i8, ptr %t417, i64 %t404
  %t419 = call i64 @__olang_fmt_i64(ptr %t418, i64 %t407)
  %t420 = getelementptr i8, ptr %t418, i64 %t408
  call void @olang_textcopy(ptr %t420, ptr %t411, i64 %t412)
  %t421 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t414, 1
  store { i64, ptr } %t422, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb71
bb56:
  %t424 = load { i64, [8 x i64] }, ptr %l1
  %t426 = extractvalue { i64, [8 x i64] } %t424, 0
  %t427 = icmp eq i64 %t426, 9
  br i1 %t427, label %bb57, label %bb58
bb57:
  %t429 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t430 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t429, i32 0, i32 1
  %t431 = load i32, ptr %t430, !range !{i32 0, i32 15}
  store i32 %t431, ptr %l21
  %t433 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t433, i32 0, i32 2
  %t435 = load { i64, [4 x i64] }, ptr %t434
  store { i64, [4 x i64] } %t435, ptr %l22
  br label %bb59
bb58:
  br label %bb66
bb59:
  store %olang.scope zeroinitializer, ptr %s21
  %t437 = load i32, ptr %l21, !range !{i32 0, i32 15}
  store i32 %t437, ptr %l132
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s22, ptr %l132, i64 0)
  br label %bb60
bb60:
  %t439 = load ptr, ptr %s22
  %t440 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t441 = load i64, ptr %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t439, i64 %t441)
  %t443 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  store { i64, ptr } %t444, ptr %l134, !tbaa !27
  %t445 = getelementptr %olang.builder, ptr %s22, i32 0, i32 3
  %t446 = load ptr, ptr %t445
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %sbgrew.448, label %sbdone.449
sbgrew.448:
  call void @__olang_sb_done(ptr %s22)
  br label %sbdone.449
sbdone.449:
  %t450 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  %t452 = extractvalue { i64, ptr } %t450, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t458 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s21, ptr %s21, { i64, ptr } %t456)
  store { i64, ptr } %t458, ptr %l136
  br label %bb61
bb61:
  %t459 = load { i64, [4 x i64] }, ptr %l22
  %t461 = extractvalue { i64, [4 x i64] } %t459, 0
  %t462 = icmp eq i64 %t461, 0
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb62, label %bb63
bb62:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load { i64, [4 x i64] }, ptr %l22
  %t470 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t466, { i64, [4 x i64] } %t467)
  store { i64, ptr } %t470, ptr %l143
  br label %bb64
bb63:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l140, !tbaa !27
  br label %bb65
bb64:
  %t471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t473 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = add i64 %t472, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t471, i64 %t472)
  %t478 = getelementptr i8, ptr %t477, i64 %t472
  call void @olang_textcopy(ptr %t478, ptr %t474, i64 %t475)
  %t479 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t477, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = extractvalue { i64, ptr } %t480, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  store { i64, ptr } %t487, ptr %l140, !tbaa !27
  br label %bb65
bb65:
  %t489 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t495, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = add i64 %t494, %t497
  %t499 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t498)
  call void @olang_textcopy(ptr %t499, ptr %t489, i64 %t490)
  %t500 = getelementptr i8, ptr %t499, i64 %t490
  call void @olang_textcopy(ptr %t500, ptr %t492, i64 %t493)
  %t501 = getelementptr i8, ptr %t500, i64 %t493
  call void @olang_textcopy(ptr %t501, ptr %t496, i64 %t497)
  %t502 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t499, 1
  store { i64, ptr } %t503, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb71
bb66:
  %t505 = load { i64, [8 x i64] }, ptr %l1
  %t507 = extractvalue { i64, [8 x i64] } %t505, 0
  %t508 = icmp eq i64 %t507, 10
  br i1 %t508, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l149, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t510, ptr %l25, !tbaa !27
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_8b20d2ead933ce67_842549c98b36ec43)
  unreachable
bb71:
  %t512 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l151, !tbaa !24
  %t514 = load i64, ptr %l151, !tbaa !24
  %t515 = mul i64 %t514, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t515)
  %t517 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  store { i64, ptr } %t518, ptr %l152, !tbaa !27
  %t519 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = load i64, ptr %l151, !tbaa !24
  %t524 = mul i64 %t523, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t520, ptr %t522, i64 %t524, i1 false)
  %t525 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t525, ptr %l25, !tbaa !27
  %t526 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t526, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l25 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca { i64, [4 x i64] }
  %l85 = alloca i32
  %l88 = alloca i32
  %l98 = alloca i32
  %l102 = alloca i1
  %l105 = alloca { i64, ptr }
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l118 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca { i64, ptr }
  %l133 = alloca i32
  %l139 = alloca i32
  %l143 = alloca i1
  %l146 = alloca ptr
  %l149 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l25
  br label %bb1
bb1:
  %t16 = load i32, ptr %l25, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l31
  br label %bb4
bb3:
  br label %bb34
bb4:
  %t28 = load i32, ptr %l31, !tbaa !23
  store i32 %t28, ptr %l7, !tbaa !23
  %t29 = load i32, ptr %l7, !tbaa !23
  %t31 = icmp eq i32 %t29, 0
  br i1 %t31, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb8
bb6:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l37
  br label %bb7
bb7:
  %t38 = load i32, ptr %l37, !range !{i32 0, i32 33}
  %t40 = trunc i64 26 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l34, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l44
  br label %bb11
bb11:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l44, !tbaa !24
  %t54 = icmp ne i64 %t52, %t51
  store i1 %t54, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l41, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l47, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l50
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t74 = call i64 @__olang_fmt_i64(ptr null, i64 %t63)
  %t75 = add i64 %t72, %t74
  %t76 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t64, i64 %t65)
  %t80 = getelementptr i8, ptr %t79, i64 %t65
  call void @olang_textcopy(ptr %t80, ptr %t67, i64 %t68)
  %t81 = getelementptr i8, ptr %t80, i64 %t68
  call void @olang_textcopy(ptr %t81, ptr %t70, i64 %t71)
  %t82 = getelementptr i8, ptr %t81, i64 %t71
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t63)
  %t84 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t84, ptr %t76, i64 %t77)
  %t85 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t79, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t94, { i64, ptr } %t93)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb23
bb20:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l61, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb22
bb22:
  %t124 = load i64, ptr %l61, !tbaa !24
  store i64 %t124, ptr %l58, !tbaa !24
  br label %bb23
bb23:
  %t125 = load i64, ptr %l58, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t126 = load i64, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l13, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l79, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l80, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/mir:Range", ptr %l3
  %t148 = load i64, ptr %l13, !tbaa !24
  %t152 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t146, %"compiler/mir:Range" %t147, i64 %t148)
  store { i64, [4 x i64] } %t152, ptr %l84
  br label %bb28
bb28:
  %t153 = load ptr, ptr %l80, !tbaa !29
  %t154 = load { i64, [4 x i64] }, ptr %l84
  %t155 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t153, { i64, [4 x i64] } %t154)
  store i32 %t155, ptr %l85
  br label %bb29
bb29:
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load i32, ptr %l6, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l88
  br label %bb30
bb30:
  %t161 = load i64, ptr %l13, !tbaa !24
  %t162 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t161)
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t162, i64 %t163)
  %t168 = getelementptr i8, ptr %t167, i64 %t163
  %t169 = call i64 @__olang_fmt_i64(ptr %t168, i64 %t161)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = load ptr, ptr %l79, !tbaa !29
  %t180 = load i32, ptr %l85, !tbaa !23
  %t181 = load i32, ptr %l88, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s5, ptr %t179, i32 %t180, i32 %t181, { i64, ptr } %t178)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t183 = load i64, ptr %l12, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l12, !tbaa !24
  br label %bb24
bb33:
  %t187 = load i32, ptr %l1, !tbaa !23
  store i32 %t187, ptr %rv
  br label %ret
bb34:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/mir:verifier", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l98
  br label %bb35
bb35:
  %t197 = load i32, ptr %l98, !tbaa !23
  store i32 %t197, ptr %l14, !tbaa !23
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/mir:verifier", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t201, i32 %t202)
  store i1 %t205, ptr %l102
  br label %bb36
bb36:
  %t206 = load i1, ptr %l102, !tbaa !21
  store i1 %t206, ptr %l15, !tbaa !21
  %t207 = load ptr, ptr %l4, !tbaa !29
  %t208 = load i32, ptr %l14, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l105
  br label %bb37
bb37:
  %t212 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t212, ptr %l16, !tbaa !27
  %t213 = load i1, ptr %l15, !tbaa !21
  br i1 %t213, label %bb38, label %bb39
bb38:
  %t215 = load i64, ptr %l2, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb42
bb41:
  %t219 = load i64, ptr %l2, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t225 = icmp sge i64 %t219, %t222
  store i1 %t225, ptr %l109, !tbaa !21
  br label %bb42
bb42:
  %t227 = load i1, ptr %l109, !tbaa !21
  br i1 %t227, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l2, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l1, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %t230, i32 %t231)
  store { i64, ptr } %t234, ptr %l118
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t235 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t237 = load i64, ptr %l115, !tbaa !24
  %t238 = call i64 @__olang_fmt_i64(ptr null, i64 %t237)
  %t239 = add i64 %t236, %t238
  %t240 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = add i64 %t242, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t235, i64 %t236)
  %t248 = getelementptr i8, ptr %t247, i64 %t236
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t237)
  %t250 = getelementptr i8, ptr %t248, i64 %t238
  call void @olang_textcopy(ptr %t250, ptr %t240, i64 %t241)
  %t251 = getelementptr i8, ptr %t250, i64 %t241
  call void @olang_textcopy(ptr %t251, ptr %t244, i64 %t245)
  %t252 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t247, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } %t253, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t261 = load ptr, ptr %l114, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t261, { i64, ptr } %t260)
  br label %bb46
bb46:
  %t263 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  store i32 %t263, ptr %rv
  br label %ret
bb47:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l122, !tbaa !29
  %t266 = load i32, ptr %l1, !tbaa !23
  store i32 %t266, ptr %l123, !tbaa !23
  %t267 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t267, ptr %l124, !tbaa !27
  %t268 = load i64, ptr %l2, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  %t275 = icmp ne i32 %t273, 0
  br i1 %t275, label %bb48, label %bb49
bb48:
  %t277 = load ptr, ptr %l4, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t278, ptr %l130, !tbaa !27
  %t279 = load i64, ptr %l2, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i32, ptr %t282, i64 %t279
  %t284 = load i32, ptr %t283, !tbaa !33
  %t287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t277, i32 %t284)
  store i32 %t287, ptr %l133
  br label %bb50
bb49:
  store i32 0, ptr %l128, !tbaa !23
  br label %bb51
bb50:
  %t288 = load i32, ptr %l133, !tbaa !23
  store i32 %t288, ptr %l128, !tbaa !23
  br label %bb51
bb51:
  %t289 = load %"compiler/mir:Range", ptr %l3
  %t290 = load ptr, ptr %l122, !tbaa !29
  %t291 = load i32, ptr %l123, !tbaa !23
  %t292 = load i32, ptr %l128, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t290, i32 %t291, i32 %t292, %"compiler/mir:Range" %t289)
  br label %bb52
bb52:
  %t294 = load i32, ptr %l1, !tbaa !23
  store i32 %t294, ptr %rv
  br label %ret
bb53:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/mir:verifier", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load i32, ptr %l1, !tbaa !23
  %t303 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t299, i32 %t300)
  store i32 %t303, ptr %l139
  br label %bb54
bb54:
  %t304 = load i32, ptr %l139, !tbaa !23
  store i32 %t304, ptr %l17, !tbaa !23
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/mir:verifier", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t309 = load i32, ptr %l1, !tbaa !23
  %t312 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t308, i32 %t309)
  store i1 %t312, ptr %l143
  br label %bb55
bb55:
  %t313 = load i1, ptr %l143, !tbaa !21
  %t316 = xor i1 %t313, true
  br i1 %t316, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l146, !tbaa !29
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l1, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t319, i32 %t320)
  store { i64, ptr } %t323, ptr %l149
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t324 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t326 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t324, i64 %t325)
  %t334 = getelementptr i8, ptr %t333, i64 %t325
  call void @olang_textcopy(ptr %t334, ptr %t327, i64 %t328)
  %t335 = getelementptr i8, ptr %t334, i64 %t328
  call void @olang_textcopy(ptr %t335, ptr %t330, i64 %t331)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t333, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t345 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t345, { i64, ptr } %t344)
  br label %bb59
bb59:
  %t347 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  store i32 %t347, ptr %rv
  br label %ret
bb60:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l1, !tbaa !23
  %t351 = load i32, ptr %l17, !tbaa !23
  %t352 = load %"compiler/mir:Range", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t349, i32 %t350, i32 %t351, %"compiler/mir:Range" %t352)
  br label %bb61
bb61:
  %t357 = load i32, ptr %l1, !tbaa !23
  store i32 %t357, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l57 = alloca i64
  %l60 = alloca i64
  %l78 = alloca ptr
  %l82 = alloca { i64, [4 x i64] }
  %l83 = alloca i32
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca { i64, ptr }
  %l108 = alloca i64
  %l122 = alloca i32
  %l125 = alloca i32
  %l151 = alloca { i64, [1 x i64] }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l24, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l27
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l24, !tbaa !29
  %t13 = load i32, ptr %l27, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t14, ptr %l28
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t15, ptr %l6, !tbaa !27
  %t16 = load { i64, [7 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd)
  unreachable
bb11:
  %t21 = load i1, ptr %l29, !tbaa !21
  store i1 %t21, ptr %l7, !tbaa !21
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = icmp ne i64 %t24, %t28
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load i1, ptr %l7, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb14:
  %t35 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  store i1 %t44, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l39, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t59 = sext i32 %t52 to i64
  %t60 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t66 = call i64 @__olang_fmt_i64(ptr null, i64 %t55)
  %t67 = add i64 %t64, %t66
  %t68 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t56, i64 %t57)
  %t72 = getelementptr i8, ptr %t71, i64 %t57
  %t73 = call i64 @__olang_fmt_i64(ptr %t72, i64 %t59)
  %t74 = getelementptr i8, ptr %t72, i64 %t60
  call void @olang_textcopy(ptr %t74, ptr %t62, i64 %t63)
  %t75 = getelementptr i8, ptr %t74, i64 %t63
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t55)
  %t77 = getelementptr i8, ptr %t75, i64 %t66
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t71, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t50, { i64, ptr } %t86)
  br label %bb20
bb19:
  store i64 0, ptr %l8, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb21, label %bb22
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb21:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb26
bb23:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l60, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb26
bb26:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t121 = load i64, ptr %l12, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb29:
  br label %bb30
bb30:
  %t129 = load i64, ptr %l8, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l13, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l78, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/mir:Range", ptr %l3
  %t142 = load i64, ptr %l13, !tbaa !24
  %t146 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t140, %"compiler/mir:Range" %t141, i64 %t142)
  store { i64, [4 x i64] } %t146, ptr %l82
  br label %bb31
bb31:
  %t147 = load ptr, ptr %l78, !tbaa !29
  %t148 = load { i64, [4 x i64] }, ptr %l82
  %t149 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t147, { i64, [4 x i64] } %t148)
  store i32 %t149, ptr %l83
  br label %bb32
bb32:
  %t150 = load i32, ptr %l83, !tbaa !23
  store i32 %t150, ptr %l14, !tbaa !23
  %t151 = load i1, ptr %l7, !tbaa !21
  br i1 %t151, label %bb33, label %bb34
bb33:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t154, ptr %l87, !tbaa !27
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t163 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %t153, i32 %t160)
  store i1 %t163, ptr %l90
  br label %bb35
bb34:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb36
bb35:
  %t164 = load i1, ptr %l90, !tbaa !21
  store i1 %t164, ptr %l85, !tbaa !21
  br label %bb36
bb36:
  %t165 = load i1, ptr %l85, !tbaa !21
  br i1 %t165, label %bb37, label %bb38
bb37:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l94
  br label %bb39
bb38:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb40
bb39:
  %t171 = load i1, ptr %l94, !tbaa !21
  store i1 %t171, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t172 = load i1, ptr %l91, !tbaa !21
  br i1 %t172, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb42:
  br label %bb43
bb43:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l14, !tbaa !23
  %t175 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t175, ptr %l97, !tbaa !27
  %t176 = load i64, ptr %l13, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t176
  %t181 = load i32, ptr %t180, !tbaa !33
  %t182 = load i64, ptr %l13, !tbaa !24
  %t183 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t182)
  %t187 = add i64 %t184, %t186
  %t188 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t187)
  call void @olang_textcopy(ptr %t188, ptr %t183, i64 %t184)
  %t189 = getelementptr i8, ptr %t188, i64 %t184
  %t190 = call i64 @__olang_fmt_i64(ptr %t189, i64 %t182)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t188, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s7, ptr %t173, i32 %t174, i32 %t181, { i64, ptr } %t199)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t204 = load i64, ptr %l12, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l12, !tbaa !24
  br label %bb27
bb46:
  br label %bb47
bb47:
  %t208 = load ptr, ptr %l5, !tbaa !29
  %t209 = load { i64, [7 x i64] }, ptr %l1
  %t210 = load i32, ptr %l2, !tbaa !23
  %t214 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t208, { i64, [7 x i64] } %t209, i32 %t210)
  store i64 %t214, ptr %l108
  br label %bb48
bb48:
  %t215 = load i64, ptr %l108, !tbaa !24
  store i64 %t215, ptr %l15, !tbaa !24
  %t216 = load i64, ptr %l15, !tbaa !24
  %t217 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  %t223 = icmp ne i64 %t216, %t220
  br i1 %t223, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t227 = load i32, ptr %t226, !tbaa !23
  %t228 = load i64, ptr %l15, !tbaa !24
  %t229 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t232 = sext i32 %t227 to i64
  %t233 = call i64 @__olang_fmt_i64(ptr null, i64 %t232)
  %t234 = add i64 %t230, %t233
  %t235 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t239 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t229, i64 %t230)
  %t242 = getelementptr i8, ptr %t241, i64 %t230
  %t243 = call i64 @__olang_fmt_i64(ptr %t242, i64 %t232)
  %t244 = getelementptr i8, ptr %t242, i64 %t233
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  %t246 = call i64 @__olang_fmt_i64(ptr %t245, i64 %t228)
  %t247 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t241, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t225, { i64, ptr } %t255)
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb52:
  store i32 0, ptr %l16, !tbaa !23
  %t258 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t259 = load i32, ptr %t258, !tbaa !23
  store i32 %t259, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t261 = load i32, ptr %l17, !tbaa !23
  %t262 = load i32, ptr %l16, !tbaa !23
  %t265 = icmp sgt i32 %t261, %t262
  br i1 %t265, label %bb53, label %bb54
bb53:
  %t267 = load i32, ptr %l18, !tbaa !23
  %t269 = icmp sgt i32 %t267, 0
  br i1 %t269, label %bb55, label %bb56
bb54:
  store i32 0, ptr %l122, !tbaa !23
  br label %bb58
bb55:
  %t271 = load i32, ptr %l17, !tbaa !23
  %t272 = load i32, ptr %l16, !tbaa !23
  %t275 = sub i32 %t271, %t272
  %t276 = load i32, ptr %l18, !tbaa !23
  %t279 = add i32 %t275, %t276
  %t281 = sub i32 %t279, 1
  %t282 = load i32, ptr %l18, !tbaa !23
  %t285 = sdiv i32 %t281, %t282
  store i32 %t285, ptr %l125, !tbaa !23
  br label %bb57
bb56:
  store i32 0, ptr %l125, !tbaa !23
  br label %bb57
bb57:
  %t287 = load i32, ptr %l125, !tbaa !23
  store i32 %t287, ptr %l122, !tbaa !23
  br label %bb58
bb58:
  %t288 = load i32, ptr %l122, !tbaa !23
  store i32 %t288, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb59
bb59:
  %t289 = load i32, ptr %l20, !tbaa !23
  %t290 = load i32, ptr %l19, !tbaa !23
  %t293 = icmp slt i32 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb60, label %bb61
bb60:
  br label %bb69
bb61:
  br label %bb62
bb62:
  %t297 = load i32, ptr %l16, !tbaa !23
  %t298 = load i32, ptr %l20, !tbaa !23
  %t299 = load i32, ptr %l18, !tbaa !23
  %t302 = mul i32 %t298, %t299
  %t305 = add i32 %t297, %t302
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/mir:verifier", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/mir:Fn", ptr %t310, i32 0, i32 12
  %t313 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t314 = load i32, ptr %t313, !tbaa !23
  %t316 = sext i32 %t314 to i64
  %t319 = sext i32 %t305 to i64
  %t322 = add i64 %t316, %t319
  %t325 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t312, i64 %t322)
  store { i64, [1 x i64] } %t325, ptr %l151
  br label %bb63
bb63:
  %t326 = load { i64, [1 x i64] }, ptr %l151
  %t328 = extractvalue { i64, [1 x i64] } %t326, 0
  %t329 = icmp eq i64 %t328, 3
  br i1 %t329, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t331 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t331, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t333 = load i32, ptr %l20, !tbaa !23
  %t335 = add i32 %t333, 1
  store i32 %t335, ptr %l20, !tbaa !23
  br label %bb59
bb69:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:verifier", ptr %t15, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t17, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t19, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:verifier", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t33, i64 %t34)
  %t42 = getelementptr i8, ptr %t41, i64 %t34
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t32)
  %t44 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t38, i64 %t39)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t41, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t28, { i64, ptr } %t53)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:verifier", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/mir:verifier", ptr %t59, i32 0, i32 3
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 4
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t66)
  %t77 = add i64 %t74, %t76
  %t78 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t67, i64 %t68)
  %t82 = getelementptr i8, ptr %t81, i64 %t68
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t62)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t66)
  %t87 = getelementptr i8, ptr %t85, i64 %t76
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t81, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t58, { i64, ptr } %t96)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/mir:verifier", ptr %t99, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %a1)
  br label %bb13
bb13:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t107, i8 10)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l14 = alloca %"compiler/mir:ScopeInfo"
  %l24 = alloca { i64, [1 x i64] }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 8
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:ScopeInfo" %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:ScopeInfo", ptr %l14, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 7}
  %t25 = trunc i64 6 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l5, !tbaa !21
  br label %bb15
bb5:
  %t28 = load { i64, [1 x i64] }, ptr %l1
  %t30 = extractvalue { i64, [1 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/mir:Fn", ptr %t40, i32 0, i32 6
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t42, i64 %t43)
  store { i64, [1 x i64] } %t46, ptr %l24
  br label %bb9
bb9:
  %t47 = load { i64, [1 x i64] }, ptr %l24
  %t49 = extractvalue { i64, [1 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 5
  store i1 %t50, ptr %l5, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9c289c76542078e7_53d9d4aa9af07973)
  unreachable
bb15:
  %t52 = load i1, ptr %l5, !tbaa !21
  %t55 = xor i1 %t52, true
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i32
  %rv = alloca i32
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i1, ptr %l9, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t20 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t14, i32 %a1, i64 %a2)
  store i64 %t20, ptr %l15
  br label %bb4
bb4:
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t22 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp ne i64 %t22, %t21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l11, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l22
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l25
  br label %bb10
bb10:
  %t40 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t43 = or i64 %t41, %t40
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i32, ptr %l22, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t44, i32 %t45, i64 %t43)
  store i32 %t47, ptr %l28
  br label %bb11
bb11:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_62f33ceaa6d0d243_a40627fd170062cf)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t11 = trunc i64 21 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l12
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = add i64 %t23, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = getelementptr i8, ptr %t28, i64 %t23
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t39, { i64, ptr } %t38)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l76 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t19 = trunc i64 22 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l25
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = load i32, ptr %l25, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l26
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l28, !tbaa !24
  %t35 = load i64, ptr %l28, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = icmp sle i64 %t38, 2305843009213693951
  br i1 %t39, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb9:
  %t41 = load i64, ptr %l28, !tbaa !24
  %t42 = mul i64 %t41, 4
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb11:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb16
bb13:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l40, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb15
bb15:
  %t77 = load i64, ptr %l40, !tbaa !24
  store i64 %t77, ptr %l37, !tbaa !24
  br label %bb16
bb16:
  %t78 = load i64, ptr %l37, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l1, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l62, !tbaa !27
  %t102 = load i64, ptr %l11, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t98, i32 %t99, i64 %t100, i32 %t107)
  store i32 %t112, ptr %l65
  br label %bb21
bb21:
  %t113 = load i32, ptr %l65, !tbaa !23
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t114
  store i32 %t113, ptr %t117, !tbaa !33
  br label %bb22
bb22:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l10, !tbaa !24
  br label %bb17
bb23:
  %t122 = load ptr, ptr %l2, !tbaa !29
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t123, { i64, ptr } %t124)
  store i32 %t127, ptr %l71
  br label %bb24
bb24:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load i32, ptr %l71, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t130, ptr %l72
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t131 = load i32, ptr %l72, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i32, ptr %l3, !tbaa !23
  %t138 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t132, i32 %t133, i64 0, i32 %t134)
  store i32 %t138, ptr %l76
  br label %bb27
bb27:
  %t139 = load i32, ptr %l76, !tbaa !23
  store i32 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l16
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l12, !tbaa !23
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  %t28 = load i32, ptr %l12, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t33, ptr %l21
  br label %bb8
bb8:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i32, ptr %l4, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i32, ptr %l29, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l30
  br label %bb12
bb12:
  %t50 = load i32, ptr %l30, !tbaa !23
  %t51 = icmp eq i32 %t50, 7
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l14, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/mir:verifier", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 20
  %t56 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = sext i32 %t48 to i64
  %t65 = add i64 %t59, %t62
  %t68 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t55, i64 %t65)
  store i32 %t68, ptr %l43
  br label %bb11
bb11:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l9, !tbaa !23
  %t70 = load i32, ptr %l9, !tbaa !23
  %t72 = icmp slt i32 %t70, 0
  br i1 %t72, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb14
bb13:
  %t74 = load i32, ptr %l9, !tbaa !23
  %t75 = load i64, ptr %l2, !tbaa !24
  %t77 = trunc i64 %t75 to i32
  %t80 = icmp sge i32 %t74, %t77
  store i1 %t80, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i32, ptr %l9, !tbaa !23
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t90 = add i64 %t87, %t89
  %t91 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t95 = sext i32 %t85 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t86, i64 %t87)
  %t102 = getelementptr i8, ptr %t101, i64 %t87
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t84)
  %t104 = getelementptr i8, ptr %t102, i64 %t89
  call void @olang_textcopy(ptr %t104, ptr %t91, i64 %t92)
  %t105 = getelementptr i8, ptr %t104, i64 %t92
  %t106 = call i64 @__olang_fmt_i64(ptr %t105, i64 %t95)
  %t107 = getelementptr i8, ptr %t105, i64 %t96
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t101, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t83, { i64, ptr } %t116)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t119 = load i32, ptr %l7, !tbaa !23
  %t121 = add i32 %t119, 1
  store i32 %t121, ptr %l7, !tbaa !23
  br label %bb7
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t40)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca %"compiler/mir:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 7
  %t9 = sext i32 %a1 to i64
  %t12 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t6, i64 %t9)
  store %"compiler/mir:Local" %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/mir:Local", ptr %l7, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t13 = sext i32 %t9 to i64
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = getelementptr i8, ptr %t16, i64 %t11
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t13)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l11, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l57 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l18
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i32, ptr %l18, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t33, ptr %l23
  br label %bb8
bb8:
  %t34 = load i32, ptr %l23, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb12
bb10:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb11
bb11:
  %t46 = load i32, ptr %l30, !tbaa !23
  %t47 = icmp ne i32 %t46, 0
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l35
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t77, { i64, ptr } %t76)
  br label %bb16
bb16:
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t79, ptr %rv
  br label %ret
bb17:
  %t81 = load ptr, ptr %l4, !tbaa !29
  store ptr %t81, ptr %l39, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  store ptr %t82, ptr %l40, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t83, { i64, [4 x i64] } %a2)
  store i32 %t87, ptr %l43
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load i32, ptr %l43, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t90, ptr %l44
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t93, ptr %l45
  br label %bb20
bb20:
  %t94 = load i1, ptr %l45, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t97, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t99 = load { i64, [4 x i64] }, ptr %l3
  %t101 = extractvalue { i64, [4 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 0
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l51, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, [4 x i64] }, ptr %l3
  %t111 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t107, { i64, [4 x i64] } %t108)
  store i32 %t111, ptr %l54
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t113 = load i32, ptr %l6, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l57
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l51, !tbaa !29
  %t118 = load i32, ptr %l54, !tbaa !23
  %t119 = load i32, ptr %l57, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %t117, i32 %t118, i32 %t119, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t120 = load i32, ptr %l1, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t10, %"compiler/mir:Lvalue" %t11)
  br label %bb4
bb4:
  br label %bb22
bb5:
  %t14 = load { i64, [4 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [4 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 3
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = icmp slt i32 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb12
bb10:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:verifier", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/mir:Fn", ptr %t33, i32 0, i32 19
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l20
  br label %bb11
bb11:
  %t38 = load i64, ptr %l16, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = icmp sge i64 %t38, %t39
  store i1 %t40, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l14, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t45 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t48 = sext i32 %t44 to i64
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = getelementptr i8, ptr %t51, i64 %t46
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t48)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t43, { i64, ptr } %t62)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_293fa35c34966465_23dfef653c6d5c71)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l4 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  br label %bb16
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Lvalue", ptr %t14
  store %"compiler/mir:Lvalue" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t18 = load %"compiler/mir:Lvalue", ptr %l2
  %t21 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t18)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb16
bb9:
  %t23 = load { i64, [4 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [4 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb14
bb11:
  %t32 = load { i64, [4 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [4 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 3
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9)
  unreachable
bb16:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l8 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t8 = trunc i64 3 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t13 = trunc i64 4 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t23 = trunc i64 6 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp eq i32 %t27, 2
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb21
bb10:
  %t31 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t33 = trunc i64 0 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 43}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l8, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97)
  unreachable
bb21:
  %t46 = load i1, ptr %l8, !tbaa !21
  %t49 = xor i1 %t46, true
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 43}
  store i32 %t52, ptr %l28
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s5, ptr %l28, i64 0)
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t54 = load ptr, ptr %s5
  %t55 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l30, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.64
sbdone.64:
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s4, ptr %s4, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l32
  br label %bb25
bb25:
  %t74 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t76 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t78 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t86 = sext i32 %t75 to i64
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t76, i64 %t77)
  %t93 = getelementptr i8, ptr %t92, i64 %t77
  call void @olang_textcopy(ptr %t93, ptr %t79, i64 %t80)
  %t94 = getelementptr i8, ptr %t93, i64 %t80
  call void @olang_textcopy(ptr %t94, ptr %t82, i64 %t83)
  %t95 = getelementptr i8, ptr %t94, i64 %t83
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t86)
  %t97 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t89, i64 %t90)
  %t98 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t92, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } %t106)
  br label %bb26
bb26:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t109, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l4, !tbaa !29
  store ptr %t111, ptr %l37, !tbaa !29
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t113 = load i32, ptr %l2, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l40
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l37, !tbaa !29
  %t118 = load i32, ptr %l40, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t119, ptr %l41
  br label %bb29
bb29:
  %t120 = load i1, ptr %l41, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l43, !tbaa !29
  %t124 = load i32, ptr %l1, !range !{i32 0, i32 43}
  store i32 %t124, ptr %l44
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l44, i64 0)
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t126 = load ptr, ptr %s8
  %t127 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t128 = load i64, ptr %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t126, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l46, !tbaa !27
  %t132 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t133 = load ptr, ptr %t132
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %sbgrew.135, label %sbdone.136
sbgrew.135:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.136
sbdone.136:
  %t137 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t143)
  store { i64, ptr } %t145, ptr %l48
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s7, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l51
  br label %bb34
bb34:
  %t151 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t153 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t151, i64 %t152)
  %t168 = getelementptr i8, ptr %t167, i64 %t152
  call void @olang_textcopy(ptr %t168, ptr %t154, i64 %t155)
  %t169 = getelementptr i8, ptr %t168, i64 %t155
  call void @olang_textcopy(ptr %t169, ptr %t157, i64 %t158)
  %t170 = getelementptr i8, ptr %t169, i64 %t158
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t164, i64 %t165)
  %t172 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t167, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t181 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t181, { i64, ptr } %t180)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca %"compiler/mir:Range"
  %l19 = alloca i64
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l10
  br label %bb4
bb4:
  br label %bb15
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_70d66502dd431e07_8b33d36aabf56353)
  unreachable
bb15:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t27 = load %"compiler/mir:Range", ptr %t26
  store %"compiler/mir:Range" %t27, ptr %l15
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/mir:verifier", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/mir:Fn", ptr %t31, i32 0, i32 10
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l19
  br label %bb16
bb16:
  %t36 = load ptr, ptr %l14, !tbaa !29
  %t37 = load %"compiler/mir:Range", ptr %l15
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t36, %"compiler/mir:Range" %t37, i64 %t38, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d113, i32 0, i32 1) })
  store i1 %t39, ptr %l20
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i32
  %l66 = alloca { i64, [1 x i64] }
  %l67 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l19
  br label %bb4
bb4:
  %t18 = load i32, ptr %l19, !tbaa !23
  store i32 %t18, ptr %l13, !tbaa !23
  br label %bb14
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64, i32, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4, !tbaa !23
  store i32 %t28, ptr %l13, !tbaa !23
  br label %bb14
bb9:
  %t30 = load { i64, [2 x i64] }, ptr %l2
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t35, ptr %l13, !tbaa !23
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2986d82de8391aaf_d61db5ce8081183b)
  unreachable
bb14:
  %t37 = load i32, ptr %l13, !tbaa !23
  store i32 %t37, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  %t38 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t39 = getelementptr %"compiler/mir:Range", ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  store i32 %t40, ptr %l7, !tbaa !23
  store i32 1, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l7, !tbaa !23
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = icmp sgt i32 %t42, %t43
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load i32, ptr %l8, !tbaa !23
  %t50 = icmp sgt i32 %t48, 0
  br i1 %t50, label %bb17, label %bb18
bb16:
  store i32 0, ptr %l31, !tbaa !23
  br label %bb20
bb17:
  %t52 = load i32, ptr %l7, !tbaa !23
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = sub i32 %t52, %t53
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = add i32 %t56, %t57
  %t62 = sub i32 %t60, 1
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = sdiv i32 %t62, %t63
  store i32 %t66, ptr %l34, !tbaa !23
  br label %bb19
bb18:
  store i32 0, ptr %l34, !tbaa !23
  br label %bb19
bb19:
  %t68 = load i32, ptr %l34, !tbaa !23
  store i32 %t68, ptr %l31, !tbaa !23
  br label %bb20
bb20:
  %t69 = load i32, ptr %l31, !tbaa !23
  store i32 %t69, ptr %l9, !tbaa !23
  store i32 0, ptr %l10, !tbaa !23
  br label %bb21
bb21:
  %t70 = load i32, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l9, !tbaa !23
  %t74 = icmp slt i32 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t79 = load i32, ptr %l10, !tbaa !23
  %t80 = load i32, ptr %l8, !tbaa !23
  %t83 = mul i32 %t79, %t80
  %t86 = add i32 %t78, %t83
  store i32 %t86, ptr %l11, !tbaa !23
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = icmp eq i32 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i32, ptr %l5, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load i32, ptr %l5, !tbaa !23
  store i32 %t97, ptr %l57, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/mir:verifier", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/mir:Fn", ptr %t101, i32 0, i32 10
  %t104 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t105 = getelementptr %"compiler/mir:Range", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t109 = load i32, ptr %l11, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = add i64 %t108, %t111
  %t117 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t103, i64 %t114)
  store { i64, [1 x i64] } %t117, ptr %l66
  br label %bb28
bb28:
  %t118 = load ptr, ptr %l56, !tbaa !29
  %t119 = load i32, ptr %l57, !tbaa !23
  %t120 = load { i64, [1 x i64] }, ptr %l66
  %t121 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprojected(ptr %v0, ptr %t118, i32 %t119, { i64, [1 x i64] } %t120)
  store i32 %t121, ptr %l67
  br label %bb29
bb29:
  %t122 = load i32, ptr %l67, !tbaa !23
  store i32 %t122, ptr %l5, !tbaa !23
  br label %bb30
bb30:
  %t123 = load i32, ptr %l10, !tbaa !23
  %t125 = add i32 %t123, 1
  store i32 %t125, ptr %l10, !tbaa !23
  br label %bb21
bb31:
  %t127 = load i32, ptr %l5, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/mir:verifier", ptr %t9, i32 0, i32 17
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t19, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %t22
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 17
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/mir:verifier", ptr %t40, i32 0, i32 17
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l27
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t51 = sext i32 %t46 to i64
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t47, 1
  %t59 = extractvalue { i64, ptr } %t47, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t51)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } %t78)
  br label %bb15
bb12:
  %t81 = load i64, ptr %l27, !tbaa !24
  %t82 = sub i64 %t81, 1
  %t83 = load ptr, ptr %l24, !tbaa !29
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t83, i64 %t82)
  store i32 %t85, ptr %l29
  br label %bb13
bb13:
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t88 = load i32, ptr %l21, !tbaa !23
  %t89 = sext i32 %t88 to i64
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load i32, ptr %l29, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t86, i64 %t87)
  %t110 = getelementptr i8, ptr %t109, i64 %t87
  %t111 = call i64 @__olang_fmt_i64(ptr %t110, i64 %t89)
  %t112 = getelementptr i8, ptr %t110, i64 %t90
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t96, i64 %t97)
  %t114 = getelementptr i8, ptr %t113, i64 %t97
  call void @olang_textcopy(ptr %t114, ptr %t99, i64 %t100)
  %t115 = getelementptr i8, ptr %t114, i64 %t100
  %t116 = call i64 @__olang_fmt_i64(ptr %t115, i64 %t103)
  %t117 = getelementptr i8, ptr %t115, i64 %t104
  call void @olang_textcopy(ptr %t117, ptr %t106, i64 %t107)
  %t118 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t109, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t127, { i64, ptr } %t126)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/mir:verifier", ptr %t129, i32 0, i32 17
  %t133 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t131)
  %t134 = extractvalue { i32, i32 } %t133, 1
  %t135 = extractvalue { i32, i32 } %t133, 0
  store i32 %t135, ptr %l41
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb19, label %ok.137, !prof !99
ok.137:
  store i32 %t134, ptr %l40
  br label %bb18
bb18:
  %t138 = load i32, ptr %l40, !tbaa !23
  store i32 %t138, ptr %l37, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_525ae97147cf6b9b_c46e40fbd793c77f)
  unreachable
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [21 x i64] }
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca ptr
  %l49 = alloca %"compiler/mir:BasicBlock"
  %l51 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l71 = alloca %"compiler/mir:BasicBlock"
  %l73 = alloca %"compiler/mir:BasicBlock"
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca { i64, [21 x i64] }
  %l83 = alloca { i64, [21 x i64] }
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca i64
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l25
  br label %bb1
bb1:
  %t9 = load i64, ptr %l25, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l26, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l27, !tbaa !24
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l27, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = load ptr, ptr %l26, !tbaa !29
  %t22 = getelementptr %"compiler/mir:verifier", ptr %t21, i32 0, i32 13
  store { i64, ptr } %t19, ptr %t22, !tbaa !27
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l30
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608)
  unreachable
bb4:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 0)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:verifier", ptr %t26, i32 0, i32 13
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l33, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i1, ptr %t31, i64 0
  store i1 true, ptr %t32, !tbaa !31
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  store i64 %t34, ptr %l35
  br label %bb7
bb7:
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = icmp sgt i64 %t35, 0
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb61
bb9:
  br label %bb10
bb10:
  %t41 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  %t42 = extractvalue { i32, i32 } %t41, 1
  %t43 = extractvalue { i32, i32 } %t41, 0
  store i32 %t43, ptr %l41
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb12, label %ok.45, !prof !99
ok.45:
  store i32 %t42, ptr %l40
  br label %bb11
bb11:
  %t46 = load i32, ptr %l40, !tbaa !23
  store i32 %t46, ptr %l38, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6)
  unreachable
bb14:
  %t47 = load i32, ptr %l38, !tbaa !23
  store i32 %t47, ptr %l3, !tbaa !23
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l42
  br label %bb15
bb15:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l43, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/mir:verifier", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 9
  %t57 = load i32, ptr %l3, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s3, ptr %t56, i64 %t59)
  store %"compiler/mir:BasicBlock" %t62, ptr %l49
  br label %bb16
bb16:
  %t63 = getelementptr %"compiler/mir:BasicBlock", ptr %l49, i32 0, i32 1
  %t64 = load { i64, [8 x i64] }, ptr %t63
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %s3, ptr %t65, { i64, [8 x i64] } %t64)
  store { i64, ptr } %t67, ptr %l51
  br label %bb17
bb17:
  %t68 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 4
  %t72 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t88, ptr %l59, !tbaa !27
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i32, ptr %t92, i64 %t89
  %t94 = load i32, ptr %t93, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t94)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l6, !tbaa !24
  br label %bb18
bb24:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s6
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/mir:verifier", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/mir:Fn", ptr %t106, i32 0, i32 9
  %t109 = load i32, ptr %l3, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t108, i64 %t111)
  store %"compiler/mir:BasicBlock" %t114, ptr %l71
  br label %bb25
bb25:
  %t116 = call %"compiler/mir:BasicBlock" @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %l71)
  store %"compiler/mir:BasicBlock" %t116, ptr %l73
  br label %bb26
bb26:
  %t117 = getelementptr %"compiler/mir:BasicBlock", ptr %l73, i32 0, i32 0
  store ptr %t117, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t119 = load i64, ptr %l10, !tbaa !24
  store i64 %t119, ptr %l75, !tbaa !24
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s6, ptr %t120)
  store i64 %t122, ptr %l77
  br label %bb28
bb28:
  %t123 = load i64, ptr %l75, !tbaa !24
  %t124 = load i64, ptr %l77, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb29, label %bb30
bb29:
  br label %bb47
bb30:
  br label %bb31
bb31:
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s6, ptr %t129, i64 %t130)
  store { i64, [21 x i64] } %t133, ptr %l82
  br label %bb32
bb32:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l82, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %l11, i64 176, i1 false)
  %t134 = load { i64, [21 x i64] }, ptr %l83
  %t135 = extractvalue { i64, [21 x i64] } %t134, 0
  %t136 = icmp eq i64 %t135, 12
  br i1 %t136, label %bb33, label %bb34
bb33:
  %t138 = getelementptr { i64, [21 x i64] }, ptr %l11, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t138, i32 0, i32 2
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l12, !tbaa !23
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t142 = load i32, ptr %l12, !tbaa !23
  %t143 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t146 = icmp ne i32 %t142, %t143
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t148 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t148)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_7127dab5ce57c749_b077692428e4994d)
  unreachable
bb45:
  br label %bb46
bb46:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l10, !tbaa !24
  br label %bb27
bb47:
  call void @__olang_scope_close(ptr %s6)
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t156 = load i64, ptr %l14, !tbaa !24
  store i64 %t156, ptr %l94, !tbaa !24
  %t157 = load ptr, ptr %l13, !tbaa !29
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t157)
  store i64 %t159, ptr %l96
  br label %bb49
bb49:
  %t160 = load i64, ptr %l94, !tbaa !24
  %t161 = load i64, ptr %l96, !tbaa !24
  %t162 = icmp slt i64 %t160, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb50, label %bb51
bb50:
  br label %bb59
bb51:
  br label %bb52
bb52:
  %t166 = load ptr, ptr %l13, !tbaa !29
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t166, i64 %t167)
  store i32 %t170, ptr %l101
  br label %bb53
bb53:
  %t171 = load i32, ptr %l101, !tbaa !23
  store i32 %t171, ptr %l15, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/mir:verifier", ptr %t172, i32 0, i32 13
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l103, !tbaa !27
  %t176 = load i32, ptr %l15, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t180 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i1, ptr %t181, i64 %t178
  %t183 = load i1, ptr %t182, !tbaa !31
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb54, label %bb55
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/mir:verifier", ptr %t187, i32 0, i32 13
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l109, !tbaa !27
  %t191 = load i32, ptr %l15, !tbaa !23
  %t193 = sext i32 %t191 to i64
  %t195 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i1, ptr %t196, i64 %t193
  store i1 true, ptr %t197, !tbaa !31
  %t198 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 %t198)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l14, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l14, !tbaa !24
  br label %bb48
bb59:
  call void @__olang_scope_close(ptr %s1)
  br label %bb60
bb60:
  br label %bb6
bb61:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/mir:verifier", ptr %t205, i32 0, i32 4
  store i64 -1, ptr %t207, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t211 = load i64, ptr %l16, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb62, label %bb63
bb62:
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb67
bb64:
  %t220 = load i64, ptr %l17, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l18, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l18, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l124, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb66
bb66:
  %t236 = load i64, ptr %l124, !tbaa !24
  store i64 %t236, ptr %l121, !tbaa !24
  br label %bb67
bb67:
  %t237 = load i64, ptr %l121, !tbaa !24
  store i64 %t237, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb68
bb68:
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load i64, ptr %l19, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb69, label %bb70
bb69:
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load i64, ptr %l20, !tbaa !24
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l21, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/mir:verifier", ptr %t256, i32 0, i32 13
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l21, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i1, ptr %t263, i64 %t260
  %t265 = load i1, ptr %t264, !tbaa !31
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s18
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l21, !tbaa !24
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t269, i32 0, i32 3
  store i64 %t270, ptr %t273, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t274, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d121, i32 0, i32 1) })
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s18)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t276 = load i64, ptr %l20, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l20, !tbaa !24
  br label %bb68
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l12, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %l12, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l12, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load i32, ptr %l6, !tbaa !23
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l1
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = add i32 %t62, 1
  store i32 %t64, ptr %l6, !tbaa !23
  br label %bb7
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t13, i32 %t14)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b)
  unreachable
bb10:
  store i32 0, ptr %l4, !tbaa !23
  %t17 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t18 = getelementptr %"compiler/mir:Range", ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l5, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = icmp sgt i32 %t21, %t22
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  br i1 %t29, label %bb13, label %bb14
bb12:
  store i32 0, ptr %l22, !tbaa !23
  br label %bb16
bb13:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = sub i32 %t31, %t32
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = add i32 %t35, %t36
  %t41 = sub i32 %t39, 1
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = sdiv i32 %t41, %t42
  store i32 %t45, ptr %l25, !tbaa !23
  br label %bb15
bb14:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb15
bb15:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %l22, !tbaa !23
  br label %bb16
bb16:
  %t48 = load i32, ptr %l22, !tbaa !23
  store i32 %t48, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb17
bb17:
  %t49 = load i32, ptr %l8, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = icmp slt i32 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t58 = load i32, ptr %l8, !tbaa !23
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = mul i32 %t58, %t59
  %t65 = add i32 %t57, %t62
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/mir:Fn", ptr %t70, i32 0, i32 10
  %t73 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t74 = getelementptr %"compiler/mir:Range", ptr %t73, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = sext i32 %t65 to i64
  %t83 = add i64 %t77, %t80
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t72, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l51
  br label %bb21
bb21:
  %t87 = load { i64, [1 x i64] }, ptr %l51
  store { i64, [1 x i64] } %t87, ptr %l10
  %t88 = load { i64, [1 x i64] }, ptr %l10
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l11, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t97, i32 %t98)
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a)
  unreachable
bb31:
  br label %bb32
bb32:
  %t101 = load i32, ptr %l8, !tbaa !23
  %t103 = add i32 %t101, 1
  store i32 %t103, ptr %l8, !tbaa !23
  br label %bb17
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a5f83820f05cb9f9_5f257facca4b96a5)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l32 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l10
  br label %bb4
bb4:
  br label %bb27
bb5:
  %t15 = load { i64, [1 x i64] }, ptr %l1
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 1
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb12
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/mir:Fn", ptr %t32, i32 0, i32 6
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load i64, ptr %l17, !tbaa !24
  %t38 = load i64, ptr %l21, !tbaa !24
  %t39 = icmp sge i64 %t37, %t38
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l16, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t48 = add i64 %t45, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = getelementptr i8, ptr %t49, i64 %t45
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t60)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t63 = load { i64, [1 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [1 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32 }, ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l4, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l4, !tbaa !23
  %t76 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6be72733009cb689_7eadbfb9b429b955)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i1, ptr %l8, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l13
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = getelementptr i8, ptr %t26, i64 %t21
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t37 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t37, { i64, ptr } %t36)
  br label %bb5
bb5:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t39, ptr %rv
  br label %ret
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp ne i32 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  store i32 %t48, ptr %l22, !tbaa !23
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t55 = load i32, ptr %l22, !tbaa !23
  %t56 = load i32, ptr %l25, !tbaa !23
  %t57 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t54, i32 %t55, i32 %t56)
  store i1 %t57, ptr %l26
  br label %bb10
bb10:
  %t58 = load i1, ptr %l26, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l20, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l28, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l31
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l34
  br label %bb15
bb15:
  %t73 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t75 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t73, i64 %t74)
  %t87 = getelementptr i8, ptr %t86, i64 %t74
  call void @olang_textcopy(ptr %t87, ptr %t76, i64 %t77)
  %t88 = getelementptr i8, ptr %t87, i64 %t77
  call void @olang_textcopy(ptr %t88, ptr %t79, i64 %t80)
  %t89 = getelementptr i8, ptr %t88, i64 %t80
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t86, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t99 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t99, { i64, ptr } %t98)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t101 = load i32, ptr %l2, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:verifier", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/mir:verifier", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = load i32, ptr %l11, !tbaa !23
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load i1, ptr %l12, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l5, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l17
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = getelementptr i8, ptr %t38, i64 %t33
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t49, { i64, ptr } %t48)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t51 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %t7)
  br label %bb5
bb5:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %t9)
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %t11)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l102 = alloca i32
  %l105 = alloca i32
  %l123 = alloca ptr
  %l132 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb5
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 11
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t19, { i64, [4 x i64] } %t20)
  br label %bb6
bb6:
  br label %bb86
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Lvalue", ptr %t29
  store %"compiler/mir:Lvalue" %t30, ptr %l3
  br label %bb14
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 2
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Lvalue", ptr %t38
  store %"compiler/mir:Lvalue" %t39, ptr %l3
  br label %bb14
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 5
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Lvalue", ptr %t47
  store %"compiler/mir:Lvalue" %t48, ptr %l3
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/mir:Lvalue", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t50, %"compiler/mir:Lvalue" %t51)
  br label %bb15
bb15:
  br label %bb86
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 3
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb23
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb23
bb20:
  %t72 = load { i64, [15 x i64] }, ptr %l1
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 6
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/mir:Range", ptr %t78
  store %"compiler/mir:Range" %t79, ptr %l4
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t81, %"compiler/mir:Range" %t82)
  br label %bb24
bb24:
  br label %bb86
bb25:
  %t85 = load { i64, [15 x i64] }, ptr %l1
  %t87 = extractvalue { i64, [15 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 7
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t91 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, [1 x i64] }, ptr %t91
  store { i64, [1 x i64] } %t92, ptr %l5
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t94, i32 0, i32 1
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l6
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t98, { i64, [4 x i64] } %t99)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t102, { i64, [1 x i64] } %t103)
  br label %bb30
bb30:
  br label %bb86
bb31:
  %t106 = load { i64, [15 x i64] }, ptr %l1
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 8
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t112 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 0
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l7
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t116 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t115, i32 0, i32 2
  %t117 = load { i64, [4 x i64] }, ptr %t116
  store { i64, [4 x i64] } %t117, ptr %l8
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t120 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t119, i32 0, i32 3
  %t121 = load { i64, [4 x i64] }, ptr %t120
  store { i64, [4 x i64] } %t121, ptr %l9
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t123, { i64, [4 x i64] } %t124)
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t127, { i64, [4 x i64] } %t128)
  br label %bb36
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t131, { i64, [1 x i64] } %t132)
  br label %bb37
bb37:
  br label %bb86
bb38:
  %t135 = load { i64, [15 x i64] }, ptr %l1
  %t137 = extractvalue { i64, [15 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 9
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t141 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/mir:Lvalue", ptr %t141
  store %"compiler/mir:Lvalue" %t142, ptr %l10
  %t144 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t145 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t144, i32 0, i32 1
  %t146 = load { i64, [4 x i64] }, ptr %t145
  store { i64, [4 x i64] } %t146, ptr %l11
  %t148 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t149 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t148, i32 0, i32 2
  %t150 = load { i64, [4 x i64] }, ptr %t149
  store { i64, [4 x i64] } %t150, ptr %l12
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t152, %"compiler/mir:Lvalue" %t153)
  br label %bb42
bb42:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t156, { i64, [4 x i64] } %t157)
  br label %bb43
bb43:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t160, { i64, [4 x i64] } %t161)
  br label %bb44
bb44:
  br label %bb86
bb45:
  %t164 = load { i64, [15 x i64] }, ptr %l1
  %t166 = extractvalue { i64, [15 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 10
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t169, i32 0, i32 2
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l13
  %t173 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t174 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t173, i32 0, i32 3
  %t175 = load %"compiler/mir:Range", ptr %t174
  store %"compiler/mir:Range" %t175, ptr %l14
  %t177 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t178 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t177, i32 0, i32 4
  %t179 = load %"compiler/mir:Range", ptr %t178
  store %"compiler/mir:Range" %t179, ptr %l15
  br label %bb48
bb47:
  br label %bb68
bb48:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t181, %"compiler/mir:Range" %t182)
  br label %bb49
bb49:
  %t185 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t186 = load i32, ptr %t185, !tbaa !23
  %t188 = icmp sgt i32 %t186, 0
  br i1 %t188, label %bb50, label %bb51
bb50:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t190, { i64, [1 x i64] } %t191)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  store i32 0, ptr %l16, !tbaa !23
  %t194 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  store i32 %t195, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t197 = load i32, ptr %l17, !tbaa !23
  %t198 = load i32, ptr %l16, !tbaa !23
  %t201 = icmp sgt i32 %t197, %t198
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t203 = load i32, ptr %l18, !tbaa !23
  %t205 = icmp sgt i32 %t203, 0
  br i1 %t205, label %bb56, label %bb57
bb55:
  store i32 0, ptr %l102, !tbaa !23
  br label %bb59
bb56:
  %t207 = load i32, ptr %l17, !tbaa !23
  %t208 = load i32, ptr %l16, !tbaa !23
  %t211 = sub i32 %t207, %t208
  %t212 = load i32, ptr %l18, !tbaa !23
  %t215 = add i32 %t211, %t212
  %t217 = sub i32 %t215, 1
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = sdiv i32 %t217, %t218
  store i32 %t221, ptr %l105, !tbaa !23
  br label %bb58
bb57:
  store i32 0, ptr %l105, !tbaa !23
  br label %bb58
bb58:
  %t223 = load i32, ptr %l105, !tbaa !23
  store i32 %t223, ptr %l102, !tbaa !23
  br label %bb59
bb59:
  %t224 = load i32, ptr %l102, !tbaa !23
  store i32 %t224, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb60
bb60:
  %t225 = load i32, ptr %l20, !tbaa !23
  %t226 = load i32, ptr %l19, !tbaa !23
  %t229 = icmp slt i32 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t233 = load i32, ptr %l16, !tbaa !23
  %t234 = load i32, ptr %l20, !tbaa !23
  %t235 = load i32, ptr %l18, !tbaa !23
  %t238 = mul i32 %t234, %t235
  %t241 = add i32 %t233, %t238
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l123, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/mir:verifier", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/mir:Fn", ptr %t247, i32 0, i32 12
  %t250 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  %t256 = sext i32 %t241 to i64
  %t259 = add i64 %t253, %t256
  %t262 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t249, i64 %t259)
  store { i64, [1 x i64] } %t262, ptr %l132
  br label %bb64
bb64:
  %t263 = load ptr, ptr %l123, !tbaa !29
  %t264 = load { i64, [1 x i64] }, ptr %l132
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t263, { i64, [1 x i64] } %t264)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t265 = load i32, ptr %l20, !tbaa !23
  %t267 = add i32 %t265, 1
  store i32 %t267, ptr %l20, !tbaa !23
  br label %bb60
bb67:
  br label %bb86
bb68:
  %t269 = load { i64, [15 x i64] }, ptr %l1
  %t271 = extractvalue { i64, [15 x i64] } %t269, 0
  %t272 = icmp eq i64 %t271, 12
  br i1 %t272, label %bb69, label %bb70
bb69:
  %t274 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t275 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t274, i32 0, i32 0
  %t276 = load { i64, [1 x i64] }, ptr %t275
  store { i64, [1 x i64] } %t276, ptr %l22
  %t278 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t279 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t278, i32 0, i32 1
  %t280 = load { i64, [1 x i64] }, ptr %t279
  store { i64, [1 x i64] } %t280, ptr %l23
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, [1 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t282, { i64, [1 x i64] } %t283)
  br label %bb72
bb72:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load { i64, [1 x i64] }, ptr %l23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t286, { i64, [1 x i64] } %t287)
  br label %bb73
bb73:
  br label %bb86
bb74:
  %t290 = load { i64, [15 x i64] }, ptr %l1
  %t292 = extractvalue { i64, [15 x i64] } %t290, 0
  %t293 = icmp eq i64 %t292, 13
  br i1 %t293, label %bb75, label %bb76
bb75:
  %t295 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t296 = getelementptr { { i64, [1 x i64] } }, ptr %t295, i32 0, i32 0
  %t297 = load { i64, [1 x i64] }, ptr %t296
  store { i64, [1 x i64] } %t297, ptr %l24
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load { i64, [1 x i64] }, ptr %l24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t299, { i64, [1 x i64] } %t300)
  br label %bb78
bb78:
  br label %bb86
bb79:
  %t303 = load { i64, [15 x i64] }, ptr %l1
  %t305 = extractvalue { i64, [15 x i64] } %t303, 0
  %t306 = icmp eq i64 %t305, 14
  br i1 %t306, label %bb80, label %bb81
bb80:
  %t308 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t309 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t308, i32 0, i32 0
  %t310 = load { i64, [4 x i64] }, ptr %t309
  store { i64, [4 x i64] } %t310, ptr %l25
  %t312 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t313 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t312, i32 0, i32 1
  %t314 = load { i64, [1 x i64] }, ptr %t313
  store { i64, [1 x i64] } %t314, ptr %l26
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load { i64, [4 x i64] }, ptr %l25
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t316, { i64, [4 x i64] } %t317)
  br label %bb83
bb83:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load { i64, [1 x i64] }, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t320, { i64, [1 x i64] } %t321)
  br label %bb84
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f)
  unreachable
bb86:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Range"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca i32
  %l36 = alloca i32
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l64 = alloca i32
  %l74 = alloca i32
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l92 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l102 = alloca i32
  %l112 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca i32
  %l126 = alloca i32
  %l132 = alloca i32
  %l136 = alloca ptr
  %l139 = alloca i32
  %l141 = alloca i32
  %l149 = alloca i32
  %l156 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l2
  %t14 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11)
  store i32 %t14, ptr %l36
  br label %bb4
bb4:
  %t15 = load i32, ptr %l36, !tbaa !23
  store i32 %t15, ptr %l30, !tbaa !23
  br label %bb82
bb5:
  %t16 = load { i64, [15 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [15 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/mir:Lvalue", ptr %t22
  store %"compiler/mir:Lvalue" %t23, ptr %l3
  %t25 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t25, i32 0, i32 1
  %t27 = load i32, ptr %t26
  store i32 %t27, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l41, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/mir:Lvalue", ptr %l3
  %t34 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t30, %"compiler/mir:Lvalue" %t31)
  store i32 %t34, ptr %l44
  br label %bb9
bb9:
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t37 = load i32, ptr %l44, !tbaa !23
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t36, i32 %t37, i32 %t35)
  store i32 %t39, ptr %l46
  br label %bb10
bb10:
  %t40 = load i32, ptr %l46, !tbaa !23
  store i32 %t40, ptr %l30, !tbaa !23
  br label %bb82
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Lvalue", ptr %t47
  store %"compiler/mir:Lvalue" %t48, ptr %l5
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l50, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Lvalue", ptr %l5
  %t55 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t51, %"compiler/mir:Lvalue" %t52)
  store i32 %t55, ptr %l53
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l50, !tbaa !29
  %t57 = load i32, ptr %l53, !tbaa !23
  %t58 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l54
  br label %bb16
bb16:
  %t59 = load i32, ptr %l54, !tbaa !23
  store i32 %t59, ptr %l30, !tbaa !23
  br label %bb82
bb17:
  %t60 = load { i64, [15 x i64] }, ptr %l1
  %t62 = extractvalue { i64, [15 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 3
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t65 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t65, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 43}
  store i32 %t67, ptr %l6
  %t69 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t70 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l7, !tbaa !23
  %t73 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t74 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t73, i32 0, i32 2
  %t75 = load %"compiler/mir:Range", ptr %t74
  store %"compiler/mir:Range" %t75, ptr %l8
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l6, !range !{i32 0, i32 43}
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load %"compiler/mir:Range", ptr %l8
  %t85 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %t77, i32 %t78, i32 %t79, %"compiler/mir:Range" %t80)
  store i32 %t85, ptr %l64
  br label %bb21
bb21:
  %t86 = load i32, ptr %l64, !tbaa !23
  store i32 %t86, ptr %l30, !tbaa !23
  br label %bb82
bb22:
  %t87 = load { i64, [15 x i64] }, ptr %l1
  %t89 = extractvalue { i64, [15 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 4
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t93 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t92, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 43}
  store i32 %t94, ptr %l9
  %t96 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t97 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l10, !tbaa !23
  %t100 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t101 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t100, i32 0, i32 2
  %t102 = load %"compiler/mir:Range", ptr %t101
  store %"compiler/mir:Range" %t102, ptr %l11
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l9, !range !{i32 0, i32 43}
  %t106 = load i32, ptr %l10, !tbaa !23
  %t107 = load %"compiler/mir:Range", ptr %l11
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %t104, i32 %t105, i32 %t106, %"compiler/mir:Range" %t107)
  store i32 %t112, ptr %l74
  br label %bb26
bb26:
  %t113 = load i32, ptr %l74, !tbaa !23
  store i32 %t113, ptr %l30, !tbaa !23
  br label %bb82
bb27:
  %t114 = load { i64, [15 x i64] }, ptr %l1
  %t116 = extractvalue { i64, [15 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 5
  br i1 %t117, label %bb28, label %bb29
bb28:
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/mir:Lvalue", ptr %t120
  store %"compiler/mir:Lvalue" %t121, ptr %l12
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l78, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/mir:Lvalue", ptr %l12
  %t128 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t124, %"compiler/mir:Lvalue" %t125)
  store i32 %t128, ptr %l81
  br label %bb31
bb31:
  %t129 = load ptr, ptr %l78, !tbaa !29
  %t130 = load i32, ptr %l81, !tbaa !23
  %t131 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l82
  br label %bb32
bb32:
  %t132 = load i32, ptr %l82, !tbaa !23
  store i32 %t132, ptr %l30, !tbaa !23
  br label %bb82
bb33:
  %t133 = load { i64, [15 x i64] }, ptr %l1
  %t135 = extractvalue { i64, [15 x i64] } %t133, 0
  %t136 = icmp eq i64 %t135, 6
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t138 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t139 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t138, i32 0, i32 0
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l13, !tbaa !23
  %t142 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t143 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t142, i32 0, i32 1
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l14, !tbaa !24
  %t146 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t147 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t146, i32 0, i32 2
  %t148 = load %"compiler/mir:Range", ptr %t147
  store %"compiler/mir:Range" %t148, ptr %l15
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l13, !tbaa !23
  %t152 = load i64, ptr %l14, !tbaa !24
  %t153 = load %"compiler/mir:Range", ptr %l15
  %t158 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %t150, i32 %t151, i64 %t152, %"compiler/mir:Range" %t153)
  store i32 %t158, ptr %l92
  br label %bb37
bb37:
  %t159 = load i32, ptr %l92, !tbaa !23
  store i32 %t159, ptr %l30, !tbaa !23
  br label %bb82
bb38:
  %t160 = load { i64, [15 x i64] }, ptr %l1
  %t162 = extractvalue { i64, [15 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 7
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t166 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t165, i32 0, i32 1
  %t167 = load { i64, [4 x i64] }, ptr %t166
  store { i64, [4 x i64] } %t167, ptr %l16
  %t169 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t169, i32 0, i32 2
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l17, !tbaa !23
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l97, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, [4 x i64] }, ptr %l16
  %t178 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t174, { i64, [4 x i64] } %t175)
  store i32 %t178, ptr %l100
  br label %bb42
bb42:
  %t179 = load i32, ptr %l17, !tbaa !23
  %t180 = load ptr, ptr %l97, !tbaa !29
  %t181 = load i32, ptr %l100, !tbaa !23
  %t183 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t180, i32 %t181, i32 %t179)
  store i32 %t183, ptr %l102
  br label %bb43
bb43:
  %t184 = load i32, ptr %l102, !tbaa !23
  store i32 %t184, ptr %l30, !tbaa !23
  br label %bb82
bb44:
  %t185 = load { i64, [15 x i64] }, ptr %l1
  %t187 = extractvalue { i64, [15 x i64] } %t185, 0
  %t188 = icmp eq i64 %t187, 8
  br i1 %t188, label %bb45, label %bb46
bb45:
  %t190 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t191 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t190, i32 0, i32 1
  %t192 = load i32, ptr %t191
  store i32 %t192, ptr %l18, !tbaa !23
  %t194 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t195 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t194, i32 0, i32 2
  %t196 = load { i64, [4 x i64] }, ptr %t195
  store { i64, [4 x i64] } %t196, ptr %l19
  %t198 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t199 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t198, i32 0, i32 3
  %t200 = load { i64, [4 x i64] }, ptr %t199
  store { i64, [4 x i64] } %t200, ptr %l20
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l18, !tbaa !23
  %t204 = load { i64, [4 x i64] }, ptr %l19
  %t205 = load { i64, [4 x i64] }, ptr %l20
  %t210 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %t202, i32 %t203, { i64, [4 x i64] } %t204, { i64, [4 x i64] } %t205)
  store i32 %t210, ptr %l112
  br label %bb48
bb48:
  %t211 = load i32, ptr %l112, !tbaa !23
  store i32 %t211, ptr %l30, !tbaa !23
  br label %bb82
bb49:
  %t212 = load { i64, [15 x i64] }, ptr %l1
  %t214 = extractvalue { i64, [15 x i64] } %t212, 0
  %t215 = icmp eq i64 %t214, 9
  br i1 %t215, label %bb50, label %bb51
bb50:
  %t217 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t218 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t217, i32 0, i32 0
  %t219 = load %"compiler/mir:Lvalue", ptr %t218
  store %"compiler/mir:Lvalue" %t219, ptr %l21
  %t221 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t222 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t221, i32 0, i32 1
  %t223 = load { i64, [4 x i64] }, ptr %t222
  store { i64, [4 x i64] } %t223, ptr %l22
  %t225 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t226 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t225, i32 0, i32 2
  %t227 = load { i64, [4 x i64] }, ptr %t226
  store { i64, [4 x i64] } %t227, ptr %l23
  %t229 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t230 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t229, i32 0, i32 3
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l24, !tbaa !23
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l119, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/mir:Lvalue", ptr %l21
  %t238 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t234, %"compiler/mir:Lvalue" %t235)
  store i32 %t238, ptr %l122
  br label %bb53
bb53:
  %t239 = load { i64, [4 x i64] }, ptr %l22
  %t240 = load { i64, [4 x i64] }, ptr %l23
  %t241 = load i32, ptr %l24, !tbaa !23
  %t242 = load ptr, ptr %l119, !tbaa !29
  %t243 = load i32, ptr %l122, !tbaa !23
  %t247 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %t242, i32 %t243, { i64, [4 x i64] } %t239, { i64, [4 x i64] } %t240, i32 %t241)
  store i32 %t247, ptr %l126
  br label %bb54
bb54:
  %t248 = load i32, ptr %l126, !tbaa !23
  store i32 %t248, ptr %l30, !tbaa !23
  br label %bb82
bb55:
  %t249 = load { i64, [15 x i64] }, ptr %l1
  %t251 = extractvalue { i64, [15 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 10
  br i1 %t252, label %bb56, label %bb57
bb56:
  %t254 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t255 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255
  store i32 %t256, ptr %l25, !tbaa !23
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l25, !tbaa !23
  %t262 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l132
  br label %bb59
bb59:
  %t263 = load i32, ptr %l132, !tbaa !23
  store i32 %t263, ptr %l30, !tbaa !23
  br label %bb82
bb60:
  %t264 = load { i64, [15 x i64] }, ptr %l1
  %t266 = extractvalue { i64, [15 x i64] } %t264, 0
  %t267 = icmp eq i64 %t266, 11
  br i1 %t267, label %bb61, label %bb62
bb61:
  %t269 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t270 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t269, i32 0, i32 0
  %t271 = load { i64, [4 x i64] }, ptr %t270
  store { i64, [4 x i64] } %t271, ptr %l26
  br label %bb63
bb62:
  br label %bb66
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l136, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load { i64, [4 x i64] }, ptr %l26
  %t278 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t274, { i64, [4 x i64] } %t275)
  store i32 %t278, ptr %l139
  br label %bb64
bb64:
  %t279 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t280 = load ptr, ptr %l136, !tbaa !29
  %t281 = load i32, ptr %l139, !tbaa !23
  %t283 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s12, ptr %t280, i32 %t281, i32 %t279, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i32 %t283, ptr %l141
  br label %bb65
bb65:
  %t284 = load i32, ptr %l141, !tbaa !23
  store i32 %t284, ptr %l30, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb66:
  %t285 = load { i64, [15 x i64] }, ptr %l1
  %t287 = extractvalue { i64, [15 x i64] } %t285, 0
  %t288 = icmp eq i64 %t287, 12
  br i1 %t288, label %bb67, label %bb68
bb67:
  %t290 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t290, i32 0, i32 0
  %t292 = load { i64, [1 x i64] }, ptr %t291
  store { i64, [1 x i64] } %t292, ptr %l27
  %t294 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t295 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t294, i32 0, i32 2
  %t296 = load i32, ptr %t295
  store i32 %t296, ptr %l28, !tbaa !23
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, [1 x i64] }, ptr %l27
  %t300 = load i32, ptr %l28, !tbaa !23
  %t304 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %t298, { i64, [1 x i64] } %t299, i32 %t300)
  store i32 %t304, ptr %l149
  br label %bb70
bb70:
  %t305 = load i32, ptr %l149, !tbaa !23
  store i32 %t305, ptr %l30, !tbaa !23
  br label %bb82
bb71:
  %t306 = load { i64, [15 x i64] }, ptr %l1
  %t308 = extractvalue { i64, [15 x i64] } %t306, 0
  %t309 = icmp eq i64 %t308, 13
  br i1 %t309, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t311 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t311, ptr %l30, !tbaa !23
  br label %bb82
bb75:
  %t313 = load { i64, [15 x i64] }, ptr %l1
  %t315 = extractvalue { i64, [15 x i64] } %t313, 0
  %t316 = icmp eq i64 %t315, 14
  br i1 %t316, label %bb76, label %bb77
bb76:
  %t318 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t319 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t318, i32 0, i32 0
  %t320 = load { i64, [4 x i64] }, ptr %t319
  store { i64, [4 x i64] } %t320, ptr %l29
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l156, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load { i64, [4 x i64] }, ptr %l29
  %t327 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t323, { i64, [4 x i64] } %t324)
  store i32 %t327, ptr %l159
  br label %bb79
bb79:
  %t328 = load ptr, ptr %l156, !tbaa !29
  %t329 = load i32, ptr %l159, !tbaa !23
  %t330 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t330, ptr %l160
  br label %bb80
bb80:
  %t331 = load i32, ptr %l160, !tbaa !23
  store i32 %t331, ptr %l30, !tbaa !23
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_3d9554dfcf1aeb63_1386be72809b2127)
  unreachable
bb82:
  %t332 = load i32, ptr %l30, !tbaa !23
  store i32 %t332, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l2
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l41
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l41
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  store i32 %t62, ptr %l42
  br label %bb12
bb12:
  %t63 = load i32, ptr %l42, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:verifier", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i32, ptr %l10, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l48
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l52
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load i32, ptr %l48, !tbaa !23
  %t86 = load i32, ptr %l52, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t87, ptr %l53
  br label %bb15
bb15:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  store i32 %a1, ptr %l56
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s4, ptr %l56, i64 0)
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t94 = load ptr, ptr %s4
  %t95 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t94, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %sbgrew.103, label %sbdone.104
sbgrew.103:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.104
sbdone.104:
  %t105 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s3, ptr %s3, { i64, ptr } %t111)
  store { i64, ptr } %t113, ptr %l60
  br label %bb19
bb19:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l3, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t114, i32 %t115)
  store { i64, ptr } %t118, ptr %l63
  br label %bb20
bb20:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l10, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l66
  br label %bb21
bb21:
  %t124 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t125, i64 %t126)
  %t142 = getelementptr i8, ptr %t141, i64 %t126
  call void @olang_textcopy(ptr %t142, ptr %t127, i64 %t128)
  %t143 = getelementptr i8, ptr %t142, i64 %t128
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = getelementptr i8, ptr %t143, i64 %t132
  call void @olang_textcopy(ptr %t144, ptr %t134, i64 %t135)
  %t145 = getelementptr i8, ptr %t144, i64 %t135
  call void @olang_textcopy(ptr %t145, ptr %t138, i64 %t139)
  %t146 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t141, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } %t147, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t155 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t155, { i64, ptr } %t154)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t157 = load i32, ptr %l8, !tbaa !23
  %t159 = add i32 %t157, 1
  store i32 %t159, ptr %l8, !tbaa !23
  br label %bb7
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t20 = load i32, ptr %l5, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i1 %t24, ptr %l17
  br label %bb3
bb3:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t34 = trunc i64 19 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t44 = trunc i64 19 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l24, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l32
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l5, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l35
  br label %bb15
bb15:
  %t58 = load i32, ptr %l32, !tbaa !23
  %t59 = load i32, ptr %l35, !tbaa !23
  %t60 = icmp eq i32 %t58, %t59
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l41
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb18:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load i32, ptr %l5, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l44
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l41, !tbaa !23
  %t75 = load i32, ptr %l44, !tbaa !23
  %t76 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i1 %t76, ptr %l45
  br label %bb20
bb20:
  %t77 = load i1, ptr %l45, !tbaa !21
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t78 = load i1, ptr %l37, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/mir:Local"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/mir:Call"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:Case"
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/mir:Task"
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l52 = alloca %"compiler/mir:TaskClause"
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca { i64, [1 x i64] }
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, [1 x i64] }
  %l70 = alloca %"compiler/mir:Range"
  %l71 = alloca %"compiler/mir:Range"
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l91 = alloca i64
  %l98 = alloca i64
  %l106 = alloca i32
  %l113 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l128 = alloca i64
  %l131 = alloca i64
  %l136 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca %"compiler/mir:Local"
  %l178 = alloca ptr
  %l179 = alloca i64
  %l183 = alloca i32
  %l190 = alloca i1
  %l193 = alloca { i64, ptr }
  %l196 = alloca i1
  %l197 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l204 = alloca ptr
  %l208 = alloca i32
  %l211 = alloca { i64, ptr }
  %l214 = alloca i32
  %l215 = alloca i1
  %l220 = alloca i1
  %l224 = alloca { i64, ptr }
  %l227 = alloca i1
  %l229 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i64
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l250 = alloca i64
  %l252 = alloca i64
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i1
  %l266 = alloca %"compiler/mir:Local"
  %l278 = alloca i64
  %l282 = alloca i64
  %l285 = alloca i64
  %l306 = alloca %"compiler/mir:Local"
  %l320 = alloca i64
  %l324 = alloca i64
  %l327 = alloca i64
  %l348 = alloca %"compiler/mir:ScopeInfo"
  %l355 = alloca i1
  %l368 = alloca i64
  %l370 = alloca i64
  %l375 = alloca %"compiler/mir:Call"
  %l390 = alloca i1
  %l396 = alloca i1
  %l399 = alloca i1
  %l404 = alloca i64
  %l406 = alloca i64
  %l411 = alloca %"compiler/mir:Case"
  %l414 = alloca i1
  %l419 = alloca i64
  %l421 = alloca i64
  %l426 = alloca %"compiler/mir:Task"
  %l439 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca %"compiler/mir:Range"
  %l448 = alloca i64
  %l449 = alloca i1
  %l454 = alloca i32
  %l457 = alloca i32
  %l475 = alloca ptr
  %l483 = alloca %"compiler/mir:Lvalue"
  %l486 = alloca ptr
  %l487 = alloca %"compiler/mir:Range"
  %l490 = alloca i64
  %l491 = alloca i1
  %l496 = alloca i32
  %l499 = alloca i32
  %l524 = alloca %"compiler/mir:TaskClause"
  %l525 = alloca ptr
  %l526 = alloca %"compiler/mir:Range"
  %l529 = alloca i64
  %l530 = alloca i1
  %l539 = alloca i64
  %l541 = alloca i64
  %l546 = alloca { i64, [4 x i64] }
  %l553 = alloca i64
  %l555 = alloca i64
  %l560 = alloca { i64, [1 x i64] }
  %l567 = alloca i64
  %l569 = alloca i64
  %l574 = alloca { i64, [1 x i64] }
  %l580 = alloca i1
  %l585 = alloca i64
  %l589 = alloca i64
  %l592 = alloca i64
  %l613 = alloca { i64, [1 x i64] }
  %l617 = alloca ptr
  %l618 = alloca %"compiler/mir:Range"
  %l621 = alloca i64
  %l622 = alloca i1
  %l626 = alloca ptr
  %l627 = alloca %"compiler/mir:Range"
  %l630 = alloca i64
  %l631 = alloca i1
  %l639 = alloca i64
  %l643 = alloca i64
  %l646 = alloca i64
  %l669 = alloca ptr
  %l672 = alloca i64
  %l676 = alloca i64
  %l679 = alloca i64
  %l699 = alloca ptr
  %l703 = alloca { i64, [21 x i64] }
  %l719 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l91
  br label %bb1
bb1:
  %t11 = load i64, ptr %l91, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 3
  store i64 -1, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t17, i32 0, i32 4
  store i64 -1, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/mir:Fn", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l98
  br label %bb2
bb2:
  %t27 = load i64, ptr %l98, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t30, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/mir:verifier", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t40)
  store i32 %t43, ptr %l106
  br label %bb7
bb7:
  %t44 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t46 = trunc i64 21 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/mir:verifier", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l113, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:verifier", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/mir:Fn", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t61, i32 %t65)
  store i32 %t68, ptr %l118
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l113, !tbaa !29
  %t70 = load i32, ptr %l118, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l119
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l121, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/mir:Fn", ptr %t76, i32 0, i32 4
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l124
  br label %bb14
bb14:
  %t81 = load i64, ptr %l121, !tbaa !24
  %t82 = load i64, ptr %l124, !tbaa !24
  %t83 = icmp ne i64 %t81, %t82
  br i1 %t83, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l126, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l128, !tbaa !24
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/mir:Fn", ptr %t89, i32 0, i32 4
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l131
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t94 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t96 = load i64, ptr %l128, !tbaa !24
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t95, %t97
  %t99 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load i64, ptr %l131, !tbaa !24
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t102)
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t94, i64 %t95)
  %t106 = getelementptr i8, ptr %t105, i64 %t95
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t96)
  %t108 = getelementptr i8, ptr %t106, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t102)
  %t111 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t105, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } %t112, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t120, { i64, ptr } %t119)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 4
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l136
  br label %bb20
bb20:
  %t127 = load i64, ptr %l136, !tbaa !24
  store i64 %t127, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load i64, ptr %l6, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb21, label %bb22
bb21:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb26
bb23:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l143, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb25
bb25:
  %t154 = load i64, ptr %l143, !tbaa !24
  store i64 %t154, ptr %l140, !tbaa !24
  br label %bb26
bb26:
  %t155 = load i64, ptr %l140, !tbaa !24
  store i64 %t155, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb28, label %bb29
bb28:
  br label %bb71
bb29:
  br label %bb30
bb30:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t165 = load i64, ptr %l10, !tbaa !24
  %t166 = load i64, ptr %l8, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l11, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l161, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/mir:Fn", ptr %t175, i32 0, i32 4
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l165
  br label %bb31
bb31:
  %t182 = load ptr, ptr %l161, !tbaa !29
  %t183 = load i32, ptr %l165, !tbaa !23
  %t184 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t184, ptr %l166
  br label %bb32
bb32:
  %t185 = load i1, ptr %l166, !tbaa !21
  br i1 %t185, label %bb33, label %bb34
bb33:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/mir:Fn", ptr %t186, i32 0, i32 7
  store ptr %t188, ptr %l168, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/mir:Fn", ptr %t189, i32 0, i32 4
  %t192 = load i64, ptr %l11, !tbaa !24
  %t195 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t191, i64 %t192)
  store i32 %t195, ptr %l172
  br label %bb35
bb34:
  br label %bb69
bb35:
  %t196 = load i32, ptr %l172, !tbaa !23
  %t197 = sext i32 %t196 to i64
  %t198 = load ptr, ptr %l168, !tbaa !29
  %t200 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t198, i64 %t197)
  store %"compiler/mir:Local" %t200, ptr %l174
  br label %bb36
bb36:
  %t201 = load %"compiler/mir:Local", ptr %l174
  store %"compiler/mir:Local" %t201, ptr %l12
  %t202 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t203 = load i32, ptr %t202, !range !{i32 0, i32 4}
  %t205 = trunc i64 0 to i32
  %t206 = icmp eq i32 %t203, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l178, !tbaa !29
  %t211 = load i64, ptr %l11, !tbaa !24
  store i64 %t211, ptr %l179, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/mir:Fn", ptr %t212, i32 0, i32 4
  %t215 = load i64, ptr %l11, !tbaa !24
  %t218 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l183
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t219 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t221 = load i64, ptr %l179, !tbaa !24
  %t222 = call i64 @__olang_fmt_i64(ptr null, i64 %t221)
  %t223 = add i64 %t220, %t222
  %t224 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = load i32, ptr %l183, !tbaa !23
  %t228 = sext i32 %t227 to i64
  %t229 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t219, i64 %t220)
  %t235 = getelementptr i8, ptr %t234, i64 %t220
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t221)
  %t237 = getelementptr i8, ptr %t235, i64 %t222
  call void @olang_textcopy(ptr %t237, ptr %t224, i64 %t225)
  %t238 = getelementptr i8, ptr %t237, i64 %t225
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t228)
  %t240 = getelementptr i8, ptr %t238, i64 %t229
  call void @olang_textcopy(ptr %t240, ptr %t231, i64 %t232)
  %t241 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t234, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t250 = load ptr, ptr %l178, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t250, { i64, ptr } %t249)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t258 = icmp slt i64 %t252, %t255
  br i1 %t258, label %bb42, label %bb43
bb42:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/mir:verifier", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t264, ptr %l193, !tbaa !27
  %t265 = load i64, ptr %l11, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t265
  %t270 = load i32, ptr %t269, !tbaa !33
  %t273 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %t263, i32 %t270)
  store i1 %t273, ptr %l196
  br label %bb44
bb43:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb45
bb44:
  %t274 = load i1, ptr %l196, !tbaa !21
  store i1 %t274, ptr %l190, !tbaa !21
  br label %bb45
bb45:
  %t275 = load i1, ptr %l190, !tbaa !21
  br i1 %t275, label %bb46, label %bb47
bb46:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/mir:verifier", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t280 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t281 = load i32, ptr %t280, !tbaa !23
  %t284 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t279, i32 %t281)
  store i1 %t284, ptr %l201
  br label %bb48
bb47:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb49
bb48:
  %t285 = load i1, ptr %l201, !tbaa !21
  store i1 %t285, ptr %l197, !tbaa !21
  br label %bb49
bb49:
  %t286 = load i1, ptr %l197, !tbaa !21
  br i1 %t286, label %bb50, label %bb51
bb50:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/mir:verifier", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  store ptr %t290, ptr %l204, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/mir:verifier", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t295 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t296 = load i32, ptr %t295, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t294, i32 %t296)
  store i32 %t299, ptr %l208
  br label %bb52
bb51:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb55
bb52:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/mir:verifier", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t304, ptr %l211, !tbaa !27
  %t305 = load i64, ptr %l11, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i32, ptr %t308, i64 %t305
  %t310 = load i32, ptr %t309, !tbaa !33
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t303, i32 %t310)
  store i32 %t313, ptr %l214
  br label %bb53
bb53:
  %t314 = load ptr, ptr %l204, !tbaa !29
  %t315 = load i32, ptr %l208, !tbaa !23
  %t316 = load i32, ptr %l214, !tbaa !23
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t314, i32 %t315, i32 %t316)
  store i1 %t317, ptr %l215
  br label %bb54
bb54:
  %t318 = load i1, ptr %l215, !tbaa !21
  store i1 %t318, ptr %l202, !tbaa !21
  br label %bb55
bb55:
  %t319 = load i1, ptr %l202, !tbaa !21
  store i1 %t319, ptr %l13, !tbaa !21
  %t320 = load i64, ptr %l11, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t326 = icmp slt i64 %t320, %t323
  br i1 %t326, label %bb56, label %bb57
bb56:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/mir:verifier", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t333 = load i32, ptr %t332, !tbaa !23
  %t334 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t334, ptr %l224, !tbaa !27
  %t335 = load i64, ptr %l11, !tbaa !24
  %t337 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr i32, ptr %t338, i64 %t335
  %t340 = load i32, ptr %t339, !tbaa !33
  %t344 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t331, i32 %t333, i32 %t340)
  store i1 %t344, ptr %l227
  br label %bb58
bb57:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb59
bb58:
  %t345 = load i1, ptr %l227, !tbaa !21
  %t346 = xor i1 %t345, true
  store i1 %t346, ptr %l220, !tbaa !21
  br label %bb59
bb59:
  %t348 = load i1, ptr %l220, !tbaa !21
  br i1 %t348, label %bb60, label %bb61
bb60:
  %t349 = load i1, ptr %l13, !tbaa !21
  %t351 = xor i1 %t349, true
  store i1 %t351, ptr %l229, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb62
bb62:
  %t353 = load i1, ptr %l229, !tbaa !21
  br i1 %t353, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l232, !tbaa !29
  %t355 = load i64, ptr %l11, !tbaa !24
  store i64 %t355, ptr %l233, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/mir:verifier", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t361 = load i32, ptr %t360, !tbaa !23
  %t364 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s10, ptr %t359, i32 %t361)
  store { i64, ptr } %t364, ptr %l237
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/mir:verifier", ptr %t365, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t369, ptr %l240, !tbaa !27
  %t370 = load i64, ptr %l11, !tbaa !24
  %t372 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr i32, ptr %t373, i64 %t370
  %t375 = load i32, ptr %t374, !tbaa !33
  %t378 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s10, ptr %t368, i32 %t375)
  store { i64, ptr } %t378, ptr %l243
  br label %bb66
bb66:
  %t379 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t381 = load i64, ptr %l233, !tbaa !24
  %t382 = call i64 @__olang_fmt_i64(ptr null, i64 %t381)
  %t383 = add i64 %t380, %t382
  %t384 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t387 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = add i64 %t386, %t389
  %t391 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = add i64 %t393, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t379, i64 %t380)
  %t399 = getelementptr i8, ptr %t398, i64 %t380
  %t400 = call i64 @__olang_fmt_i64(ptr %t399, i64 %t381)
  %t401 = getelementptr i8, ptr %t399, i64 %t382
  call void @olang_textcopy(ptr %t401, ptr %t384, i64 %t385)
  %t402 = getelementptr i8, ptr %t401, i64 %t385
  call void @olang_textcopy(ptr %t402, ptr %t388, i64 %t389)
  %t403 = getelementptr i8, ptr %t402, i64 %t389
  call void @olang_textcopy(ptr %t403, ptr %t391, i64 %t392)
  %t404 = getelementptr i8, ptr %t403, i64 %t392
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t398, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } %t406, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t414 = load ptr, ptr %l232, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t414, { i64, ptr } %t413)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t416 = load i64, ptr %l10, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l10, !tbaa !24
  br label %bb27
bb71:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr %"compiler/mir:Fn", ptr %t420, i32 0, i32 5
  store ptr %t422, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb72
bb72:
  %t424 = load i64, ptr %l15, !tbaa !24
  store i64 %t424, ptr %l250, !tbaa !24
  %t425 = load ptr, ptr %l14, !tbaa !29
  %t427 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t425)
  store i64 %t427, ptr %l252
  br label %bb73
bb73:
  %t428 = load i64, ptr %l250, !tbaa !24
  %t429 = load i64, ptr %l252, !tbaa !24
  %t430 = icmp slt i64 %t428, %t429
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb74, label %bb75
bb74:
  br label %bb88
bb75:
  br label %bb76
bb76:
  %t434 = load ptr, ptr %l14, !tbaa !29
  %t435 = load i64, ptr %l15, !tbaa !24
  %t438 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t434, i64 %t435)
  store i32 %t438, ptr %l257
  br label %bb77
bb77:
  %t439 = load i32, ptr %l257, !tbaa !23
  store i32 %t439, ptr %l16, !tbaa !23
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l16, !tbaa !23
  %t444 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t440, i32 %t441)
  store i1 %t444, ptr %l260
  br label %bb78
bb78:
  %t445 = load i1, ptr %l260, !tbaa !21
  br i1 %t445, label %bb79, label %bb80
bb79:
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t448 = getelementptr %"compiler/mir:Fn", ptr %t446, i32 0, i32 7
  %t449 = load i32, ptr %l16, !tbaa !23
  %t451 = sext i32 %t449 to i64
  %t454 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t448, i64 %t451)
  store %"compiler/mir:Local" %t454, ptr %l266
  br label %bb81
bb80:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb82
bb81:
  %t455 = getelementptr %"compiler/mir:Local", ptr %l266, i32 0, i32 3
  %t456 = load i32, ptr %t455, !range !{i32 0, i32 4}
  %t458 = trunc i64 1 to i32
  %t459 = icmp eq i32 %t456, %t458
  %t461 = xor i1 %t459, true
  store i1 %t461, ptr %l261, !tbaa !21
  br label %bb82
bb82:
  %t463 = load i1, ptr %l261, !tbaa !21
  br i1 %t463, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s15
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i32, ptr %l16, !tbaa !23
  %t466 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t469 = sext i32 %t465 to i64
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t469)
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t466, i64 %t467)
  %t476 = getelementptr i8, ptr %t475, i64 %t467
  %t477 = call i64 @__olang_fmt_i64(ptr %t476, i64 %t469)
  %t478 = getelementptr i8, ptr %t476, i64 %t470
  call void @olang_textcopy(ptr %t478, ptr %t472, i64 %t473)
  %t479 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t475, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = extractvalue { i64, ptr } %t480, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t464, { i64, ptr } %t487)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t490 = load i64, ptr %l15, !tbaa !24
  %t492 = add i64 %t490, 1
  store i64 %t492, ptr %l15, !tbaa !24
  br label %bb72
bb88:
  store i64 0, ptr %l17, !tbaa !24
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr %"compiler/mir:Fn", ptr %t494, i32 0, i32 7
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t496)
  store i64 %t498, ptr %l278
  br label %bb89
bb89:
  %t499 = load i64, ptr %l278, !tbaa !24
  store i64 %t499, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t500 = load i64, ptr %l18, !tbaa !24
  %t501 = load i64, ptr %l17, !tbaa !24
  %t504 = icmp sgt i64 %t500, %t501
  br i1 %t504, label %bb90, label %bb91
bb90:
  %t506 = load i64, ptr %l19, !tbaa !24
  %t508 = icmp sgt i64 %t506, 0
  br i1 %t508, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb95
bb92:
  %t510 = load i64, ptr %l18, !tbaa !24
  %t511 = load i64, ptr %l17, !tbaa !24
  %t514 = sub i64 %t510, %t511
  %t515 = load i64, ptr %l19, !tbaa !24
  %t518 = add i64 %t514, %t515
  %t520 = sub i64 %t518, 1
  %t521 = load i64, ptr %l19, !tbaa !24
  %t524 = sdiv i64 %t520, %t521
  store i64 %t524, ptr %l285, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l285, !tbaa !24
  br label %bb94
bb94:
  %t526 = load i64, ptr %l285, !tbaa !24
  store i64 %t526, ptr %l282, !tbaa !24
  br label %bb95
bb95:
  %t527 = load i64, ptr %l282, !tbaa !24
  store i64 %t527, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb96
bb96:
  %t528 = load i64, ptr %l21, !tbaa !24
  %t529 = load i64, ptr %l20, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb97, label %bb98
bb97:
  br label %bb107
bb98:
  br label %bb99
bb99:
  %t536 = load i64, ptr %l17, !tbaa !24
  %t537 = load i64, ptr %l21, !tbaa !24
  %t538 = load i64, ptr %l19, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  store i64 %t544, ptr %l22, !tbaa !24
  %t546 = load ptr, ptr %l1, !tbaa !29
  %t548 = getelementptr %"compiler/mir:Fn", ptr %t546, i32 0, i32 7
  %t549 = load i64, ptr %l22, !tbaa !24
  %t552 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t548, i64 %t549)
  store %"compiler/mir:Local" %t552, ptr %l306
  br label %bb100
bb100:
  %t553 = load %"compiler/mir:Local", ptr %l306
  store %"compiler/mir:Local" %t553, ptr %l23
  %t554 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 2
  %t555 = load i32, ptr %t554, !tbaa !23
  %t556 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t559 = icmp eq i32 %t555, %t556
  br i1 %t559, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s20
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load i64, ptr %l22, !tbaa !24
  %t563 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t566 = call i64 @__olang_fmt_i64(ptr null, i64 %t562)
  %t567 = add i64 %t564, %t566
  %t568 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t569 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t570 = add i64 %t567, %t569
  %t571 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t563, i64 %t564)
  %t572 = getelementptr i8, ptr %t571, i64 %t564
  %t573 = call i64 @__olang_fmt_i64(ptr %t572, i64 %t562)
  %t574 = getelementptr i8, ptr %t572, i64 %t566
  call void @olang_textcopy(ptr %t574, ptr %t568, i64 %t569)
  %t575 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t571, 1
  %t578 = extractvalue { i64, ptr } %t576, 0
  %t579 = extractvalue { i64, ptr } %t576, 1
  %t580 = mul i64 %t578, 1
  %t581 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t580)
  call void @llvm.memcpy.p0.p0.i64(ptr %t581, ptr %t579, i64 %t580, i1 false)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t581, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t561, { i64, ptr } %t583)
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb104
bb104:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 4
  %t588 = load { i64, [1 x i64] }, ptr %t587
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t586, { i64, [1 x i64] } %t588)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t591 = load i64, ptr %l21, !tbaa !24
  %t593 = add i64 %t591, 1
  store i64 %t593, ptr %l21, !tbaa !24
  br label %bb96
bb107:
  store i64 0, ptr %l24, !tbaa !24
  %t595 = load ptr, ptr %l1, !tbaa !29
  %t597 = getelementptr %"compiler/mir:Fn", ptr %t595, i32 0, i32 8
  %t599 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t597)
  store i64 %t599, ptr %l320
  br label %bb108
bb108:
  %t600 = load i64, ptr %l320, !tbaa !24
  store i64 %t600, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t601 = load i64, ptr %l25, !tbaa !24
  %t602 = load i64, ptr %l24, !tbaa !24
  %t605 = icmp sgt i64 %t601, %t602
  br i1 %t605, label %bb109, label %bb110
bb109:
  %t607 = load i64, ptr %l26, !tbaa !24
  %t609 = icmp sgt i64 %t607, 0
  br i1 %t609, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb114
bb111:
  %t611 = load i64, ptr %l25, !tbaa !24
  %t612 = load i64, ptr %l24, !tbaa !24
  %t615 = sub i64 %t611, %t612
  %t616 = load i64, ptr %l26, !tbaa !24
  %t619 = add i64 %t615, %t616
  %t621 = sub i64 %t619, 1
  %t622 = load i64, ptr %l26, !tbaa !24
  %t625 = sdiv i64 %t621, %t622
  store i64 %t625, ptr %l327, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb113
bb113:
  %t627 = load i64, ptr %l327, !tbaa !24
  store i64 %t627, ptr %l324, !tbaa !24
  br label %bb114
bb114:
  %t628 = load i64, ptr %l324, !tbaa !24
  store i64 %t628, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb115
bb115:
  %t629 = load i64, ptr %l28, !tbaa !24
  %t630 = load i64, ptr %l27, !tbaa !24
  %t633 = icmp slt i64 %t629, %t630
  %t635 = xor i1 %t633, true
  br i1 %t635, label %bb116, label %bb117
bb116:
  br label %bb128
bb117:
  br label %bb118
bb118:
  %t637 = load i64, ptr %l24, !tbaa !24
  %t638 = load i64, ptr %l28, !tbaa !24
  %t639 = load i64, ptr %l26, !tbaa !24
  %t642 = mul i64 %t638, %t639
  %t645 = add i64 %t637, %t642
  store i64 %t645, ptr %l29, !tbaa !24
  %t647 = load ptr, ptr %l1, !tbaa !29
  %t649 = getelementptr %"compiler/mir:Fn", ptr %t647, i32 0, i32 8
  %t650 = load i64, ptr %l29, !tbaa !24
  %t653 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t649, i64 %t650)
  store %"compiler/mir:ScopeInfo" %t653, ptr %l348
  br label %bb119
bb119:
  %t654 = getelementptr %"compiler/mir:ScopeInfo", ptr %l348, i32 0, i32 1
  %t655 = load i32, ptr %t654, !tbaa !23
  store i32 %t655, ptr %l30, !tbaa !23
  %t657 = load i32, ptr %l30, !tbaa !23
  %t658 = load i64, ptr %l29, !tbaa !24
  %t660 = trunc i64 %t658 to i32
  %t664 = icmp sge i32 %t657, %t660
  br i1 %t664, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l355, !tbaa !21
  br label %bb122
bb121:
  %t666 = load i32, ptr %l30, !tbaa !23
  %t667 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t670 = icmp slt i32 %t666, %t667
  store i1 %t670, ptr %l355, !tbaa !21
  br label %bb122
bb122:
  %t672 = load i1, ptr %l355, !tbaa !21
  br i1 %t672, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s25
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load i64, ptr %l29, !tbaa !24
  %t675 = load i32, ptr %l30, !tbaa !23
  %t676 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t677 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t679 = call i64 @__olang_fmt_i64(ptr null, i64 %t674)
  %t680 = add i64 %t677, %t679
  %t681 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t683 = add i64 %t680, %t682
  %t685 = sext i32 %t675 to i64
  %t686 = call i64 @__olang_fmt_i64(ptr null, i64 %t685)
  %t687 = add i64 %t683, %t686
  %t688 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t690)
  call void @olang_textcopy(ptr %t691, ptr %t676, i64 %t677)
  %t692 = getelementptr i8, ptr %t691, i64 %t677
  %t693 = call i64 @__olang_fmt_i64(ptr %t692, i64 %t674)
  %t694 = getelementptr i8, ptr %t692, i64 %t679
  call void @olang_textcopy(ptr %t694, ptr %t681, i64 %t682)
  %t695 = getelementptr i8, ptr %t694, i64 %t682
  %t696 = call i64 @__olang_fmt_i64(ptr %t695, i64 %t685)
  %t697 = getelementptr i8, ptr %t695, i64 %t686
  call void @olang_textcopy(ptr %t697, ptr %t688, i64 %t689)
  %t698 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t691, 1
  %t701 = extractvalue { i64, ptr } %t699, 0
  %t702 = extractvalue { i64, ptr } %t699, 1
  %t703 = mul i64 %t701, 1
  %t704 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t703)
  call void @llvm.memcpy.p0.p0.i64(ptr %t704, ptr %t702, i64 %t703, i1 false)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t704, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t673, { i64, ptr } %t706)
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t709 = load i64, ptr %l28, !tbaa !24
  %t711 = add i64 %t709, 1
  store i64 %t711, ptr %l28, !tbaa !24
  br label %bb115
bb128:
  %t713 = load ptr, ptr %l1, !tbaa !29
  %t715 = getelementptr %"compiler/mir:Fn", ptr %t713, i32 0, i32 14
  store ptr %t715, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb129
bb129:
  %t717 = load i64, ptr %l32, !tbaa !24
  store i64 %t717, ptr %l368, !tbaa !24
  %t718 = load ptr, ptr %l31, !tbaa !29
  %t720 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t718)
  store i64 %t720, ptr %l370
  br label %bb130
bb130:
  %t721 = load i64, ptr %l368, !tbaa !24
  %t722 = load i64, ptr %l370, !tbaa !24
  %t723 = icmp slt i64 %t721, %t722
  %t725 = xor i1 %t723, true
  br i1 %t725, label %bb131, label %bb132
bb131:
  br label %bb152
bb132:
  br label %bb133
bb133:
  %t727 = load ptr, ptr %l31, !tbaa !29
  %t728 = load i64, ptr %l32, !tbaa !24
  %t731 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t727, i64 %t728)
  store %"compiler/mir:Call" %t731, ptr %l375
  br label %bb134
bb134:
  %t732 = load %"compiler/mir:Call", ptr %l375
  store %"compiler/mir:Call" %t732, ptr %l33
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t734 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 0
  %t735 = load { i64, [7 x i64] }, ptr %t734
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t733, { i64, [7 x i64] } %t735)
  br label %bb135
bb135:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 1
  %t740 = load %"compiler/mir:Range", ptr %t739
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t738, %"compiler/mir:Range" %t740)
  br label %bb136
bb136:
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 2
  %t745 = load %"compiler/mir:Range", ptr %t744
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t743, %"compiler/mir:Range" %t745)
  br label %bb137
bb137:
  %t748 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 4
  %t749 = load i1, ptr %t748, !tbaa !21
  br i1 %t749, label %bb138, label %bb139
bb138:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 3
  %t753 = load %"compiler/mir:Lvalue", ptr %t752
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t751, %"compiler/mir:Lvalue" %t753)
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  %t756 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t757 = load i32, ptr %t756, !tbaa !23
  %t758 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t761 = icmp ne i32 %t757, %t758
  br i1 %t761, label %bb142, label %bb143
bb142:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t764 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t765 = load i32, ptr %t764, !tbaa !23
  %t768 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t763, i32 %t765)
  store i1 %t768, ptr %l390
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  %t769 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t770 = load i32, ptr %t769, !tbaa !23
  %t771 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t774 = icmp ne i32 %t770, %t771
  br i1 %t774, label %bb146, label %bb147
bb146:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t778 = load i32, ptr %t777, !tbaa !23
  %t781 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t776, i32 %t778)
  store i1 %t781, ptr %l396
  br label %bb148
bb147:
  br label %bb150
bb148:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 6
  %t784 = load i32, ptr %t783, !tbaa !23
  %t787 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t782, i32 %t784)
  store i1 %t787, ptr %l399
  br label %bb149
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t788 = load i64, ptr %l32, !tbaa !24
  %t790 = add i64 %t788, 1
  store i64 %t790, ptr %l32, !tbaa !24
  br label %bb129
bb152:
  %t792 = load ptr, ptr %l1, !tbaa !29
  %t794 = getelementptr %"compiler/mir:Fn", ptr %t792, i32 0, i32 15
  store ptr %t794, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb153
bb153:
  %t796 = load i64, ptr %l35, !tbaa !24
  store i64 %t796, ptr %l404, !tbaa !24
  %t797 = load ptr, ptr %l34, !tbaa !29
  %t799 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t797)
  store i64 %t799, ptr %l406
  br label %bb154
bb154:
  %t800 = load i64, ptr %l404, !tbaa !24
  %t801 = load i64, ptr %l406, !tbaa !24
  %t802 = icmp slt i64 %t800, %t801
  %t804 = xor i1 %t802, true
  br i1 %t804, label %bb155, label %bb156
bb155:
  br label %bb161
bb156:
  br label %bb157
bb157:
  %t806 = load ptr, ptr %l34, !tbaa !29
  %t807 = load i64, ptr %l35, !tbaa !24
  %t810 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t806, i64 %t807)
  store %"compiler/mir:Case" %t810, ptr %l411
  br label %bb158
bb158:
  %t811 = load %"compiler/mir:Case", ptr %l411
  store %"compiler/mir:Case" %t811, ptr %l36
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = getelementptr %"compiler/mir:Case", ptr %l36, i32 0, i32 1
  %t814 = load i32, ptr %t813, !tbaa !23
  %t817 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t812, i32 %t814)
  store i1 %t817, ptr %l414
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t818 = load i64, ptr %l35, !tbaa !24
  %t820 = add i64 %t818, 1
  store i64 %t820, ptr %l35, !tbaa !24
  br label %bb153
bb161:
  %t822 = load ptr, ptr %l1, !tbaa !29
  %t824 = getelementptr %"compiler/mir:Fn", ptr %t822, i32 0, i32 16
  store ptr %t824, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s38
  %t826 = load i64, ptr %l38, !tbaa !24
  store i64 %t826, ptr %l419, !tbaa !24
  %t827 = load ptr, ptr %l37, !tbaa !29
  %t829 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t827)
  store i64 %t829, ptr %l421
  br label %bb163
bb163:
  %t830 = load i64, ptr %l419, !tbaa !24
  %t831 = load i64, ptr %l421, !tbaa !24
  %t832 = icmp slt i64 %t830, %t831
  %t834 = xor i1 %t832, true
  br i1 %t834, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s38)
  br label %bb221
bb165:
  br label %bb166
bb166:
  %t836 = load ptr, ptr %l37, !tbaa !29
  %t837 = load i64, ptr %l38, !tbaa !24
  %t840 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t836, i64 %t837)
  store %"compiler/mir:Task" %t840, ptr %l426
  br label %bb167
bb167:
  %t841 = load %"compiler/mir:Task", ptr %l426
  store %"compiler/mir:Task" %t841, ptr %l39
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 0
  %t844 = load { i64, [7 x i64] }, ptr %t843
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t842, { i64, [7 x i64] } %t844)
  br label %bb168
bb168:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 1
  %t849 = load %"compiler/mir:Range", ptr %t848
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t847, %"compiler/mir:Range" %t849)
  br label %bb169
bb169:
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 5
  %t854 = load %"compiler/mir:Range", ptr %t853
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t852, %"compiler/mir:Range" %t854)
  br label %bb170
bb170:
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 2
  %t859 = load %"compiler/mir:Range", ptr %t858
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t857, %"compiler/mir:Range" %t859)
  br label %bb171
bb171:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t864 = load %"compiler/mir:Range", ptr %t863
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t862, %"compiler/mir:Range" %t864)
  br label %bb172
bb172:
  %t867 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t868 = getelementptr %"compiler/mir:Range", ptr %t867, i32 0, i32 1
  %t869 = load i32, ptr %t868, !tbaa !23
  %t871 = icmp ne i32 %t869, 0
  br i1 %t871, label %bb173, label %bb174
bb173:
  %t873 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t874 = getelementptr %"compiler/mir:Range", ptr %t873, i32 0, i32 1
  %t875 = load i32, ptr %t874, !tbaa !23
  %t876 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t877 = getelementptr %"compiler/mir:Range", ptr %t876, i32 0, i32 1
  %t878 = load i32, ptr %t877, !tbaa !23
  %t881 = icmp ne i32 %t875, %t878
  store i1 %t881, ptr %l439, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb175
bb175:
  %t883 = load i1, ptr %l439, !tbaa !21
  br i1 %t883, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s39
  %t884 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t884, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s39)
  br label %bb179
bb179:
  %t886 = load ptr, ptr %l0, !tbaa !29
  store ptr %t886, ptr %l444, !tbaa !29
  %t887 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t888 = load %"compiler/mir:Range", ptr %t887
  store %"compiler/mir:Range" %t888, ptr %l445
  %t889 = load ptr, ptr %l1, !tbaa !29
  %t891 = getelementptr %"compiler/mir:Fn", ptr %t889, i32 0, i32 13
  %t893 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t891)
  store i64 %t893, ptr %l448
  br label %bb180
bb180:
  %t894 = load ptr, ptr %l444, !tbaa !29
  %t895 = load %"compiler/mir:Range", ptr %l445
  %t896 = load i64, ptr %l448, !tbaa !24
  %t897 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t894, %"compiler/mir:Range" %t895, i64 %t896, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d148, i32 0, i32 1) })
  store i1 %t897, ptr %l449
  br label %bb181
bb181:
  %t898 = load i1, ptr %l449, !tbaa !21
  br i1 %t898, label %bb182, label %bb183
bb182:
  store i32 0, ptr %l40, !tbaa !23
  %t899 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t900 = getelementptr %"compiler/mir:Range", ptr %t899, i32 0, i32 1
  %t901 = load i32, ptr %t900, !tbaa !23
  store i32 %t901, ptr %l41, !tbaa !23
  store i32 1, ptr %l42, !tbaa !23
  %t903 = load i32, ptr %l41, !tbaa !23
  %t904 = load i32, ptr %l40, !tbaa !23
  %t907 = icmp sgt i32 %t903, %t904
  br i1 %t907, label %bb184, label %bb185
bb183:
  br label %bb198
bb184:
  %t909 = load i32, ptr %l42, !tbaa !23
  %t911 = icmp sgt i32 %t909, 0
  br i1 %t911, label %bb186, label %bb187
bb185:
  store i32 0, ptr %l454, !tbaa !23
  br label %bb189
bb186:
  %t913 = load i32, ptr %l41, !tbaa !23
  %t914 = load i32, ptr %l40, !tbaa !23
  %t917 = sub i32 %t913, %t914
  %t918 = load i32, ptr %l42, !tbaa !23
  %t921 = add i32 %t917, %t918
  %t923 = sub i32 %t921, 1
  %t924 = load i32, ptr %l42, !tbaa !23
  %t927 = sdiv i32 %t923, %t924
  store i32 %t927, ptr %l457, !tbaa !23
  br label %bb188
bb187:
  store i32 0, ptr %l457, !tbaa !23
  br label %bb188
bb188:
  %t929 = load i32, ptr %l457, !tbaa !23
  store i32 %t929, ptr %l454, !tbaa !23
  br label %bb189
bb189:
  %t930 = load i32, ptr %l454, !tbaa !23
  store i32 %t930, ptr %l43, !tbaa !23
  store i32 0, ptr %l44, !tbaa !23
  br label %bb190
bb190:
  %t931 = load i32, ptr %l44, !tbaa !23
  %t932 = load i32, ptr %l43, !tbaa !23
  %t935 = icmp slt i32 %t931, %t932
  %t937 = xor i1 %t935, true
  br i1 %t937, label %bb191, label %bb192
bb191:
  br label %bb197
bb192:
  br label %bb193
bb193:
  %t939 = load i32, ptr %l40, !tbaa !23
  %t940 = load i32, ptr %l44, !tbaa !23
  %t941 = load i32, ptr %l42, !tbaa !23
  %t944 = mul i32 %t940, %t941
  %t947 = add i32 %t939, %t944
  %t949 = load ptr, ptr %l0, !tbaa !29
  store ptr %t949, ptr %l475, !tbaa !29
  %t950 = load ptr, ptr %l1, !tbaa !29
  %t952 = getelementptr %"compiler/mir:Fn", ptr %t950, i32 0, i32 13
  %t953 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t954 = getelementptr %"compiler/mir:Range", ptr %t953, i32 0, i32 0
  %t955 = load i32, ptr %t954, !tbaa !23
  %t957 = sext i32 %t955 to i64
  %t960 = sext i32 %t947 to i64
  %t963 = add i64 %t957, %t960
  %t966 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t952, i64 %t963)
  store %"compiler/mir:Lvalue" %t966, ptr %l483
  br label %bb194
bb194:
  %t967 = load ptr, ptr %l475, !tbaa !29
  %t968 = load %"compiler/mir:Lvalue", ptr %l483
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t967, %"compiler/mir:Lvalue" %t968)
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t969 = load i32, ptr %l44, !tbaa !23
  %t971 = add i32 %t969, 1
  store i32 %t971, ptr %l44, !tbaa !23
  br label %bb190
bb197:
  br label %bb198
bb198:
  %t973 = load ptr, ptr %l0, !tbaa !29
  store ptr %t973, ptr %l486, !tbaa !29
  %t974 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t975 = load %"compiler/mir:Range", ptr %t974
  store %"compiler/mir:Range" %t975, ptr %l487
  %t976 = load ptr, ptr %l1, !tbaa !29
  %t978 = getelementptr %"compiler/mir:Fn", ptr %t976, i32 0, i32 17
  %t980 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t978)
  store i64 %t980, ptr %l490
  br label %bb199
bb199:
  %t981 = load ptr, ptr %l486, !tbaa !29
  %t982 = load %"compiler/mir:Range", ptr %l487
  %t983 = load i64, ptr %l490, !tbaa !24
  %t984 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t981, %"compiler/mir:Range" %t982, i64 %t983, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t984, ptr %l491
  br label %bb200
bb200:
  %t985 = load i1, ptr %l491, !tbaa !21
  br i1 %t985, label %bb201, label %bb202
bb201:
  store i32 0, ptr %l46, !tbaa !23
  %t986 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t987 = getelementptr %"compiler/mir:Range", ptr %t986, i32 0, i32 1
  %t988 = load i32, ptr %t987, !tbaa !23
  store i32 %t988, ptr %l47, !tbaa !23
  store i32 1, ptr %l48, !tbaa !23
  %t990 = load i32, ptr %l47, !tbaa !23
  %t991 = load i32, ptr %l46, !tbaa !23
  %t994 = icmp sgt i32 %t990, %t991
  br i1 %t994, label %bb203, label %bb204
bb202:
  br label %bb219
bb203:
  %t996 = load i32, ptr %l48, !tbaa !23
  %t998 = icmp sgt i32 %t996, 0
  br i1 %t998, label %bb205, label %bb206
bb204:
  store i32 0, ptr %l496, !tbaa !23
  br label %bb208
bb205:
  %t1000 = load i32, ptr %l47, !tbaa !23
  %t1001 = load i32, ptr %l46, !tbaa !23
  %t1004 = sub i32 %t1000, %t1001
  %t1005 = load i32, ptr %l48, !tbaa !23
  %t1008 = add i32 %t1004, %t1005
  %t1010 = sub i32 %t1008, 1
  %t1011 = load i32, ptr %l48, !tbaa !23
  %t1014 = sdiv i32 %t1010, %t1011
  store i32 %t1014, ptr %l499, !tbaa !23
  br label %bb207
bb206:
  store i32 0, ptr %l499, !tbaa !23
  br label %bb207
bb207:
  %t1016 = load i32, ptr %l499, !tbaa !23
  store i32 %t1016, ptr %l496, !tbaa !23
  br label %bb208
bb208:
  %t1017 = load i32, ptr %l496, !tbaa !23
  store i32 %t1017, ptr %l49, !tbaa !23
  store i32 0, ptr %l50, !tbaa !23
  br label %bb209
bb209:
  store %olang.scope zeroinitializer, ptr %s46
  %t1018 = load i32, ptr %l50, !tbaa !23
  %t1019 = load i32, ptr %l49, !tbaa !23
  %t1022 = icmp slt i32 %t1018, %t1019
  %t1024 = xor i1 %t1022, true
  br i1 %t1024, label %bb210, label %bb211
bb210:
  call void @__olang_scope_close(ptr %s46)
  br label %bb218
bb211:
  br label %bb212
bb212:
  %t1026 = load i32, ptr %l46, !tbaa !23
  %t1027 = load i32, ptr %l50, !tbaa !23
  %t1028 = load i32, ptr %l48, !tbaa !23
  %t1031 = mul i32 %t1027, %t1028
  %t1034 = add i32 %t1026, %t1031
  %t1036 = load ptr, ptr %l1, !tbaa !29
  %t1038 = getelementptr %"compiler/mir:Fn", ptr %t1036, i32 0, i32 17
  %t1039 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1040 = getelementptr %"compiler/mir:Range", ptr %t1039, i32 0, i32 0
  %t1041 = load i32, ptr %t1040, !tbaa !23
  %t1043 = sext i32 %t1041 to i64
  %t1046 = sext i32 %t1034 to i64
  %t1049 = add i64 %t1043, %t1046
  %t1052 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t1038, i64 %t1049)
  store %"compiler/mir:TaskClause" %t1052, ptr %l524
  br label %bb213
bb213:
  %t1053 = load %"compiler/mir:TaskClause", ptr %l524
  store %"compiler/mir:TaskClause" %t1053, ptr %l52
  %t1054 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1054, ptr %l525, !tbaa !29
  %t1055 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 0
  %t1056 = load %"compiler/mir:Range", ptr %t1055
  store %"compiler/mir:Range" %t1056, ptr %l526
  %t1057 = load ptr, ptr %l1, !tbaa !29
  %t1059 = getelementptr %"compiler/mir:Fn", ptr %t1057, i32 0, i32 18
  %t1061 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t1059)
  store i64 %t1061, ptr %l529
  br label %bb214
bb214:
  %t1062 = load ptr, ptr %l525, !tbaa !29
  %t1063 = load %"compiler/mir:Range", ptr %l526
  %t1064 = load i64, ptr %l529, !tbaa !24
  %t1065 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s46, ptr %t1062, %"compiler/mir:Range" %t1063, i64 %t1064, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t1065, ptr %l530
  br label %bb215
bb215:
  %t1066 = load ptr, ptr %l0, !tbaa !29
  %t1067 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 2
  %t1068 = load { i64, [4 x i64] }, ptr %t1067
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1066, { i64, [4 x i64] } %t1068)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s46)
  br label %bb217
bb217:
  %t1071 = load i32, ptr %l50, !tbaa !23
  %t1073 = add i32 %t1071, 1
  store i32 %t1073, ptr %l50, !tbaa !23
  br label %bb209
bb218:
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s38)
  br label %bb220
bb220:
  %t1075 = load i64, ptr %l38, !tbaa !24
  %t1077 = add i64 %t1075, 1
  store i64 %t1077, ptr %l38, !tbaa !24
  br label %bb162
bb221:
  %t1079 = load ptr, ptr %l1, !tbaa !29
  %t1081 = getelementptr %"compiler/mir:Fn", ptr %t1079, i32 0, i32 11
  store ptr %t1081, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb222
bb222:
  %t1083 = load i64, ptr %l54, !tbaa !24
  store i64 %t1083, ptr %l539, !tbaa !24
  %t1084 = load ptr, ptr %l53, !tbaa !29
  %t1086 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1084)
  store i64 %t1086, ptr %l541
  br label %bb223
bb223:
  %t1087 = load i64, ptr %l539, !tbaa !24
  %t1088 = load i64, ptr %l541, !tbaa !24
  %t1089 = icmp slt i64 %t1087, %t1088
  %t1091 = xor i1 %t1089, true
  br i1 %t1091, label %bb224, label %bb225
bb224:
  br label %bb230
bb225:
  br label %bb226
bb226:
  %t1093 = load ptr, ptr %l53, !tbaa !29
  %t1094 = load i64, ptr %l54, !tbaa !24
  %t1097 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1093, i64 %t1094)
  store { i64, [4 x i64] } %t1097, ptr %l546
  br label %bb227
bb227:
  %t1098 = load { i64, [4 x i64] }, ptr %l546
  %t1099 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1099, { i64, [4 x i64] } %t1098)
  br label %bb228
bb228:
  br label %bb229
bb229:
  %t1103 = load i64, ptr %l54, !tbaa !24
  %t1105 = add i64 %t1103, 1
  store i64 %t1105, ptr %l54, !tbaa !24
  br label %bb222
bb230:
  %t1107 = load ptr, ptr %l1, !tbaa !29
  %t1109 = getelementptr %"compiler/mir:Fn", ptr %t1107, i32 0, i32 12
  store ptr %t1109, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb231
bb231:
  %t1111 = load i64, ptr %l57, !tbaa !24
  store i64 %t1111, ptr %l553, !tbaa !24
  %t1112 = load ptr, ptr %l56, !tbaa !29
  %t1114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t1112)
  store i64 %t1114, ptr %l555
  br label %bb232
bb232:
  %t1115 = load i64, ptr %l553, !tbaa !24
  %t1116 = load i64, ptr %l555, !tbaa !24
  %t1117 = icmp slt i64 %t1115, %t1116
  %t1119 = xor i1 %t1117, true
  br i1 %t1119, label %bb233, label %bb234
bb233:
  br label %bb239
bb234:
  br label %bb235
bb235:
  %t1121 = load ptr, ptr %l56, !tbaa !29
  %t1122 = load i64, ptr %l57, !tbaa !24
  %t1125 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t1121, i64 %t1122)
  store { i64, [1 x i64] } %t1125, ptr %l560
  br label %bb236
bb236:
  %t1126 = load { i64, [1 x i64] }, ptr %l560
  %t1127 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t1127, { i64, [1 x i64] } %t1126)
  br label %bb237
bb237:
  br label %bb238
bb238:
  %t1131 = load i64, ptr %l57, !tbaa !24
  %t1133 = add i64 %t1131, 1
  store i64 %t1133, ptr %l57, !tbaa !24
  br label %bb231
bb239:
  %t1135 = load ptr, ptr %l1, !tbaa !29
  %t1137 = getelementptr %"compiler/mir:Fn", ptr %t1135, i32 0, i32 10
  store ptr %t1137, ptr %l59, !tbaa !29
  store i64 0, ptr %l60, !tbaa !24
  br label %bb240
bb240:
  %t1139 = load i64, ptr %l60, !tbaa !24
  store i64 %t1139, ptr %l567, !tbaa !24
  %t1140 = load ptr, ptr %l59, !tbaa !29
  %t1142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t1140)
  store i64 %t1142, ptr %l569
  br label %bb241
bb241:
  %t1143 = load i64, ptr %l567, !tbaa !24
  %t1144 = load i64, ptr %l569, !tbaa !24
  %t1145 = icmp slt i64 %t1143, %t1144
  %t1147 = xor i1 %t1145, true
  br i1 %t1147, label %bb242, label %bb243
bb242:
  br label %bb257
bb243:
  br label %bb244
bb244:
  %t1149 = load ptr, ptr %l59, !tbaa !29
  %t1150 = load i64, ptr %l60, !tbaa !24
  %t1153 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t1149, i64 %t1150)
  store { i64, [1 x i64] } %t1153, ptr %l574
  br label %bb245
bb245:
  %t1154 = load { i64, [1 x i64] }, ptr %l574
  store { i64, [1 x i64] } %t1154, ptr %l61
  %t1155 = load { i64, [1 x i64] }, ptr %l61
  %t1157 = extractvalue { i64, [1 x i64] } %t1155, 0
  %t1158 = icmp eq i64 %t1157, 1
  br i1 %t1158, label %bb246, label %bb247
bb246:
  %t1160 = getelementptr { i64, [1 x i64] }, ptr %l61, i32 0, i32 1
  %t1161 = getelementptr { i32 }, ptr %t1160, i32 0, i32 0
  %t1162 = load i32, ptr %t1161
  store i32 %t1162, ptr %l62, !tbaa !23
  br label %bb248
bb247:
  br label %bb250
bb248:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  %t1165 = load i32, ptr %l62, !tbaa !23
  %t1168 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t1164, i32 %t1165)
  store i1 %t1168, ptr %l580
  br label %bb249
bb249:
  br label %bb255
bb250:
  br i1 true, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb254
bb253:
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_729af306d1a375bd_3b9d78bce782a851)
  unreachable
bb255:
  br label %bb256
bb256:
  %t1169 = load i64, ptr %l60, !tbaa !24
  %t1171 = add i64 %t1169, 1
  store i64 %t1171, ptr %l60, !tbaa !24
  br label %bb240
bb257:
  store i64 0, ptr %l63, !tbaa !24
  %t1173 = load ptr, ptr %l1, !tbaa !29
  %t1175 = getelementptr %"compiler/mir:Fn", ptr %t1173, i32 0, i32 19
  %t1177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t1175)
  store i64 %t1177, ptr %l585
  br label %bb258
bb258:
  %t1178 = load i64, ptr %l585, !tbaa !24
  store i64 %t1178, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t1179 = load i64, ptr %l64, !tbaa !24
  %t1180 = load i64, ptr %l63, !tbaa !24
  %t1183 = icmp sgt i64 %t1179, %t1180
  br i1 %t1183, label %bb259, label %bb260
bb259:
  %t1185 = load i64, ptr %l65, !tbaa !24
  %t1187 = icmp sgt i64 %t1185, 0
  br i1 %t1187, label %bb261, label %bb262
bb260:
  store i64 0, ptr %l589, !tbaa !24
  br label %bb264
bb261:
  %t1189 = load i64, ptr %l64, !tbaa !24
  %t1190 = load i64, ptr %l63, !tbaa !24
  %t1193 = sub i64 %t1189, %t1190
  %t1194 = load i64, ptr %l65, !tbaa !24
  %t1197 = add i64 %t1193, %t1194
  %t1199 = sub i64 %t1197, 1
  %t1200 = load i64, ptr %l65, !tbaa !24
  %t1203 = sdiv i64 %t1199, %t1200
  store i64 %t1203, ptr %l592, !tbaa !24
  br label %bb263
bb262:
  store i64 0, ptr %l592, !tbaa !24
  br label %bb263
bb263:
  %t1205 = load i64, ptr %l592, !tbaa !24
  store i64 %t1205, ptr %l589, !tbaa !24
  br label %bb264
bb264:
  %t1206 = load i64, ptr %l589, !tbaa !24
  store i64 %t1206, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb265
bb265:
  %t1207 = load i64, ptr %l67, !tbaa !24
  %t1208 = load i64, ptr %l66, !tbaa !24
  %t1211 = icmp slt i64 %t1207, %t1208
  %t1213 = xor i1 %t1211, true
  br i1 %t1213, label %bb266, label %bb267
bb266:
  br label %bb292
bb267:
  br label %bb268
bb268:
  %t1215 = load i64, ptr %l63, !tbaa !24
  %t1216 = load i64, ptr %l67, !tbaa !24
  %t1217 = load i64, ptr %l65, !tbaa !24
  %t1220 = mul i64 %t1216, %t1217
  %t1223 = add i64 %t1215, %t1220
  store i64 %t1223, ptr %l68, !tbaa !24
  %t1225 = load ptr, ptr %l1, !tbaa !29
  %t1227 = getelementptr %"compiler/mir:Fn", ptr %t1225, i32 0, i32 19
  %t1228 = load i64, ptr %l68, !tbaa !24
  %t1231 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t1227, i64 %t1228)
  store { i64, [1 x i64] } %t1231, ptr %l613
  br label %bb269
bb269:
  %t1232 = load { i64, [1 x i64] }, ptr %l613
  store { i64, [1 x i64] } %t1232, ptr %l69
  %t1233 = load { i64, [1 x i64] }, ptr %l69
  %t1235 = extractvalue { i64, [1 x i64] } %t1233, 0
  %t1236 = icmp eq i64 %t1235, 1
  br i1 %t1236, label %bb270, label %bb271
bb270:
  %t1238 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1239 = getelementptr { %"compiler/mir:Range" }, ptr %t1238, i32 0, i32 0
  %t1240 = load %"compiler/mir:Range", ptr %t1239
  store %"compiler/mir:Range" %t1240, ptr %l70
  br label %bb272
bb271:
  br label %bb275
bb272:
  store %olang.scope zeroinitializer, ptr %s62
  %t1242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1242, ptr %l617, !tbaa !29
  %t1243 = load %"compiler/mir:Range", ptr %l70
  store %"compiler/mir:Range" %t1243, ptr %l618
  %t1244 = load ptr, ptr %l1, !tbaa !29
  %t1246 = getelementptr %"compiler/mir:Fn", ptr %t1244, i32 0, i32 21
  %t1248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t1246)
  store i64 %t1248, ptr %l621
  br label %bb273
bb273:
  %t1249 = load ptr, ptr %l617, !tbaa !29
  %t1250 = load %"compiler/mir:Range", ptr %l618
  %t1251 = load i64, ptr %l621, !tbaa !24
  %t1252 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s62, ptr %t1249, %"compiler/mir:Range" %t1250, i64 %t1251, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t1252, ptr %l622
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s62)
  br label %bb290
bb275:
  %t1253 = load { i64, [1 x i64] }, ptr %l69
  %t1255 = extractvalue { i64, [1 x i64] } %t1253, 0
  %t1256 = icmp eq i64 %t1255, 2
  br i1 %t1256, label %bb276, label %bb277
bb276:
  %t1258 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1259 = getelementptr { %"compiler/mir:Range" }, ptr %t1258, i32 0, i32 0
  %t1260 = load %"compiler/mir:Range", ptr %t1259
  store %"compiler/mir:Range" %t1260, ptr %l71
  br label %bb278
bb277:
  br label %bb285
bb278:
  store %olang.scope zeroinitializer, ptr %s63
  %t1262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1262, ptr %l626, !tbaa !29
  %t1263 = load %"compiler/mir:Range", ptr %l71
  store %"compiler/mir:Range" %t1263, ptr %l627
  %t1264 = load ptr, ptr %l1, !tbaa !29
  %t1266 = getelementptr %"compiler/mir:Fn", ptr %t1264, i32 0, i32 20
  %t1268 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t1266)
  store i64 %t1268, ptr %l630
  br label %bb279
bb279:
  %t1269 = load ptr, ptr %l626, !tbaa !29
  %t1270 = load %"compiler/mir:Range", ptr %l627
  %t1271 = load i64, ptr %l630, !tbaa !24
  %t1272 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s63, ptr %t1269, %"compiler/mir:Range" %t1270, i64 %t1271, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t1272, ptr %l631
  br label %bb280
bb280:
  %t1273 = load i1, ptr %l631, !tbaa !21
  br i1 %t1273, label %bb281, label %bb282
bb281:
  %t1274 = load ptr, ptr %l0, !tbaa !29
  %t1275 = load %"compiler/mir:Range", ptr %l71
  %t1276 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %t1274, %"compiler/mir:Range" %t1275, i64 %t1276)
  br label %bb283
bb282:
  br label %bb284
bb283:
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s63)
  br label %bb290
bb285:
  br i1 true, label %bb286, label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb289
bb288:
  br label %bb290
bb289:
  call void @__olang_check_failed(ptr @olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0)
  unreachable
bb290:
  br label %bb291
bb291:
  %t1280 = load i64, ptr %l67, !tbaa !24
  %t1282 = add i64 %t1280, 1
  store i64 %t1282, ptr %l67, !tbaa !24
  br label %bb265
bb292:
  store i64 0, ptr %l72, !tbaa !24
  %t1284 = load ptr, ptr %l1, !tbaa !29
  %t1286 = getelementptr %"compiler/mir:Fn", ptr %t1284, i32 0, i32 9
  %t1288 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t1286)
  store i64 %t1288, ptr %l639
  br label %bb293
bb293:
  %t1289 = load i64, ptr %l639, !tbaa !24
  store i64 %t1289, ptr %l73, !tbaa !24
  store i64 1, ptr %l74, !tbaa !24
  %t1290 = load i64, ptr %l73, !tbaa !24
  %t1291 = load i64, ptr %l72, !tbaa !24
  %t1294 = icmp sgt i64 %t1290, %t1291
  br i1 %t1294, label %bb294, label %bb295
bb294:
  %t1296 = load i64, ptr %l74, !tbaa !24
  %t1298 = icmp sgt i64 %t1296, 0
  br i1 %t1298, label %bb296, label %bb297
bb295:
  store i64 0, ptr %l643, !tbaa !24
  br label %bb299
bb296:
  %t1300 = load i64, ptr %l73, !tbaa !24
  %t1301 = load i64, ptr %l72, !tbaa !24
  %t1304 = sub i64 %t1300, %t1301
  %t1305 = load i64, ptr %l74, !tbaa !24
  %t1308 = add i64 %t1304, %t1305
  %t1310 = sub i64 %t1308, 1
  %t1311 = load i64, ptr %l74, !tbaa !24
  %t1314 = sdiv i64 %t1310, %t1311
  store i64 %t1314, ptr %l646, !tbaa !24
  br label %bb298
bb297:
  store i64 0, ptr %l646, !tbaa !24
  br label %bb298
bb298:
  %t1316 = load i64, ptr %l646, !tbaa !24
  store i64 %t1316, ptr %l643, !tbaa !24
  br label %bb299
bb299:
  %t1317 = load i64, ptr %l643, !tbaa !24
  store i64 %t1317, ptr %l75, !tbaa !24
  store i64 0, ptr %l76, !tbaa !24
  br label %bb300
bb300:
  %t1318 = load i64, ptr %l76, !tbaa !24
  %t1319 = load i64, ptr %l75, !tbaa !24
  %t1322 = icmp slt i64 %t1318, %t1319
  %t1324 = xor i1 %t1322, true
  br i1 %t1324, label %bb301, label %bb302
bb301:
  br label %bb322
bb302:
  br label %bb303
bb303:
  %t1326 = load i64, ptr %l72, !tbaa !24
  %t1327 = load i64, ptr %l76, !tbaa !24
  %t1328 = load i64, ptr %l74, !tbaa !24
  %t1331 = mul i64 %t1327, %t1328
  %t1334 = add i64 %t1326, %t1331
  store i64 %t1334, ptr %l77, !tbaa !24
  %t1336 = load ptr, ptr %l0, !tbaa !29
  %t1337 = load i64, ptr %l77, !tbaa !24
  %t1340 = getelementptr %"compiler/mir:verifier", ptr %t1336, i32 0, i32 3
  store i64 %t1337, ptr %t1340, !tbaa !24
  %t1341 = load ptr, ptr %l1, !tbaa !29
  %t1343 = getelementptr %"compiler/mir:Fn", ptr %t1341, i32 0, i32 9
  %t1344 = load i64, ptr %l77, !tbaa !24
  %t1347 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t1343, i64 %t1344)
  store ptr %t1347, ptr %l669
  br label %bb304
bb304:
  %t1348 = load ptr, ptr %l669, !tbaa !29
  store ptr %t1348, ptr %l78, !tbaa !29
  store i64 0, ptr %l79, !tbaa !24
  %t1349 = load ptr, ptr %l78, !tbaa !29
  %t1351 = getelementptr %"compiler/mir:BasicBlock", ptr %t1349, i32 0, i32 0
  %t1353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t1351)
  store i64 %t1353, ptr %l672
  br label %bb305
bb305:
  %t1354 = load i64, ptr %l672, !tbaa !24
  store i64 %t1354, ptr %l80, !tbaa !24
  store i64 1, ptr %l81, !tbaa !24
  %t1355 = load i64, ptr %l80, !tbaa !24
  %t1356 = load i64, ptr %l79, !tbaa !24
  %t1359 = icmp sgt i64 %t1355, %t1356
  br i1 %t1359, label %bb306, label %bb307
bb306:
  %t1361 = load i64, ptr %l81, !tbaa !24
  %t1363 = icmp sgt i64 %t1361, 0
  br i1 %t1363, label %bb308, label %bb309
bb307:
  store i64 0, ptr %l676, !tbaa !24
  br label %bb311
bb308:
  %t1365 = load i64, ptr %l80, !tbaa !24
  %t1366 = load i64, ptr %l79, !tbaa !24
  %t1369 = sub i64 %t1365, %t1366
  %t1370 = load i64, ptr %l81, !tbaa !24
  %t1373 = add i64 %t1369, %t1370
  %t1375 = sub i64 %t1373, 1
  %t1376 = load i64, ptr %l81, !tbaa !24
  %t1379 = sdiv i64 %t1375, %t1376
  store i64 %t1379, ptr %l679, !tbaa !24
  br label %bb310
bb309:
  store i64 0, ptr %l679, !tbaa !24
  br label %bb310
bb310:
  %t1381 = load i64, ptr %l679, !tbaa !24
  store i64 %t1381, ptr %l676, !tbaa !24
  br label %bb311
bb311:
  %t1382 = load i64, ptr %l676, !tbaa !24
  store i64 %t1382, ptr %l82, !tbaa !24
  store i64 0, ptr %l83, !tbaa !24
  br label %bb312
bb312:
  store %olang.scope zeroinitializer, ptr %s70
  %t1383 = load i64, ptr %l83, !tbaa !24
  %t1384 = load i64, ptr %l82, !tbaa !24
  %t1387 = icmp slt i64 %t1383, %t1384
  %t1389 = xor i1 %t1387, true
  br i1 %t1389, label %bb313, label %bb314
bb313:
  call void @__olang_scope_close(ptr %s70)
  br label %bb319
bb314:
  br label %bb315
bb315:
  %t1391 = load i64, ptr %l79, !tbaa !24
  %t1392 = load i64, ptr %l83, !tbaa !24
  %t1393 = load i64, ptr %l81, !tbaa !24
  %t1396 = mul i64 %t1392, %t1393
  %t1399 = add i64 %t1391, %t1396
  store i64 %t1399, ptr %l84, !tbaa !24
  %t1401 = load ptr, ptr %l0, !tbaa !29
  %t1402 = load i64, ptr %l84, !tbaa !24
  %t1405 = getelementptr %"compiler/mir:verifier", ptr %t1401, i32 0, i32 4
  store i64 %t1402, ptr %t1405, !tbaa !24
  %t1406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1406, ptr %l699, !tbaa !29
  %t1407 = load ptr, ptr %l78, !tbaa !29
  %t1409 = getelementptr %"compiler/mir:BasicBlock", ptr %t1407, i32 0, i32 0
  %t1410 = load i64, ptr %l84, !tbaa !24
  %t1413 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t1409, i64 %t1410)
  store { i64, [21 x i64] } %t1413, ptr %l703
  br label %bb316
bb316:
  %t1414 = load { i64, [21 x i64] }, ptr %l703
  %t1415 = call ptr @__olang_scope_alloc_a(ptr %s70, i64 176, i64 8)
  store { i64, [21 x i64] } %t1414, ptr %t1415
  %t1416 = load ptr, ptr %l699, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %s70, ptr %t1416, ptr %t1415)
  br label %bb317
bb317:
  call void @__olang_scope_close(ptr %s70)
  br label %bb318
bb318:
  %t1418 = load i64, ptr %l83, !tbaa !24
  %t1420 = add i64 %t1418, 1
  store i64 %t1420, ptr %l83, !tbaa !24
  br label %bb312
bb319:
  %t1422 = load ptr, ptr %l0, !tbaa !29
  %t1424 = getelementptr %"compiler/mir:verifier", ptr %t1422, i32 0, i32 4
  store i64 -1, ptr %t1424, !tbaa !24
  %t1425 = load ptr, ptr %l0, !tbaa !29
  %t1426 = load ptr, ptr %l78, !tbaa !29
  %t1428 = getelementptr %"compiler/mir:BasicBlock", ptr %t1426, i32 0, i32 1
  %t1429 = load { i64, [8 x i64] }, ptr %t1428
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %t1425, { i64, [8 x i64] } %t1429)
  br label %bb320
bb320:
  br label %bb321
bb321:
  %t1432 = load i64, ptr %l76, !tbaa !24
  %t1434 = add i64 %t1432, 1
  store i64 %t1434, ptr %l76, !tbaa !24
  br label %bb300
bb322:
  %t1436 = load ptr, ptr %l0, !tbaa !29
  %t1440 = getelementptr %"compiler/mir:verifier", ptr %t1436, i32 0, i32 3
  store i64 -1, ptr %t1440, !tbaa !24
  %t1441 = load ptr, ptr %l0, !tbaa !29
  %t1445 = getelementptr %"compiler/mir:verifier", ptr %t1441, i32 0, i32 4
  store i64 -1, ptr %t1445, !tbaa !24
  %t1446 = load ptr, ptr %l0, !tbaa !29
  %t1448 = getelementptr %"compiler/mir:verifier", ptr %t1446, i32 0, i32 2
  %t1450 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1448)
  store i64 %t1450, ptr %l719
  br label %bb323
bb323:
  %t1451 = load i64, ptr %l2, !tbaa !24
  %t1452 = load i64, ptr %l719, !tbaa !24
  %t1454 = icmp eq i64 %t1452, %t1451
  store i1 %t1454, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 11
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l19, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d154, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 12
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 10
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = sext i32 %t74 to i64
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t88 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t69, i64 %t85)
  store i32 %t88, ptr %l53
  br label %bb16
bb16:
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = sext i32 %t95 to i64
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t90, i64 %t91)
  %t100 = getelementptr i8, ptr %t99, i64 %t91
  call void @olang_textcopy(ptr %t100, ptr %t92, i64 %t93)
  %t101 = getelementptr i8, ptr %t100, i64 %t93
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t112 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t112, { i64, ptr } %t111)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb9
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb20
bb20:
  %t120 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t120, ptr %l60
  br label %bb21
bb21:
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t121, ptr %l61, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l62, !tbaa !24
  %t124 = load i64, ptr %l62, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l63, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l62, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t135, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 17
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l12
  br label %bb3
bb3:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb9
bb6:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l19, !tbaa !24
  store i64 %t36, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l16, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l37, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 17
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t62, i64 %t63)
  store i32 %t66, ptr %l44
  br label %bb17
bb17:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load i32, ptr %l44, !tbaa !23
  %t74 = sext i32 %t73 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t70, i64 %t71)
  %t79 = getelementptr i8, ptr %t78, i64 %t71
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t74)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t98, ptr %l51
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t99, ptr %l52, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  store i64 %t101, ptr %l53, !tbaa !24
  %t102 = load i64, ptr %l53, !tbaa !24
  %t103 = mul i64 %t102, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = mul i64 %t111, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %t110, i64 %t112, i1 false)
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t114 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l133 = alloca i1
  %l136 = alloca i1
  %l138 = alloca i64
  %l142 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l162 = alloca i1
  %l168 = alloca i1
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 13}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t22, %"compiler/mir:Lvalue" %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [15 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %t26, { i64, [15 x i64] } %t27)
  br label %bb7
bb7:
  br label %bb103
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t31 = load ptr, ptr %l32, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 13}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l33, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t46 = load ptr, ptr %l38, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 13}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l39, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l46
  br label %bb18
bb18:
  br label %bb103
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t66 = load ptr, ptr %l47, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 13}
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l48, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32 }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t81 = load ptr, ptr %l53, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l53, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 13}
  %t87 = icmp eq i64 %t85, 4
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l54, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l5, !tbaa !23
  %t99 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l61
  br label %bb29
bb29:
  br label %bb103
bb30:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l62, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 13}
  %t107 = icmp eq i64 %t105, 5
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [21 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 1
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l6
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t117, i32 0, i32 3
  %t119 = load { i64, [4 x i64] }, ptr %t118
  store { i64, [4 x i64] } %t119, ptr %l7
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t121, { i64, [1 x i64] } %t122)
  br label %bb36
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t125, { i64, [4 x i64] } %t126)
  br label %bb37
bb37:
  br label %bb103
bb38:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t130 = load ptr, ptr %l74, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l74, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 13}
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t137 = load i1, ptr %l75, !tbaa !21
  br i1 %t137, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [21 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t140, i32 0, i32 1
  %t142 = load %"compiler/mir:Lvalue", ptr %t141
  store %"compiler/mir:Lvalue" %t142, ptr %l8
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/mir:Lvalue", ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t144, %"compiler/mir:Lvalue" %t145)
  br label %bb44
bb44:
  br label %bb103
bb45:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb46, label %bb47
bb46:
  %t152 = load ptr, ptr %l82, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 13}
  %t155 = icmp eq i64 %t153, 7
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t156 = load i1, ptr %l83, !tbaa !21
  br i1 %t156, label %bb48, label %bb49
bb48:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [21 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t159, i32 0, i32 1
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr { i64, [21 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t165, i32 0, i32 2
  %t167 = load %"compiler/mir:Lvalue", ptr %t166
  store %"compiler/mir:Lvalue" %t167, ptr %l10
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l9, !tbaa !23
  %t173 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l92
  br label %bb51
bb51:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t174, %"compiler/mir:Lvalue" %t175)
  br label %bb52
bb52:
  br label %bb103
bb53:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t179 = load ptr, ptr %l95, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb54, label %bb55
bb54:
  %t182 = load ptr, ptr %l95, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 13}
  %t185 = icmp eq i64 %t183, 8
  store i1 %t185, ptr %l96, !tbaa !21
  br label %bb55
bb55:
  %t186 = load i1, ptr %l96, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t189, i32 0, i32 1
  %t191 = load { i64, [1 x i64] }, ptr %t190
  store { i64, [1 x i64] } %t191, ptr %l11
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [21 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t195, i32 0, i32 3
  %t197 = load { i64, [4 x i64] }, ptr %t196
  store { i64, [4 x i64] } %t197, ptr %l12
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, [1 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t199, { i64, [1 x i64] } %t200)
  br label %bb59
bb59:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t203, { i64, [4 x i64] } %t204)
  br label %bb60
bb60:
  br label %bb103
bb61:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t208 = load ptr, ptr %l107, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb62, label %bb63
bb62:
  %t211 = load ptr, ptr %l107, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 13}
  %t214 = icmp eq i64 %t212, 9
  store i1 %t214, ptr %l108, !tbaa !21
  br label %bb63
bb63:
  %t215 = load i1, ptr %l108, !tbaa !21
  br i1 %t215, label %bb64, label %bb65
bb64:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [21 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t218, i32 0, i32 1
  %t220 = load %"compiler/mir:Lvalue", ptr %t219
  store %"compiler/mir:Lvalue" %t220, ptr %l13
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [21 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t224, i32 0, i32 2
  %t226 = load %"compiler/mir:Lvalue", ptr %t225
  store %"compiler/mir:Lvalue" %t226, ptr %l14
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr { i64, [21 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t230, i32 0, i32 3
  %t232 = load { i64, [4 x i64] }, ptr %t231
  store { i64, [4 x i64] } %t232, ptr %l15
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/mir:Lvalue", ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t234, %"compiler/mir:Lvalue" %t235)
  br label %bb67
bb67:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/mir:Lvalue", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t238, %"compiler/mir:Lvalue" %t239)
  br label %bb68
bb68:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load { i64, [4 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t242, { i64, [4 x i64] } %t243)
  br label %bb69
bb69:
  br label %bb103
bb70:
  %t246 = load ptr, ptr %l1, !tbaa !29
  store ptr %t246, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t247 = load ptr, ptr %l123, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb71, label %bb72
bb71:
  %t250 = load ptr, ptr %l123, !tbaa !29
  %t251 = load i64, ptr %t250, !range !{i64 0, i64 13}
  %t253 = icmp eq i64 %t251, 10
  store i1 %t253, ptr %l124, !tbaa !21
  br label %bb72
bb72:
  %t254 = load i1, ptr %l124, !tbaa !21
  br i1 %t254, label %bb73, label %bb74
bb73:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [21 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258
  store i32 %t259, ptr %l16, !tbaa !23
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr { i64, [21 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t263, i32 0, i32 2
  %t265 = load i32, ptr %t264
  store i32 %t265, ptr %l17, !tbaa !23
  br label %bb75
bb74:
  br label %bb85
bb75:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l16, !tbaa !23
  %t271 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l133
  br label %bb76
bb76:
  %t272 = load i32, ptr %l17, !tbaa !23
  %t274 = icmp slt i32 %t272, 0
  br i1 %t274, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb80
bb78:
  %t276 = load i32, ptr %l17, !tbaa !23
  %t278 = sext i32 %t276 to i64
  store i64 %t278, ptr %l138, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/mir:verifier", ptr %t279, i32 0, i32 0
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/mir:Fn", ptr %t282, i32 0, i32 16
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l142
  br label %bb79
bb79:
  %t287 = load i64, ptr %l138, !tbaa !24
  %t288 = load i64, ptr %l142, !tbaa !24
  %t289 = icmp sge i64 %t287, %t288
  store i1 %t289, ptr %l136, !tbaa !21
  br label %bb80
bb80:
  %t291 = load i1, ptr %l136, !tbaa !21
  br i1 %t291, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i32, ptr %l17, !tbaa !23
  %t294 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t297 = sext i32 %t293 to i64
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t299 = add i64 %t295, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t294, i64 %t295)
  %t301 = getelementptr i8, ptr %t300, i64 %t295
  %t302 = call i64 @__olang_fmt_i64(ptr %t301, i64 %t297)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t300, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = extractvalue { i64, ptr } %t304, 1
  %t308 = mul i64 %t306, 1
  %t309 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t309, ptr %t307, i64 %t308, i1 false)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t292, { i64, ptr } %t311)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb84:
  br label %bb103
bb85:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t315 = load ptr, ptr %l148, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb86, label %bb87
bb86:
  %t318 = load ptr, ptr %l148, !tbaa !29
  %t319 = load i64, ptr %t318, !range !{i64 0, i64 13}
  %t321 = icmp eq i64 %t319, 11
  store i1 %t321, ptr %l149, !tbaa !21
  br label %bb87
bb87:
  %t322 = load i1, ptr %l149, !tbaa !21
  br i1 %t322, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb103
bb91:
  %t323 = load ptr, ptr %l1, !tbaa !29
  store ptr %t323, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t324 = load ptr, ptr %l152, !tbaa !29
  %t325 = icmp ne ptr %t324, null
  br i1 %t325, label %bb92, label %bb93
bb92:
  %t327 = load ptr, ptr %l152, !tbaa !29
  %t328 = load i64, ptr %t327, !range !{i64 0, i64 13}
  %t330 = icmp eq i64 %t328, 12
  store i1 %t330, ptr %l153, !tbaa !21
  br label %bb93
bb93:
  %t331 = load i1, ptr %l153, !tbaa !21
  br i1 %t331, label %bb94, label %bb95
bb94:
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = getelementptr { i64, [21 x i64] }, ptr %t332, i32 0, i32 1
  %t335 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t334, i32 0, i32 1
  %t336 = load i32, ptr %t335
  store i32 %t336, ptr %l18, !tbaa !23
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t340 = getelementptr { i64, [21 x i64] }, ptr %t338, i32 0, i32 1
  %t341 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t340, i32 0, i32 2
  %t342 = load i32, ptr %t341
  store i32 %t342, ptr %l19, !tbaa !23
  br label %bb96
bb95:
  br label %bb102
bb96:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i32, ptr %l18, !tbaa !23
  %t348 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t344, i32 %t345)
  store i1 %t348, ptr %l162
  br label %bb97
bb97:
  %t349 = load i32, ptr %l19, !tbaa !23
  %t350 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t353 = icmp ne i32 %t349, %t350
  br i1 %t353, label %bb98, label %bb99
bb98:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l19, !tbaa !23
  %t359 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t355, i32 %t356)
  store i1 %t359, ptr %l168
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_145fd452f8e36c9b_ff9c6902187c9987)
  unreachable
bb103:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca %"compiler/mir:Lvalue"
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca %"compiler/mir:Task"
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l57 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i32
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i32
  %l85 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca i32
  %l118 = alloca i1
  %l121 = alloca i1
  %l123 = alloca i1
  %l126 = alloca i1
  %l128 = alloca i1
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca i64
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca i32
  %l153 = alloca i1
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l158 = alloca i64
  %l160 = alloca i1
  %l163 = alloca i1
  %l165 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca i1
  %l185 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i1
  %l196 = alloca i1
  %l207 = alloca i1
  %l208 = alloca i1
  %l211 = alloca i1
  %l217 = alloca i1
  %l222 = alloca i1
  %l230 = alloca ptr
  %l231 = alloca i32
  %l233 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l242 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca i32
  %l256 = alloca ptr
  %l259 = alloca i32
  %l260 = alloca i32
  %l264 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca ptr
  %l273 = alloca i32
  %l274 = alloca i32
  %l275 = alloca ptr
  %l278 = alloca i32
  %l279 = alloca i32
  %l280 = alloca i1
  %l282 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca ptr
  %l295 = alloca i32
  %l296 = alloca i32
  %l297 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l313 = alloca %"compiler/mir:ScopeInfo"
  %l326 = alloca %"compiler/mir:Task"
  %l329 = alloca i32
  %l338 = alloca ptr
  %l339 = alloca ptr
  %l342 = alloca i32
  %l345 = alloca i32
  %l348 = alloca i32
  %l349 = alloca i32
  %l350 = alloca { i64, ptr }
  %l353 = alloca i1
  %l370 = alloca i1
  %l371 = alloca ptr
  %l374 = alloca i32
  %l375 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t7 = load ptr, ptr %l33, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l33, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 13}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l34, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l34, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Lvalue", ptr %t18
  store %"compiler/mir:Lvalue" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l3
  %t31 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store i32 %t31, ptr %l43
  br label %bb6
bb6:
  %t32 = load i32, ptr %l43, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [15 x i64] }, ptr %l4
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %t33, { i64, [15 x i64] } %t34)
  store i32 %t37, ptr %l46
  br label %bb7
bb7:
  %t38 = load i32, ptr %l46, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load { i64, [15 x i64] }, ptr %l4
  %t41 = extractvalue { i64, [15 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, [4 x i64] }, ptr %t45
  %t48 = extractvalue { i64, [4 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l49, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l49, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { { i64, [4 x i64] } }, ptr %t52, i32 0, i32 0
  %t54 = load { i64, [4 x i64] }, ptr %t53
  store { i64, [4 x i64] } %t54, ptr %l7
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp ne i32 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  store i1 %t68, ptr %l57, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l57, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s3, ptr %t71, i32 %t72, i32 %t73, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb224
bb21:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t78 = load ptr, ptr %l64, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = load ptr, ptr %l64, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 13}
  %t84 = icmp eq i64 %t82, 5
  store i1 %t84, ptr %l65, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l65, !tbaa !21
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [21 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l8, !tbaa !23
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [21 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t94, i32 0, i32 3
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l9
  br label %bb26
bb25:
  br label %bb46
bb26:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l9
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t98, { i64, [4 x i64] } %t99)
  store i32 %t102, ptr %l74
  br label %bb27
bb27:
  %t103 = load i32, ptr %l74, !tbaa !23
  store i32 %t103, ptr %l10, !tbaa !23
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t105 = load i32, ptr %l10, !tbaa !23
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l77
  br label %bb28
bb28:
  %t109 = load i1, ptr %l77, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb33
bb30:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l83
  br label %bb31
bb31:
  %t118 = load i32, ptr %l8, !tbaa !23
  %t119 = load ptr, ptr %l80, !tbaa !29
  %t120 = load i32, ptr %l83, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t119, i32 %t120, i32 %t118)
  store i1 %t122, ptr %l85
  br label %bb32
bb32:
  %t123 = load i1, ptr %l85, !tbaa !21
  %t124 = xor i1 %t123, true
  store i1 %t124, ptr %l79, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l79, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l87, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l10, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l90
  br label %bb36
bb35:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t134 = load i32, ptr %l8, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l98
  br label %bb39
bb36:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l8, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t138, i32 %t139)
  store { i64, ptr } %t142, ptr %l93
  br label %bb37
bb37:
  %t143 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t145 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = getelementptr i8, ptr %t158, i64 %t150
  call void @olang_textcopy(ptr %t159, ptr %t153, i64 %t154)
  %t160 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t156, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } %t161, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t169 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t169, { i64, ptr } %t168)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb39:
  %t171 = load i1, ptr %l98, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l100, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l8, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s8, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l103
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t180 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t182 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t188)
  call void @olang_textcopy(ptr %t189, ptr %t180, i64 %t181)
  %t190 = getelementptr i8, ptr %t189, i64 %t181
  call void @olang_textcopy(ptr %t190, ptr %t183, i64 %t184)
  %t191 = getelementptr i8, ptr %t190, i64 %t184
  call void @olang_textcopy(ptr %t191, ptr %t186, i64 %t187)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t189, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } %t193, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t201 = load ptr, ptr %l100, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t201, { i64, ptr } %t200)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb224
bb46:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t204 = load ptr, ptr %l106, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb47, label %bb48
bb47:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 13}
  %t210 = icmp eq i64 %t208, 6
  store i1 %t210, ptr %l107, !tbaa !21
  br label %bb48
bb48:
  %t211 = load i1, ptr %l107, !tbaa !21
  br i1 %t211, label %bb49, label %bb50
bb49:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [21 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t214, i32 0, i32 1
  %t216 = load %"compiler/mir:Lvalue", ptr %t215
  store %"compiler/mir:Lvalue" %t216, ptr %l11
  br label %bb51
bb50:
  br label %bb71
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load %"compiler/mir:Lvalue", ptr %l11
  %t222 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t218, %"compiler/mir:Lvalue" %t219)
  store i32 %t222, ptr %l114
  br label %bb52
bb52:
  %t223 = load i32, ptr %l114, !tbaa !23
  store i32 %t223, ptr %l12, !tbaa !23
  %t224 = load i32, ptr %l12, !tbaa !23
  %t225 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t228 = icmp ne i32 %t224, %t225
  br i1 %t228, label %bb53, label %bb54
bb53:
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t231 = load i32, ptr %l12, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l121
  br label %bb55
bb54:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb56
bb55:
  %t235 = load i1, ptr %l121, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l118, !tbaa !21
  br label %bb56
bb56:
  %t238 = load i1, ptr %l118, !tbaa !21
  br i1 %t238, label %bb57, label %bb58
bb57:
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t240 = load i32, ptr %l12, !tbaa !23
  %t243 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t239, i32 %t240)
  store i1 %t243, ptr %l126
  br label %bb59
bb58:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb60
bb59:
  %t244 = load i1, ptr %l126, !tbaa !21
  %t245 = xor i1 %t244, true
  store i1 %t245, ptr %l123, !tbaa !21
  br label %bb60
bb60:
  %t247 = load i1, ptr %l123, !tbaa !21
  br i1 %t247, label %bb61, label %bb62
bb61:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load i32, ptr %l12, !tbaa !23
  %t252 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %s10, ptr %t248, i32 %t249)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t252, ptr %l131
  br label %bb63
bb62:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb65
bb63:
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s10, ptr %l131)
  store i64 %t254, ptr %l133
  br label %bb64
bb64:
  %t255 = load i64, ptr %l133, !tbaa !24
  %t256 = icmp eq i64 %t255, 0
  store i1 %t256, ptr %l128, !tbaa !21
  br label %bb65
bb65:
  %t258 = load i1, ptr %l128, !tbaa !21
  br i1 %t258, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l135, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i32, ptr %l12, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t260, i32 %t261)
  store { i64, ptr } %t264, ptr %l138
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t265 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t267 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } %t278, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t286 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t286, { i64, ptr } %t285)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb224
bb71:
  %t288 = load ptr, ptr %l1, !tbaa !29
  store ptr %t288, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t289 = load ptr, ptr %l141, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb72, label %bb73
bb72:
  %t292 = load ptr, ptr %l141, !tbaa !29
  %t293 = load i64, ptr %t292, !range !{i64 0, i64 13}
  %t295 = icmp eq i64 %t293, 7
  store i1 %t295, ptr %l142, !tbaa !21
  br label %bb73
bb73:
  %t296 = load i1, ptr %l142, !tbaa !21
  br i1 %t296, label %bb74, label %bb75
bb74:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [21 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t299, i32 0, i32 2
  %t301 = load %"compiler/mir:Lvalue", ptr %t300
  store %"compiler/mir:Lvalue" %t301, ptr %l13
  br label %bb76
bb75:
  br label %bb92
bb76:
  store %olang.scope zeroinitializer, ptr %s13
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/mir:Lvalue", ptr %l13
  %t307 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t303, %"compiler/mir:Lvalue" %t304)
  store i32 %t307, ptr %l149
  br label %bb77
bb77:
  %t308 = load i32, ptr %l149, !tbaa !23
  store i32 %t308, ptr %l14, !tbaa !23
  %t309 = load i32, ptr %l14, !tbaa !23
  %t310 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t313 = icmp ne i32 %t309, %t310
  br i1 %t313, label %bb78, label %bb79
bb78:
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t316 = load i32, ptr %l14, !tbaa !23
  %t319 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %s13, ptr %t315, i32 %t316)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l156
  br label %bb80
bb79:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb82
bb80:
  %t321 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s13, ptr %l156)
  store i64 %t321, ptr %l158
  br label %bb81
bb81:
  %t322 = load i64, ptr %l158, !tbaa !24
  %t323 = icmp eq i64 %t322, 0
  store i1 %t323, ptr %l153, !tbaa !21
  br label %bb82
bb82:
  %t325 = load i1, ptr %l153, !tbaa !21
  br i1 %t325, label %bb83, label %bb84
bb83:
  %t326 = load ptr, ptr %l2, !tbaa !29
  %t327 = load i32, ptr %l14, !tbaa !23
  %t330 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t326, i32 %t327)
  store i1 %t330, ptr %l163
  br label %bb85
bb84:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb86
bb85:
  %t331 = load i1, ptr %l163, !tbaa !21
  %t332 = xor i1 %t331, true
  store i1 %t332, ptr %l160, !tbaa !21
  br label %bb86
bb86:
  %t334 = load i1, ptr %l160, !tbaa !21
  br i1 %t334, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s14
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l165, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l14, !tbaa !23
  %t340 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s14, ptr %t336, i32 %t337)
  store { i64, ptr } %t340, ptr %l168
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t341 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t343 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t350 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t349)
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = getelementptr i8, ptr %t350, i64 %t342
  call void @olang_textcopy(ptr %t351, ptr %t344, i64 %t345)
  %t352 = getelementptr i8, ptr %t351, i64 %t345
  call void @olang_textcopy(ptr %t352, ptr %t347, i64 %t348)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t350, 1
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t357 = extractvalue { i64, ptr } %t354, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t362 = load ptr, ptr %l165, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t362, { i64, ptr } %t361)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s13)
  br label %bb224
bb92:
  %t364 = load ptr, ptr %l1, !tbaa !29
  store ptr %t364, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t365 = load ptr, ptr %l171, !tbaa !29
  %t366 = icmp ne ptr %t365, null
  br i1 %t366, label %bb93, label %bb94
bb93:
  %t368 = load ptr, ptr %l171, !tbaa !29
  %t369 = load i64, ptr %t368, !range !{i64 0, i64 13}
  %t371 = icmp eq i64 %t369, 8
  store i1 %t371, ptr %l172, !tbaa !21
  br label %bb94
bb94:
  %t372 = load i1, ptr %l172, !tbaa !21
  br i1 %t372, label %bb95, label %bb96
bb95:
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [21 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t375, i32 0, i32 1
  %t377 = load { i64, [1 x i64] }, ptr %t376
  store { i64, [1 x i64] } %t377, ptr %l15
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [21 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t381, i32 0, i32 2
  %t383 = load i32, ptr %t382, !range !{i32 0, i32 8}
  store i32 %t383, ptr %l16
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [21 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t387, i32 0, i32 3
  %t389 = load { i64, [4 x i64] }, ptr %t388
  store { i64, [4 x i64] } %t389, ptr %l17
  br label %bb97
bb96:
  br label %bb145
bb97:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t391, { i64, [1 x i64] } %t392)
  br label %bb98
bb98:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load { i64, [4 x i64] }, ptr %l17
  %t399 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t395, { i64, [4 x i64] } %t396)
  store i32 %t399, ptr %l185
  br label %bb99
bb99:
  %t400 = load i32, ptr %l185, !tbaa !23
  store i32 %t400, ptr %l18, !tbaa !23
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t402 = load i32, ptr %l18, !tbaa !23
  %t405 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t401, i32 %t402)
  store i32 %t405, ptr %l188
  br label %bb100
bb100:
  %t406 = load i32, ptr %l188, !tbaa !23
  store i32 %t406, ptr %l19, !tbaa !23
  %t407 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t409 = trunc i64 0 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb101, label %bb102
bb101:
  br label %bb105
bb102:
  %t412 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t414 = trunc i64 1 to i32
  %t415 = icmp eq i32 %t412, %t414
  br i1 %t415, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l18, !tbaa !23
  %t421 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t417, i32 %t418)
  store i1 %t421, ptr %l196
  br label %bb106
bb106:
  %t422 = load i1, ptr %l196, !tbaa !21
  store i1 %t422, ptr %l189, !tbaa !21
  br label %bb137
bb107:
  %t423 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t425 = trunc i64 2 to i32
  %t426 = icmp eq i32 %t423, %t425
  br i1 %t426, label %bb108, label %bb109
bb108:
  br label %bb112
bb109:
  %t428 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t430 = trunc i64 3 to i32
  %t431 = icmp eq i32 %t428, %t430
  br i1 %t431, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  %t433 = load i32, ptr %l19, !tbaa !23
  %t435 = icmp eq i32 %t433, 7
  store i1 %t435, ptr %l189, !tbaa !21
  br label %bb137
bb113:
  %t437 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t439 = trunc i64 4 to i32
  %t440 = icmp eq i32 %t437, %t439
  br i1 %t440, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb122
bb116:
  %t442 = load ptr, ptr %l2, !tbaa !29
  %t443 = load i32, ptr %l19, !tbaa !23
  %t446 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t442, i32 %t443)
  store i1 %t446, ptr %l207
  br label %bb117
bb117:
  %t447 = load i1, ptr %l207, !tbaa !21
  br i1 %t447, label %bb118, label %bb119
bb118:
  %t448 = load ptr, ptr %l2, !tbaa !29
  %t449 = load i32, ptr %l19, !tbaa !23
  %t452 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l211
  br label %bb120
bb119:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb121
bb120:
  %t453 = load i1, ptr %l211, !tbaa !21
  %t454 = xor i1 %t453, true
  store i1 %t454, ptr %l208, !tbaa !21
  br label %bb121
bb121:
  %t456 = load i1, ptr %l208, !tbaa !21
  store i1 %t456, ptr %l189, !tbaa !21
  br label %bb137
bb122:
  %t457 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t459 = trunc i64 5 to i32
  %t460 = icmp eq i32 %t457, %t459
  br i1 %t460, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t463 = load i32, ptr %l19, !tbaa !23
  %t466 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t462, i32 %t463)
  store i1 %t466, ptr %l217
  br label %bb126
bb126:
  %t467 = load i1, ptr %l217, !tbaa !21
  store i1 %t467, ptr %l189, !tbaa !21
  br label %bb137
bb127:
  %t468 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t470 = trunc i64 6 to i32
  %t471 = icmp eq i32 %t468, %t470
  br i1 %t471, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t473 = load ptr, ptr %l2, !tbaa !29
  %t474 = load i32, ptr %l19, !tbaa !23
  %t477 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t473, i32 %t474)
  store i1 %t477, ptr %l222
  br label %bb131
bb131:
  %t478 = load i1, ptr %l222, !tbaa !21
  store i1 %t478, ptr %l189, !tbaa !21
  br label %bb137
bb132:
  %t479 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t481 = trunc i64 7 to i32
  %t482 = icmp eq i32 %t479, %t481
  br i1 %t482, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t484 = load i32, ptr %l19, !tbaa !23
  %t485 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t488 = icmp eq i32 %t484, %t485
  store i1 %t488, ptr %l189, !tbaa !21
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23)
  unreachable
bb137:
  %t490 = load i1, ptr %l189, !tbaa !21
  %t493 = xor i1 %t490, true
  br i1 %t493, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s23
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l230, !tbaa !29
  %t496 = load i32, ptr %l16, !range !{i32 0, i32 8}
  store i32 %t496, ptr %l231
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s24, ptr %l231, i64 0)
  br label %bb140
bb139:
  br label %bb144
bb140:
  %t498 = load ptr, ptr %s24
  %t499 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t500 = load i64, ptr %t499
  %t501 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t500)
  call void @olang_textcopy(ptr %t501, ptr %t498, i64 %t500)
  %t502 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t501, 1
  store { i64, ptr } %t503, ptr %l233, !tbaa !27
  %t504 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t505 = load ptr, ptr %t504
  %t506 = icmp ne ptr %t505, null
  br i1 %t506, label %sbgrew.507, label %sbdone.508
sbgrew.507:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.508
sbdone.508:
  %t509 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 0
  %t511 = extractvalue { i64, ptr } %t509, 1
  %t512 = mul i64 %t510, 1
  %t513 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t512)
  call void @llvm.memcpy.p0.p0.i64(ptr %t513, ptr %t511, i64 %t512, i1 false)
  %t514 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t515 = insertvalue { i64, ptr } %t514, ptr %t513, 1
  %t517 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s23, ptr %s23, { i64, ptr } %t515)
  store { i64, ptr } %t517, ptr %l235
  br label %bb141
bb141:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load i32, ptr %l18, !tbaa !23
  %t522 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s23, ptr %t518, i32 %t519)
  store { i64, ptr } %t522, ptr %l238
  br label %bb142
bb142:
  %t523 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t525 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t525, 1
  %t527 = extractvalue { i64, ptr } %t525, 0
  %t528 = add i64 %t524, %t527
  %t529 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t530 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t531 = add i64 %t528, %t530
  %t532 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 1
  %t534 = extractvalue { i64, ptr } %t532, 0
  %t535 = add i64 %t531, %t534
  %t536 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t535)
  call void @olang_textcopy(ptr %t536, ptr %t523, i64 %t524)
  %t537 = getelementptr i8, ptr %t536, i64 %t524
  call void @olang_textcopy(ptr %t537, ptr %t526, i64 %t527)
  %t538 = getelementptr i8, ptr %t537, i64 %t527
  call void @olang_textcopy(ptr %t538, ptr %t529, i64 %t530)
  %t539 = getelementptr i8, ptr %t538, i64 %t530
  call void @olang_textcopy(ptr %t539, ptr %t533, i64 %t534)
  %t540 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t536, 1
  %t543 = extractvalue { i64, ptr } %t541, 0
  %t544 = extractvalue { i64, ptr } %t541, 1
  %t545 = mul i64 %t543, 1
  %t546 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t545)
  call void @llvm.memcpy.p0.p0.i64(ptr %t546, ptr %t544, i64 %t545, i1 false)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t546, 1
  %t549 = load ptr, ptr %l230, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s23, ptr %t549, { i64, ptr } %t548)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s23)
  br label %bb144
bb144:
  br label %bb224
bb145:
  %t551 = load ptr, ptr %l1, !tbaa !29
  store ptr %t551, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t552 = load ptr, ptr %l241, !tbaa !29
  %t553 = icmp ne ptr %t552, null
  br i1 %t553, label %bb146, label %bb147
bb146:
  %t555 = load ptr, ptr %l241, !tbaa !29
  %t556 = load i64, ptr %t555, !range !{i64 0, i64 13}
  %t558 = icmp eq i64 %t556, 9
  store i1 %t558, ptr %l242, !tbaa !21
  br label %bb147
bb147:
  %t559 = load i1, ptr %l242, !tbaa !21
  br i1 %t559, label %bb148, label %bb149
bb148:
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [21 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t562, i32 0, i32 1
  %t564 = load %"compiler/mir:Lvalue", ptr %t563
  store %"compiler/mir:Lvalue" %t564, ptr %l21
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [21 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t568, i32 0, i32 2
  %t570 = load %"compiler/mir:Lvalue", ptr %t569
  store %"compiler/mir:Lvalue" %t570, ptr %l22
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [21 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t574, i32 0, i32 3
  %t576 = load { i64, [4 x i64] }, ptr %t575
  store { i64, [4 x i64] } %t576, ptr %l23
  br label %bb150
bb149:
  br label %bb180
bb150:
  %t578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t578, ptr %l251, !tbaa !29
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load %"compiler/mir:Lvalue", ptr %l21
  %t583 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t579, %"compiler/mir:Lvalue" %t580)
  store i32 %t583, ptr %l254
  br label %bb151
bb151:
  %t584 = load ptr, ptr %l251, !tbaa !29
  %t585 = load i32, ptr %l254, !tbaa !23
  %t586 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t584, i32 %t585)
  store i32 %t586, ptr %l255
  br label %bb152
bb152:
  %t587 = load i32, ptr %l255, !tbaa !23
  store i32 %t587, ptr %l24, !tbaa !23
  %t588 = load ptr, ptr %l0, !tbaa !29
  store ptr %t588, ptr %l256, !tbaa !29
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load %"compiler/mir:Lvalue", ptr %l22
  %t593 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t589, %"compiler/mir:Lvalue" %t590)
  store i32 %t593, ptr %l259
  br label %bb153
bb153:
  %t594 = load ptr, ptr %l256, !tbaa !29
  %t595 = load i32, ptr %l259, !tbaa !23
  %t596 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t594, i32 %t595)
  store i32 %t596, ptr %l260
  br label %bb154
bb154:
  %t597 = load i32, ptr %l260, !tbaa !23
  store i32 %t597, ptr %l25, !tbaa !23
  %t598 = load i32, ptr %l24, !tbaa !23
  %t599 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t602 = icmp eq i32 %t598, %t599
  br i1 %t602, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l264, !tbaa !21
  br label %bb157
bb156:
  %t604 = load i32, ptr %l25, !tbaa !23
  %t605 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t608 = icmp eq i32 %t604, %t605
  store i1 %t608, ptr %l264, !tbaa !21
  br label %bb157
bb157:
  %t610 = load i1, ptr %l264, !tbaa !21
  br i1 %t610, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s27
  %t611 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s27, ptr %t611, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb160
bb159:
  %t613 = load ptr, ptr %l2, !tbaa !29
  store ptr %t613, ptr %l269, !tbaa !29
  %t614 = load ptr, ptr %l2, !tbaa !29
  store ptr %t614, ptr %l270, !tbaa !29
  %t615 = load ptr, ptr %l2, !tbaa !29
  %t616 = load i32, ptr %l24, !tbaa !23
  %t619 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t615, i32 %t616)
  store i32 %t619, ptr %l273
  br label %bb161
bb160:
  call void @__olang_scope_close(ptr %s27)
  br label %bb172
bb161:
  %t620 = load ptr, ptr %l270, !tbaa !29
  %t621 = load i32, ptr %l273, !tbaa !23
  %t622 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t620, i32 %t621)
  store i32 %t622, ptr %l274
  br label %bb162
bb162:
  %t623 = load ptr, ptr %l2, !tbaa !29
  store ptr %t623, ptr %l275, !tbaa !29
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t625 = load i32, ptr %l25, !tbaa !23
  %t628 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t624, i32 %t625)
  store i32 %t628, ptr %l278
  br label %bb163
bb163:
  %t629 = load ptr, ptr %l275, !tbaa !29
  %t630 = load i32, ptr %l278, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t629, i32 %t630)
  store i32 %t631, ptr %l279
  br label %bb164
bb164:
  %t632 = load ptr, ptr %l269, !tbaa !29
  %t633 = load i32, ptr %l274, !tbaa !23
  %t634 = load i32, ptr %l279, !tbaa !23
  %t635 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t632, i32 %t633, i32 %t634)
  store i1 %t635, ptr %l280
  br label %bb165
bb165:
  %t636 = load i1, ptr %l280, !tbaa !21
  %t637 = xor i1 %t636, true
  br i1 %t637, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s29
  %t639 = load ptr, ptr %l0, !tbaa !29
  store ptr %t639, ptr %l282, !tbaa !29
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load i32, ptr %l25, !tbaa !23
  %t644 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s29, ptr %t640, i32 %t641)
  store { i64, ptr } %t644, ptr %l285
  br label %bb168
bb167:
  br label %bb171
bb168:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load i32, ptr %l24, !tbaa !23
  %t649 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s29, ptr %t645, i32 %t646)
  store { i64, ptr } %t649, ptr %l288
  br label %bb169
bb169:
  %t650 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t651 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t652 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t653 = extractvalue { i64, ptr } %t652, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = add i64 %t651, %t654
  %t656 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t657 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t658 = add i64 %t655, %t657
  %t659 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t659, 1
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = add i64 %t658, %t661
  %t663 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t662)
  call void @olang_textcopy(ptr %t663, ptr %t650, i64 %t651)
  %t664 = getelementptr i8, ptr %t663, i64 %t651
  call void @olang_textcopy(ptr %t664, ptr %t653, i64 %t654)
  %t665 = getelementptr i8, ptr %t664, i64 %t654
  call void @olang_textcopy(ptr %t665, ptr %t656, i64 %t657)
  %t666 = getelementptr i8, ptr %t665, i64 %t657
  call void @olang_textcopy(ptr %t666, ptr %t660, i64 %t661)
  %t667 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t663, 1
  %t670 = extractvalue { i64, ptr } %t668, 0
  %t671 = extractvalue { i64, ptr } %t668, 1
  %t672 = mul i64 %t670, 1
  %t673 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t672)
  call void @llvm.memcpy.p0.p0.i64(ptr %t673, ptr %t671, i64 %t672, i1 false)
  %t674 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t673, 1
  %t676 = load ptr, ptr %l282, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t676, { i64, ptr } %t675)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t678 = load ptr, ptr %l2, !tbaa !29
  store ptr %t678, ptr %l291, !tbaa !29
  %t679 = load ptr, ptr %l2, !tbaa !29
  store ptr %t679, ptr %l292, !tbaa !29
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load { i64, [4 x i64] }, ptr %l23
  %t684 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t680, { i64, [4 x i64] } %t681)
  store i32 %t684, ptr %l295
  br label %bb173
bb173:
  %t685 = load ptr, ptr %l292, !tbaa !29
  %t686 = load i32, ptr %l295, !tbaa !23
  %t687 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t685, i32 %t686)
  store i32 %t687, ptr %l296
  br label %bb174
bb174:
  %t688 = load ptr, ptr %l291, !tbaa !29
  %t689 = load i32, ptr %l296, !tbaa !23
  %t690 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t688, i32 %t689)
  store i1 %t690, ptr %l297
  br label %bb175
bb175:
  %t691 = load i1, ptr %l297, !tbaa !21
  %t692 = xor i1 %t691, true
  br i1 %t692, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s31
  %t694 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t694, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s31)
  br label %bb179
bb179:
  br label %bb224
bb180:
  %t696 = load ptr, ptr %l1, !tbaa !29
  store ptr %t696, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t697 = load ptr, ptr %l300, !tbaa !29
  %t698 = icmp ne ptr %t697, null
  br i1 %t698, label %bb181, label %bb182
bb181:
  %t700 = load ptr, ptr %l300, !tbaa !29
  %t701 = load i64, ptr %t700, !range !{i64 0, i64 13}
  %t703 = icmp eq i64 %t701, 10
  store i1 %t703, ptr %l301, !tbaa !21
  br label %bb182
bb182:
  %t704 = load i1, ptr %l301, !tbaa !21
  br i1 %t704, label %bb183, label %bb184
bb183:
  %t705 = load ptr, ptr %l1, !tbaa !29
  %t707 = getelementptr { i64, [21 x i64] }, ptr %t705, i32 0, i32 1
  %t708 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t707, i32 0, i32 1
  %t709 = load i32, ptr %t708
  store i32 %t709, ptr %l26, !tbaa !23
  %t711 = load ptr, ptr %l1, !tbaa !29
  %t713 = getelementptr { i64, [21 x i64] }, ptr %t711, i32 0, i32 1
  %t714 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t713, i32 0, i32 2
  %t715 = load i32, ptr %t714
  store i32 %t715, ptr %l27, !tbaa !23
  br label %bb185
bb184:
  br label %bb219
bb185:
  store %olang.scope zeroinitializer, ptr %s32
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/mir:verifier", ptr %t717, i32 0, i32 0
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/mir:Fn", ptr %t720, i32 0, i32 8
  %t723 = load i32, ptr %l26, !tbaa !23
  %t725 = sext i32 %t723 to i64
  %t728 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t722, i64 %t725)
  store %"compiler/mir:ScopeInfo" %t728, ptr %l313
  br label %bb186
bb186:
  %t729 = getelementptr %"compiler/mir:ScopeInfo", ptr %l313, i32 0, i32 0
  %t730 = load i32, ptr %t729, !range !{i32 0, i32 7}
  %t732 = trunc i64 3 to i32
  %t733 = icmp eq i32 %t730, %t732
  %t735 = xor i1 %t733, true
  br i1 %t735, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s33
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load i32, ptr %l26, !tbaa !23
  %t739 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t742 = sext i32 %t738 to i64
  %t743 = call i64 @__olang_fmt_i64(ptr null, i64 %t742)
  %t744 = add i64 %t740, %t743
  %t745 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t739, i64 %t740)
  %t749 = getelementptr i8, ptr %t748, i64 %t740
  %t750 = call i64 @__olang_fmt_i64(ptr %t749, i64 %t742)
  %t751 = getelementptr i8, ptr %t749, i64 %t743
  call void @olang_textcopy(ptr %t751, ptr %t745, i64 %t746)
  %t752 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t748, 1
  %t755 = extractvalue { i64, ptr } %t753, 0
  %t756 = extractvalue { i64, ptr } %t753, 1
  %t757 = mul i64 %t755, 1
  %t758 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t757)
  call void @llvm.memcpy.p0.p0.i64(ptr %t758, ptr %t756, i64 %t757, i1 false)
  %t759 = insertvalue { i64, ptr } undef, i64 %t755, 0
  %t760 = insertvalue { i64, ptr } %t759, ptr %t758, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t737, { i64, ptr } %t760)
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_scope_close(ptr %s33)
  br label %bb190
bb190:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/mir:verifier", ptr %t763, i32 0, i32 0
  %t766 = load ptr, ptr %t765, !tbaa !29
  %t768 = getelementptr %"compiler/mir:Fn", ptr %t766, i32 0, i32 16
  %t769 = load i32, ptr %l27, !tbaa !23
  %t771 = sext i32 %t769 to i64
  %t774 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t768, i64 %t771)
  store %"compiler/mir:Task" %t774, ptr %l326
  br label %bb191
bb191:
  %t775 = load %"compiler/mir:Task", ptr %l326
  store %"compiler/mir:Task" %t775, ptr %l28
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 0
  %t778 = load { i64, [7 x i64] }, ptr %t777
  %t781 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t776, { i64, [7 x i64] } %t778)
  store i32 %t781, ptr %l329
  br label %bb192
bb192:
  %t782 = load i32, ptr %l329, !tbaa !23
  store i32 %t782, ptr %l29, !tbaa !23
  %t783 = load i32, ptr %l29, !tbaa !23
  %t784 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t787 = icmp ne i32 %t783, %t784
  br i1 %t787, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s35
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 0
  %t791 = load { i64, [7 x i64] }, ptr %t790
  %t792 = load i32, ptr %l29, !tbaa !23
  %t793 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 1
  %t794 = load %"compiler/mir:Range", ptr %t793
  %t795 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 2
  %t796 = load %"compiler/mir:Range", ptr %t795
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t789, { i64, [7 x i64] } %t791, i32 %t792, %"compiler/mir:Range" %t794, %"compiler/mir:Range" %t796)
  br label %bb195
bb194:
  br label %bb218
bb195:
  %t802 = load ptr, ptr %l2, !tbaa !29
  store ptr %t802, ptr %l338, !tbaa !29
  %t803 = load ptr, ptr %l2, !tbaa !29
  store ptr %t803, ptr %l339, !tbaa !29
  %t804 = load ptr, ptr %l2, !tbaa !29
  %t805 = load i32, ptr %l29, !tbaa !23
  %t808 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t804, i32 %t805)
  store i32 %t808, ptr %l342
  br label %bb196
bb196:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t810 = load i32, ptr %l29, !tbaa !23
  %t813 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t809, i32 %t810)
  store i32 %t813, ptr %l345
  br label %bb197
bb197:
  %t814 = load ptr, ptr %l2, !tbaa !29
  %t815 = load i32, ptr %l29, !tbaa !23
  %t818 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t814, i32 %t815)
  store i32 %t818, ptr %l348
  br label %bb198
bb198:
  %t819 = load ptr, ptr %l339, !tbaa !29
  %t820 = load i32, ptr %l342, !tbaa !23
  %t821 = load i32, ptr %l345, !tbaa !23
  %t822 = load i32, ptr %l348, !tbaa !23
  %t823 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t819, i32 %t820, i32 %t821, i32 %t822, i32 0, i64 0, i1 false, i32 0)
  store i32 %t823, ptr %l349
  br label %bb199
bb199:
  %t824 = load ptr, ptr %l338, !tbaa !29
  %t825 = load i32, ptr %l349, !tbaa !23
  %t826 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s35, ptr %t824, i32 %t825)
  store { i64, ptr } %t826, ptr %l350
  br label %bb200
bb200:
  %t827 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t827, ptr %l30, !tbaa !27
  %t828 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t829 = getelementptr %"compiler/mir:Range", ptr %t828, i32 0, i32 1
  %t830 = load i32, ptr %t829, !tbaa !23
  %t832 = icmp sgt i32 %t830, 0
  br i1 %t832, label %bb201, label %bb202
bb201:
  %t834 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t835 = getelementptr %"compiler/mir:Range", ptr %t834, i32 0, i32 1
  %t836 = load i32, ptr %t835, !tbaa !23
  %t838 = sext i32 %t836 to i64
  %t839 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t839, 0
  %t844 = icmp ne i64 %t838, %t841
  store i1 %t844, ptr %l353, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb203
bb203:
  %t846 = load i1, ptr %l353, !tbaa !21
  br i1 %t846, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s36
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t849 = getelementptr %"compiler/mir:Range", ptr %t848, i32 0, i32 1
  %t850 = load i32, ptr %t849, !tbaa !23
  %t851 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t851, 0
  %t854 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t855 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t857 = sext i32 %t850 to i64
  %t858 = call i64 @__olang_fmt_i64(ptr null, i64 %t857)
  %t859 = add i64 %t855, %t858
  %t860 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t862 = add i64 %t859, %t861
  %t864 = call i64 @__olang_fmt_i64(ptr null, i64 %t853)
  %t865 = add i64 %t862, %t864
  %t866 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t868 = add i64 %t865, %t867
  %t869 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t868)
  call void @olang_textcopy(ptr %t869, ptr %t854, i64 %t855)
  %t870 = getelementptr i8, ptr %t869, i64 %t855
  %t871 = call i64 @__olang_fmt_i64(ptr %t870, i64 %t857)
  %t872 = getelementptr i8, ptr %t870, i64 %t858
  call void @olang_textcopy(ptr %t872, ptr %t860, i64 %t861)
  %t873 = getelementptr i8, ptr %t872, i64 %t861
  %t874 = call i64 @__olang_fmt_i64(ptr %t873, i64 %t853)
  %t875 = getelementptr i8, ptr %t873, i64 %t864
  call void @olang_textcopy(ptr %t875, ptr %t866, i64 %t867)
  %t876 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t869, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = extractvalue { i64, ptr } %t877, 1
  %t881 = mul i64 %t879, 1
  %t882 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t881)
  call void @llvm.memcpy.p0.p0.i64(ptr %t882, ptr %t880, i64 %t881, i1 false)
  %t883 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t882, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t847, { i64, ptr } %t884)
  br label %bb206
bb205:
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t888 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %s32, ptr %s35, ptr %t887, ptr %l28, { i64, ptr } %t888)
  br label %bb207
bb206:
  call void @__olang_scope_close(ptr %s36)
  br label %bb208
bb207:
  br label %bb208
bb208:
  %t892 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 4
  %t893 = getelementptr %"compiler/mir:Range", ptr %t892, i32 0, i32 1
  %t894 = load i32, ptr %t893, !tbaa !23
  %t896 = icmp sgt i32 %t894, 0
  br i1 %t896, label %bb209, label %bb210
bb209:
  %t898 = load ptr, ptr %l2, !tbaa !29
  store ptr %t898, ptr %l371, !tbaa !29
  %t899 = load ptr, ptr %l2, !tbaa !29
  %t900 = load i32, ptr %l29, !tbaa !23
  %t903 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t899, i32 %t900)
  store i32 %t903, ptr %l374
  br label %bb211
bb210:
  store i1 false, ptr %l370, !tbaa !21
  br label %bb213
bb211:
  %t904 = load ptr, ptr %l371, !tbaa !29
  %t905 = load i32, ptr %l374, !tbaa !23
  %t906 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s35, ptr %t904, i32 %t905)
  store { i64, ptr } %t906, ptr %l375
  br label %bb212
bb212:
  %t907 = load { i64, ptr }, ptr %l375, !tbaa !27
  %t908 = extractvalue { i64, ptr } %t907, 0
  %t910 = icmp eq i64 %t908, 0
  store i1 %t910, ptr %l370, !tbaa !21
  br label %bb213
bb213:
  %t912 = load i1, ptr %l370, !tbaa !21
  br i1 %t912, label %bb214, label %bb215
bb214:
  store %olang.scope zeroinitializer, ptr %s39
  %t913 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t913, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d180, i32 0, i32 1) })
  br label %bb216
bb215:
  br label %bb217
bb216:
  call void @__olang_scope_close(ptr %s39)
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s35)
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s32)
  br label %bb224
bb219:
  br i1 true, label %bb220, label %bb221
bb220:
  br label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22)
  unreachable
bb224:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca %"compiler/mir:Call"
  %l46 = alloca { i64, ptr }
  %l51 = alloca %"compiler/mir:Call"
  %l53 = alloca { i64, ptr }
  %l58 = alloca %"compiler/mir:Call"
  %l59 = alloca i32
  %l64 = alloca %"compiler/mir:Call"
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = mul i64 1, 4
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  store i32 %t15, ptr %t23, !tbaa !33
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  br label %bb40
bb4:
  %t25 = load { i64, [8 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [8 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l4, !tbaa !23
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t38 = load i32, ptr %l4, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = mul i64 2, 4
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 2, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i32, ptr %t46, i64 0
  store i32 %t38, ptr %t47, !tbaa !33
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 1
  store i32 %t39, ptr %t51, !tbaa !33
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t52, ptr %l14, !tbaa !27
  br label %bb40
bb8:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb9, label %bb10
bb9:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 1
  %t60 = load %"compiler/mir:Range", ptr %t59
  store %"compiler/mir:Range" %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 2
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Range", ptr %l6
  %t68 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %t66, %"compiler/mir:Range" %t67, i32 %t68)
  store { i64, ptr } %t72, ptr %l34
  br label %bb12
bb12:
  %t73 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t73, ptr %l14, !tbaa !27
  br label %bb40
bb13:
  %t74 = load { i64, [8 x i64] }, ptr %l1
  %t76 = extractvalue { i64, [8 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 4
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l8, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 14
  %t86 = load i32, ptr %l8, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t85, i64 %t88)
  store %"compiler/mir:Call" %t91, ptr %l42
  br label %bb17
bb17:
  %t92 = getelementptr %"compiler/mir:Call", ptr %l42, i32 0, i32 7
  %t93 = load i32, ptr %t92, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t97 = icmp eq i32 %t93, %t94
  br i1 %t97, label %bb18, label %bb19
bb18:
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/mir:Fn", ptr %t99, i32 0, i32 14
  %t102 = load i32, ptr %l8, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t101, i64 %t104)
  store %"compiler/mir:Call" %t107, ptr %l51
  br label %bb20
bb19:
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 14
  %t111 = load i32, ptr %l8, !tbaa !23
  %t113 = sext i32 %t111 to i64
  %t116 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t110, i64 %t113)
  store %"compiler/mir:Call" %t116, ptr %l58
  br label %bb21
bb20:
  %t117 = getelementptr %"compiler/mir:Call", ptr %l51, i32 0, i32 5
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = mul i64 1, 4
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 1, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l53, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  store i32 %t118, ptr %t126, !tbaa !33
  %t127 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t127, ptr %l46, !tbaa !27
  br label %bb23
bb21:
  %t128 = getelementptr %"compiler/mir:Call", ptr %l58, i32 0, i32 5
  %t129 = load i32, ptr %t128, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/mir:Fn", ptr %t130, i32 0, i32 14
  %t133 = load i32, ptr %l8, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t132, i64 %t135)
  store %"compiler/mir:Call" %t138, ptr %l64
  br label %bb22
bb22:
  %t139 = getelementptr %"compiler/mir:Call", ptr %l64, i32 0, i32 7
  %t140 = load i32, ptr %t139, !tbaa !23
  %t141 = mul i64 2, 4
  %t142 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 2, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l66, !tbaa !27
  %t145 = load i32, ptr %l59, !tbaa !23
  %t146 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 0
  store i32 %t145, ptr %t148, !tbaa !33
  %t150 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 1
  store i32 %t140, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t153, ptr %l46, !tbaa !27
  br label %bb23
bb23:
  %t154 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t154, ptr %l14, !tbaa !27
  br label %bb40
bb24:
  %t155 = load { i64, [8 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [8 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 8
  br i1 %t158, label %bb25, label %bb26
bb25:
  %t160 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l9, !tbaa !23
  %t164 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t164, i32 0, i32 4
  %t166 = load i32, ptr %t165
  store i32 %t166, ptr %l10, !tbaa !23
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t168 = load i32, ptr %l10, !tbaa !23
  %t169 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t172 = icmp eq i32 %t168, %t169
  br i1 %t172, label %bb28, label %bb29
bb28:
  %t174 = load i32, ptr %l9, !tbaa !23
  %t175 = mul i64 1, 4
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 1, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l76, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 0
  store i32 %t174, ptr %t182, !tbaa !33
  %t183 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t183, ptr %l74, !tbaa !27
  br label %bb30
bb29:
  %t184 = load i32, ptr %l9, !tbaa !23
  %t185 = load i32, ptr %l10, !tbaa !23
  %t186 = mul i64 2, 4
  %t187 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 2, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l79, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 0
  store i32 %t184, ptr %t193, !tbaa !33
  %t195 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 1
  store i32 %t185, ptr %t197, !tbaa !33
  %t198 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t198, ptr %l74, !tbaa !27
  br label %bb30
bb30:
  %t199 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t199, ptr %l14, !tbaa !27
  br label %bb40
bb31:
  %t200 = load { i64, [8 x i64] }, ptr %l1
  %t202 = extractvalue { i64, [8 x i64] } %t200, 0
  %t203 = icmp eq i64 %t202, 11
  br i1 %t203, label %bb32, label %bb33
bb32:
  %t205 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t205, i32 0, i32 2
  %t207 = load i32, ptr %t206
  store i32 %t207, ptr %l11, !tbaa !23
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t209 = load i32, ptr %l11, !tbaa !23
  %t210 = mul i64 1, 4
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 1, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 0
  store i32 %t209, ptr %t217, !tbaa !33
  %t218 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t218, ptr %l14, !tbaa !27
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t219 = mul i64 0, 4
  %t220 = insertvalue { i64, ptr } undef, i64 0, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t221, ptr %l14, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7)
  unreachable
bb40:
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l86, !tbaa !24
  %t225 = load i64, ptr %l86, !tbaa !24
  %t226 = mul i64 %t225, 4
  %t227 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l87, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l86, !tbaa !24
  %t235 = mul i64 %t234, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t231, ptr %t233, i64 %t235, i1 false)
  %t236 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t236, ptr %l14, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t237, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i32 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i32
  %l41 = alloca i32
  %l50 = alloca %"compiler/mir:Case"
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sle i64 %t10, 2305843009213693951
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = mul i64 %t13, 4
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t18, ptr %lp3
  %t20 = load ptr, ptr %lp3
  store { i64, ptr } %t17, ptr %t20, !tbaa !27
  store i32 0, ptr %l4, !tbaa !23
  %t21 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = icmp sgt i32 %t24, %t25
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb5:
  %t30 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t30, 0
  br i1 %t32, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l20, !tbaa !23
  br label %bb10
bb7:
  %t34 = load i32, ptr %l5, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = sub i32 %t34, %t35
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = add i32 %t38, %t39
  %t44 = sub i32 %t42, 1
  %t45 = load i32, ptr %l6, !tbaa !23
  %t48 = sdiv i32 %t44, %t45
  store i32 %t48, ptr %l23, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb9
bb9:
  %t50 = load i32, ptr %l23, !tbaa !23
  store i32 %t50, ptr %l20, !tbaa !23
  br label %bb10
bb10:
  %t51 = load i32, ptr %l20, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb11
bb11:
  %t52 = load i32, ptr %l8, !tbaa !23
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = icmp slt i32 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t60 = load i32, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l8, !tbaa !23
  %t62 = load i32, ptr %l6, !tbaa !23
  %t65 = mul i32 %t61, %t62
  %t68 = add i32 %t60, %t65
  store i32 %t68, ptr %l9, !tbaa !23
  %t70 = load i32, ptr %l9, !tbaa !23
  store i32 %t70, ptr %l41, !tbaa !23
  %t73 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/mir:Fn", ptr %t74, i32 0, i32 15
  %t77 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load i32, ptr %l9, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = add i64 %t80, %t83
  %t89 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t76, i64 %t86)
  store %"compiler/mir:Case" %t89, ptr %l50
  br label %bb15
bb15:
  %t90 = getelementptr %"compiler/mir:Case", ptr %l50, i32 0, i32 1
  %t91 = load i32, ptr %t90, !tbaa !23
  %t93 = load ptr, ptr %lp3
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = sext i32 %t94 to i64
  %t96 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t95
  store i32 %t91, ptr %t98, !tbaa !33
  br label %bb16
bb16:
  %t99 = load i32, ptr %l8, !tbaa !23
  %t101 = add i32 %t99, 1
  store i32 %t101, ptr %l8, !tbaa !23
  br label %bb11
bb17:
  %t103 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t104 = load i32, ptr %t103, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t109 = load ptr, ptr %lp3
  %t111 = getelementptr { i64, ptr }, ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t106
  store i32 %a2, ptr %t113, !tbaa !33
  %t114 = load ptr, ptr %lp3
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca ptr
  %l49 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Task", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t33 = load i32, ptr %l17, !tbaa !23
  store i32 %t33, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t34 = load i32, ptr %l14, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store { i64, ptr } %a2, ptr %l36, !tbaa !27
  %t55 = load i32, ptr %l8, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t57
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l38, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 13
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/mir:Task", ptr %t69, i32 0, i32 3
  %t72 = getelementptr %"compiler/mir:Range", ptr %t71, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = load i32, ptr %l8, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t81 = add i64 %t75, %t78
  %t84 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t68, i64 %t81)
  store %"compiler/mir:Lvalue" %t84, ptr %l49
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l39, !tbaa !29
  %t86 = load %"compiler/mir:Lvalue", ptr %l49
  %t87 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t85, %"compiler/mir:Lvalue" %t86)
  store i32 %t87, ptr %l50
  br label %bb12
bb12:
  %t88 = load i32, ptr %l8, !tbaa !23
  %t89 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t92 = sext i32 %t88 to i64
  %t93 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t94 = add i64 %t90, %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t89, i64 %t90)
  %t96 = getelementptr i8, ptr %t95, i64 %t90
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t92)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load ptr, ptr %l35, !tbaa !29
  %t108 = load i32, ptr %l38, !tbaa !23
  %t109 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s2, ptr %t107, i32 %t108, i32 %t109, { i64, ptr } %t106)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t111 = load i32, ptr %l7, !tbaa !23
  %t113 = add i32 %t111, 1
  store i32 %t113, ptr %l7, !tbaa !23
  br label %bb7
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Range"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l26 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/mir:Range"
  %l52 = alloca i64
  %l53 = alloca i1
  %l56 = alloca i1
  %l65 = alloca i1
  %l67 = alloca i64
  %l71 = alloca i64
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/mir:Range"
  %l103 = alloca i64
  %l104 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [8 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb72
bb5:
  %t8 = load { i64, [8 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [8 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t13 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l26
  br label %bb9
bb9:
  br label %bb72
bb10:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [4 x i64] } %t29, ptr %l3
  %t31 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t39, { i64, [4 x i64] } %t40)
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l36
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l39
  br label %bb16
bb16:
  br label %bb72
bb17:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 0
  %t60 = load { i64, [4 x i64] }, ptr %t59
  store { i64, [4 x i64] } %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 1
  %t64 = load %"compiler/mir:Range", ptr %t63
  store %"compiler/mir:Range" %t64, ptr %l7
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l8, !tbaa !23
  br label %bb20
bb19:
  br label %bb25
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t70, { i64, [4 x i64] } %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l47, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l7
  store %"compiler/mir:Range" %t75, ptr %l48
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 15
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l52
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load %"compiler/mir:Range", ptr %l48
  %t86 = load i64, ptr %l52, !tbaa !24
  %t87 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s4, ptr %t84, %"compiler/mir:Range" %t85, i64 %t86, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store i1 %t87, ptr %l53
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l56
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb25:
  %t93 = load { i64, [8 x i64] }, ptr %l1
  %t95 = extractvalue { i64, [8 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 4
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t98 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32 }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l9, !tbaa !23
  br label %bb30
bb27:
  %t102 = load { i64, [8 x i64] }, ptr %l1
  %t104 = extractvalue { i64, [8 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 6
  br i1 %t105, label %bb28, label %bb29
bb28:
  %t107 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32 }, ptr %t107, i32 0, i32 1
  %t109 = load i32, ptr %t108
  store i32 %t109, ptr %l9, !tbaa !23
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t111 = load i32, ptr %l9, !tbaa !23
  %t113 = icmp slt i32 %t111, 0
  br i1 %t113, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb34
bb32:
  %t115 = load i32, ptr %l9, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l67, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/mir:verifier", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/mir:Fn", ptr %t121, i32 0, i32 14
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l71
  br label %bb33
bb33:
  %t126 = load i64, ptr %l67, !tbaa !24
  %t127 = load i64, ptr %l71, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t130 = load i1, ptr %l65, !tbaa !21
  br i1 %t130, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l9, !tbaa !23
  %t133 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t136 = sext i32 %t132 to i64
  %t137 = call i64 @__olang_fmt_i64(ptr null, i64 %t136)
  %t138 = add i64 %t134, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t133, i64 %t134)
  %t140 = getelementptr i8, ptr %t139, i64 %t134
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t136)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t139, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t131, { i64, ptr } %t150)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  br label %bb72
bb39:
  %t153 = load { i64, [8 x i64] }, ptr %l1
  %t155 = extractvalue { i64, [8 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 5
  br i1 %t156, label %bb40, label %bb41
bb40:
  %t158 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t158, i32 0, i32 1
  %t160 = load { i64, [4 x i64] }, ptr %t159
  store { i64, [4 x i64] } %t160, ptr %l10
  br label %bb46
bb41:
  %t162 = load { i64, [8 x i64] }, ptr %l1
  %t164 = extractvalue { i64, [8 x i64] } %t162, 0
  %t165 = icmp eq i64 %t164, 7
  br i1 %t165, label %bb42, label %bb43
bb42:
  %t167 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t167, i32 0, i32 1
  %t169 = load { i64, [4 x i64] }, ptr %t168
  store { i64, [4 x i64] } %t169, ptr %l10
  br label %bb46
bb43:
  %t171 = load { i64, [8 x i64] }, ptr %l1
  %t173 = extractvalue { i64, [8 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 9
  br i1 %t174, label %bb44, label %bb45
bb44:
  %t176 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t176, i32 0, i32 2
  %t178 = load { i64, [4 x i64] }, ptr %t177
  store { i64, [4 x i64] } %t178, ptr %l10
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load { i64, [4 x i64] }, ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t180, { i64, [4 x i64] } %t181)
  br label %bb47
bb47:
  br label %bb72
bb48:
  %t184 = load { i64, [8 x i64] }, ptr %l1
  %t186 = extractvalue { i64, [8 x i64] } %t184, 0
  %t187 = icmp eq i64 %t186, 11
  br i1 %t187, label %bb49, label %bb50
bb49:
  %t189 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t189, i32 0, i32 1
  %t191 = load { i64, [4 x i64] }, ptr %t190
  store { i64, [4 x i64] } %t191, ptr %l11
  %t193 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t193, i32 0, i32 2
  %t195 = load i32, ptr %t194
  store i32 %t195, ptr %l12, !tbaa !23
  %t197 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t197, i32 0, i32 3
  %t199 = load %"compiler/mir:Range", ptr %t198
  store %"compiler/mir:Range" %t199, ptr %l13
  br label %bb51
bb50:
  br label %bb56
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t201, { i64, [4 x i64] } %t202)
  br label %bb52
bb52:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l12, !tbaa !23
  %t209 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t205, i32 %t206)
  store i1 %t209, ptr %l97
  br label %bb53
bb53:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l98, !tbaa !29
  %t211 = load %"compiler/mir:Range", ptr %l13
  store %"compiler/mir:Range" %t211, ptr %l99
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/mir:verifier", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/mir:Fn", ptr %t215, i32 0, i32 12
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t217)
  store i64 %t219, ptr %l103
  br label %bb54
bb54:
  %t220 = load ptr, ptr %l98, !tbaa !29
  %t221 = load %"compiler/mir:Range", ptr %l99
  %t222 = load i64, ptr %l103, !tbaa !24
  %t223 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s9, ptr %t220, %"compiler/mir:Range" %t221, i64 %t222, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i1 %t223, ptr %l104
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb56:
  %t224 = load { i64, [8 x i64] }, ptr %l1
  %t226 = extractvalue { i64, [8 x i64] } %t224, 0
  %t227 = icmp eq i64 %t226, 8
  br i1 %t227, label %bb57, label %bb58
bb57:
  %t229 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t229, i32 0, i32 1
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l14, !tbaa !23
  %t233 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t233, i32 0, i32 2
  %t235 = load i32, ptr %t234
  store i32 %t235, ptr %l15, !tbaa !23
  %t237 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t237, i32 0, i32 3
  %t239 = load i32, ptr %t238
  store i32 %t239, ptr %l16, !tbaa !23
  %t241 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t241, i32 0, i32 4
  %t243 = load i32, ptr %t242
  store i32 %t243, ptr %l17, !tbaa !23
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l14, !tbaa !23
  %t249 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t245, i32 %t246)
  store i1 %t249, ptr %l113
  br label %bb60
bb60:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l15, !tbaa !23
  %t254 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t250, i32 %t251)
  store i1 %t254, ptr %l116
  br label %bb61
bb61:
  %t255 = load i32, ptr %l17, !tbaa !23
  %t256 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t259 = icmp ne i32 %t255, %t256
  br i1 %t259, label %bb62, label %bb63
bb62:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i32, ptr %l17, !tbaa !23
  %t265 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t261, i32 %t262)
  store i1 %t265, ptr %l122
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l16, !tbaa !23
  %t270 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t266, i32 %t267)
  store i1 %t270, ptr %l125
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb72
bb67:
  %t271 = load { i64, [8 x i64] }, ptr %l1
  %t273 = extractvalue { i64, [8 x i64] } %t271, 0
  %t274 = icmp eq i64 %t273, 10
  br i1 %t274, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_4fdb0c87eb50ced7_f9856407ece22343)
  unreachable
bb72:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Call"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Call"
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l37 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l77 = alloca %"compiler/mir:Call"
  %l80 = alloca i32
  %l91 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i32
  %l101 = alloca i32
  %l102 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l117 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca i32
  %l130 = alloca i32
  %l138 = alloca %"compiler/mir:Call"
  %l141 = alloca i32
  %l151 = alloca i1
  %l155 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca i32
  %l168 = alloca i1
  %l177 = alloca i32
  %l183 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l196 = alloca i32
  %l205 = alloca ptr
  %l208 = alloca i32
  %l212 = alloca i32
  %l216 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca i32
  %l230 = alloca i32
  %l240 = alloca %"compiler/mir:ScopeInfo"
  %l250 = alloca { i64, ptr }
  %l254 = alloca i1
  %l261 = alloca i1
  %l269 = alloca ptr
  %l272 = alloca i32
  %l274 = alloca i32
  %l285 = alloca i1
  %l289 = alloca i1
  %l293 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca i32
  %l300 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.builder
  %s39room = alloca [64 x i8], align 8
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load { i64, [8 x i64] }, ptr %l1
  %t13 = extractvalue { i64, [8 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 2
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t17 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t18, ptr %l4
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t20, { i64, [4 x i64] } %t21)
  store i32 %t24, ptr %l37
  br label %bb4
bb4:
  %t25 = load i32, ptr %l37, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l40
  br label %bb5
bb5:
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t32 = load i32, ptr %l40, !tbaa !23
  %t34 = icmp ne i32 %t32, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l43, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l46
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t42 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t44 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t59, { i64, ptr } %t58)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb196
bb11:
  %t61 = load { i64, [8 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [8 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 3
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l6
  %t70 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t70, i32 0, i32 1
  %t72 = load %"compiler/mir:Range", ptr %t71
  store %"compiler/mir:Range" %t72, ptr %l7
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l6
  %t78 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t74, { i64, [4 x i64] } %t75)
  store i32 %t78, ptr %l55
  br label %bb15
bb15:
  %t79 = load i32, ptr %l55, !tbaa !23
  store i32 %t79, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l56, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t82 = load i32, ptr %l8, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l59
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l56, !tbaa !29
  %t87 = load i32, ptr %l59, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l60
  br label %bb17
bb17:
  %t89 = load i1, ptr %l60, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l62, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l65
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t98 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t100 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t115 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t115, { i64, ptr } %t114)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/mir:Range", ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %t117, %"compiler/mir:Range" %t118)
  br label %bb23
bb23:
  br label %bb196
bb24:
  %t121 = load { i64, [8 x i64] }, ptr %l1
  %t123 = extractvalue { i64, [8 x i64] } %t121, 0
  %t124 = icmp eq i64 %t123, 4
  br i1 %t124, label %bb25, label %bb26
bb25:
  %t126 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb65
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/mir:Fn", ptr %t130, i32 0, i32 14
  %t133 = load i32, ptr %l9, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t132, i64 %t135)
  store %"compiler/mir:Call" %t138, ptr %l77
  br label %bb28
bb28:
  %t139 = load %"compiler/mir:Call", ptr %l77
  store %"compiler/mir:Call" %t139, ptr %l10
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t142 = load { i64, [7 x i64] }, ptr %t141
  %t145 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t140, { i64, [7 x i64] } %t142)
  store i32 %t145, ptr %l80
  br label %bb29
bb29:
  %t146 = load i32, ptr %l80, !tbaa !23
  store i32 %t146, ptr %l11, !tbaa !23
  %t147 = load i32, ptr %l11, !tbaa !23
  %t148 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t151 = icmp eq i32 %t147, %t148
  br i1 %t151, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t155 = load { i64, [7 x i64] }, ptr %t154
  %t156 = load i32, ptr %l11, !tbaa !23
  %t157 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 1
  %t158 = load %"compiler/mir:Range", ptr %t157
  %t159 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 2
  %t160 = load %"compiler/mir:Range", ptr %t159
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t153, { i64, [7 x i64] } %t155, i32 %t156, %"compiler/mir:Range" %t158, %"compiler/mir:Range" %t160)
  br label %bb33
bb33:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l11, !tbaa !23
  %t170 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t170, ptr %l91
  br label %bb34
bb34:
  %t171 = load i32, ptr %l91, !tbaa !23
  store i32 %t171, ptr %l12, !tbaa !23
  %t172 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 4
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb35, label %bb36
bb35:
  %t175 = load i32, ptr %l12, !tbaa !23
  %t176 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t179 = icmp eq i32 %t175, %t176
  br i1 %t179, label %bb37, label %bb38
bb36:
  br label %bb43
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t181, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s11
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l97, !tbaa !29
  %t184 = load i32, ptr %l12, !tbaa !23
  store i32 %t184, ptr %l98, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 3
  %t187 = load %"compiler/mir:Lvalue", ptr %t186
  %t190 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t185, %"compiler/mir:Lvalue" %t187)
  store i32 %t190, ptr %l101
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb42
bb40:
  %t191 = load ptr, ptr %l97, !tbaa !29
  %t192 = load i32, ptr %l98, !tbaa !23
  %t193 = load i32, ptr %l101, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s11, ptr %t191, i32 %t192, i32 %t193, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d189, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t194 = load ptr, ptr %l2, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t196 = load i32, ptr %l11, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l105
  br label %bb44
bb44:
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i32, ptr %l105, !tbaa !23
  %t202 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t200, i32 %t201)
  store { i64, ptr } %t202, ptr %l106
  br label %bb45
bb45:
  %t203 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t206 = icmp sgt i64 %t204, 0
  store i1 %t206, ptr %l13, !tbaa !21
  %t208 = load i1, ptr %l13, !tbaa !21
  br i1 %t208, label %bb46, label %bb47
bb46:
  %t210 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t211 = load i32, ptr %t210, !tbaa !23
  %t212 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t215 = icmp eq i32 %t211, %t212
  store i1 %t215, ptr %l110, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb48
bb48:
  %t217 = load i1, ptr %l110, !tbaa !21
  br i1 %t217, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s12, ptr %t218, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d190, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb52:
  %t220 = load i1, ptr %l13, !tbaa !21
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb53, label %bb54
bb53:
  %t224 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t225 = load i32, ptr %t224, !tbaa !23
  %t226 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t229 = icmp ne i32 %t225, %t226
  store i1 %t229, ptr %l117, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb55
bb55:
  %t231 = load i1, ptr %l117, !tbaa !21
  br i1 %t231, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t232, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d191, i32 0, i32 1) })
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  %t234 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t239 = icmp ne i32 %t235, %t236
  br i1 %t239, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l125, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 6
  %t244 = load i32, ptr %t243, !tbaa !23
  %t247 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t242, i32 %t244)
  store i32 %t247, ptr %l128
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t248 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t249 = load ptr, ptr %l125, !tbaa !29
  %t250 = load i32, ptr %l128, !tbaa !23
  %t252 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s14, ptr %t249, i32 %t250, i32 %t248, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d192, i32 0, i32 1) })
  store i32 %t252, ptr %l130
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb196
bb65:
  %t253 = load { i64, [8 x i64] }, ptr %l1
  %t255 = extractvalue { i64, [8 x i64] } %t253, 0
  %t256 = icmp eq i64 %t255, 6
  br i1 %t256, label %bb66, label %bb67
bb66:
  %t258 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32 }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l14, !tbaa !23
  br label %bb68
bb67:
  br label %bb92
bb68:
  %t262 = load ptr, ptr %l3, !tbaa !29
  %t264 = getelementptr %"compiler/mir:Fn", ptr %t262, i32 0, i32 14
  %t265 = load i32, ptr %l14, !tbaa !23
  %t267 = sext i32 %t265 to i64
  %t270 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t264, i64 %t267)
  store %"compiler/mir:Call" %t270, ptr %l138
  br label %bb69
bb69:
  %t271 = load %"compiler/mir:Call", ptr %l138
  store %"compiler/mir:Call" %t271, ptr %l15
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t274 = load { i64, [7 x i64] }, ptr %t273
  %t277 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t272, { i64, [7 x i64] } %t274)
  store i32 %t277, ptr %l141
  br label %bb70
bb70:
  %t278 = load i32, ptr %l141, !tbaa !23
  store i32 %t278, ptr %l16, !tbaa !23
  %t279 = load i32, ptr %l16, !tbaa !23
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t283 = icmp eq i32 %t279, %t280
  br i1 %t283, label %bb71, label %bb72
bb71:
  br label %ret
bb72:
  br label %bb73
bb73:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t287 = load { i64, [7 x i64] }, ptr %t286
  %t288 = load i32, ptr %l16, !tbaa !23
  %t289 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 1
  %t290 = load %"compiler/mir:Range", ptr %t289
  %t291 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 2
  %t292 = load %"compiler/mir:Range", ptr %t291
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t285, { i64, [7 x i64] } %t287, i32 %t288, %"compiler/mir:Range" %t290, %"compiler/mir:Range" %t292)
  br label %bb74
bb74:
  %t298 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 4
  %t299 = load i1, ptr %t298, !tbaa !21
  br i1 %t299, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb77
bb76:
  %t301 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 5
  %t302 = load i32, ptr %t301, !tbaa !23
  %t303 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t306 = icmp ne i32 %t302, %t303
  store i1 %t306, ptr %l151, !tbaa !21
  br label %bb77
bb77:
  %t308 = load i1, ptr %l151, !tbaa !21
  br i1 %t308, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb80
bb79:
  %t309 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 7
  %t310 = load i32, ptr %t309, !tbaa !23
  %t311 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t314 = icmp ne i32 %t310, %t311
  store i1 %t314, ptr %l155, !tbaa !21
  br label %bb80
bb80:
  %t316 = load i1, ptr %l155, !tbaa !21
  br i1 %t316, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t317 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t317, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d193, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  %t319 = load ptr, ptr %l2, !tbaa !29
  store ptr %t319, ptr %l160, !tbaa !29
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t321 = load i32, ptr %l16, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l163
  br label %bb85
bb85:
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t326 = load ptr, ptr %l3, !tbaa !29
  %t328 = getelementptr %"compiler/mir:Fn", ptr %t326, i32 0, i32 1
  %t329 = load i32, ptr %t328, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t325, i32 %t329)
  store i32 %t332, ptr %l167
  br label %bb86
bb86:
  %t333 = load ptr, ptr %l160, !tbaa !29
  %t334 = load i32, ptr %l163, !tbaa !23
  %t335 = load i32, ptr %l167, !tbaa !23
  %t336 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t333, i32 %t334, i32 %t335)
  store i1 %t336, ptr %l168
  br label %bb87
bb87:
  %t337 = load i1, ptr %l168, !tbaa !21
  %t338 = xor i1 %t337, true
  br i1 %t338, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  %t340 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t340, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb91:
  br label %bb196
bb92:
  %t342 = load { i64, [8 x i64] }, ptr %l1
  %t344 = extractvalue { i64, [8 x i64] } %t342, 0
  %t345 = icmp eq i64 %t344, 5
  br i1 %t345, label %bb93, label %bb94
bb93:
  %t347 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t347, i32 0, i32 1
  %t349 = load { i64, [4 x i64] }, ptr %t348
  store { i64, [4 x i64] } %t349, ptr %l17
  br label %bb95
bb94:
  br label %bb111
bb95:
  %t351 = load ptr, ptr %l2, !tbaa !29
  %t352 = load ptr, ptr %l3, !tbaa !29
  %t354 = getelementptr %"compiler/mir:Fn", ptr %t352, i32 0, i32 1
  %t355 = load i32, ptr %t354, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t351, i32 %t355)
  store i32 %t358, ptr %l177
  br label %bb96
bb96:
  %t359 = load i32, ptr %l177, !tbaa !23
  store i32 %t359, ptr %l18, !tbaa !23
  %t360 = load { i64, [4 x i64] }, ptr %l17
  %t362 = extractvalue { i64, [4 x i64] } %t360, 0
  %t363 = icmp eq i64 %t362, 0
  br i1 %t363, label %bb97, label %bb98
bb97:
  %t365 = load i32, ptr %l18, !tbaa !23
  %t366 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t369 = icmp ne i32 %t365, %t366
  br i1 %t369, label %bb99, label %bb100
bb98:
  %t371 = load i32, ptr %l18, !tbaa !23
  %t372 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t375 = icmp eq i32 %t371, %t372
  br i1 %t375, label %bb104, label %bb105
bb99:
  store %olang.scope zeroinitializer, ptr %s21
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l183, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l18, !tbaa !23
  %t382 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s21, ptr %t378, i32 %t379)
  store { i64, ptr } %t382, ptr %l186
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t383 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t385 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t388)
  call void @olang_textcopy(ptr %t389, ptr %t383, i64 %t384)
  %t390 = getelementptr i8, ptr %t389, i64 %t384
  call void @olang_textcopy(ptr %t390, ptr %t386, i64 %t387)
  %t391 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t389, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = extractvalue { i64, ptr } %t392, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l183, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t400, { i64, ptr } %t399)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb103
bb103:
  br label %bb110
bb104:
  store %olang.scope zeroinitializer, ptr %s24
  %t402 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t402, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s25
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l193, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load { i64, [4 x i64] }, ptr %l17
  %t409 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t405, { i64, [4 x i64] } %t406)
  store i32 %t409, ptr %l196
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb107:
  %t410 = load i32, ptr %l18, !tbaa !23
  %t411 = load ptr, ptr %l193, !tbaa !29
  %t412 = load i32, ptr %l196, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s25, ptr %t411, i32 %t412, i32 %t410, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s25)
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb196
bb111:
  %t414 = load { i64, [8 x i64] }, ptr %l1
  %t416 = extractvalue { i64, [8 x i64] } %t414, 0
  %t417 = icmp eq i64 %t416, 11
  br i1 %t417, label %bb112, label %bb113
bb112:
  %t419 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t419, i32 0, i32 1
  %t421 = load { i64, [4 x i64] }, ptr %t420
  store { i64, [4 x i64] } %t421, ptr %l19
  br label %bb114
bb113:
  br label %bb122
bb114:
  store %olang.scope zeroinitializer, ptr %s26
  %t423 = load ptr, ptr %l3, !tbaa !29
  %t425 = getelementptr %"compiler/mir:Fn", ptr %t423, i32 0, i32 25
  %t426 = load i1, ptr %t425, !tbaa !21
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s27
  %t430 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s27, ptr %t430, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d198, i32 0, i32 1) })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s27)
  br label %bb118
bb118:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l205, !tbaa !29
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load { i64, [4 x i64] }, ptr %l19
  %t437 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t433, { i64, [4 x i64] } %t434)
  store i32 %t437, ptr %l208
  br label %bb119
bb119:
  %t438 = load ptr, ptr %l2, !tbaa !29
  %t439 = load ptr, ptr %l3, !tbaa !29
  %t441 = getelementptr %"compiler/mir:Fn", ptr %t439, i32 0, i32 1
  %t442 = load i32, ptr %t441, !tbaa !23
  %t445 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t438, i32 %t442)
  store i32 %t445, ptr %l212
  br label %bb120
bb120:
  %t446 = load ptr, ptr %l205, !tbaa !29
  %t447 = load i32, ptr %l208, !tbaa !23
  %t448 = load i32, ptr %l212, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s26, ptr %t446, i32 %t447, i32 %t448, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d199, i32 0, i32 1) })
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s26)
  br label %bb196
bb122:
  %t449 = load { i64, [8 x i64] }, ptr %l1
  %t451 = extractvalue { i64, [8 x i64] } %t449, 0
  %t452 = icmp eq i64 %t451, 7
  br i1 %t452, label %bb123, label %bb124
bb123:
  %t454 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t454, i32 0, i32 1
  %t456 = load { i64, [4 x i64] }, ptr %t455
  store { i64, [4 x i64] } %t456, ptr %l20
  br label %bb125
bb124:
  br label %bb134
bb125:
  store %olang.scope zeroinitializer, ptr %s28
  %t458 = load ptr, ptr %l2, !tbaa !29
  store ptr %t458, ptr %l216, !tbaa !29
  %t459 = load ptr, ptr %l2, !tbaa !29
  %t460 = load ptr, ptr %l3, !tbaa !29
  %t462 = getelementptr %"compiler/mir:Fn", ptr %t460, i32 0, i32 1
  %t463 = load i32, ptr %t462, !tbaa !23
  %t466 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t459, i32 %t463)
  store i32 %t466, ptr %l220
  br label %bb126
bb126:
  %t467 = load ptr, ptr %l216, !tbaa !29
  %t468 = load i32, ptr %l220, !tbaa !23
  %t469 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s28, ptr %t467, i32 %t468)
  store { i64, ptr } %t469, ptr %l221
  br label %bb127
bb127:
  %t470 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 0
  %t473 = icmp eq i64 %t471, 0
  br i1 %t473, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s29
  %t475 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t475, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s29)
  br label %bb131
bb131:
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l225, !tbaa !29
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load { i64, [4 x i64] }, ptr %l20
  %t482 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t478, { i64, [4 x i64] } %t479)
  store i32 %t482, ptr %l228
  br label %bb132
bb132:
  %t483 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t484 = load ptr, ptr %l225, !tbaa !29
  %t485 = load i32, ptr %l228, !tbaa !23
  %t487 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s28, ptr %t484, i32 %t485, i32 %t483, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d201, i32 0, i32 1) })
  store i32 %t487, ptr %l230
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s28)
  br label %bb196
bb134:
  %t488 = load { i64, [8 x i64] }, ptr %l1
  %t490 = extractvalue { i64, [8 x i64] } %t488, 0
  %t491 = icmp eq i64 %t490, 8
  br i1 %t491, label %bb135, label %bb136
bb135:
  %t493 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t493, i32 0, i32 1
  %t495 = load i32, ptr %t494
  store i32 %t495, ptr %l21, !tbaa !23
  %t497 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t497, i32 0, i32 3
  %t499 = load i32, ptr %t498
  store i32 %t499, ptr %l22, !tbaa !23
  %t501 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t501, i32 0, i32 4
  %t503 = load i32, ptr %t502
  store i32 %t503, ptr %l23, !tbaa !23
  br label %bb137
bb136:
  br label %bb163
bb137:
  store %olang.scope zeroinitializer, ptr %s30
  %t505 = load ptr, ptr %l3, !tbaa !29
  %t507 = getelementptr %"compiler/mir:Fn", ptr %t505, i32 0, i32 8
  %t508 = load i32, ptr %l21, !tbaa !23
  %t510 = sext i32 %t508 to i64
  %t513 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t507, i64 %t510)
  store %"compiler/mir:ScopeInfo" %t513, ptr %l240
  br label %bb138
bb138:
  %t514 = load %"compiler/mir:ScopeInfo", ptr %l240
  store %"compiler/mir:ScopeInfo" %t514, ptr %l24
  %t515 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t516 = load i32, ptr %t515, !range !{i32 0, i32 7}
  %t518 = trunc i64 3 to i32
  %t519 = icmp eq i32 %t516, %t518
  %t521 = xor i1 %t519, true
  br i1 %t521, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s31
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load i32, ptr %l21, !tbaa !23
  %t525 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t528 = sext i32 %t524 to i64
  %t529 = call i64 @__olang_fmt_i64(ptr null, i64 %t528)
  %t530 = add i64 %t526, %t529
  %t531 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t532 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t533 = add i64 %t530, %t532
  %t534 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t533)
  call void @olang_textcopy(ptr %t534, ptr %t525, i64 %t526)
  %t535 = getelementptr i8, ptr %t534, i64 %t526
  %t536 = call i64 @__olang_fmt_i64(ptr %t535, i64 %t528)
  %t537 = getelementptr i8, ptr %t535, i64 %t529
  call void @olang_textcopy(ptr %t537, ptr %t531, i64 %t532)
  %t538 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t534, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = extractvalue { i64, ptr } %t539, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t523, { i64, ptr } %t546)
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  %t549 = load ptr, ptr %l2, !tbaa !29
  %t550 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t551 = load i32, ptr %t550, !tbaa !23
  %t554 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s30, ptr %t549, i32 %t551)
  store { i64, ptr } %t554, ptr %l250
  br label %bb143
bb143:
  %t555 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 0
  %t558 = icmp sgt i64 %t556, 0
  store i1 %t558, ptr %l25, !tbaa !21
  %t560 = load i1, ptr %l25, !tbaa !21
  br i1 %t560, label %bb144, label %bb145
bb144:
  %t562 = load i32, ptr %l23, !tbaa !23
  %t563 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t566 = icmp eq i32 %t562, %t563
  store i1 %t566, ptr %l254, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb146
bb146:
  %t568 = load i1, ptr %l254, !tbaa !21
  br i1 %t568, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s33
  %t569 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t569, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb149
bb148:
  br label %bb150
bb149:
  call void @__olang_scope_close(ptr %s33)
  br label %bb150
bb150:
  %t571 = load i1, ptr %l25, !tbaa !21
  %t573 = xor i1 %t571, true
  br i1 %t573, label %bb151, label %bb152
bb151:
  %t575 = load i32, ptr %l23, !tbaa !23
  %t576 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t579 = icmp ne i32 %t575, %t576
  store i1 %t579, ptr %l261, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb153
bb153:
  %t581 = load i1, ptr %l261, !tbaa !21
  br i1 %t581, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s34
  %t582 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s34, ptr %t582, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s34)
  br label %bb157
bb157:
  %t584 = load i32, ptr %l23, !tbaa !23
  %t585 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t588 = icmp ne i32 %t584, %t585
  br i1 %t588, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s35
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l269, !tbaa !29
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load i32, ptr %l22, !tbaa !23
  %t595 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t591, i32 %t592)
  store i32 %t595, ptr %l272
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t596 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t597 = load ptr, ptr %l269, !tbaa !29
  %t598 = load i32, ptr %l272, !tbaa !23
  %t600 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s35, ptr %t597, i32 %t598, i32 %t596, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i32 %t600, ptr %l274
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s35)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s30)
  br label %bb196
bb163:
  %t601 = load { i64, [8 x i64] }, ptr %l1
  %t603 = extractvalue { i64, [8 x i64] } %t601, 0
  %t604 = icmp eq i64 %t603, 9
  br i1 %t604, label %bb164, label %bb165
bb164:
  %t606 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t607 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t606, i32 0, i32 1
  %t608 = load i32, ptr %t607, !range !{i32 0, i32 15}
  store i32 %t608, ptr %l26
  %t610 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t610, i32 0, i32 2
  %t612 = load { i64, [4 x i64] }, ptr %t611
  store { i64, [4 x i64] } %t612, ptr %l27
  br label %bb166
bb165:
  br label %bb191
bb166:
  %t614 = load { i64, [4 x i64] }, ptr %l27
  %t616 = extractvalue { i64, [4 x i64] } %t614, 0
  %t617 = icmp eq i64 %t616, 0
  %t619 = xor i1 %t617, true
  br i1 %t619, label %bb167, label %bb168
bb167:
  %t621 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t623 = trunc i64 6 to i32
  %t624 = icmp eq i32 %t621, %t623
  %t626 = xor i1 %t624, true
  br i1 %t626, label %bb169, label %bb170
bb168:
  br label %bb190
bb169:
  %t628 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t630 = trunc i64 3 to i32
  %t631 = icmp eq i32 %t628, %t630
  %t633 = xor i1 %t631, true
  store i1 %t633, ptr %l285, !tbaa !21
  br label %bb171
bb170:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb171
bb171:
  %t635 = load i1, ptr %l285, !tbaa !21
  br i1 %t635, label %bb172, label %bb173
bb172:
  %t636 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t638 = trunc i64 13 to i32
  %t639 = icmp eq i32 %t636, %t638
  %t641 = xor i1 %t639, true
  store i1 %t641, ptr %l289, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb174
bb174:
  %t643 = load i1, ptr %l289, !tbaa !21
  br i1 %t643, label %bb175, label %bb176
bb175:
  %t644 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t646 = trunc i64 14 to i32
  %t647 = icmp eq i32 %t644, %t646
  %t649 = xor i1 %t647, true
  store i1 %t649, ptr %l293, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb177
bb177:
  %t651 = load i1, ptr %l293, !tbaa !21
  br i1 %t651, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s38
  %t652 = load ptr, ptr %l0, !tbaa !29
  store ptr %t652, ptr %l297, !tbaa !29
  %t653 = load i32, ptr %l26, !range !{i32 0, i32 15}
  store i32 %t653, ptr %l298
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s39
  store ptr %s39room, ptr %s39
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s39, ptr %l298, i64 0)
  br label %bb180
bb179:
  br label %bb183
bb180:
  %t655 = load ptr, ptr %s39
  %t656 = getelementptr %olang.builder, ptr %s39, i32 0, i32 1
  %t657 = load i64, ptr %t656
  %t658 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t657)
  call void @olang_textcopy(ptr %t658, ptr %t655, i64 %t657)
  %t659 = insertvalue { i64, ptr } undef, i64 %t657, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t658, 1
  store { i64, ptr } %t660, ptr %l300, !tbaa !27
  %t661 = getelementptr %olang.builder, ptr %s39, i32 0, i32 3
  %t662 = load ptr, ptr %t661
  %t663 = icmp ne ptr %t662, null
  br i1 %t663, label %sbgrew.664, label %sbdone.665
sbgrew.664:
  call void @__olang_sb_done(ptr %s39)
  br label %sbdone.665
sbdone.665:
  %t666 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 0
  %t668 = extractvalue { i64, ptr } %t666, 1
  %t669 = mul i64 %t667, 1
  %t670 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t669)
  call void @llvm.memcpy.p0.p0.i64(ptr %t670, ptr %t668, i64 %t669, i1 false)
  %t671 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  %t674 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s38, ptr %s38, { i64, ptr } %t672)
  store { i64, ptr } %t674, ptr %l302
  br label %bb181
bb181:
  %t675 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t677 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 1
  %t679 = extractvalue { i64, ptr } %t677, 0
  %t680 = add i64 %t676, %t679
  %t681 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t683 = add i64 %t680, %t682
  %t684 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t683)
  call void @olang_textcopy(ptr %t684, ptr %t675, i64 %t676)
  %t685 = getelementptr i8, ptr %t684, i64 %t676
  call void @olang_textcopy(ptr %t685, ptr %t678, i64 %t679)
  %t686 = getelementptr i8, ptr %t685, i64 %t679
  call void @olang_textcopy(ptr %t686, ptr %t681, i64 %t682)
  %t687 = insertvalue { i64, ptr } undef, i64 %t683, 0
  %t688 = insertvalue { i64, ptr } %t687, ptr %t684, 1
  %t690 = extractvalue { i64, ptr } %t688, 0
  %t691 = extractvalue { i64, ptr } %t688, 1
  %t692 = mul i64 %t690, 1
  %t693 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t692)
  call void @llvm.memcpy.p0.p0.i64(ptr %t693, ptr %t691, i64 %t692, i1 false)
  %t694 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t695 = insertvalue { i64, ptr } %t694, ptr %t693, 1
  %t696 = load ptr, ptr %l297, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s38, ptr %t696, { i64, ptr } %t695)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s38)
  br label %bb183
bb183:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l305, !tbaa !29
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load { i64, [4 x i64] }, ptr %l27
  %t703 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t699, { i64, [4 x i64] } %t700)
  store i32 %t703, ptr %l308
  br label %bb184
bb184:
  %t704 = load ptr, ptr %l305, !tbaa !29
  %t705 = load i32, ptr %l308, !tbaa !23
  %t706 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t704, i32 %t705)
  store i1 %t706, ptr %l309
  br label %bb185
bb185:
  %t707 = load i1, ptr %l309, !tbaa !21
  %t708 = xor i1 %t707, true
  br i1 %t708, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s41
  %t710 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s41, ptr %t710, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d209, i32 0, i32 1) })
  br label %bb188
bb187:
  br label %bb189
bb188:
  call void @__olang_scope_close(ptr %s41)
  br label %bb189
bb189:
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7)
  unreachable
bb196:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t1, { i64, [1 x i64] } %a1)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l12
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t19, i64 %t20)
  %t26 = getelementptr i8, ptr %t25, i64 %t20
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t36, { i64, ptr } %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, [21 x i64] }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load i64, ptr %l21, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l28, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/mir:verifier", ptr %t58, i32 0, i32 13
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l47, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i1, ptr %t65, i64 %t62
  %t67 = load i1, ptr %t66, !tbaa !31
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb32
bb13:
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = getelementptr %"compiler/mir:verifier", ptr %t71, i32 0, i32 3
  store i64 %t72, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/mir:Fn", ptr %t76, i32 0, i32 9
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l56
  br label %bb15
bb15:
  %t83 = load ptr, ptr %l56, !tbaa !29
  store ptr %t83, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr %"compiler/mir:BasicBlock", ptr %t84, i32 0, i32 0
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l59
  br label %bb16
bb16:
  %t89 = load i64, ptr %l59, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb22
bb19:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l66, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb21
bb21:
  %t116 = load i64, ptr %l66, !tbaa !24
  store i64 %t116, ptr %l63, !tbaa !24
  br label %bb22
bb22:
  %t117 = load i64, ptr %l63, !tbaa !24
  store i64 %t117, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l14, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = getelementptr %"compiler/mir:verifier", ptr %t136, i32 0, i32 4
  store i64 %t137, ptr %t140, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l86, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  %t144 = getelementptr %"compiler/mir:BasicBlock", ptr %t142, i32 0, i32 0
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t144, i64 %t145)
  store { i64, [21 x i64] } %t148, ptr %l90
  br label %bb27
bb27:
  %t149 = load { i64, [21 x i64] }, ptr %l90
  %t150 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t149, ptr %t150
  %t151 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %s5, ptr %t151, ptr %t150)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t153 = load i64, ptr %l13, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l13, !tbaa !24
  br label %bb23
bb30:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/mir:verifier", ptr %t157, i32 0, i32 4
  store i64 -1, ptr %t159, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l8, !tbaa !29
  %t163 = getelementptr %"compiler/mir:BasicBlock", ptr %t161, i32 0, i32 1
  %t164 = load { i64, [8 x i64] }, ptr %t163
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %t160, { i64, [8 x i64] } %t164)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l6, !tbaa !24
  br label %bb8
bb33:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/mir:verifier", ptr %t171, i32 0, i32 3
  store i64 -1, ptr %t175, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/mir:verifier", ptr %t176, i32 0, i32 4
  store i64 -1, ptr %t180, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i1, ptr %t10, i64 %t7
  %t12 = load i1, ptr %t11, !tbaa !31
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t21 = sext i32 %t17 to i64
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t21)
  %t30 = getelementptr i8, ptr %t28, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t27, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } %t39)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca i64
  %l140 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l168 = alloca i32
  %l176 = alloca ptr
  %l179 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i64
  %l206 = alloca ptr
  %l210 = alloca { i64, [21 x i64] }
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 8
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l38
  br label %bb2
bb2:
  %t17 = load i64, ptr %l38, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t20 = sext i32 %a1 to i64
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb8
bb5:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l48, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t50 = load i64, ptr %l48, !tbaa !24
  store i64 %t50, ptr %l45, !tbaa !24
  br label %bb8
bb8:
  %t51 = load i64, ptr %l45, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 14
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l67, !tbaa !27
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/mir:verifier", ptr %t75, i32 0, i32 7
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l70, !tbaa !27
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i1, ptr %t90, i64 %t87
  %t92 = load i1, ptr %t91, !tbaa !31
  %t95 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t74
  store i1 %t92, ptr %t97, !tbaa !31
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/mir:verifier", ptr %t98, i32 0, i32 15
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l78, !tbaa !27
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/mir:verifier", ptr %t103, i32 0, i32 8
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l81, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i1, ptr %t118, i64 %t115
  %t120 = load i1, ptr %t119, !tbaa !31
  %t123 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i1, ptr %t124, i64 %t102
  store i1 %t120, ptr %t125, !tbaa !31
  br label %bb13
bb13:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l10, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  store i64 %t130, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb15, label %bb16
bb15:
  %t138 = load i64, ptr %l14, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb20
bb17:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l14, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l97, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb19
bb19:
  %t158 = load i64, ptr %l97, !tbaa !24
  store i64 %t158, ptr %l94, !tbaa !24
  br label %bb20
bb20:
  %t159 = load i64, ptr %l94, !tbaa !24
  store i64 %t159, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t160 = load i64, ptr %l16, !tbaa !24
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l17, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/mir:verifier", ptr %t178, i32 0, i32 16
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l116, !tbaa !27
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/mir:verifier", ptr %t183, i32 0, i32 9
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l119, !tbaa !27
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load i64, ptr %l4, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t192 = load i64, ptr %l17, !tbaa !24
  %t195 = add i64 %t191, %t192
  %t197 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i1, ptr %t198, i64 %t195
  %t200 = load i1, ptr %t199, !tbaa !31
  %t203 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i1, ptr %t204, i64 %t182
  store i1 %t200, ptr %t205, !tbaa !31
  br label %bb25
bb25:
  %t206 = load i64, ptr %l16, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l16, !tbaa !24
  br label %bb21
bb26:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/mir:verifier", ptr %t210, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t212)
  br label %bb27
bb27:
  store i64 0, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t214, i32 0, i32 11
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l131, !tbaa !27
  %t218 = load i64, ptr %l5, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i64, ptr %t221, i64 %t218
  %t223 = load i64, ptr %t222, !tbaa !34
  store i64 %t223, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l19, !tbaa !24
  %t226 = load i64, ptr %l18, !tbaa !24
  %t229 = icmp sgt i64 %t225, %t226
  br i1 %t229, label %bb28, label %bb29
bb28:
  %t231 = load i64, ptr %l20, !tbaa !24
  %t233 = icmp sgt i64 %t231, 0
  br i1 %t233, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb33
bb30:
  %t235 = load i64, ptr %l19, !tbaa !24
  %t236 = load i64, ptr %l18, !tbaa !24
  %t239 = sub i64 %t235, %t236
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = add i64 %t239, %t240
  %t245 = sub i64 %t243, 1
  %t246 = load i64, ptr %l20, !tbaa !24
  %t249 = sdiv i64 %t245, %t246
  store i64 %t249, ptr %l140, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb32
bb32:
  %t251 = load i64, ptr %l140, !tbaa !24
  store i64 %t251, ptr %l137, !tbaa !24
  br label %bb33
bb33:
  %t252 = load i64, ptr %l137, !tbaa !24
  store i64 %t252, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb34
bb34:
  %t253 = load i64, ptr %l22, !tbaa !24
  %t254 = load i64, ptr %l21, !tbaa !24
  %t257 = icmp slt i64 %t253, %t254
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t261 = load i64, ptr %l18, !tbaa !24
  %t262 = load i64, ptr %l22, !tbaa !24
  %t263 = load i64, ptr %l20, !tbaa !24
  %t266 = mul i64 %t262, %t263
  %t269 = add i64 %t261, %t266
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t271, i32 0, i32 17
  store ptr %t273, ptr %l159, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/mir:verifier", ptr %t274, i32 0, i32 12
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/mir:verifier", ptr %t277, i32 0, i32 10
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l163, !tbaa !27
  %t281 = load i64, ptr %l5, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i64, ptr %t284, i64 %t281
  %t286 = load i64, ptr %t285, !tbaa !34
  %t290 = add i64 %t286, %t269
  %t293 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t276, i64 %t290)
  store i32 %t293, ptr %l168
  br label %bb38
bb38:
  %t294 = load ptr, ptr %l159, !tbaa !29
  %t295 = load i32, ptr %l168, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t294, i32 %t295)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t296 = load i64, ptr %l22, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l22, !tbaa !24
  br label %bb34
bb41:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i64, ptr %l5, !tbaa !24
  %t304 = getelementptr %"compiler/mir:verifier", ptr %t300, i32 0, i32 3
  store i64 %t301, ptr %t304, !tbaa !24
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = getelementptr %"compiler/mir:Fn", ptr %t305, i32 0, i32 9
  %t308 = load i64, ptr %l5, !tbaa !24
  %t311 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t307, i64 %t308)
  store ptr %t311, ptr %l176
  br label %bb42
bb42:
  %t312 = load ptr, ptr %l176, !tbaa !29
  store ptr %t312, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  %t313 = load ptr, ptr %l24, !tbaa !29
  %t315 = getelementptr %"compiler/mir:BasicBlock", ptr %t313, i32 0, i32 0
  %t317 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t315)
  store i64 %t317, ptr %l179
  br label %bb43
bb43:
  %t318 = load i64, ptr %l179, !tbaa !24
  store i64 %t318, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t320 = load i64, ptr %l25, !tbaa !24
  %t323 = icmp sgt i64 %t319, %t320
  br i1 %t323, label %bb44, label %bb45
bb44:
  %t325 = load i64, ptr %l27, !tbaa !24
  %t327 = icmp sgt i64 %t325, 0
  br i1 %t327, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb49
bb46:
  %t329 = load i64, ptr %l26, !tbaa !24
  %t330 = load i64, ptr %l25, !tbaa !24
  %t333 = sub i64 %t329, %t330
  %t334 = load i64, ptr %l27, !tbaa !24
  %t337 = add i64 %t333, %t334
  %t339 = sub i64 %t337, 1
  %t340 = load i64, ptr %l27, !tbaa !24
  %t343 = sdiv i64 %t339, %t340
  store i64 %t343, ptr %l186, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb48
bb48:
  %t345 = load i64, ptr %l186, !tbaa !24
  store i64 %t345, ptr %l183, !tbaa !24
  br label %bb49
bb49:
  %t346 = load i64, ptr %l183, !tbaa !24
  store i64 %t346, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t347 = load i64, ptr %l29, !tbaa !24
  %t348 = load i64, ptr %l28, !tbaa !24
  %t351 = icmp slt i64 %t347, %t348
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t355 = load i64, ptr %l25, !tbaa !24
  %t356 = load i64, ptr %l29, !tbaa !24
  %t357 = load i64, ptr %l27, !tbaa !24
  %t360 = mul i64 %t356, %t357
  %t363 = add i64 %t355, %t360
  store i64 %t363, ptr %l30, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i64, ptr %l30, !tbaa !24
  %t369 = getelementptr %"compiler/mir:verifier", ptr %t365, i32 0, i32 4
  store i64 %t366, ptr %t369, !tbaa !24
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l206, !tbaa !29
  %t371 = load ptr, ptr %l24, !tbaa !29
  %t373 = getelementptr %"compiler/mir:BasicBlock", ptr %t371, i32 0, i32 0
  %t374 = load i64, ptr %l30, !tbaa !24
  %t377 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t373, i64 %t374)
  store { i64, [21 x i64] } %t377, ptr %l210
  br label %bb54
bb54:
  %t378 = load { i64, [21 x i64] }, ptr %l210
  %t379 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t378, ptr %t379
  %t380 = load ptr, ptr %l206, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %s11, ptr %t380, ptr %t379)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb56:
  %t382 = load i64, ptr %l29, !tbaa !24
  %t384 = add i64 %t382, 1
  store i64 %t384, ptr %l29, !tbaa !24
  br label %bb50
bb57:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/mir:verifier", ptr %t386, i32 0, i32 4
  store i64 -1, ptr %t388, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l24, !tbaa !29
  %t392 = getelementptr %"compiler/mir:BasicBlock", ptr %t390, i32 0, i32 1
  %t393 = load { i64, [8 x i64] }, ptr %t392
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %t389, { i64, [8 x i64] } %t393)
  br label %bb58
bb58:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l6 = alloca i1
  %l9 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp slt i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = add i64 %t15, %t19
  %t26 = icmp sgt i64 %t22, %a2
  store i1 %t26, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l9, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %a3, 1
  %t35 = extractvalue { i64, ptr } %a3, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %a0, { i64, ptr } %t51)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2edeferFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Fn"
  %l13 = alloca ptr
  %l16 = alloca i32
  %l21 = alloca %"compiler/mir:Local"
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/mir:Lvalue"
  %l33 = alloca { i64, [21 x i64] }
  %l39 = alloca { i64, [21 x i64] }
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/mir:Lvalue"
  %l49 = alloca { i64, [21 x i64] }
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/mir:Lvalue"
  %l63 = alloca { i64, [21 x i64] }
  %l69 = alloca { i64, [21 x i64] }
  %l71 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/mir:Lvalue"
  %l79 = alloca { i64, [21 x i64] }
  %l84 = alloca { i64, [21 x i64] }
  %l91 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t11 = alloca %"compiler/mir:Fn", align 8
  %t25 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [4 x i64] }, align 8
  %t56 = alloca { i64, [15 x i64] }, align 8
  %t62 = alloca { i64, [21 x i64] }, align 8
  %t79 = alloca { i64, [21 x i64] }, align 8
  %t98 = alloca { i64, [4 x i64] }, align 8
  %t105 = alloca { i64, [15 x i64] }, align 8
  %t111 = alloca { i64, [21 x i64] }, align 8
  %t127 = alloca { i64, [8 x i64] }, align 8
  %t143 = alloca { i64, [4 x i64] }, align 8
  %t150 = alloca { i64, [15 x i64] }, align 8
  %t156 = alloca { i64, [21 x i64] }, align 8
  %t173 = alloca { i64, [21 x i64] }, align 8
  %t192 = alloca { i64, [4 x i64] }, align 8
  %t199 = alloca { i64, [15 x i64] }, align 8
  %t205 = alloca { i64, [21 x i64] }, align 8
  %t221 = alloca { i64, [21 x i64] }, align 8
  %t234 = alloca { i64, [4 x i64] }, align 8
  %t237 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d215, i32 0, i32 1) })
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t6, i32 0, i32 %t7, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t11, ptr %v0, ptr %v1, ptr %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t11, i64 800, i1 false)
  br label %bb3
bb3:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t14, ptr %lp2
  %t15 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %l12, i64 800, i1 false)
  %t16 = load ptr, ptr %lp2
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d216, i32 0, i32 1) })
  store i32 %t22, ptr %l16
  br label %bb4
bb4:
  %t23 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t24 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i32 0, i32 0
  store i64 3, ptr %t26
  %t27 = load { i64, [1 x i64] }, ptr %t25
  %t28 = load i32, ptr %l16, !tbaa !23
  %t33 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t28, %"compiler/source:Span" %t23, i32 %t24, i32 2, { i64, [1 x i64] } %t27)
  store %"compiler/mir:Local" %t33, ptr %l21
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"compiler/mir:Local", ptr %l21
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t34, %"compiler/mir:Local" %t35)
  store i32 %t36, ptr %l22
  br label %bb6
bb6:
  %t37 = load i32, ptr %l22, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %lp2
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb7
bb7:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t42 = load ptr, ptr %lp2
  store ptr %t42, ptr %l25, !tbaa !29
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t44, ptr %l27
  %t45 = load i32, ptr %l3, !tbaa !23
  %t47 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t45)
  store %"compiler/mir:Lvalue" %t47, ptr %l29
  br label %bb8
bb8:
  %t48 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i64 } undef, i32 %t48, 0
  %t53 = insertvalue { i32, i64 } %t52, i64 1, 1
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i64 } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t49
  store { i64, [15 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [15 x i64] }, ptr %t56, i32 0, i32 0
  store i64 0, ptr %t57
  %t59 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t55, 0
  %t60 = getelementptr { i64, [15 x i64] }, ptr %t56, i32 0, i32 1
  store { { i64, [4 x i64] } } %t59, ptr %t60
  %t61 = load { i64, [15 x i64] }, ptr %t56
  store { i64, [21 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l27
  %t65 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t64, 0
  %t66 = load %"compiler/mir:Lvalue", ptr %l29
  %t67 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t65, %"compiler/mir:Lvalue" %t66, 1
  %t69 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t67, { i64, [15 x i64] } %t61, 2
  %t70 = getelementptr { i64, [21 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t69, ptr %t70
  %t71 = load { i64, [21 x i64] }, ptr %t62
  store { i64, [21 x i64] } %t71, ptr %l33
  %t72 = load ptr, ptr %l25, !tbaa !29
  %t73 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t72, i32 %t73, ptr %l33)
  br label %bb9
bb9:
  %t75 = load ptr, ptr %lp2
  %t76 = load i32, ptr %l4, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t78 = load i32, ptr %l5, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [21 x i64] }, ptr %t79, i32 0, i32 0
  store i64 12, ptr %t80
  %t82 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t77, 0
  %t83 = insertvalue { %"compiler/source:Span", i32, i32 } %t82, i32 0, 1
  %t85 = insertvalue { %"compiler/source:Span", i32, i32 } %t83, i32 %t78, 2
  %t86 = getelementptr { i64, [21 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t85, ptr %t86
  %t87 = load { i64, [21 x i64] }, ptr %t79
  store { i64, [21 x i64] } %t87, ptr %l39
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t75, i32 %t76, ptr %l39)
  br label %bb10
bb10:
  %t91 = load ptr, ptr %lp2
  store ptr %t91, ptr %l41, !tbaa !29
  %t92 = load i32, ptr %l5, !tbaa !23
  store i32 %t92, ptr %l42, !tbaa !23
  %t93 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t93, ptr %l43
  %t94 = load i32, ptr %l3, !tbaa !23
  %t96 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t94)
  store %"compiler/mir:Lvalue" %t96, ptr %l45
  br label %bb11
bb11:
  %t97 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 0
  store i64 2, ptr %t99
  %t101 = insertvalue { i32, i64 } undef, i32 %t97, 0
  %t102 = insertvalue { i32, i64 } %t101, i64 2, 1
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  store { i32, i64 } %t102, ptr %t103
  %t104 = load { i64, [4 x i64] }, ptr %t98
  store { i64, [15 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [15 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t108 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t104, 0
  %t109 = getelementptr { i64, [15 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] } } %t108, ptr %t109
  %t110 = load { i64, [15 x i64] }, ptr %t105
  store { i64, [21 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [21 x i64] }, ptr %t111, i32 0, i32 0
  store i64 0, ptr %t112
  %t113 = load %"compiler/source:Span", ptr %l43
  %t114 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t113, 0
  %t115 = load %"compiler/mir:Lvalue", ptr %l45
  %t116 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t114, %"compiler/mir:Lvalue" %t115, 1
  %t118 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t116, { i64, [15 x i64] } %t110, 2
  %t119 = getelementptr { i64, [21 x i64] }, ptr %t111, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t118, ptr %t119
  %t120 = load { i64, [21 x i64] }, ptr %t111
  store { i64, [21 x i64] } %t120, ptr %l49
  %t121 = load ptr, ptr %l41, !tbaa !29
  %t122 = load i32, ptr %l42, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t121, i32 %t122, ptr %l49)
  br label %bb12
bb12:
  %t124 = load ptr, ptr %lp2
  %t125 = load i32, ptr %l5, !tbaa !23
  %t126 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [8 x i64] }, ptr %t127, i32 0, i32 0
  store i64 10, ptr %t128
  %t130 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t126, 0
  %t131 = getelementptr { i64, [8 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span" } %t130, ptr %t131
  %t132 = load { i64, [8 x i64] }, ptr %t127
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t124, i32 %t125, { i64, [8 x i64] } %t132)
  br label %bb13
bb13:
  %t136 = load ptr, ptr %lp2
  store ptr %t136, ptr %l55, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  store i32 %t137, ptr %l56, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t138, ptr %l57
  %t139 = load i32, ptr %l3, !tbaa !23
  %t141 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t139)
  store %"compiler/mir:Lvalue" %t141, ptr %l59
  br label %bb14
bb14:
  %t142 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 0
  store i64 2, ptr %t144
  %t146 = insertvalue { i32, i64 } undef, i32 %t142, 0
  %t147 = insertvalue { i32, i64 } %t146, i64 3, 1
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 1
  store { i32, i64 } %t147, ptr %t148
  %t149 = load { i64, [4 x i64] }, ptr %t143
  store { i64, [15 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [15 x i64] }, ptr %t150, i32 0, i32 0
  store i64 0, ptr %t151
  %t153 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t149, 0
  %t154 = getelementptr { i64, [15 x i64] }, ptr %t150, i32 0, i32 1
  store { { i64, [4 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [15 x i64] }, ptr %t150
  store { i64, [21 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [21 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load %"compiler/source:Span", ptr %l57
  %t159 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t158, 0
  %t160 = load %"compiler/mir:Lvalue", ptr %l59
  %t161 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t159, %"compiler/mir:Lvalue" %t160, 1
  %t163 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t161, { i64, [15 x i64] } %t155, 2
  %t164 = getelementptr { i64, [21 x i64] }, ptr %t156, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t163, ptr %t164
  %t165 = load { i64, [21 x i64] }, ptr %t156
  store { i64, [21 x i64] } %t165, ptr %l63
  %t166 = load ptr, ptr %l55, !tbaa !29
  %t167 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t166, i32 %t167, ptr %l63)
  br label %bb15
bb15:
  %t169 = load ptr, ptr %lp2
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t172 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [21 x i64] }, ptr %t173, i32 0, i32 0
  store i64 12, ptr %t174
  %t176 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t171, 0
  %t177 = insertvalue { %"compiler/source:Span", i32, i32 } %t176, i32 0, 1
  %t179 = insertvalue { %"compiler/source:Span", i32, i32 } %t177, i32 %t172, 2
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t179, ptr %t180
  %t181 = load { i64, [21 x i64] }, ptr %t173
  store { i64, [21 x i64] } %t181, ptr %l69
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t169, i32 %t170, ptr %l69)
  br label %bb16
bb16:
  %t185 = load ptr, ptr %lp2
  store ptr %t185, ptr %l71, !tbaa !29
  %t186 = load i32, ptr %l4, !tbaa !23
  store i32 %t186, ptr %l72, !tbaa !23
  %t187 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t187, ptr %l73
  %t188 = load i32, ptr %l3, !tbaa !23
  %t190 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t188)
  store %"compiler/mir:Lvalue" %t190, ptr %l75
  br label %bb17
bb17:
  %t191 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 0
  store i64 2, ptr %t193
  %t195 = insertvalue { i32, i64 } undef, i32 %t191, 0
  %t196 = insertvalue { i32, i64 } %t195, i64 2, 1
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  store { i32, i64 } %t196, ptr %t197
  %t198 = load { i64, [4 x i64] }, ptr %t192
  store { i64, [15 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [15 x i64] }, ptr %t199, i32 0, i32 0
  store i64 0, ptr %t200
  %t202 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t198, 0
  %t203 = getelementptr { i64, [15 x i64] }, ptr %t199, i32 0, i32 1
  store { { i64, [4 x i64] } } %t202, ptr %t203
  %t204 = load { i64, [15 x i64] }, ptr %t199
  store { i64, [21 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [21 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load %"compiler/source:Span", ptr %l73
  %t208 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t207, 0
  %t209 = load %"compiler/mir:Lvalue", ptr %l75
  %t210 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t208, %"compiler/mir:Lvalue" %t209, 1
  %t212 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t210, { i64, [15 x i64] } %t204, 2
  %t213 = getelementptr { i64, [21 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t212, ptr %t213
  %t214 = load { i64, [21 x i64] }, ptr %t205
  store { i64, [21 x i64] } %t214, ptr %l79
  %t215 = load ptr, ptr %l71, !tbaa !29
  %t216 = load i32, ptr %l72, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t215, i32 %t216, ptr %l79)
  br label %bb18
bb18:
  %t218 = load ptr, ptr %lp2
  %t219 = load i32, ptr %l4, !tbaa !23
  %t220 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t221
  %t222 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 0
  store i64 4, ptr %t222
  %t224 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t220, 0
  %t225 = insertvalue { %"compiler/source:Span", i32 } %t224, i32 0, 1
  %t226 = getelementptr { i64, [21 x i64] }, ptr %t221, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t225, ptr %t226
  %t227 = load { i64, [21 x i64] }, ptr %t221
  store { i64, [21 x i64] } %t227, ptr %l84
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t218, i32 %t219, ptr %l84)
  br label %bb19
bb19:
  %t231 = load ptr, ptr %lp2
  %t232 = load i32, ptr %l4, !tbaa !23
  %t233 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [4 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 0
  store i64 0, ptr %t235
  %t236 = load { i64, [4 x i64] }, ptr %t234
  store { i64, [8 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [8 x i64] }, ptr %t237, i32 0, i32 0
  store i64 5, ptr %t238
  %t240 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t233, 0
  %t242 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t240, { i64, [4 x i64] } %t236, 1
  %t243 = getelementptr { i64, [8 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t242, ptr %t243
  %t244 = load { i64, [8 x i64] }, ptr %t237
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t231, i32 %t232, { i64, [8 x i64] } %t244)
  br label %bb20
bb20:
  %t248 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t248, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l91, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eloopFn(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca %"compiler/mir:Fn"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l47 = alloca %"compiler/mir:Local"
  %l48 = alloca i32
  %l52 = alloca i32
  %l56 = alloca i32
  %l60 = alloca i32
  %l64 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/mir:Lvalue"
  %l86 = alloca { i64, [21 x i64] }
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/mir:Lvalue"
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca ptr
  %l100 = alloca %"compiler/mir:Lvalue"
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca %"compiler/mir:Lvalue"
  %l105 = alloca { i64, ptr }
  %l106 = alloca %"compiler/mir:Range"
  %l108 = alloca { i64, [21 x i64] }
  %l110 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca %"compiler/mir:Lvalue"
  %l122 = alloca { i64, [21 x i64] }
  %l124 = alloca ptr
  %l127 = alloca { i64, [7 x i64] }
  %l128 = alloca ptr
  %l130 = alloca %"compiler/mir:Lvalue"
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/mir:Range"
  %l134 = alloca %"compiler/mir:Range"
  %l136 = alloca %"compiler/mir:Lvalue"
  %l140 = alloca %"compiler/mir:Call"
  %l141 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca %"compiler/source:Span"
  %l151 = alloca %"compiler/mir:Lvalue"
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca ptr
  %l156 = alloca %"compiler/mir:Lvalue"
  %l160 = alloca { i64, ptr }
  %l161 = alloca %"compiler/mir:Range"
  %l163 = alloca { i64, [21 x i64] }
  %l169 = alloca { i64, [21 x i64] }
  %l178 = alloca { i64, [21 x i64] }
  %l180 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/mir:Lvalue"
  %l187 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/mir:Lvalue"
  %l193 = alloca %"compiler/mir:Lvalue"
  %l198 = alloca { i64, [21 x i64] }
  %l204 = alloca { i64, [21 x i64] }
  %l209 = alloca { i64, [21 x i64] }
  %l211 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l215 = alloca %"compiler/mir:Lvalue"
  %l218 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t25 = alloca %"compiler/mir:Fn", align 8
  %t53 = alloca { i64, [1 x i64] }, align 8
  %t131 = alloca { i64, [4 x i64] }, align 8
  %t138 = alloca { i64, [15 x i64] }, align 8
  %t144 = alloca { i64, [21 x i64] }, align 8
  %t158 = alloca { i64, [8 x i64] }, align 8
  %t177 = alloca { i64, [4 x i64] }, align 8
  %t186 = alloca { i64, [4 x i64] }, align 8
  %t207 = alloca { i64, [15 x i64] }, align 8
  %t217 = alloca { i64, [21 x i64] }, align 8
  %t235 = alloca { i64, [4 x i64] }, align 8
  %t243 = alloca { i64, [8 x i64] }, align 8
  %t260 = alloca { i64, [21 x i64] }, align 8
  %t272 = alloca { i64, [2 x i64] }, align 8
  %t278 = alloca { i64, [7 x i64] }, align 8
  %t290 = alloca { i64, [4 x i64] }, align 8
  %t330 = alloca { i64, [8 x i64] }, align 8
  %t352 = alloca { i64, [4 x i64] }, align 8
  %t359 = alloca { i64, [4 x i64] }, align 8
  %t381 = alloca { i64, [15 x i64] }, align 8
  %t391 = alloca { i64, [21 x i64] }, align 8
  %t408 = alloca { i64, [21 x i64] }, align 8
  %t422 = alloca { i64, [8 x i64] }, align 8
  %t434 = alloca { i64, [21 x i64] }, align 8
  %t450 = alloca { i64, [4 x i64] }, align 8
  %t456 = alloca { i64, [8 x i64] }, align 8
  %t476 = alloca { i64, [4 x i64] }, align 8
  %t484 = alloca { i64, [15 x i64] }, align 8
  %t494 = alloca { i64, [21 x i64] }, align 8
  %t511 = alloca { i64, [21 x i64] }, align 8
  %t525 = alloca { i64, [21 x i64] }, align 8
  %t541 = alloca { i64, [4 x i64] }, align 8
  %t547 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d217, i32 0, i32 1) })
  store i32 %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load i32, ptr %l19, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i32, ptr %l22, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l23, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l24, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l27
  br label %bb3
bb3:
  %t18 = load i32, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t20, i32 %t21, i32 %t18, i32 %t19, i32 0, i64 0, i1 false, i32 0)
  store i32 %t24, ptr %l30
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2etfn(ptr %t25, ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t25, i64 800, i1 false)
  br label %bb5
bb5:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t28, ptr %lp3
  %t29 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l31, i64 800, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l35
  br label %bb6
bb6:
  %t36 = load i32, ptr %l1, !tbaa !23
  %t37 = load i32, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l32, !tbaa !29
  %t39 = load i32, ptr %l35, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t38, i32 %t39, i32 %t36, i32 %t37, i32 0, i64 0, i1 false, i32 0)
  store i32 %t42, ptr %l38
  br label %bb7
bb7:
  %t43 = load i32, ptr %l38, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  store i32 0, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp3
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t48, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) })
  store i32 %t50, ptr %l42
  br label %bb8
bb8:
  %t51 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t52 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i32 0, i32 0
  store i64 3, ptr %t54
  %t55 = load { i64, [1 x i64] }, ptr %t53
  %t56 = load i32, ptr %l42, !tbaa !23
  %t61 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t56, %"compiler/source:Span" %t51, i32 %t52, i32 2, { i64, [1 x i64] } %t55)
  store %"compiler/mir:Local" %t61, ptr %l47
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t63 = load %"compiler/mir:Local", ptr %l47
  %t64 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t62, %"compiler/mir:Local" %t63)
  store i32 %t64, ptr %l48
  br label %bb10
bb10:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %lp3
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t72 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t66, i32 %t67, %"compiler/source:Span" %t68)
  store i32 %t72, ptr %l52
  br label %bb11
bb11:
  %t73 = load i32, ptr %l52, !tbaa !23
  store i32 %t73, ptr %l7, !tbaa !23
  %t74 = load ptr, ptr %lp3
  %t75 = load i32, ptr %l1, !tbaa !23
  %t76 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t80 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t74, i32 %t75, %"compiler/source:Span" %t76)
  store i32 %t80, ptr %l56
  br label %bb12
bb12:
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %l8, !tbaa !23
  %t82 = load ptr, ptr %lp3
  %t83 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t88 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t82, i32 %t83, %"compiler/source:Span" %t84)
  store i32 %t88, ptr %l60
  br label %bb13
bb13:
  %t89 = load i32, ptr %l60, !tbaa !23
  store i32 %t89, ptr %l9, !tbaa !23
  %t90 = load ptr, ptr %lp3
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t92 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t96 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t90, i32 %t91, %"compiler/source:Span" %t92)
  store i32 %t96, ptr %l64
  br label %bb14
bb14:
  %t97 = load i32, ptr %l64, !tbaa !23
  store i32 %t97, ptr %l10, !tbaa !23
  %t98 = load ptr, ptr %lp3
  %t99 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t98, i32 2, i32 0, i32 1, %"compiler/source:Span" %t99, i32 0)
  store i32 %t103, ptr %l68
  br label %bb15
bb15:
  %t104 = load i32, ptr %l68, !tbaa !23
  store i32 %t104, ptr %l11, !tbaa !23
  %t105 = load ptr, ptr %lp3
  %t107 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t105)
  store i32 %t107, ptr %l70
  br label %bb16
bb16:
  %t108 = load i32, ptr %l70, !tbaa !23
  store i32 %t108, ptr %l12, !tbaa !23
  %t109 = load ptr, ptr %lp3
  %t111 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t109)
  store i32 %t111, ptr %l72
  br label %bb17
bb17:
  %t112 = load i32, ptr %l72, !tbaa !23
  store i32 %t112, ptr %l13, !tbaa !23
  %t113 = load ptr, ptr %lp3
  %t115 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t113)
  store i32 %t115, ptr %l74
  br label %bb18
bb18:
  %t116 = load i32, ptr %l74, !tbaa !23
  store i32 %t116, ptr %l14, !tbaa !23
  %t117 = load ptr, ptr %lp3
  %t119 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t117)
  store i32 %t119, ptr %l76
  br label %bb19
bb19:
  %t120 = load i32, ptr %l76, !tbaa !23
  store i32 %t120, ptr %l15, !tbaa !23
  %t121 = load ptr, ptr %lp3
  %t123 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t121)
  store i32 %t123, ptr %l78
  br label %bb20
bb20:
  %t124 = load i32, ptr %l78, !tbaa !23
  store i32 %t124, ptr %l16, !tbaa !23
  %t125 = load ptr, ptr %lp3
  store ptr %t125, ptr %l79, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t126, ptr %l80
  %t127 = load i32, ptr %l6, !tbaa !23
  %t129 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t127)
  store %"compiler/mir:Lvalue" %t129, ptr %l82
  br label %bb21
bb21:
  %t130 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 2, ptr %t132
  %t134 = insertvalue { i32, i64 } undef, i32 %t130, 0
  %t135 = insertvalue { i32, i64 } %t134, i64 0, 1
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { i32, i64 } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t131
  store { i64, [15 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [15 x i64] }, ptr %t138, i32 0, i32 0
  store i64 0, ptr %t139
  %t141 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t137, 0
  %t142 = getelementptr { i64, [15 x i64] }, ptr %t138, i32 0, i32 1
  store { { i64, [4 x i64] } } %t141, ptr %t142
  %t143 = load { i64, [15 x i64] }, ptr %t138
  store { i64, [21 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l80
  %t147 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t146, 0
  %t148 = load %"compiler/mir:Lvalue", ptr %l82
  %t149 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t147, %"compiler/mir:Lvalue" %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t149, { i64, [15 x i64] } %t143, 2
  %t152 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t151, ptr %t152
  %t153 = load { i64, [21 x i64] }, ptr %t144
  store { i64, [21 x i64] } %t153, ptr %l86
  %t154 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t154, i32 0, ptr %l86)
  br label %bb22
bb22:
  %t156 = load ptr, ptr %lp3
  %t157 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [8 x i64] }, ptr %t158, i32 0, i32 0
  store i64 1, ptr %t159
  %t161 = insertvalue { i32 } undef, i32 %t157, 0
  %t162 = getelementptr { i64, [8 x i64] }, ptr %t158, i32 0, i32 1
  store { i32 } %t161, ptr %t162
  %t163 = load { i64, [8 x i64] }, ptr %t158
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t156, i32 0, { i64, [8 x i64] } %t163)
  br label %bb23
bb23:
  %t166 = load ptr, ptr %lp3
  store ptr %t166, ptr %l91, !tbaa !29
  %t167 = load i32, ptr %l12, !tbaa !23
  store i32 %t167, ptr %l92, !tbaa !23
  %t168 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t168, ptr %l93
  %t169 = load i32, ptr %l7, !tbaa !23
  %t171 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t169)
  store %"compiler/mir:Lvalue" %t171, ptr %l95
  br label %bb24
bb24:
  store i32 15, ptr %l96
  %t172 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t172, ptr %l97, !tbaa !23
  %t173 = load ptr, ptr %lp3
  store ptr %t173, ptr %l98, !tbaa !29
  %t174 = load i32, ptr %l6, !tbaa !23
  %t176 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t174)
  store %"compiler/mir:Lvalue" %t176, ptr %l100
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 0
  store i64 1, ptr %t178
  %t179 = load %"compiler/mir:Lvalue", ptr %l100
  %t180 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t179, 0
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t177, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t180, ptr %t181
  %t182 = load { i64, [4 x i64] }, ptr %t177
  store { i64, [4 x i64] } %t182, ptr %l101
  %t183 = load i32, ptr %l5, !tbaa !23
  %t185 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t183)
  store %"compiler/mir:Lvalue" %t185, ptr %l103
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 0
  store i64 1, ptr %t187
  %t188 = load %"compiler/mir:Lvalue", ptr %l103
  %t189 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t188, 0
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t189, ptr %t190
  %t191 = load { i64, [4 x i64] }, ptr %t186
  %t192 = mul i64 2, 40
  %t193 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 2, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l105, !tbaa !27
  %t196 = load { i64, [4 x i64] }, ptr %l101
  %t197 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i64 0
  store { i64, [4 x i64] } %t196, ptr %t199
  %t201 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i64 1
  store { i64, [4 x i64] } %t191, ptr %t203
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t206 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t204, { i64, ptr } %t205)
  store %"compiler/mir:Range" %t206, ptr %l106
  br label %bb27
bb27:
  store { i64, [15 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [15 x i64] }, ptr %t207, i32 0, i32 0
  store i64 3, ptr %t208
  %t209 = load i32, ptr %l96, !range !{i32 0, i32 43}
  %t210 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t209, 0
  %t211 = load i32, ptr %l97, !tbaa !23
  %t212 = insertvalue { i32, i32, %"compiler/mir:Range" } %t210, i32 %t211, 1
  %t213 = load %"compiler/mir:Range", ptr %l106
  %t214 = insertvalue { i32, i32, %"compiler/mir:Range" } %t212, %"compiler/mir:Range" %t213, 2
  %t215 = getelementptr { i64, [15 x i64] }, ptr %t207, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t214, ptr %t215
  %t216 = load { i64, [15 x i64] }, ptr %t207
  store { i64, [21 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [21 x i64] }, ptr %t217, i32 0, i32 0
  store i64 0, ptr %t218
  %t219 = load %"compiler/source:Span", ptr %l93
  %t220 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t219, 0
  %t221 = load %"compiler/mir:Lvalue", ptr %l95
  %t222 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t220, %"compiler/mir:Lvalue" %t221, 1
  %t224 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t222, { i64, [15 x i64] } %t216, 2
  %t225 = getelementptr { i64, [21 x i64] }, ptr %t217, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t224, ptr %t225
  %t226 = load { i64, [21 x i64] }, ptr %t217
  store { i64, [21 x i64] } %t226, ptr %l108
  %t227 = load ptr, ptr %l91, !tbaa !29
  %t228 = load i32, ptr %l92, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t227, i32 %t228, ptr %l108)
  br label %bb28
bb28:
  %t230 = load ptr, ptr %lp3
  store ptr %t230, ptr %l110, !tbaa !29
  %t231 = load i32, ptr %l12, !tbaa !23
  store i32 %t231, ptr %l111, !tbaa !23
  %t232 = load i32, ptr %l7, !tbaa !23
  %t234 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t232)
  store %"compiler/mir:Lvalue" %t234, ptr %l113
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 0
  store i64 1, ptr %t236
  %t237 = load %"compiler/mir:Lvalue", ptr %l113
  %t238 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t237, 0
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t235
  %t241 = load i32, ptr %l13, !tbaa !23
  %t242 = load i32, ptr %l15, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 0
  store i64 2, ptr %t244
  %t246 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t240, 0
  %t248 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t246, i32 %t241, 1
  %t250 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t248, i32 %t242, 2
  %t251 = getelementptr { i64, [8 x i64] }, ptr %t243, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t250, ptr %t251
  %t252 = load { i64, [8 x i64] }, ptr %t243
  %t253 = load ptr, ptr %l110, !tbaa !29
  %t254 = load i32, ptr %l111, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t253, i32 %t254, { i64, [8 x i64] } %t252)
  br label %bb30
bb30:
  %t256 = load ptr, ptr %lp3
  %t257 = load i32, ptr %l13, !tbaa !23
  %t258 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t259 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [21 x i64] }, ptr %t260, i32 0, i32 0
  store i64 3, ptr %t261
  %t263 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t258, 0
  %t265 = insertvalue { %"compiler/source:Span", i32 } %t263, i32 %t259, 1
  %t266 = getelementptr { i64, [21 x i64] }, ptr %t260, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t265, ptr %t266
  %t267 = load { i64, [21 x i64] }, ptr %t260
  store { i64, [21 x i64] } %t267, ptr %l122
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t256, i32 %t257, ptr %l122)
  br label %bb31
bb31:
  %t271 = load ptr, ptr %lp3
  store ptr %t271, ptr %l124, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [2 x i64] }, ptr %t272, i32 0, i32 0
  store i64 0, ptr %t273
  %t274 = insertvalue { i32 } undef, i32 1, 0
  %t275 = getelementptr { i64, [2 x i64] }, ptr %t272, i32 0, i32 1
  store { i32 } %t274, ptr %t275
  %t276 = load { i64, [2 x i64] }, ptr %t272
  %t277 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [7 x i64] }, ptr %t278, i32 0, i32 0
  store i64 0, ptr %t279
  %t281 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t276, 0
  %t283 = insertvalue { { i64, [2 x i64] }, i32 } %t281, i32 %t277, 1
  %t284 = getelementptr { i64, [7 x i64] }, ptr %t278, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t283, ptr %t284
  %t285 = load { i64, [7 x i64] }, ptr %t278
  store { i64, [7 x i64] } %t285, ptr %l127
  %t286 = load ptr, ptr %lp3
  store ptr %t286, ptr %l128, !tbaa !29
  %t287 = load i32, ptr %l6, !tbaa !23
  %t289 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t287)
  store %"compiler/mir:Lvalue" %t289, ptr %l130
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t290
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 0
  store i64 1, ptr %t291
  %t292 = load %"compiler/mir:Lvalue", ptr %l130
  %t293 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t292, 0
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t293, ptr %t294
  %t295 = load { i64, [4 x i64] }, ptr %t290
  %t296 = mul i64 1, 40
  %t297 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t296)
  %t298 = insertvalue { i64, ptr } undef, i64 1, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l132, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t302, i64 0
  store { i64, [4 x i64] } %t295, ptr %t303
  %t304 = load ptr, ptr %l128, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t306 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t304, { i64, ptr } %t305)
  store %"compiler/mir:Range" %t306, ptr %l133
  br label %bb33
bb33:
  %t307 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t307, ptr %l134
  %t308 = load i32, ptr %l8, !tbaa !23
  %t310 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t308)
  store %"compiler/mir:Lvalue" %t310, ptr %l136
  br label %bb34
bb34:
  %t311 = load i32, ptr %l14, !tbaa !23
  %t312 = load i32, ptr %l9, !tbaa !23
  %t313 = load i32, ptr %l16, !tbaa !23
  %t314 = load { i64, [7 x i64] }, ptr %l127
  %t315 = load %"compiler/mir:Range", ptr %l133
  %t316 = load %"compiler/mir:Range", ptr %l134
  %t317 = load %"compiler/mir:Lvalue", ptr %l136
  %t321 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t314, %"compiler/mir:Range" %t315, %"compiler/mir:Range" %t316, %"compiler/mir:Lvalue" %t317, i1 true, i32 %t311, i32 %t312, i32 %t313)
  store %"compiler/mir:Call" %t321, ptr %l140
  br label %bb35
bb35:
  %t322 = load ptr, ptr %l124, !tbaa !29
  %t323 = load %"compiler/mir:Call", ptr %l140
  %t324 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t322, %"compiler/mir:Call" %t323)
  store i32 %t324, ptr %l141
  br label %bb36
bb36:
  %t325 = load i32, ptr %l141, !tbaa !23
  %t326 = load ptr, ptr %lp3
  %t327 = load i32, ptr %l13, !tbaa !23
  %t328 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [8 x i64] }, ptr %t330, i32 0, i32 0
  store i64 4, ptr %t331
  %t333 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t328, 0
  %t335 = insertvalue { %"compiler/source:Span", i32 } %t333, i32 %t325, 1
  %t336 = getelementptr { i64, [8 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t335, ptr %t336
  %t337 = load { i64, [8 x i64] }, ptr %t330
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t326, i32 %t327, { i64, [8 x i64] } %t337)
  br label %bb37
bb37:
  %t341 = load ptr, ptr %lp3
  store ptr %t341, ptr %l147, !tbaa !29
  %t342 = load i32, ptr %l14, !tbaa !23
  store i32 %t342, ptr %l148, !tbaa !23
  %t343 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t343, ptr %l149
  %t344 = load i32, ptr %l6, !tbaa !23
  %t346 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t344)
  store %"compiler/mir:Lvalue" %t346, ptr %l151
  br label %bb38
bb38:
  store i32 3, ptr %l152
  %t347 = load i32, ptr %l1, !tbaa !23
  store i32 %t347, ptr %l153, !tbaa !23
  %t348 = load ptr, ptr %lp3
  store ptr %t348, ptr %l154, !tbaa !29
  %t349 = load i32, ptr %l6, !tbaa !23
  %t351 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t349)
  store %"compiler/mir:Lvalue" %t351, ptr %l156
  br label %bb39
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 0
  store i64 1, ptr %t353
  %t354 = load %"compiler/mir:Lvalue", ptr %l156
  %t355 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t354, 0
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t355, ptr %t356
  %t357 = load { i64, [4 x i64] }, ptr %t352
  %t358 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 0
  store i64 2, ptr %t360
  %t362 = insertvalue { i32, i64 } undef, i32 %t358, 0
  %t363 = insertvalue { i32, i64 } %t362, i64 1, 1
  %t364 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 1
  store { i32, i64 } %t363, ptr %t364
  %t365 = load { i64, [4 x i64] }, ptr %t359
  %t366 = mul i64 2, 40
  %t367 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t366)
  %t368 = insertvalue { i64, ptr } undef, i64 2, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  store { i64, ptr } %t369, ptr %l160, !tbaa !27
  %t371 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t372, i64 0
  store { i64, [4 x i64] } %t357, ptr %t373
  %t375 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr { i64, [4 x i64] }, ptr %t376, i64 1
  store { i64, [4 x i64] } %t365, ptr %t377
  %t378 = load ptr, ptr %l154, !tbaa !29
  %t379 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t380 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t378, { i64, ptr } %t379)
  store %"compiler/mir:Range" %t380, ptr %l161
  br label %bb40
bb40:
  store { i64, [15 x i64] } zeroinitializer, ptr %t381
  %t382 = getelementptr { i64, [15 x i64] }, ptr %t381, i32 0, i32 0
  store i64 3, ptr %t382
  %t383 = load i32, ptr %l152, !range !{i32 0, i32 43}
  %t384 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t383, 0
  %t385 = load i32, ptr %l153, !tbaa !23
  %t386 = insertvalue { i32, i32, %"compiler/mir:Range" } %t384, i32 %t385, 1
  %t387 = load %"compiler/mir:Range", ptr %l161
  %t388 = insertvalue { i32, i32, %"compiler/mir:Range" } %t386, %"compiler/mir:Range" %t387, 2
  %t389 = getelementptr { i64, [15 x i64] }, ptr %t381, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t388, ptr %t389
  %t390 = load { i64, [15 x i64] }, ptr %t381
  store { i64, [21 x i64] } zeroinitializer, ptr %t391
  %t392 = getelementptr { i64, [21 x i64] }, ptr %t391, i32 0, i32 0
  store i64 0, ptr %t392
  %t393 = load %"compiler/source:Span", ptr %l149
  %t394 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t393, 0
  %t395 = load %"compiler/mir:Lvalue", ptr %l151
  %t396 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t394, %"compiler/mir:Lvalue" %t395, 1
  %t398 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t396, { i64, [15 x i64] } %t390, 2
  %t399 = getelementptr { i64, [21 x i64] }, ptr %t391, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t398, ptr %t399
  %t400 = load { i64, [21 x i64] }, ptr %t391
  store { i64, [21 x i64] } %t400, ptr %l163
  %t401 = load ptr, ptr %l147, !tbaa !29
  %t402 = load i32, ptr %l148, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t401, i32 %t402, ptr %l163)
  br label %bb41
bb41:
  %t404 = load ptr, ptr %lp3
  %t405 = load i32, ptr %l14, !tbaa !23
  %t406 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t407 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t408
  %t409 = getelementptr { i64, [21 x i64] }, ptr %t408, i32 0, i32 0
  store i64 4, ptr %t409
  %t411 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t406, 0
  %t413 = insertvalue { %"compiler/source:Span", i32 } %t411, i32 %t407, 1
  %t414 = getelementptr { i64, [21 x i64] }, ptr %t408, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t413, ptr %t414
  %t415 = load { i64, [21 x i64] }, ptr %t408
  store { i64, [21 x i64] } %t415, ptr %l169
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t404, i32 %t405, ptr %l169)
  br label %bb42
bb42:
  %t419 = load ptr, ptr %lp3
  %t420 = load i32, ptr %l14, !tbaa !23
  %t421 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [8 x i64] }, ptr %t422, i32 0, i32 0
  store i64 1, ptr %t423
  %t425 = insertvalue { i32 } undef, i32 %t421, 0
  %t426 = getelementptr { i64, [8 x i64] }, ptr %t422, i32 0, i32 1
  store { i32 } %t425, ptr %t426
  %t427 = load { i64, [8 x i64] }, ptr %t422
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t419, i32 %t420, { i64, [8 x i64] } %t427)
  br label %bb43
bb43:
  %t431 = load ptr, ptr %lp3
  %t432 = load i32, ptr %l15, !tbaa !23
  %t433 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [21 x i64] }, ptr %t434, i32 0, i32 0
  store i64 4, ptr %t435
  %t437 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t433, 0
  %t438 = insertvalue { %"compiler/source:Span", i32 } %t437, i32 0, 1
  %t439 = getelementptr { i64, [21 x i64] }, ptr %t434, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t438, ptr %t439
  %t440 = load { i64, [21 x i64] }, ptr %t434
  store { i64, [21 x i64] } %t440, ptr %l178
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t431, i32 %t432, ptr %l178)
  br label %bb44
bb44:
  %t444 = load ptr, ptr %lp3
  store ptr %t444, ptr %l180, !tbaa !29
  %t445 = load i32, ptr %l15, !tbaa !23
  store i32 %t445, ptr %l181, !tbaa !23
  %t446 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t446, ptr %l182
  %t447 = load i32, ptr %l6, !tbaa !23
  %t449 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t447)
  store %"compiler/mir:Lvalue" %t449, ptr %l184
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t450
  %t451 = getelementptr { i64, [4 x i64] }, ptr %t450, i32 0, i32 0
  store i64 1, ptr %t451
  %t452 = load %"compiler/mir:Lvalue", ptr %l184
  %t453 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t452, 0
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t450, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t453, ptr %t454
  %t455 = load { i64, [4 x i64] }, ptr %t450
  store { i64, [8 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [8 x i64] }, ptr %t456, i32 0, i32 0
  store i64 5, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l182
  %t459 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t458, 0
  %t461 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t459, { i64, [4 x i64] } %t455, 1
  %t462 = getelementptr { i64, [8 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t461, ptr %t462
  %t463 = load { i64, [8 x i64] }, ptr %t456
  %t464 = load ptr, ptr %l180, !tbaa !29
  %t465 = load i32, ptr %l181, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t464, i32 %t465, { i64, [8 x i64] } %t463)
  br label %bb46
bb46:
  %t467 = load ptr, ptr %lp3
  store ptr %t467, ptr %l187, !tbaa !29
  %t468 = load i32, ptr %l16, !tbaa !23
  store i32 %t468, ptr %l188, !tbaa !23
  %t469 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t469, ptr %l189
  %t470 = load i32, ptr %l10, !tbaa !23
  %t472 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t470)
  store %"compiler/mir:Lvalue" %t472, ptr %l191
  br label %bb47
bb47:
  %t473 = load i32, ptr %l9, !tbaa !23
  %t475 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t473)
  store %"compiler/mir:Lvalue" %t475, ptr %l193
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t476
  %t477 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 0
  store i64 1, ptr %t477
  %t478 = load %"compiler/mir:Lvalue", ptr %l193
  %t479 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t478, 0
  %t480 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t479, ptr %t480
  %t481 = load { i64, [4 x i64] }, ptr %t476
  %t482 = load i32, ptr %l2, !tbaa !23
  %t483 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t484
  %t485 = getelementptr { i64, [15 x i64] }, ptr %t484, i32 0, i32 0
  store i64 11, ptr %t485
  %t487 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t481, 0
  %t489 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t487, i32 %t482, 1
  %t491 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t489, i32 %t483, 2
  %t492 = getelementptr { i64, [15 x i64] }, ptr %t484, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t491, ptr %t492
  %t493 = load { i64, [15 x i64] }, ptr %t484
  store { i64, [21 x i64] } zeroinitializer, ptr %t494
  %t495 = getelementptr { i64, [21 x i64] }, ptr %t494, i32 0, i32 0
  store i64 0, ptr %t495
  %t496 = load %"compiler/source:Span", ptr %l189
  %t497 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t496, 0
  %t498 = load %"compiler/mir:Lvalue", ptr %l191
  %t499 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t497, %"compiler/mir:Lvalue" %t498, 1
  %t501 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t499, { i64, [15 x i64] } %t493, 2
  %t502 = getelementptr { i64, [21 x i64] }, ptr %t494, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t501, ptr %t502
  %t503 = load { i64, [21 x i64] }, ptr %t494
  store { i64, [21 x i64] } %t503, ptr %l198
  %t504 = load ptr, ptr %l187, !tbaa !29
  %t505 = load i32, ptr %l188, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t504, i32 %t505, ptr %l198)
  br label %bb49
bb49:
  %t507 = load ptr, ptr %lp3
  %t508 = load i32, ptr %l16, !tbaa !23
  %t509 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t510 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t511
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 0
  store i64 4, ptr %t512
  %t514 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t509, 0
  %t516 = insertvalue { %"compiler/source:Span", i32 } %t514, i32 %t510, 1
  %t517 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t516, ptr %t517
  %t518 = load { i64, [21 x i64] }, ptr %t511
  store { i64, [21 x i64] } %t518, ptr %l204
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t507, i32 %t508, ptr %l204)
  br label %bb50
bb50:
  %t522 = load ptr, ptr %lp3
  %t523 = load i32, ptr %l16, !tbaa !23
  %t524 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t525
  %t526 = getelementptr { i64, [21 x i64] }, ptr %t525, i32 0, i32 0
  store i64 4, ptr %t526
  %t528 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t524, 0
  %t529 = insertvalue { %"compiler/source:Span", i32 } %t528, i32 0, 1
  %t530 = getelementptr { i64, [21 x i64] }, ptr %t525, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t529, ptr %t530
  %t531 = load { i64, [21 x i64] }, ptr %t525
  store { i64, [21 x i64] } %t531, ptr %l209
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t522, i32 %t523, ptr %l209)
  br label %bb51
bb51:
  %t535 = load ptr, ptr %lp3
  store ptr %t535, ptr %l211, !tbaa !29
  %t536 = load i32, ptr %l16, !tbaa !23
  store i32 %t536, ptr %l212, !tbaa !23
  %t537 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t537, ptr %l213
  %t538 = load i32, ptr %l10, !tbaa !23
  %t540 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t538)
  store %"compiler/mir:Lvalue" %t540, ptr %l215
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [4 x i64] }, ptr %t541, i32 0, i32 0
  store i64 1, ptr %t542
  %t543 = load %"compiler/mir:Lvalue", ptr %l215
  %t544 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t543, 0
  %t545 = getelementptr { i64, [4 x i64] }, ptr %t541, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t544, ptr %t545
  %t546 = load { i64, [4 x i64] }, ptr %t541
  store { i64, [8 x i64] } zeroinitializer, ptr %t547
  %t548 = getelementptr { i64, [8 x i64] }, ptr %t547, i32 0, i32 0
  store i64 7, ptr %t548
  %t549 = load %"compiler/source:Span", ptr %l213
  %t550 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t549, 0
  %t552 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t550, { i64, [4 x i64] } %t546, 1
  %t553 = getelementptr { i64, [8 x i64] }, ptr %t547, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t552, ptr %t553
  %t554 = load { i64, [8 x i64] }, ptr %t547
  %t555 = load ptr, ptr %l211, !tbaa !29
  %t556 = load i32, ptr %l212, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t555, i32 %t556, { i64, [8 x i64] } %t554)
  br label %bb53
bb53:
  %t558 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l218, ptr %t558, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l218, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d219, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca %"compiler/mir:Fn"
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l40 = alloca { i64, [21 x i64] }
  %l42 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/mir:Fn", align 8
  %t68 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = insertvalue { i32 } undef, i32 9, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i32 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  call void @compiler_2fmir_3aFn_2ector(ptr %t8, ptr %v1, { i64, [2 x i64] } %t5, i32 %t6, i64 0, %"compiler/source:Span" %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t8, i64 800, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t12, ptr %lp2
  %t13 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %l10, i64 800, i1 false)
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  %t44 = load ptr, ptr %lp2
  %t45 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t50 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v1, ptr %t44, i32 0, %"compiler/source:Span" %t45, i32 %t42)
  store i32 %t50, ptr %l28
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  %t55 = load ptr, ptr %lp2
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t55, i32 0, i32 %t56, i32 0, %"compiler/source:Span" %t57, i32 0)
  store i32 %t62, ptr %l35
  br label %bb11
bb11:
  %t63 = load ptr, ptr %lp2
  %t65 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t63)
  store i32 %t65, ptr %l37
  br label %bb12
bb12:
  %t66 = load ptr, ptr %lp2
  %t67 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 0
  store i64 3, ptr %t69
  %t71 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t67, 0
  %t72 = insertvalue { %"compiler/source:Span", i32 } %t71, i32 0, 1
  %t73 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t72, ptr %t73
  %t74 = load { i64, [21 x i64] }, ptr %t68
  store { i64, [21 x i64] } %t74, ptr %l40
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t66, i32 0, ptr %l40)
  br label %bb13
bb13:
  %t77 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t77, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l42, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ewritesInto(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [21 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i32
  %l7 = alloca %"compiler/mir:Lvalue"
  %l8 = alloca { i64, [21 x i64] }
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i64
  %l40 = alloca { i64, [21 x i64] }
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [21 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l1, i64 176, i1 false)
  %t1 = load { i64, [21 x i64] }, ptr %l8
  %t2 = extractvalue { i64, [21 x i64] } %t1, 0
  %t3 = icmp eq i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t6 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t5, i32 0, i32 1
  %t7 = load %"compiler/mir:Lvalue", ptr %t6
  store %"compiler/mir:Lvalue" %t7, ptr %l3
  %t9 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t9, i32 0, i32 2
  %t11 = load { i64, [15 x i64] }, ptr %t10
  store { i64, [15 x i64] } %t11, ptr %l4
  br label %bb3
bb2:
  br label %bb28
bb3:
  %t13 = getelementptr %"compiler/mir:Lvalue", ptr %l3, i32 0, i32 1
  %t14 = getelementptr %"compiler/mir:Range", ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = icmp sgt i32 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load %"compiler/mir:Lvalue", ptr %l3
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t19, i32 %t20)
  store i1 %t23, ptr %l17
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, [15 x i64] }, ptr %l4
  %t29 = extractvalue { i64, [15 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 1
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t33 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/mir:Lvalue", ptr %t33
  store %"compiler/mir:Lvalue" %t34, ptr %l5
  %t36 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t37 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l6, !tbaa !23
  br label %bb15
bb12:
  %t40 = load { i64, [15 x i64] }, ptr %l4
  %t42 = extractvalue { i64, [15 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 9
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t46 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load %"compiler/mir:Lvalue", ptr %t46
  store %"compiler/mir:Lvalue" %t47, ptr %l5
  %t49 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t50 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t49, i32 0, i32 3
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t53 = load %"compiler/mir:Lvalue", ptr %l5
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t53, i32 %t54)
  store i1 %t57, ptr %l30
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb19
bb18:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i32, ptr %l35, !tbaa !23
  %t67 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t67, ptr %l36
  br label %bb20
bb20:
  %t68 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t69 = load i64, ptr %l36, !tbaa !24
  %t71 = and i64 %t69, %t68
  %t73 = icmp ne i64 %t71, 0
  store i1 %t73, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t75 = load i1, ptr %l31, !tbaa !21
  store i1 %t75, ptr %l19, !tbaa !21
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3eb640399bd8b02d_f3190a2cda9b9811)
  unreachable
bb27:
  %t76 = load i1, ptr %l19, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
bb28:
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l1, i64 176, i1 false)
  %t77 = load { i64, [21 x i64] }, ptr %l40
  %t78 = extractvalue { i64, [21 x i64] } %t77, 0
  %t79 = icmp eq i64 %t78, 9
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t81, i32 0, i32 1
  %t83 = load %"compiler/mir:Lvalue", ptr %t82
  store %"compiler/mir:Lvalue" %t83, ptr %l7
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t85 = load %"compiler/mir:Lvalue", ptr %l7
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t85, i32 %t86)
  store i1 %t89, ptr %l45
  br label %bb32
bb32:
  %t90 = load i1, ptr %l45, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a9954f8fd49ad07c_7121af0b4200b780)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %v0) #0 {
entry:
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/mir:BasicBlock"
  %t3 = alloca { i64, [8 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store { i64, [8 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [8 x i64] }, ptr %t3
  %t8 = insertvalue %"compiler/mir:BasicBlock" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, 0
  %t10 = insertvalue %"compiler/mir:BasicBlock" %t8, { i64, [8 x i64] } %t5, 1
  store %"compiler/mir:BasicBlock" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

define dso_local %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:Local" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:Local" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/mir:Local" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:Local" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/mir:Local" %t18, { i64, [1 x i64] } %a4, 4
  store %"compiler/mir:Local" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Local", ptr %rv
  ret %"compiler/mir:Local" %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Lvalue"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Lvalue" undef, { i64, [2 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/mir:Lvalue" %t6, %"compiler/mir:Range" %a1, 1
  store %"compiler/mir:Lvalue" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Range"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Range" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/mir:Range" %t6, i32 %a1, 1
  store %"compiler/mir:Range" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6, %"compiler/mir:Range" %a7) #0 {
entry:
  %rv = alloca %"compiler/mir:Task"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/mir:Task" undef, { i64, [7 x i64] } %a0, 0
  %t20 = insertvalue %"compiler/mir:Task" %t18, %"compiler/mir:Range" %a1, 1
  %t22 = insertvalue %"compiler/mir:Task" %t20, %"compiler/mir:Range" %a2, 2
  %t24 = insertvalue %"compiler/mir:Task" %t22, %"compiler/mir:Range" %a3, 3
  %t26 = insertvalue %"compiler/mir:Task" %t24, %"compiler/mir:Range" %a4, 4
  %t28 = insertvalue %"compiler/mir:Task" %t26, %"compiler/mir:Range" %a5, 5
  %t30 = insertvalue %"compiler/mir:Task" %t28, %"compiler/source:Span" %a6, 6
  %t32 = insertvalue %"compiler/mir:Task" %t30, %"compiler/mir:Range" %a7, 7
  store %"compiler/mir:Task" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Task", ptr %rv
  ret %"compiler/mir:Task" %rr
}

define dso_local %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/mir:dumper"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l7
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = insertvalue %"compiler/mir:dumper" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = insertvalue %"compiler/mir:dumper" %t8, ptr %t9, 1
  %t12 = insertvalue %"compiler/mir:dumper" %t10, %"std/prelude/text:StringBuilder" %t6, 2
  store %"compiler/mir:dumper" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:dumper", ptr %rv
  ret %"compiler/mir:dumper" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d7 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" err L" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d10 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch#" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" + " }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"live L" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"dead L" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"open S" }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"close S" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"register dtor " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"release " }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"settle L" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 8}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"copy " }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" from " }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d41 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"spawn in S" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raised" }>, align 8
@.d44 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" cleanup bb" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" runs" }>, align 8
@.d46 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"deferred at S" }>, align 8
@.d47 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"(no terminator)" }>, align 8
@.d48 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"goto bb" }>, align 8
@.d49 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"branch " }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d53 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"] else bb" }>, align 8
@.d54 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d59 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
@.d60 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
@.d61 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" holding " }>, align 8
@.d62 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" failed L" }>, align 8
@.d63 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"wait S" }>, align 8
@.d66 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 15}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
ret:
  ret void
}

@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"resume" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d72 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" made of " }>, align 8
@.d73 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"element " }>, align 8
@.d75 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no case " }>, align 8
@.d76 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" in a " }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d78 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" made of parts" }>, align 8
@.d79 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"a call of " }>, align 8
@.d80 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" arguments to a function of " }>, align 8
@.d81 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" parameters" }>, align 8
@.d82 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"argument " }>, align 8
@.d83 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a call passing " }>, align 8
@.d84 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" scopes for its callee's " }>, align 8
@.d85 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a call passing the frame for a scope variable" }>, align 8
@.d86 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn: " }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d88 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"[term]: " }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"]: " }>, align 8
@.d92 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"no block bb" }>, align 8
@.d93 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a text builder that is none" }>, align 8
@.d94 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a function value typed " }>, align 8
@.d95 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"constant " }>, align 8
@.d96 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" holds constant " }>, align 8
@.d97 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", not made before it" }>, align 8
@.d98 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"no local L" }>, align 8
@.d99 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d101 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array typed " }>, align 8
@.d102 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a run-time-length array" }>, align 8
@.d103 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a new array's length that is no integer" }>, align 8
@.d104 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array's fill" }>, align 8
@.d105 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"no constant " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 43}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
ret:
  ret void
}

@.d106 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"no overflow test for " }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d108 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" operands" }>, align 8
@.d109 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an overflow test of " }>, align 8
@.d110 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d111 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", not an integer" }>, align 8
@.d112 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d113 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"projections" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", but it is not open" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d119 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" while S" }>, align 8
@.d120 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", opened in it, is open" }>, align 8
declare void @__olang_ert_req_clear()
define linkonce_odr %"compiler/mir:BasicBlock" @olang_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

@.d121 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"unreachable: no path from the entry" }>, align 8
@.d122 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"no scope variable V" }>, align 8
@.d123 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a reference typed " }>, align 8
@.d124 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a reference " }>, align 8
@.d125 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d126 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the region of a " }>, align 8
@.d127 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error code" }>, align 8
@.d128 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d129 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d130 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no blocks" }>, align 8
@.d131 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"its type is no function type" }>, align 8
@.d132 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"its type has " }>, align 8
@.d133 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" parameters, its Params " }>, align 8
@.d134 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d135 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" is local L" }>, align 8
@.d136 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not a Param" }>, align 8
@.d137 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d138 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d139 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", its type says " }>, align 8
@.d140 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"capture L" }>, align 8
@.d141 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is no Capture local" }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d143 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" has the Unknown type" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d145 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"'s parent S" }>, align 8
@.d146 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" is not opened before it" }>, align 8
@.d147 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a task's copies are not one per target" }>, align 8
@.d148 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"targets" }>, align 8
@.d149 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"clauses" }>, align 8
@.d150 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"items" }>, align 8
@.d151 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"bytes" }>, align 8
@.d152 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"constant items" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d154 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d155 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d157 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d158 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d159 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no task " }>, align 8
@.d160 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the value stored" }>, align 8
@.d161 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d162 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", not a reference to a " }>, align 8
@.d163 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d164 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", which declares none" }>, align 8
@.d165 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a release of a " }>, align 8
@.d166 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a reference or an owner" }>, align 8
@.d167 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a settle of a " }>, align 8
@.d168 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", not an owner" }>, align 8
@.d169 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d170 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" write of a " }>, align 8
@.d171 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"elements copied between places that are not both arrays" }>, align 8
@.d172 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"elements copied between a " }>, align 8
@.d173 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d174 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a count of copied elements that is no integer" }>, align 8
@.d175 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a spawn into S" }>, align 8
@.d176 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d177 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a task with " }>, align 8
@.d178 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" targets for " }>, align 8
@.d179 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" results" }>, align 8
@.d180 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"a task's clauses for a call that cannot fail" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d181 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a task's result " }>, align 8
@.d182 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no terminator" }>, align 8
@.d183 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cases" }>, align 8
@.d184 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no call " }>, align 8
@.d185 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"scope refs" }>, align 8
@.d186 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a branch on a " }>, align 8
@.d187 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a switch on a " }>, align 8
@.d188 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a call with no result stores one" }>, align 8
@.d189 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the call's result" }>, align 8
@.d190 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a call that can fail with no error edge" }>, align 8
@.d191 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"an error edge for a call that cannot fail" }>, align 8
@.d192 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the call's error code" }>, align 8
@.d193 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a tail call with somewhere to go after it" }>, align 8
@.d194 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a tail call giving another result than the function's" }>, align 8
@.d195 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a return with no value from a function giving a " }>, align 8
@.d196 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"a return with a value from a function giving none" }>, align 8
@.d197 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"the value returned" }>, align 8
@.d198 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a suspend in a function that is no generator's" }>, align 8
@.d199 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the value yielded" }>, align 8
@.d200 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a raise in a function that cannot fail" }>, align 8
@.d201 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the error raised" }>, align 8
@.d202 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a wait for S" }>, align 8
@.d203 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d204 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a wait for a join that can fail with no failed edge" }>, align 8
@.d205 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a failed edge for a join that cannot fail" }>, align 8
@.d206 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the join's error code" }>, align 8
@.d207 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a message for a " }>, align 8
@.d208 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" exit" }>, align 8
@.d209 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an assert's message that is no text" }>, align 8
@.d210 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"text typed " }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d212 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" read before it is initialized on every path" }>, align 8
@.d213 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"a range of " }>, align 8
@.d214 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" out of bounds" }>, align 8
@.d215 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d216 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
@.d217 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d219 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d220 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"WriteKind.Bytes" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d221 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"WriteKind.Quoted" }>, align 8
@.d222 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"WriteKind.Char" }>, align 8
@.d223 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"WriteKind.QuotedChar" }>, align 8
@.d224 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"WriteKind.Int" }>, align 8
@.d225 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"WriteKind.Uint" }>, align 8
@.d226 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"WriteKind.Float" }>, align 8
@.d227 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"WriteKind.Bool" }>, align 8
@.d228 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Done" }>, align 8
@.d229 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Fail" }>, align 8
@.d230 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Abort" }>, align 8
@.d231 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.Unreachable" }>, align 8
@.d232 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.NullReached" }>, align 8
@.d233 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"ExitKind.NullError" }>, align 8
@.d234 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ExitKind.Assert" }>, align 8
@.d235 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.SliceBounds" }>, align 8
@.d236 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.ArrayLength" }>, align 8
@.d237 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ExitKind.As" }>, align 8
@.d238 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.FixedLength" }>, align 8
@.d239 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"ExitKind.LaneLength" }>, align 8
@.d240 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"ExitKind.GenRunning" }>, align 8
@.d241 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Error" }>, align 8
@.d242 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ExitKind.Escaped" }>, align 8
@.d243 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Neg" }>, align 8
@.d244 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitNot" }>, align 8
@.d245 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Not" }>, align 8
@.d246 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Add" }>, align 8
@.d247 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Sub" }>, align 8
@.d248 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Mul" }>, align 8
@.d249 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Div" }>, align 8
@.d250 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Rem" }>, align 8
@.d251 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shl" }>, align 8
@.d252 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Shr" }>, align 8
@.d253 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitAnd" }>, align 8
@.d254 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.BitOr" }>, align 8
@.d255 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.BitXor" }>, align 8
@.d256 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Eq" }>, align 8
@.d257 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ne" }>, align 8
@.d258 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Lt" }>, align 8
@.d259 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Le" }>, align 8
@.d260 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Gt" }>, align 8
@.d261 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"PrimOp.Ge" }>, align 8
@.d262 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"PrimOp.Same" }>, align 8
@.d263 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Convert" }>, align 8
@.d264 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Bitcast" }>, align 8
@.d265 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"PrimOp.Len" }>, align 8
@.d266 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.IsCase" }>, align 8
@.d267 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicLoad" }>, align 8
@.d268 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AtomicStore" }>, align 8
@.d269 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"PrimOp.AtomicAdd" }>, align 8
@.d270 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.AtomicSwap" }>, align 8
@.d271 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"PrimOp.AtomicCompareSwap" }>, align 8
@.d272 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"PrimOp.Retire" }>, align 8
@.d273 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.Destroy" }>, align 8
@.d274 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"PrimOp.LeadingZeros" }>, align 8
@.d275 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"PrimOp.TrailingZeros" }>, align 8
@.d276 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.PopCount" }>, align 8
@.d277 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"PrimOp.RotateLeft" }>, align 8
@.d278 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.RotateRight" }>, align 8
@.d279 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.ByteSwap" }>, align 8
@.d280 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.Holds" }>, align 8
@.d281 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.LaneLen" }>, align 8
@.d282 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"PrimOp.NonEmpty" }>, align 8
@.d283 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"PrimOp.AnyMake" }>, align 8
@.d284 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"PrimOp.AnyInstance" }>, align 8
@.d285 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"PrimOp.AnyIs" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f3abe41a98405543_7d26227a2bded35f = external constant [0 x i8]
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ePush_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, %"compiler/mir:ScopeInfo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ePush_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:BasicBlock" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_dca1ca4acf899191_a3a5645eac28d4dd = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1)
@olang_loc_63d4bc85d5a0ee63_941776bd89ba250f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b20d2ead933ce67_842549c98b36ec43 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c289c76542078e7_53d9d4aa9af07973 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_62f33ceaa6d0d243_a40627fd170062cf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f7be8aa76db69854_ffaa205b85e46cd8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
@olang_loc_293fa35c34966465_23dfef653c6d5c71 = external constant [0 x i8]
@olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9 = external constant [0 x i8]
@olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97 = external constant [0 x i8]
@olang_loc_70d66502dd431e07_8b33d36aabf56353 = external constant [0 x i8]
@olang_loc_2986d82de8391aaf_d61db5ce8081183b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprojected(ptr %v0, ptr %a0, i32 %a1, { i64, [1 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
@olang_loc_525ae97147cf6b9b_c46e40fbd793c77f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6 = external constant [0 x i8]
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7127dab5ce57c749_b077692428e4994d = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b = external constant [0 x i8]
@olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a = external constant [0 x i8]
@olang_loc_a5f83820f05cb9f9_5f257facca4b96a5 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
@olang_loc_6be72733009cb689_7eadbfb9b429b955 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3d9554dfcf1aeb63_1386be72809b2127 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
@olang_loc_729af306d1a375bd_3b9d78bce782a851 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
@olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
@olang_loc_145fd452f8e36c9b_ff9c6902187c9987 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22 = external constant [0 x i8]
@olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7 = external constant [0 x i8]
@olang_loc_4f65b4158cb36c84_7aab915b507980 = external constant [0 x i8]
@olang_loc_4fdb0c87eb50ced7_f9856407ece22343 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_91402ead91eecd74_d65ac3d6c8116e0 = external constant [0 x i8]
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %a0, i32 %a1)
@olang_loc_3eb640399bd8b02d_f3190a2cda9b9811 = external constant [0 x i8]
@olang_loc_a9954f8fd49ad07c_7121af0b4200b780 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
