; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [8 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:verifier" = type { ptr, ptr, %"std/prelude/text:StringBuilder", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:dumper" = type { ptr, ptr, %"std/prelude/text:StringBuilder" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
define dso_local i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t23 = trunc i64 24 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb10
bb9:
  %t36 = load i32, ptr %l19, !tbaa !23
  store i32 %t36, ptr %l16, !tbaa !23
  br label %bb11
bb10:
  %t37 = load i32, ptr %l22, !tbaa !23
  store i32 %t37, ptr %l16, !tbaa !23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l16, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2eDropsParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l71 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l17
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = load i32, ptr %l17, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l18
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb16
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  store i32 %t29, ptr %l5, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l30
  br label %bb7
bb7:
  %t36 = load i1, ptr %l30, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l35
  br label %bb10
bb9:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i1, ptr %l35, !tbaa !21
  store i1 %t44, ptr %l32, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l32, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb3
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l39, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l42
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = load i32, ptr %l42, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l43
  br label %bb18
bb18:
  %t60 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb20, label %bb21
bb20:
  br label %bb43
bb21:
  br label %bb22
bb22:
  %t73 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t73, ptr %l50, !tbaa !27
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i32, ptr %t77, i64 %t74
  %t79 = load i32, ptr %t78, !tbaa !33
  store i32 %t79, ptr %l9, !tbaa !23
  %t81 = load i32, ptr %l9, !tbaa !23
  %t83 = icmp eq i32 %t81, 0
  br i1 %t83, label %bb23, label %bb24
bb23:
  br label %bb42
bb24:
  br label %bb25
bb25:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l55, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l9, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l58
  br label %bb26
bb26:
  %t91 = load ptr, ptr %l55, !tbaa !29
  %t92 = load i32, ptr %l58, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t91, i32 %t92)
  store { i64, ptr } %t93, ptr %l59
  br label %bb27
bb27:
  %t94 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t94, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l66, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  store i32 %t113, ptr %l13, !tbaa !23
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l13, !tbaa !23
  %t119 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t115, i32 %t116)
  store i1 %t119, ptr %l71
  br label %bb32
bb32:
  %t120 = load i1, ptr %l71, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l13, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t123, i32 %t124)
  store i1 %t127, ptr %l76
  br label %bb35
bb34:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb36
bb35:
  %t128 = load i1, ptr %l76, !tbaa !21
  store i1 %t128, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb37, label %bb38
bb37:
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t131 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l11, !tbaa !24
  br label %bb28
bb41:
  br label %bb42
bb42:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb19
bb43:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i32, ptr %l10, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t23 = trunc i64 18 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb10
bb9:
  %t38 = load i32, ptr %l20, !tbaa !23
  store i32 %t38, ptr %l17, !tbaa !23
  br label %bb11
bb10:
  %t39 = load i32, ptr %l23, !tbaa !23
  store i32 %t39, ptr %l17, !tbaa !23
  br label %bb11
bb11:
  %t40 = load i32, ptr %l17, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i32
  %l13 = alloca i1
  %l16 = alloca i1
  %l24 = alloca i1
  %rv = alloca { i32, { i64, [2 x i64] } }
  %t12 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fmir_2eGuardOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = load i32, ptr %l5, !tbaa !23
  %t9 = icmp ne i32 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t15 = insertvalue { i32, i32 } undef, i32 7, 0
  %t17 = insertvalue { i32, i32 } %t15, i32 %t11, 1
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 1
  store { i32, i32 } %t17, ptr %t18
  %t19 = load { i64, [2 x i64] }, ptr %t12
  %t21 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t19, 1
  store { i32, { i64, [2 x i64] } } %t21, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2fmir_2eDropsParts(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l13, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t42 = insertvalue { i32 } undef, i32 %t37, 0
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  store { i32 } %t42, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t39
  %t46 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t44, 1
  store { i32, { i64, [2 x i64] } } %t46, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l24
  br label %bb12
bb12:
  %t52 = load i1, ptr %l24, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t56 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t56, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t57 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 0
  store i64 3, ptr %t59
  %t61 = insertvalue { i32, i32 } undef, i32 6, 0
  %t63 = insertvalue { i32, i32 } %t61, i32 %t57, 1
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  store { i32, i32 } %t63, ptr %t64
  %t65 = load { i64, [2 x i64] }, ptr %t58
  %t67 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t65, 1
  store { i32, { i64, [2 x i64] } } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

define dso_local void @compiler_2fmir_2eFn_2edefer(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Fn"
  %l13 = alloca ptr
  %l16 = alloca i32
  %l21 = alloca %"compiler/mir:Local"
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/mir:Lvalue"
  %l33 = alloca { i64, [21 x i64] }
  %l39 = alloca { i64, [21 x i64] }
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/mir:Lvalue"
  %l49 = alloca { i64, [21 x i64] }
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/mir:Lvalue"
  %l63 = alloca { i64, [21 x i64] }
  %l69 = alloca { i64, [21 x i64] }
  %l71 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/mir:Lvalue"
  %l79 = alloca { i64, [21 x i64] }
  %l84 = alloca { i64, [21 x i64] }
  %l91 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t11 = alloca %"compiler/mir:Fn", align 8
  %t26 = alloca { i64, [1 x i64] }, align 8
  %t50 = alloca { i64, [4 x i64] }, align 8
  %t57 = alloca { i64, [15 x i64] }, align 8
  %t63 = alloca { i64, [21 x i64] }, align 8
  %t80 = alloca { i64, [21 x i64] }, align 8
  %t99 = alloca { i64, [4 x i64] }, align 8
  %t106 = alloca { i64, [15 x i64] }, align 8
  %t112 = alloca { i64, [21 x i64] }, align 8
  %t128 = alloca { i64, [8 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  %t151 = alloca { i64, [15 x i64] }, align 8
  %t157 = alloca { i64, [21 x i64] }, align 8
  %t174 = alloca { i64, [21 x i64] }, align 8
  %t193 = alloca { i64, [4 x i64] }, align 8
  %t200 = alloca { i64, [15 x i64] }, align 8
  %t206 = alloca { i64, [21 x i64] }, align 8
  %t222 = alloca { i64, [21 x i64] }, align 8
  %t235 = alloca { i64, [4 x i64] }, align 8
  %t238 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i32, ptr %l7, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t6, i32 0, i32 %t7, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2eFn_2etfn(ptr %t11, ptr %v0, ptr %v1, ptr %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t11, i64 800, i1 false)
  br label %bb3
bb3:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t14, ptr %lp2
  %t15 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %l12, i64 800, i1 false)
  %t16 = load ptr, ptr %lp2
  store ptr %t16, ptr %l13, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr @__olang_prog_scope
  %t23 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t21, ptr %s0, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t23, ptr %l16
  br label %bb4
bb4:
  %t24 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t25 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 0
  store i64 3, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load i32, ptr %l16, !tbaa !23
  %t34 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t29, %"compiler/source:Span" %t24, i32 %t25, i32 2, { i64, [1 x i64] } %t28)
  store %"compiler/mir:Local" %t34, ptr %l21
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l13, !tbaa !29
  %t36 = load %"compiler/mir:Local", ptr %l21
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t35, %"compiler/mir:Local" %t36)
  store i32 %t37, ptr %l22
  br label %bb6
bb6:
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %l3, !tbaa !23
  store i32 0, ptr %l4, !tbaa !23
  %t39 = load ptr, ptr %lp2
  %t41 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t39)
  store i32 %t41, ptr %l24
  br label %bb7
bb7:
  %t42 = load i32, ptr %l24, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %lp2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  store i32 %t44, ptr %l26, !tbaa !23
  %t45 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t45, ptr %l27
  %t46 = load i32, ptr %l3, !tbaa !23
  %t48 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t46)
  store %"compiler/mir:Lvalue" %t48, ptr %l29
  br label %bb8
bb8:
  %t49 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 0
  store i64 2, ptr %t51
  %t53 = insertvalue { i32, i64 } undef, i32 %t49, 0
  %t54 = insertvalue { i32, i64 } %t53, i64 1, 1
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  store { i32, i64 } %t54, ptr %t55
  %t56 = load { i64, [4 x i64] }, ptr %t50
  store { i64, [15 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [15 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t60 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t56, 0
  %t61 = getelementptr { i64, [15 x i64] }, ptr %t57, i32 0, i32 1
  store { { i64, [4 x i64] } } %t60, ptr %t61
  %t62 = load { i64, [15 x i64] }, ptr %t57
  store { i64, [21 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [21 x i64] }, ptr %t63, i32 0, i32 0
  store i64 0, ptr %t64
  %t65 = load %"compiler/source:Span", ptr %l27
  %t66 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t65, 0
  %t67 = load %"compiler/mir:Lvalue", ptr %l29
  %t68 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t66, %"compiler/mir:Lvalue" %t67, 1
  %t70 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t68, { i64, [15 x i64] } %t62, 2
  %t71 = getelementptr { i64, [21 x i64] }, ptr %t63, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t70, ptr %t71
  %t72 = load { i64, [21 x i64] }, ptr %t63
  store { i64, [21 x i64] } %t72, ptr %l33
  %t73 = load ptr, ptr %l25, !tbaa !29
  %t74 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t73, i32 %t74, ptr %l33)
  br label %bb9
bb9:
  %t76 = load ptr, ptr %lp2
  %t77 = load i32, ptr %l4, !tbaa !23
  %t78 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t79 = load i32, ptr %l5, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [21 x i64] }, ptr %t80, i32 0, i32 0
  store i64 14, ptr %t81
  %t83 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t78, 0
  %t84 = insertvalue { %"compiler/source:Span", i32, i32 } %t83, i32 0, 1
  %t86 = insertvalue { %"compiler/source:Span", i32, i32 } %t84, i32 %t79, 2
  %t87 = getelementptr { i64, [21 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t86, ptr %t87
  %t88 = load { i64, [21 x i64] }, ptr %t80
  store { i64, [21 x i64] } %t88, ptr %l39
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t76, i32 %t77, ptr %l39)
  br label %bb10
bb10:
  %t92 = load ptr, ptr %lp2
  store ptr %t92, ptr %l41, !tbaa !29
  %t93 = load i32, ptr %l5, !tbaa !23
  store i32 %t93, ptr %l42, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t94, ptr %l43
  %t95 = load i32, ptr %l3, !tbaa !23
  %t97 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t95)
  store %"compiler/mir:Lvalue" %t97, ptr %l45
  br label %bb11
bb11:
  %t98 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 0
  store i64 2, ptr %t100
  %t102 = insertvalue { i32, i64 } undef, i32 %t98, 0
  %t103 = insertvalue { i32, i64 } %t102, i64 2, 1
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 1
  store { i32, i64 } %t103, ptr %t104
  %t105 = load { i64, [4 x i64] }, ptr %t99
  store { i64, [15 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [15 x i64] }, ptr %t106, i32 0, i32 0
  store i64 0, ptr %t107
  %t109 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t105, 0
  %t110 = getelementptr { i64, [15 x i64] }, ptr %t106, i32 0, i32 1
  store { { i64, [4 x i64] } } %t109, ptr %t110
  %t111 = load { i64, [15 x i64] }, ptr %t106
  store { i64, [21 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 0
  store i64 0, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l43
  %t115 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t114, 0
  %t116 = load %"compiler/mir:Lvalue", ptr %l45
  %t117 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t115, %"compiler/mir:Lvalue" %t116, 1
  %t119 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t117, { i64, [15 x i64] } %t111, 2
  %t120 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t119, ptr %t120
  %t121 = load { i64, [21 x i64] }, ptr %t112
  store { i64, [21 x i64] } %t121, ptr %l49
  %t122 = load ptr, ptr %l41, !tbaa !29
  %t123 = load i32, ptr %l42, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t122, i32 %t123, ptr %l49)
  br label %bb12
bb12:
  %t125 = load ptr, ptr %lp2
  %t126 = load i32, ptr %l5, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [8 x i64] }, ptr %t128, i32 0, i32 0
  store i64 10, ptr %t129
  %t131 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t127, 0
  %t132 = getelementptr { i64, [8 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span" } %t131, ptr %t132
  %t133 = load { i64, [8 x i64] }, ptr %t128
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t125, i32 %t126, { i64, [8 x i64] } %t133)
  br label %bb13
bb13:
  %t137 = load ptr, ptr %lp2
  store ptr %t137, ptr %l55, !tbaa !29
  %t138 = load i32, ptr %l4, !tbaa !23
  store i32 %t138, ptr %l56, !tbaa !23
  %t139 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t139, ptr %l57
  %t140 = load i32, ptr %l3, !tbaa !23
  %t142 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t140)
  store %"compiler/mir:Lvalue" %t142, ptr %l59
  br label %bb14
bb14:
  %t143 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 2, ptr %t145
  %t147 = insertvalue { i32, i64 } undef, i32 %t143, 0
  %t148 = insertvalue { i32, i64 } %t147, i64 3, 1
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { i32, i64 } %t148, ptr %t149
  %t150 = load { i64, [4 x i64] }, ptr %t144
  store { i64, [15 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [15 x i64] }, ptr %t151, i32 0, i32 0
  store i64 0, ptr %t152
  %t154 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t150, 0
  %t155 = getelementptr { i64, [15 x i64] }, ptr %t151, i32 0, i32 1
  store { { i64, [4 x i64] } } %t154, ptr %t155
  %t156 = load { i64, [15 x i64] }, ptr %t151
  store { i64, [21 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [21 x i64] }, ptr %t157, i32 0, i32 0
  store i64 0, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l57
  %t160 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t159, 0
  %t161 = load %"compiler/mir:Lvalue", ptr %l59
  %t162 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t160, %"compiler/mir:Lvalue" %t161, 1
  %t164 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t162, { i64, [15 x i64] } %t156, 2
  %t165 = getelementptr { i64, [21 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t164, ptr %t165
  %t166 = load { i64, [21 x i64] }, ptr %t157
  store { i64, [21 x i64] } %t166, ptr %l63
  %t167 = load ptr, ptr %l55, !tbaa !29
  %t168 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t167, i32 %t168, ptr %l63)
  br label %bb15
bb15:
  %t170 = load ptr, ptr %lp2
  %t171 = load i32, ptr %l4, !tbaa !23
  %t172 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t173 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [21 x i64] }, ptr %t174, i32 0, i32 0
  store i64 14, ptr %t175
  %t177 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t172, 0
  %t178 = insertvalue { %"compiler/source:Span", i32, i32 } %t177, i32 0, 1
  %t180 = insertvalue { %"compiler/source:Span", i32, i32 } %t178, i32 %t173, 2
  %t181 = getelementptr { i64, [21 x i64] }, ptr %t174, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t180, ptr %t181
  %t182 = load { i64, [21 x i64] }, ptr %t174
  store { i64, [21 x i64] } %t182, ptr %l69
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t170, i32 %t171, ptr %l69)
  br label %bb16
bb16:
  %t186 = load ptr, ptr %lp2
  store ptr %t186, ptr %l71, !tbaa !29
  %t187 = load i32, ptr %l4, !tbaa !23
  store i32 %t187, ptr %l72, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t188, ptr %l73
  %t189 = load i32, ptr %l3, !tbaa !23
  %t191 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t189)
  store %"compiler/mir:Lvalue" %t191, ptr %l75
  br label %bb17
bb17:
  %t192 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 0
  store i64 2, ptr %t194
  %t196 = insertvalue { i32, i64 } undef, i32 %t192, 0
  %t197 = insertvalue { i32, i64 } %t196, i64 2, 1
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  store { i32, i64 } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t193
  store { i64, [15 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [15 x i64] }, ptr %t200, i32 0, i32 0
  store i64 0, ptr %t201
  %t203 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t199, 0
  %t204 = getelementptr { i64, [15 x i64] }, ptr %t200, i32 0, i32 1
  store { { i64, [4 x i64] } } %t203, ptr %t204
  %t205 = load { i64, [15 x i64] }, ptr %t200
  store { i64, [21 x i64] } zeroinitializer, ptr %t206
  %t207 = getelementptr { i64, [21 x i64] }, ptr %t206, i32 0, i32 0
  store i64 0, ptr %t207
  %t208 = load %"compiler/source:Span", ptr %l73
  %t209 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t208, 0
  %t210 = load %"compiler/mir:Lvalue", ptr %l75
  %t211 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t209, %"compiler/mir:Lvalue" %t210, 1
  %t213 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t211, { i64, [15 x i64] } %t205, 2
  %t214 = getelementptr { i64, [21 x i64] }, ptr %t206, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t213, ptr %t214
  %t215 = load { i64, [21 x i64] }, ptr %t206
  store { i64, [21 x i64] } %t215, ptr %l79
  %t216 = load ptr, ptr %l71, !tbaa !29
  %t217 = load i32, ptr %l72, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t216, i32 %t217, ptr %l79)
  br label %bb18
bb18:
  %t219 = load ptr, ptr %lp2
  %t220 = load i32, ptr %l4, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [21 x i64] }, ptr %t222, i32 0, i32 0
  store i64 4, ptr %t223
  %t225 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t221, 0
  %t226 = insertvalue { %"compiler/source:Span", i32 } %t225, i32 0, 1
  %t227 = getelementptr { i64, [21 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t226, ptr %t227
  %t228 = load { i64, [21 x i64] }, ptr %t222
  store { i64, [21 x i64] } %t228, ptr %l84
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t219, i32 %t220, ptr %l84)
  br label %bb19
bb19:
  %t232 = load ptr, ptr %lp2
  %t233 = load i32, ptr %l4, !tbaa !23
  %t234 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [4 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load { i64, [4 x i64] }, ptr %t235
  store { i64, [8 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [8 x i64] }, ptr %t238, i32 0, i32 0
  store i64 5, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t234, 0
  %t243 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t241, { i64, [4 x i64] } %t237, 1
  %t244 = getelementptr { i64, [8 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t243, ptr %t244
  %t245 = load { i64, [8 x i64] }, ptr %t238
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t232, i32 %t233, { i64, [8 x i64] } %t245)
  br label %bb20
bb20:
  %t249 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l91, ptr %t249, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l91, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eFn_2eloop(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca %"compiler/mir:Fn"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l42 = alloca i32
  %l47 = alloca %"compiler/mir:Local"
  %l48 = alloca i32
  %l52 = alloca i32
  %l56 = alloca i32
  %l60 = alloca i32
  %l64 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/mir:Lvalue"
  %l86 = alloca { i64, [21 x i64] }
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/mir:Lvalue"
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca ptr
  %l100 = alloca %"compiler/mir:Lvalue"
  %l101 = alloca { i64, [4 x i64] }
  %l103 = alloca %"compiler/mir:Lvalue"
  %l105 = alloca { i64, ptr }
  %l106 = alloca %"compiler/mir:Range"
  %l108 = alloca { i64, [21 x i64] }
  %l110 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca %"compiler/mir:Lvalue"
  %l122 = alloca { i64, [21 x i64] }
  %l124 = alloca ptr
  %l127 = alloca { i64, [7 x i64] }
  %l128 = alloca ptr
  %l130 = alloca %"compiler/mir:Lvalue"
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/mir:Range"
  %l134 = alloca %"compiler/mir:Range"
  %l136 = alloca %"compiler/mir:Lvalue"
  %l140 = alloca %"compiler/mir:Call"
  %l141 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca %"compiler/source:Span"
  %l151 = alloca %"compiler/mir:Lvalue"
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca ptr
  %l156 = alloca %"compiler/mir:Lvalue"
  %l160 = alloca { i64, ptr }
  %l161 = alloca %"compiler/mir:Range"
  %l163 = alloca { i64, [21 x i64] }
  %l169 = alloca { i64, [21 x i64] }
  %l178 = alloca { i64, [21 x i64] }
  %l180 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/mir:Lvalue"
  %l187 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/mir:Lvalue"
  %l193 = alloca %"compiler/mir:Lvalue"
  %l198 = alloca { i64, [21 x i64] }
  %l204 = alloca { i64, [21 x i64] }
  %l209 = alloca { i64, [21 x i64] }
  %l211 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l215 = alloca %"compiler/mir:Lvalue"
  %l218 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t25 = alloca %"compiler/mir:Fn", align 8
  %t54 = alloca { i64, [1 x i64] }, align 8
  %t132 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [15 x i64] }, align 8
  %t145 = alloca { i64, [21 x i64] }, align 8
  %t159 = alloca { i64, [8 x i64] }, align 8
  %t178 = alloca { i64, [4 x i64] }, align 8
  %t187 = alloca { i64, [4 x i64] }, align 8
  %t208 = alloca { i64, [15 x i64] }, align 8
  %t218 = alloca { i64, [21 x i64] }, align 8
  %t236 = alloca { i64, [4 x i64] }, align 8
  %t244 = alloca { i64, [8 x i64] }, align 8
  %t261 = alloca { i64, [21 x i64] }, align 8
  %t273 = alloca { i64, [2 x i64] }, align 8
  %t279 = alloca { i64, [7 x i64] }, align 8
  %t291 = alloca { i64, [4 x i64] }, align 8
  %t331 = alloca { i64, [8 x i64] }, align 8
  %t353 = alloca { i64, [4 x i64] }, align 8
  %t360 = alloca { i64, [4 x i64] }, align 8
  %t382 = alloca { i64, [15 x i64] }, align 8
  %t392 = alloca { i64, [21 x i64] }, align 8
  %t409 = alloca { i64, [21 x i64] }, align 8
  %t423 = alloca { i64, [8 x i64] }, align 8
  %t435 = alloca { i64, [21 x i64] }, align 8
  %t451 = alloca { i64, [4 x i64] }, align 8
  %t457 = alloca { i64, [8 x i64] }, align 8
  %t477 = alloca { i64, [4 x i64] }, align 8
  %t485 = alloca { i64, [15 x i64] }, align 8
  %t495 = alloca { i64, [21 x i64] }, align 8
  %t512 = alloca { i64, [21 x i64] }, align 8
  %t526 = alloca { i64, [21 x i64] }, align 8
  %t542 = alloca { i64, [4 x i64] }, align 8
  %t548 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load i32, ptr %l19, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i32, ptr %l22, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l23, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l24, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l27
  br label %bb3
bb3:
  %t18 = load i32, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t20, i32 %t21, i32 %t18, i32 %t19, i32 0, i64 0, i1 false, i32 0)
  store i32 %t24, ptr %l30
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2fmir_2eFn_2etfn(ptr %t25, ptr %v0, ptr %v1, ptr %t26, i32 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t25, i64 800, i1 false)
  br label %bb5
bb5:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t28, ptr %lp3
  %t29 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l31, i64 800, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l32, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l35
  br label %bb6
bb6:
  %t36 = load i32, ptr %l1, !tbaa !23
  %t37 = load i32, ptr %l2, !tbaa !23
  %t38 = load ptr, ptr %l32, !tbaa !29
  %t39 = load i32, ptr %l35, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t38, i32 %t39, i32 %t36, i32 %t37, i32 0, i64 0, i1 false, i32 0)
  store i32 %t42, ptr %l38
  br label %bb7
bb7:
  %t43 = load i32, ptr %l38, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  store i32 0, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp3
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load ptr, ptr @__olang_prog_scope
  %t51 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t49, ptr %s0, ptr %t48, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t51, ptr %l42
  br label %bb8
bb8:
  %t52 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t53 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t54
  %t57 = load i32, ptr %l42, !tbaa !23
  %t62 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 %t57, %"compiler/source:Span" %t52, i32 %t53, i32 2, { i64, [1 x i64] } %t56)
  store %"compiler/mir:Local" %t62, ptr %l47
  br label %bb9
bb9:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load %"compiler/mir:Local", ptr %l47
  %t65 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v1, ptr %t63, %"compiler/mir:Local" %t64)
  store i32 %t65, ptr %l48
  br label %bb10
bb10:
  %t66 = load i32, ptr %l48, !tbaa !23
  store i32 %t66, ptr %l6, !tbaa !23
  %t67 = load ptr, ptr %lp3
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t69 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t73 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t67, i32 %t68, %"compiler/source:Span" %t69)
  store i32 %t73, ptr %l52
  br label %bb11
bb11:
  %t74 = load i32, ptr %l52, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  %t75 = load ptr, ptr %lp3
  %t76 = load i32, ptr %l1, !tbaa !23
  %t77 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t81 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t75, i32 %t76, %"compiler/source:Span" %t77)
  store i32 %t81, ptr %l56
  br label %bb12
bb12:
  %t82 = load i32, ptr %l56, !tbaa !23
  store i32 %t82, ptr %l8, !tbaa !23
  %t83 = load ptr, ptr %lp3
  %t84 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t85 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t89 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t83, i32 %t84, %"compiler/source:Span" %t85)
  store i32 %t89, ptr %l60
  br label %bb13
bb13:
  %t90 = load i32, ptr %l60, !tbaa !23
  store i32 %t90, ptr %l9, !tbaa !23
  %t91 = load ptr, ptr %lp3
  %t92 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t93 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t97 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t91, i32 %t92, %"compiler/source:Span" %t93)
  store i32 %t97, ptr %l64
  br label %bb14
bb14:
  %t98 = load i32, ptr %l64, !tbaa !23
  store i32 %t98, ptr %l10, !tbaa !23
  %t99 = load ptr, ptr %lp3
  %t100 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t104 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t99, i32 2, i32 0, i32 1, %"compiler/source:Span" %t100, i32 0)
  store i32 %t104, ptr %l68
  br label %bb15
bb15:
  %t105 = load i32, ptr %l68, !tbaa !23
  store i32 %t105, ptr %l11, !tbaa !23
  %t106 = load ptr, ptr %lp3
  %t108 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t106)
  store i32 %t108, ptr %l70
  br label %bb16
bb16:
  %t109 = load i32, ptr %l70, !tbaa !23
  store i32 %t109, ptr %l12, !tbaa !23
  %t110 = load ptr, ptr %lp3
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l72
  br label %bb17
bb17:
  %t113 = load i32, ptr %l72, !tbaa !23
  store i32 %t113, ptr %l13, !tbaa !23
  %t114 = load ptr, ptr %lp3
  %t116 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t114)
  store i32 %t116, ptr %l74
  br label %bb18
bb18:
  %t117 = load i32, ptr %l74, !tbaa !23
  store i32 %t117, ptr %l14, !tbaa !23
  %t118 = load ptr, ptr %lp3
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t118)
  store i32 %t120, ptr %l76
  br label %bb19
bb19:
  %t121 = load i32, ptr %l76, !tbaa !23
  store i32 %t121, ptr %l15, !tbaa !23
  %t122 = load ptr, ptr %lp3
  %t124 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t122)
  store i32 %t124, ptr %l78
  br label %bb20
bb20:
  %t125 = load i32, ptr %l78, !tbaa !23
  store i32 %t125, ptr %l16, !tbaa !23
  %t126 = load ptr, ptr %lp3
  store ptr %t126, ptr %l79, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t127, ptr %l80
  %t128 = load i32, ptr %l6, !tbaa !23
  %t130 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t128)
  store %"compiler/mir:Lvalue" %t130, ptr %l82
  br label %bb21
bb21:
  %t131 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 0
  store i64 2, ptr %t133
  %t135 = insertvalue { i32, i64 } undef, i32 %t131, 0
  %t136 = insertvalue { i32, i64 } %t135, i64 0, 1
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  store { i32, i64 } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t132
  store { i64, [15 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t138, 0
  %t143 = getelementptr { i64, [15 x i64] }, ptr %t139, i32 0, i32 1
  store { { i64, [4 x i64] } } %t142, ptr %t143
  %t144 = load { i64, [15 x i64] }, ptr %t139
  store { i64, [21 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [21 x i64] }, ptr %t145, i32 0, i32 0
  store i64 0, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l80
  %t148 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t147, 0
  %t149 = load %"compiler/mir:Lvalue", ptr %l82
  %t150 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t148, %"compiler/mir:Lvalue" %t149, 1
  %t152 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t150, { i64, [15 x i64] } %t144, 2
  %t153 = getelementptr { i64, [21 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t152, ptr %t153
  %t154 = load { i64, [21 x i64] }, ptr %t145
  store { i64, [21 x i64] } %t154, ptr %l86
  %t155 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t155, i32 0, ptr %l86)
  br label %bb22
bb22:
  %t157 = load ptr, ptr %lp3
  %t158 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [8 x i64] }, ptr %t159, i32 0, i32 0
  store i64 1, ptr %t160
  %t162 = insertvalue { i32 } undef, i32 %t158, 0
  %t163 = getelementptr { i64, [8 x i64] }, ptr %t159, i32 0, i32 1
  store { i32 } %t162, ptr %t163
  %t164 = load { i64, [8 x i64] }, ptr %t159
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t157, i32 0, { i64, [8 x i64] } %t164)
  br label %bb23
bb23:
  %t167 = load ptr, ptr %lp3
  store ptr %t167, ptr %l91, !tbaa !29
  %t168 = load i32, ptr %l12, !tbaa !23
  store i32 %t168, ptr %l92, !tbaa !23
  %t169 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t169, ptr %l93
  %t170 = load i32, ptr %l7, !tbaa !23
  %t172 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t170)
  store %"compiler/mir:Lvalue" %t172, ptr %l95
  br label %bb24
bb24:
  store i32 15, ptr %l96
  %t173 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t173, ptr %l97, !tbaa !23
  %t174 = load ptr, ptr %lp3
  store ptr %t174, ptr %l98, !tbaa !29
  %t175 = load i32, ptr %l6, !tbaa !23
  %t177 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t175)
  store %"compiler/mir:Lvalue" %t177, ptr %l100
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 1, ptr %t179
  %t180 = load %"compiler/mir:Lvalue", ptr %l100
  %t181 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t180, 0
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t181, ptr %t182
  %t183 = load { i64, [4 x i64] }, ptr %t178
  store { i64, [4 x i64] } %t183, ptr %l101
  %t184 = load i32, ptr %l5, !tbaa !23
  %t186 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t184)
  store %"compiler/mir:Lvalue" %t186, ptr %l103
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 0
  store i64 1, ptr %t188
  %t189 = load %"compiler/mir:Lvalue", ptr %l103
  %t190 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t189, 0
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t190, ptr %t191
  %t192 = load { i64, [4 x i64] }, ptr %t187
  %t193 = mul i64 2, 40
  %t194 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 2, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l105, !tbaa !27
  %t197 = load { i64, [4 x i64] }, ptr %l101
  %t198 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t199, i64 0
  store { i64, [4 x i64] } %t197, ptr %t200
  %t202 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t203, i64 1
  store { i64, [4 x i64] } %t192, ptr %t204
  %t205 = load ptr, ptr %l98, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t207 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t205, { i64, ptr } %t206)
  store %"compiler/mir:Range" %t207, ptr %l106
  br label %bb27
bb27:
  store { i64, [15 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [15 x i64] }, ptr %t208, i32 0, i32 0
  store i64 3, ptr %t209
  %t210 = load i32, ptr %l96, !range !{i32 0, i32 49}
  %t211 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t210, 0
  %t212 = load i32, ptr %l97, !tbaa !23
  %t213 = insertvalue { i32, i32, %"compiler/mir:Range" } %t211, i32 %t212, 1
  %t214 = load %"compiler/mir:Range", ptr %l106
  %t215 = insertvalue { i32, i32, %"compiler/mir:Range" } %t213, %"compiler/mir:Range" %t214, 2
  %t216 = getelementptr { i64, [15 x i64] }, ptr %t208, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t215, ptr %t216
  %t217 = load { i64, [15 x i64] }, ptr %t208
  store { i64, [21 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [21 x i64] }, ptr %t218, i32 0, i32 0
  store i64 0, ptr %t219
  %t220 = load %"compiler/source:Span", ptr %l93
  %t221 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t220, 0
  %t222 = load %"compiler/mir:Lvalue", ptr %l95
  %t223 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t221, %"compiler/mir:Lvalue" %t222, 1
  %t225 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t223, { i64, [15 x i64] } %t217, 2
  %t226 = getelementptr { i64, [21 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t225, ptr %t226
  %t227 = load { i64, [21 x i64] }, ptr %t218
  store { i64, [21 x i64] } %t227, ptr %l108
  %t228 = load ptr, ptr %l91, !tbaa !29
  %t229 = load i32, ptr %l92, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t228, i32 %t229, ptr %l108)
  br label %bb28
bb28:
  %t231 = load ptr, ptr %lp3
  store ptr %t231, ptr %l110, !tbaa !29
  %t232 = load i32, ptr %l12, !tbaa !23
  store i32 %t232, ptr %l111, !tbaa !23
  %t233 = load i32, ptr %l7, !tbaa !23
  %t235 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t233)
  store %"compiler/mir:Lvalue" %t235, ptr %l113
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 0
  store i64 1, ptr %t237
  %t238 = load %"compiler/mir:Lvalue", ptr %l113
  %t239 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t238, 0
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t236, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t239, ptr %t240
  %t241 = load { i64, [4 x i64] }, ptr %t236
  %t242 = load i32, ptr %l13, !tbaa !23
  %t243 = load i32, ptr %l15, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t244
  %t245 = getelementptr { i64, [8 x i64] }, ptr %t244, i32 0, i32 0
  store i64 2, ptr %t245
  %t247 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t241, 0
  %t249 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t247, i32 %t242, 1
  %t251 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t249, i32 %t243, 2
  %t252 = getelementptr { i64, [8 x i64] }, ptr %t244, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t251, ptr %t252
  %t253 = load { i64, [8 x i64] }, ptr %t244
  %t254 = load ptr, ptr %l110, !tbaa !29
  %t255 = load i32, ptr %l111, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t254, i32 %t255, { i64, [8 x i64] } %t253)
  br label %bb30
bb30:
  %t257 = load ptr, ptr %lp3
  %t258 = load i32, ptr %l13, !tbaa !23
  %t259 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t260 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [21 x i64] }, ptr %t261, i32 0, i32 0
  store i64 3, ptr %t262
  %t264 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t259, 0
  %t266 = insertvalue { %"compiler/source:Span", i32 } %t264, i32 %t260, 1
  %t267 = getelementptr { i64, [21 x i64] }, ptr %t261, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t266, ptr %t267
  %t268 = load { i64, [21 x i64] }, ptr %t261
  store { i64, [21 x i64] } %t268, ptr %l122
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t257, i32 %t258, ptr %l122)
  br label %bb31
bb31:
  %t272 = load ptr, ptr %lp3
  store ptr %t272, ptr %l124, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [2 x i64] }, ptr %t273, i32 0, i32 0
  store i64 0, ptr %t274
  %t275 = insertvalue { i32 } undef, i32 1, 0
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t273, i32 0, i32 1
  store { i32 } %t275, ptr %t276
  %t277 = load { i64, [2 x i64] }, ptr %t273
  %t278 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [7 x i64] }, ptr %t279, i32 0, i32 0
  store i64 0, ptr %t280
  %t282 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t277, 0
  %t284 = insertvalue { { i64, [2 x i64] }, i32 } %t282, i32 %t278, 1
  %t285 = getelementptr { i64, [7 x i64] }, ptr %t279, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t284, ptr %t285
  %t286 = load { i64, [7 x i64] }, ptr %t279
  store { i64, [7 x i64] } %t286, ptr %l127
  %t287 = load ptr, ptr %lp3
  store ptr %t287, ptr %l128, !tbaa !29
  %t288 = load i32, ptr %l6, !tbaa !23
  %t290 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t288)
  store %"compiler/mir:Lvalue" %t290, ptr %l130
  br label %bb32
bb32:
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 1, ptr %t292
  %t293 = load %"compiler/mir:Lvalue", ptr %l130
  %t294 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t293, 0
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t291
  %t297 = mul i64 1, 40
  %t298 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 1, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l132, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t303, i64 0
  store { i64, [4 x i64] } %t296, ptr %t304
  %t305 = load ptr, ptr %l128, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t307 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t305, { i64, ptr } %t306)
  store %"compiler/mir:Range" %t307, ptr %l133
  br label %bb33
bb33:
  %t308 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t308, ptr %l134
  %t309 = load i32, ptr %l8, !tbaa !23
  %t311 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t309)
  store %"compiler/mir:Lvalue" %t311, ptr %l136
  br label %bb34
bb34:
  %t312 = load i32, ptr %l14, !tbaa !23
  %t313 = load i32, ptr %l9, !tbaa !23
  %t314 = load i32, ptr %l16, !tbaa !23
  %t315 = load { i64, [7 x i64] }, ptr %l127
  %t316 = load %"compiler/mir:Range", ptr %l133
  %t317 = load %"compiler/mir:Range", ptr %l134
  %t318 = load %"compiler/mir:Lvalue", ptr %l136
  %t322 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t315, %"compiler/mir:Range" %t316, %"compiler/mir:Range" %t317, %"compiler/mir:Lvalue" %t318, i1 true, i32 %t312, i32 %t313, i32 %t314)
  store %"compiler/mir:Call" %t322, ptr %l140
  br label %bb35
bb35:
  %t323 = load ptr, ptr %l124, !tbaa !29
  %t324 = load %"compiler/mir:Call", ptr %l140
  %t325 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t323, %"compiler/mir:Call" %t324)
  store i32 %t325, ptr %l141
  br label %bb36
bb36:
  %t326 = load i32, ptr %l141, !tbaa !23
  %t327 = load ptr, ptr %lp3
  %t328 = load i32, ptr %l13, !tbaa !23
  %t329 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t331
  %t332 = getelementptr { i64, [8 x i64] }, ptr %t331, i32 0, i32 0
  store i64 4, ptr %t332
  %t334 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t329, 0
  %t336 = insertvalue { %"compiler/source:Span", i32 } %t334, i32 %t326, 1
  %t337 = getelementptr { i64, [8 x i64] }, ptr %t331, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t336, ptr %t337
  %t338 = load { i64, [8 x i64] }, ptr %t331
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t327, i32 %t328, { i64, [8 x i64] } %t338)
  br label %bb37
bb37:
  %t342 = load ptr, ptr %lp3
  store ptr %t342, ptr %l147, !tbaa !29
  %t343 = load i32, ptr %l14, !tbaa !23
  store i32 %t343, ptr %l148, !tbaa !23
  %t344 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t344, ptr %l149
  %t345 = load i32, ptr %l6, !tbaa !23
  %t347 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t345)
  store %"compiler/mir:Lvalue" %t347, ptr %l151
  br label %bb38
bb38:
  store i32 3, ptr %l152
  %t348 = load i32, ptr %l1, !tbaa !23
  store i32 %t348, ptr %l153, !tbaa !23
  %t349 = load ptr, ptr %lp3
  store ptr %t349, ptr %l154, !tbaa !29
  %t350 = load i32, ptr %l6, !tbaa !23
  %t352 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t350)
  store %"compiler/mir:Lvalue" %t352, ptr %l156
  br label %bb39
bb39:
  store { i64, [4 x i64] } zeroinitializer, ptr %t353
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 0
  store i64 1, ptr %t354
  %t355 = load %"compiler/mir:Lvalue", ptr %l156
  %t356 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t355, 0
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t356, ptr %t357
  %t358 = load { i64, [4 x i64] }, ptr %t353
  %t359 = load i32, ptr %l1, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t360
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 0
  store i64 2, ptr %t361
  %t363 = insertvalue { i32, i64 } undef, i32 %t359, 0
  %t364 = insertvalue { i32, i64 } %t363, i64 1, 1
  %t365 = getelementptr { i64, [4 x i64] }, ptr %t360, i32 0, i32 1
  store { i32, i64 } %t364, ptr %t365
  %t366 = load { i64, [4 x i64] }, ptr %t360
  %t367 = mul i64 2, 40
  %t368 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t367)
  %t369 = insertvalue { i64, ptr } undef, i64 2, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l160, !tbaa !27
  %t372 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr { i64, [4 x i64] }, ptr %t373, i64 0
  store { i64, [4 x i64] } %t358, ptr %t374
  %t376 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t377, i64 1
  store { i64, [4 x i64] } %t366, ptr %t378
  %t379 = load ptr, ptr %l154, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t381 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t379, { i64, ptr } %t380)
  store %"compiler/mir:Range" %t381, ptr %l161
  br label %bb40
bb40:
  store { i64, [15 x i64] } zeroinitializer, ptr %t382
  %t383 = getelementptr { i64, [15 x i64] }, ptr %t382, i32 0, i32 0
  store i64 3, ptr %t383
  %t384 = load i32, ptr %l152, !range !{i32 0, i32 49}
  %t385 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t384, 0
  %t386 = load i32, ptr %l153, !tbaa !23
  %t387 = insertvalue { i32, i32, %"compiler/mir:Range" } %t385, i32 %t386, 1
  %t388 = load %"compiler/mir:Range", ptr %l161
  %t389 = insertvalue { i32, i32, %"compiler/mir:Range" } %t387, %"compiler/mir:Range" %t388, 2
  %t390 = getelementptr { i64, [15 x i64] }, ptr %t382, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t389, ptr %t390
  %t391 = load { i64, [15 x i64] }, ptr %t382
  store { i64, [21 x i64] } zeroinitializer, ptr %t392
  %t393 = getelementptr { i64, [21 x i64] }, ptr %t392, i32 0, i32 0
  store i64 0, ptr %t393
  %t394 = load %"compiler/source:Span", ptr %l149
  %t395 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t394, 0
  %t396 = load %"compiler/mir:Lvalue", ptr %l151
  %t397 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t395, %"compiler/mir:Lvalue" %t396, 1
  %t399 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t397, { i64, [15 x i64] } %t391, 2
  %t400 = getelementptr { i64, [21 x i64] }, ptr %t392, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t399, ptr %t400
  %t401 = load { i64, [21 x i64] }, ptr %t392
  store { i64, [21 x i64] } %t401, ptr %l163
  %t402 = load ptr, ptr %l147, !tbaa !29
  %t403 = load i32, ptr %l148, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t402, i32 %t403, ptr %l163)
  br label %bb41
bb41:
  %t405 = load ptr, ptr %lp3
  %t406 = load i32, ptr %l14, !tbaa !23
  %t407 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t408 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t409
  %t410 = getelementptr { i64, [21 x i64] }, ptr %t409, i32 0, i32 0
  store i64 4, ptr %t410
  %t412 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t407, 0
  %t414 = insertvalue { %"compiler/source:Span", i32 } %t412, i32 %t408, 1
  %t415 = getelementptr { i64, [21 x i64] }, ptr %t409, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t414, ptr %t415
  %t416 = load { i64, [21 x i64] }, ptr %t409
  store { i64, [21 x i64] } %t416, ptr %l169
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t405, i32 %t406, ptr %l169)
  br label %bb42
bb42:
  %t420 = load ptr, ptr %lp3
  %t421 = load i32, ptr %l14, !tbaa !23
  %t422 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t423
  %t424 = getelementptr { i64, [8 x i64] }, ptr %t423, i32 0, i32 0
  store i64 1, ptr %t424
  %t426 = insertvalue { i32 } undef, i32 %t422, 0
  %t427 = getelementptr { i64, [8 x i64] }, ptr %t423, i32 0, i32 1
  store { i32 } %t426, ptr %t427
  %t428 = load { i64, [8 x i64] }, ptr %t423
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t420, i32 %t421, { i64, [8 x i64] } %t428)
  br label %bb43
bb43:
  %t432 = load ptr, ptr %lp3
  %t433 = load i32, ptr %l15, !tbaa !23
  %t434 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t435
  %t436 = getelementptr { i64, [21 x i64] }, ptr %t435, i32 0, i32 0
  store i64 4, ptr %t436
  %t438 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t434, 0
  %t439 = insertvalue { %"compiler/source:Span", i32 } %t438, i32 0, 1
  %t440 = getelementptr { i64, [21 x i64] }, ptr %t435, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t439, ptr %t440
  %t441 = load { i64, [21 x i64] }, ptr %t435
  store { i64, [21 x i64] } %t441, ptr %l178
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t432, i32 %t433, ptr %l178)
  br label %bb44
bb44:
  %t445 = load ptr, ptr %lp3
  store ptr %t445, ptr %l180, !tbaa !29
  %t446 = load i32, ptr %l15, !tbaa !23
  store i32 %t446, ptr %l181, !tbaa !23
  %t447 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t447, ptr %l182
  %t448 = load i32, ptr %l6, !tbaa !23
  %t450 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t448)
  store %"compiler/mir:Lvalue" %t450, ptr %l184
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t451
  %t452 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 0
  store i64 1, ptr %t452
  %t453 = load %"compiler/mir:Lvalue", ptr %l184
  %t454 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t453, 0
  %t455 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t454, ptr %t455
  %t456 = load { i64, [4 x i64] }, ptr %t451
  store { i64, [8 x i64] } zeroinitializer, ptr %t457
  %t458 = getelementptr { i64, [8 x i64] }, ptr %t457, i32 0, i32 0
  store i64 5, ptr %t458
  %t459 = load %"compiler/source:Span", ptr %l182
  %t460 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t459, 0
  %t462 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t460, { i64, [4 x i64] } %t456, 1
  %t463 = getelementptr { i64, [8 x i64] }, ptr %t457, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t462, ptr %t463
  %t464 = load { i64, [8 x i64] }, ptr %t457
  %t465 = load ptr, ptr %l180, !tbaa !29
  %t466 = load i32, ptr %l181, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t465, i32 %t466, { i64, [8 x i64] } %t464)
  br label %bb46
bb46:
  %t468 = load ptr, ptr %lp3
  store ptr %t468, ptr %l187, !tbaa !29
  %t469 = load i32, ptr %l16, !tbaa !23
  store i32 %t469, ptr %l188, !tbaa !23
  %t470 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t470, ptr %l189
  %t471 = load i32, ptr %l10, !tbaa !23
  %t473 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t471)
  store %"compiler/mir:Lvalue" %t473, ptr %l191
  br label %bb47
bb47:
  %t474 = load i32, ptr %l9, !tbaa !23
  %t476 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t474)
  store %"compiler/mir:Lvalue" %t476, ptr %l193
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t477
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 0
  store i64 1, ptr %t478
  %t479 = load %"compiler/mir:Lvalue", ptr %l193
  %t480 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t479, 0
  %t481 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t480, ptr %t481
  %t482 = load { i64, [4 x i64] }, ptr %t477
  %t483 = load i32, ptr %l2, !tbaa !23
  %t484 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t485
  %t486 = getelementptr { i64, [15 x i64] }, ptr %t485, i32 0, i32 0
  store i64 11, ptr %t486
  %t488 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t482, 0
  %t490 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t488, i32 %t483, 1
  %t492 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t490, i32 %t484, 2
  %t493 = getelementptr { i64, [15 x i64] }, ptr %t485, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t492, ptr %t493
  %t494 = load { i64, [15 x i64] }, ptr %t485
  store { i64, [21 x i64] } zeroinitializer, ptr %t495
  %t496 = getelementptr { i64, [21 x i64] }, ptr %t495, i32 0, i32 0
  store i64 0, ptr %t496
  %t497 = load %"compiler/source:Span", ptr %l189
  %t498 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t497, 0
  %t499 = load %"compiler/mir:Lvalue", ptr %l191
  %t500 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t498, %"compiler/mir:Lvalue" %t499, 1
  %t502 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t500, { i64, [15 x i64] } %t494, 2
  %t503 = getelementptr { i64, [21 x i64] }, ptr %t495, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t502, ptr %t503
  %t504 = load { i64, [21 x i64] }, ptr %t495
  store { i64, [21 x i64] } %t504, ptr %l198
  %t505 = load ptr, ptr %l187, !tbaa !29
  %t506 = load i32, ptr %l188, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t505, i32 %t506, ptr %l198)
  br label %bb49
bb49:
  %t508 = load ptr, ptr %lp3
  %t509 = load i32, ptr %l16, !tbaa !23
  %t510 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t511 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [21 x i64] }, ptr %t512, i32 0, i32 0
  store i64 4, ptr %t513
  %t515 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t510, 0
  %t517 = insertvalue { %"compiler/source:Span", i32 } %t515, i32 %t511, 1
  %t518 = getelementptr { i64, [21 x i64] }, ptr %t512, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t517, ptr %t518
  %t519 = load { i64, [21 x i64] }, ptr %t512
  store { i64, [21 x i64] } %t519, ptr %l204
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t508, i32 %t509, ptr %l204)
  br label %bb50
bb50:
  %t523 = load ptr, ptr %lp3
  %t524 = load i32, ptr %l16, !tbaa !23
  %t525 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t526
  %t527 = getelementptr { i64, [21 x i64] }, ptr %t526, i32 0, i32 0
  store i64 4, ptr %t527
  %t529 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t525, 0
  %t530 = insertvalue { %"compiler/source:Span", i32 } %t529, i32 0, 1
  %t531 = getelementptr { i64, [21 x i64] }, ptr %t526, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t530, ptr %t531
  %t532 = load { i64, [21 x i64] }, ptr %t526
  store { i64, [21 x i64] } %t532, ptr %l209
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t523, i32 %t524, ptr %l209)
  br label %bb51
bb51:
  %t536 = load ptr, ptr %lp3
  store ptr %t536, ptr %l211, !tbaa !29
  %t537 = load i32, ptr %l16, !tbaa !23
  store i32 %t537, ptr %l212, !tbaa !23
  %t538 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store %"compiler/source:Span" %t538, ptr %l213
  %t539 = load i32, ptr %l10, !tbaa !23
  %t541 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t539)
  store %"compiler/mir:Lvalue" %t541, ptr %l215
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t542
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 0
  store i64 1, ptr %t543
  %t544 = load %"compiler/mir:Lvalue", ptr %l215
  %t545 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t544, 0
  %t546 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t545, ptr %t546
  %t547 = load { i64, [4 x i64] }, ptr %t542
  store { i64, [8 x i64] } zeroinitializer, ptr %t548
  %t549 = getelementptr { i64, [8 x i64] }, ptr %t548, i32 0, i32 0
  store i64 7, ptr %t549
  %t550 = load %"compiler/source:Span", ptr %l213
  %t551 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t550, 0
  %t553 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t551, { i64, [4 x i64] } %t547, 1
  %t554 = getelementptr { i64, [8 x i64] }, ptr %t548, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t553, ptr %t554
  %t555 = load { i64, [8 x i64] }, ptr %t548
  %t556 = load ptr, ptr %l211, !tbaa !29
  %t557 = load i32, ptr %l212, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t556, i32 %t557, { i64, [8 x i64] } %t555)
  br label %bb53
bb53:
  %t559 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l218, ptr %t559, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l218, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2eFn_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca %"compiler/mir:Fn"
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i32
  %l40 = alloca { i64, [21 x i64] }
  %l42 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/mir:Fn", align 8
  %t68 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = insertvalue { i32 } undef, i32 9, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i32 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  call void @compiler_2fmir_3aFn_2ector(ptr %t8, ptr %v1, { i64, [2 x i64] } %t5, i32 %t6, i64 0, %"compiler/source:Span" %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t8, i64 800, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store ptr %t12, ptr %lp2
  %t13 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %l10, i64 800, i1 false)
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  %t44 = load ptr, ptr %lp2
  %t45 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t50 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v1, ptr %t44, i32 0, %"compiler/source:Span" %t45, i32 %t42)
  store i32 %t50, ptr %l28
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  %t55 = load ptr, ptr %lp2
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t57 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t55, i32 0, i32 %t56, i32 0, %"compiler/source:Span" %t57, i32 0)
  store i32 %t62, ptr %l35
  br label %bb11
bb11:
  %t63 = load ptr, ptr %lp2
  %t65 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t63)
  store i32 %t65, ptr %l37
  br label %bb12
bb12:
  %t66 = load ptr, ptr %lp2
  %t67 = load %"compiler/source:Span", ptr @G_2ecompiler_2fmir_2eSp0
  store { i64, [21 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 0
  store i64 3, ptr %t69
  %t71 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t67, 0
  %t72 = insertvalue { %"compiler/source:Span", i32 } %t71, i32 0, 1
  %t73 = getelementptr { i64, [21 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t72, ptr %t73
  %t74 = load { i64, [21 x i64] }, ptr %t68
  store { i64, [21 x i64] } %t74, ptr %l40
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t66, i32 0, ptr %l40)
  br label %bb13
bb13:
  %t77 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t77, i64 800, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l42, i64 800, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2eGuardOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i32
  %l39 = alloca { i64, ptr }
  %l41 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t8 = trunc i64 22 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l13
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l10, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = icmp ne i64 %t27, 2
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 0
  %t36 = load i32, ptr %t35, !tbaa !33
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t36)
  store i1 %t39, ptr %l22
  br label %bb9
bb9:
  %t40 = load i1, ptr %l22, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l18, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l26, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 1
  %t49 = load i32, ptr %t48, !tbaa !33
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t44, i32 %t49)
  store i1 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load i1, ptr %l28, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l24, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb18
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 0
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t62)
  store i32 %t65, ptr %l34
  br label %bb17
bb17:
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t67 = load i32, ptr %l34, !tbaa !23
  %t69 = icmp ne i32 %t67, %t66
  store i1 %t69, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l39, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i32, ptr %t77, i64 1
  %t79 = load i32, ptr %t78, !tbaa !33
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t74, i32 %t79)
  store i32 %t82, ptr %l41
  br label %bb22
bb22:
  %t83 = load i32, ptr %l41, !tbaa !23
  store i32 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l46 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l64 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1, i32 %t2, i64 %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t11 = trunc i64 0 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb7
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t18 = mul i64 2, 4
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 2, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 0
  store i32 %t16, ptr %t25, !tbaa !33
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 1
  store i32 %t17, ptr %t29, !tbaa !33
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } %t31)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t34 = load ptr, ptr %l11, !tbaa !29
  %t35 = load i32, ptr %l16, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t34, i32 %t35, i32 %t33, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t37, ptr %l18
  br label %bb6
bb6:
  %t38 = load i32, ptr %l18, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb42
bb7:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = mul i64 2, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 2, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t46, ptr %t55, !tbaa !33
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 1
  store i32 %t47, ptr %t59, !tbaa !33
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t45, { i64, ptr } %t61)
  store i32 %t62, ptr %l26
  br label %bb11
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t64 = load ptr, ptr %l21, !tbaa !29
  %t65 = load i32, ptr %l26, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t64, i32 %t65, i32 %t63, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t67, ptr %l28
  br label %bb12
bb12:
  %t68 = load i32, ptr %l28, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb13:
  %t69 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l31, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l34
  br label %bb17
bb17:
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load ptr, ptr %l31, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t81, i32 %t82, i32 %t80, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t84, ptr %l36
  br label %bb18
bb18:
  %t85 = load i32, ptr %l36, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  br label %bb42
bb19:
  %t86 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t88 = trunc i64 3 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t91, i32 0, i32 %t92, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t95, ptr %l41
  br label %bb23
bb23:
  %t96 = load i32, ptr %l41, !tbaa !23
  store i32 %t96, ptr %l8, !tbaa !23
  br label %bb42
bb24:
  %t97 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t99 = trunc i64 4 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  %t102 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t104 = trunc i64 5 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l46, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l3, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l49
  br label %bb30
bb30:
  %t113 = load i32, ptr %l2, !tbaa !23
  %t114 = load ptr, ptr %l46, !tbaa !29
  %t115 = load i32, ptr %l49, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t114, i32 %t115, i32 %t113, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t117, ptr %l51
  br label %bb31
bb31:
  %t118 = load i32, ptr %l51, !tbaa !23
  store i32 %t118, ptr %l8, !tbaa !23
  br label %bb42
bb32:
  %t119 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t121 = trunc i64 6 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t124 = load i32, ptr %l1, !range !{i32 0, i32 8}
  %t126 = trunc i64 7 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l56, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l57, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t133 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t137, ptr %l61
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l57, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb39
bb39:
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t142 = load ptr, ptr %l56, !tbaa !29
  %t143 = load i32, ptr %l62, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t142, i32 %t143, i32 %t141, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t145, ptr %l64
  br label %bb40
bb40:
  %t146 = load i32, ptr %l64, !tbaa !23
  store i32 %t146, ptr %l8, !tbaa !23
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_f3abe41a98405543_7d26227a2bded35f)
  unreachable
bb42:
  %t147 = load i32, ptr %l8, !tbaa !23
  store i32 %t147, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l8 = alloca ptr
  %l12 = alloca { i64, [21 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t6 = sext i32 %a1 to i64
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  store ptr %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"compiler/mir:BasicBlock", ptr %t10, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %a2, i64 176, i1 false)
  %t17 = load { i64, [21 x i64] }, ptr %l12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t13, { i64, [21 x i64] } %t17)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t3, %"compiler/mir:Call" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 14
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddItems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 18
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/typed:Item", ptr %t25, i64 %t22
  %t27 = load %"compiler/typed:Item", ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t31, %"compiler/typed:Item" %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca ptr
  %l13 = alloca %"compiler/mir:ScopeInfo"
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l7, !tbaa !29
  %t14 = call %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %s0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
  store %"compiler/mir:ScopeInfo" %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/mir:ScopeInfo", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ePush_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t15, %"compiler/mir:ScopeInfo" %t16)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 8
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t25 = trunc i64 %t23 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t4 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [1 x i64] }, ptr %t4, i32 0, i32 0
  store i64 3, ptr %t5
  %t6 = load { i64, [1 x i64] }, ptr %t4
  %t11 = call %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %s0, i32 0, %"compiler/source:Span" %a2, i32 %a1, i32 3, { i64, [1 x i64] } %t6)
  store %"compiler/mir:Local" %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load %"compiler/mir:Local", ptr %l8
  %t14 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %t12, %"compiler/mir:Local" %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l17 = alloca { i64, ptr }
  %l30 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [4 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t31, { i64, [4 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t41, i32 %t46)
  store %"compiler/mir:Range" %t49, ptr %l30
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/mir:Range", ptr %l30
  store %"compiler/mir:Range" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2) #0 {
entry:
  %l10 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  %t7 = getelementptr %"compiler/mir:Fn", ptr %a0, i32 0, i32 9
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v0, ptr %t7, i64 %t3)
  store ptr %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t17 = getelementptr %"compiler/mir:BasicBlock", ptr %t12, i32 0, i32 1
  store { i64, [8 x i64] } %a2, ptr %t17
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:BasicBlock"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %s0)
  store %"compiler/mir:BasicBlock" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/mir:BasicBlock", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ePush_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s0, ptr %t5, %"compiler/mir:BasicBlock" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 9
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 10
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, [1 x i64] }, ptr %t25, i64 %t22
  %t27 = load { i64, [1 x i64] }, ptr %t26
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb8:
  store { i64, [2 x i64] } %a1, ptr %l26
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = trunc i64 %t45 to i32
  %t50 = call %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %s0, i32 %t42, i32 %t47)
  store %"compiler/mir:Range" %t50, ptr %l32
  br label %bb9
bb9:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  %t52 = load %"compiler/mir:Range", ptr %l32
  %t53 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t51, %"compiler/mir:Range" %t52)
  store %"compiler/mir:Lvalue" %t53, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/mir:Lvalue", ptr %l33
  store %"compiler/mir:Lvalue" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 23
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 23
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t55, i64 %t56)
  store i32 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i32, ptr %l38, !tbaa !23
  %t64 = icmp eq i32 %t62, %t61
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l44
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t73 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca %"compiler/mir:verifier"
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/mir:verifier", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fmir_3averifier_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %t3, i64 304, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 304, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l5, i64 304, i1 false)
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %s0, ptr %t8)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 2
  %t14 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t12)
  store { i64, ptr } %t14, ptr %l10
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  %t11 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t6, %"compiler/mir:Lvalue" %t8)
  store { i64, ptr } %t11, ptr %l8
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  call void @olang_textcopy(ptr %t19, ptr %t15, i64 %t16)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t29 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t29, { i64, ptr } %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  store ptr %l2, ptr %l11, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 0
  %t33 = load { i64, [7 x i64] }, ptr %t32
  %t36 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %s0, ptr %t31, { i64, [7 x i64] } %t33)
  store { i64, ptr } %t36, ptr %l14
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t39 = load %"compiler/mir:Range", ptr %t38
  %t42 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %s0, ptr %t37, %"compiler/mir:Range" %t39)
  store { i64, ptr } %t42, ptr %l17
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t43, i64 %t44)
  %t60 = getelementptr i8, ptr %t59, i64 %t44
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t49, i64 %t50)
  %t62 = getelementptr i8, ptr %t61, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t59, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t73, { i64, ptr } %t72)
  br label %bb9
bb9:
  %t75 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = icmp sgt i32 %t77, 0
  br i1 %t79, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l22, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 2
  %t83 = load %"compiler/mir:Range", ptr %t82
  %t86 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %s4, ptr %t81, %"compiler/mir:Range" %t83)
  store { i64, ptr } %t86, ptr %l25
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t89 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t108, { i64, ptr } %t107)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t110 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t115 = sext i32 %t111 to i64
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t113, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t112, i64 %t113)
  %t119 = getelementptr i8, ptr %t118, i64 %t113
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t115)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t129)
  br label %bb15
bb15:
  %t132 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t137 = icmp ne i32 %t133, %t134
  br i1 %t137, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 6
  %t140 = load i32, ptr %t139, !tbaa !23
  %t141 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 7
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t146 = sext i32 %t140 to i64
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t146)
  %t159 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t159, ptr %t149, i64 %t150)
  %t160 = getelementptr i8, ptr %t159, i64 %t150
  %t161 = call i64 @__olang_fmt_i64(ptr %t160, i64 %t153)
  %t162 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t156, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t170)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb19
bb19:
  %t174 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t174, ptr %l41
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t175 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t175, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t14 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %t10, { i64, [2 x i64] } %t11)
  store { i64, ptr } %t14, ptr %l13
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  br label %bb20
bb5:
  %t16 = load { i64, [7 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { i64, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t29 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  %t33 = call i64 @__olang_fmt_i64(ptr %t32, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %l7, !tbaa !27
  br label %bb20
bb9:
  %t37 = load { i64, [7 x i64] }, ptr %l1
  %t39 = extractvalue { i64, [7 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 2
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, [4 x i64] } }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l4
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l4
  %t50 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t46, { i64, [4 x i64] } %t47)
  store { i64, ptr } %t50, ptr %l24
  br label %bb13
bb13:
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t53 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb14:
  %t66 = load { i64, [7 x i64] }, ptr %l1
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 3
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t72 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t73, ptr %l5
  %t75 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t76 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l30, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, [4 x i64] }, ptr %l5
  %t84 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %t80, { i64, [4 x i64] } %t81)
  store { i64, ptr } %t84, ptr %l33
  br label %bb18
bb18:
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t87 = load i64, ptr %l30, !tbaa !24
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t86, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t85, i64 %t86)
  %t101 = getelementptr i8, ptr %t100, i64 %t86
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t87)
  %t103 = getelementptr i8, ptr %t101, i64 %t88
  call void @olang_textcopy(ptr %t103, ptr %t90, i64 %t91)
  %t104 = getelementptr i8, ptr %t103, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t94, i64 %t95)
  %t105 = getelementptr i8, ptr %t104, i64 %t95
  call void @olang_textcopy(ptr %t105, ptr %t97, i64 %t98)
  %t106 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t100, 1
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267)
  unreachable
bb20:
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstant(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/mir:Range"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 19
  %t9 = sext i32 %a1 to i64
  %t10 = load ptr, ptr @__olang_prog_scope
  %t13 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %t10, ptr %t6, i64 %t9)
  store { i64, [1 x i64] } %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t14, ptr %l2
  %t15 = load { i64, [1 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l12, !tbaa !27
  br label %bb15
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  %t34 = extractvalue { i64, [1 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 1
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Range" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Range", ptr %t38
  store %"compiler/mir:Range" %t39, ptr %l4
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t46 = sext i32 %t42 to i64
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t46)
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  store { i64, ptr } %t53, ptr %l12, !tbaa !27
  br label %bb15
bb9:
  %t55 = load { i64, [1 x i64] }, ptr %l2
  %t57 = extractvalue { i64, [1 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 2
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t61 = getelementptr { %"compiler/mir:Range" }, ptr %t60, i32 0, i32 0
  %t62 = load %"compiler/mir:Range", ptr %t61
  store %"compiler/mir:Range" %t62, ptr %l5
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/mir:Range", ptr %l5
  %t68 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %t64, %"compiler/mir:Range" %t65)
  store { i64, ptr } %t68, ptr %l28
  br label %bb13
bb13:
  %t69 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t69, ptr %l12, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dca1ca4acf899191_a3a5645eac28d4dd)
  unreachable
bb15:
  %t70 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3adumper_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/mir:dumper", ptr %t49, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:dumper", ptr %t63, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2elist(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/mir:dumper", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t8, ptr %s0, ptr %t6, i32 %a1)
  store { i64, ptr } %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l20, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  store ptr %l2, ptr %l41, !tbaa !29
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:dumper", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t78 = load ptr, ptr @__olang_prog_scope
  %t81 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t78, ptr %s2, ptr %t70, i32 %t77)
  store { i64, ptr } %t81, ptr %l50
  br label %bb16
bb16:
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t100, { i64, ptr } %t99)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t107 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t107, ptr %l56
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperands(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 11
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t73, ptr %t62, i64 %t72)
  store { i64, [4 x i64] } %t76, ptr %l48
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load { i64, [4 x i64] }, ptr %l48
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s2, ptr %t77, { i64, [4 x i64] } %t78)
  store { i64, ptr } %t79, ptr %l49
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t105, ptr %l55
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2erefs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l48 = alloca { i64, [1 x i64] }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i32 0, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = icmp sgt i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb7
bb4:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = sub i32 %t16, %t17
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = add i32 %t20, %t21
  %t26 = sub i32 %t24, 1
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = sdiv i32 %t26, %t27
  store i32 %t30, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l17, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l6, !tbaa !23
  %t38 = icmp slt i32 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t47 = mul i32 %t43, %t44
  %t50 = add i32 %t42, %t47
  store i32 %t50, ptr %l8, !tbaa !23
  store ptr %l2, ptr %l35, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t54 = icmp sgt i32 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/mir:dumper", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/mir:Fn", ptr %t60, i32 0, i32 12
  %t63 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t67 = load i32, ptr %l8, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = add i64 %t66, %t69
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t73, ptr %t62, i64 %t72)
  store { i64, [1 x i64] } %t76, ptr %l48
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load { i64, [1 x i64] }, ptr %l48
  %t79 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s2, ptr %t77, { i64, [1 x i64] } %t78)
  store { i64, ptr } %t79, ptr %l49
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t98, { i64, ptr } %t97)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t100 = load i32, ptr %l7, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l7, !tbaa !23
  br label %bb8
bb19:
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t105, ptr %l55
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i32
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca %"compiler/mir:Lvalue"
  %l18 = alloca %"compiler/mir:Lvalue"
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i1
  %l113 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l119 = alloca i1
  %l128 = alloca i32
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i1
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca i1
  %l168 = alloca i32
  %l169 = alloca ptr
  %l175 = alloca %"compiler/mir:Task"
  %l176 = alloca { i64, ptr }
  %l178 = alloca ptr
  %l179 = alloca i1
  %l182 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l185 = alloca i1
  %l192 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca i1
  %l198 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l201 = alloca i1
  %l208 = alloca i32
  %l212 = alloca { i64, ptr }
  %l217 = alloca i64
  %l218 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t2 = load ptr, ptr %l26, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l26, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 15}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l27, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l27, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  %t26 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s1, ptr %t22, %"compiler/mir:Lvalue" %t23)
  store { i64, ptr } %t26, ptr %l36
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [15 x i64] }, ptr %l3
  %t31 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %s1, ptr %t27, { i64, [15 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l39
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = getelementptr i8, ptr %t43, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  store { i64, ptr } %t46, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb111
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 15}
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l42, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l42, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [21 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t67 = sext i32 %t63 to i64
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = getelementptr i8, ptr %t70, i64 %t65
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t67)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  store { i64, ptr } %t74, ptr %l25, !tbaa !27
  br label %bb111
bb14:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l49, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 15}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [21 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t91 = load i32, ptr %l5, !tbaa !23
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t95 = sext i32 %t91 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t92, i64 %t93)
  %t99 = getelementptr i8, ptr %t98, i64 %t93
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t95)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t98, 1
  store { i64, ptr } %t102, ptr %l25, !tbaa !27
  br label %bb111
bb20:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t105 = load ptr, ptr %l57, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 15}
  %t111 = icmp eq i64 %t109, 3
  store i1 %t111, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t112 = load i1, ptr %l58, !tbaa !21
  br i1 %t112, label %bb23, label %bb24
bb23:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32 }, ptr %t115, i32 0, i32 1
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l6, !tbaa !23
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t123 = sext i32 %t119 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  %t128 = call i64 @__olang_fmt_i64(ptr %t127, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l25, !tbaa !27
  br label %bb111
bb26:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 15}
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t140 = load i1, ptr %l66, !tbaa !21
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32 }, ptr %t143, i32 0, i32 1
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l7, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t147 = load i32, ptr %l7, !tbaa !23
  %t148 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t151 = sext i32 %t147 to i64
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t149, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t148, i64 %t149)
  %t155 = getelementptr i8, ptr %t154, i64 %t149
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t151)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l25, !tbaa !27
  br label %bb111
bb32:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t161 = load ptr, ptr %l73, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = load ptr, ptr %l73, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 15}
  %t167 = icmp eq i64 %t165, 5
  store i1 %t167, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l74, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [21 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t171, i32 0, i32 1
  %t173 = load { i64, [1 x i64] }, ptr %t172
  store { i64, [1 x i64] } %t173, ptr %l8
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [21 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t177, i32 0, i32 2
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l9, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t183, i32 0, i32 3
  %t185 = load { i64, [4 x i64] }, ptr %t184
  store { i64, [4 x i64] } %t185, ptr %l10
  br label %bb37
bb36:
  br label %bb41
bb37:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/mir:dumper", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i32, ptr %l9, !tbaa !23
  %t192 = load ptr, ptr @__olang_prog_scope
  %t195 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t192, ptr %s11, ptr %t190, i32 %t191)
  store { i64, ptr } %t195, ptr %l86
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, [4 x i64] }, ptr %l10
  %t200 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %t196, { i64, [4 x i64] } %t197)
  store { i64, ptr } %t200, ptr %l89
  br label %bb39
bb39:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, [1 x i64] }, ptr %l8
  %t205 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s11, ptr %t201, { i64, [1 x i64] } %t202)
  store { i64, ptr } %t205, ptr %l92
  br label %bb40
bb40:
  %t206 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t208 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = add i64 %t207, %t210
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t215 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t206, i64 %t207)
  %t227 = getelementptr i8, ptr %t226, i64 %t207
  call void @olang_textcopy(ptr %t227, ptr %t209, i64 %t210)
  %t228 = getelementptr i8, ptr %t227, i64 %t210
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t216, i64 %t217)
  %t230 = getelementptr i8, ptr %t229, i64 %t217
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t223, i64 %t224)
  %t232 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t226, 1
  store { i64, ptr } %t233, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb111
bb41:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t236 = load ptr, ptr %l94, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb42, label %bb43
bb42:
  %t239 = load ptr, ptr %l94, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 15}
  %t242 = icmp eq i64 %t240, 6
  store i1 %t242, ptr %l95, !tbaa !21
  br label %bb43
bb43:
  %t243 = load i1, ptr %l95, !tbaa !21
  br i1 %t243, label %bb44, label %bb45
bb44:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [21 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t246, i32 0, i32 1
  %t248 = load %"compiler/mir:Lvalue", ptr %t247
  store %"compiler/mir:Lvalue" %t248, ptr %l11
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/mir:Lvalue", ptr %l11
  %t254 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s13, ptr %t250, %"compiler/mir:Lvalue" %t251)
  store { i64, ptr } %t254, ptr %l102
  br label %bb47
bb47:
  %t255 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t255, i64 %t256)
  %t262 = getelementptr i8, ptr %t261, i64 %t256
  call void @olang_textcopy(ptr %t262, ptr %t258, i64 %t259)
  %t263 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t261, 1
  store { i64, ptr } %t264, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb111
bb48:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t267 = load ptr, ptr %l104, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb49, label %bb50
bb49:
  %t270 = load ptr, ptr %l104, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 15}
  %t273 = icmp eq i64 %t271, 7
  store i1 %t273, ptr %l105, !tbaa !21
  br label %bb50
bb50:
  %t274 = load i1, ptr %l105, !tbaa !21
  br i1 %t274, label %bb51, label %bb52
bb51:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [21 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t277, i32 0, i32 1
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l12, !tbaa !23
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [21 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t283, i32 0, i32 2
  %t285 = load %"compiler/mir:Lvalue", ptr %t284
  store %"compiler/mir:Lvalue" %t285, ptr %l13
  br label %bb53
bb52:
  br label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t287 = load i32, ptr %l12, !tbaa !23
  %t289 = sext i32 %t287 to i64
  store i64 %t289, ptr %l113, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/mir:Lvalue", ptr %l13
  %t294 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s15, ptr %t290, %"compiler/mir:Lvalue" %t291)
  store { i64, ptr } %t294, ptr %l116
  br label %bb54
bb54:
  %t295 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t297 = load i64, ptr %l113, !tbaa !24
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t299 = add i64 %t296, %t298
  %t300 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = add i64 %t302, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t295, i64 %t296)
  %t308 = getelementptr i8, ptr %t307, i64 %t296
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t297)
  %t310 = getelementptr i8, ptr %t308, i64 %t298
  call void @olang_textcopy(ptr %t310, ptr %t300, i64 %t301)
  %t311 = getelementptr i8, ptr %t310, i64 %t301
  call void @olang_textcopy(ptr %t311, ptr %t304, i64 %t305)
  %t312 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t307, 1
  store { i64, ptr } %t313, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb111
bb55:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t316 = load ptr, ptr %l118, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb56, label %bb57
bb56:
  %t319 = load ptr, ptr %l118, !tbaa !29
  %t320 = load i64, ptr %t319, !range !{i64 0, i64 15}
  %t322 = icmp eq i64 %t320, 8
  store i1 %t322, ptr %l119, !tbaa !21
  br label %bb57
bb57:
  %t323 = load i1, ptr %l119, !tbaa !21
  br i1 %t323, label %bb58, label %bb59
bb58:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [21 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t326, i32 0, i32 1
  %t328 = load { i64, [1 x i64] }, ptr %t327
  store { i64, [1 x i64] } %t328, ptr %l14
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [21 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t332, i32 0, i32 2
  %t334 = load i32, ptr %t333, !range !{i32 0, i32 8}
  store i32 %t334, ptr %l15
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [21 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t338, i32 0, i32 3
  %t340 = load { i64, [4 x i64] }, ptr %t339
  store { i64, [4 x i64] } %t340, ptr %l16
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  %t342 = load i32, ptr %l15, !range !{i32 0, i32 8}
  store i32 %t342, ptr %l128
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s18, ptr %l128, i64 0)
  br label %bb61
bb61:
  %t344 = load ptr, ptr %s18
  %t345 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t346 = load i64, ptr %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t344, i64 %t346)
  %t348 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l130, !tbaa !27
  %t350 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t351 = load ptr, ptr %t350
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %sbgrew.353, label %sbdone.354
sbgrew.353:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.354
sbdone.354:
  %t355 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t363 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s17, ptr %s17, { i64, ptr } %t361)
  store { i64, ptr } %t363, ptr %l132
  br label %bb62
bb62:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load { i64, [4 x i64] }, ptr %l16
  %t368 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s17, ptr %t364, { i64, [4 x i64] } %t365)
  store { i64, ptr } %t368, ptr %l135
  br label %bb63
bb63:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load { i64, [1 x i64] }, ptr %l14
  %t373 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %s17, ptr %t369, { i64, [1 x i64] } %t370)
  store { i64, ptr } %t373, ptr %l138
  br label %bb64
bb64:
  %t374 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t376 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = add i64 %t389, %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t374, i64 %t375)
  %t395 = getelementptr i8, ptr %t394, i64 %t375
  call void @olang_textcopy(ptr %t395, ptr %t377, i64 %t378)
  %t396 = getelementptr i8, ptr %t395, i64 %t378
  call void @olang_textcopy(ptr %t396, ptr %t380, i64 %t381)
  %t397 = getelementptr i8, ptr %t396, i64 %t381
  call void @olang_textcopy(ptr %t397, ptr %t384, i64 %t385)
  %t398 = getelementptr i8, ptr %t397, i64 %t385
  call void @olang_textcopy(ptr %t398, ptr %t387, i64 %t388)
  %t399 = getelementptr i8, ptr %t398, i64 %t388
  call void @olang_textcopy(ptr %t399, ptr %t391, i64 %t392)
  %t400 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t394, 1
  store { i64, ptr } %t401, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb65:
  %t403 = load ptr, ptr %l1, !tbaa !29
  store ptr %t403, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t404 = load ptr, ptr %l140, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb66, label %bb67
bb66:
  %t407 = load ptr, ptr %l140, !tbaa !29
  %t408 = load i64, ptr %t407, !range !{i64 0, i64 15}
  %t410 = icmp eq i64 %t408, 9
  store i1 %t410, ptr %l141, !tbaa !21
  br label %bb67
bb67:
  %t411 = load i1, ptr %l141, !tbaa !21
  br i1 %t411, label %bb68, label %bb69
bb68:
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [21 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t414, i32 0, i32 1
  %t416 = load %"compiler/mir:Lvalue", ptr %t415
  store %"compiler/mir:Lvalue" %t416, ptr %l17
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t420 = getelementptr { i64, [21 x i64] }, ptr %t418, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t420, i32 0, i32 2
  %t422 = load %"compiler/mir:Lvalue", ptr %t421
  store %"compiler/mir:Lvalue" %t422, ptr %l18
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [21 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t426, i32 0, i32 3
  %t428 = load { i64, [4 x i64] }, ptr %t427
  store { i64, [4 x i64] } %t428, ptr %l19
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s20
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load { i64, [4 x i64] }, ptr %l19
  %t434 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s20, ptr %t430, { i64, [4 x i64] } %t431)
  store { i64, ptr } %t434, ptr %l152
  br label %bb71
bb71:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load %"compiler/mir:Lvalue", ptr %l18
  %t439 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s20, ptr %t435, %"compiler/mir:Lvalue" %t436)
  store { i64, ptr } %t439, ptr %l155
  br label %bb72
bb72:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/mir:Lvalue", ptr %l17
  %t444 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %s20, ptr %t440, %"compiler/mir:Lvalue" %t441)
  store { i64, ptr } %t444, ptr %l158
  br label %bb73
bb73:
  %t445 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t447 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t461 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = add i64 %t460, %t463
  %t465 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t445, i64 %t446)
  %t466 = getelementptr i8, ptr %t465, i64 %t446
  call void @olang_textcopy(ptr %t466, ptr %t448, i64 %t449)
  %t467 = getelementptr i8, ptr %t466, i64 %t449
  call void @olang_textcopy(ptr %t467, ptr %t451, i64 %t452)
  %t468 = getelementptr i8, ptr %t467, i64 %t452
  call void @olang_textcopy(ptr %t468, ptr %t455, i64 %t456)
  %t469 = getelementptr i8, ptr %t468, i64 %t456
  call void @olang_textcopy(ptr %t469, ptr %t458, i64 %t459)
  %t470 = getelementptr i8, ptr %t469, i64 %t459
  call void @olang_textcopy(ptr %t470, ptr %t462, i64 %t463)
  %t471 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t465, 1
  store { i64, ptr } %t472, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  br label %bb111
bb74:
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t475 = load ptr, ptr %l160, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb75, label %bb76
bb75:
  %t478 = load ptr, ptr %l160, !tbaa !29
  %t479 = load i64, ptr %t478, !range !{i64 0, i64 15}
  %t481 = icmp eq i64 %t479, 10
  store i1 %t481, ptr %l161, !tbaa !21
  br label %bb76
bb76:
  %t482 = load i1, ptr %l161, !tbaa !21
  br i1 %t482, label %bb77, label %bb78
bb77:
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [21 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t485, i32 0, i32 1
  %t487 = load i32, ptr %t486
  store i32 %t487, ptr %l20, !tbaa !23
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr { i64, [21 x i64] }, ptr %t489, i32 0, i32 1
  %t492 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t491, i32 0, i32 2
  %t493 = load i32, ptr %t492
  store i32 %t493, ptr %l21, !tbaa !23
  br label %bb79
bb78:
  br label %bb82
bb79:
  store %olang.scope zeroinitializer, ptr %s22
  %t495 = load i32, ptr %l20, !tbaa !23
  store i32 %t495, ptr %l168, !tbaa !23
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l169, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/mir:dumper", ptr %t497, i32 0, i32 0
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = getelementptr %"compiler/mir:Fn", ptr %t500, i32 0, i32 16
  %t503 = load i32, ptr %l21, !tbaa !23
  %t505 = sext i32 %t503 to i64
  %t506 = load ptr, ptr @__olang_prog_scope
  %t509 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t506, ptr %t502, i64 %t505)
  store %"compiler/mir:Task" %t509, ptr %l175
  br label %bb80
bb80:
  %t510 = load ptr, ptr %l169, !tbaa !29
  %t511 = load %"compiler/mir:Task", ptr %l175
  %t512 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %s22, ptr %t510, %"compiler/mir:Task" %t511)
  store { i64, ptr } %t512, ptr %l176
  br label %bb81
bb81:
  %t513 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t515 = load i32, ptr %l168, !tbaa !23
  %t516 = sext i32 %t515 to i64
  %t517 = call i64 @__olang_fmt_i64(ptr null, i64 %t516)
  %t518 = add i64 %t514, %t517
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = add i64 %t521, %t524
  %t526 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t525)
  call void @olang_textcopy(ptr %t526, ptr %t513, i64 %t514)
  %t527 = getelementptr i8, ptr %t526, i64 %t514
  %t528 = call i64 @__olang_fmt_i64(ptr %t527, i64 %t516)
  %t529 = getelementptr i8, ptr %t527, i64 %t517
  call void @olang_textcopy(ptr %t529, ptr %t519, i64 %t520)
  %t530 = getelementptr i8, ptr %t529, i64 %t520
  call void @olang_textcopy(ptr %t530, ptr %t523, i64 %t524)
  %t531 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t526, 1
  store { i64, ptr } %t532, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb111
bb82:
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t535 = load ptr, ptr %l178, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb83, label %bb84
bb83:
  %t538 = load ptr, ptr %l178, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 15}
  %t541 = icmp eq i64 %t539, 11
  store i1 %t541, ptr %l179, !tbaa !21
  br label %bb84
bb84:
  %t542 = load i1, ptr %l179, !tbaa !21
  br i1 %t542, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l182, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t543, ptr %l25, !tbaa !27
  br label %bb111
bb88:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t546 = load ptr, ptr %l184, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb89, label %bb90
bb89:
  %t549 = load ptr, ptr %l184, !tbaa !29
  %t550 = load i64, ptr %t549, !range !{i64 0, i64 15}
  %t552 = icmp eq i64 %t550, 12
  store i1 %t552, ptr %l185, !tbaa !21
  br label %bb90
bb90:
  %t553 = load i1, ptr %l185, !tbaa !21
  br i1 %t553, label %bb91, label %bb92
bb91:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [21 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t556, i32 0, i32 1
  %t558 = load { i64, [4 x i64] }, ptr %t557
  store { i64, [4 x i64] } %t558, ptr %l22
  br label %bb93
bb92:
  br label %bb95
bb93:
  store %olang.scope zeroinitializer, ptr %s25
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load { i64, [4 x i64] }, ptr %l22
  %t564 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s25, ptr %t560, { i64, [4 x i64] } %t561)
  store { i64, ptr } %t564, ptr %l192
  br label %bb94
bb94:
  %t565 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t566 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t567 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t570 = add i64 %t566, %t569
  %t571 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t565, i64 %t566)
  %t572 = getelementptr i8, ptr %t571, i64 %t566
  call void @olang_textcopy(ptr %t572, ptr %t568, i64 %t569)
  %t573 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t571, 1
  store { i64, ptr } %t574, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s25)
  br label %bb111
bb95:
  %t576 = load ptr, ptr %l1, !tbaa !29
  store ptr %t576, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t577 = load ptr, ptr %l194, !tbaa !29
  %t578 = icmp ne ptr %t577, null
  br i1 %t578, label %bb96, label %bb97
bb96:
  %t580 = load ptr, ptr %l194, !tbaa !29
  %t581 = load i64, ptr %t580, !range !{i64 0, i64 15}
  %t583 = icmp eq i64 %t581, 13
  store i1 %t583, ptr %l195, !tbaa !21
  br label %bb97
bb97:
  %t584 = load i1, ptr %l195, !tbaa !21
  br i1 %t584, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l198, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t585, ptr %l25, !tbaa !27
  br label %bb111
bb101:
  %t587 = load ptr, ptr %l1, !tbaa !29
  store ptr %t587, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t588 = load ptr, ptr %l200, !tbaa !29
  %t589 = icmp ne ptr %t588, null
  br i1 %t589, label %bb102, label %bb103
bb102:
  %t591 = load ptr, ptr %l200, !tbaa !29
  %t592 = load i64, ptr %t591, !range !{i64 0, i64 15}
  %t594 = icmp eq i64 %t592, 14
  store i1 %t594, ptr %l201, !tbaa !21
  br label %bb103
bb103:
  %t595 = load i1, ptr %l201, !tbaa !21
  br i1 %t595, label %bb104, label %bb105
bb104:
  %t596 = load ptr, ptr %l1, !tbaa !29
  %t598 = getelementptr { i64, [21 x i64] }, ptr %t596, i32 0, i32 1
  %t599 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t598, i32 0, i32 1
  %t600 = load i32, ptr %t599
  store i32 %t600, ptr %l23, !tbaa !23
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [21 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t604, i32 0, i32 2
  %t606 = load i32, ptr %t605
  store i32 %t606, ptr %l24, !tbaa !23
  br label %bb106
bb105:
  br label %bb110
bb106:
  store %olang.scope zeroinitializer, ptr %s28
  %t608 = load i32, ptr %l23, !tbaa !23
  store i32 %t608, ptr %l208, !tbaa !23
  %t609 = load i32, ptr %l24, !tbaa !23
  %t610 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t613 = icmp ne i32 %t609, %t610
  br i1 %t613, label %bb107, label %bb108
bb107:
  %t615 = load i32, ptr %l24, !tbaa !23
  %t616 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t619 = sext i32 %t615 to i64
  %t620 = call i64 @__olang_fmt_i64(ptr null, i64 %t619)
  %t621 = add i64 %t617, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t616, i64 %t617)
  %t623 = getelementptr i8, ptr %t622, i64 %t617
  %t624 = call i64 @__olang_fmt_i64(ptr %t623, i64 %t619)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  store { i64, ptr } %t633, ptr %l212, !tbaa !27
  br label %bb109
bb108:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l212, !tbaa !27
  br label %bb109
bb109:
  %t635 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t636 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t637 = load i32, ptr %l208, !tbaa !23
  %t638 = sext i32 %t637 to i64
  %t639 = call i64 @__olang_fmt_i64(ptr null, i64 %t638)
  %t640 = add i64 %t636, %t639
  %t641 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t642 = extractvalue { i64, ptr } %t641, 1
  %t643 = extractvalue { i64, ptr } %t641, 0
  %t644 = add i64 %t640, %t643
  %t645 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t644)
  call void @olang_textcopy(ptr %t645, ptr %t635, i64 %t636)
  %t646 = getelementptr i8, ptr %t645, i64 %t636
  %t647 = call i64 @__olang_fmt_i64(ptr %t646, i64 %t638)
  %t648 = getelementptr i8, ptr %t646, i64 %t639
  call void @olang_textcopy(ptr %t648, ptr %t642, i64 %t643)
  %t649 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t645, 1
  store { i64, ptr } %t650, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s28)
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_63d4bc85d5a0ee63_941776bd89ba250f)
  unreachable
bb111:
  %t652 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t653 = extractvalue { i64, ptr } %t652, 0
  store i64 %t653, ptr %l217, !tbaa !24
  %t654 = load i64, ptr %l217, !tbaa !24
  %t655 = mul i64 %t654, 1
  %t656 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t655)
  %t657 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t656, 1
  store { i64, ptr } %t658, ptr %l218, !tbaa !27
  %t659 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !27
  %t661 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !27
  %t663 = load i64, ptr %l217, !tbaa !24
  %t664 = mul i64 %t663, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t660, ptr %t662, i64 %t664, i1 false)
  %t665 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t665, ptr %l25, !tbaa !27
  %t666 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t666, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eterm(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l67 = alloca %"compiler/mir:Call"
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l77 = alloca %"compiler/mir:Call"
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l117 = alloca i32
  %l118 = alloca i32
  %l122 = alloca { i64, ptr }
  %l132 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:dumper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t11, ptr %l25, !tbaa !27
  br label %bb71
bb4:
  %t13 = load { i64, [8 x i64] }, ptr %l1
  %t15 = extractvalue { i64, [8 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t19 = getelementptr { i32 }, ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t26 = sext i32 %t22 to i64
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  %t31 = call i64 @__olang_fmt_i64(ptr %t30, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  br label %bb71
bb8:
  %t35 = load { i64, [8 x i64] }, ptr %l1
  %t37 = extractvalue { i64, [8 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 2
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t40, i32 0, i32 0
  %t42 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t42, ptr %l4
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l5, !tbaa !23
  %t48 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, [4 x i64] }, ptr %l4
  %t56 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s4, ptr %t52, { i64, [4 x i64] } %t53)
  store { i64, ptr } %t56, ptr %l42
  br label %bb12
bb12:
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t69 = sext i32 %t57 to i64
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = sext i32 %t58 to i64
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t59, i64 %t60)
  %t80 = getelementptr i8, ptr %t79, i64 %t60
  call void @olang_textcopy(ptr %t80, ptr %t62, i64 %t63)
  %t81 = getelementptr i8, ptr %t80, i64 %t63
  call void @olang_textcopy(ptr %t81, ptr %t65, i64 %t66)
  %t82 = getelementptr i8, ptr %t81, i64 %t66
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t69)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t76)
  %t87 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t79, 1
  store { i64, ptr } %t88, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb13:
  %t90 = load { i64, [8 x i64] }, ptr %l1
  %t92 = extractvalue { i64, [8 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 3
  br i1 %t93, label %bb14, label %bb15
bb14:
  %t95 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t96 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t95, i32 0, i32 0
  %t97 = load { i64, [4 x i64] }, ptr %t96
  store { i64, [4 x i64] } %t97, ptr %l7
  %t99 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t99, i32 0, i32 1
  %t101 = load %"compiler/mir:Range", ptr %t100
  store %"compiler/mir:Range" %t101, ptr %l8
  %t103 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t104 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t103, i32 0, i32 2
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l9, !tbaa !23
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, [4 x i64] }, ptr %l7
  %t111 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s6, ptr %t107, { i64, [4 x i64] } %t108)
  store { i64, ptr } %t111, ptr %l53
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/mir:Range", ptr %l8
  %t116 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %s6, ptr %t112, %"compiler/mir:Range" %t113)
  store { i64, ptr } %t116, ptr %l56
  br label %bb18
bb18:
  %t117 = load i32, ptr %l9, !tbaa !23
  %t118 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = sext i32 %t117 to i64
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t133, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t121, i64 %t122)
  %t140 = getelementptr i8, ptr %t139, i64 %t122
  call void @olang_textcopy(ptr %t140, ptr %t124, i64 %t125)
  %t141 = getelementptr i8, ptr %t140, i64 %t125
  call void @olang_textcopy(ptr %t141, ptr %t128, i64 %t129)
  %t142 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t135)
  %t145 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t138, 1
  store { i64, ptr } %t146, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb19:
  %t148 = load { i64, [8 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [8 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb20, label %bb21
bb20:
  %t153 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32 }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l10, !tbaa !23
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l62, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/mir:Fn", ptr %t158, i32 0, i32 14
  %t161 = load i32, ptr %l10, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t164 = load ptr, ptr @__olang_prog_scope
  %t167 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t164, ptr %t160, i64 %t163)
  store %"compiler/mir:Call" %t167, ptr %l67
  br label %bb23
bb23:
  %t168 = load ptr, ptr %l62, !tbaa !29
  %t169 = load %"compiler/mir:Call", ptr %l67
  %t170 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %v1, ptr %t168, %"compiler/mir:Call" %t169)
  store { i64, ptr } %t170, ptr %l68
  br label %bb24
bb24:
  %t171 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t171, ptr %l25, !tbaa !27
  br label %bb71
bb25:
  %t172 = load { i64, [8 x i64] }, ptr %l1
  %t174 = extractvalue { i64, [8 x i64] } %t172, 0
  %t175 = icmp eq i64 %t174, 6
  br i1 %t175, label %bb26, label %bb27
bb26:
  %t177 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32 }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l11, !tbaa !23
  br label %bb28
bb27:
  br label %bb31
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l72, !tbaa !29
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr %"compiler/mir:Fn", ptr %t182, i32 0, i32 14
  %t185 = load i32, ptr %l11, !tbaa !23
  %t187 = sext i32 %t185 to i64
  %t188 = load ptr, ptr @__olang_prog_scope
  %t191 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t188, ptr %t184, i64 %t187)
  store %"compiler/mir:Call" %t191, ptr %l77
  br label %bb29
bb29:
  %t192 = load ptr, ptr %l72, !tbaa !29
  %t193 = load %"compiler/mir:Call", ptr %l77
  %t194 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecall(ptr %v0, ptr %s9, ptr %t192, %"compiler/mir:Call" %t193)
  store { i64, ptr } %t194, ptr %l78
  br label %bb30
bb30:
  %t195 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t197 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t195, i64 %t196)
  %t202 = getelementptr i8, ptr %t201, i64 %t196
  call void @olang_textcopy(ptr %t202, ptr %t198, i64 %t199)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t201, 1
  store { i64, ptr } %t204, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb31:
  %t206 = load { i64, [8 x i64] }, ptr %l1
  %t208 = extractvalue { i64, [8 x i64] } %t206, 0
  %t209 = icmp eq i64 %t208, 5
  br i1 %t209, label %bb32, label %bb33
bb32:
  %t211 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t211, i32 0, i32 1
  %t213 = load { i64, [4 x i64] }, ptr %t212
  store { i64, [4 x i64] } %t213, ptr %l12
  br label %bb34
bb33:
  br label %bb39
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load { i64, [4 x i64] }, ptr %l12
  %t217 = extractvalue { i64, [4 x i64] } %t215, 0
  %t218 = icmp eq i64 %t217, 0
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb35, label %bb36
bb35:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load { i64, [4 x i64] }, ptr %l12
  %t226 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s11, ptr %t222, { i64, [4 x i64] } %t223)
  store { i64, ptr } %t226, ptr %l89
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb38
bb37:
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t229 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t227, i64 %t228)
  %t234 = getelementptr i8, ptr %t233, i64 %t228
  call void @olang_textcopy(ptr %t234, ptr %t230, i64 %t231)
  %t235 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t233, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l86, !tbaa !27
  br label %bb38
bb38:
  %t245 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t247 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  store { i64, ptr } %t254, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb39:
  %t256 = load { i64, [8 x i64] }, ptr %l1
  %t258 = extractvalue { i64, [8 x i64] } %t256, 0
  %t259 = icmp eq i64 %t258, 7
  br i1 %t259, label %bb40, label %bb41
bb40:
  %t261 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t261, i32 0, i32 1
  %t263 = load { i64, [4 x i64] }, ptr %t262
  store { i64, [4 x i64] } %t263, ptr %l13
  br label %bb42
bb41:
  br label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s14
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, [4 x i64] }, ptr %l13
  %t269 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s14, ptr %t265, { i64, [4 x i64] } %t266)
  store { i64, ptr } %t269, ptr %l98
  br label %bb43
bb43:
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t272 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = add i64 %t271, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t270, i64 %t271)
  %t277 = getelementptr i8, ptr %t276, i64 %t271
  call void @olang_textcopy(ptr %t277, ptr %t273, i64 %t274)
  %t278 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t276, 1
  store { i64, ptr } %t279, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb44:
  %t281 = load { i64, [8 x i64] }, ptr %l1
  %t283 = extractvalue { i64, [8 x i64] } %t281, 0
  %t284 = icmp eq i64 %t283, 11
  br i1 %t284, label %bb45, label %bb46
bb45:
  %t286 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t287 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t286, i32 0, i32 1
  %t288 = load { i64, [4 x i64] }, ptr %t287
  store { i64, [4 x i64] } %t288, ptr %l14
  %t290 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t290, i32 0, i32 2
  %t292 = load i32, ptr %t291
  store i32 %t292, ptr %l15, !tbaa !23
  %t294 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t294, i32 0, i32 3
  %t296 = load %"compiler/mir:Range", ptr %t295
  store %"compiler/mir:Range" %t296, ptr %l16
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s16
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, [4 x i64] }, ptr %l14
  %t302 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s16, ptr %t298, { i64, [4 x i64] } %t299)
  store { i64, ptr } %t302, ptr %l107
  br label %bb48
bb48:
  %t303 = load i32, ptr %l15, !tbaa !23
  %t304 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 1
  %t305 = load i32, ptr %t304, !tbaa !23
  %t306 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t308 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t316 = sext i32 %t303 to i64
  %t317 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t318 = add i64 %t314, %t317
  %t319 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t323 = sext i32 %t305 to i64
  %t324 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t325 = add i64 %t321, %t324
  %t326 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t325)
  call void @olang_textcopy(ptr %t326, ptr %t306, i64 %t307)
  %t327 = getelementptr i8, ptr %t326, i64 %t307
  call void @olang_textcopy(ptr %t327, ptr %t309, i64 %t310)
  %t328 = getelementptr i8, ptr %t327, i64 %t310
  call void @olang_textcopy(ptr %t328, ptr %t312, i64 %t313)
  %t329 = getelementptr i8, ptr %t328, i64 %t313
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t316)
  %t331 = getelementptr i8, ptr %t329, i64 %t317
  call void @olang_textcopy(ptr %t331, ptr %t319, i64 %t320)
  %t332 = getelementptr i8, ptr %t331, i64 %t320
  %t333 = call i64 @__olang_fmt_i64(ptr %t332, i64 %t323)
  %t334 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t326, 1
  store { i64, ptr } %t335, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb71
bb49:
  %t337 = load { i64, [8 x i64] }, ptr %l1
  %t339 = extractvalue { i64, [8 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 8
  br i1 %t340, label %bb50, label %bb51
bb50:
  %t342 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t342, i32 0, i32 1
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l17, !tbaa !23
  %t346 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t347 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t346, i32 0, i32 2
  %t348 = load i32, ptr %t347
  store i32 %t348, ptr %l18, !tbaa !23
  %t350 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t350, i32 0, i32 3
  %t352 = load i32, ptr %t351
  store i32 %t352, ptr %l19, !tbaa !23
  %t354 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t354, i32 0, i32 4
  %t356 = load i32, ptr %t355
  store i32 %t356, ptr %l20, !tbaa !23
  br label %bb52
bb51:
  br label %bb56
bb52:
  store %olang.scope zeroinitializer, ptr %s18
  %t358 = load i32, ptr %l17, !tbaa !23
  store i32 %t358, ptr %l117, !tbaa !23
  %t359 = load i32, ptr %l18, !tbaa !23
  store i32 %t359, ptr %l118, !tbaa !23
  %t360 = load i32, ptr %l20, !tbaa !23
  %t361 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t364 = icmp ne i32 %t360, %t361
  br i1 %t364, label %bb53, label %bb54
bb53:
  %t366 = load i32, ptr %l19, !tbaa !23
  %t367 = load i32, ptr %l20, !tbaa !23
  %t368 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t371 = sext i32 %t366 to i64
  %t372 = call i64 @__olang_fmt_i64(ptr null, i64 %t371)
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t378 = sext i32 %t367 to i64
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t378)
  %t380 = add i64 %t376, %t379
  %t381 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t380)
  call void @olang_textcopy(ptr %t381, ptr %t368, i64 %t369)
  %t382 = getelementptr i8, ptr %t381, i64 %t369
  %t383 = call i64 @__olang_fmt_i64(ptr %t382, i64 %t371)
  %t384 = getelementptr i8, ptr %t382, i64 %t372
  call void @olang_textcopy(ptr %t384, ptr %t374, i64 %t375)
  %t385 = getelementptr i8, ptr %t384, i64 %t375
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t378)
  %t387 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t381, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  store { i64, ptr } %t395, ptr %l122, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l122, !tbaa !27
  br label %bb55
bb55:
  %t397 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t399 = load i32, ptr %l117, !tbaa !23
  %t400 = sext i32 %t399 to i64
  %t401 = call i64 @__olang_fmt_i64(ptr null, i64 %t400)
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = load i32, ptr %l118, !tbaa !23
  %t407 = sext i32 %t406 to i64
  %t408 = call i64 @__olang_fmt_i64(ptr null, i64 %t407)
  %t409 = add i64 %t405, %t408
  %t410 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t413)
  call void @olang_textcopy(ptr %t414, ptr %t397, i64 %t398)
  %t415 = getelementptr i8, ptr %t414, i64 %t398
  %t416 = call i64 @__olang_fmt_i64(ptr %t415, i64 %t400)
  %t417 = getelementptr i8, ptr %t415, i64 %t401
  call void @olang_textcopy(ptr %t417, ptr %t403, i64 %t404)
  %t418 = getelementptr i8, ptr %t417, i64 %t404
  %t419 = call i64 @__olang_fmt_i64(ptr %t418, i64 %t407)
  %t420 = getelementptr i8, ptr %t418, i64 %t408
  call void @olang_textcopy(ptr %t420, ptr %t411, i64 %t412)
  %t421 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t414, 1
  store { i64, ptr } %t422, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb71
bb56:
  %t424 = load { i64, [8 x i64] }, ptr %l1
  %t426 = extractvalue { i64, [8 x i64] } %t424, 0
  %t427 = icmp eq i64 %t426, 9
  br i1 %t427, label %bb57, label %bb58
bb57:
  %t429 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t430 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t429, i32 0, i32 1
  %t431 = load i32, ptr %t430, !range !{i32 0, i32 16}
  store i32 %t431, ptr %l21
  %t433 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t433, i32 0, i32 2
  %t435 = load { i64, [4 x i64] }, ptr %t434
  store { i64, [4 x i64] } %t435, ptr %l22
  br label %bb59
bb58:
  br label %bb66
bb59:
  store %olang.scope zeroinitializer, ptr %s21
  %t437 = load i32, ptr %l21, !range !{i32 0, i32 16}
  store i32 %t437, ptr %l132
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s22, ptr %l132, i64 0)
  br label %bb60
bb60:
  %t439 = load ptr, ptr %s22
  %t440 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t441 = load i64, ptr %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t439, i64 %t441)
  %t443 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  store { i64, ptr } %t444, ptr %l134, !tbaa !27
  %t445 = getelementptr %olang.builder, ptr %s22, i32 0, i32 3
  %t446 = load ptr, ptr %t445
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %sbgrew.448, label %sbdone.449
sbgrew.448:
  call void @__olang_sb_done(ptr %s22)
  br label %sbdone.449
sbdone.449:
  %t450 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  %t452 = extractvalue { i64, ptr } %t450, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t458 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s21, ptr %s21, { i64, ptr } %t456)
  store { i64, ptr } %t458, ptr %l136
  br label %bb61
bb61:
  %t459 = load { i64, [4 x i64] }, ptr %l22
  %t461 = extractvalue { i64, [4 x i64] } %t459, 0
  %t462 = icmp eq i64 %t461, 0
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb62, label %bb63
bb62:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load { i64, [4 x i64] }, ptr %l22
  %t470 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %s21, ptr %t466, { i64, [4 x i64] } %t467)
  store { i64, ptr } %t470, ptr %l143
  br label %bb64
bb63:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l140, !tbaa !27
  br label %bb65
bb64:
  %t471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t473 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = add i64 %t472, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t471, i64 %t472)
  %t478 = getelementptr i8, ptr %t477, i64 %t472
  call void @olang_textcopy(ptr %t478, ptr %t474, i64 %t475)
  %t479 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t477, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  %t483 = extractvalue { i64, ptr } %t480, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  store { i64, ptr } %t487, ptr %l140, !tbaa !27
  br label %bb65
bb65:
  %t489 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t495, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = add i64 %t494, %t497
  %t499 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t498)
  call void @olang_textcopy(ptr %t499, ptr %t489, i64 %t490)
  %t500 = getelementptr i8, ptr %t499, i64 %t490
  call void @olang_textcopy(ptr %t500, ptr %t492, i64 %t493)
  %t501 = getelementptr i8, ptr %t500, i64 %t493
  call void @olang_textcopy(ptr %t501, ptr %t496, i64 %t497)
  %t502 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t499, 1
  store { i64, ptr } %t503, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb71
bb66:
  %t505 = load { i64, [8 x i64] }, ptr %l1
  %t507 = extractvalue { i64, [8 x i64] } %t505, 0
  %t508 = icmp eq i64 %t507, 10
  br i1 %t508, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l149, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t510, ptr %l25, !tbaa !27
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_8b20d2ead933ce67_842549c98b36ec43)
  unreachable
bb71:
  %t512 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l151, !tbaa !24
  %t514 = load i64, ptr %l151, !tbaa !24
  %t515 = mul i64 %t514, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t515)
  %t517 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  store { i64, ptr } %t518, ptr %l152, !tbaa !27
  %t519 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = load i64, ptr %l151, !tbaa !24
  %t524 = mul i64 %t523, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t520, ptr %t522, i64 %t524, i1 false)
  %t525 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t525, ptr %l25, !tbaa !27
  %t526 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t526, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l25 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca { i64, [4 x i64] }
  %l85 = alloca i32
  %l88 = alloca i32
  %l98 = alloca i32
  %l102 = alloca i1
  %l105 = alloca { i64, ptr }
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l118 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca { i64, ptr }
  %l133 = alloca i32
  %l139 = alloca i32
  %l143 = alloca i1
  %l146 = alloca ptr
  %l149 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l25
  br label %bb1
bb1:
  %t16 = load i32, ptr %l25, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t25 = load ptr, ptr @__olang_prog_scope
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t25, ptr %t23, i32 %t24)
  store i32 %t28, ptr %l31
  br label %bb4
bb3:
  br label %bb34
bb4:
  %t29 = load i32, ptr %l31, !tbaa !23
  store i32 %t29, ptr %l7, !tbaa !23
  %t30 = load i32, ptr %l7, !tbaa !23
  %t32 = icmp eq i32 %t30, 0
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load ptr, ptr @__olang_prog_scope
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t36, ptr %t34, i32 %t35)
  store i32 %t39, ptr %l37
  br label %bb7
bb7:
  %t40 = load i32, ptr %l37, !range !{i32 0, i32 33}
  %t42 = trunc i64 26 to i32
  %t43 = icmp eq i32 %t40, %t42
  %t45 = xor i1 %t43, true
  store i1 %t45, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t47 = load i1, ptr %l34, !tbaa !21
  br i1 %t47, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load i32, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr @__olang_prog_scope
  %t53 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %t50, ptr %t48, i32 %t49)
  store i64 %t53, ptr %l44
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l44, !tbaa !24
  %t57 = icmp ne i64 %t55, %t54
  store i1 %t57, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l41, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l47, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l50
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t69 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t66)
  %t78 = add i64 %t75, %t77
  %t79 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t67, i64 %t68)
  %t83 = getelementptr i8, ptr %t82, i64 %t68
  call void @olang_textcopy(ptr %t83, ptr %t70, i64 %t71)
  %t84 = getelementptr i8, ptr %t83, i64 %t71
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t66)
  %t87 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t87, ptr %t79, i64 %t80)
  %t88 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t82, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t97, { i64, ptr } %t96)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l5, !tbaa !24
  store i64 %t99, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb18, label %bb19
bb18:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb23
bb20:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l61, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb22
bb22:
  %t127 = load i64, ptr %l61, !tbaa !24
  store i64 %t127, ptr %l58, !tbaa !24
  br label %bb23
bb23:
  %t128 = load i64, ptr %l58, !tbaa !24
  store i64 %t128, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load i64, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l13, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l79, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l80, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/mir:Range", ptr %l3
  %t151 = load i64, ptr %l13, !tbaa !24
  %t155 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t149, %"compiler/mir:Range" %t150, i64 %t151)
  store { i64, [4 x i64] } %t155, ptr %l84
  br label %bb28
bb28:
  %t156 = load ptr, ptr %l80, !tbaa !29
  %t157 = load { i64, [4 x i64] }, ptr %l84
  %t158 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t156, { i64, [4 x i64] } %t157)
  store i32 %t158, ptr %l85
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t160 = load i32, ptr %l6, !tbaa !23
  %t161 = load ptr, ptr @__olang_prog_scope
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t161, ptr %t159, i32 %t160)
  store i32 %t164, ptr %l88
  br label %bb30
bb30:
  %t165 = load i64, ptr %l13, !tbaa !24
  %t166 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t169 = call i64 @__olang_fmt_i64(ptr null, i64 %t165)
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t166, i64 %t167)
  %t172 = getelementptr i8, ptr %t171, i64 %t167
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t165)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t171, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t183 = load ptr, ptr %l79, !tbaa !29
  %t184 = load i32, ptr %l85, !tbaa !23
  %t185 = load i32, ptr %l88, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s5, ptr %t183, i32 %t184, i32 %t185, { i64, ptr } %t182)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l12, !tbaa !24
  br label %bb24
bb33:
  %t191 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t191, ptr %rv
  br label %ret
bb34:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/mir:verifier", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t197 = load i32, ptr %l1, !tbaa !23
  %t198 = load ptr, ptr @__olang_prog_scope
  %t201 = call i32 @compiler_2fmir_2eCasesOf(ptr %t198, ptr %t196, i32 %t197)
  store i32 %t201, ptr %l98
  br label %bb35
bb35:
  %t202 = load i32, ptr %l98, !tbaa !23
  store i32 %t202, ptr %l14, !tbaa !23
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/mir:verifier", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t207 = load i32, ptr %l1, !tbaa !23
  %t208 = load ptr, ptr @__olang_prog_scope
  %t211 = call i1 @compiler_2fmir_2eHasCases(ptr %t208, ptr %t206, i32 %t207)
  store i1 %t211, ptr %l102
  br label %bb36
bb36:
  %t212 = load i1, ptr %l102, !tbaa !21
  store i1 %t212, ptr %l15, !tbaa !21
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t214 = load i32, ptr %l14, !tbaa !23
  %t215 = load ptr, ptr @__olang_prog_scope
  %t218 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t215, ptr %s0, ptr %t213, i32 %t214)
  store { i64, ptr } %t218, ptr %l105
  br label %bb37
bb37:
  %t219 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t219, ptr %l16, !tbaa !27
  %t220 = load i1, ptr %l15, !tbaa !21
  br i1 %t220, label %bb38, label %bb39
bb38:
  %t222 = load i64, ptr %l2, !tbaa !24
  %t224 = icmp slt i64 %t222, 0
  br i1 %t224, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb42
bb41:
  %t226 = load i64, ptr %l2, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t232 = icmp sge i64 %t226, %t229
  store i1 %t232, ptr %l109, !tbaa !21
  br label %bb42
bb42:
  %t234 = load i1, ptr %l109, !tbaa !21
  br i1 %t234, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l114, !tbaa !29
  %t236 = load i64, ptr %l2, !tbaa !24
  store i64 %t236, ptr %l115, !tbaa !24
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i32, ptr %l1, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s9, ptr %t237, i32 %t238)
  store { i64, ptr } %t241, ptr %l118
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t242 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = call i64 @__olang_fmt_i64(ptr null, i64 %t244)
  %t246 = add i64 %t243, %t245
  %t247 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t242, i64 %t243)
  %t255 = getelementptr i8, ptr %t254, i64 %t243
  %t256 = call i64 @__olang_fmt_i64(ptr %t255, i64 %t244)
  %t257 = getelementptr i8, ptr %t255, i64 %t245
  call void @olang_textcopy(ptr %t257, ptr %t247, i64 %t248)
  %t258 = getelementptr i8, ptr %t257, i64 %t248
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t254, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l114, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s9, ptr %t268, { i64, ptr } %t267)
  br label %bb46
bb46:
  %t270 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t270, ptr %rv
  br label %ret
bb47:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l122, !tbaa !29
  %t273 = load i32, ptr %l1, !tbaa !23
  store i32 %t273, ptr %l123, !tbaa !23
  %t274 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t274, ptr %l124, !tbaa !27
  %t275 = load i64, ptr %l2, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr i32, ptr %t278, i64 %t275
  %t280 = load i32, ptr %t279, !tbaa !33
  %t282 = icmp ne i32 %t280, 0
  br i1 %t282, label %bb48, label %bb49
bb48:
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t285, ptr %l130, !tbaa !27
  %t286 = load i64, ptr %l2, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr i32, ptr %t289, i64 %t286
  %t291 = load i32, ptr %t290, !tbaa !33
  %t292 = load ptr, ptr @__olang_prog_scope
  %t295 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t292, ptr %t284, i32 %t291)
  store i32 %t295, ptr %l133
  br label %bb50
bb49:
  store i32 0, ptr %l128, !tbaa !23
  br label %bb51
bb50:
  %t296 = load i32, ptr %l133, !tbaa !23
  store i32 %t296, ptr %l128, !tbaa !23
  br label %bb51
bb51:
  %t297 = load %"compiler/mir:Range", ptr %l3
  %t298 = load ptr, ptr %l122, !tbaa !29
  %t299 = load i32, ptr %l123, !tbaa !23
  %t300 = load i32, ptr %l128, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t298, i32 %t299, i32 %t300, %"compiler/mir:Range" %t297)
  br label %bb52
bb52:
  %t302 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t302, ptr %rv
  br label %ret
bb53:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/mir:verifier", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t308 = load i32, ptr %l1, !tbaa !23
  %t309 = load ptr, ptr @__olang_prog_scope
  %t312 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t309, ptr %t307, i32 %t308)
  store i32 %t312, ptr %l139
  br label %bb54
bb54:
  %t313 = load i32, ptr %l139, !tbaa !23
  store i32 %t313, ptr %l17, !tbaa !23
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/mir:verifier", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load i32, ptr %l1, !tbaa !23
  %t319 = load ptr, ptr @__olang_prog_scope
  %t322 = call i1 @compiler_2fmir_2eHasFields(ptr %t319, ptr %t317, i32 %t318)
  store i1 %t322, ptr %l143
  br label %bb55
bb55:
  %t323 = load i1, ptr %l143, !tbaa !21
  %t326 = xor i1 %t323, true
  br i1 %t326, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l146, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l1, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t329, i32 %t330)
  store { i64, ptr } %t333, ptr %l149
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t334 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t336 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t334, i64 %t335)
  %t344 = getelementptr i8, ptr %t343, i64 %t335
  call void @olang_textcopy(ptr %t344, ptr %t337, i64 %t338)
  %t345 = getelementptr i8, ptr %t344, i64 %t338
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t355, { i64, ptr } %t354)
  br label %bb59
bb59:
  %t357 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t357, ptr %rv
  br label %ret
bb60:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l1, !tbaa !23
  %t361 = load i32, ptr %l17, !tbaa !23
  %t362 = load %"compiler/mir:Range", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %t359, i32 %t360, i32 %t361, %"compiler/mir:Range" %t362)
  br label %bb61
bb61:
  %t367 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t367, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l57 = alloca i64
  %l60 = alloca i64
  %l78 = alloca ptr
  %l82 = alloca { i64, [4 x i64] }
  %l83 = alloca i32
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca { i64, ptr }
  %l108 = alloca i64
  %l122 = alloca i32
  %l125 = alloca i32
  %l151 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l24, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr @__olang_prog_scope
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t9, ptr %t7, i32 %t8)
  store i32 %t12, ptr %l27
  br label %bb1
bb1:
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = load ptr, ptr %l24, !tbaa !29
  %t15 = load i32, ptr %l27, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t13, ptr %s0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = load { i64, [7 x i64] }, ptr %l1
  %t20 = extractvalue { i64, [7 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 1
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd)
  unreachable
bb11:
  %t23 = load i1, ptr %l29, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = icmp ne i64 %t26, %t30
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t35 = load i1, ptr %l7, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb14:
  %t37 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = icmp sgt i64 %t40, %t43
  store i1 %t46, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l39, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l37, !tbaa !21
  br i1 %t51, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t61 = sext i32 %t54 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t69 = add i64 %t66, %t68
  %t70 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t58, i64 %t59)
  %t74 = getelementptr i8, ptr %t73, i64 %t59
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t61)
  %t76 = getelementptr i8, ptr %t74, i64 %t62
  call void @olang_textcopy(ptr %t76, ptr %t64, i64 %t65)
  %t77 = getelementptr i8, ptr %t76, i64 %t65
  %t78 = call i64 @__olang_fmt_i64(ptr %t77, i64 %t57)
  %t79 = getelementptr i8, ptr %t77, i64 %t68
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t73, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t52, { i64, ptr } %t88)
  br label %bb20
bb19:
  store i64 0, ptr %l8, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb21, label %bb22
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb21:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb26
bb23:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l60, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t121 = load i64, ptr %l60, !tbaa !24
  store i64 %t121, ptr %l57, !tbaa !24
  br label %bb26
bb26:
  %t122 = load i64, ptr %l57, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb29:
  br label %bb30
bb30:
  %t131 = load i64, ptr %l8, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l13, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/mir:Range", ptr %l3
  %t144 = load i64, ptr %l13, !tbaa !24
  %t148 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t142, %"compiler/mir:Range" %t143, i64 %t144)
  store { i64, [4 x i64] } %t148, ptr %l82
  br label %bb31
bb31:
  %t149 = load ptr, ptr %l78, !tbaa !29
  %t150 = load { i64, [4 x i64] }, ptr %l82
  %t151 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t149, { i64, [4 x i64] } %t150)
  store i32 %t151, ptr %l83
  br label %bb32
bb32:
  %t152 = load i32, ptr %l83, !tbaa !23
  store i32 %t152, ptr %l14, !tbaa !23
  %t153 = load i1, ptr %l7, !tbaa !21
  br i1 %t153, label %bb33, label %bb34
bb33:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t156, ptr %l87, !tbaa !27
  %t157 = load i64, ptr %l13, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %t155, i32 %t162)
  store i1 %t165, ptr %l90
  br label %bb35
bb34:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb36
bb35:
  %t166 = load i1, ptr %l90, !tbaa !21
  store i1 %t166, ptr %l85, !tbaa !21
  br label %bb36
bb36:
  %t167 = load i1, ptr %l85, !tbaa !21
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l14, !tbaa !23
  %t172 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %t168, i32 %t169)
  store i1 %t172, ptr %l94
  br label %bb39
bb38:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb40
bb39:
  %t173 = load i1, ptr %l94, !tbaa !21
  store i1 %t173, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t174 = load i1, ptr %l91, !tbaa !21
  br i1 %t174, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb42:
  br label %bb43
bb43:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l14, !tbaa !23
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l13, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i32, ptr %t181, i64 %t178
  %t183 = load i32, ptr %t182, !tbaa !33
  %t184 = load i64, ptr %l13, !tbaa !24
  %t185 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t188 = call i64 @__olang_fmt_i64(ptr null, i64 %t184)
  %t189 = add i64 %t186, %t188
  %t190 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t185, i64 %t186)
  %t191 = getelementptr i8, ptr %t190, i64 %t186
  %t192 = call i64 @__olang_fmt_i64(ptr %t191, i64 %t184)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t190, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s7, ptr %t175, i32 %t176, i32 %t183, { i64, ptr } %t201)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t206 = load i64, ptr %l12, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l12, !tbaa !24
  br label %bb27
bb46:
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l5, !tbaa !29
  %t211 = load { i64, [7 x i64] }, ptr %l1
  %t212 = load i32, ptr %l2, !tbaa !23
  %t213 = load ptr, ptr @__olang_prog_scope
  %t217 = call i64 @compiler_2fmir_2ePassedCount(ptr %t213, ptr %t210, { i64, [7 x i64] } %t211, i32 %t212)
  store i64 %t217, ptr %l108
  br label %bb48
bb48:
  %t218 = load i64, ptr %l108, !tbaa !24
  store i64 %t218, ptr %l15, !tbaa !24
  %t219 = load i64, ptr %l15, !tbaa !24
  %t220 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t221 = load i32, ptr %t220, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t226 = icmp ne i64 %t219, %t223
  br i1 %t226, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t230 = load i32, ptr %t229, !tbaa !23
  %t231 = load i64, ptr %l15, !tbaa !24
  %t232 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t235 = sext i32 %t230 to i64
  %t236 = call i64 @__olang_fmt_i64(ptr null, i64 %t235)
  %t237 = add i64 %t233, %t236
  %t238 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t232, i64 %t233)
  %t245 = getelementptr i8, ptr %t244, i64 %t233
  %t246 = call i64 @__olang_fmt_i64(ptr %t245, i64 %t235)
  %t247 = getelementptr i8, ptr %t245, i64 %t236
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = getelementptr i8, ptr %t247, i64 %t239
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t231)
  %t250 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t244, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t228, { i64, ptr } %t258)
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb52
bb52:
  store i32 0, ptr %l16, !tbaa !23
  %t261 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t262 = load i32, ptr %t261, !tbaa !23
  store i32 %t262, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t264 = load i32, ptr %l17, !tbaa !23
  %t265 = load i32, ptr %l16, !tbaa !23
  %t268 = icmp sgt i32 %t264, %t265
  br i1 %t268, label %bb53, label %bb54
bb53:
  %t270 = load i32, ptr %l18, !tbaa !23
  %t272 = icmp sgt i32 %t270, 0
  br i1 %t272, label %bb55, label %bb56
bb54:
  store i32 0, ptr %l122, !tbaa !23
  br label %bb58
bb55:
  %t274 = load i32, ptr %l17, !tbaa !23
  %t275 = load i32, ptr %l16, !tbaa !23
  %t278 = sub i32 %t274, %t275
  %t279 = load i32, ptr %l18, !tbaa !23
  %t282 = add i32 %t278, %t279
  %t284 = sub i32 %t282, 1
  %t285 = load i32, ptr %l18, !tbaa !23
  %t288 = sdiv i32 %t284, %t285
  store i32 %t288, ptr %l125, !tbaa !23
  br label %bb57
bb56:
  store i32 0, ptr %l125, !tbaa !23
  br label %bb57
bb57:
  %t290 = load i32, ptr %l125, !tbaa !23
  store i32 %t290, ptr %l122, !tbaa !23
  br label %bb58
bb58:
  %t291 = load i32, ptr %l122, !tbaa !23
  store i32 %t291, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb59
bb59:
  %t292 = load i32, ptr %l20, !tbaa !23
  %t293 = load i32, ptr %l19, !tbaa !23
  %t296 = icmp slt i32 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb60, label %bb61
bb60:
  br label %bb69
bb61:
  br label %bb62
bb62:
  %t300 = load i32, ptr %l16, !tbaa !23
  %t301 = load i32, ptr %l20, !tbaa !23
  %t302 = load i32, ptr %l18, !tbaa !23
  %t305 = mul i32 %t301, %t302
  %t308 = add i32 %t300, %t305
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/mir:verifier", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/mir:Fn", ptr %t313, i32 0, i32 12
  %t316 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = sext i32 %t317 to i64
  %t322 = sext i32 %t308 to i64
  %t325 = add i64 %t319, %t322
  %t326 = load ptr, ptr @__olang_prog_scope
  %t329 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t326, ptr %t315, i64 %t325)
  store { i64, [1 x i64] } %t329, ptr %l151
  br label %bb63
bb63:
  %t330 = load { i64, [1 x i64] }, ptr %l151
  %t332 = extractvalue { i64, [1 x i64] } %t330, 0
  %t333 = icmp eq i64 %t332, 3
  br i1 %t333, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t335 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t335, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t337 = load i32, ptr %l20, !tbaa !23
  %t339 = add i32 %t337, 1
  store i32 %t339, ptr %l20, !tbaa !23
  br label %bb59
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/mir:verifier", ptr %t15, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t17, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t19, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/mir:verifier", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t37 = add i64 %t34, %t36
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t33, i64 %t34)
  %t42 = getelementptr i8, ptr %t41, i64 %t34
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t32)
  %t44 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t44, ptr %t38, i64 %t39)
  %t45 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t41, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t28, { i64, ptr } %t53)
  br label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:verifier", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/mir:verifier", ptr %t59, i32 0, i32 3
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 4
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t62)
  %t71 = add i64 %t68, %t70
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t66)
  %t77 = add i64 %t74, %t76
  %t78 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t67, i64 %t68)
  %t82 = getelementptr i8, ptr %t81, i64 %t68
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t62)
  %t84 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t66)
  %t87 = getelementptr i8, ptr %t85, i64 %t76
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t81, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t58, { i64, ptr } %t96)
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/mir:verifier", ptr %t99, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %a1)
  br label %bb13
bb13:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t107, i8 10)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 9
  %t14 = load ptr, ptr @__olang_prog_scope
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t14, ptr %t13)
  store i64 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t27 = sext i32 %t23 to i64
  %t28 = call i64 @__olang_fmt_i64(ptr null, i64 %t27)
  %t29 = add i64 %t25, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = getelementptr i8, ptr %t30, i64 %t25
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l14 = alloca %"compiler/mir:ScopeInfo"
  %l24 = alloca { i64, [1 x i64] }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:verifier", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 8
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t19, ptr %t15, i64 %t18)
  store %"compiler/mir:ScopeInfo" %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = getelementptr %"compiler/mir:ScopeInfo", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 7}
  %t26 = trunc i64 6 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l5, !tbaa !21
  br label %bb15
bb5:
  %t29 = load { i64, [1 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [1 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/mir:verifier", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/mir:Fn", ptr %t41, i32 0, i32 6
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load ptr, ptr @__olang_prog_scope
  %t48 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %t45, ptr %t43, i64 %t44)
  store { i64, [1 x i64] } %t48, ptr %l24
  br label %bb9
bb9:
  %t49 = load { i64, [1 x i64] }, ptr %l24
  %t51 = extractvalue { i64, [1 x i64] } %t49, 0
  %t52 = icmp eq i64 %t51, 5
  store i1 %t52, ptr %l5, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9c289c76542078e7_53d9d4aa9af07973)
  unreachable
bb15:
  %t54 = load i1, ptr %l5, !tbaa !21
  %t57 = xor i1 %t54, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t59, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i32
  %rv = alloca i32
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t8, ptr %t6, i32 %t7)
  store i1 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i1, ptr %l9, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr @__olang_prog_scope
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %t18, ptr %t15, i32 %a1, i64 %a2)
  store i64 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp ne i64 %t24, %t23
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t34 = load ptr, ptr @__olang_prog_scope
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t34, ptr %t32, i32 %t33)
  store i32 %t37, ptr %l22
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t40 = load ptr, ptr @__olang_prog_scope
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t40, ptr %t38, i32 %t39)
  store i64 %t43, ptr %l25
  br label %bb10
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t45 = load i64, ptr %l25, !tbaa !24
  %t47 = or i64 %t45, %t44
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = load ptr, ptr %l19, !tbaa !29
  %t50 = load i32, ptr %l22, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t48, ptr %t49, i32 %t50, i64 %t47)
  store i32 %t52, ptr %l28
  br label %bb11
bb11:
  %t53 = load i32, ptr %l28, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeReads(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_62f33ceaa6d0d243_a40627fd170062cf)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t6, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t6, ptr %t4, i32 %t5)
  store i32 %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t12 = trunc i64 21 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l12
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t23 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  call void @olang_textcopy(ptr %t30, ptr %t26, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t40, { i64, ptr } %t39)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t42 = load i32, ptr %l1, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l76 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t8, ptr %t6, i32 %t7)
  store i32 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load i32, ptr %l16, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr @__olang_prog_scope
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t15, ptr %t13, i32 %t14)
  store i32 %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t21 = trunc i64 22 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l22, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load ptr, ptr @__olang_prog_scope
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t27, ptr %t25, i32 %t26)
  store i32 %t30, ptr %l25
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t31 = load ptr, ptr @__olang_prog_scope
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = load i32, ptr %l25, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t31, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l28, !tbaa !24
  %t39 = load i64, ptr %l28, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sle i64 %t42, 2305843009213693951
  br i1 %t43, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb9:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = mul i64 %t45, 4
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f7be8aa76db69854_ffaa205b85e46cd8)
  unreachable
bb11:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb16
bb13:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l40, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb15
bb15:
  %t81 = load i64, ptr %l40, !tbaa !24
  store i64 %t81, ptr %l37, !tbaa !24
  br label %bb16
bb16:
  %t82 = load i64, ptr %l37, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l1, !tbaa !23
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l62, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t116 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t102, i32 %t103, i64 %t104, i32 %t111)
  store i32 %t116, ptr %l65
  br label %bb21
bb21:
  %t117 = load i32, ptr %l65, !tbaa !23
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t118
  store i32 %t117, ptr %t121, !tbaa !33
  br label %bb22
bb22:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l10, !tbaa !24
  br label %bb17
bb23:
  %t126 = load ptr, ptr %l2, !tbaa !29
  store ptr %t126, ptr %l68, !tbaa !29
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = load ptr, ptr @__olang_prog_scope
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %t129, ptr %s1, ptr %t127, { i64, ptr } %t128)
  store i32 %t132, ptr %l71
  br label %bb24
bb24:
  %t133 = load ptr, ptr @__olang_prog_scope
  %t134 = load ptr, ptr %l68, !tbaa !29
  %t135 = load i32, ptr %l71, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %t133, ptr %t134, i32 %t135)
  store i32 %t136, ptr %l72
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t137 = load i32, ptr %l72, !tbaa !23
  store i32 %t137, ptr %rv
  br label %ret
bb26:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l1, !tbaa !23
  %t140 = load i32, ptr %l3, !tbaa !23
  %t144 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuiltPart(ptr %v0, ptr %t138, i32 %t139, i64 0, i32 %t140)
  store i32 %t144, ptr %l76
  br label %bb27
bb27:
  %t145 = load i32, ptr %l76, !tbaa !23
  store i32 %t145, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load ptr, ptr @__olang_prog_scope
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t9, ptr %t7, i32 %t8)
  store i32 %t12, ptr %l10
  br label %bb1
bb1:
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t13, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load ptr, ptr @__olang_prog_scope
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t21, ptr %t19, i32 %t20)
  store i32 %t24, ptr %l16
  br label %bb5
bb4:
  %t25 = load i32, ptr %l1, !tbaa !23
  store i32 %t25, ptr %l12, !tbaa !23
  br label %bb7
bb5:
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i32, ptr %l16, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t27, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l17
  br label %bb6
bb6:
  %t31 = load i32, ptr %l17, !tbaa !23
  store i32 %t31, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l12, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t33, i32 %t32)
  store i32 %t37, ptr %l21
  br label %bb8
bb8:
  %t38 = load i32, ptr %l21, !tbaa !23
  store i32 %t38, ptr %l4, !tbaa !23
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp ne i32 %t39, %t40
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr @__olang_prog_scope
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t48, ptr %t46, i32 %t47)
  store i32 %t51, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t52 = load ptr, ptr @__olang_prog_scope
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t52, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l30
  br label %bb12
bb12:
  %t56 = load i32, ptr %l30, !tbaa !23
  %t57 = icmp eq i32 %t56, 7
  store i1 %t57, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l25, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l14, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/mir:verifier", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 20
  %t56 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = sext i32 %t48 to i64
  %t65 = add i64 %t59, %t62
  %t66 = load ptr, ptr @__olang_prog_scope
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %t66, ptr %t55, i64 %t65)
  store i32 %t69, ptr %l43
  br label %bb11
bb11:
  %t70 = load i32, ptr %l43, !tbaa !23
  store i32 %t70, ptr %l9, !tbaa !23
  %t71 = load i32, ptr %l9, !tbaa !23
  %t73 = icmp slt i32 %t71, 0
  br i1 %t73, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb14
bb13:
  %t75 = load i32, ptr %l9, !tbaa !23
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = trunc i64 %t76 to i32
  %t81 = icmp sge i32 %t75, %t78
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = load i32, ptr %l9, !tbaa !23
  %t87 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t85)
  %t91 = add i64 %t88, %t90
  %t92 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t96 = sext i32 %t86 to i64
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t87, i64 %t88)
  %t103 = getelementptr i8, ptr %t102, i64 %t88
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t85)
  %t105 = getelementptr i8, ptr %t103, i64 %t90
  call void @olang_textcopy(ptr %t105, ptr %t92, i64 %t93)
  %t106 = getelementptr i8, ptr %t105, i64 %t93
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t96)
  %t108 = getelementptr i8, ptr %t106, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t102, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t84, { i64, ptr } %t117)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t120 = load i32, ptr %l7, !tbaa !23
  %t122 = add i32 %t120, 1
  store i32 %t122, ptr %l7, !tbaa !23
  br label %bb7
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i64
  %l10 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:verifier", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t14 = load ptr, ptr @__olang_prog_scope
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t14, ptr %t13)
  store i64 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t27 = sext i32 %t23 to i64
  %t28 = call i64 @__olang_fmt_i64(ptr null, i64 %t27)
  %t29 = add i64 %t25, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = getelementptr i8, ptr %t30, i64 %t25
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } %t41)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca %"compiler/mir:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 7
  %t9 = sext i32 %a1 to i64
  %t10 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t10, ptr %t6, i64 %t9)
  store %"compiler/mir:Local" %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/mir:Local", ptr %l7, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ename(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t13 = sext i32 %t9 to i64
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = getelementptr i8, ptr %t16, i64 %t11
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t13)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l11, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l57 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load ptr, ptr @__olang_prog_scope
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t9, ptr %t7, i32 %t8)
  store i32 %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t13, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l4, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load ptr, ptr @__olang_prog_scope
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t21, ptr %t19, i32 %t20)
  store i32 %t24, ptr %l18
  br label %bb5
bb4:
  %t25 = load i32, ptr %l1, !tbaa !23
  store i32 %t25, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t27, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l14, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t33, i32 %t32)
  store i32 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i32, ptr %l23, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb12
bb10:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t47 = load ptr, ptr @__olang_prog_scope
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t47, ptr %t45, i32 %t46)
  store i32 %t50, ptr %l30
  br label %bb11
bb11:
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = icmp ne i32 %t51, 0
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l35
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t61 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t63 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = add i64 %t62, %t65
  %t67 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t61, i64 %t62)
  %t71 = getelementptr i8, ptr %t70, i64 %t62
  call void @olang_textcopy(ptr %t71, ptr %t64, i64 %t65)
  %t72 = getelementptr i8, ptr %t71, i64 %t65
  call void @olang_textcopy(ptr %t72, ptr %t67, i64 %t68)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } %t74, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t82 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t82, { i64, ptr } %t81)
  br label %bb16
bb16:
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t84, ptr %rv
  br label %ret
bb17:
  %t86 = load ptr, ptr %l4, !tbaa !29
  store ptr %t86, ptr %l39, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  store ptr %t87, ptr %l40, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t88, { i64, [4 x i64] } %a2)
  store i32 %t92, ptr %l43
  br label %bb18
bb18:
  %t93 = load ptr, ptr @__olang_prog_scope
  %t94 = load ptr, ptr %l40, !tbaa !29
  %t95 = load i32, ptr %l43, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t93, ptr %t94, i32 %t95)
  store i32 %t96, ptr %l44
  br label %bb19
bb19:
  %t97 = load ptr, ptr @__olang_prog_scope
  %t98 = load ptr, ptr %l39, !tbaa !29
  %t99 = load i32, ptr %l44, !tbaa !23
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t97, ptr %t98, i32 %t99)
  store i1 %t100, ptr %l45
  br label %bb20
bb20:
  %t101 = load i1, ptr %l45, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t104, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t106 = load { i64, [4 x i64] }, ptr %l3
  %t108 = extractvalue { i64, [4 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 0
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l51, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [4 x i64] }, ptr %l3
  %t118 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t114, { i64, [4 x i64] } %t115)
  store i32 %t118, ptr %l54
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t120 = load i32, ptr %l6, !tbaa !23
  %t121 = load ptr, ptr @__olang_prog_scope
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t121, ptr %t119, i32 %t120)
  store i32 %t124, ptr %l57
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l51, !tbaa !29
  %t126 = load i32, ptr %l54, !tbaa !23
  %t127 = load i32, ptr %l57, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s4, ptr %t125, i32 %t126, i32 %t127, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t128 = load i32, ptr %l1, !tbaa !23
  store i32 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i64
  %l20 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t10, %"compiler/mir:Lvalue" %t11)
  br label %bb4
bb4:
  br label %bb22
bb5:
  %t14 = load { i64, [4 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [4 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 3
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = icmp slt i32 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb12
bb10:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/mir:verifier", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/mir:Fn", ptr %t33, i32 0, i32 19
  %t36 = load ptr, ptr @__olang_prog_scope
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %t36, ptr %t35)
  store i64 %t38, ptr %l20
  br label %bb11
bb11:
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = icmp sge i64 %t39, %t40
  store i1 %t41, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l14, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t46 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t49 = sext i32 %t45 to i64
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t49)
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t49)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t52, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } %t56, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t44, { i64, ptr } %t63)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_293fa35c34966465_23dfef653c6d5c71)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i32
  %l4 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  br label %bb16
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Lvalue", ptr %t14
  store %"compiler/mir:Lvalue" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t18 = load %"compiler/mir:Lvalue", ptr %l2
  %t21 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t18)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb16
bb9:
  %t23 = load { i64, [4 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [4 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb14
bb11:
  %t32 = load { i64, [4 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [4 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 3
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9)
  unreachable
bb16:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l8 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t8 = trunc i64 3 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t11 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t13 = trunc i64 4 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t23 = trunc i64 6 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp eq i32 %t27, 2
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb21
bb10:
  %t31 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t33 = trunc i64 0 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t36 = load i32, ptr %l1, !range !{i32 0, i32 49}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t41 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l8, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97)
  unreachable
bb21:
  %t46 = load i1, ptr %l8, !tbaa !21
  %t49 = xor i1 %t46, true
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t52, ptr %l28
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s5, ptr %l28, i64 0)
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t54 = load ptr, ptr %s5
  %t55 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l30, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.64
sbdone.64:
  %t65 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s4, ptr %s4, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l32
  br label %bb25
bb25:
  %t74 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t76 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t78 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t86 = sext i32 %t75 to i64
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t76, i64 %t77)
  %t93 = getelementptr i8, ptr %t92, i64 %t77
  call void @olang_textcopy(ptr %t93, ptr %t79, i64 %t80)
  %t94 = getelementptr i8, ptr %t93, i64 %t80
  call void @olang_textcopy(ptr %t94, ptr %t82, i64 %t83)
  %t95 = getelementptr i8, ptr %t94, i64 %t83
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t86)
  %t97 = getelementptr i8, ptr %t95, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t89, i64 %t90)
  %t98 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t92, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } %t106)
  br label %bb26
bb26:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  store i32 %t109, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l4, !tbaa !29
  store ptr %t111, ptr %l37, !tbaa !29
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t113 = load i32, ptr %l2, !tbaa !23
  %t114 = load ptr, ptr @__olang_prog_scope
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t114, ptr %t112, i32 %t113)
  store i32 %t117, ptr %l40
  br label %bb28
bb28:
  %t118 = load ptr, ptr @__olang_prog_scope
  %t119 = load ptr, ptr %l37, !tbaa !29
  %t120 = load i32, ptr %l40, !tbaa !23
  %t121 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t118, ptr %t119, i32 %t120)
  store i1 %t121, ptr %l41
  br label %bb29
bb29:
  %t122 = load i1, ptr %l41, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l43, !tbaa !29
  %t126 = load i32, ptr %l1, !range !{i32 0, i32 49}
  store i32 %t126, ptr %l44
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s8, ptr %l44, i64 0)
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t128 = load ptr, ptr %s8
  %t129 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t130 = load i64, ptr %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t128, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l46, !tbaa !27
  %t134 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t135 = load ptr, ptr %t134
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %sbgrew.137, label %sbdone.138
sbgrew.137:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.138
sbdone.138:
  %t139 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t147 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t145)
  store { i64, ptr } %t147, ptr %l48
  br label %bb33
bb33:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s7, ptr %t148, i32 %t149)
  store { i64, ptr } %t152, ptr %l51
  br label %bb34
bb34:
  %t153 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t155 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = add i64 %t161, %t164
  %t166 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t153, i64 %t154)
  %t170 = getelementptr i8, ptr %t169, i64 %t154
  call void @olang_textcopy(ptr %t170, ptr %t156, i64 %t157)
  %t171 = getelementptr i8, ptr %t170, i64 %t157
  call void @olang_textcopy(ptr %t171, ptr %t159, i64 %t160)
  %t172 = getelementptr i8, ptr %t171, i64 %t160
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t166, i64 %t167)
  %t174 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t169, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t183 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s7, ptr %t183, { i64, ptr } %t182)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t185 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t185, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca %"compiler/mir:Range"
  %l19 = alloca i64
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l10
  br label %bb4
bb4:
  br label %bb15
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_70d66502dd431e07_8b33d36aabf56353)
  unreachable
bb15:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t27 = load %"compiler/mir:Range", ptr %t26
  store %"compiler/mir:Range" %t27, ptr %l15
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/mir:verifier", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/mir:Fn", ptr %t31, i32 0, i32 10
  %t34 = load ptr, ptr @__olang_prog_scope
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %t34, ptr %t33)
  store i64 %t36, ptr %l19
  br label %bb16
bb16:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load %"compiler/mir:Range", ptr %l15
  %t39 = load i64, ptr %l19, !tbaa !24
  %t40 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s0, ptr %t37, %"compiler/mir:Range" %t38, i64 %t39, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t40, ptr %l20
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i32
  %l66 = alloca { i64, [1 x i64] }
  %l67 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l19
  br label %bb4
bb4:
  %t18 = load i32, ptr %l19, !tbaa !23
  store i32 %t18, ptr %l13, !tbaa !23
  br label %bb14
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64, i32, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4, !tbaa !23
  store i32 %t28, ptr %l13, !tbaa !23
  br label %bb14
bb9:
  %t30 = load { i64, [2 x i64] }, ptr %l2
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t35, ptr %l13, !tbaa !23
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2986d82de8391aaf_d61db5ce8081183b)
  unreachable
bb14:
  %t37 = load i32, ptr %l13, !tbaa !23
  store i32 %t37, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  %t38 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t39 = getelementptr %"compiler/mir:Range", ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  store i32 %t40, ptr %l7, !tbaa !23
  store i32 1, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l7, !tbaa !23
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = icmp sgt i32 %t42, %t43
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load i32, ptr %l8, !tbaa !23
  %t50 = icmp sgt i32 %t48, 0
  br i1 %t50, label %bb17, label %bb18
bb16:
  store i32 0, ptr %l31, !tbaa !23
  br label %bb20
bb17:
  %t52 = load i32, ptr %l7, !tbaa !23
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = sub i32 %t52, %t53
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = add i32 %t56, %t57
  %t62 = sub i32 %t60, 1
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = sdiv i32 %t62, %t63
  store i32 %t66, ptr %l34, !tbaa !23
  br label %bb19
bb18:
  store i32 0, ptr %l34, !tbaa !23
  br label %bb19
bb19:
  %t68 = load i32, ptr %l34, !tbaa !23
  store i32 %t68, ptr %l31, !tbaa !23
  br label %bb20
bb20:
  %t69 = load i32, ptr %l31, !tbaa !23
  store i32 %t69, ptr %l9, !tbaa !23
  store i32 0, ptr %l10, !tbaa !23
  br label %bb21
bb21:
  %t70 = load i32, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l9, !tbaa !23
  %t74 = icmp slt i32 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t79 = load i32, ptr %l10, !tbaa !23
  %t80 = load i32, ptr %l8, !tbaa !23
  %t83 = mul i32 %t79, %t80
  %t86 = add i32 %t78, %t83
  store i32 %t86, ptr %l11, !tbaa !23
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = icmp eq i32 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i32, ptr %l5, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load i32, ptr %l5, !tbaa !23
  store i32 %t97, ptr %l57, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/mir:verifier", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/mir:Fn", ptr %t101, i32 0, i32 10
  %t104 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t105 = getelementptr %"compiler/mir:Range", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t109 = load i32, ptr %l11, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = add i64 %t108, %t111
  %t115 = load ptr, ptr @__olang_prog_scope
  %t118 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t115, ptr %t103, i64 %t114)
  store { i64, [1 x i64] } %t118, ptr %l66
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l56, !tbaa !29
  %t120 = load i32, ptr %l57, !tbaa !23
  %t121 = load { i64, [1 x i64] }, ptr %l66
  %t122 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprojected(ptr %v0, ptr %t119, i32 %t120, { i64, [1 x i64] } %t121)
  store i32 %t122, ptr %l67
  br label %bb29
bb29:
  %t123 = load i32, ptr %l67, !tbaa !23
  store i32 %t123, ptr %l5, !tbaa !23
  br label %bb30
bb30:
  %t124 = load i32, ptr %l10, !tbaa !23
  %t126 = add i32 %t124, 1
  store i32 %t126, ptr %l10, !tbaa !23
  br label %bb21
bb31:
  %t128 = load i32, ptr %l5, !tbaa !23
  store i32 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2epop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 17
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/mir:verifier", ptr %t9, i32 0, i32 17
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t19, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %t22
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  store i32 %t35, ptr %l21, !tbaa !23
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/mir:verifier", ptr %t37, i32 0, i32 17
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/mir:verifier", ptr %t40, i32 0, i32 17
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l27
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t51 = sext i32 %t46 to i64
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t47, 1
  %t59 = extractvalue { i64, ptr } %t47, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t51)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  call void @olang_textcopy(ptr %t68, ptr %t58, i64 %t59)
  %t69 = getelementptr i8, ptr %t68, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } %t78)
  br label %bb15
bb12:
  %t81 = load i64, ptr %l27, !tbaa !24
  %t82 = sub i64 %t81, 1
  %t83 = load ptr, ptr %l24, !tbaa !29
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t83, i64 %t82)
  store i32 %t85, ptr %l29
  br label %bb13
bb13:
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t88 = load i32, ptr %l21, !tbaa !23
  %t89 = sext i32 %t88 to i64
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load i32, ptr %l29, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t86, i64 %t87)
  %t110 = getelementptr i8, ptr %t109, i64 %t87
  %t111 = call i64 @__olang_fmt_i64(ptr %t110, i64 %t89)
  %t112 = getelementptr i8, ptr %t110, i64 %t90
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t96, i64 %t97)
  %t114 = getelementptr i8, ptr %t113, i64 %t97
  call void @olang_textcopy(ptr %t114, ptr %t99, i64 %t100)
  %t115 = getelementptr i8, ptr %t114, i64 %t100
  %t116 = call i64 @__olang_fmt_i64(ptr %t115, i64 %t103)
  %t117 = getelementptr i8, ptr %t115, i64 %t104
  call void @olang_textcopy(ptr %t117, ptr %t106, i64 %t107)
  %t118 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t109, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t127, { i64, ptr } %t126)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  br label %ret
bb17:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/mir:verifier", ptr %t129, i32 0, i32 17
  %t133 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t131)
  %t134 = extractvalue { i32, i32 } %t133, 1
  %t135 = extractvalue { i32, i32 } %t133, 0
  store i32 %t135, ptr %l41
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb19, label %ok.137, !prof !99
ok.137:
  store i32 %t134, ptr %l40
  br label %bb18
bb18:
  %t138 = load i32, ptr %l40, !tbaa !23
  store i32 %t138, ptr %l37, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_check_failed(ptr @olang_loc_525ae97147cf6b9b_c46e40fbd793c77f)
  unreachable
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [21 x i64] }
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca ptr
  %l49 = alloca %"compiler/mir:BasicBlock"
  %l51 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l71 = alloca %"compiler/mir:BasicBlock"
  %l73 = alloca %"compiler/mir:BasicBlock"
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca { i64, [21 x i64] }
  %l83 = alloca { i64, [21 x i64] }
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca i64
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  %t7 = load ptr, ptr @__olang_prog_scope
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t7, ptr %t6)
  store i64 %t9, ptr %l25
  br label %bb1
bb1:
  %t10 = load i64, ptr %l25, !tbaa !24
  store i64 %t10, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l26, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l27, !tbaa !24
  %t13 = load i64, ptr %l27, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l27, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = load ptr, ptr %l26, !tbaa !29
  %t23 = getelementptr %"compiler/mir:verifier", ptr %t22, i32 0, i32 13
  store { i64, ptr } %t20, ptr %t23, !tbaa !27
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l30
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608)
  unreachable
bb4:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 0)
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/mir:verifier", ptr %t27, i32 0, i32 13
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l33, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i1, ptr %t32, i64 0
  store i1 true, ptr %t33, !tbaa !31
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  store i64 %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb61
bb9:
  br label %bb10
bb10:
  %t42 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2)
  %t43 = extractvalue { i32, i32 } %t42, 1
  %t44 = extractvalue { i32, i32 } %t42, 0
  store i32 %t44, ptr %l41
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb12, label %ok.46, !prof !99
ok.46:
  store i32 %t43, ptr %l40
  br label %bb11
bb11:
  %t47 = load i32, ptr %l40, !tbaa !23
  store i32 %t47, ptr %l38, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_check_failed(ptr @olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6)
  unreachable
bb14:
  %t48 = load i32, ptr %l38, !tbaa !23
  store i32 %t48, ptr %l3, !tbaa !23
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l42
  br label %bb15
bb15:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/mir:verifier", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/mir:Fn", ptr %t55, i32 0, i32 9
  %t58 = load i32, ptr %l3, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t61 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t61, ptr %s3, ptr %t57, i64 %t60)
  store %"compiler/mir:BasicBlock" %t64, ptr %l49
  br label %bb16
bb16:
  %t65 = getelementptr %"compiler/mir:BasicBlock", ptr %l49, i32 0, i32 1
  %t66 = load { i64, [8 x i64] }, ptr %t65
  %t67 = load ptr, ptr %l43, !tbaa !29
  %t69 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %s3, ptr %t67, { i64, [8 x i64] } %t66)
  store { i64, ptr } %t69, ptr %l51
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 4
  %t74 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l59, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t96)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb18
bb24:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/mir:Fn", ptr %t108, i32 0, i32 9
  %t111 = load i32, ptr %l3, !tbaa !23
  %t113 = sext i32 %t111 to i64
  %t114 = load ptr, ptr @__olang_prog_scope
  %t117 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t114, ptr %s6, ptr %t110, i64 %t113)
  store %"compiler/mir:BasicBlock" %t117, ptr %l71
  br label %bb25
bb25:
  %t119 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %s6, ptr %l71)
  store %"compiler/mir:BasicBlock" %t119, ptr %l73
  br label %bb26
bb26:
  %t120 = getelementptr %"compiler/mir:BasicBlock", ptr %l73, i32 0, i32 0
  store ptr %t120, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t122 = load i64, ptr %l10, !tbaa !24
  store i64 %t122, ptr %l75, !tbaa !24
  %t123 = load ptr, ptr %l9, !tbaa !29
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s6, ptr %t123)
  store i64 %t125, ptr %l77
  br label %bb28
bb28:
  %t126 = load i64, ptr %l75, !tbaa !24
  %t127 = load i64, ptr %l77, !tbaa !24
  %t128 = icmp slt i64 %t126, %t127
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb29, label %bb30
bb29:
  br label %bb47
bb30:
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l9, !tbaa !29
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s6, ptr %t132, i64 %t133)
  store { i64, [21 x i64] } %t136, ptr %l82
  br label %bb32
bb32:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l82, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %l11, i64 176, i1 false)
  %t137 = load { i64, [21 x i64] }, ptr %l83
  %t138 = extractvalue { i64, [21 x i64] } %t137, 0
  %t139 = icmp eq i64 %t138, 14
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t141 = getelementptr { i64, [21 x i64] }, ptr %l11, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load i32, ptr %t142
  store i32 %t143, ptr %l12, !tbaa !23
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t145 = load i32, ptr %l12, !tbaa !23
  %t146 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t149 = icmp ne i32 %t145, %t146
  br i1 %t149, label %bb36, label %bb37
bb36:
  %t151 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %l4, i32 %t151)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_7127dab5ce57c749_b077692428e4994d)
  unreachable
bb45:
  br label %bb46
bb46:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb27
bb47:
  call void @__olang_scope_close(ptr %s6)
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t159 = load i64, ptr %l14, !tbaa !24
  store i64 %t159, ptr %l94, !tbaa !24
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t160)
  store i64 %t162, ptr %l96
  br label %bb49
bb49:
  %t163 = load i64, ptr %l94, !tbaa !24
  %t164 = load i64, ptr %l96, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb50, label %bb51
bb50:
  br label %bb59
bb51:
  br label %bb52
bb52:
  %t169 = load ptr, ptr %l13, !tbaa !29
  %t170 = load i64, ptr %l14, !tbaa !24
  %t173 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %s1, ptr %t169, i64 %t170)
  store i32 %t173, ptr %l101
  br label %bb53
bb53:
  %t174 = load i32, ptr %l101, !tbaa !23
  store i32 %t174, ptr %l15, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/mir:verifier", ptr %t175, i32 0, i32 13
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l103, !tbaa !27
  %t179 = load i32, ptr %l15, !tbaa !23
  %t181 = sext i32 %t179 to i64
  %t183 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i1, ptr %t184, i64 %t181
  %t186 = load i1, ptr %t185, !tbaa !31
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb54, label %bb55
bb54:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/mir:verifier", ptr %t190, i32 0, i32 13
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l109, !tbaa !27
  %t194 = load i32, ptr %l15, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t198 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i1, ptr %t199, i64 %t196
  store i1 true, ptr %t200, !tbaa !31
  %t201 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %s0, ptr %l2, i32 %t201)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l14, !tbaa !24
  br label %bb48
bb59:
  call void @__olang_scope_close(ptr %s1)
  br label %bb60
bb60:
  br label %bb6
bb61:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/mir:verifier", ptr %t208, i32 0, i32 4
  store i64 -1, ptr %t210, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t211 = load i64, ptr %l1, !tbaa !24
  store i64 %t211, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l17, !tbaa !24
  %t214 = load i64, ptr %l16, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb62, label %bb63
bb62:
  %t219 = load i64, ptr %l18, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb67
bb64:
  %t223 = load i64, ptr %l17, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l18, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l18, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l124, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb66
bb66:
  %t239 = load i64, ptr %l124, !tbaa !24
  store i64 %t239, ptr %l121, !tbaa !24
  br label %bb67
bb67:
  %t240 = load i64, ptr %l121, !tbaa !24
  store i64 %t240, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb68
bb68:
  %t241 = load i64, ptr %l20, !tbaa !24
  %t242 = load i64, ptr %l19, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb69, label %bb70
bb69:
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t249 = load i64, ptr %l16, !tbaa !24
  %t250 = load i64, ptr %l20, !tbaa !24
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l21, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/mir:verifier", ptr %t259, i32 0, i32 13
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l143, !tbaa !27
  %t263 = load i64, ptr %l21, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i1, ptr %t266, i64 %t263
  %t268 = load i1, ptr %t267, !tbaa !31
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s18
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i64, ptr %l21, !tbaa !24
  %t276 = getelementptr %"compiler/mir:verifier", ptr %t272, i32 0, i32 3
  store i64 %t273, ptr %t276, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t277, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s18)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t279 = load i64, ptr %l20, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l20, !tbaa !24
  br label %bb68
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Range"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l12, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %l12, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l12, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load i32, ptr %l6, !tbaa !23
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l1
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = add i32 %t62, 1
  store i32 %t64, ptr %l6, !tbaa !23
  br label %bb7
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t13, i32 %t14)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b)
  unreachable
bb10:
  store i32 0, ptr %l4, !tbaa !23
  %t17 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t18 = getelementptr %"compiler/mir:Range", ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l5, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = icmp sgt i32 %t21, %t22
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  br i1 %t29, label %bb13, label %bb14
bb12:
  store i32 0, ptr %l22, !tbaa !23
  br label %bb16
bb13:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = sub i32 %t31, %t32
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = add i32 %t35, %t36
  %t41 = sub i32 %t39, 1
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = sdiv i32 %t41, %t42
  store i32 %t45, ptr %l25, !tbaa !23
  br label %bb15
bb14:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb15
bb15:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %l22, !tbaa !23
  br label %bb16
bb16:
  %t48 = load i32, ptr %l22, !tbaa !23
  store i32 %t48, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb17
bb17:
  %t49 = load i32, ptr %l8, !tbaa !23
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = icmp slt i32 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t57 = load i32, ptr %l4, !tbaa !23
  %t58 = load i32, ptr %l8, !tbaa !23
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = mul i32 %t58, %t59
  %t65 = add i32 %t57, %t62
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/mir:Fn", ptr %t70, i32 0, i32 10
  %t73 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t74 = getelementptr %"compiler/mir:Range", ptr %t73, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t80 = sext i32 %t65 to i64
  %t83 = add i64 %t77, %t80
  %t84 = load ptr, ptr @__olang_prog_scope
  %t87 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t84, ptr %t72, i64 %t83)
  store { i64, [1 x i64] } %t87, ptr %l51
  br label %bb21
bb21:
  %t88 = load { i64, [1 x i64] }, ptr %l51
  store { i64, [1 x i64] } %t88, ptr %l10
  %t89 = load { i64, [1 x i64] }, ptr %l10
  %t91 = extractvalue { i64, [1 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 1
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l11, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %t98, i32 %t99)
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a)
  unreachable
bb31:
  br label %bb32
bb32:
  %t102 = load i32, ptr %l8, !tbaa !23
  %t104 = add i32 %t102, 1
  store i32 %t104, ptr %l8, !tbaa !23
  br label %bb17
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Lvalue"
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t11)
  br label %bb4
bb4:
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a5f83820f05cb9f9_5f257facca4b96a5)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l32 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l10
  br label %bb4
bb4:
  br label %bb27
bb5:
  %t15 = load { i64, [1 x i64] }, ptr %l1
  %t17 = extractvalue { i64, [1 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 1
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb12
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/mir:verifier", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/mir:Fn", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr @__olang_prog_scope
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %t35, ptr %t34)
  store i64 %t37, ptr %l21
  br label %bb11
bb11:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = icmp sge i64 %t38, %t39
  store i1 %t40, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l16, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t43, { i64, ptr } %t61)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t64 = load { i64, [1 x i64] }, ptr %l1
  %t66 = extractvalue { i64, [1 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 4
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t70 = getelementptr { i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l4, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l4, !tbaa !23
  %t77 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l32
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6be72733009cb689_7eadbfb9b429b955)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t8, ptr %t6, i32 %t7)
  store i1 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i1, ptr %l8, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l13
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t21 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t23 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  call void @olang_textcopy(ptr %t28, ptr %t24, i64 %t25)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t38 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t38, { i64, ptr } %t37)
  br label %bb5
bb5:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t40, ptr %rv
  br label %ret
bb6:
  %t42 = load i32, ptr %l1, !tbaa !23
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t46 = icmp ne i32 %t42, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l21, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l22, !tbaa !23
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load ptr, ptr @__olang_prog_scope
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t52, ptr %t50, i32 %t51)
  store i32 %t55, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t56 = load ptr, ptr %l21, !tbaa !29
  %t57 = load i32, ptr %l22, !tbaa !23
  %t58 = load i32, ptr %l25, !tbaa !23
  %t59 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t59, ptr %l26
  br label %bb10
bb10:
  %t60 = load i1, ptr %l26, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t63 = load i1, ptr %l20, !tbaa !21
  br i1 %t63, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l28, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l2, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t65, i32 %t66)
  store { i64, ptr } %t69, ptr %l31
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t70, i32 %t71)
  store { i64, ptr } %t74, ptr %l34
  br label %bb15
bb15:
  %t75 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t77 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = add i64 %t83, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t75, i64 %t76)
  %t89 = getelementptr i8, ptr %t88, i64 %t76
  call void @olang_textcopy(ptr %t89, ptr %t78, i64 %t79)
  %t90 = getelementptr i8, ptr %t89, i64 %t79
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t85, i64 %t86)
  %t92 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t88, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t101, { i64, ptr } %t100)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t103 = load i32, ptr %l2, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/mir:verifier", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/mir:verifier", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr @__olang_prog_scope
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t16, ptr %t14, i32 %t15)
  store i32 %t19, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t20, ptr %t21, i32 %t22)
  store i1 %t23, ptr %l12
  br label %bb4
bb4:
  %t24 = load i1, ptr %l12, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l5, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l17
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t34 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t36 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = getelementptr i8, ptr %t40, i64 %t35
  call void @olang_textcopy(ptr %t41, ptr %t37, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t51, { i64, ptr } %t50)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t53 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereach(ptr %v0, ptr %t7)
  br label %bb5
bb5:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %t9)
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %t11)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueFlow(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l102 = alloca i32
  %l105 = alloca i32
  %l123 = alloca ptr
  %l132 = alloca { i64, [1 x i64] }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb5
bb2:
  %t10 = load { i64, [15 x i64] }, ptr %l1
  %t12 = extractvalue { i64, [15 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 11
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, [4 x i64] }, ptr %t16
  store { i64, [4 x i64] } %t17, ptr %l2
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t19, { i64, [4 x i64] } %t20)
  br label %bb6
bb6:
  br label %bb92
bb7:
  %t23 = load { i64, [15 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [15 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 1
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t28, i32 0, i32 0
  %t30 = load %"compiler/mir:Lvalue", ptr %t29
  store %"compiler/mir:Lvalue" %t30, ptr %l3
  br label %bb14
bb9:
  %t32 = load { i64, [15 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [15 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 2
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/mir:Lvalue", ptr %t38
  store %"compiler/mir:Lvalue" %t39, ptr %l3
  br label %bb14
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 5
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Lvalue", ptr %t47
  store %"compiler/mir:Lvalue" %t48, ptr %l3
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/mir:Lvalue", ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t50, %"compiler/mir:Lvalue" %t51)
  br label %bb15
bb15:
  br label %bb92
bb16:
  %t54 = load { i64, [15 x i64] }, ptr %l1
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 3
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t60 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t59, i32 0, i32 2
  %t61 = load %"compiler/mir:Range", ptr %t60
  store %"compiler/mir:Range" %t61, ptr %l4
  br label %bb23
bb18:
  %t63 = load { i64, [15 x i64] }, ptr %l1
  %t65 = extractvalue { i64, [15 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t68, i32 0, i32 2
  %t70 = load %"compiler/mir:Range", ptr %t69
  store %"compiler/mir:Range" %t70, ptr %l4
  br label %bb23
bb20:
  %t72 = load { i64, [15 x i64] }, ptr %l1
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 6
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/mir:Range", ptr %t78
  store %"compiler/mir:Range" %t79, ptr %l4
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t81, %"compiler/mir:Range" %t82)
  br label %bb24
bb24:
  br label %bb92
bb25:
  %t85 = load { i64, [15 x i64] }, ptr %l1
  %t87 = extractvalue { i64, [15 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 7
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t91 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, [1 x i64] }, ptr %t91
  store { i64, [1 x i64] } %t92, ptr %l5
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t95 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t94, i32 0, i32 1
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l6
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t98, { i64, [4 x i64] } %t99)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, [1 x i64] }, ptr %l5
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t102, { i64, [1 x i64] } %t103)
  br label %bb30
bb30:
  br label %bb92
bb31:
  %t106 = load { i64, [15 x i64] }, ptr %l1
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 8
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t112 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 0
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l7
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t116 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t115, i32 0, i32 2
  %t117 = load { i64, [4 x i64] }, ptr %t116
  store { i64, [4 x i64] } %t117, ptr %l8
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t120 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t119, i32 0, i32 3
  %t121 = load { i64, [4 x i64] }, ptr %t120
  store { i64, [4 x i64] } %t121, ptr %l9
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t123, { i64, [4 x i64] } %t124)
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load { i64, [4 x i64] }, ptr %l9
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t127, { i64, [4 x i64] } %t128)
  br label %bb36
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, [1 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t131, { i64, [1 x i64] } %t132)
  br label %bb37
bb37:
  br label %bb92
bb38:
  %t135 = load { i64, [15 x i64] }, ptr %l1
  %t137 = extractvalue { i64, [15 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 9
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t141 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/mir:Lvalue", ptr %t141
  store %"compiler/mir:Lvalue" %t142, ptr %l10
  %t144 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t145 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t144, i32 0, i32 1
  %t146 = load { i64, [4 x i64] }, ptr %t145
  store { i64, [4 x i64] } %t146, ptr %l11
  %t148 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t149 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t148, i32 0, i32 2
  %t150 = load { i64, [4 x i64] }, ptr %t149
  store { i64, [4 x i64] } %t150, ptr %l12
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadPlace(ptr %v0, ptr %t152, %"compiler/mir:Lvalue" %t153)
  br label %bb42
bb42:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t156, { i64, [4 x i64] } %t157)
  br label %bb43
bb43:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t160, { i64, [4 x i64] } %t161)
  br label %bb44
bb44:
  br label %bb92
bb45:
  %t164 = load { i64, [15 x i64] }, ptr %l1
  %t166 = extractvalue { i64, [15 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 10
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t169, i32 0, i32 2
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l13
  %t173 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t174 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t173, i32 0, i32 3
  %t175 = load %"compiler/mir:Range", ptr %t174
  store %"compiler/mir:Range" %t175, ptr %l14
  %t177 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t178 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t177, i32 0, i32 4
  %t179 = load %"compiler/mir:Range", ptr %t178
  store %"compiler/mir:Range" %t179, ptr %l15
  br label %bb48
bb47:
  br label %bb68
bb48:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/mir:Range", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereadArgs(ptr %v0, ptr %t181, %"compiler/mir:Range" %t182)
  br label %bb49
bb49:
  %t185 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t186 = load i32, ptr %t185, !tbaa !23
  %t188 = icmp sgt i32 %t186, 0
  br i1 %t188, label %bb50, label %bb51
bb50:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, [1 x i64] }, ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t190, { i64, [1 x i64] } %t191)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  store i32 0, ptr %l16, !tbaa !23
  %t194 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  store i32 %t195, ptr %l17, !tbaa !23
  store i32 1, ptr %l18, !tbaa !23
  %t197 = load i32, ptr %l17, !tbaa !23
  %t198 = load i32, ptr %l16, !tbaa !23
  %t201 = icmp sgt i32 %t197, %t198
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t203 = load i32, ptr %l18, !tbaa !23
  %t205 = icmp sgt i32 %t203, 0
  br i1 %t205, label %bb56, label %bb57
bb55:
  store i32 0, ptr %l102, !tbaa !23
  br label %bb59
bb56:
  %t207 = load i32, ptr %l17, !tbaa !23
  %t208 = load i32, ptr %l16, !tbaa !23
  %t211 = sub i32 %t207, %t208
  %t212 = load i32, ptr %l18, !tbaa !23
  %t215 = add i32 %t211, %t212
  %t217 = sub i32 %t215, 1
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = sdiv i32 %t217, %t218
  store i32 %t221, ptr %l105, !tbaa !23
  br label %bb58
bb57:
  store i32 0, ptr %l105, !tbaa !23
  br label %bb58
bb58:
  %t223 = load i32, ptr %l105, !tbaa !23
  store i32 %t223, ptr %l102, !tbaa !23
  br label %bb59
bb59:
  %t224 = load i32, ptr %l102, !tbaa !23
  store i32 %t224, ptr %l19, !tbaa !23
  store i32 0, ptr %l20, !tbaa !23
  br label %bb60
bb60:
  %t225 = load i32, ptr %l20, !tbaa !23
  %t226 = load i32, ptr %l19, !tbaa !23
  %t229 = icmp slt i32 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t233 = load i32, ptr %l16, !tbaa !23
  %t234 = load i32, ptr %l20, !tbaa !23
  %t235 = load i32, ptr %l18, !tbaa !23
  %t238 = mul i32 %t234, %t235
  %t241 = add i32 %t233, %t238
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l123, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/mir:verifier", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/mir:Fn", ptr %t247, i32 0, i32 12
  %t250 = getelementptr %"compiler/mir:Range", ptr %l15, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  %t256 = sext i32 %t241 to i64
  %t259 = add i64 %t253, %t256
  %t260 = load ptr, ptr @__olang_prog_scope
  %t263 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t260, ptr %t249, i64 %t259)
  store { i64, [1 x i64] } %t263, ptr %l132
  br label %bb64
bb64:
  %t264 = load ptr, ptr %l123, !tbaa !29
  %t265 = load { i64, [1 x i64] }, ptr %l132
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t264, { i64, [1 x i64] } %t265)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t266 = load i32, ptr %l20, !tbaa !23
  %t268 = add i32 %t266, 1
  store i32 %t268, ptr %l20, !tbaa !23
  br label %bb60
bb67:
  br label %bb92
bb68:
  %t270 = load { i64, [15 x i64] }, ptr %l1
  %t272 = extractvalue { i64, [15 x i64] } %t270, 0
  %t273 = icmp eq i64 %t272, 12
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t276 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t275, i32 0, i32 0
  %t277 = load { i64, [1 x i64] }, ptr %t276
  store { i64, [1 x i64] } %t277, ptr %l22
  %t279 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t280 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t279, i32 0, i32 1
  %t281 = load { i64, [1 x i64] }, ptr %t280
  store { i64, [1 x i64] } %t281, ptr %l23
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load { i64, [1 x i64] }, ptr %l22
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t283, { i64, [1 x i64] } %t284)
  br label %bb72
bb72:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load { i64, [1 x i64] }, ptr %l23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t287, { i64, [1 x i64] } %t288)
  br label %bb73
bb73:
  br label %bb92
bb74:
  %t291 = load { i64, [15 x i64] }, ptr %l1
  %t293 = extractvalue { i64, [15 x i64] } %t291, 0
  %t294 = icmp eq i64 %t293, 13
  br i1 %t294, label %bb75, label %bb76
bb75:
  %t296 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t297 = getelementptr { { i64, [1 x i64] } }, ptr %t296, i32 0, i32 0
  %t298 = load { i64, [1 x i64] }, ptr %t297
  store { i64, [1 x i64] } %t298, ptr %l24
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load { i64, [1 x i64] }, ptr %l24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %t300, { i64, [1 x i64] } %t301)
  br label %bb78
bb78:
  br label %bb92
bb79:
  %t304 = load { i64, [15 x i64] }, ptr %l1
  %t306 = extractvalue { i64, [15 x i64] } %t304, 0
  %t307 = icmp eq i64 %t306, 14
  br i1 %t307, label %bb80, label %bb81
bb80:
  %t309 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t310 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t309, i32 0, i32 0
  %t311 = load { i64, [4 x i64] }, ptr %t310
  store { i64, [4 x i64] } %t311, ptr %l25
  %t313 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t314 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t313, i32 0, i32 1
  %t315 = load { i64, [1 x i64] }, ptr %t314
  store { i64, [1 x i64] } %t315, ptr %l26
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load { i64, [4 x i64] }, ptr %l25
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ereads(ptr %v0, ptr %t317, { i64, [4 x i64] } %t318)
  br label %bb83
bb83:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load { i64, [1 x i64] }, ptr %l26
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %t321, { i64, [1 x i64] } %t322)
  br label %bb84
bb84:
  br label %bb92
bb85:
  %t325 = load { i64, [15 x i64] }, ptr %l1
  %t327 = extractvalue { i64, [15 x i64] } %t325, 0
  %t328 = icmp eq i64 %t327, 15
  br i1 %t328, label %bb86, label %bb87
bb86:
  br label %bb90
bb87:
  %t330 = load { i64, [15 x i64] }, ptr %l1
  %t332 = extractvalue { i64, [15 x i64] } %t330, 0
  %t333 = icmp eq i64 %t332, 16
  br i1 %t333, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f)
  unreachable
bb92:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Range"
  %l12 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Range"
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca i32
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca i32
  %l31 = alloca i32
  %l37 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i32
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l65 = alloca i32
  %l75 = alloca i32
  %l79 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca i32
  %l93 = alloca i32
  %l98 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i32
  %l113 = alloca i32
  %l120 = alloca ptr
  %l123 = alloca i32
  %l127 = alloca i32
  %l133 = alloca i32
  %l137 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca i32
  %l150 = alloca i32
  %l157 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca i32
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [4 x i64] }, ptr %l2
  %t14 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t10, { i64, [4 x i64] } %t11)
  store i32 %t14, ptr %l37
  br label %bb4
bb4:
  %t15 = load i32, ptr %l37, !tbaa !23
  store i32 %t15, ptr %l31, !tbaa !23
  br label %bb90
bb5:
  %t16 = load { i64, [15 x i64] }, ptr %l1
  %t18 = extractvalue { i64, [15 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t22 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/mir:Lvalue", ptr %t22
  store %"compiler/mir:Lvalue" %t23, ptr %l3
  %t25 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t25, i32 0, i32 1
  %t27 = load i32, ptr %t26
  store i32 %t27, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l42, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/mir:Lvalue", ptr %l3
  %t34 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t30, %"compiler/mir:Lvalue" %t31)
  store i32 %t34, ptr %l45
  br label %bb9
bb9:
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load ptr, ptr %l42, !tbaa !29
  %t37 = load i32, ptr %l45, !tbaa !23
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t36, i32 %t37, i32 %t35)
  store i32 %t39, ptr %l47
  br label %bb10
bb10:
  %t40 = load i32, ptr %l47, !tbaa !23
  store i32 %t40, ptr %l31, !tbaa !23
  br label %bb90
bb11:
  %t41 = load { i64, [15 x i64] }, ptr %l1
  %t43 = extractvalue { i64, [15 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t47 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/mir:Lvalue", ptr %t47
  store %"compiler/mir:Lvalue" %t48, ptr %l5
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l51, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Lvalue", ptr %l5
  %t55 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t51, %"compiler/mir:Lvalue" %t52)
  store i32 %t55, ptr %l54
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l51, !tbaa !29
  %t57 = load i32, ptr %l54, !tbaa !23
  %t58 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l55
  br label %bb16
bb16:
  %t59 = load i32, ptr %l55, !tbaa !23
  store i32 %t59, ptr %l31, !tbaa !23
  br label %bb90
bb17:
  %t60 = load { i64, [15 x i64] }, ptr %l1
  %t62 = extractvalue { i64, [15 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 3
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t65 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t65, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 49}
  store i32 %t67, ptr %l6
  %t69 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t70 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l7, !tbaa !23
  %t73 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t74 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t73, i32 0, i32 2
  %t75 = load %"compiler/mir:Range", ptr %t74
  store %"compiler/mir:Range" %t75, ptr %l8
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l6, !range !{i32 0, i32 49}
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load %"compiler/mir:Range", ptr %l8
  %t85 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %t77, i32 %t78, i32 %t79, %"compiler/mir:Range" %t80)
  store i32 %t85, ptr %l65
  br label %bb21
bb21:
  %t86 = load i32, ptr %l65, !tbaa !23
  store i32 %t86, ptr %l31, !tbaa !23
  br label %bb90
bb22:
  %t87 = load { i64, [15 x i64] }, ptr %l1
  %t89 = extractvalue { i64, [15 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 4
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t93 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t92, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 49}
  store i32 %t94, ptr %l9
  %t96 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t97 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t96, i32 0, i32 1
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l10, !tbaa !23
  %t100 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t101 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t100, i32 0, i32 2
  %t102 = load %"compiler/mir:Range", ptr %t101
  store %"compiler/mir:Range" %t102, ptr %l11
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l9, !range !{i32 0, i32 49}
  %t106 = load i32, ptr %l10, !tbaa !23
  %t107 = load %"compiler/mir:Range", ptr %l11
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoverflowsType(ptr %v0, ptr %t104, i32 %t105, i32 %t106, %"compiler/mir:Range" %t107)
  store i32 %t112, ptr %l75
  br label %bb26
bb26:
  %t113 = load i32, ptr %l75, !tbaa !23
  store i32 %t113, ptr %l31, !tbaa !23
  br label %bb90
bb27:
  %t114 = load { i64, [15 x i64] }, ptr %l1
  %t116 = extractvalue { i64, [15 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 5
  br i1 %t117, label %bb28, label %bb29
bb28:
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/mir:Lvalue", ptr %t120
  store %"compiler/mir:Lvalue" %t121, ptr %l12
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l79, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/mir:Lvalue", ptr %l12
  %t128 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t124, %"compiler/mir:Lvalue" %t125)
  store i32 %t128, ptr %l82
  br label %bb31
bb31:
  %t129 = load ptr, ptr %l79, !tbaa !29
  %t130 = load i32, ptr %l82, !tbaa !23
  %t131 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l83
  br label %bb32
bb32:
  %t132 = load i32, ptr %l83, !tbaa !23
  store i32 %t132, ptr %l31, !tbaa !23
  br label %bb90
bb33:
  %t133 = load { i64, [15 x i64] }, ptr %l1
  %t135 = extractvalue { i64, [15 x i64] } %t133, 0
  %t136 = icmp eq i64 %t135, 6
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t138 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t139 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t138, i32 0, i32 0
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l13, !tbaa !23
  %t142 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t143 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t142, i32 0, i32 1
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l14, !tbaa !24
  %t146 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t147 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t146, i32 0, i32 2
  %t148 = load %"compiler/mir:Range", ptr %t147
  store %"compiler/mir:Range" %t148, ptr %l15
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l13, !tbaa !23
  %t152 = load i64, ptr %l14, !tbaa !24
  %t153 = load %"compiler/mir:Range", ptr %l15
  %t158 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eaggregateType(ptr %v0, ptr %t150, i32 %t151, i64 %t152, %"compiler/mir:Range" %t153)
  store i32 %t158, ptr %l93
  br label %bb37
bb37:
  %t159 = load i32, ptr %l93, !tbaa !23
  store i32 %t159, ptr %l31, !tbaa !23
  br label %bb90
bb38:
  %t160 = load { i64, [15 x i64] }, ptr %l1
  %t162 = extractvalue { i64, [15 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 7
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t166 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t165, i32 0, i32 1
  %t167 = load { i64, [4 x i64] }, ptr %t166
  store { i64, [4 x i64] } %t167, ptr %l16
  %t169 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t169, i32 0, i32 2
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l17, !tbaa !23
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l98, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, [4 x i64] }, ptr %l16
  %t178 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t174, { i64, [4 x i64] } %t175)
  store i32 %t178, ptr %l101
  br label %bb42
bb42:
  %t179 = load i32, ptr %l17, !tbaa !23
  %t180 = load ptr, ptr %l98, !tbaa !29
  %t181 = load i32, ptr %l101, !tbaa !23
  %t183 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefType(ptr %v0, ptr %t180, i32 %t181, i32 %t179)
  store i32 %t183, ptr %l103
  br label %bb43
bb43:
  %t184 = load i32, ptr %l103, !tbaa !23
  store i32 %t184, ptr %l31, !tbaa !23
  br label %bb90
bb44:
  %t185 = load { i64, [15 x i64] }, ptr %l1
  %t187 = extractvalue { i64, [15 x i64] } %t185, 0
  %t188 = icmp eq i64 %t187, 8
  br i1 %t188, label %bb45, label %bb46
bb45:
  %t190 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t191 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t190, i32 0, i32 1
  %t192 = load i32, ptr %t191
  store i32 %t192, ptr %l18, !tbaa !23
  %t194 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t195 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t194, i32 0, i32 2
  %t196 = load { i64, [4 x i64] }, ptr %t195
  store { i64, [4 x i64] } %t196, ptr %l19
  %t198 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t199 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t198, i32 0, i32 3
  %t200 = load { i64, [4 x i64] }, ptr %t199
  store { i64, [4 x i64] } %t200, ptr %l20
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l18, !tbaa !23
  %t204 = load { i64, [4 x i64] }, ptr %l19
  %t205 = load { i64, [4 x i64] }, ptr %l20
  %t210 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2enewArrayType(ptr %v0, ptr %t202, i32 %t203, { i64, [4 x i64] } %t204, { i64, [4 x i64] } %t205)
  store i32 %t210, ptr %l113
  br label %bb48
bb48:
  %t211 = load i32, ptr %l113, !tbaa !23
  store i32 %t211, ptr %l31, !tbaa !23
  br label %bb90
bb49:
  %t212 = load { i64, [15 x i64] }, ptr %l1
  %t214 = extractvalue { i64, [15 x i64] } %t212, 0
  %t215 = icmp eq i64 %t214, 9
  br i1 %t215, label %bb50, label %bb51
bb50:
  %t217 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t218 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t217, i32 0, i32 0
  %t219 = load %"compiler/mir:Lvalue", ptr %t218
  store %"compiler/mir:Lvalue" %t219, ptr %l21
  %t221 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t222 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t221, i32 0, i32 1
  %t223 = load { i64, [4 x i64] }, ptr %t222
  store { i64, [4 x i64] } %t223, ptr %l22
  %t225 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t226 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t225, i32 0, i32 2
  %t227 = load { i64, [4 x i64] }, ptr %t226
  store { i64, [4 x i64] } %t227, ptr %l23
  %t229 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t230 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t229, i32 0, i32 3
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l24, !tbaa !23
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l120, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/mir:Lvalue", ptr %l21
  %t238 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t234, %"compiler/mir:Lvalue" %t235)
  store i32 %t238, ptr %l123
  br label %bb53
bb53:
  %t239 = load { i64, [4 x i64] }, ptr %l22
  %t240 = load { i64, [4 x i64] }, ptr %l23
  %t241 = load i32, ptr %l24, !tbaa !23
  %t242 = load ptr, ptr %l120, !tbaa !29
  %t243 = load i32, ptr %l123, !tbaa !23
  %t247 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %t242, i32 %t243, { i64, [4 x i64] } %t239, { i64, [4 x i64] } %t240, i32 %t241)
  store i32 %t247, ptr %l127
  br label %bb54
bb54:
  %t248 = load i32, ptr %l127, !tbaa !23
  store i32 %t248, ptr %l31, !tbaa !23
  br label %bb90
bb55:
  %t249 = load { i64, [15 x i64] }, ptr %l1
  %t251 = extractvalue { i64, [15 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 10
  br i1 %t252, label %bb56, label %bb57
bb56:
  %t254 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t255 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255
  store i32 %t256, ptr %l25, !tbaa !23
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l25, !tbaa !23
  %t262 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eclosureType(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l133
  br label %bb59
bb59:
  %t263 = load i32, ptr %l133, !tbaa !23
  store i32 %t263, ptr %l31, !tbaa !23
  br label %bb90
bb60:
  %t264 = load { i64, [15 x i64] }, ptr %l1
  %t266 = extractvalue { i64, [15 x i64] } %t264, 0
  %t267 = icmp eq i64 %t266, 11
  br i1 %t267, label %bb61, label %bb62
bb61:
  %t269 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t270 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t269, i32 0, i32 0
  %t271 = load { i64, [4 x i64] }, ptr %t270
  store { i64, [4 x i64] } %t271, ptr %l26
  br label %bb63
bb62:
  br label %bb66
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l137, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load { i64, [4 x i64] }, ptr %l26
  %t278 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t274, { i64, [4 x i64] } %t275)
  store i32 %t278, ptr %l140
  br label %bb64
bb64:
  %t279 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t280 = load ptr, ptr %l137, !tbaa !29
  %t281 = load i32, ptr %l140, !tbaa !23
  %t283 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s12, ptr %t280, i32 %t281, i32 %t279, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i32 %t283, ptr %l142
  br label %bb65
bb65:
  %t284 = load i32, ptr %l142, !tbaa !23
  store i32 %t284, ptr %l31, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb66:
  %t285 = load { i64, [15 x i64] }, ptr %l1
  %t287 = extractvalue { i64, [15 x i64] } %t285, 0
  %t288 = icmp eq i64 %t287, 12
  br i1 %t288, label %bb67, label %bb68
bb67:
  %t290 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t291 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t290, i32 0, i32 0
  %t292 = load { i64, [1 x i64] }, ptr %t291
  store { i64, [1 x i64] } %t292, ptr %l27
  %t294 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t295 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t294, i32 0, i32 2
  %t296 = load i32, ptr %t295
  store i32 %t296, ptr %l28, !tbaa !23
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load { i64, [1 x i64] }, ptr %l27
  %t300 = load i32, ptr %l28, !tbaa !23
  %t304 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %t298, { i64, [1 x i64] } %t299, i32 %t300)
  store i32 %t304, ptr %l150
  br label %bb70
bb70:
  %t305 = load i32, ptr %l150, !tbaa !23
  store i32 %t305, ptr %l31, !tbaa !23
  br label %bb90
bb71:
  %t306 = load { i64, [15 x i64] }, ptr %l1
  %t308 = extractvalue { i64, [15 x i64] } %t306, 0
  %t309 = icmp eq i64 %t308, 13
  br i1 %t309, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t311 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t311, ptr %l31, !tbaa !23
  br label %bb90
bb75:
  %t313 = load { i64, [15 x i64] }, ptr %l1
  %t315 = extractvalue { i64, [15 x i64] } %t313, 0
  %t316 = icmp eq i64 %t315, 14
  br i1 %t316, label %bb76, label %bb77
bb76:
  %t318 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t319 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t318, i32 0, i32 0
  %t320 = load { i64, [4 x i64] }, ptr %t319
  store { i64, [4 x i64] } %t320, ptr %l29
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l157, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load { i64, [4 x i64] }, ptr %l29
  %t327 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t323, { i64, [4 x i64] } %t324)
  store i32 %t327, ptr %l160
  br label %bb79
bb79:
  %t328 = load ptr, ptr %l157, !tbaa !29
  %t329 = load i32, ptr %l160, !tbaa !23
  %t330 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eregionOrType(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t330, ptr %l161
  br label %bb80
bb80:
  %t331 = load i32, ptr %l161, !tbaa !23
  store i32 %t331, ptr %l31, !tbaa !23
  br label %bb90
bb81:
  %t332 = load { i64, [15 x i64] }, ptr %l1
  %t334 = extractvalue { i64, [15 x i64] } %t332, 0
  %t335 = icmp eq i64 %t334, 15
  br i1 %t335, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t337 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t337, ptr %l31, !tbaa !23
  br label %bb90
bb85:
  %t339 = load { i64, [15 x i64] }, ptr %l1
  %t341 = extractvalue { i64, [15 x i64] } %t339, 0
  %t342 = icmp eq i64 %t341, 16
  br i1 %t342, label %bb86, label %bb87
bb86:
  %t344 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t345 = getelementptr { i32 }, ptr %t344, i32 0, i32 0
  %t346 = load i32, ptr %t345
  store i32 %t346, ptr %l30, !tbaa !23
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t348 = load i32, ptr %l30, !tbaa !23
  store i32 %t348, ptr %l31, !tbaa !23
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_3d9554dfcf1aeb63_1386be72809b2127)
  unreachable
bb90:
  %t350 = load i32, ptr %l31, !tbaa !23
  store i32 %t350, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameArgs(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/mir:Range", ptr %l2
  %t55 = sext i32 %t48 to i64
  %t59 = call { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %t51, %"compiler/mir:Range" %t52, i64 %t55)
  store { i64, [4 x i64] } %t59, ptr %l41
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = load { i64, [4 x i64] }, ptr %l41
  %t62 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t60, { i64, [4 x i64] } %t61)
  store i32 %t62, ptr %l42
  br label %bb12
bb12:
  %t63 = load i32, ptr %l42, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/mir:verifier", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:verifier", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i32, ptr %l10, !tbaa !23
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t73, ptr %t71, i32 %t72)
  store i32 %t76, ptr %l48
  br label %bb13
bb13:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/mir:verifier", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l3, !tbaa !23
  %t82 = load ptr, ptr @__olang_prog_scope
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t82, ptr %t80, i32 %t81)
  store i32 %t85, ptr %l52
  br label %bb14
bb14:
  %t86 = load ptr, ptr @__olang_prog_scope
  %t87 = load ptr, ptr %l44, !tbaa !29
  %t88 = load i32, ptr %l48, !tbaa !23
  %t89 = load i32, ptr %l52, !tbaa !23
  %t90 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t86, ptr %t87, i32 %t88, i32 %t89)
  store i1 %t90, ptr %l53
  br label %bb15
bb15:
  %t91 = load i1, ptr %l53, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  store i32 %a1, ptr %l56
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s4, ptr %l56, i64 0)
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t97 = load ptr, ptr %s4
  %t98 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t99 = load i64, ptr %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t97, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l58, !tbaa !27
  %t103 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t104 = load ptr, ptr %t103
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %sbgrew.106, label %sbdone.107
sbgrew.106:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.107
sbdone.107:
  %t108 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s3, ptr %s3, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l60
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l3, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t117, i32 %t118)
  store { i64, ptr } %t121, ptr %l63
  br label %bb20
bb20:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l10, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s3, ptr %t122, i32 %t123)
  store { i64, ptr } %t126, ptr %l66
  br label %bb21
bb21:
  %t127 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t128, i64 %t129)
  %t145 = getelementptr i8, ptr %t144, i64 %t129
  call void @olang_textcopy(ptr %t145, ptr %t130, i64 %t131)
  %t146 = getelementptr i8, ptr %t145, i64 %t131
  call void @olang_textcopy(ptr %t146, ptr %t134, i64 %t135)
  %t147 = getelementptr i8, ptr %t146, i64 %t135
  call void @olang_textcopy(ptr %t147, ptr %t137, i64 %t138)
  %t148 = getelementptr i8, ptr %t147, i64 %t138
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t144, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t158, { i64, ptr } %t157)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t160 = load i32, ptr %l8, !tbaa !23
  %t162 = add i32 %t160, 1
  store i32 %t162, ptr %l8, !tbaa !23
  br label %bb7
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t8, ptr %t6, i32 %a1)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr @__olang_prog_scope
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t15, ptr %t13, i32 %a2)
  store i32 %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr @__olang_prog_scope
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t23, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t27, ptr %l17
  br label %bb3
bb3:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr @__olang_prog_scope
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t32, ptr %t30, i32 %t31)
  store i32 %t35, ptr %l21
  br label %bb7
bb7:
  %t36 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t38 = trunc i64 19 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr @__olang_prog_scope
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t43, ptr %t41, i32 %t42)
  store i32 %t46, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t47 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t49 = trunc i64 19 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l24, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t55, ptr %t53, i32 %t54)
  store i32 %t58, ptr %l32
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t61 = load ptr, ptr @__olang_prog_scope
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t61, ptr %t59, i32 %t60)
  store i32 %t64, ptr %l35
  br label %bb15
bb15:
  %t65 = load i32, ptr %l32, !tbaa !23
  %t66 = load i32, ptr %l35, !tbaa !23
  %t67 = icmp eq i32 %t65, %t66
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l38, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t72 = load ptr, ptr @__olang_prog_scope
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t72, ptr %t70, i32 %t71)
  store i32 %t75, ptr %l41
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb18:
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr %l5, !tbaa !23
  %t78 = load ptr, ptr @__olang_prog_scope
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t78, ptr %t76, i32 %t77)
  store i32 %t81, ptr %l44
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i32, ptr %l41, !tbaa !23
  %t84 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esameRepr(ptr %v0, ptr %t82, i32 %t83, i32 %t84)
  store i1 %t85, ptr %l45
  br label %bb20
bb20:
  %t86 = load i1, ptr %l45, !tbaa !21
  store i1 %t86, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l37, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eshape(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/mir:Local"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/mir:Call"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:Case"
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/mir:Task"
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l52 = alloca %"compiler/mir:TaskClause"
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca { i64, [1 x i64] }
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, [1 x i64] }
  %l70 = alloca %"compiler/mir:Range"
  %l71 = alloca %"compiler/mir:Range"
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l91 = alloca i64
  %l98 = alloca i64
  %l106 = alloca i32
  %l113 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l128 = alloca i64
  %l131 = alloca i64
  %l136 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca %"compiler/mir:Local"
  %l178 = alloca ptr
  %l179 = alloca i64
  %l183 = alloca i32
  %l190 = alloca i1
  %l193 = alloca { i64, ptr }
  %l196 = alloca i1
  %l197 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l204 = alloca ptr
  %l208 = alloca i32
  %l211 = alloca { i64, ptr }
  %l214 = alloca i32
  %l215 = alloca i1
  %l220 = alloca i1
  %l224 = alloca { i64, ptr }
  %l227 = alloca i1
  %l229 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i64
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l250 = alloca i64
  %l252 = alloca i64
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i1
  %l266 = alloca %"compiler/mir:Local"
  %l278 = alloca i64
  %l282 = alloca i64
  %l285 = alloca i64
  %l306 = alloca %"compiler/mir:Local"
  %l320 = alloca i64
  %l324 = alloca i64
  %l327 = alloca i64
  %l348 = alloca %"compiler/mir:ScopeInfo"
  %l355 = alloca i1
  %l368 = alloca i64
  %l370 = alloca i64
  %l375 = alloca %"compiler/mir:Call"
  %l390 = alloca i1
  %l396 = alloca i1
  %l399 = alloca i1
  %l404 = alloca i64
  %l406 = alloca i64
  %l411 = alloca %"compiler/mir:Case"
  %l414 = alloca i1
  %l419 = alloca i64
  %l421 = alloca i64
  %l426 = alloca %"compiler/mir:Task"
  %l439 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca %"compiler/mir:Range"
  %l448 = alloca i64
  %l449 = alloca i1
  %l454 = alloca i32
  %l457 = alloca i32
  %l475 = alloca ptr
  %l483 = alloca %"compiler/mir:Lvalue"
  %l486 = alloca ptr
  %l487 = alloca %"compiler/mir:Range"
  %l490 = alloca i64
  %l491 = alloca i1
  %l496 = alloca i32
  %l499 = alloca i32
  %l524 = alloca %"compiler/mir:TaskClause"
  %l525 = alloca ptr
  %l526 = alloca %"compiler/mir:Range"
  %l529 = alloca i64
  %l530 = alloca i1
  %l539 = alloca i64
  %l541 = alloca i64
  %l546 = alloca { i64, [4 x i64] }
  %l553 = alloca i64
  %l555 = alloca i64
  %l560 = alloca { i64, [1 x i64] }
  %l567 = alloca i64
  %l569 = alloca i64
  %l574 = alloca { i64, [1 x i64] }
  %l580 = alloca i1
  %l585 = alloca i64
  %l589 = alloca i64
  %l592 = alloca i64
  %l613 = alloca { i64, [1 x i64] }
  %l617 = alloca ptr
  %l618 = alloca %"compiler/mir:Range"
  %l621 = alloca i64
  %l622 = alloca i1
  %l626 = alloca ptr
  %l627 = alloca %"compiler/mir:Range"
  %l630 = alloca i64
  %l631 = alloca i1
  %l639 = alloca i64
  %l643 = alloca i64
  %l646 = alloca i64
  %l669 = alloca ptr
  %l672 = alloca i64
  %l676 = alloca i64
  %l679 = alloca i64
  %l699 = alloca ptr
  %l703 = alloca { i64, [21 x i64] }
  %l719 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l91
  br label %bb1
bb1:
  %t11 = load i64, ptr %l91, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/mir:verifier", ptr %t12, i32 0, i32 3
  store i64 -1, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/mir:verifier", ptr %t17, i32 0, i32 4
  store i64 -1, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/mir:Fn", ptr %t22, i32 0, i32 9
  %t25 = load ptr, ptr @__olang_prog_scope
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t25, ptr %t24)
  store i64 %t27, ptr %l98
  br label %bb2
bb2:
  %t28 = load i64, ptr %l98, !tbaa !24
  %t29 = icmp eq i64 %t28, 0
  br i1 %t29, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/mir:verifier", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/mir:Fn", ptr %t38, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr @__olang_prog_scope
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t42, ptr %t37, i32 %t41)
  store i32 %t45, ptr %l106
  br label %bb7
bb7:
  %t46 = load i32, ptr %l106, !range !{i32 0, i32 33}
  %t48 = trunc i64 21 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/mir:verifier", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l113, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/mir:Fn", ptr %t64, i32 0, i32 1
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr @__olang_prog_scope
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t68, ptr %t63, i32 %t67)
  store i32 %t71, ptr %l118
  br label %bb12
bb12:
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = load ptr, ptr %l113, !tbaa !29
  %t74 = load i32, ptr %l118, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t72, ptr %s0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l119
  br label %bb13
bb13:
  %t76 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t76, ptr %l5, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l121, !tbaa !24
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 4
  %t83 = load ptr, ptr @__olang_prog_scope
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t83, ptr %t82)
  store i64 %t85, ptr %l124
  br label %bb14
bb14:
  %t86 = load i64, ptr %l121, !tbaa !24
  %t87 = load i64, ptr %l124, !tbaa !24
  %t88 = icmp ne i64 %t86, %t87
  br i1 %t88, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l126, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l128, !tbaa !24
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/mir:Fn", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr @__olang_prog_scope
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t97, ptr %t96)
  store i64 %t99, ptr %l131
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t100 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t102 = load i64, ptr %l128, !tbaa !24
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t102)
  %t104 = add i64 %t101, %t103
  %t105 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load i64, ptr %l131, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = getelementptr i8, ptr %t111, i64 %t101
  %t113 = call i64 @__olang_fmt_i64(ptr %t112, i64 %t102)
  %t114 = getelementptr i8, ptr %t112, i64 %t103
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  %t116 = call i64 @__olang_fmt_i64(ptr %t115, i64 %t108)
  %t117 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t111, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s3, ptr %t126, { i64, ptr } %t125)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/mir:Fn", ptr %t128, i32 0, i32 4
  %t131 = load ptr, ptr @__olang_prog_scope
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t131, ptr %t130)
  store i64 %t133, ptr %l136
  br label %bb20
bb20:
  %t134 = load i64, ptr %l136, !tbaa !24
  store i64 %t134, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sgt i64 %t135, %t136
  br i1 %t139, label %bb21, label %bb22
bb21:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb26
bb23:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l6, !tbaa !24
  %t149 = sub i64 %t145, %t146
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = add i64 %t149, %t150
  %t155 = sub i64 %t153, 1
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = sdiv i64 %t155, %t156
  store i64 %t159, ptr %l143, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb25
bb25:
  %t161 = load i64, ptr %l143, !tbaa !24
  store i64 %t161, ptr %l140, !tbaa !24
  br label %bb26
bb26:
  %t162 = load i64, ptr %l140, !tbaa !24
  store i64 %t162, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t163 = load i64, ptr %l10, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb28, label %bb29
bb28:
  br label %bb71
bb29:
  br label %bb30
bb30:
  %t171 = load i64, ptr %l6, !tbaa !24
  %t172 = load i64, ptr %l10, !tbaa !24
  %t173 = load i64, ptr %l8, !tbaa !24
  %t176 = mul i64 %t172, %t173
  %t179 = add i64 %t171, %t176
  store i64 %t179, ptr %l11, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l161, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr %"compiler/mir:Fn", ptr %t182, i32 0, i32 4
  %t185 = load i64, ptr %l11, !tbaa !24
  %t186 = load ptr, ptr @__olang_prog_scope
  %t189 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t186, ptr %t184, i64 %t185)
  store i32 %t189, ptr %l165
  br label %bb31
bb31:
  %t190 = load ptr, ptr %l161, !tbaa !29
  %t191 = load i32, ptr %l165, !tbaa !23
  %t192 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t192, ptr %l166
  br label %bb32
bb32:
  %t193 = load i1, ptr %l166, !tbaa !21
  br i1 %t193, label %bb33, label %bb34
bb33:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/mir:Fn", ptr %t194, i32 0, i32 7
  store ptr %t196, ptr %l168, !tbaa !29
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/mir:Fn", ptr %t197, i32 0, i32 4
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load ptr, ptr @__olang_prog_scope
  %t204 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t201, ptr %t199, i64 %t200)
  store i32 %t204, ptr %l172
  br label %bb35
bb34:
  br label %bb69
bb35:
  %t205 = load i32, ptr %l172, !tbaa !23
  %t206 = sext i32 %t205 to i64
  %t207 = load ptr, ptr @__olang_prog_scope
  %t208 = load ptr, ptr %l168, !tbaa !29
  %t210 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t207, ptr %t208, i64 %t206)
  store %"compiler/mir:Local" %t210, ptr %l174
  br label %bb36
bb36:
  %t211 = load %"compiler/mir:Local", ptr %l174
  store %"compiler/mir:Local" %t211, ptr %l12
  %t212 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t213 = load i32, ptr %t212, !range !{i32 0, i32 4}
  %t215 = trunc i64 0 to i32
  %t216 = icmp eq i32 %t213, %t215
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l178, !tbaa !29
  %t221 = load i64, ptr %l11, !tbaa !24
  store i64 %t221, ptr %l179, !tbaa !24
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/mir:Fn", ptr %t222, i32 0, i32 4
  %t225 = load i64, ptr %l11, !tbaa !24
  %t226 = load ptr, ptr @__olang_prog_scope
  %t229 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t226, ptr %t224, i64 %t225)
  store i32 %t229, ptr %l183
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t230 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t232 = load i64, ptr %l179, !tbaa !24
  %t233 = call i64 @__olang_fmt_i64(ptr null, i64 %t232)
  %t234 = add i64 %t231, %t233
  %t235 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t238 = load i32, ptr %l183, !tbaa !23
  %t239 = sext i32 %t238 to i64
  %t240 = call i64 @__olang_fmt_i64(ptr null, i64 %t239)
  %t241 = add i64 %t237, %t240
  %t242 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t230, i64 %t231)
  %t246 = getelementptr i8, ptr %t245, i64 %t231
  %t247 = call i64 @__olang_fmt_i64(ptr %t246, i64 %t232)
  %t248 = getelementptr i8, ptr %t246, i64 %t233
  call void @olang_textcopy(ptr %t248, ptr %t235, i64 %t236)
  %t249 = getelementptr i8, ptr %t248, i64 %t236
  %t250 = call i64 @__olang_fmt_i64(ptr %t249, i64 %t239)
  %t251 = getelementptr i8, ptr %t249, i64 %t240
  call void @olang_textcopy(ptr %t251, ptr %t242, i64 %t243)
  %t252 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t245, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } %t253, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t261 = load ptr, ptr %l178, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t261, { i64, ptr } %t260)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t263 = load i64, ptr %l11, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t269 = icmp slt i64 %t263, %t266
  br i1 %t269, label %bb42, label %bb43
bb42:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/mir:verifier", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t275, ptr %l193, !tbaa !27
  %t276 = load i64, ptr %l11, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr i32, ptr %t279, i64 %t276
  %t281 = load i32, ptr %t280, !tbaa !33
  %t282 = load ptr, ptr @__olang_prog_scope
  %t285 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %t282, ptr %t274, i32 %t281)
  store i1 %t285, ptr %l196
  br label %bb44
bb43:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb45
bb44:
  %t286 = load i1, ptr %l196, !tbaa !21
  store i1 %t286, ptr %l190, !tbaa !21
  br label %bb45
bb45:
  %t287 = load i1, ptr %l190, !tbaa !21
  br i1 %t287, label %bb46, label %bb47
bb46:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/mir:verifier", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t293 = load i32, ptr %t292, !tbaa !23
  %t294 = load ptr, ptr @__olang_prog_scope
  %t297 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t294, ptr %t291, i32 %t293)
  store i1 %t297, ptr %l201
  br label %bb48
bb47:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb49
bb48:
  %t298 = load i1, ptr %l201, !tbaa !21
  store i1 %t298, ptr %l197, !tbaa !21
  br label %bb49
bb49:
  %t299 = load i1, ptr %l197, !tbaa !21
  br i1 %t299, label %bb50, label %bb51
bb50:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/mir:verifier", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  store ptr %t303, ptr %l204, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/mir:verifier", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t308 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t309 = load i32, ptr %t308, !tbaa !23
  %t310 = load ptr, ptr @__olang_prog_scope
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t310, ptr %t307, i32 %t309)
  store i32 %t313, ptr %l208
  br label %bb52
bb51:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb55
bb52:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/mir:verifier", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t318, ptr %l211, !tbaa !27
  %t319 = load i64, ptr %l11, !tbaa !24
  %t321 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i32, ptr %t322, i64 %t319
  %t324 = load i32, ptr %t323, !tbaa !33
  %t325 = load ptr, ptr @__olang_prog_scope
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t325, ptr %t317, i32 %t324)
  store i32 %t328, ptr %l214
  br label %bb53
bb53:
  %t329 = load ptr, ptr @__olang_prog_scope
  %t330 = load ptr, ptr %l204, !tbaa !29
  %t331 = load i32, ptr %l208, !tbaa !23
  %t332 = load i32, ptr %l214, !tbaa !23
  %t333 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t329, ptr %t330, i32 %t331, i32 %t332)
  store i1 %t333, ptr %l215
  br label %bb54
bb54:
  %t334 = load i1, ptr %l215, !tbaa !21
  store i1 %t334, ptr %l202, !tbaa !21
  br label %bb55
bb55:
  %t335 = load i1, ptr %l202, !tbaa !21
  store i1 %t335, ptr %l13, !tbaa !21
  %t336 = load i64, ptr %l11, !tbaa !24
  %t337 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t342 = icmp slt i64 %t336, %t339
  br i1 %t342, label %bb56, label %bb57
bb56:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/mir:verifier", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t348 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t349 = load i32, ptr %t348, !tbaa !23
  %t350 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t350, ptr %l224, !tbaa !27
  %t351 = load i64, ptr %l11, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i32, ptr %t354, i64 %t351
  %t356 = load i32, ptr %t355, !tbaa !33
  %t357 = load ptr, ptr @__olang_prog_scope
  %t361 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t357, ptr %t347, i32 %t349, i32 %t356)
  store i1 %t361, ptr %l227
  br label %bb58
bb57:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb59
bb58:
  %t362 = load i1, ptr %l227, !tbaa !21
  %t363 = xor i1 %t362, true
  store i1 %t363, ptr %l220, !tbaa !21
  br label %bb59
bb59:
  %t365 = load i1, ptr %l220, !tbaa !21
  br i1 %t365, label %bb60, label %bb61
bb60:
  %t366 = load i1, ptr %l13, !tbaa !21
  %t368 = xor i1 %t366, true
  store i1 %t368, ptr %l229, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb62
bb62:
  %t370 = load i1, ptr %l229, !tbaa !21
  br i1 %t370, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l232, !tbaa !29
  %t372 = load i64, ptr %l11, !tbaa !24
  store i64 %t372, ptr %l233, !tbaa !24
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/mir:verifier", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t377 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t378 = load i32, ptr %t377, !tbaa !23
  %t379 = load ptr, ptr @__olang_prog_scope
  %t382 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t379, ptr %s10, ptr %t376, i32 %t378)
  store { i64, ptr } %t382, ptr %l237
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/mir:verifier", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t387, ptr %l240, !tbaa !27
  %t388 = load i64, ptr %l11, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr i32, ptr %t391, i64 %t388
  %t393 = load i32, ptr %t392, !tbaa !33
  %t394 = load ptr, ptr @__olang_prog_scope
  %t397 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t394, ptr %s10, ptr %t386, i32 %t393)
  store { i64, ptr } %t397, ptr %l243
  br label %bb66
bb66:
  %t398 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t400 = load i64, ptr %l233, !tbaa !24
  %t401 = call i64 @__olang_fmt_i64(ptr null, i64 %t400)
  %t402 = add i64 %t399, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t412 = add i64 %t409, %t411
  %t413 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = add i64 %t412, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t398, i64 %t399)
  %t418 = getelementptr i8, ptr %t417, i64 %t399
  %t419 = call i64 @__olang_fmt_i64(ptr %t418, i64 %t400)
  %t420 = getelementptr i8, ptr %t418, i64 %t401
  call void @olang_textcopy(ptr %t420, ptr %t403, i64 %t404)
  %t421 = getelementptr i8, ptr %t420, i64 %t404
  call void @olang_textcopy(ptr %t421, ptr %t407, i64 %t408)
  %t422 = getelementptr i8, ptr %t421, i64 %t408
  call void @olang_textcopy(ptr %t422, ptr %t410, i64 %t411)
  %t423 = getelementptr i8, ptr %t422, i64 %t411
  call void @olang_textcopy(ptr %t423, ptr %t414, i64 %t415)
  %t424 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t417, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } %t425, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  %t433 = load ptr, ptr %l232, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t433, { i64, ptr } %t432)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t435 = load i64, ptr %l10, !tbaa !24
  %t437 = add i64 %t435, 1
  store i64 %t437, ptr %l10, !tbaa !24
  br label %bb27
bb71:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr %"compiler/mir:Fn", ptr %t439, i32 0, i32 5
  store ptr %t441, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb72
bb72:
  %t443 = load i64, ptr %l15, !tbaa !24
  store i64 %t443, ptr %l250, !tbaa !24
  %t444 = load ptr, ptr %l14, !tbaa !29
  %t445 = load ptr, ptr @__olang_prog_scope
  %t447 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t445, ptr %t444)
  store i64 %t447, ptr %l252
  br label %bb73
bb73:
  %t448 = load i64, ptr %l250, !tbaa !24
  %t449 = load i64, ptr %l252, !tbaa !24
  %t450 = icmp slt i64 %t448, %t449
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb74, label %bb75
bb74:
  br label %bb88
bb75:
  br label %bb76
bb76:
  %t454 = load ptr, ptr %l14, !tbaa !29
  %t455 = load i64, ptr %l15, !tbaa !24
  %t456 = load ptr, ptr @__olang_prog_scope
  %t459 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t456, ptr %t454, i64 %t455)
  store i32 %t459, ptr %l257
  br label %bb77
bb77:
  %t460 = load i32, ptr %l257, !tbaa !23
  store i32 %t460, ptr %l16, !tbaa !23
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i32, ptr %l16, !tbaa !23
  %t465 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t461, i32 %t462)
  store i1 %t465, ptr %l260
  br label %bb78
bb78:
  %t466 = load i1, ptr %l260, !tbaa !21
  br i1 %t466, label %bb79, label %bb80
bb79:
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr %"compiler/mir:Fn", ptr %t467, i32 0, i32 7
  %t470 = load i32, ptr %l16, !tbaa !23
  %t472 = sext i32 %t470 to i64
  %t473 = load ptr, ptr @__olang_prog_scope
  %t476 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t473, ptr %t469, i64 %t472)
  store %"compiler/mir:Local" %t476, ptr %l266
  br label %bb81
bb80:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb82
bb81:
  %t477 = getelementptr %"compiler/mir:Local", ptr %l266, i32 0, i32 3
  %t478 = load i32, ptr %t477, !range !{i32 0, i32 4}
  %t480 = trunc i64 1 to i32
  %t481 = icmp eq i32 %t478, %t480
  %t483 = xor i1 %t481, true
  store i1 %t483, ptr %l261, !tbaa !21
  br label %bb82
bb82:
  %t485 = load i1, ptr %l261, !tbaa !21
  br i1 %t485, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s15
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l16, !tbaa !23
  %t488 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t491 = sext i32 %t487 to i64
  %t492 = call i64 @__olang_fmt_i64(ptr null, i64 %t491)
  %t493 = add i64 %t489, %t492
  %t494 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t495 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t496 = add i64 %t493, %t495
  %t497 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t496)
  call void @olang_textcopy(ptr %t497, ptr %t488, i64 %t489)
  %t498 = getelementptr i8, ptr %t497, i64 %t489
  %t499 = call i64 @__olang_fmt_i64(ptr %t498, i64 %t491)
  %t500 = getelementptr i8, ptr %t498, i64 %t492
  call void @olang_textcopy(ptr %t500, ptr %t494, i64 %t495)
  %t501 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t497, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = extractvalue { i64, ptr } %t502, 1
  %t506 = mul i64 %t504, 1
  %t507 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t506)
  call void @llvm.memcpy.p0.p0.i64(ptr %t507, ptr %t505, i64 %t506, i1 false)
  %t508 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s15, ptr %t486, { i64, ptr } %t509)
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t512 = load i64, ptr %l15, !tbaa !24
  %t514 = add i64 %t512, 1
  store i64 %t514, ptr %l15, !tbaa !24
  br label %bb72
bb88:
  store i64 0, ptr %l17, !tbaa !24
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr %"compiler/mir:Fn", ptr %t516, i32 0, i32 7
  %t519 = load ptr, ptr @__olang_prog_scope
  %t521 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t519, ptr %t518)
  store i64 %t521, ptr %l278
  br label %bb89
bb89:
  %t522 = load i64, ptr %l278, !tbaa !24
  store i64 %t522, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t523 = load i64, ptr %l18, !tbaa !24
  %t524 = load i64, ptr %l17, !tbaa !24
  %t527 = icmp sgt i64 %t523, %t524
  br i1 %t527, label %bb90, label %bb91
bb90:
  %t529 = load i64, ptr %l19, !tbaa !24
  %t531 = icmp sgt i64 %t529, 0
  br i1 %t531, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb95
bb92:
  %t533 = load i64, ptr %l18, !tbaa !24
  %t534 = load i64, ptr %l17, !tbaa !24
  %t537 = sub i64 %t533, %t534
  %t538 = load i64, ptr %l19, !tbaa !24
  %t541 = add i64 %t537, %t538
  %t543 = sub i64 %t541, 1
  %t544 = load i64, ptr %l19, !tbaa !24
  %t547 = sdiv i64 %t543, %t544
  store i64 %t547, ptr %l285, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l285, !tbaa !24
  br label %bb94
bb94:
  %t549 = load i64, ptr %l285, !tbaa !24
  store i64 %t549, ptr %l282, !tbaa !24
  br label %bb95
bb95:
  %t550 = load i64, ptr %l282, !tbaa !24
  store i64 %t550, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb96
bb96:
  %t551 = load i64, ptr %l21, !tbaa !24
  %t552 = load i64, ptr %l20, !tbaa !24
  %t555 = icmp slt i64 %t551, %t552
  %t557 = xor i1 %t555, true
  br i1 %t557, label %bb97, label %bb98
bb97:
  br label %bb107
bb98:
  br label %bb99
bb99:
  %t559 = load i64, ptr %l17, !tbaa !24
  %t560 = load i64, ptr %l21, !tbaa !24
  %t561 = load i64, ptr %l19, !tbaa !24
  %t564 = mul i64 %t560, %t561
  %t567 = add i64 %t559, %t564
  store i64 %t567, ptr %l22, !tbaa !24
  %t569 = load ptr, ptr %l1, !tbaa !29
  %t571 = getelementptr %"compiler/mir:Fn", ptr %t569, i32 0, i32 7
  %t572 = load i64, ptr %l22, !tbaa !24
  %t573 = load ptr, ptr @__olang_prog_scope
  %t576 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t573, ptr %t571, i64 %t572)
  store %"compiler/mir:Local" %t576, ptr %l306
  br label %bb100
bb100:
  %t577 = load %"compiler/mir:Local", ptr %l306
  store %"compiler/mir:Local" %t577, ptr %l23
  %t578 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 2
  %t579 = load i32, ptr %t578, !tbaa !23
  %t580 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t583 = icmp eq i32 %t579, %t580
  br i1 %t583, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s20
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load i64, ptr %l22, !tbaa !24
  %t587 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t588 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t590 = call i64 @__olang_fmt_i64(ptr null, i64 %t586)
  %t591 = add i64 %t588, %t590
  %t592 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t593 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t594 = add i64 %t591, %t593
  %t595 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t594)
  call void @olang_textcopy(ptr %t595, ptr %t587, i64 %t588)
  %t596 = getelementptr i8, ptr %t595, i64 %t588
  %t597 = call i64 @__olang_fmt_i64(ptr %t596, i64 %t586)
  %t598 = getelementptr i8, ptr %t596, i64 %t590
  call void @olang_textcopy(ptr %t598, ptr %t592, i64 %t593)
  %t599 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t595, 1
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s20, ptr %t585, { i64, ptr } %t607)
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb104
bb104:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/mir:Local", ptr %l23, i32 0, i32 4
  %t612 = load { i64, [1 x i64] }, ptr %t611
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t610, { i64, [1 x i64] } %t612)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t615 = load i64, ptr %l21, !tbaa !24
  %t617 = add i64 %t615, 1
  store i64 %t617, ptr %l21, !tbaa !24
  br label %bb96
bb107:
  store i64 0, ptr %l24, !tbaa !24
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr %"compiler/mir:Fn", ptr %t619, i32 0, i32 8
  %t622 = load ptr, ptr @__olang_prog_scope
  %t624 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t622, ptr %t621)
  store i64 %t624, ptr %l320
  br label %bb108
bb108:
  %t625 = load i64, ptr %l320, !tbaa !24
  store i64 %t625, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t626 = load i64, ptr %l25, !tbaa !24
  %t627 = load i64, ptr %l24, !tbaa !24
  %t630 = icmp sgt i64 %t626, %t627
  br i1 %t630, label %bb109, label %bb110
bb109:
  %t632 = load i64, ptr %l26, !tbaa !24
  %t634 = icmp sgt i64 %t632, 0
  br i1 %t634, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb114
bb111:
  %t636 = load i64, ptr %l25, !tbaa !24
  %t637 = load i64, ptr %l24, !tbaa !24
  %t640 = sub i64 %t636, %t637
  %t641 = load i64, ptr %l26, !tbaa !24
  %t644 = add i64 %t640, %t641
  %t646 = sub i64 %t644, 1
  %t647 = load i64, ptr %l26, !tbaa !24
  %t650 = sdiv i64 %t646, %t647
  store i64 %t650, ptr %l327, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb113
bb113:
  %t652 = load i64, ptr %l327, !tbaa !24
  store i64 %t652, ptr %l324, !tbaa !24
  br label %bb114
bb114:
  %t653 = load i64, ptr %l324, !tbaa !24
  store i64 %t653, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb115
bb115:
  %t654 = load i64, ptr %l28, !tbaa !24
  %t655 = load i64, ptr %l27, !tbaa !24
  %t658 = icmp slt i64 %t654, %t655
  %t660 = xor i1 %t658, true
  br i1 %t660, label %bb116, label %bb117
bb116:
  br label %bb128
bb117:
  br label %bb118
bb118:
  %t662 = load i64, ptr %l24, !tbaa !24
  %t663 = load i64, ptr %l28, !tbaa !24
  %t664 = load i64, ptr %l26, !tbaa !24
  %t667 = mul i64 %t663, %t664
  %t670 = add i64 %t662, %t667
  store i64 %t670, ptr %l29, !tbaa !24
  %t672 = load ptr, ptr %l1, !tbaa !29
  %t674 = getelementptr %"compiler/mir:Fn", ptr %t672, i32 0, i32 8
  %t675 = load i64, ptr %l29, !tbaa !24
  %t676 = load ptr, ptr @__olang_prog_scope
  %t679 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t676, ptr %t674, i64 %t675)
  store %"compiler/mir:ScopeInfo" %t679, ptr %l348
  br label %bb119
bb119:
  %t680 = getelementptr %"compiler/mir:ScopeInfo", ptr %l348, i32 0, i32 1
  %t681 = load i32, ptr %t680, !tbaa !23
  store i32 %t681, ptr %l30, !tbaa !23
  %t683 = load i32, ptr %l30, !tbaa !23
  %t684 = load i64, ptr %l29, !tbaa !24
  %t686 = trunc i64 %t684 to i32
  %t690 = icmp sge i32 %t683, %t686
  br i1 %t690, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l355, !tbaa !21
  br label %bb122
bb121:
  %t692 = load i32, ptr %l30, !tbaa !23
  %t693 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t696 = icmp slt i32 %t692, %t693
  store i1 %t696, ptr %l355, !tbaa !21
  br label %bb122
bb122:
  %t698 = load i1, ptr %l355, !tbaa !21
  br i1 %t698, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s25
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load i64, ptr %l29, !tbaa !24
  %t701 = load i32, ptr %l30, !tbaa !23
  %t702 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t705 = call i64 @__olang_fmt_i64(ptr null, i64 %t700)
  %t706 = add i64 %t703, %t705
  %t707 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t709 = add i64 %t706, %t708
  %t711 = sext i32 %t701 to i64
  %t712 = call i64 @__olang_fmt_i64(ptr null, i64 %t711)
  %t713 = add i64 %t709, %t712
  %t714 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t715 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t716 = add i64 %t713, %t715
  %t717 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t716)
  call void @olang_textcopy(ptr %t717, ptr %t702, i64 %t703)
  %t718 = getelementptr i8, ptr %t717, i64 %t703
  %t719 = call i64 @__olang_fmt_i64(ptr %t718, i64 %t700)
  %t720 = getelementptr i8, ptr %t718, i64 %t705
  call void @olang_textcopy(ptr %t720, ptr %t707, i64 %t708)
  %t721 = getelementptr i8, ptr %t720, i64 %t708
  %t722 = call i64 @__olang_fmt_i64(ptr %t721, i64 %t711)
  %t723 = getelementptr i8, ptr %t721, i64 %t712
  call void @olang_textcopy(ptr %t723, ptr %t714, i64 %t715)
  %t724 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t717, 1
  %t727 = extractvalue { i64, ptr } %t725, 0
  %t728 = extractvalue { i64, ptr } %t725, 1
  %t729 = mul i64 %t727, 1
  %t730 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t729)
  call void @llvm.memcpy.p0.p0.i64(ptr %t730, ptr %t728, i64 %t729, i1 false)
  %t731 = insertvalue { i64, ptr } undef, i64 %t727, 0
  %t732 = insertvalue { i64, ptr } %t731, ptr %t730, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s25, ptr %t699, { i64, ptr } %t732)
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t735 = load i64, ptr %l28, !tbaa !24
  %t737 = add i64 %t735, 1
  store i64 %t737, ptr %l28, !tbaa !24
  br label %bb115
bb128:
  %t739 = load ptr, ptr %l1, !tbaa !29
  %t741 = getelementptr %"compiler/mir:Fn", ptr %t739, i32 0, i32 14
  store ptr %t741, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb129
bb129:
  %t743 = load i64, ptr %l32, !tbaa !24
  store i64 %t743, ptr %l368, !tbaa !24
  %t744 = load ptr, ptr %l31, !tbaa !29
  %t745 = load ptr, ptr @__olang_prog_scope
  %t747 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %t745, ptr %t744)
  store i64 %t747, ptr %l370
  br label %bb130
bb130:
  %t748 = load i64, ptr %l368, !tbaa !24
  %t749 = load i64, ptr %l370, !tbaa !24
  %t750 = icmp slt i64 %t748, %t749
  %t752 = xor i1 %t750, true
  br i1 %t752, label %bb131, label %bb132
bb131:
  br label %bb152
bb132:
  br label %bb133
bb133:
  %t754 = load ptr, ptr %l31, !tbaa !29
  %t755 = load i64, ptr %l32, !tbaa !24
  %t756 = load ptr, ptr @__olang_prog_scope
  %t759 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t756, ptr %t754, i64 %t755)
  store %"compiler/mir:Call" %t759, ptr %l375
  br label %bb134
bb134:
  %t760 = load %"compiler/mir:Call", ptr %l375
  store %"compiler/mir:Call" %t760, ptr %l33
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 0
  %t763 = load { i64, [7 x i64] }, ptr %t762
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t761, { i64, [7 x i64] } %t763)
  br label %bb135
bb135:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 1
  %t768 = load %"compiler/mir:Range", ptr %t767
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t766, %"compiler/mir:Range" %t768)
  br label %bb136
bb136:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t772 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 2
  %t773 = load %"compiler/mir:Range", ptr %t772
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t771, %"compiler/mir:Range" %t773)
  br label %bb137
bb137:
  %t776 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 4
  %t777 = load i1, ptr %t776, !tbaa !21
  br i1 %t777, label %bb138, label %bb139
bb138:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 3
  %t781 = load %"compiler/mir:Lvalue", ptr %t780
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t779, %"compiler/mir:Lvalue" %t781)
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  %t784 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t785 = load i32, ptr %t784, !tbaa !23
  %t786 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t789 = icmp ne i32 %t785, %t786
  br i1 %t789, label %bb142, label %bb143
bb142:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 5
  %t793 = load i32, ptr %t792, !tbaa !23
  %t796 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t791, i32 %t793)
  store i1 %t796, ptr %l390
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  %t797 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t798 = load i32, ptr %t797, !tbaa !23
  %t799 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t802 = icmp ne i32 %t798, %t799
  br i1 %t802, label %bb146, label %bb147
bb146:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 7
  %t806 = load i32, ptr %t805, !tbaa !23
  %t809 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t804, i32 %t806)
  store i1 %t809, ptr %l396
  br label %bb148
bb147:
  br label %bb150
bb148:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = getelementptr %"compiler/mir:Call", ptr %l33, i32 0, i32 6
  %t812 = load i32, ptr %t811, !tbaa !23
  %t815 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t810, i32 %t812)
  store i1 %t815, ptr %l399
  br label %bb149
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t816 = load i64, ptr %l32, !tbaa !24
  %t818 = add i64 %t816, 1
  store i64 %t818, ptr %l32, !tbaa !24
  br label %bb129
bb152:
  %t820 = load ptr, ptr %l1, !tbaa !29
  %t822 = getelementptr %"compiler/mir:Fn", ptr %t820, i32 0, i32 15
  store ptr %t822, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb153
bb153:
  %t824 = load i64, ptr %l35, !tbaa !24
  store i64 %t824, ptr %l404, !tbaa !24
  %t825 = load ptr, ptr %l34, !tbaa !29
  %t826 = load ptr, ptr @__olang_prog_scope
  %t828 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %t826, ptr %t825)
  store i64 %t828, ptr %l406
  br label %bb154
bb154:
  %t829 = load i64, ptr %l404, !tbaa !24
  %t830 = load i64, ptr %l406, !tbaa !24
  %t831 = icmp slt i64 %t829, %t830
  %t833 = xor i1 %t831, true
  br i1 %t833, label %bb155, label %bb156
bb155:
  br label %bb161
bb156:
  br label %bb157
bb157:
  %t835 = load ptr, ptr %l34, !tbaa !29
  %t836 = load i64, ptr %l35, !tbaa !24
  %t837 = load ptr, ptr @__olang_prog_scope
  %t840 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t837, ptr %t835, i64 %t836)
  store %"compiler/mir:Case" %t840, ptr %l411
  br label %bb158
bb158:
  %t841 = load %"compiler/mir:Case", ptr %l411
  store %"compiler/mir:Case" %t841, ptr %l36
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/mir:Case", ptr %l36, i32 0, i32 1
  %t844 = load i32, ptr %t843, !tbaa !23
  %t847 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t842, i32 %t844)
  store i1 %t847, ptr %l414
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t848 = load i64, ptr %l35, !tbaa !24
  %t850 = add i64 %t848, 1
  store i64 %t850, ptr %l35, !tbaa !24
  br label %bb153
bb161:
  %t852 = load ptr, ptr %l1, !tbaa !29
  %t854 = getelementptr %"compiler/mir:Fn", ptr %t852, i32 0, i32 16
  store ptr %t854, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s38
  %t856 = load i64, ptr %l38, !tbaa !24
  store i64 %t856, ptr %l419, !tbaa !24
  %t857 = load ptr, ptr %l37, !tbaa !29
  %t858 = load ptr, ptr @__olang_prog_scope
  %t860 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %t858, ptr %t857)
  store i64 %t860, ptr %l421
  br label %bb163
bb163:
  %t861 = load i64, ptr %l419, !tbaa !24
  %t862 = load i64, ptr %l421, !tbaa !24
  %t863 = icmp slt i64 %t861, %t862
  %t865 = xor i1 %t863, true
  br i1 %t865, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s38)
  br label %bb221
bb165:
  br label %bb166
bb166:
  %t867 = load ptr, ptr %l37, !tbaa !29
  %t868 = load i64, ptr %l38, !tbaa !24
  %t869 = load ptr, ptr @__olang_prog_scope
  %t872 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t869, ptr %t867, i64 %t868)
  store %"compiler/mir:Task" %t872, ptr %l426
  br label %bb167
bb167:
  %t873 = load %"compiler/mir:Task", ptr %l426
  store %"compiler/mir:Task" %t873, ptr %l39
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 0
  %t876 = load { i64, [7 x i64] }, ptr %t875
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %t874, { i64, [7 x i64] } %t876)
  br label %bb168
bb168:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 1
  %t881 = load %"compiler/mir:Range", ptr %t880
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t879, %"compiler/mir:Range" %t881)
  br label %bb169
bb169:
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 5
  %t886 = load %"compiler/mir:Range", ptr %t885
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %t884, %"compiler/mir:Range" %t886)
  br label %bb170
bb170:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 2
  %t891 = load %"compiler/mir:Range", ptr %t890
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t889, %"compiler/mir:Range" %t891)
  br label %bb171
bb171:
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t896 = load %"compiler/mir:Range", ptr %t895
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %t894, %"compiler/mir:Range" %t896)
  br label %bb172
bb172:
  %t899 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t900 = getelementptr %"compiler/mir:Range", ptr %t899, i32 0, i32 1
  %t901 = load i32, ptr %t900, !tbaa !23
  %t903 = icmp ne i32 %t901, 0
  br i1 %t903, label %bb173, label %bb174
bb173:
  %t905 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 7
  %t906 = getelementptr %"compiler/mir:Range", ptr %t905, i32 0, i32 1
  %t907 = load i32, ptr %t906, !tbaa !23
  %t908 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t909 = getelementptr %"compiler/mir:Range", ptr %t908, i32 0, i32 1
  %t910 = load i32, ptr %t909, !tbaa !23
  %t913 = icmp ne i32 %t907, %t910
  store i1 %t913, ptr %l439, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb175
bb175:
  %t915 = load i1, ptr %l439, !tbaa !21
  br i1 %t915, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s39
  %t916 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t916, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s39)
  br label %bb179
bb179:
  %t918 = load ptr, ptr %l0, !tbaa !29
  store ptr %t918, ptr %l444, !tbaa !29
  %t919 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t920 = load %"compiler/mir:Range", ptr %t919
  store %"compiler/mir:Range" %t920, ptr %l445
  %t921 = load ptr, ptr %l1, !tbaa !29
  %t923 = getelementptr %"compiler/mir:Fn", ptr %t921, i32 0, i32 13
  %t924 = load ptr, ptr @__olang_prog_scope
  %t926 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %t924, ptr %t923)
  store i64 %t926, ptr %l448
  br label %bb180
bb180:
  %t927 = load ptr, ptr %l444, !tbaa !29
  %t928 = load %"compiler/mir:Range", ptr %l445
  %t929 = load i64, ptr %l448, !tbaa !24
  %t930 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t927, %"compiler/mir:Range" %t928, i64 %t929, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t930, ptr %l449
  br label %bb181
bb181:
  %t931 = load i1, ptr %l449, !tbaa !21
  br i1 %t931, label %bb182, label %bb183
bb182:
  store i32 0, ptr %l40, !tbaa !23
  %t932 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t933 = getelementptr %"compiler/mir:Range", ptr %t932, i32 0, i32 1
  %t934 = load i32, ptr %t933, !tbaa !23
  store i32 %t934, ptr %l41, !tbaa !23
  store i32 1, ptr %l42, !tbaa !23
  %t936 = load i32, ptr %l41, !tbaa !23
  %t937 = load i32, ptr %l40, !tbaa !23
  %t940 = icmp sgt i32 %t936, %t937
  br i1 %t940, label %bb184, label %bb185
bb183:
  br label %bb198
bb184:
  %t942 = load i32, ptr %l42, !tbaa !23
  %t944 = icmp sgt i32 %t942, 0
  br i1 %t944, label %bb186, label %bb187
bb185:
  store i32 0, ptr %l454, !tbaa !23
  br label %bb189
bb186:
  %t946 = load i32, ptr %l41, !tbaa !23
  %t947 = load i32, ptr %l40, !tbaa !23
  %t950 = sub i32 %t946, %t947
  %t951 = load i32, ptr %l42, !tbaa !23
  %t954 = add i32 %t950, %t951
  %t956 = sub i32 %t954, 1
  %t957 = load i32, ptr %l42, !tbaa !23
  %t960 = sdiv i32 %t956, %t957
  store i32 %t960, ptr %l457, !tbaa !23
  br label %bb188
bb187:
  store i32 0, ptr %l457, !tbaa !23
  br label %bb188
bb188:
  %t962 = load i32, ptr %l457, !tbaa !23
  store i32 %t962, ptr %l454, !tbaa !23
  br label %bb189
bb189:
  %t963 = load i32, ptr %l454, !tbaa !23
  store i32 %t963, ptr %l43, !tbaa !23
  store i32 0, ptr %l44, !tbaa !23
  br label %bb190
bb190:
  %t964 = load i32, ptr %l44, !tbaa !23
  %t965 = load i32, ptr %l43, !tbaa !23
  %t968 = icmp slt i32 %t964, %t965
  %t970 = xor i1 %t968, true
  br i1 %t970, label %bb191, label %bb192
bb191:
  br label %bb197
bb192:
  br label %bb193
bb193:
  %t972 = load i32, ptr %l40, !tbaa !23
  %t973 = load i32, ptr %l44, !tbaa !23
  %t974 = load i32, ptr %l42, !tbaa !23
  %t977 = mul i32 %t973, %t974
  %t980 = add i32 %t972, %t977
  %t982 = load ptr, ptr %l0, !tbaa !29
  store ptr %t982, ptr %l475, !tbaa !29
  %t983 = load ptr, ptr %l1, !tbaa !29
  %t985 = getelementptr %"compiler/mir:Fn", ptr %t983, i32 0, i32 13
  %t986 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 3
  %t987 = getelementptr %"compiler/mir:Range", ptr %t986, i32 0, i32 0
  %t988 = load i32, ptr %t987, !tbaa !23
  %t990 = sext i32 %t988 to i64
  %t993 = sext i32 %t980 to i64
  %t996 = add i64 %t990, %t993
  %t997 = load ptr, ptr @__olang_prog_scope
  %t1000 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t997, ptr %t985, i64 %t996)
  store %"compiler/mir:Lvalue" %t1000, ptr %l483
  br label %bb194
bb194:
  %t1001 = load ptr, ptr %l475, !tbaa !29
  %t1002 = load %"compiler/mir:Lvalue", ptr %l483
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t1001, %"compiler/mir:Lvalue" %t1002)
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t1003 = load i32, ptr %l44, !tbaa !23
  %t1005 = add i32 %t1003, 1
  store i32 %t1005, ptr %l44, !tbaa !23
  br label %bb190
bb197:
  br label %bb198
bb198:
  %t1007 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1007, ptr %l486, !tbaa !29
  %t1008 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1009 = load %"compiler/mir:Range", ptr %t1008
  store %"compiler/mir:Range" %t1009, ptr %l487
  %t1010 = load ptr, ptr %l1, !tbaa !29
  %t1012 = getelementptr %"compiler/mir:Fn", ptr %t1010, i32 0, i32 17
  %t1013 = load ptr, ptr @__olang_prog_scope
  %t1015 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %t1013, ptr %t1012)
  store i64 %t1015, ptr %l490
  br label %bb199
bb199:
  %t1016 = load ptr, ptr %l486, !tbaa !29
  %t1017 = load %"compiler/mir:Range", ptr %l487
  %t1018 = load i64, ptr %l490, !tbaa !24
  %t1019 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s38, ptr %t1016, %"compiler/mir:Range" %t1017, i64 %t1018, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t1019, ptr %l491
  br label %bb200
bb200:
  %t1020 = load i1, ptr %l491, !tbaa !21
  br i1 %t1020, label %bb201, label %bb202
bb201:
  store i32 0, ptr %l46, !tbaa !23
  %t1021 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1022 = getelementptr %"compiler/mir:Range", ptr %t1021, i32 0, i32 1
  %t1023 = load i32, ptr %t1022, !tbaa !23
  store i32 %t1023, ptr %l47, !tbaa !23
  store i32 1, ptr %l48, !tbaa !23
  %t1025 = load i32, ptr %l47, !tbaa !23
  %t1026 = load i32, ptr %l46, !tbaa !23
  %t1029 = icmp sgt i32 %t1025, %t1026
  br i1 %t1029, label %bb203, label %bb204
bb202:
  br label %bb219
bb203:
  %t1031 = load i32, ptr %l48, !tbaa !23
  %t1033 = icmp sgt i32 %t1031, 0
  br i1 %t1033, label %bb205, label %bb206
bb204:
  store i32 0, ptr %l496, !tbaa !23
  br label %bb208
bb205:
  %t1035 = load i32, ptr %l47, !tbaa !23
  %t1036 = load i32, ptr %l46, !tbaa !23
  %t1039 = sub i32 %t1035, %t1036
  %t1040 = load i32, ptr %l48, !tbaa !23
  %t1043 = add i32 %t1039, %t1040
  %t1045 = sub i32 %t1043, 1
  %t1046 = load i32, ptr %l48, !tbaa !23
  %t1049 = sdiv i32 %t1045, %t1046
  store i32 %t1049, ptr %l499, !tbaa !23
  br label %bb207
bb206:
  store i32 0, ptr %l499, !tbaa !23
  br label %bb207
bb207:
  %t1051 = load i32, ptr %l499, !tbaa !23
  store i32 %t1051, ptr %l496, !tbaa !23
  br label %bb208
bb208:
  %t1052 = load i32, ptr %l496, !tbaa !23
  store i32 %t1052, ptr %l49, !tbaa !23
  store i32 0, ptr %l50, !tbaa !23
  br label %bb209
bb209:
  store %olang.scope zeroinitializer, ptr %s46
  %t1053 = load i32, ptr %l50, !tbaa !23
  %t1054 = load i32, ptr %l49, !tbaa !23
  %t1057 = icmp slt i32 %t1053, %t1054
  %t1059 = xor i1 %t1057, true
  br i1 %t1059, label %bb210, label %bb211
bb210:
  call void @__olang_scope_close(ptr %s46)
  br label %bb218
bb211:
  br label %bb212
bb212:
  %t1061 = load i32, ptr %l46, !tbaa !23
  %t1062 = load i32, ptr %l50, !tbaa !23
  %t1063 = load i32, ptr %l48, !tbaa !23
  %t1066 = mul i32 %t1062, %t1063
  %t1069 = add i32 %t1061, %t1066
  %t1071 = load ptr, ptr %l1, !tbaa !29
  %t1073 = getelementptr %"compiler/mir:Fn", ptr %t1071, i32 0, i32 17
  %t1074 = getelementptr %"compiler/mir:Task", ptr %l39, i32 0, i32 4
  %t1075 = getelementptr %"compiler/mir:Range", ptr %t1074, i32 0, i32 0
  %t1076 = load i32, ptr %t1075, !tbaa !23
  %t1078 = sext i32 %t1076 to i64
  %t1081 = sext i32 %t1069 to i64
  %t1084 = add i64 %t1078, %t1081
  %t1085 = load ptr, ptr @__olang_prog_scope
  %t1088 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t1085, ptr %t1073, i64 %t1084)
  store %"compiler/mir:TaskClause" %t1088, ptr %l524
  br label %bb213
bb213:
  %t1089 = load %"compiler/mir:TaskClause", ptr %l524
  store %"compiler/mir:TaskClause" %t1089, ptr %l52
  %t1090 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1090, ptr %l525, !tbaa !29
  %t1091 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 0
  %t1092 = load %"compiler/mir:Range", ptr %t1091
  store %"compiler/mir:Range" %t1092, ptr %l526
  %t1093 = load ptr, ptr %l1, !tbaa !29
  %t1095 = getelementptr %"compiler/mir:Fn", ptr %t1093, i32 0, i32 18
  %t1096 = load ptr, ptr @__olang_prog_scope
  %t1098 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %t1096, ptr %t1095)
  store i64 %t1098, ptr %l529
  br label %bb214
bb214:
  %t1099 = load ptr, ptr %l525, !tbaa !29
  %t1100 = load %"compiler/mir:Range", ptr %l526
  %t1101 = load i64, ptr %l529, !tbaa !24
  %t1102 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s46, ptr %t1099, %"compiler/mir:Range" %t1100, i64 %t1101, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store i1 %t1102, ptr %l530
  br label %bb215
bb215:
  %t1103 = load ptr, ptr %l0, !tbaa !29
  %t1104 = getelementptr %"compiler/mir:TaskClause", ptr %l52, i32 0, i32 2
  %t1105 = load { i64, [4 x i64] }, ptr %t1104
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1103, { i64, [4 x i64] } %t1105)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s46)
  br label %bb217
bb217:
  %t1108 = load i32, ptr %l50, !tbaa !23
  %t1110 = add i32 %t1108, 1
  store i32 %t1110, ptr %l50, !tbaa !23
  br label %bb209
bb218:
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s38)
  br label %bb220
bb220:
  %t1112 = load i64, ptr %l38, !tbaa !24
  %t1114 = add i64 %t1112, 1
  store i64 %t1114, ptr %l38, !tbaa !24
  br label %bb162
bb221:
  %t1116 = load ptr, ptr %l1, !tbaa !29
  %t1118 = getelementptr %"compiler/mir:Fn", ptr %t1116, i32 0, i32 11
  store ptr %t1118, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb222
bb222:
  %t1120 = load i64, ptr %l54, !tbaa !24
  store i64 %t1120, ptr %l539, !tbaa !24
  %t1121 = load ptr, ptr %l53, !tbaa !29
  %t1122 = load ptr, ptr @__olang_prog_scope
  %t1124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %t1122, ptr %t1121)
  store i64 %t1124, ptr %l541
  br label %bb223
bb223:
  %t1125 = load i64, ptr %l539, !tbaa !24
  %t1126 = load i64, ptr %l541, !tbaa !24
  %t1127 = icmp slt i64 %t1125, %t1126
  %t1129 = xor i1 %t1127, true
  br i1 %t1129, label %bb224, label %bb225
bb224:
  br label %bb230
bb225:
  br label %bb226
bb226:
  %t1131 = load ptr, ptr %l53, !tbaa !29
  %t1132 = load i64, ptr %l54, !tbaa !24
  %t1133 = load ptr, ptr @__olang_prog_scope
  %t1136 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t1133, ptr %t1131, i64 %t1132)
  store { i64, [4 x i64] } %t1136, ptr %l546
  br label %bb227
bb227:
  %t1137 = load { i64, [4 x i64] }, ptr %l546
  %t1138 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t1138, { i64, [4 x i64] } %t1137)
  br label %bb228
bb228:
  br label %bb229
bb229:
  %t1142 = load i64, ptr %l54, !tbaa !24
  %t1144 = add i64 %t1142, 1
  store i64 %t1144, ptr %l54, !tbaa !24
  br label %bb222
bb230:
  %t1146 = load ptr, ptr %l1, !tbaa !29
  %t1148 = getelementptr %"compiler/mir:Fn", ptr %t1146, i32 0, i32 12
  store ptr %t1148, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb231
bb231:
  %t1150 = load i64, ptr %l57, !tbaa !24
  store i64 %t1150, ptr %l553, !tbaa !24
  %t1151 = load ptr, ptr %l56, !tbaa !29
  %t1152 = load ptr, ptr @__olang_prog_scope
  %t1154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1152, ptr %t1151)
  store i64 %t1154, ptr %l555
  br label %bb232
bb232:
  %t1155 = load i64, ptr %l553, !tbaa !24
  %t1156 = load i64, ptr %l555, !tbaa !24
  %t1157 = icmp slt i64 %t1155, %t1156
  %t1159 = xor i1 %t1157, true
  br i1 %t1159, label %bb233, label %bb234
bb233:
  br label %bb239
bb234:
  br label %bb235
bb235:
  %t1161 = load ptr, ptr %l56, !tbaa !29
  %t1162 = load i64, ptr %l57, !tbaa !24
  %t1163 = load ptr, ptr @__olang_prog_scope
  %t1166 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t1163, ptr %t1161, i64 %t1162)
  store { i64, [1 x i64] } %t1166, ptr %l560
  br label %bb236
bb236:
  %t1167 = load { i64, [1 x i64] }, ptr %l560
  %t1168 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t1168, { i64, [1 x i64] } %t1167)
  br label %bb237
bb237:
  br label %bb238
bb238:
  %t1172 = load i64, ptr %l57, !tbaa !24
  %t1174 = add i64 %t1172, 1
  store i64 %t1174, ptr %l57, !tbaa !24
  br label %bb231
bb239:
  %t1176 = load ptr, ptr %l1, !tbaa !29
  %t1178 = getelementptr %"compiler/mir:Fn", ptr %t1176, i32 0, i32 10
  store ptr %t1178, ptr %l59, !tbaa !29
  store i64 0, ptr %l60, !tbaa !24
  br label %bb240
bb240:
  %t1180 = load i64, ptr %l60, !tbaa !24
  store i64 %t1180, ptr %l567, !tbaa !24
  %t1181 = load ptr, ptr %l59, !tbaa !29
  %t1182 = load ptr, ptr @__olang_prog_scope
  %t1184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %t1182, ptr %t1181)
  store i64 %t1184, ptr %l569
  br label %bb241
bb241:
  %t1185 = load i64, ptr %l567, !tbaa !24
  %t1186 = load i64, ptr %l569, !tbaa !24
  %t1187 = icmp slt i64 %t1185, %t1186
  %t1189 = xor i1 %t1187, true
  br i1 %t1189, label %bb242, label %bb243
bb242:
  br label %bb257
bb243:
  br label %bb244
bb244:
  %t1191 = load ptr, ptr %l59, !tbaa !29
  %t1192 = load i64, ptr %l60, !tbaa !24
  %t1193 = load ptr, ptr @__olang_prog_scope
  %t1196 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t1193, ptr %t1191, i64 %t1192)
  store { i64, [1 x i64] } %t1196, ptr %l574
  br label %bb245
bb245:
  %t1197 = load { i64, [1 x i64] }, ptr %l574
  store { i64, [1 x i64] } %t1197, ptr %l61
  %t1198 = load { i64, [1 x i64] }, ptr %l61
  %t1200 = extractvalue { i64, [1 x i64] } %t1198, 0
  %t1201 = icmp eq i64 %t1200, 1
  br i1 %t1201, label %bb246, label %bb247
bb246:
  %t1203 = getelementptr { i64, [1 x i64] }, ptr %l61, i32 0, i32 1
  %t1204 = getelementptr { i32 }, ptr %t1203, i32 0, i32 0
  %t1205 = load i32, ptr %t1204
  store i32 %t1205, ptr %l62, !tbaa !23
  br label %bb248
bb247:
  br label %bb250
bb248:
  %t1207 = load ptr, ptr %l0, !tbaa !29
  %t1208 = load i32, ptr %l62, !tbaa !23
  %t1211 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t1207, i32 %t1208)
  store i1 %t1211, ptr %l580
  br label %bb249
bb249:
  br label %bb255
bb250:
  br i1 true, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb254
bb253:
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_729af306d1a375bd_3b9d78bce782a851)
  unreachable
bb255:
  br label %bb256
bb256:
  %t1212 = load i64, ptr %l60, !tbaa !24
  %t1214 = add i64 %t1212, 1
  store i64 %t1214, ptr %l60, !tbaa !24
  br label %bb240
bb257:
  store i64 0, ptr %l63, !tbaa !24
  %t1216 = load ptr, ptr %l1, !tbaa !29
  %t1218 = getelementptr %"compiler/mir:Fn", ptr %t1216, i32 0, i32 19
  %t1219 = load ptr, ptr @__olang_prog_scope
  %t1221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %t1219, ptr %t1218)
  store i64 %t1221, ptr %l585
  br label %bb258
bb258:
  %t1222 = load i64, ptr %l585, !tbaa !24
  store i64 %t1222, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t1223 = load i64, ptr %l64, !tbaa !24
  %t1224 = load i64, ptr %l63, !tbaa !24
  %t1227 = icmp sgt i64 %t1223, %t1224
  br i1 %t1227, label %bb259, label %bb260
bb259:
  %t1229 = load i64, ptr %l65, !tbaa !24
  %t1231 = icmp sgt i64 %t1229, 0
  br i1 %t1231, label %bb261, label %bb262
bb260:
  store i64 0, ptr %l589, !tbaa !24
  br label %bb264
bb261:
  %t1233 = load i64, ptr %l64, !tbaa !24
  %t1234 = load i64, ptr %l63, !tbaa !24
  %t1237 = sub i64 %t1233, %t1234
  %t1238 = load i64, ptr %l65, !tbaa !24
  %t1241 = add i64 %t1237, %t1238
  %t1243 = sub i64 %t1241, 1
  %t1244 = load i64, ptr %l65, !tbaa !24
  %t1247 = sdiv i64 %t1243, %t1244
  store i64 %t1247, ptr %l592, !tbaa !24
  br label %bb263
bb262:
  store i64 0, ptr %l592, !tbaa !24
  br label %bb263
bb263:
  %t1249 = load i64, ptr %l592, !tbaa !24
  store i64 %t1249, ptr %l589, !tbaa !24
  br label %bb264
bb264:
  %t1250 = load i64, ptr %l589, !tbaa !24
  store i64 %t1250, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb265
bb265:
  %t1251 = load i64, ptr %l67, !tbaa !24
  %t1252 = load i64, ptr %l66, !tbaa !24
  %t1255 = icmp slt i64 %t1251, %t1252
  %t1257 = xor i1 %t1255, true
  br i1 %t1257, label %bb266, label %bb267
bb266:
  br label %bb292
bb267:
  br label %bb268
bb268:
  %t1259 = load i64, ptr %l63, !tbaa !24
  %t1260 = load i64, ptr %l67, !tbaa !24
  %t1261 = load i64, ptr %l65, !tbaa !24
  %t1264 = mul i64 %t1260, %t1261
  %t1267 = add i64 %t1259, %t1264
  store i64 %t1267, ptr %l68, !tbaa !24
  %t1269 = load ptr, ptr %l1, !tbaa !29
  %t1271 = getelementptr %"compiler/mir:Fn", ptr %t1269, i32 0, i32 19
  %t1272 = load i64, ptr %l68, !tbaa !24
  %t1273 = load ptr, ptr @__olang_prog_scope
  %t1276 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %t1273, ptr %t1271, i64 %t1272)
  store { i64, [1 x i64] } %t1276, ptr %l613
  br label %bb269
bb269:
  %t1277 = load { i64, [1 x i64] }, ptr %l613
  store { i64, [1 x i64] } %t1277, ptr %l69
  %t1278 = load { i64, [1 x i64] }, ptr %l69
  %t1280 = extractvalue { i64, [1 x i64] } %t1278, 0
  %t1281 = icmp eq i64 %t1280, 1
  br i1 %t1281, label %bb270, label %bb271
bb270:
  %t1283 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1284 = getelementptr { %"compiler/mir:Range" }, ptr %t1283, i32 0, i32 0
  %t1285 = load %"compiler/mir:Range", ptr %t1284
  store %"compiler/mir:Range" %t1285, ptr %l70
  br label %bb272
bb271:
  br label %bb275
bb272:
  store %olang.scope zeroinitializer, ptr %s62
  %t1287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1287, ptr %l617, !tbaa !29
  %t1288 = load %"compiler/mir:Range", ptr %l70
  store %"compiler/mir:Range" %t1288, ptr %l618
  %t1289 = load ptr, ptr %l1, !tbaa !29
  %t1291 = getelementptr %"compiler/mir:Fn", ptr %t1289, i32 0, i32 21
  %t1292 = load ptr, ptr @__olang_prog_scope
  %t1294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %t1292, ptr %t1291)
  store i64 %t1294, ptr %l621
  br label %bb273
bb273:
  %t1295 = load ptr, ptr %l617, !tbaa !29
  %t1296 = load %"compiler/mir:Range", ptr %l618
  %t1297 = load i64, ptr %l621, !tbaa !24
  %t1298 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s62, ptr %t1295, %"compiler/mir:Range" %t1296, i64 %t1297, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d157, i32 0, i32 1) })
  store i1 %t1298, ptr %l622
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s62)
  br label %bb290
bb275:
  %t1299 = load { i64, [1 x i64] }, ptr %l69
  %t1301 = extractvalue { i64, [1 x i64] } %t1299, 0
  %t1302 = icmp eq i64 %t1301, 2
  br i1 %t1302, label %bb276, label %bb277
bb276:
  %t1304 = getelementptr { i64, [1 x i64] }, ptr %l69, i32 0, i32 1
  %t1305 = getelementptr { %"compiler/mir:Range" }, ptr %t1304, i32 0, i32 0
  %t1306 = load %"compiler/mir:Range", ptr %t1305
  store %"compiler/mir:Range" %t1306, ptr %l71
  br label %bb278
bb277:
  br label %bb285
bb278:
  store %olang.scope zeroinitializer, ptr %s63
  %t1308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1308, ptr %l626, !tbaa !29
  %t1309 = load %"compiler/mir:Range", ptr %l71
  store %"compiler/mir:Range" %t1309, ptr %l627
  %t1310 = load ptr, ptr %l1, !tbaa !29
  %t1312 = getelementptr %"compiler/mir:Fn", ptr %t1310, i32 0, i32 20
  %t1313 = load ptr, ptr @__olang_prog_scope
  %t1315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %t1313, ptr %t1312)
  store i64 %t1315, ptr %l630
  br label %bb279
bb279:
  %t1316 = load ptr, ptr %l626, !tbaa !29
  %t1317 = load %"compiler/mir:Range", ptr %l627
  %t1318 = load i64, ptr %l630, !tbaa !24
  %t1319 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s63, ptr %t1316, %"compiler/mir:Range" %t1317, i64 %t1318, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t1319, ptr %l631
  br label %bb280
bb280:
  %t1320 = load i1, ptr %l631, !tbaa !21
  br i1 %t1320, label %bb281, label %bb282
bb281:
  %t1321 = load ptr, ptr %l0, !tbaa !29
  %t1322 = load %"compiler/mir:Range", ptr %l71
  %t1323 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eitemsBefore(ptr %v0, ptr %t1321, %"compiler/mir:Range" %t1322, i64 %t1323)
  br label %bb283
bb282:
  br label %bb284
bb283:
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s63)
  br label %bb290
bb285:
  br i1 true, label %bb286, label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb289
bb288:
  br label %bb290
bb289:
  call void @__olang_check_failed(ptr @olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0)
  unreachable
bb290:
  br label %bb291
bb291:
  %t1327 = load i64, ptr %l67, !tbaa !24
  %t1329 = add i64 %t1327, 1
  store i64 %t1329, ptr %l67, !tbaa !24
  br label %bb265
bb292:
  store i64 0, ptr %l72, !tbaa !24
  %t1331 = load ptr, ptr %l1, !tbaa !29
  %t1333 = getelementptr %"compiler/mir:Fn", ptr %t1331, i32 0, i32 9
  %t1334 = load ptr, ptr @__olang_prog_scope
  %t1336 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t1334, ptr %t1333)
  store i64 %t1336, ptr %l639
  br label %bb293
bb293:
  %t1337 = load i64, ptr %l639, !tbaa !24
  store i64 %t1337, ptr %l73, !tbaa !24
  store i64 1, ptr %l74, !tbaa !24
  %t1338 = load i64, ptr %l73, !tbaa !24
  %t1339 = load i64, ptr %l72, !tbaa !24
  %t1342 = icmp sgt i64 %t1338, %t1339
  br i1 %t1342, label %bb294, label %bb295
bb294:
  %t1344 = load i64, ptr %l74, !tbaa !24
  %t1346 = icmp sgt i64 %t1344, 0
  br i1 %t1346, label %bb296, label %bb297
bb295:
  store i64 0, ptr %l643, !tbaa !24
  br label %bb299
bb296:
  %t1348 = load i64, ptr %l73, !tbaa !24
  %t1349 = load i64, ptr %l72, !tbaa !24
  %t1352 = sub i64 %t1348, %t1349
  %t1353 = load i64, ptr %l74, !tbaa !24
  %t1356 = add i64 %t1352, %t1353
  %t1358 = sub i64 %t1356, 1
  %t1359 = load i64, ptr %l74, !tbaa !24
  %t1362 = sdiv i64 %t1358, %t1359
  store i64 %t1362, ptr %l646, !tbaa !24
  br label %bb298
bb297:
  store i64 0, ptr %l646, !tbaa !24
  br label %bb298
bb298:
  %t1364 = load i64, ptr %l646, !tbaa !24
  store i64 %t1364, ptr %l643, !tbaa !24
  br label %bb299
bb299:
  %t1365 = load i64, ptr %l643, !tbaa !24
  store i64 %t1365, ptr %l75, !tbaa !24
  store i64 0, ptr %l76, !tbaa !24
  br label %bb300
bb300:
  store %olang.scope zeroinitializer, ptr %s68
  %t1366 = load i64, ptr %l76, !tbaa !24
  %t1367 = load i64, ptr %l75, !tbaa !24
  %t1370 = icmp slt i64 %t1366, %t1367
  %t1372 = xor i1 %t1370, true
  br i1 %t1372, label %bb301, label %bb302
bb301:
  call void @__olang_scope_close(ptr %s68)
  br label %bb322
bb302:
  br label %bb303
bb303:
  %t1374 = load i64, ptr %l72, !tbaa !24
  %t1375 = load i64, ptr %l76, !tbaa !24
  %t1376 = load i64, ptr %l74, !tbaa !24
  %t1379 = mul i64 %t1375, %t1376
  %t1382 = add i64 %t1374, %t1379
  store i64 %t1382, ptr %l77, !tbaa !24
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1385 = load i64, ptr %l77, !tbaa !24
  %t1388 = getelementptr %"compiler/mir:verifier", ptr %t1384, i32 0, i32 3
  store i64 %t1385, ptr %t1388, !tbaa !24
  %t1389 = load ptr, ptr %l1, !tbaa !29
  %t1391 = getelementptr %"compiler/mir:Fn", ptr %t1389, i32 0, i32 9
  %t1392 = load i64, ptr %l77, !tbaa !24
  %t1393 = load ptr, ptr @__olang_prog_scope
  %t1396 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t1393, ptr %s68, ptr %t1391, i64 %t1392)
  store ptr %t1396, ptr %l669
  br label %bb304
bb304:
  %t1397 = load ptr, ptr %l669, !tbaa !29
  store ptr %t1397, ptr %l78, !tbaa !29
  store i64 0, ptr %l79, !tbaa !24
  %t1398 = load ptr, ptr %l78, !tbaa !29
  %t1400 = getelementptr %"compiler/mir:BasicBlock", ptr %t1398, i32 0, i32 0
  %t1402 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s68, ptr %t1400)
  store i64 %t1402, ptr %l672
  br label %bb305
bb305:
  %t1403 = load i64, ptr %l672, !tbaa !24
  store i64 %t1403, ptr %l80, !tbaa !24
  store i64 1, ptr %l81, !tbaa !24
  %t1404 = load i64, ptr %l80, !tbaa !24
  %t1405 = load i64, ptr %l79, !tbaa !24
  %t1408 = icmp sgt i64 %t1404, %t1405
  br i1 %t1408, label %bb306, label %bb307
bb306:
  %t1410 = load i64, ptr %l81, !tbaa !24
  %t1412 = icmp sgt i64 %t1410, 0
  br i1 %t1412, label %bb308, label %bb309
bb307:
  store i64 0, ptr %l676, !tbaa !24
  br label %bb311
bb308:
  %t1414 = load i64, ptr %l80, !tbaa !24
  %t1415 = load i64, ptr %l79, !tbaa !24
  %t1418 = sub i64 %t1414, %t1415
  %t1419 = load i64, ptr %l81, !tbaa !24
  %t1422 = add i64 %t1418, %t1419
  %t1424 = sub i64 %t1422, 1
  %t1425 = load i64, ptr %l81, !tbaa !24
  %t1428 = sdiv i64 %t1424, %t1425
  store i64 %t1428, ptr %l679, !tbaa !24
  br label %bb310
bb309:
  store i64 0, ptr %l679, !tbaa !24
  br label %bb310
bb310:
  %t1430 = load i64, ptr %l679, !tbaa !24
  store i64 %t1430, ptr %l676, !tbaa !24
  br label %bb311
bb311:
  %t1431 = load i64, ptr %l676, !tbaa !24
  store i64 %t1431, ptr %l82, !tbaa !24
  store i64 0, ptr %l83, !tbaa !24
  br label %bb312
bb312:
  store %olang.scope zeroinitializer, ptr %s70
  %t1432 = load i64, ptr %l83, !tbaa !24
  %t1433 = load i64, ptr %l82, !tbaa !24
  %t1436 = icmp slt i64 %t1432, %t1433
  %t1438 = xor i1 %t1436, true
  br i1 %t1438, label %bb313, label %bb314
bb313:
  call void @__olang_scope_close(ptr %s70)
  br label %bb319
bb314:
  br label %bb315
bb315:
  %t1440 = load i64, ptr %l79, !tbaa !24
  %t1441 = load i64, ptr %l83, !tbaa !24
  %t1442 = load i64, ptr %l81, !tbaa !24
  %t1445 = mul i64 %t1441, %t1442
  %t1448 = add i64 %t1440, %t1445
  store i64 %t1448, ptr %l84, !tbaa !24
  %t1450 = load ptr, ptr %l0, !tbaa !29
  %t1451 = load i64, ptr %l84, !tbaa !24
  %t1454 = getelementptr %"compiler/mir:verifier", ptr %t1450, i32 0, i32 4
  store i64 %t1451, ptr %t1454, !tbaa !24
  %t1455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1455, ptr %l699, !tbaa !29
  %t1456 = load ptr, ptr %l78, !tbaa !29
  %t1458 = getelementptr %"compiler/mir:BasicBlock", ptr %t1456, i32 0, i32 0
  %t1459 = load i64, ptr %l84, !tbaa !24
  %t1462 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s68, ptr %t1458, i64 %t1459)
  store { i64, [21 x i64] } %t1462, ptr %l703
  br label %bb316
bb316:
  %t1463 = load { i64, [21 x i64] }, ptr %l703
  %t1464 = call ptr @__olang_scope_alloc_a(ptr %s70, i64 176, i64 8)
  store { i64, [21 x i64] } %t1463, ptr %t1464
  %t1465 = load ptr, ptr %l699, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %s70, ptr %t1465, ptr %t1464)
  br label %bb317
bb317:
  call void @__olang_scope_close(ptr %s70)
  br label %bb318
bb318:
  %t1467 = load i64, ptr %l83, !tbaa !24
  %t1469 = add i64 %t1467, 1
  store i64 %t1469, ptr %l83, !tbaa !24
  br label %bb312
bb319:
  %t1471 = load ptr, ptr %l0, !tbaa !29
  %t1473 = getelementptr %"compiler/mir:verifier", ptr %t1471, i32 0, i32 4
  store i64 -1, ptr %t1473, !tbaa !24
  %t1474 = load ptr, ptr %l0, !tbaa !29
  %t1475 = load ptr, ptr %l78, !tbaa !29
  %t1477 = getelementptr %"compiler/mir:BasicBlock", ptr %t1475, i32 0, i32 1
  %t1478 = load { i64, [8 x i64] }, ptr %t1477
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %t1474, { i64, [8 x i64] } %t1478)
  br label %bb320
bb320:
  call void @__olang_scope_close(ptr %s68)
  br label %bb321
bb321:
  %t1481 = load i64, ptr %l76, !tbaa !24
  %t1483 = add i64 %t1481, 1
  store i64 %t1483, ptr %l76, !tbaa !24
  br label %bb300
bb322:
  %t1485 = load ptr, ptr %l0, !tbaa !29
  %t1489 = getelementptr %"compiler/mir:verifier", ptr %t1485, i32 0, i32 3
  store i64 -1, ptr %t1489, !tbaa !24
  %t1490 = load ptr, ptr %l0, !tbaa !29
  %t1494 = getelementptr %"compiler/mir:verifier", ptr %t1490, i32 0, i32 4
  store i64 -1, ptr %t1494, !tbaa !24
  %t1495 = load ptr, ptr %l0, !tbaa !29
  %t1497 = getelementptr %"compiler/mir:verifier", ptr %t1495, i32 0, i32 2
  %t1499 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1497)
  store i64 %t1499, ptr %l719
  br label %bb323
bb323:
  %t1500 = load i64, ptr %l2, !tbaa !24
  %t1501 = load i64, ptr %l719, !tbaa !24
  %t1503 = icmp eq i64 %t1501, %t1500
  call void @__olang_scope_close(ptr %s0)
  store i1 %t1503, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca i32
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 11
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l19, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l40, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/mir:verifier", ptr %t67, i32 0, i32 12
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/mir:verifier", ptr %t70, i32 0, i32 10
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = sext i32 %t74 to i64
  %t78 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i64, ptr %t79, i64 %t76
  %t81 = load i64, ptr %t80, !tbaa !34
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t88 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t69, i64 %t85)
  store i32 %t88, ptr %l53
  br label %bb16
bb16:
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = sext i32 %t95 to i64
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t90, i64 %t91)
  %t100 = getelementptr i8, ptr %t99, i64 %t91
  call void @olang_textcopy(ptr %t100, ptr %t92, i64 %t93)
  %t101 = getelementptr i8, ptr %t100, i64 %t93
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t112 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t112, { i64, ptr } %t111)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb9
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 93)
  br label %bb20
bb20:
  %t120 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t120, ptr %l60
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2estackText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca i32
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/mir:verifier", ptr %t4, i32 0, i32 17
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l12
  br label %bb3
bb3:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb9
bb6:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l19, !tbaa !24
  store i64 %t36, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l16, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l37, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d163, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/mir:verifier", ptr %t60, i32 0, i32 17
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t62, i64 %t63)
  store i32 %t66, ptr %l44
  br label %bb17
bb17:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load i32, ptr %l44, !tbaa !23
  %t74 = sext i32 %t73 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t70, i64 %t71)
  %t79 = getelementptr i8, ptr %t78, i64 %t71
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t74)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t98, ptr %l51
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtShape(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Lvalue"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l134 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i64
  %l143 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l175 = alloca i1
  %l181 = alloca i1
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l21, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 15}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l22, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/mir:Lvalue", ptr %l2
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t22, %"compiler/mir:Lvalue" %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [15 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %t26, { i64, [15 x i64] } %t27)
  br label %bb7
bb7:
  br label %bb114
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t31 = load ptr, ptr %l33, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 15}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l34, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l34, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [21 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t46 = load ptr, ptr %l39, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l39, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 15}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l40, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l4, !tbaa !23
  %t64 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l47
  br label %bb18
bb18:
  br label %bb114
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 15}
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32 }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l5, !tbaa !23
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t81 = load ptr, ptr %l54, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l54, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 15}
  %t87 = icmp eq i64 %t85, 4
  store i1 %t87, ptr %l55, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32 }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l5, !tbaa !23
  %t99 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l62
  br label %bb29
bb29:
  br label %bb114
bb30:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 15}
  %t107 = icmp eq i64 %t105, 5
  store i1 %t107, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l64, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [21 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t111, i32 0, i32 1
  %t113 = load { i64, [1 x i64] }, ptr %t112
  store { i64, [1 x i64] } %t113, ptr %l6
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [21 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t117, i32 0, i32 3
  %t119 = load { i64, [4 x i64] }, ptr %t118
  store { i64, [4 x i64] } %t119, ptr %l7
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, [1 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t121, { i64, [1 x i64] } %t122)
  br label %bb36
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [4 x i64] }, ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t125, { i64, [4 x i64] } %t126)
  br label %bb37
bb37:
  br label %bb114
bb38:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t130 = load ptr, ptr %l75, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l75, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 15}
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  %t137 = load i1, ptr %l76, !tbaa !21
  br i1 %t137, label %bb41, label %bb42
bb41:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [21 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t140, i32 0, i32 1
  %t142 = load %"compiler/mir:Lvalue", ptr %t141
  store %"compiler/mir:Lvalue" %t142, ptr %l8
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/mir:Lvalue", ptr %l8
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t144, %"compiler/mir:Lvalue" %t145)
  br label %bb44
bb44:
  br label %bb114
bb45:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t149 = load ptr, ptr %l83, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb46, label %bb47
bb46:
  %t152 = load ptr, ptr %l83, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 15}
  %t155 = icmp eq i64 %t153, 7
  store i1 %t155, ptr %l84, !tbaa !21
  br label %bb47
bb47:
  %t156 = load i1, ptr %l84, !tbaa !21
  br i1 %t156, label %bb48, label %bb49
bb48:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [21 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t159, i32 0, i32 1
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr { i64, [21 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t165, i32 0, i32 2
  %t167 = load %"compiler/mir:Lvalue", ptr %t166
  store %"compiler/mir:Lvalue" %t167, ptr %l10
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l9, !tbaa !23
  %t173 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l93
  br label %bb51
bb51:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Lvalue", ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t174, %"compiler/mir:Lvalue" %t175)
  br label %bb52
bb52:
  br label %bb114
bb53:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb54, label %bb55
bb54:
  %t182 = load ptr, ptr %l96, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 15}
  %t185 = icmp eq i64 %t183, 8
  store i1 %t185, ptr %l97, !tbaa !21
  br label %bb55
bb55:
  %t186 = load i1, ptr %l97, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t189, i32 0, i32 1
  %t191 = load { i64, [1 x i64] }, ptr %t190
  store { i64, [1 x i64] } %t191, ptr %l11
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [21 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t195, i32 0, i32 3
  %t197 = load { i64, [4 x i64] }, ptr %t196
  store { i64, [4 x i64] } %t197, ptr %l12
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, [1 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eref(ptr %v0, ptr %t199, { i64, [1 x i64] } %t200)
  br label %bb59
bb59:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [4 x i64] }, ptr %l12
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t203, { i64, [4 x i64] } %t204)
  br label %bb60
bb60:
  br label %bb114
bb61:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t208 = load ptr, ptr %l108, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb62, label %bb63
bb62:
  %t211 = load ptr, ptr %l108, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 15}
  %t214 = icmp eq i64 %t212, 9
  store i1 %t214, ptr %l109, !tbaa !21
  br label %bb63
bb63:
  %t215 = load i1, ptr %l109, !tbaa !21
  br i1 %t215, label %bb64, label %bb65
bb64:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [21 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t218, i32 0, i32 1
  %t220 = load %"compiler/mir:Lvalue", ptr %t219
  store %"compiler/mir:Lvalue" %t220, ptr %l13
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [21 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t224, i32 0, i32 2
  %t226 = load %"compiler/mir:Lvalue", ptr %t225
  store %"compiler/mir:Lvalue" %t226, ptr %l14
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr { i64, [21 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t230, i32 0, i32 3
  %t232 = load { i64, [4 x i64] }, ptr %t231
  store { i64, [4 x i64] } %t232, ptr %l15
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/mir:Lvalue", ptr %l13
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t234, %"compiler/mir:Lvalue" %t235)
  br label %bb67
bb67:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/mir:Lvalue", ptr %l14
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplace(ptr %v0, ptr %t238, %"compiler/mir:Lvalue" %t239)
  br label %bb68
bb68:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load { i64, [4 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t242, { i64, [4 x i64] } %t243)
  br label %bb69
bb69:
  br label %bb114
bb70:
  %t246 = load ptr, ptr %l1, !tbaa !29
  store ptr %t246, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb71, label %bb72
bb71:
  %t250 = load ptr, ptr %l124, !tbaa !29
  %t251 = load i64, ptr %t250, !range !{i64 0, i64 15}
  %t253 = icmp eq i64 %t251, 10
  store i1 %t253, ptr %l125, !tbaa !21
  br label %bb72
bb72:
  %t254 = load i1, ptr %l125, !tbaa !21
  br i1 %t254, label %bb73, label %bb74
bb73:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [21 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258
  store i32 %t259, ptr %l16, !tbaa !23
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr { i64, [21 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t263, i32 0, i32 2
  %t265 = load i32, ptr %t264
  store i32 %t265, ptr %l17, !tbaa !23
  br label %bb75
bb74:
  br label %bb85
bb75:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l16, !tbaa !23
  %t271 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l134
  br label %bb76
bb76:
  %t272 = load i32, ptr %l17, !tbaa !23
  %t274 = icmp slt i32 %t272, 0
  br i1 %t274, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb80
bb78:
  %t276 = load i32, ptr %l17, !tbaa !23
  %t278 = sext i32 %t276 to i64
  store i64 %t278, ptr %l139, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/mir:verifier", ptr %t279, i32 0, i32 0
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/mir:Fn", ptr %t282, i32 0, i32 16
  %t285 = load ptr, ptr @__olang_prog_scope
  %t287 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %t285, ptr %t284)
  store i64 %t287, ptr %l143
  br label %bb79
bb79:
  %t288 = load i64, ptr %l139, !tbaa !24
  %t289 = load i64, ptr %l143, !tbaa !24
  %t290 = icmp sge i64 %t288, %t289
  store i1 %t290, ptr %l137, !tbaa !21
  br label %bb80
bb80:
  %t292 = load i1, ptr %l137, !tbaa !21
  br i1 %t292, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l17, !tbaa !23
  %t295 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t298 = sext i32 %t294 to i64
  %t299 = call i64 @__olang_fmt_i64(ptr null, i64 %t298)
  %t300 = add i64 %t296, %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t295, i64 %t296)
  %t302 = getelementptr i8, ptr %t301, i64 %t296
  %t303 = call i64 @__olang_fmt_i64(ptr %t302, i64 %t298)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t301, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t293, { i64, ptr } %t312)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb84:
  br label %bb114
bb85:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t316 = load ptr, ptr %l149, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb86, label %bb87
bb86:
  %t319 = load ptr, ptr %l149, !tbaa !29
  %t320 = load i64, ptr %t319, !range !{i64 0, i64 15}
  %t322 = icmp eq i64 %t320, 11
  store i1 %t322, ptr %l150, !tbaa !21
  br label %bb87
bb87:
  %t323 = load i1, ptr %l150, !tbaa !21
  br i1 %t323, label %bb88, label %bb89
bb88:
  br label %bb94
bb89:
  %t324 = load ptr, ptr %l1, !tbaa !29
  store ptr %t324, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t325 = load ptr, ptr %l153, !tbaa !29
  %t326 = icmp ne ptr %t325, null
  br i1 %t326, label %bb90, label %bb91
bb90:
  %t328 = load ptr, ptr %l153, !tbaa !29
  %t329 = load i64, ptr %t328, !range !{i64 0, i64 15}
  %t331 = icmp eq i64 %t329, 13
  store i1 %t331, ptr %l154, !tbaa !21
  br label %bb91
bb91:
  %t332 = load i1, ptr %l154, !tbaa !21
  br i1 %t332, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb114
bb95:
  %t333 = load ptr, ptr %l1, !tbaa !29
  store ptr %t333, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t334 = load ptr, ptr %l157, !tbaa !29
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %bb96, label %bb97
bb96:
  %t337 = load ptr, ptr %l157, !tbaa !29
  %t338 = load i64, ptr %t337, !range !{i64 0, i64 15}
  %t340 = icmp eq i64 %t338, 12
  store i1 %t340, ptr %l158, !tbaa !21
  br label %bb97
bb97:
  %t341 = load i1, ptr %l158, !tbaa !21
  br i1 %t341, label %bb98, label %bb99
bb98:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr { i64, [21 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t344, i32 0, i32 1
  %t346 = load { i64, [4 x i64] }, ptr %t345
  store { i64, [4 x i64] } %t346, ptr %l18
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load { i64, [4 x i64] }, ptr %l18
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t348, { i64, [4 x i64] } %t349)
  br label %bb101
bb101:
  br label %bb114
bb102:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t353 = load ptr, ptr %l165, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb103, label %bb104
bb103:
  %t356 = load ptr, ptr %l165, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 15}
  %t359 = icmp eq i64 %t357, 14
  store i1 %t359, ptr %l166, !tbaa !21
  br label %bb104
bb104:
  %t360 = load i1, ptr %l166, !tbaa !21
  br i1 %t360, label %bb105, label %bb106
bb105:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [21 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t363, i32 0, i32 1
  %t365 = load i32, ptr %t364
  store i32 %t365, ptr %l19, !tbaa !23
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [21 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t369, i32 0, i32 2
  %t371 = load i32, ptr %t370
  store i32 %t371, ptr %l20, !tbaa !23
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l19, !tbaa !23
  %t377 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t373, i32 %t374)
  store i1 %t377, ptr %l175
  br label %bb108
bb108:
  %t378 = load i32, ptr %l20, !tbaa !23
  %t379 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t382 = icmp ne i32 %t378, %t379
  br i1 %t382, label %bb109, label %bb110
bb109:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l20, !tbaa !23
  %t388 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t384, i32 %t385)
  store i1 %t388, ptr %l181
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb112
bb112:
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_145fd452f8e36c9b_ff9c6902187c9987)
  unreachable
bb114:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Lvalue"
  %l14 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/mir:Lvalue"
  %l22 = alloca %"compiler/mir:Lvalue"
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca %"compiler/mir:Task"
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l57 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i32
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i32
  %l85 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i32
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca i32
  %l124 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l132 = alloca i1
  %l134 = alloca i1
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca i64
  %l141 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l148 = alloca i1
  %l155 = alloca i32
  %l159 = alloca i1
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca i64
  %l166 = alloca i1
  %l169 = alloca i1
  %l171 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca i1
  %l191 = alloca i32
  %l194 = alloca i32
  %l195 = alloca i1
  %l202 = alloca i1
  %l213 = alloca i1
  %l214 = alloca i1
  %l217 = alloca i1
  %l223 = alloca i1
  %l228 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i32
  %l239 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca i1
  %l257 = alloca ptr
  %l260 = alloca i32
  %l261 = alloca i32
  %l262 = alloca ptr
  %l265 = alloca i32
  %l266 = alloca i32
  %l270 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l279 = alloca i32
  %l280 = alloca i32
  %l281 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca i32
  %l286 = alloca i1
  %l288 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l297 = alloca ptr
  %l298 = alloca ptr
  %l301 = alloca i32
  %l302 = alloca i32
  %l303 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %l319 = alloca %"compiler/mir:ScopeInfo"
  %l332 = alloca %"compiler/mir:Task"
  %l335 = alloca i32
  %l344 = alloca ptr
  %l345 = alloca ptr
  %l348 = alloca i32
  %l351 = alloca i32
  %l354 = alloca i32
  %l355 = alloca i32
  %l356 = alloca { i64, ptr }
  %l359 = alloca i1
  %l376 = alloca i1
  %l377 = alloca ptr
  %l380 = alloca i32
  %l381 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t7 = load ptr, ptr %l33, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l33, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 15}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l34, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l34, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [21 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t17, i32 0, i32 1
  %t19 = load %"compiler/mir:Lvalue", ptr %t18
  store %"compiler/mir:Lvalue" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [21 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t23, i32 0, i32 2
  %t25 = load { i64, [15 x i64] }, ptr %t24
  store { i64, [15 x i64] } %t25, ptr %l4
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l3
  %t31 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store i32 %t31, ptr %l43
  br label %bb6
bb6:
  %t32 = load i32, ptr %l43, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [15 x i64] }, ptr %l4
  %t37 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueType(ptr %v0, ptr %t33, { i64, [15 x i64] } %t34)
  store i32 %t37, ptr %l46
  br label %bb7
bb7:
  %t38 = load i32, ptr %l46, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load { i64, [15 x i64] }, ptr %l4
  %t41 = extractvalue { i64, [15 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t45 = getelementptr { { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, [4 x i64] }, ptr %t45
  %t48 = extractvalue { i64, [4 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l49, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l49, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { { i64, [4 x i64] } }, ptr %t52, i32 0, i32 0
  %t54 = load { i64, [4 x i64] }, ptr %t53
  store { i64, [4 x i64] } %t54, ptr %l7
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp ne i32 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  store i1 %t68, ptr %l57, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l57, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s3, ptr %t71, i32 %t72, i32 %t73, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb228
bb21:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t78 = load ptr, ptr %l64, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = load ptr, ptr %l64, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 15}
  %t84 = icmp eq i64 %t82, 5
  store i1 %t84, ptr %l65, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l65, !tbaa !21
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [21 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l8, !tbaa !23
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [21 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t94, i32 0, i32 3
  %t96 = load { i64, [4 x i64] }, ptr %t95
  store { i64, [4 x i64] } %t96, ptr %l9
  br label %bb26
bb25:
  br label %bb50
bb26:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [4 x i64] }, ptr %l9
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t98, { i64, [4 x i64] } %t99)
  store i32 %t102, ptr %l74
  br label %bb27
bb27:
  %t103 = load i32, ptr %l74, !tbaa !23
  store i32 %t103, ptr %l10, !tbaa !23
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t105 = load i32, ptr %l10, !tbaa !23
  %t106 = load ptr, ptr @__olang_prog_scope
  %t109 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t106, ptr %t104, i32 %t105)
  store i1 %t109, ptr %l77
  br label %bb28
bb28:
  %t110 = load i1, ptr %l77, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb33
bb30:
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l80, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t115 = load i32, ptr %l10, !tbaa !23
  %t116 = load ptr, ptr @__olang_prog_scope
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t116, ptr %t114, i32 %t115)
  store i32 %t119, ptr %l83
  br label %bb31
bb31:
  %t120 = load i32, ptr %l8, !tbaa !23
  %t121 = load ptr, ptr @__olang_prog_scope
  %t122 = load ptr, ptr %l80, !tbaa !29
  %t123 = load i32, ptr %l83, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t121, ptr %t122, i32 %t123, i32 %t120)
  store i1 %t125, ptr %l85
  br label %bb32
bb32:
  %t126 = load i1, ptr %l85, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l79, !tbaa !21
  br label %bb33
bb33:
  %t129 = load i1, ptr %l79, !tbaa !21
  br i1 %t129, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l87, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l90
  br label %bb36
bb35:
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load i32, ptr %l8, !tbaa !23
  %t138 = load ptr, ptr @__olang_prog_scope
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t138, ptr %t136, i32 %t137)
  store i1 %t141, ptr %l98
  br label %bb39
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l93
  br label %bb37
bb37:
  %t147 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t149 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = add i64 %t155, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t147, i64 %t148)
  %t161 = getelementptr i8, ptr %t160, i64 %t148
  call void @olang_textcopy(ptr %t161, ptr %t150, i64 %t151)
  %t162 = getelementptr i8, ptr %t161, i64 %t151
  call void @olang_textcopy(ptr %t162, ptr %t153, i64 %t154)
  %t163 = getelementptr i8, ptr %t162, i64 %t154
  call void @olang_textcopy(ptr %t163, ptr %t157, i64 %t158)
  %t164 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t160, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } %t165, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  %t173 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t173, { i64, ptr } %t172)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb39:
  %t175 = load i1, ptr %l98, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb40, label %bb41
bb40:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i32, ptr %l8, !tbaa !23
  %t180 = load ptr, ptr @__olang_prog_scope
  %t183 = call i32 @compiler_2fmir_2eGuardOf(ptr %t180, ptr %t178, i32 %t179)
  store i32 %t183, ptr %l103
  br label %bb42
bb41:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb43
bb42:
  %t184 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t185 = load i32, ptr %l103, !tbaa !23
  %t187 = icmp eq i32 %t185, %t184
  store i1 %t187, ptr %l100, !tbaa !21
  br label %bb43
bb43:
  %t189 = load i1, ptr %l100, !tbaa !21
  br i1 %t189, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l106, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l8, !tbaa !23
  %t195 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s8, ptr %t191, i32 %t192)
  store { i64, ptr } %t195, ptr %l109
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t196 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t198 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t205 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t196, i64 %t197)
  %t206 = getelementptr i8, ptr %t205, i64 %t197
  call void @olang_textcopy(ptr %t206, ptr %t199, i64 %t200)
  %t207 = getelementptr i8, ptr %t206, i64 %t200
  call void @olang_textcopy(ptr %t207, ptr %t202, i64 %t203)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t205, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = extractvalue { i64, ptr } %t209, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load ptr, ptr %l106, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s8, ptr %t217, { i64, ptr } %t216)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb228
bb50:
  %t219 = load ptr, ptr %l1, !tbaa !29
  store ptr %t219, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t220 = load ptr, ptr %l112, !tbaa !29
  %t221 = icmp ne ptr %t220, null
  br i1 %t221, label %bb51, label %bb52
bb51:
  %t223 = load ptr, ptr %l112, !tbaa !29
  %t224 = load i64, ptr %t223, !range !{i64 0, i64 15}
  %t226 = icmp eq i64 %t224, 6
  store i1 %t226, ptr %l113, !tbaa !21
  br label %bb52
bb52:
  %t227 = load i1, ptr %l113, !tbaa !21
  br i1 %t227, label %bb53, label %bb54
bb53:
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr { i64, [21 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t230, i32 0, i32 1
  %t232 = load %"compiler/mir:Lvalue", ptr %t231
  store %"compiler/mir:Lvalue" %t232, ptr %l11
  br label %bb55
bb54:
  br label %bb75
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/mir:Lvalue", ptr %l11
  %t238 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t234, %"compiler/mir:Lvalue" %t235)
  store i32 %t238, ptr %l120
  br label %bb56
bb56:
  %t239 = load i32, ptr %l120, !tbaa !23
  store i32 %t239, ptr %l12, !tbaa !23
  %t240 = load i32, ptr %l12, !tbaa !23
  %t241 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t244 = icmp ne i32 %t240, %t241
  br i1 %t244, label %bb57, label %bb58
bb57:
  %t246 = load ptr, ptr %l2, !tbaa !29
  %t247 = load i32, ptr %l12, !tbaa !23
  %t248 = load ptr, ptr @__olang_prog_scope
  %t251 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t248, ptr %t246, i32 %t247)
  store i1 %t251, ptr %l127
  br label %bb59
bb58:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb60
bb59:
  %t252 = load i1, ptr %l127, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l124, !tbaa !21
  br label %bb60
bb60:
  %t255 = load i1, ptr %l124, !tbaa !21
  br i1 %t255, label %bb61, label %bb62
bb61:
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t257 = load i32, ptr %l12, !tbaa !23
  %t258 = load ptr, ptr @__olang_prog_scope
  %t261 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t258, ptr %t256, i32 %t257)
  store i1 %t261, ptr %l132
  br label %bb63
bb62:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb64
bb63:
  %t262 = load i1, ptr %l132, !tbaa !21
  %t263 = xor i1 %t262, true
  store i1 %t263, ptr %l129, !tbaa !21
  br label %bb64
bb64:
  %t265 = load i1, ptr %l129, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb65:
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t267 = load i32, ptr %l12, !tbaa !23
  %t268 = load ptr, ptr @__olang_prog_scope
  %t271 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %t268, ptr %s10, ptr %t266, i32 %t267)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t271, ptr %l137
  br label %bb67
bb66:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb69
bb67:
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s10, ptr %l137)
  store i64 %t273, ptr %l139
  br label %bb68
bb68:
  %t274 = load i64, ptr %l139, !tbaa !24
  %t275 = icmp eq i64 %t274, 0
  store i1 %t275, ptr %l134, !tbaa !21
  br label %bb69
bb69:
  %t277 = load i1, ptr %l134, !tbaa !21
  br i1 %t277, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s11
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l141, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l12, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s11, ptr %t279, i32 %t280)
  store { i64, ptr } %t283, ptr %l144
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t284 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t286 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t284, i64 %t285)
  %t294 = getelementptr i8, ptr %t293, i64 %t285
  call void @olang_textcopy(ptr %t294, ptr %t287, i64 %t288)
  %t295 = getelementptr i8, ptr %t294, i64 %t288
  call void @olang_textcopy(ptr %t295, ptr %t290, i64 %t291)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t293, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s11, ptr %t305, { i64, ptr } %t304)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb228
bb75:
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t308 = load ptr, ptr %l147, !tbaa !29
  %t309 = icmp ne ptr %t308, null
  br i1 %t309, label %bb76, label %bb77
bb76:
  %t311 = load ptr, ptr %l147, !tbaa !29
  %t312 = load i64, ptr %t311, !range !{i64 0, i64 15}
  %t314 = icmp eq i64 %t312, 7
  store i1 %t314, ptr %l148, !tbaa !21
  br label %bb77
bb77:
  %t315 = load i1, ptr %l148, !tbaa !21
  br i1 %t315, label %bb78, label %bb79
bb78:
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [21 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t318, i32 0, i32 2
  %t320 = load %"compiler/mir:Lvalue", ptr %t319
  store %"compiler/mir:Lvalue" %t320, ptr %l13
  br label %bb80
bb79:
  br label %bb96
bb80:
  store %olang.scope zeroinitializer, ptr %s13
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load %"compiler/mir:Lvalue", ptr %l13
  %t326 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t322, %"compiler/mir:Lvalue" %t323)
  store i32 %t326, ptr %l155
  br label %bb81
bb81:
  %t327 = load i32, ptr %l155, !tbaa !23
  store i32 %t327, ptr %l14, !tbaa !23
  %t328 = load i32, ptr %l14, !tbaa !23
  %t329 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t332 = icmp ne i32 %t328, %t329
  br i1 %t332, label %bb82, label %bb83
bb82:
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t335 = load i32, ptr %l14, !tbaa !23
  %t336 = load ptr, ptr @__olang_prog_scope
  %t339 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %t336, ptr %s13, ptr %t334, i32 %t335)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t339, ptr %l162
  br label %bb84
bb83:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb86
bb84:
  %t341 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s13, ptr %l162)
  store i64 %t341, ptr %l164
  br label %bb85
bb85:
  %t342 = load i64, ptr %l164, !tbaa !24
  %t343 = icmp eq i64 %t342, 0
  store i1 %t343, ptr %l159, !tbaa !21
  br label %bb86
bb86:
  %t345 = load i1, ptr %l159, !tbaa !21
  br i1 %t345, label %bb87, label %bb88
bb87:
  %t346 = load ptr, ptr %l2, !tbaa !29
  %t347 = load i32, ptr %l14, !tbaa !23
  %t348 = load ptr, ptr @__olang_prog_scope
  %t351 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t348, ptr %t346, i32 %t347)
  store i1 %t351, ptr %l169
  br label %bb89
bb88:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb90
bb89:
  %t352 = load i1, ptr %l169, !tbaa !21
  %t353 = xor i1 %t352, true
  store i1 %t353, ptr %l166, !tbaa !21
  br label %bb90
bb90:
  %t355 = load i1, ptr %l166, !tbaa !21
  br i1 %t355, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l171, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l14, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s14, ptr %t357, i32 %t358)
  store { i64, ptr } %t361, ptr %l174
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t362 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t364 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = add i64 %t363, %t366
  %t368 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t371 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t370)
  call void @olang_textcopy(ptr %t371, ptr %t362, i64 %t363)
  %t372 = getelementptr i8, ptr %t371, i64 %t363
  call void @olang_textcopy(ptr %t372, ptr %t365, i64 %t366)
  %t373 = getelementptr i8, ptr %t372, i64 %t366
  call void @olang_textcopy(ptr %t373, ptr %t368, i64 %t369)
  %t374 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t371, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = extractvalue { i64, ptr } %t375, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  %t383 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s14, ptr %t383, { i64, ptr } %t382)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s14)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s13)
  br label %bb228
bb96:
  %t385 = load ptr, ptr %l1, !tbaa !29
  store ptr %t385, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t386 = load ptr, ptr %l177, !tbaa !29
  %t387 = icmp ne ptr %t386, null
  br i1 %t387, label %bb97, label %bb98
bb97:
  %t389 = load ptr, ptr %l177, !tbaa !29
  %t390 = load i64, ptr %t389, !range !{i64 0, i64 15}
  %t392 = icmp eq i64 %t390, 8
  store i1 %t392, ptr %l178, !tbaa !21
  br label %bb98
bb98:
  %t393 = load i1, ptr %l178, !tbaa !21
  br i1 %t393, label %bb99, label %bb100
bb99:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [21 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t396, i32 0, i32 1
  %t398 = load { i64, [1 x i64] }, ptr %t397
  store { i64, [1 x i64] } %t398, ptr %l15
  %t400 = load ptr, ptr %l1, !tbaa !29
  %t402 = getelementptr { i64, [21 x i64] }, ptr %t400, i32 0, i32 1
  %t403 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t402, i32 0, i32 2
  %t404 = load i32, ptr %t403, !range !{i32 0, i32 8}
  store i32 %t404, ptr %l16
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [21 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t408, i32 0, i32 3
  %t410 = load { i64, [4 x i64] }, ptr %t409
  store { i64, [4 x i64] } %t410, ptr %l17
  br label %bb101
bb100:
  br label %bb149
bb101:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t412, { i64, [1 x i64] } %t413)
  br label %bb102
bb102:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load { i64, [4 x i64] }, ptr %l17
  %t420 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t416, { i64, [4 x i64] } %t417)
  store i32 %t420, ptr %l191
  br label %bb103
bb103:
  %t421 = load i32, ptr %l191, !tbaa !23
  store i32 %t421, ptr %l18, !tbaa !23
  %t422 = load ptr, ptr %l2, !tbaa !29
  %t423 = load i32, ptr %l18, !tbaa !23
  %t424 = load ptr, ptr @__olang_prog_scope
  %t427 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t424, ptr %t422, i32 %t423)
  store i32 %t427, ptr %l194
  br label %bb104
bb104:
  %t428 = load i32, ptr %l194, !tbaa !23
  store i32 %t428, ptr %l19, !tbaa !23
  %t429 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t431 = trunc i64 0 to i32
  %t432 = icmp eq i32 %t429, %t431
  br i1 %t432, label %bb105, label %bb106
bb105:
  br label %bb109
bb106:
  %t434 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t436 = trunc i64 1 to i32
  %t437 = icmp eq i32 %t434, %t436
  br i1 %t437, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l18, !tbaa !23
  %t443 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t439, i32 %t440)
  store i1 %t443, ptr %l202
  br label %bb110
bb110:
  %t444 = load i1, ptr %l202, !tbaa !21
  store i1 %t444, ptr %l195, !tbaa !21
  br label %bb141
bb111:
  %t445 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t447 = trunc i64 2 to i32
  %t448 = icmp eq i32 %t445, %t447
  br i1 %t448, label %bb112, label %bb113
bb112:
  br label %bb116
bb113:
  %t450 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t452 = trunc i64 3 to i32
  %t453 = icmp eq i32 %t450, %t452
  br i1 %t453, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  %t455 = load i32, ptr %l19, !tbaa !23
  %t457 = icmp eq i32 %t455, 7
  store i1 %t457, ptr %l195, !tbaa !21
  br label %bb141
bb117:
  %t459 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t461 = trunc i64 4 to i32
  %t462 = icmp eq i32 %t459, %t461
  br i1 %t462, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb126
bb120:
  %t464 = load ptr, ptr %l2, !tbaa !29
  %t465 = load i32, ptr %l19, !tbaa !23
  %t466 = load ptr, ptr @__olang_prog_scope
  %t469 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t466, ptr %t464, i32 %t465)
  store i1 %t469, ptr %l213
  br label %bb121
bb121:
  %t470 = load i1, ptr %l213, !tbaa !21
  br i1 %t470, label %bb122, label %bb123
bb122:
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t472 = load i32, ptr %l19, !tbaa !23
  %t473 = load ptr, ptr @__olang_prog_scope
  %t476 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t473, ptr %t471, i32 %t472)
  store i1 %t476, ptr %l217
  br label %bb124
bb123:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb125
bb124:
  %t477 = load i1, ptr %l217, !tbaa !21
  %t478 = xor i1 %t477, true
  store i1 %t478, ptr %l214, !tbaa !21
  br label %bb125
bb125:
  %t480 = load i1, ptr %l214, !tbaa !21
  store i1 %t480, ptr %l195, !tbaa !21
  br label %bb141
bb126:
  %t481 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t483 = trunc i64 5 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t486 = load ptr, ptr %l2, !tbaa !29
  %t487 = load i32, ptr %l19, !tbaa !23
  %t488 = load ptr, ptr @__olang_prog_scope
  %t491 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t488, ptr %t486, i32 %t487)
  store i1 %t491, ptr %l223
  br label %bb130
bb130:
  %t492 = load i1, ptr %l223, !tbaa !21
  store i1 %t492, ptr %l195, !tbaa !21
  br label %bb141
bb131:
  %t493 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t495 = trunc i64 6 to i32
  %t496 = icmp eq i32 %t493, %t495
  br i1 %t496, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t498 = load ptr, ptr %l2, !tbaa !29
  %t499 = load i32, ptr %l19, !tbaa !23
  %t500 = load ptr, ptr @__olang_prog_scope
  %t503 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %t500, ptr %t498, i32 %t499)
  store i1 %t503, ptr %l228
  br label %bb135
bb135:
  %t504 = load i1, ptr %l228, !tbaa !21
  store i1 %t504, ptr %l195, !tbaa !21
  br label %bb141
bb136:
  %t505 = load i32, ptr %l16, !range !{i32 0, i32 8}
  %t507 = trunc i64 7 to i32
  %t508 = icmp eq i32 %t505, %t507
  br i1 %t508, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t510 = load i32, ptr %l19, !tbaa !23
  %t511 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t514 = icmp eq i32 %t510, %t511
  store i1 %t514, ptr %l195, !tbaa !21
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23)
  unreachable
bb141:
  %t516 = load i1, ptr %l195, !tbaa !21
  %t519 = xor i1 %t516, true
  br i1 %t519, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s23
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l236, !tbaa !29
  %t522 = load i32, ptr %l16, !range !{i32 0, i32 8}
  store i32 %t522, ptr %l237
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %s24, ptr %l237, i64 0)
  br label %bb144
bb143:
  br label %bb148
bb144:
  %t524 = load ptr, ptr %s24
  %t525 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t526 = load i64, ptr %t525
  %t527 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t526)
  call void @olang_textcopy(ptr %t527, ptr %t524, i64 %t526)
  %t528 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  store { i64, ptr } %t529, ptr %l239, !tbaa !27
  %t530 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t531 = load ptr, ptr %t530
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %sbgrew.533, label %sbdone.534
sbgrew.533:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.534
sbdone.534:
  %t535 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  %t537 = extractvalue { i64, ptr } %t535, 1
  %t538 = mul i64 %t536, 1
  %t539 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t538)
  call void @llvm.memcpy.p0.p0.i64(ptr %t539, ptr %t537, i64 %t538, i1 false)
  %t540 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t539, 1
  %t543 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s23, ptr %s23, { i64, ptr } %t541)
  store { i64, ptr } %t543, ptr %l241
  br label %bb145
bb145:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load i32, ptr %l18, !tbaa !23
  %t548 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s23, ptr %t544, i32 %t545)
  store { i64, ptr } %t548, ptr %l244
  br label %bb146
bb146:
  %t549 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t551 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = add i64 %t550, %t553
  %t555 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t557 = add i64 %t554, %t556
  %t558 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = extractvalue { i64, ptr } %t558, 0
  %t561 = add i64 %t557, %t560
  %t562 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t561)
  call void @olang_textcopy(ptr %t562, ptr %t549, i64 %t550)
  %t563 = getelementptr i8, ptr %t562, i64 %t550
  call void @olang_textcopy(ptr %t563, ptr %t552, i64 %t553)
  %t564 = getelementptr i8, ptr %t563, i64 %t553
  call void @olang_textcopy(ptr %t564, ptr %t555, i64 %t556)
  %t565 = getelementptr i8, ptr %t564, i64 %t556
  call void @olang_textcopy(ptr %t565, ptr %t559, i64 %t560)
  %t566 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t567 = insertvalue { i64, ptr } %t566, ptr %t562, 1
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t570 = extractvalue { i64, ptr } %t567, 1
  %t571 = mul i64 %t569, 1
  %t572 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t571)
  call void @llvm.memcpy.p0.p0.i64(ptr %t572, ptr %t570, i64 %t571, i1 false)
  %t573 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  %t575 = load ptr, ptr %l236, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s23, ptr %t575, { i64, ptr } %t574)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s23)
  br label %bb148
bb148:
  br label %bb228
bb149:
  %t577 = load ptr, ptr %l1, !tbaa !29
  store ptr %t577, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t578 = load ptr, ptr %l247, !tbaa !29
  %t579 = icmp ne ptr %t578, null
  br i1 %t579, label %bb150, label %bb151
bb150:
  %t581 = load ptr, ptr %l247, !tbaa !29
  %t582 = load i64, ptr %t581, !range !{i64 0, i64 15}
  %t584 = icmp eq i64 %t582, 9
  store i1 %t584, ptr %l248, !tbaa !21
  br label %bb151
bb151:
  %t585 = load i1, ptr %l248, !tbaa !21
  br i1 %t585, label %bb152, label %bb153
bb152:
  %t586 = load ptr, ptr %l1, !tbaa !29
  %t588 = getelementptr { i64, [21 x i64] }, ptr %t586, i32 0, i32 1
  %t589 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t588, i32 0, i32 1
  %t590 = load %"compiler/mir:Lvalue", ptr %t589
  store %"compiler/mir:Lvalue" %t590, ptr %l21
  %t592 = load ptr, ptr %l1, !tbaa !29
  %t594 = getelementptr { i64, [21 x i64] }, ptr %t592, i32 0, i32 1
  %t595 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t594, i32 0, i32 2
  %t596 = load %"compiler/mir:Lvalue", ptr %t595
  store %"compiler/mir:Lvalue" %t596, ptr %l22
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t600 = getelementptr { i64, [21 x i64] }, ptr %t598, i32 0, i32 1
  %t601 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t600, i32 0, i32 3
  %t602 = load { i64, [4 x i64] }, ptr %t601
  store { i64, [4 x i64] } %t602, ptr %l23
  br label %bb154
bb153:
  br label %bb184
bb154:
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l257, !tbaa !29
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load %"compiler/mir:Lvalue", ptr %l21
  %t609 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t605, %"compiler/mir:Lvalue" %t606)
  store i32 %t609, ptr %l260
  br label %bb155
bb155:
  %t610 = load ptr, ptr %l257, !tbaa !29
  %t611 = load i32, ptr %l260, !tbaa !23
  %t612 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t610, i32 %t611)
  store i32 %t612, ptr %l261
  br label %bb156
bb156:
  %t613 = load i32, ptr %l261, !tbaa !23
  store i32 %t613, ptr %l24, !tbaa !23
  %t614 = load ptr, ptr %l0, !tbaa !29
  store ptr %t614, ptr %l262, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load %"compiler/mir:Lvalue", ptr %l22
  %t619 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t615, %"compiler/mir:Lvalue" %t616)
  store i32 %t619, ptr %l265
  br label %bb157
bb157:
  %t620 = load ptr, ptr %l262, !tbaa !29
  %t621 = load i32, ptr %l265, !tbaa !23
  %t622 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %t620, i32 %t621)
  store i32 %t622, ptr %l266
  br label %bb158
bb158:
  %t623 = load i32, ptr %l266, !tbaa !23
  store i32 %t623, ptr %l25, !tbaa !23
  %t624 = load i32, ptr %l24, !tbaa !23
  %t625 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t628 = icmp eq i32 %t624, %t625
  br i1 %t628, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l270, !tbaa !21
  br label %bb161
bb160:
  %t630 = load i32, ptr %l25, !tbaa !23
  %t631 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t634 = icmp eq i32 %t630, %t631
  store i1 %t634, ptr %l270, !tbaa !21
  br label %bb161
bb161:
  %t636 = load i1, ptr %l270, !tbaa !21
  br i1 %t636, label %bb162, label %bb163
bb162:
  store %olang.scope zeroinitializer, ptr %s27
  %t637 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s27, ptr %t637, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb164
bb163:
  %t639 = load ptr, ptr %l2, !tbaa !29
  store ptr %t639, ptr %l275, !tbaa !29
  %t640 = load ptr, ptr %l2, !tbaa !29
  store ptr %t640, ptr %l276, !tbaa !29
  %t641 = load ptr, ptr %l2, !tbaa !29
  %t642 = load i32, ptr %l24, !tbaa !23
  %t643 = load ptr, ptr @__olang_prog_scope
  %t646 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t643, ptr %t641, i32 %t642)
  store i32 %t646, ptr %l279
  br label %bb165
bb164:
  call void @__olang_scope_close(ptr %s27)
  br label %bb176
bb165:
  %t647 = load ptr, ptr @__olang_prog_scope
  %t648 = load ptr, ptr %l276, !tbaa !29
  %t649 = load i32, ptr %l279, !tbaa !23
  %t650 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t647, ptr %t648, i32 %t649)
  store i32 %t650, ptr %l280
  br label %bb166
bb166:
  %t651 = load ptr, ptr %l2, !tbaa !29
  store ptr %t651, ptr %l281, !tbaa !29
  %t652 = load ptr, ptr %l2, !tbaa !29
  %t653 = load i32, ptr %l25, !tbaa !23
  %t654 = load ptr, ptr @__olang_prog_scope
  %t657 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t654, ptr %t652, i32 %t653)
  store i32 %t657, ptr %l284
  br label %bb167
bb167:
  %t658 = load ptr, ptr @__olang_prog_scope
  %t659 = load ptr, ptr %l281, !tbaa !29
  %t660 = load i32, ptr %l284, !tbaa !23
  %t661 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t658, ptr %t659, i32 %t660)
  store i32 %t661, ptr %l285
  br label %bb168
bb168:
  %t662 = load ptr, ptr @__olang_prog_scope
  %t663 = load ptr, ptr %l275, !tbaa !29
  %t664 = load i32, ptr %l280, !tbaa !23
  %t665 = load i32, ptr %l285, !tbaa !23
  %t666 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t662, ptr %t663, i32 %t664, i32 %t665)
  store i1 %t666, ptr %l286
  br label %bb169
bb169:
  %t667 = load i1, ptr %l286, !tbaa !21
  %t668 = xor i1 %t667, true
  br i1 %t668, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s29
  %t670 = load ptr, ptr %l0, !tbaa !29
  store ptr %t670, ptr %l288, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load i32, ptr %l25, !tbaa !23
  %t675 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s29, ptr %t671, i32 %t672)
  store { i64, ptr } %t675, ptr %l291
  br label %bb172
bb171:
  br label %bb175
bb172:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load i32, ptr %l24, !tbaa !23
  %t680 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s29, ptr %t676, i32 %t677)
  store { i64, ptr } %t680, ptr %l294
  br label %bb173
bb173:
  %t681 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t683 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t684 = extractvalue { i64, ptr } %t683, 1
  %t685 = extractvalue { i64, ptr } %t683, 0
  %t686 = add i64 %t682, %t685
  %t687 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t689 = add i64 %t686, %t688
  %t690 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t690, 1
  %t692 = extractvalue { i64, ptr } %t690, 0
  %t693 = add i64 %t689, %t692
  %t694 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t693)
  call void @olang_textcopy(ptr %t694, ptr %t681, i64 %t682)
  %t695 = getelementptr i8, ptr %t694, i64 %t682
  call void @olang_textcopy(ptr %t695, ptr %t684, i64 %t685)
  %t696 = getelementptr i8, ptr %t695, i64 %t685
  call void @olang_textcopy(ptr %t696, ptr %t687, i64 %t688)
  %t697 = getelementptr i8, ptr %t696, i64 %t688
  call void @olang_textcopy(ptr %t697, ptr %t691, i64 %t692)
  %t698 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t694, 1
  %t701 = extractvalue { i64, ptr } %t699, 0
  %t702 = extractvalue { i64, ptr } %t699, 1
  %t703 = mul i64 %t701, 1
  %t704 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t703)
  call void @llvm.memcpy.p0.p0.i64(ptr %t704, ptr %t702, i64 %t703, i1 false)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t704, 1
  %t707 = load ptr, ptr %l288, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t707, { i64, ptr } %t706)
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s29)
  br label %bb175
bb175:
  br label %bb176
bb176:
  %t709 = load ptr, ptr %l2, !tbaa !29
  store ptr %t709, ptr %l297, !tbaa !29
  %t710 = load ptr, ptr %l2, !tbaa !29
  store ptr %t710, ptr %l298, !tbaa !29
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load { i64, [4 x i64] }, ptr %l23
  %t715 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t711, { i64, [4 x i64] } %t712)
  store i32 %t715, ptr %l301
  br label %bb177
bb177:
  %t716 = load ptr, ptr @__olang_prog_scope
  %t717 = load ptr, ptr %l298, !tbaa !29
  %t718 = load i32, ptr %l301, !tbaa !23
  %t719 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t716, ptr %t717, i32 %t718)
  store i32 %t719, ptr %l302
  br label %bb178
bb178:
  %t720 = load ptr, ptr @__olang_prog_scope
  %t721 = load ptr, ptr %l297, !tbaa !29
  %t722 = load i32, ptr %l302, !tbaa !23
  %t723 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t720, ptr %t721, i32 %t722)
  store i1 %t723, ptr %l303
  br label %bb179
bb179:
  %t724 = load i1, ptr %l303, !tbaa !21
  %t725 = xor i1 %t724, true
  br i1 %t725, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s31
  %t727 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t727, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d180, i32 0, i32 1) })
  br label %bb182
bb181:
  br label %bb183
bb182:
  call void @__olang_scope_close(ptr %s31)
  br label %bb183
bb183:
  br label %bb228
bb184:
  %t729 = load ptr, ptr %l1, !tbaa !29
  store ptr %t729, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t730 = load ptr, ptr %l306, !tbaa !29
  %t731 = icmp ne ptr %t730, null
  br i1 %t731, label %bb185, label %bb186
bb185:
  %t733 = load ptr, ptr %l306, !tbaa !29
  %t734 = load i64, ptr %t733, !range !{i64 0, i64 15}
  %t736 = icmp eq i64 %t734, 10
  store i1 %t736, ptr %l307, !tbaa !21
  br label %bb186
bb186:
  %t737 = load i1, ptr %l307, !tbaa !21
  br i1 %t737, label %bb187, label %bb188
bb187:
  %t738 = load ptr, ptr %l1, !tbaa !29
  %t740 = getelementptr { i64, [21 x i64] }, ptr %t738, i32 0, i32 1
  %t741 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t740, i32 0, i32 1
  %t742 = load i32, ptr %t741
  store i32 %t742, ptr %l26, !tbaa !23
  %t744 = load ptr, ptr %l1, !tbaa !29
  %t746 = getelementptr { i64, [21 x i64] }, ptr %t744, i32 0, i32 1
  %t747 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t746, i32 0, i32 2
  %t748 = load i32, ptr %t747
  store i32 %t748, ptr %l27, !tbaa !23
  br label %bb189
bb188:
  br label %bb223
bb189:
  store %olang.scope zeroinitializer, ptr %s32
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/mir:verifier", ptr %t750, i32 0, i32 0
  %t753 = load ptr, ptr %t752, !tbaa !29
  %t755 = getelementptr %"compiler/mir:Fn", ptr %t753, i32 0, i32 8
  %t756 = load i32, ptr %l26, !tbaa !23
  %t758 = sext i32 %t756 to i64
  %t759 = load ptr, ptr @__olang_prog_scope
  %t762 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t759, ptr %t755, i64 %t758)
  store %"compiler/mir:ScopeInfo" %t762, ptr %l319
  br label %bb190
bb190:
  %t763 = getelementptr %"compiler/mir:ScopeInfo", ptr %l319, i32 0, i32 0
  %t764 = load i32, ptr %t763, !range !{i32 0, i32 7}
  %t766 = trunc i64 3 to i32
  %t767 = icmp eq i32 %t764, %t766
  %t769 = xor i1 %t767, true
  br i1 %t769, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s33
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t772 = load i32, ptr %l26, !tbaa !23
  %t773 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t774 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t776 = sext i32 %t772 to i64
  %t777 = call i64 @__olang_fmt_i64(ptr null, i64 %t776)
  %t778 = add i64 %t774, %t777
  %t779 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t780 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t781 = add i64 %t778, %t780
  %t782 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t781)
  call void @olang_textcopy(ptr %t782, ptr %t773, i64 %t774)
  %t783 = getelementptr i8, ptr %t782, i64 %t774
  %t784 = call i64 @__olang_fmt_i64(ptr %t783, i64 %t776)
  %t785 = getelementptr i8, ptr %t783, i64 %t777
  call void @olang_textcopy(ptr %t785, ptr %t779, i64 %t780)
  %t786 = insertvalue { i64, ptr } undef, i64 %t781, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t782, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t771, { i64, ptr } %t794)
  br label %bb193
bb192:
  br label %bb194
bb193:
  call void @__olang_scope_close(ptr %s33)
  br label %bb194
bb194:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/mir:verifier", ptr %t797, i32 0, i32 0
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = getelementptr %"compiler/mir:Fn", ptr %t800, i32 0, i32 16
  %t803 = load i32, ptr %l27, !tbaa !23
  %t805 = sext i32 %t803 to i64
  %t806 = load ptr, ptr @__olang_prog_scope
  %t809 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t806, ptr %t802, i64 %t805)
  store %"compiler/mir:Task" %t809, ptr %l332
  br label %bb195
bb195:
  %t810 = load %"compiler/mir:Task", ptr %l332
  store %"compiler/mir:Task" %t810, ptr %l28
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t812 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 0
  %t813 = load { i64, [7 x i64] }, ptr %t812
  %t816 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t811, { i64, [7 x i64] } %t813)
  store i32 %t816, ptr %l335
  br label %bb196
bb196:
  %t817 = load i32, ptr %l335, !tbaa !23
  store i32 %t817, ptr %l29, !tbaa !23
  %t818 = load i32, ptr %l29, !tbaa !23
  %t819 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t822 = icmp ne i32 %t818, %t819
  br i1 %t822, label %bb197, label %bb198
bb197:
  store %olang.scope zeroinitializer, ptr %s35
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t825 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 0
  %t826 = load { i64, [7 x i64] }, ptr %t825
  %t827 = load i32, ptr %l29, !tbaa !23
  %t828 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 1
  %t829 = load %"compiler/mir:Range", ptr %t828
  %t830 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 2
  %t831 = load %"compiler/mir:Range", ptr %t830
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t824, { i64, [7 x i64] } %t826, i32 %t827, %"compiler/mir:Range" %t829, %"compiler/mir:Range" %t831)
  br label %bb199
bb198:
  br label %bb222
bb199:
  %t837 = load ptr, ptr %l2, !tbaa !29
  store ptr %t837, ptr %l344, !tbaa !29
  %t838 = load ptr, ptr %l2, !tbaa !29
  store ptr %t838, ptr %l345, !tbaa !29
  %t839 = load ptr, ptr %l2, !tbaa !29
  %t840 = load i32, ptr %l29, !tbaa !23
  %t841 = load ptr, ptr @__olang_prog_scope
  %t844 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t841, ptr %t839, i32 %t840)
  store i32 %t844, ptr %l348
  br label %bb200
bb200:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t846 = load i32, ptr %l29, !tbaa !23
  %t849 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t845, i32 %t846)
  store i32 %t849, ptr %l351
  br label %bb201
bb201:
  %t850 = load ptr, ptr %l2, !tbaa !29
  %t851 = load i32, ptr %l29, !tbaa !23
  %t852 = load ptr, ptr @__olang_prog_scope
  %t855 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t852, ptr %t850, i32 %t851)
  store i32 %t855, ptr %l354
  br label %bb202
bb202:
  %t856 = load ptr, ptr @__olang_prog_scope
  %t857 = load ptr, ptr %l345, !tbaa !29
  %t858 = load i32, ptr %l348, !tbaa !23
  %t859 = load i32, ptr %l351, !tbaa !23
  %t860 = load i32, ptr %l354, !tbaa !23
  %t861 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %t856, ptr %t857, i32 %t858, i32 %t859, i32 %t860, i32 0, i64 0, i1 false, i32 0)
  store i32 %t861, ptr %l355
  br label %bb203
bb203:
  %t862 = load ptr, ptr @__olang_prog_scope
  %t863 = load ptr, ptr %l344, !tbaa !29
  %t864 = load i32, ptr %l355, !tbaa !23
  %t865 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %t862, ptr %s35, ptr %t863, i32 %t864)
  store { i64, ptr } %t865, ptr %l356
  br label %bb204
bb204:
  %t866 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t866, ptr %l30, !tbaa !27
  %t867 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t868 = getelementptr %"compiler/mir:Range", ptr %t867, i32 0, i32 1
  %t869 = load i32, ptr %t868, !tbaa !23
  %t871 = icmp sgt i32 %t869, 0
  br i1 %t871, label %bb205, label %bb206
bb205:
  %t873 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t874 = getelementptr %"compiler/mir:Range", ptr %t873, i32 0, i32 1
  %t875 = load i32, ptr %t874, !tbaa !23
  %t877 = sext i32 %t875 to i64
  %t878 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t880 = extractvalue { i64, ptr } %t878, 0
  %t883 = icmp ne i64 %t877, %t880
  store i1 %t883, ptr %l359, !tbaa !21
  br label %bb207
bb206:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb207
bb207:
  %t885 = load i1, ptr %l359, !tbaa !21
  br i1 %t885, label %bb208, label %bb209
bb208:
  store %olang.scope zeroinitializer, ptr %s36
  %t886 = load ptr, ptr %l0, !tbaa !29
  %t887 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 3
  %t888 = getelementptr %"compiler/mir:Range", ptr %t887, i32 0, i32 1
  %t889 = load i32, ptr %t888, !tbaa !23
  %t890 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t890, 0
  %t893 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t894 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t896 = sext i32 %t889 to i64
  %t897 = call i64 @__olang_fmt_i64(ptr null, i64 %t896)
  %t898 = add i64 %t894, %t897
  %t899 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t900 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t901 = add i64 %t898, %t900
  %t903 = call i64 @__olang_fmt_i64(ptr null, i64 %t892)
  %t904 = add i64 %t901, %t903
  %t905 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t906 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t907 = add i64 %t904, %t906
  %t908 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t907)
  call void @olang_textcopy(ptr %t908, ptr %t893, i64 %t894)
  %t909 = getelementptr i8, ptr %t908, i64 %t894
  %t910 = call i64 @__olang_fmt_i64(ptr %t909, i64 %t896)
  %t911 = getelementptr i8, ptr %t909, i64 %t897
  call void @olang_textcopy(ptr %t911, ptr %t899, i64 %t900)
  %t912 = getelementptr i8, ptr %t911, i64 %t900
  %t913 = call i64 @__olang_fmt_i64(ptr %t912, i64 %t892)
  %t914 = getelementptr i8, ptr %t912, i64 %t903
  call void @olang_textcopy(ptr %t914, ptr %t905, i64 %t906)
  %t915 = insertvalue { i64, ptr } undef, i64 %t907, 0
  %t916 = insertvalue { i64, ptr } %t915, ptr %t908, 1
  %t918 = extractvalue { i64, ptr } %t916, 0
  %t919 = extractvalue { i64, ptr } %t916, 1
  %t920 = mul i64 %t918, 1
  %t921 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t920)
  call void @llvm.memcpy.p0.p0.i64(ptr %t921, ptr %t919, i64 %t920, i1 false)
  %t922 = insertvalue { i64, ptr } undef, i64 %t918, 0
  %t923 = insertvalue { i64, ptr } %t922, ptr %t921, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s36, ptr %t886, { i64, ptr } %t923)
  br label %bb210
bb209:
  %t926 = load ptr, ptr %l0, !tbaa !29
  %t927 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %s32, ptr %s35, ptr %t926, ptr %l28, { i64, ptr } %t927)
  br label %bb211
bb210:
  call void @__olang_scope_close(ptr %s36)
  br label %bb212
bb211:
  br label %bb212
bb212:
  %t931 = getelementptr %"compiler/mir:Task", ptr %l28, i32 0, i32 4
  %t932 = getelementptr %"compiler/mir:Range", ptr %t931, i32 0, i32 1
  %t933 = load i32, ptr %t932, !tbaa !23
  %t935 = icmp sgt i32 %t933, 0
  br i1 %t935, label %bb213, label %bb214
bb213:
  %t937 = load ptr, ptr %l2, !tbaa !29
  store ptr %t937, ptr %l377, !tbaa !29
  %t938 = load ptr, ptr %l2, !tbaa !29
  %t939 = load i32, ptr %l29, !tbaa !23
  %t940 = load ptr, ptr @__olang_prog_scope
  %t943 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t940, ptr %t938, i32 %t939)
  store i32 %t943, ptr %l380
  br label %bb215
bb214:
  store i1 false, ptr %l376, !tbaa !21
  br label %bb217
bb215:
  %t944 = load ptr, ptr @__olang_prog_scope
  %t945 = load ptr, ptr %l377, !tbaa !29
  %t946 = load i32, ptr %l380, !tbaa !23
  %t947 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t944, ptr %s35, ptr %t945, i32 %t946)
  store { i64, ptr } %t947, ptr %l381
  br label %bb216
bb216:
  %t948 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t949 = extractvalue { i64, ptr } %t948, 0
  %t951 = icmp eq i64 %t949, 0
  store i1 %t951, ptr %l376, !tbaa !21
  br label %bb217
bb217:
  %t953 = load i1, ptr %l376, !tbaa !21
  br i1 %t953, label %bb218, label %bb219
bb218:
  store %olang.scope zeroinitializer, ptr %s39
  %t954 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s39, ptr %t954, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb220
bb219:
  br label %bb221
bb220:
  call void @__olang_scope_close(ptr %s39)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s35)
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s32)
  br label %bb228
bb223:
  br i1 true, label %bb224, label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb228
bb227:
  call void @__olang_check_failed(ptr @olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22)
  unreachable
bb228:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2esuccs(ptr %v0, ptr %v1, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca %"compiler/mir:Call"
  %l46 = alloca { i64, ptr }
  %l51 = alloca %"compiler/mir:Call"
  %l53 = alloca { i64, ptr }
  %l58 = alloca %"compiler/mir:Call"
  %l59 = alloca i32
  %l64 = alloca %"compiler/mir:Call"
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [8 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [8 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = mul i64 1, 4
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  store i32 %t15, ptr %t23, !tbaa !33
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  br label %bb40
bb4:
  %t25 = load { i64, [8 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [8 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l4, !tbaa !23
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t38 = load i32, ptr %l4, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = mul i64 2, 4
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 2, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i32, ptr %t46, i64 0
  store i32 %t38, ptr %t47, !tbaa !33
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 1
  store i32 %t39, ptr %t51, !tbaa !33
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t52, ptr %l14, !tbaa !27
  br label %bb40
bb8:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb9, label %bb10
bb9:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 1
  %t60 = load %"compiler/mir:Range", ptr %t59
  store %"compiler/mir:Range" %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 2
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Range", ptr %l6
  %t68 = load i32, ptr %l7, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %t66, %"compiler/mir:Range" %t67, i32 %t68)
  store { i64, ptr } %t72, ptr %l34
  br label %bb12
bb12:
  %t73 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t73, ptr %l14, !tbaa !27
  br label %bb40
bb13:
  %t74 = load { i64, [8 x i64] }, ptr %l1
  %t76 = extractvalue { i64, [8 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 4
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32 }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l8, !tbaa !23
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 14
  %t86 = load i32, ptr %l8, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t89 = load ptr, ptr @__olang_prog_scope
  %t92 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t89, ptr %t85, i64 %t88)
  store %"compiler/mir:Call" %t92, ptr %l42
  br label %bb17
bb17:
  %t93 = getelementptr %"compiler/mir:Call", ptr %l42, i32 0, i32 7
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t98 = icmp eq i32 %t94, %t95
  br i1 %t98, label %bb18, label %bb19
bb18:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 14
  %t103 = load i32, ptr %l8, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t106 = load ptr, ptr @__olang_prog_scope
  %t109 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t106, ptr %t102, i64 %t105)
  store %"compiler/mir:Call" %t109, ptr %l51
  br label %bb20
bb19:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/mir:Fn", ptr %t110, i32 0, i32 14
  %t113 = load i32, ptr %l8, !tbaa !23
  %t115 = sext i32 %t113 to i64
  %t116 = load ptr, ptr @__olang_prog_scope
  %t119 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t116, ptr %t112, i64 %t115)
  store %"compiler/mir:Call" %t119, ptr %l58
  br label %bb21
bb20:
  %t120 = getelementptr %"compiler/mir:Call", ptr %l51, i32 0, i32 5
  %t121 = load i32, ptr %t120, !tbaa !23
  %t122 = mul i64 1, 4
  %t123 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 1, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l53, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 0
  store i32 %t121, ptr %t129, !tbaa !33
  %t130 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t130, ptr %l46, !tbaa !27
  br label %bb23
bb21:
  %t131 = getelementptr %"compiler/mir:Call", ptr %l58, i32 0, i32 5
  %t132 = load i32, ptr %t131, !tbaa !23
  store i32 %t132, ptr %l59, !tbaa !23
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/mir:Fn", ptr %t133, i32 0, i32 14
  %t136 = load i32, ptr %l8, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t139 = load ptr, ptr @__olang_prog_scope
  %t142 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t139, ptr %t135, i64 %t138)
  store %"compiler/mir:Call" %t142, ptr %l64
  br label %bb22
bb22:
  %t143 = getelementptr %"compiler/mir:Call", ptr %l64, i32 0, i32 7
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = mul i64 2, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 2, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l66, !tbaa !27
  %t149 = load i32, ptr %l59, !tbaa !23
  %t150 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t149, ptr %t152, !tbaa !33
  %t154 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 1
  store i32 %t144, ptr %t156, !tbaa !33
  %t157 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t157, ptr %l46, !tbaa !27
  br label %bb23
bb23:
  %t158 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t158, ptr %l14, !tbaa !27
  br label %bb40
bb24:
  %t159 = load { i64, [8 x i64] }, ptr %l1
  %t161 = extractvalue { i64, [8 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 8
  br i1 %t162, label %bb25, label %bb26
bb25:
  %t164 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t164, i32 0, i32 2
  %t166 = load i32, ptr %t165
  store i32 %t166, ptr %l9, !tbaa !23
  %t168 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t168, i32 0, i32 4
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l10, !tbaa !23
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t172 = load i32, ptr %l10, !tbaa !23
  %t173 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t176 = icmp eq i32 %t172, %t173
  br i1 %t176, label %bb28, label %bb29
bb28:
  %t178 = load i32, ptr %l9, !tbaa !23
  %t179 = mul i64 1, 4
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 1, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l76, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 0
  store i32 %t178, ptr %t186, !tbaa !33
  %t187 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  br label %bb30
bb29:
  %t188 = load i32, ptr %l9, !tbaa !23
  %t189 = load i32, ptr %l10, !tbaa !23
  %t190 = mul i64 2, 4
  %t191 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 2, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l79, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 0
  store i32 %t188, ptr %t197, !tbaa !33
  %t199 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i32, ptr %t200, i64 1
  store i32 %t189, ptr %t201, !tbaa !33
  %t202 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t202, ptr %l74, !tbaa !27
  br label %bb30
bb30:
  %t203 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t203, ptr %l14, !tbaa !27
  br label %bb40
bb31:
  %t204 = load { i64, [8 x i64] }, ptr %l1
  %t206 = extractvalue { i64, [8 x i64] } %t204, 0
  %t207 = icmp eq i64 %t206, 11
  br i1 %t207, label %bb32, label %bb33
bb32:
  %t209 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t209, i32 0, i32 2
  %t211 = load i32, ptr %t210
  store i32 %t211, ptr %l11, !tbaa !23
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t213 = load i32, ptr %l11, !tbaa !23
  %t214 = mul i64 1, 4
  %t215 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 1, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  store { i64, ptr } %t217, ptr %l84, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i32, ptr %t220, i64 0
  store i32 %t213, ptr %t221, !tbaa !33
  %t222 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t222, ptr %l14, !tbaa !27
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t223 = mul i64 0, 4
  %t224 = insertvalue { i64, ptr } undef, i64 0, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t225, ptr %l14, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7)
  unreachable
bb40:
  %t227 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  store i64 %t228, ptr %l86, !tbaa !24
  %t229 = load i64, ptr %l86, !tbaa !24
  %t230 = mul i64 %t229, 4
  %t231 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t230)
  %t232 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l87, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = load i64, ptr %l86, !tbaa !24
  %t239 = mul i64 %t238, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t235, ptr %t237, i64 %t239, i1 false)
  %t240 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t240, ptr %l14, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t241, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2eswitchSuccs(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i32 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i32
  %l41 = alloca i32
  %l50 = alloca %"compiler/mir:Case"
  %rv = alloca { i64, ptr }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sle i64 %t10, 2305843009213693951
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = mul i64 %t13, 4
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t18, ptr %lp3
  %t20 = load ptr, ptr %lp3
  store { i64, ptr } %t17, ptr %t20, !tbaa !27
  store i32 0, ptr %l4, !tbaa !23
  %t21 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = icmp sgt i32 %t24, %t25
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4f65b4158cb36c84_7aab915b507980)
  unreachable
bb5:
  %t30 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t30, 0
  br i1 %t32, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l20, !tbaa !23
  br label %bb10
bb7:
  %t34 = load i32, ptr %l5, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = sub i32 %t34, %t35
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = add i32 %t38, %t39
  %t44 = sub i32 %t42, 1
  %t45 = load i32, ptr %l6, !tbaa !23
  %t48 = sdiv i32 %t44, %t45
  store i32 %t48, ptr %l23, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb9
bb9:
  %t50 = load i32, ptr %l23, !tbaa !23
  store i32 %t50, ptr %l20, !tbaa !23
  br label %bb10
bb10:
  %t51 = load i32, ptr %l20, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb11
bb11:
  %t52 = load i32, ptr %l8, !tbaa !23
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = icmp slt i32 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t60 = load i32, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l8, !tbaa !23
  %t62 = load i32, ptr %l6, !tbaa !23
  %t65 = mul i32 %t61, %t62
  %t68 = add i32 %t60, %t65
  store i32 %t68, ptr %l9, !tbaa !23
  %t70 = load i32, ptr %l9, !tbaa !23
  store i32 %t70, ptr %l41, !tbaa !23
  %t73 = getelementptr %"compiler/mir:verifier", ptr %a0, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/mir:Fn", ptr %t74, i32 0, i32 15
  %t77 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load i32, ptr %l9, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = add i64 %t80, %t83
  %t87 = load ptr, ptr @__olang_prog_scope
  %t90 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t87, ptr %t76, i64 %t86)
  store %"compiler/mir:Case" %t90, ptr %l50
  br label %bb15
bb15:
  %t91 = getelementptr %"compiler/mir:Case", ptr %l50, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = load ptr, ptr %lp3
  %t95 = load i32, ptr %l41, !tbaa !23
  %t96 = sext i32 %t95 to i64
  %t97 = getelementptr { i64, ptr }, ptr %t94, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t96
  store i32 %t92, ptr %t99, !tbaa !33
  br label %bb16
bb16:
  %t100 = load i32, ptr %l8, !tbaa !23
  %t102 = add i32 %t100, 1
  store i32 %t102, ptr %l8, !tbaa !23
  br label %bb11
bb17:
  %t104 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t110 = load ptr, ptr %lp3
  %t112 = getelementptr { i64, ptr }, ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t107
  store i32 %a2, ptr %t114, !tbaa !33
  %t115 = load ptr, ptr %lp3
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etakeType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etaskTargets(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca ptr
  %l49 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Task", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/mir:Range", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = icmp sgt i32 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t15 = icmp sgt i32 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = sub i32 %t17, %t18
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t21, %t22
  %t27 = sub i32 %t25, 1
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = sdiv i32 %t27, %t28
  store i32 %t31, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t33 = load i32, ptr %l17, !tbaa !23
  store i32 %t33, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t34 = load i32, ptr %l14, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = icmp slt i32 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = mul i32 %t44, %t45
  %t51 = add i32 %t43, %t48
  store i32 %t51, ptr %l8, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store { i64, ptr } %a2, ptr %l36, !tbaa !27
  %t55 = load i32, ptr %l8, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t57
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l38, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/mir:verifier", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 13
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/mir:Task", ptr %t69, i32 0, i32 3
  %t72 = getelementptr %"compiler/mir:Range", ptr %t71, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = load i32, ptr %l8, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t81 = add i64 %t75, %t78
  %t82 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t82, ptr %t68, i64 %t81)
  store %"compiler/mir:Lvalue" %t85, ptr %l49
  br label %bb11
bb11:
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = load %"compiler/mir:Lvalue", ptr %l49
  %t88 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t86, %"compiler/mir:Lvalue" %t87)
  store i32 %t88, ptr %l50
  br label %bb12
bb12:
  %t89 = load i32, ptr %l8, !tbaa !23
  %t90 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t93 = sext i32 %t89 to i64
  %t94 = call i64 @__olang_fmt_i64(ptr null, i64 %t93)
  %t95 = add i64 %t91, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t90, i64 %t91)
  %t97 = getelementptr i8, ptr %t96, i64 %t91
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t93)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l35, !tbaa !29
  %t109 = load i32, ptr %l38, !tbaa !23
  %t110 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s2, ptr %t108, i32 %t109, i32 %t110, { i64, ptr } %t107)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t112 = load i32, ptr %l7, !tbaa !23
  %t114 = add i32 %t112, 1
  store i32 %t114, ptr %l7, !tbaa !23
  br label %bb7
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermShape(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Range"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l26 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/mir:Range"
  %l52 = alloca i64
  %l53 = alloca i1
  %l56 = alloca i1
  %l65 = alloca i1
  %l67 = alloca i64
  %l71 = alloca i64
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/mir:Range"
  %l103 = alloca i64
  %l104 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [8 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb72
bb5:
  %t8 = load { i64, [8 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [8 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t13 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l26
  br label %bb9
bb9:
  br label %bb72
bb10:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t27 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t28 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [4 x i64] } %t29, ptr %l3
  %t31 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t36 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l3
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t39, { i64, [4 x i64] } %t40)
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l36
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l39
  br label %bb16
bb16:
  br label %bb72
bb17:
  %t53 = load { i64, [8 x i64] }, ptr %l1
  %t55 = extractvalue { i64, [8 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 3
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t59 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t58, i32 0, i32 0
  %t60 = load { i64, [4 x i64] }, ptr %t59
  store { i64, [4 x i64] } %t60, ptr %l6
  %t62 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t62, i32 0, i32 1
  %t64 = load %"compiler/mir:Range", ptr %t63
  store %"compiler/mir:Range" %t64, ptr %l7
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l8, !tbaa !23
  br label %bb20
bb19:
  br label %bb25
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t70, { i64, [4 x i64] } %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l47, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l7
  store %"compiler/mir:Range" %t75, ptr %l48
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/mir:verifier", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 15
  %t82 = load ptr, ptr @__olang_prog_scope
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %t82, ptr %t81)
  store i64 %t84, ptr %l52
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t86 = load %"compiler/mir:Range", ptr %l48
  %t87 = load i64, ptr %l52, !tbaa !24
  %t88 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s4, ptr %t85, %"compiler/mir:Range" %t86, i64 %t87, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store i1 %t88, ptr %l53
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l8, !tbaa !23
  %t93 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l56
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb25:
  %t94 = load { i64, [8 x i64] }, ptr %l1
  %t96 = extractvalue { i64, [8 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 4
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32 }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l9, !tbaa !23
  br label %bb30
bb27:
  %t103 = load { i64, [8 x i64] }, ptr %l1
  %t105 = extractvalue { i64, [8 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 6
  br i1 %t106, label %bb28, label %bb29
bb28:
  %t108 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32 }, ptr %t108, i32 0, i32 1
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l9, !tbaa !23
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t112 = load i32, ptr %l9, !tbaa !23
  %t114 = icmp slt i32 %t112, 0
  br i1 %t114, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb34
bb32:
  %t116 = load i32, ptr %l9, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %l67, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/mir:verifier", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 14
  %t125 = load ptr, ptr @__olang_prog_scope
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %t125, ptr %t124)
  store i64 %t127, ptr %l71
  br label %bb33
bb33:
  %t128 = load i64, ptr %l67, !tbaa !24
  %t129 = load i64, ptr %l71, !tbaa !24
  %t130 = icmp sge i64 %t128, %t129
  store i1 %t130, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  %t135 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t138 = sext i32 %t134 to i64
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t135, i64 %t136)
  %t142 = getelementptr i8, ptr %t141, i64 %t136
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t138)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s6, ptr %t133, { i64, ptr } %t152)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  br label %bb72
bb39:
  %t155 = load { i64, [8 x i64] }, ptr %l1
  %t157 = extractvalue { i64, [8 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 5
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t160 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t160, i32 0, i32 1
  %t162 = load { i64, [4 x i64] }, ptr %t161
  store { i64, [4 x i64] } %t162, ptr %l10
  br label %bb46
bb41:
  %t164 = load { i64, [8 x i64] }, ptr %l1
  %t166 = extractvalue { i64, [8 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 7
  br i1 %t167, label %bb42, label %bb43
bb42:
  %t169 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t169, i32 0, i32 1
  %t171 = load { i64, [4 x i64] }, ptr %t170
  store { i64, [4 x i64] } %t171, ptr %l10
  br label %bb46
bb43:
  %t173 = load { i64, [8 x i64] }, ptr %l1
  %t175 = extractvalue { i64, [8 x i64] } %t173, 0
  %t176 = icmp eq i64 %t175, 9
  br i1 %t176, label %bb44, label %bb45
bb44:
  %t178 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t178, i32 0, i32 2
  %t180 = load { i64, [4 x i64] }, ptr %t179
  store { i64, [4 x i64] } %t180, ptr %l10
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load { i64, [4 x i64] }, ptr %l10
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t182, { i64, [4 x i64] } %t183)
  br label %bb47
bb47:
  br label %bb72
bb48:
  %t186 = load { i64, [8 x i64] }, ptr %l1
  %t188 = extractvalue { i64, [8 x i64] } %t186, 0
  %t189 = icmp eq i64 %t188, 11
  br i1 %t189, label %bb49, label %bb50
bb49:
  %t191 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t191, i32 0, i32 1
  %t193 = load { i64, [4 x i64] }, ptr %t192
  store { i64, [4 x i64] } %t193, ptr %l11
  %t195 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t195, i32 0, i32 2
  %t197 = load i32, ptr %t196
  store i32 %t197, ptr %l12, !tbaa !23
  %t199 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t199, i32 0, i32 3
  %t201 = load %"compiler/mir:Range", ptr %t200
  store %"compiler/mir:Range" %t201, ptr %l13
  br label %bb51
bb50:
  br label %bb56
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [4 x i64] }, ptr %l11
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperand(ptr %v0, ptr %t203, { i64, [4 x i64] } %t204)
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l12, !tbaa !23
  %t211 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t207, i32 %t208)
  store i1 %t211, ptr %l97
  br label %bb53
bb53:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l98, !tbaa !29
  %t213 = load %"compiler/mir:Range", ptr %l13
  store %"compiler/mir:Range" %t213, ptr %l99
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/mir:verifier", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/mir:Fn", ptr %t217, i32 0, i32 12
  %t220 = load ptr, ptr @__olang_prog_scope
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %t220, ptr %t219)
  store i64 %t222, ptr %l103
  br label %bb54
bb54:
  %t223 = load ptr, ptr %l98, !tbaa !29
  %t224 = load %"compiler/mir:Range", ptr %l99
  %t225 = load i64, ptr %l103, !tbaa !24
  %t226 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %s9, ptr %t223, %"compiler/mir:Range" %t224, i64 %t225, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d191, i32 0, i32 1) })
  store i1 %t226, ptr %l104
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb56:
  %t227 = load { i64, [8 x i64] }, ptr %l1
  %t229 = extractvalue { i64, [8 x i64] } %t227, 0
  %t230 = icmp eq i64 %t229, 8
  br i1 %t230, label %bb57, label %bb58
bb57:
  %t232 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t232, i32 0, i32 1
  %t234 = load i32, ptr %t233
  store i32 %t234, ptr %l14, !tbaa !23
  %t236 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t236, i32 0, i32 2
  %t238 = load i32, ptr %t237
  store i32 %t238, ptr %l15, !tbaa !23
  %t240 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t240, i32 0, i32 3
  %t242 = load i32, ptr %t241
  store i32 %t242, ptr %l16, !tbaa !23
  %t244 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t244, i32 0, i32 4
  %t246 = load i32, ptr %t245
  store i32 %t246, ptr %l17, !tbaa !23
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l14, !tbaa !23
  %t252 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l113
  br label %bb60
bb60:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l15, !tbaa !23
  %t257 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t253, i32 %t254)
  store i1 %t257, ptr %l116
  br label %bb61
bb61:
  %t258 = load i32, ptr %l17, !tbaa !23
  %t259 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t262 = icmp ne i32 %t258, %t259
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l17, !tbaa !23
  %t268 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eblock(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t268, ptr %l122
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l16, !tbaa !23
  %t273 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocal(ptr %v0, ptr %t269, i32 %t270)
  store i1 %t273, ptr %l125
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb72
bb67:
  %t274 = load { i64, [8 x i64] }, ptr %l1
  %t276 = extractvalue { i64, [8 x i64] } %t274, 0
  %t277 = icmp eq i64 %t276, 10
  br i1 %t277, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_4fdb0c87eb50ced7_f9856407ece22343)
  unreachable
bb72:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"compiler/mir:Call"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Call"
  %l16 = alloca i32
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i32
  %l19 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:ScopeInfo"
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca { i64, [4 x i64] }
  %l37 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l77 = alloca %"compiler/mir:Call"
  %l80 = alloca i32
  %l91 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i32
  %l101 = alloca i32
  %l102 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l117 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca i32
  %l130 = alloca i32
  %l138 = alloca %"compiler/mir:Call"
  %l141 = alloca i32
  %l151 = alloca i1
  %l155 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca i32
  %l168 = alloca i1
  %l177 = alloca i32
  %l183 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l196 = alloca i32
  %l205 = alloca ptr
  %l208 = alloca i32
  %l212 = alloca i32
  %l216 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca i32
  %l230 = alloca i32
  %l240 = alloca %"compiler/mir:ScopeInfo"
  %l250 = alloca { i64, ptr }
  %l254 = alloca i1
  %l261 = alloca i1
  %l269 = alloca ptr
  %l272 = alloca i32
  %l274 = alloca i32
  %l285 = alloca i1
  %l289 = alloca i1
  %l293 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca i32
  %l300 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.builder
  %s39room = alloca [64 x i8], align 8
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/mir:verifier", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load { i64, [8 x i64] }, ptr %l1
  %t13 = extractvalue { i64, [8 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 2
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t17 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t18, ptr %l4
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t20, { i64, [4 x i64] } %t21)
  store i32 %t24, ptr %l37
  br label %bb4
bb4:
  %t25 = load i32, ptr %l37, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr @__olang_prog_scope
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t28, ptr %t26, i32 %t27)
  store i32 %t31, ptr %l40
  br label %bb5
bb5:
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = load i32, ptr %l40, !tbaa !23
  %t35 = icmp ne i32 %t33, %t32
  br i1 %t35, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l43, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s2, ptr %t38, i32 %t39)
  store { i64, ptr } %t42, ptr %l46
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t43 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t60 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s2, ptr %t60, { i64, ptr } %t59)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb196
bb11:
  %t62 = load { i64, [8 x i64] }, ptr %l1
  %t64 = extractvalue { i64, [8 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 3
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t68 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t67, i32 0, i32 0
  %t69 = load { i64, [4 x i64] }, ptr %t68
  store { i64, [4 x i64] } %t69, ptr %l6
  %t71 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t72 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t71, i32 0, i32 1
  %t73 = load %"compiler/mir:Range", ptr %t72
  store %"compiler/mir:Range" %t73, ptr %l7
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load { i64, [4 x i64] }, ptr %l6
  %t79 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t75, { i64, [4 x i64] } %t76)
  store i32 %t79, ptr %l55
  br label %bb15
bb15:
  %t80 = load i32, ptr %l55, !tbaa !23
  store i32 %t80, ptr %l8, !tbaa !23
  %t81 = load ptr, ptr %l2, !tbaa !29
  store ptr %t81, ptr %l56, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l8, !tbaa !23
  %t84 = load ptr, ptr @__olang_prog_scope
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t84, ptr %t82, i32 %t83)
  store i32 %t87, ptr %l59
  br label %bb16
bb16:
  %t88 = load ptr, ptr @__olang_prog_scope
  %t89 = load ptr, ptr %l56, !tbaa !29
  %t90 = load i32, ptr %l59, !tbaa !23
  %t91 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %t88, ptr %t89, i32 %t90)
  store i1 %t91, ptr %l60
  br label %bb17
bb17:
  %t92 = load i1, ptr %l60, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l62, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l8, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s5, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l65
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t101 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t103 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t101, i64 %t102)
  %t108 = getelementptr i8, ptr %t107, i64 %t102
  call void @olang_textcopy(ptr %t108, ptr %t104, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s5, ptr %t118, { i64, ptr } %t117)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/mir:Range", ptr %l7
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %t120, %"compiler/mir:Range" %t121)
  br label %bb23
bb23:
  br label %bb196
bb24:
  %t124 = load { i64, [8 x i64] }, ptr %l1
  %t126 = extractvalue { i64, [8 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 4
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32 }, ptr %t129, i32 0, i32 1
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb65
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t135 = getelementptr %"compiler/mir:Fn", ptr %t133, i32 0, i32 14
  %t136 = load i32, ptr %l9, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t139 = load ptr, ptr @__olang_prog_scope
  %t142 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t139, ptr %t135, i64 %t138)
  store %"compiler/mir:Call" %t142, ptr %l77
  br label %bb28
bb28:
  %t143 = load %"compiler/mir:Call", ptr %l77
  store %"compiler/mir:Call" %t143, ptr %l10
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t146 = load { i64, [7 x i64] }, ptr %t145
  %t149 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t144, { i64, [7 x i64] } %t146)
  store i32 %t149, ptr %l80
  br label %bb29
bb29:
  %t150 = load i32, ptr %l80, !tbaa !23
  store i32 %t150, ptr %l11, !tbaa !23
  %t151 = load i32, ptr %l11, !tbaa !23
  %t152 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t155 = icmp eq i32 %t151, %t152
  br i1 %t155, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 0
  %t159 = load { i64, [7 x i64] }, ptr %t158
  %t160 = load i32, ptr %l11, !tbaa !23
  %t161 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 1
  %t162 = load %"compiler/mir:Range", ptr %t161
  %t163 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 2
  %t164 = load %"compiler/mir:Range", ptr %t163
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t157, { i64, [7 x i64] } %t159, i32 %t160, %"compiler/mir:Range" %t162, %"compiler/mir:Range" %t164)
  br label %bb33
bb33:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l11, !tbaa !23
  %t174 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eheld(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l91
  br label %bb34
bb34:
  %t175 = load i32, ptr %l91, !tbaa !23
  store i32 %t175, ptr %l12, !tbaa !23
  %t176 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 4
  %t177 = load i1, ptr %t176, !tbaa !21
  br i1 %t177, label %bb35, label %bb36
bb35:
  %t179 = load i32, ptr %l12, !tbaa !23
  %t180 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t183 = icmp eq i32 %t179, %t180
  br i1 %t183, label %bb37, label %bb38
bb36:
  br label %bb43
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s10, ptr %t185, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l97, !tbaa !29
  %t188 = load i32, ptr %l12, !tbaa !23
  store i32 %t188, ptr %l98, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 3
  %t191 = load %"compiler/mir:Lvalue", ptr %t190
  %t194 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eplaceType(ptr %v0, ptr %t189, %"compiler/mir:Lvalue" %t191)
  store i32 %t194, ptr %l101
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb42
bb40:
  %t195 = load ptr, ptr %l97, !tbaa !29
  %t196 = load i32, ptr %l98, !tbaa !23
  %t197 = load i32, ptr %l101, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s11, ptr %t195, i32 %t196, i32 %t197, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t198 = load ptr, ptr %l2, !tbaa !29
  store ptr %t198, ptr %l102, !tbaa !29
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t200 = load i32, ptr %l11, !tbaa !23
  %t201 = load ptr, ptr @__olang_prog_scope
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t201, ptr %t199, i32 %t200)
  store i32 %t204, ptr %l105
  br label %bb44
bb44:
  %t205 = load ptr, ptr @__olang_prog_scope
  %t206 = load ptr, ptr %l102, !tbaa !29
  %t207 = load i32, ptr %l105, !tbaa !23
  %t208 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t205, ptr %s7, ptr %t206, i32 %t207)
  store { i64, ptr } %t208, ptr %l106
  br label %bb45
bb45:
  %t209 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t212 = icmp sgt i64 %t210, 0
  store i1 %t212, ptr %l13, !tbaa !21
  %t214 = load i1, ptr %l13, !tbaa !21
  br i1 %t214, label %bb46, label %bb47
bb46:
  %t216 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t217 = load i32, ptr %t216, !tbaa !23
  %t218 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t221 = icmp eq i32 %t217, %t218
  store i1 %t221, ptr %l110, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb48
bb48:
  %t223 = load i1, ptr %l110, !tbaa !21
  br i1 %t223, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t224 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s12, ptr %t224, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb52:
  %t226 = load i1, ptr %l13, !tbaa !21
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb53, label %bb54
bb53:
  %t230 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t235 = icmp ne i32 %t231, %t232
  store i1 %t235, ptr %l117, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb55
bb55:
  %t237 = load i1, ptr %l117, !tbaa !21
  br i1 %t237, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s13, ptr %t238, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb59:
  %t240 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 7
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t245 = icmp ne i32 %t241, %t242
  br i1 %t245, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l125, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/mir:Call", ptr %l10, i32 0, i32 6
  %t250 = load i32, ptr %t249, !tbaa !23
  %t253 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t248, i32 %t250)
  store i32 %t253, ptr %l128
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t254 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t255 = load ptr, ptr %l125, !tbaa !29
  %t256 = load i32, ptr %l128, !tbaa !23
  %t258 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s14, ptr %t255, i32 %t256, i32 %t254, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i32 %t258, ptr %l130
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb196
bb65:
  %t259 = load { i64, [8 x i64] }, ptr %l1
  %t261 = extractvalue { i64, [8 x i64] } %t259, 0
  %t262 = icmp eq i64 %t261, 6
  br i1 %t262, label %bb66, label %bb67
bb66:
  %t264 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32 }, ptr %t264, i32 0, i32 1
  %t266 = load i32, ptr %t265
  store i32 %t266, ptr %l14, !tbaa !23
  br label %bb68
bb67:
  br label %bb92
bb68:
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = getelementptr %"compiler/mir:Fn", ptr %t268, i32 0, i32 14
  %t271 = load i32, ptr %l14, !tbaa !23
  %t273 = sext i32 %t271 to i64
  %t274 = load ptr, ptr @__olang_prog_scope
  %t277 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t274, ptr %t270, i64 %t273)
  store %"compiler/mir:Call" %t277, ptr %l138
  br label %bb69
bb69:
  %t278 = load %"compiler/mir:Call", ptr %l138
  store %"compiler/mir:Call" %t278, ptr %l15
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t281 = load { i64, [7 x i64] }, ptr %t280
  %t284 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %t279, { i64, [7 x i64] } %t281)
  store i32 %t284, ptr %l141
  br label %bb70
bb70:
  %t285 = load i32, ptr %l141, !tbaa !23
  store i32 %t285, ptr %l16, !tbaa !23
  %t286 = load i32, ptr %l16, !tbaa !23
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t290 = icmp eq i32 %t286, %t287
  br i1 %t290, label %bb71, label %bb72
bb71:
  br label %ret
bb72:
  br label %bb73
bb73:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 0
  %t294 = load { i64, [7 x i64] }, ptr %t293
  %t295 = load i32, ptr %l16, !tbaa !23
  %t296 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 1
  %t297 = load %"compiler/mir:Range", ptr %t296
  %t298 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 2
  %t299 = load %"compiler/mir:Range", ptr %t298
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eargs(ptr %v0, ptr %t292, { i64, [7 x i64] } %t294, i32 %t295, %"compiler/mir:Range" %t297, %"compiler/mir:Range" %t299)
  br label %bb74
bb74:
  %t305 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 4
  %t306 = load i1, ptr %t305, !tbaa !21
  br i1 %t306, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb77
bb76:
  %t308 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 5
  %t309 = load i32, ptr %t308, !tbaa !23
  %t310 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t313 = icmp ne i32 %t309, %t310
  store i1 %t313, ptr %l151, !tbaa !21
  br label %bb77
bb77:
  %t315 = load i1, ptr %l151, !tbaa !21
  br i1 %t315, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb80
bb79:
  %t316 = getelementptr %"compiler/mir:Call", ptr %l15, i32 0, i32 7
  %t317 = load i32, ptr %t316, !tbaa !23
  %t318 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t321 = icmp ne i32 %t317, %t318
  store i1 %t321, ptr %l155, !tbaa !21
  br label %bb80
bb80:
  %t323 = load i1, ptr %l155, !tbaa !21
  br i1 %t323, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s17, ptr %t324, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d199, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  %t326 = load ptr, ptr %l2, !tbaa !29
  store ptr %t326, ptr %l160, !tbaa !29
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t328 = load i32, ptr %l16, !tbaa !23
  %t329 = load ptr, ptr @__olang_prog_scope
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t329, ptr %t327, i32 %t328)
  store i32 %t332, ptr %l163
  br label %bb85
bb85:
  %t333 = load ptr, ptr %l2, !tbaa !29
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t336 = getelementptr %"compiler/mir:Fn", ptr %t334, i32 0, i32 1
  %t337 = load i32, ptr %t336, !tbaa !23
  %t338 = load ptr, ptr @__olang_prog_scope
  %t341 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t338, ptr %t333, i32 %t337)
  store i32 %t341, ptr %l167
  br label %bb86
bb86:
  %t342 = load ptr, ptr @__olang_prog_scope
  %t343 = load ptr, ptr %l160, !tbaa !29
  %t344 = load i32, ptr %l163, !tbaa !23
  %t345 = load i32, ptr %l167, !tbaa !23
  %t346 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t342, ptr %t343, i32 %t344, i32 %t345)
  store i1 %t346, ptr %l168
  br label %bb87
bb87:
  %t347 = load i1, ptr %l168, !tbaa !21
  %t348 = xor i1 %t347, true
  br i1 %t348, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  %t350 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s18, ptr %t350, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb91:
  br label %bb196
bb92:
  %t352 = load { i64, [8 x i64] }, ptr %l1
  %t354 = extractvalue { i64, [8 x i64] } %t352, 0
  %t355 = icmp eq i64 %t354, 5
  br i1 %t355, label %bb93, label %bb94
bb93:
  %t357 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t357, i32 0, i32 1
  %t359 = load { i64, [4 x i64] }, ptr %t358
  store { i64, [4 x i64] } %t359, ptr %l17
  br label %bb95
bb94:
  br label %bb111
bb95:
  %t361 = load ptr, ptr %l2, !tbaa !29
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t364 = getelementptr %"compiler/mir:Fn", ptr %t362, i32 0, i32 1
  %t365 = load i32, ptr %t364, !tbaa !23
  %t366 = load ptr, ptr @__olang_prog_scope
  %t369 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t366, ptr %t361, i32 %t365)
  store i32 %t369, ptr %l177
  br label %bb96
bb96:
  %t370 = load i32, ptr %l177, !tbaa !23
  store i32 %t370, ptr %l18, !tbaa !23
  %t371 = load { i64, [4 x i64] }, ptr %l17
  %t373 = extractvalue { i64, [4 x i64] } %t371, 0
  %t374 = icmp eq i64 %t373, 0
  br i1 %t374, label %bb97, label %bb98
bb97:
  %t376 = load i32, ptr %l18, !tbaa !23
  %t377 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t380 = icmp ne i32 %t376, %t377
  br i1 %t380, label %bb99, label %bb100
bb98:
  %t382 = load i32, ptr %l18, !tbaa !23
  %t383 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t386 = icmp eq i32 %t382, %t383
  br i1 %t386, label %bb104, label %bb105
bb99:
  store %olang.scope zeroinitializer, ptr %s21
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l183, !tbaa !29
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load i32, ptr %l18, !tbaa !23
  %t393 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s21, ptr %t389, i32 %t390)
  store { i64, ptr } %t393, ptr %l186
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t394 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t396 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = add i64 %t395, %t398
  %t400 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t399)
  call void @olang_textcopy(ptr %t400, ptr %t394, i64 %t395)
  %t401 = getelementptr i8, ptr %t400, i64 %t395
  call void @olang_textcopy(ptr %t401, ptr %t397, i64 %t398)
  %t402 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t400, 1
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t406 = extractvalue { i64, ptr } %t403, 1
  %t407 = mul i64 %t405, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t407)
  call void @llvm.memcpy.p0.p0.i64(ptr %t408, ptr %t406, i64 %t407, i1 false)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  %t411 = load ptr, ptr %l183, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s21, ptr %t411, { i64, ptr } %t410)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb103
bb103:
  br label %bb110
bb104:
  store %olang.scope zeroinitializer, ptr %s24
  %t413 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s24, ptr %t413, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d202, i32 0, i32 1) })
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s25
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l193, !tbaa !29
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load { i64, [4 x i64] }, ptr %l17
  %t420 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t416, { i64, [4 x i64] } %t417)
  store i32 %t420, ptr %l196
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb107:
  %t421 = load i32, ptr %l18, !tbaa !23
  %t422 = load ptr, ptr %l193, !tbaa !29
  %t423 = load i32, ptr %l196, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s25, ptr %t422, i32 %t423, i32 %t421, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s25)
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb196
bb111:
  %t425 = load { i64, [8 x i64] }, ptr %l1
  %t427 = extractvalue { i64, [8 x i64] } %t425, 0
  %t428 = icmp eq i64 %t427, 11
  br i1 %t428, label %bb112, label %bb113
bb112:
  %t430 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t430, i32 0, i32 1
  %t432 = load { i64, [4 x i64] }, ptr %t431
  store { i64, [4 x i64] } %t432, ptr %l19
  br label %bb114
bb113:
  br label %bb122
bb114:
  store %olang.scope zeroinitializer, ptr %s26
  %t434 = load ptr, ptr %l3, !tbaa !29
  %t436 = getelementptr %"compiler/mir:Fn", ptr %t434, i32 0, i32 25
  %t437 = load i1, ptr %t436, !tbaa !21
  %t439 = xor i1 %t437, true
  br i1 %t439, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s27
  %t441 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s27, ptr %t441, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s27)
  br label %bb118
bb118:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l205, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, [4 x i64] }, ptr %l19
  %t448 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t444, { i64, [4 x i64] } %t445)
  store i32 %t448, ptr %l208
  br label %bb119
bb119:
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load ptr, ptr %l3, !tbaa !29
  %t452 = getelementptr %"compiler/mir:Fn", ptr %t450, i32 0, i32 1
  %t453 = load i32, ptr %t452, !tbaa !23
  %t454 = load ptr, ptr @__olang_prog_scope
  %t457 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t454, ptr %t449, i32 %t453)
  store i32 %t457, ptr %l212
  br label %bb120
bb120:
  %t458 = load ptr, ptr %l205, !tbaa !29
  %t459 = load i32, ptr %l208, !tbaa !23
  %t460 = load i32, ptr %l212, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %s26, ptr %t458, i32 %t459, i32 %t460, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s26)
  br label %bb196
bb122:
  %t461 = load { i64, [8 x i64] }, ptr %l1
  %t463 = extractvalue { i64, [8 x i64] } %t461, 0
  %t464 = icmp eq i64 %t463, 7
  br i1 %t464, label %bb123, label %bb124
bb123:
  %t466 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t467 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t466, i32 0, i32 1
  %t468 = load { i64, [4 x i64] }, ptr %t467
  store { i64, [4 x i64] } %t468, ptr %l20
  br label %bb125
bb124:
  br label %bb134
bb125:
  store %olang.scope zeroinitializer, ptr %s28
  %t470 = load ptr, ptr %l2, !tbaa !29
  store ptr %t470, ptr %l216, !tbaa !29
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t472 = load ptr, ptr %l3, !tbaa !29
  %t474 = getelementptr %"compiler/mir:Fn", ptr %t472, i32 0, i32 1
  %t475 = load i32, ptr %t474, !tbaa !23
  %t476 = load ptr, ptr @__olang_prog_scope
  %t479 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t476, ptr %t471, i32 %t475)
  store i32 %t479, ptr %l220
  br label %bb126
bb126:
  %t480 = load ptr, ptr @__olang_prog_scope
  %t481 = load ptr, ptr %l216, !tbaa !29
  %t482 = load i32, ptr %l220, !tbaa !23
  %t483 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t480, ptr %s28, ptr %t481, i32 %t482)
  store { i64, ptr } %t483, ptr %l221
  br label %bb127
bb127:
  %t484 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t484, 0
  %t487 = icmp eq i64 %t485, 0
  br i1 %t487, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s29
  %t489 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s29, ptr %t489, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s29)
  br label %bb131
bb131:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l225, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load { i64, [4 x i64] }, ptr %l20
  %t496 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t492, { i64, [4 x i64] } %t493)
  store i32 %t496, ptr %l228
  br label %bb132
bb132:
  %t497 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t498 = load ptr, ptr %l225, !tbaa !29
  %t499 = load i32, ptr %l228, !tbaa !23
  %t501 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s28, ptr %t498, i32 %t499, i32 %t497, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d207, i32 0, i32 1) })
  store i32 %t501, ptr %l230
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s28)
  br label %bb196
bb134:
  %t502 = load { i64, [8 x i64] }, ptr %l1
  %t504 = extractvalue { i64, [8 x i64] } %t502, 0
  %t505 = icmp eq i64 %t504, 8
  br i1 %t505, label %bb135, label %bb136
bb135:
  %t507 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t507, i32 0, i32 1
  %t509 = load i32, ptr %t508
  store i32 %t509, ptr %l21, !tbaa !23
  %t511 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t512 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t511, i32 0, i32 3
  %t513 = load i32, ptr %t512
  store i32 %t513, ptr %l22, !tbaa !23
  %t515 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t515, i32 0, i32 4
  %t517 = load i32, ptr %t516
  store i32 %t517, ptr %l23, !tbaa !23
  br label %bb137
bb136:
  br label %bb163
bb137:
  store %olang.scope zeroinitializer, ptr %s30
  %t519 = load ptr, ptr %l3, !tbaa !29
  %t521 = getelementptr %"compiler/mir:Fn", ptr %t519, i32 0, i32 8
  %t522 = load i32, ptr %l21, !tbaa !23
  %t524 = sext i32 %t522 to i64
  %t525 = load ptr, ptr @__olang_prog_scope
  %t528 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t525, ptr %t521, i64 %t524)
  store %"compiler/mir:ScopeInfo" %t528, ptr %l240
  br label %bb138
bb138:
  %t529 = load %"compiler/mir:ScopeInfo", ptr %l240
  store %"compiler/mir:ScopeInfo" %t529, ptr %l24
  %t530 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 0
  %t531 = load i32, ptr %t530, !range !{i32 0, i32 7}
  %t533 = trunc i64 3 to i32
  %t534 = icmp eq i32 %t531, %t533
  %t536 = xor i1 %t534, true
  br i1 %t536, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s31
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i32, ptr %l21, !tbaa !23
  %t540 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t543 = sext i32 %t539 to i64
  %t544 = call i64 @__olang_fmt_i64(ptr null, i64 %t543)
  %t545 = add i64 %t541, %t544
  %t546 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t547 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t548 = add i64 %t545, %t547
  %t549 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t548)
  call void @olang_textcopy(ptr %t549, ptr %t540, i64 %t541)
  %t550 = getelementptr i8, ptr %t549, i64 %t541
  %t551 = call i64 @__olang_fmt_i64(ptr %t550, i64 %t543)
  %t552 = getelementptr i8, ptr %t550, i64 %t544
  call void @olang_textcopy(ptr %t552, ptr %t546, i64 %t547)
  %t553 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t549, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = extractvalue { i64, ptr } %t554, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s31, ptr %t538, { i64, ptr } %t561)
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  %t564 = load ptr, ptr %l2, !tbaa !29
  %t565 = getelementptr %"compiler/mir:ScopeInfo", ptr %l24, i32 0, i32 4
  %t566 = load i32, ptr %t565, !tbaa !23
  %t567 = load ptr, ptr @__olang_prog_scope
  %t570 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t567, ptr %s30, ptr %t564, i32 %t566)
  store { i64, ptr } %t570, ptr %l250
  br label %bb143
bb143:
  %t571 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 0
  %t574 = icmp sgt i64 %t572, 0
  store i1 %t574, ptr %l25, !tbaa !21
  %t576 = load i1, ptr %l25, !tbaa !21
  br i1 %t576, label %bb144, label %bb145
bb144:
  %t578 = load i32, ptr %l23, !tbaa !23
  %t579 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t582 = icmp eq i32 %t578, %t579
  store i1 %t582, ptr %l254, !tbaa !21
  br label %bb146
bb145:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb146
bb146:
  %t584 = load i1, ptr %l254, !tbaa !21
  br i1 %t584, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s33
  %t585 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s33, ptr %t585, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d210, i32 0, i32 1) })
  br label %bb149
bb148:
  br label %bb150
bb149:
  call void @__olang_scope_close(ptr %s33)
  br label %bb150
bb150:
  %t587 = load i1, ptr %l25, !tbaa !21
  %t589 = xor i1 %t587, true
  br i1 %t589, label %bb151, label %bb152
bb151:
  %t591 = load i32, ptr %l23, !tbaa !23
  %t592 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t595 = icmp ne i32 %t591, %t592
  store i1 %t595, ptr %l261, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb153
bb153:
  %t597 = load i1, ptr %l261, !tbaa !21
  br i1 %t597, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s34
  %t598 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s34, ptr %t598, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d211, i32 0, i32 1) })
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s34)
  br label %bb157
bb157:
  %t600 = load i32, ptr %l23, !tbaa !23
  %t601 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t604 = icmp ne i32 %t600, %t601
  br i1 %t604, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s35
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l269, !tbaa !29
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load i32, ptr %l22, !tbaa !23
  %t611 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2elocalType(ptr %v0, ptr %t607, i32 %t608)
  store i32 %t611, ptr %l272
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t612 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t613 = load ptr, ptr %l269, !tbaa !29
  %t614 = load i32, ptr %l272, !tbaa !23
  %t616 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %s35, ptr %t613, i32 %t614, i32 %t612, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d212, i32 0, i32 1) })
  store i32 %t616, ptr %l274
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s35)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s30)
  br label %bb196
bb163:
  %t617 = load { i64, [8 x i64] }, ptr %l1
  %t619 = extractvalue { i64, [8 x i64] } %t617, 0
  %t620 = icmp eq i64 %t619, 9
  br i1 %t620, label %bb164, label %bb165
bb164:
  %t622 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t623 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t622, i32 0, i32 1
  %t624 = load i32, ptr %t623, !range !{i32 0, i32 16}
  store i32 %t624, ptr %l26
  %t626 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t626, i32 0, i32 2
  %t628 = load { i64, [4 x i64] }, ptr %t627
  store { i64, [4 x i64] } %t628, ptr %l27
  br label %bb166
bb165:
  br label %bb191
bb166:
  %t630 = load { i64, [4 x i64] }, ptr %l27
  %t632 = extractvalue { i64, [4 x i64] } %t630, 0
  %t633 = icmp eq i64 %t632, 0
  %t635 = xor i1 %t633, true
  br i1 %t635, label %bb167, label %bb168
bb167:
  %t637 = load i32, ptr %l26, !range !{i32 0, i32 16}
  %t639 = trunc i64 7 to i32
  %t640 = icmp eq i32 %t637, %t639
  %t642 = xor i1 %t640, true
  br i1 %t642, label %bb169, label %bb170
bb168:
  br label %bb190
bb169:
  %t644 = load i32, ptr %l26, !range !{i32 0, i32 16}
  %t646 = trunc i64 3 to i32
  %t647 = icmp eq i32 %t644, %t646
  %t649 = xor i1 %t647, true
  store i1 %t649, ptr %l285, !tbaa !21
  br label %bb171
bb170:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb171
bb171:
  %t651 = load i1, ptr %l285, !tbaa !21
  br i1 %t651, label %bb172, label %bb173
bb172:
  %t652 = load i32, ptr %l26, !range !{i32 0, i32 16}
  %t654 = trunc i64 14 to i32
  %t655 = icmp eq i32 %t652, %t654
  %t657 = xor i1 %t655, true
  store i1 %t657, ptr %l289, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb174
bb174:
  %t659 = load i1, ptr %l289, !tbaa !21
  br i1 %t659, label %bb175, label %bb176
bb175:
  %t660 = load i32, ptr %l26, !range !{i32 0, i32 16}
  %t662 = trunc i64 15 to i32
  %t663 = icmp eq i32 %t660, %t662
  %t665 = xor i1 %t663, true
  store i1 %t665, ptr %l293, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb177
bb177:
  %t667 = load i1, ptr %l293, !tbaa !21
  br i1 %t667, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s38
  %t668 = load ptr, ptr %l0, !tbaa !29
  store ptr %t668, ptr %l297, !tbaa !29
  %t669 = load i32, ptr %l26, !range !{i32 0, i32 16}
  store i32 %t669, ptr %l298
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s39
  store ptr %s39room, ptr %s39
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s39, ptr %l298, i64 0)
  br label %bb180
bb179:
  br label %bb183
bb180:
  %t671 = load ptr, ptr %s39
  %t672 = getelementptr %olang.builder, ptr %s39, i32 0, i32 1
  %t673 = load i64, ptr %t672
  %t674 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t673)
  call void @olang_textcopy(ptr %t674, ptr %t671, i64 %t673)
  %t675 = insertvalue { i64, ptr } undef, i64 %t673, 0
  %t676 = insertvalue { i64, ptr } %t675, ptr %t674, 1
  store { i64, ptr } %t676, ptr %l300, !tbaa !27
  %t677 = getelementptr %olang.builder, ptr %s39, i32 0, i32 3
  %t678 = load ptr, ptr %t677
  %t679 = icmp ne ptr %t678, null
  br i1 %t679, label %sbgrew.680, label %sbdone.681
sbgrew.680:
  call void @__olang_sb_done(ptr %s39)
  br label %sbdone.681
sbdone.681:
  %t682 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t682, 0
  %t684 = extractvalue { i64, ptr } %t682, 1
  %t685 = mul i64 %t683, 1
  %t686 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t685)
  call void @llvm.memcpy.p0.p0.i64(ptr %t686, ptr %t684, i64 %t685, i1 false)
  %t687 = insertvalue { i64, ptr } undef, i64 %t683, 0
  %t688 = insertvalue { i64, ptr } %t687, ptr %t686, 1
  %t690 = call { i64, ptr } @compiler_2fmir_2eshort(ptr %s38, ptr %s38, { i64, ptr } %t688)
  store { i64, ptr } %t690, ptr %l302
  br label %bb181
bb181:
  %t691 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t693 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t694 = extractvalue { i64, ptr } %t693, 1
  %t695 = extractvalue { i64, ptr } %t693, 0
  %t696 = add i64 %t692, %t695
  %t697 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t700 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t699)
  call void @olang_textcopy(ptr %t700, ptr %t691, i64 %t692)
  %t701 = getelementptr i8, ptr %t700, i64 %t692
  call void @olang_textcopy(ptr %t701, ptr %t694, i64 %t695)
  %t702 = getelementptr i8, ptr %t701, i64 %t695
  call void @olang_textcopy(ptr %t702, ptr %t697, i64 %t698)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t700, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = extractvalue { i64, ptr } %t704, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  %t712 = load ptr, ptr %l297, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s38, ptr %t712, { i64, ptr } %t711)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s38)
  br label %bb183
bb183:
  %t714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t714, ptr %l305, !tbaa !29
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load { i64, [4 x i64] }, ptr %l27
  %t719 = call i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eoperandType(ptr %v0, ptr %t715, { i64, [4 x i64] } %t716)
  store i32 %t719, ptr %l308
  br label %bb184
bb184:
  %t720 = load ptr, ptr %l305, !tbaa !29
  %t721 = load i32, ptr %l308, !tbaa !23
  %t722 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t720, i32 %t721)
  store i1 %t722, ptr %l309
  br label %bb185
bb185:
  %t723 = load i1, ptr %l309, !tbaa !21
  %t724 = xor i1 %t723, true
  br i1 %t724, label %bb186, label %bb187
bb186:
  store %olang.scope zeroinitializer, ptr %s41
  %t726 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s41, ptr %t726, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb188
bb187:
  br label %bb189
bb188:
  call void @__olang_scope_close(ptr %s41)
  br label %bb189
bb189:
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7)
  unreachable
bb196:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etextType(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuilder(ptr %v0, ptr %t1, { i64, [1 x i64] } %a1)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eisText(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecanon(ptr %v0, ptr %s1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l12
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t19, i64 %t20)
  %t26 = getelementptr i8, ptr %t25, i64 %t20
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t36, { i64, ptr } %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etypes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, [21 x i64] }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 9
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l21
  br label %bb1
bb1:
  %t12 = load i64, ptr %l21, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/mir:verifier", ptr %t59, i32 0, i32 13
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l47, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i1, ptr %t66, i64 %t63
  %t68 = load i1, ptr %t67, !tbaa !31
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb13:
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = getelementptr %"compiler/mir:verifier", ptr %t72, i32 0, i32 3
  store i64 %t73, ptr %t76, !tbaa !24
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 9
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load ptr, ptr @__olang_prog_scope
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t81, ptr %s2, ptr %t79, i64 %t80)
  store ptr %t84, ptr %l56
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l56, !tbaa !29
  store ptr %t85, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  %t86 = load ptr, ptr %l8, !tbaa !29
  %t88 = getelementptr %"compiler/mir:BasicBlock", ptr %t86, i32 0, i32 0
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s2, ptr %t88)
  store i64 %t90, ptr %l59
  br label %bb16
bb16:
  %t91 = load i64, ptr %l59, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp sgt i64 %t92, %t93
  br i1 %t96, label %bb17, label %bb18
bb17:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  br i1 %t100, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb22
bb19:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = sub i64 %t102, %t103
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = add i64 %t106, %t107
  %t112 = sub i64 %t110, 1
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = sdiv i64 %t112, %t113
  store i64 %t116, ptr %l66, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb21
bb21:
  %t118 = load i64, ptr %l66, !tbaa !24
  store i64 %t118, ptr %l63, !tbaa !24
  br label %bb22
bb22:
  %t119 = load i64, ptr %l63, !tbaa !24
  store i64 %t119, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load i64, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = mul i64 %t129, %t130
  %t136 = add i64 %t128, %t133
  store i64 %t136, ptr %l14, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = getelementptr %"compiler/mir:verifier", ptr %t138, i32 0, i32 4
  store i64 %t139, ptr %t142, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l86, !tbaa !29
  %t144 = load ptr, ptr %l8, !tbaa !29
  %t146 = getelementptr %"compiler/mir:BasicBlock", ptr %t144, i32 0, i32 0
  %t147 = load i64, ptr %l14, !tbaa !24
  %t150 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s2, ptr %t146, i64 %t147)
  store { i64, [21 x i64] } %t150, ptr %l90
  br label %bb27
bb27:
  %t151 = load { i64, [21 x i64] }, ptr %l90
  %t152 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t151, ptr %t152
  %t153 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtTypes(ptr %v0, ptr %s5, ptr %t153, ptr %t152)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l13, !tbaa !24
  br label %bb23
bb30:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/mir:verifier", ptr %t159, i32 0, i32 4
  store i64 -1, ptr %t161, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t165 = getelementptr %"compiler/mir:BasicBlock", ptr %t163, i32 0, i32 1
  %t166 = load { i64, [8 x i64] }, ptr %t165
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermTypes(ptr %v0, ptr %t162, { i64, [8 x i64] } %t166)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t169 = load i64, ptr %l6, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l6, !tbaa !24
  br label %bb8
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/mir:verifier", ptr %t173, i32 0, i32 3
  store i64 -1, ptr %t177, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/mir:verifier", ptr %t178, i32 0, i32 4
  store i64 -1, ptr %t182, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eused(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i1, ptr %t10, i64 %t7
  %t12 = load i1, ptr %t11, !tbaa !31
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t21 = sext i32 %t17 to i64
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t21)
  %t30 = getelementptr i8, ptr %t28, i64 %t22
  call void @olang_textcopy(ptr %t30, ptr %t24, i64 %t25)
  %t31 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t27, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } %t39)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca i64
  %l140 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l168 = alloca i32
  %l176 = alloca ptr
  %l179 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i64
  %l206 = alloca ptr
  %l210 = alloca { i64, [21 x i64] }
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/mir:verifier", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 7
  %t9 = load ptr, ptr @__olang_prog_scope
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t9, ptr %t8)
  store i64 %t11, ptr %l35
  br label %bb1
bb1:
  %t12 = load i64, ptr %l35, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 8
  %t16 = load ptr, ptr @__olang_prog_scope
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t16, ptr %t15)
  store i64 %t18, ptr %l38
  br label %bb2
bb2:
  %t19 = load i64, ptr %l38, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  %t22 = sext i32 %a1 to i64
  store i64 %t22, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb3, label %bb4
bb3:
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb8
bb5:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l48, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t52 = load i64, ptr %l48, !tbaa !24
  store i64 %t52, ptr %l45, !tbaa !24
  br label %bb8
bb8:
  %t53 = load i64, ptr %l45, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l11, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/mir:verifier", ptr %t72, i32 0, i32 14
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l67, !tbaa !27
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/mir:verifier", ptr %t77, i32 0, i32 7
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l70, !tbaa !27
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l3, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i1, ptr %t92, i64 %t89
  %t94 = load i1, ptr %t93, !tbaa !31
  %t97 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i1, ptr %t98, i64 %t76
  store i1 %t94, ptr %t99, !tbaa !31
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/mir:verifier", ptr %t100, i32 0, i32 15
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l78, !tbaa !27
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/mir:verifier", ptr %t105, i32 0, i32 8
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l81, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i1, ptr %t120, i64 %t117
  %t122 = load i1, ptr %t121, !tbaa !31
  %t125 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i1, ptr %t126, i64 %t104
  store i1 %t122, ptr %t127, !tbaa !31
  br label %bb13
bb13:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l10, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l4, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb15, label %bb16
bb15:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb20
bb17:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l97, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb19
bb19:
  %t160 = load i64, ptr %l97, !tbaa !24
  store i64 %t160, ptr %l94, !tbaa !24
  br label %bb20
bb20:
  %t161 = load i64, ptr %l94, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/mir:verifier", ptr %t180, i32 0, i32 16
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l116, !tbaa !27
  %t184 = load i64, ptr %l17, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/mir:verifier", ptr %t185, i32 0, i32 9
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l119, !tbaa !27
  %t189 = load i64, ptr %l5, !tbaa !24
  %t190 = load i64, ptr %l4, !tbaa !24
  %t193 = mul i64 %t189, %t190
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i1, ptr %t200, i64 %t197
  %t202 = load i1, ptr %t201, !tbaa !31
  %t205 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i1, ptr %t206, i64 %t184
  store i1 %t202, ptr %t207, !tbaa !31
  br label %bb25
bb25:
  %t208 = load i64, ptr %l16, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l16, !tbaa !24
  br label %bb21
bb26:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/mir:verifier", ptr %t212, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t214)
  br label %bb27
bb27:
  store i64 0, ptr %l18, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/mir:verifier", ptr %t216, i32 0, i32 11
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l131, !tbaa !27
  %t220 = load i64, ptr %l5, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i64, ptr %t223, i64 %t220
  %t225 = load i64, ptr %t224, !tbaa !34
  store i64 %t225, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t227 = load i64, ptr %l19, !tbaa !24
  %t228 = load i64, ptr %l18, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb28, label %bb29
bb28:
  %t233 = load i64, ptr %l20, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb33
bb30:
  %t237 = load i64, ptr %l19, !tbaa !24
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l20, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l20, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l140, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb32
bb32:
  %t253 = load i64, ptr %l140, !tbaa !24
  store i64 %t253, ptr %l137, !tbaa !24
  br label %bb33
bb33:
  %t254 = load i64, ptr %l137, !tbaa !24
  store i64 %t254, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb34
bb34:
  %t255 = load i64, ptr %l22, !tbaa !24
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  br label %bb37
bb37:
  %t263 = load i64, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l22, !tbaa !24
  %t265 = load i64, ptr %l20, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/mir:verifier", ptr %t273, i32 0, i32 17
  store ptr %t275, ptr %l159, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/mir:verifier", ptr %t276, i32 0, i32 12
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/mir:verifier", ptr %t279, i32 0, i32 10
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  store { i64, ptr } %t282, ptr %l163, !tbaa !27
  %t283 = load i64, ptr %l5, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i64, ptr %t286, i64 %t283
  %t288 = load i64, ptr %t287, !tbaa !34
  %t292 = add i64 %t288, %t271
  %t295 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t278, i64 %t292)
  store i32 %t295, ptr %l168
  br label %bb38
bb38:
  %t296 = load ptr, ptr %l159, !tbaa !29
  %t297 = load i32, ptr %l168, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t296, i32 %t297)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t298 = load i64, ptr %l22, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l22, !tbaa !24
  br label %bb34
bb41:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l5, !tbaa !24
  %t306 = getelementptr %"compiler/mir:verifier", ptr %t302, i32 0, i32 3
  store i64 %t303, ptr %t306, !tbaa !24
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = getelementptr %"compiler/mir:Fn", ptr %t307, i32 0, i32 9
  %t310 = load i64, ptr %l5, !tbaa !24
  %t311 = load ptr, ptr @__olang_prog_scope
  %t314 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t311, ptr %s0, ptr %t309, i64 %t310)
  store ptr %t314, ptr %l176
  br label %bb42
bb42:
  %t315 = load ptr, ptr %l176, !tbaa !29
  store ptr %t315, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  %t316 = load ptr, ptr %l24, !tbaa !29
  %t318 = getelementptr %"compiler/mir:BasicBlock", ptr %t316, i32 0, i32 0
  %t320 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %s0, ptr %t318)
  store i64 %t320, ptr %l179
  br label %bb43
bb43:
  %t321 = load i64, ptr %l179, !tbaa !24
  store i64 %t321, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t322 = load i64, ptr %l26, !tbaa !24
  %t323 = load i64, ptr %l25, !tbaa !24
  %t326 = icmp sgt i64 %t322, %t323
  br i1 %t326, label %bb44, label %bb45
bb44:
  %t328 = load i64, ptr %l27, !tbaa !24
  %t330 = icmp sgt i64 %t328, 0
  br i1 %t330, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb49
bb46:
  %t332 = load i64, ptr %l26, !tbaa !24
  %t333 = load i64, ptr %l25, !tbaa !24
  %t336 = sub i64 %t332, %t333
  %t337 = load i64, ptr %l27, !tbaa !24
  %t340 = add i64 %t336, %t337
  %t342 = sub i64 %t340, 1
  %t343 = load i64, ptr %l27, !tbaa !24
  %t346 = sdiv i64 %t342, %t343
  store i64 %t346, ptr %l186, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb48
bb48:
  %t348 = load i64, ptr %l186, !tbaa !24
  store i64 %t348, ptr %l183, !tbaa !24
  br label %bb49
bb49:
  %t349 = load i64, ptr %l183, !tbaa !24
  store i64 %t349, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t350 = load i64, ptr %l29, !tbaa !24
  %t351 = load i64, ptr %l28, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t358 = load i64, ptr %l25, !tbaa !24
  %t359 = load i64, ptr %l29, !tbaa !24
  %t360 = load i64, ptr %l27, !tbaa !24
  %t363 = mul i64 %t359, %t360
  %t366 = add i64 %t358, %t363
  store i64 %t366, ptr %l30, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i64, ptr %l30, !tbaa !24
  %t372 = getelementptr %"compiler/mir:verifier", ptr %t368, i32 0, i32 4
  store i64 %t369, ptr %t372, !tbaa !24
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l206, !tbaa !29
  %t374 = load ptr, ptr %l24, !tbaa !29
  %t376 = getelementptr %"compiler/mir:BasicBlock", ptr %t374, i32 0, i32 0
  %t377 = load i64, ptr %l30, !tbaa !24
  %t380 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %s0, ptr %t376, i64 %t377)
  store { i64, [21 x i64] } %t380, ptr %l210
  br label %bb54
bb54:
  %t381 = load { i64, [21 x i64] }, ptr %l210
  %t382 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t381, ptr %t382
  %t383 = load ptr, ptr %l206, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %s11, ptr %t383, ptr %t382)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb56:
  %t385 = load i64, ptr %l29, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l29, !tbaa !24
  br label %bb50
bb57:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/mir:verifier", ptr %t389, i32 0, i32 4
  store i64 -1, ptr %t391, !tbaa !24
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l24, !tbaa !29
  %t395 = getelementptr %"compiler/mir:BasicBlock", ptr %t393, i32 0, i32 1
  %t396 = load { i64, [8 x i64] }, ptr %t395
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %t392, { i64, [8 x i64] } %t396)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewithin(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l6 = alloca i1
  %l9 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp slt i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = add i64 %t15, %t19
  %t26 = icmp sgt i64 %t22, %a2
  store i1 %t26, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l9, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %a3, 1
  %t35 = extractvalue { i64, ptr } %a3, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  call void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebad(ptr %v0, ptr %s1, ptr %a0, { i64, ptr } %t51)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fmir_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_91402ead91eecd74_d65ac3d6c8116e0)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fmir_2ewritesInto(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [21 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca i32
  %l7 = alloca %"compiler/mir:Lvalue"
  %l8 = alloca { i64, [21 x i64] }
  %l14 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i64
  %l40 = alloca { i64, [21 x i64] }
  %l45 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [21 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l1, i64 176, i1 false)
  %t1 = load { i64, [21 x i64] }, ptr %l8
  %t2 = extractvalue { i64, [21 x i64] } %t1, 0
  %t3 = icmp eq i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t6 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t5, i32 0, i32 1
  %t7 = load %"compiler/mir:Lvalue", ptr %t6
  store %"compiler/mir:Lvalue" %t7, ptr %l3
  %t9 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t9, i32 0, i32 2
  %t11 = load { i64, [15 x i64] }, ptr %t10
  store { i64, [15 x i64] } %t11, ptr %l4
  br label %bb3
bb2:
  br label %bb28
bb3:
  %t13 = getelementptr %"compiler/mir:Lvalue", ptr %l3, i32 0, i32 1
  %t14 = getelementptr %"compiler/mir:Range", ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = icmp sgt i32 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load %"compiler/mir:Lvalue", ptr %l3
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t19, i32 %t20)
  store i1 %t23, ptr %l17
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load { i64, [15 x i64] }, ptr %l4
  %t29 = extractvalue { i64, [15 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 1
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t33 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/mir:Lvalue", ptr %t33
  store %"compiler/mir:Lvalue" %t34, ptr %l5
  %t36 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t37 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l6, !tbaa !23
  br label %bb15
bb12:
  %t40 = load { i64, [15 x i64] }, ptr %l4
  %t42 = extractvalue { i64, [15 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 9
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t46 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load %"compiler/mir:Lvalue", ptr %t46
  store %"compiler/mir:Lvalue" %t47, ptr %l5
  %t49 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t50 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t49, i32 0, i32 3
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t53 = load %"compiler/mir:Lvalue", ptr %l5
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t53, i32 %t54)
  store i1 %t57, ptr %l30
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb19
bb18:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i32, ptr %l35, !tbaa !23
  %t67 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t67, ptr %l36
  br label %bb20
bb20:
  %t68 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t69 = load i64, ptr %l36, !tbaa !24
  %t71 = and i64 %t69, %t68
  %t73 = icmp ne i64 %t71, 0
  store i1 %t73, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t75 = load i1, ptr %l31, !tbaa !21
  store i1 %t75, ptr %l19, !tbaa !21
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3eb640399bd8b02d_f3190a2cda9b9811)
  unreachable
bb27:
  %t76 = load i1, ptr %l19, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
bb28:
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l1, i64 176, i1 false)
  %t77 = load { i64, [21 x i64] }, ptr %l40
  %t78 = extractvalue { i64, [21 x i64] } %t77, 0
  %t79 = icmp eq i64 %t78, 9
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = getelementptr { i64, [21 x i64] }, ptr %l1, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t81, i32 0, i32 1
  %t83 = load %"compiler/mir:Lvalue", ptr %t82
  store %"compiler/mir:Lvalue" %t83, ptr %l7
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t85 = load %"compiler/mir:Lvalue", ptr %l7
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t85, i32 %t86)
  store i1 %t89, ptr %l45
  br label %bb32
bb32:
  %t90 = load i1, ptr %l45, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a9954f8fd49ad07c_7121af0b4200b780)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/mir:BasicBlock" @compiler_2fmir_3aBasicBlock_2ector(ptr %v0) #0 {
entry:
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/mir:BasicBlock"
  %t3 = alloca { i64, [8 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store { i64, [8 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [8 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [8 x i64] }, ptr %t3
  %t8 = insertvalue %"compiler/mir:BasicBlock" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, 0
  %t10 = insertvalue %"compiler/mir:BasicBlock" %t8, { i64, [8 x i64] } %t5, 1
  store %"compiler/mir:BasicBlock" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

define dso_local %"compiler/mir:Local" @compiler_2fmir_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %rv = alloca %"compiler/mir:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/mir:Local" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/mir:Local" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/mir:Local" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/mir:Local" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/mir:Local" %t18, { i64, [1 x i64] } %a4, 4
  store %"compiler/mir:Local" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Local", ptr %rv
  ret %"compiler/mir:Local" %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Lvalue"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Lvalue" undef, { i64, [2 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/mir:Lvalue" %t6, %"compiler/mir:Range" %a1, 1
  store %"compiler/mir:Lvalue" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local %"compiler/mir:Range" @compiler_2fmir_3aRange_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/mir:Range"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/mir:Range" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/mir:Range" %t6, i32 %a1, 1
  store %"compiler/mir:Range" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local %"compiler/mir:Task" @compiler_2fmir_3aTask_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5, %"compiler/source:Span" %a6, %"compiler/mir:Range" %a7) #0 {
entry:
  %rv = alloca %"compiler/mir:Task"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/mir:Task" undef, { i64, [7 x i64] } %a0, 0
  %t20 = insertvalue %"compiler/mir:Task" %t18, %"compiler/mir:Range" %a1, 1
  %t22 = insertvalue %"compiler/mir:Task" %t20, %"compiler/mir:Range" %a2, 2
  %t24 = insertvalue %"compiler/mir:Task" %t22, %"compiler/mir:Range" %a3, 3
  %t26 = insertvalue %"compiler/mir:Task" %t24, %"compiler/mir:Range" %a4, 4
  %t28 = insertvalue %"compiler/mir:Task" %t26, %"compiler/mir:Range" %a5, 5
  %t30 = insertvalue %"compiler/mir:Task" %t28, %"compiler/source:Span" %a6, 6
  %t32 = insertvalue %"compiler/mir:Task" %t30, %"compiler/mir:Range" %a7, 7
  store %"compiler/mir:Task" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Task", ptr %rv
  ret %"compiler/mir:Task" %rr
}

define dso_local %"compiler/mir:dumper" @compiler_2fmir_3adumper_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/mir:dumper"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l7
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = insertvalue %"compiler/mir:dumper" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = insertvalue %"compiler/mir:dumper" %t8, ptr %t9, 1
  %t12 = insertvalue %"compiler/mir:dumper" %t10, %"std/prelude/text:StringBuilder" %t6, 2
  store %"compiler/mir:dumper" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:dumper", ptr %rv
  ret %"compiler/mir:dumper" %rr
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" err L" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d17 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch#" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d20 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" + " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"live L" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"dead L" }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"open S" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"close S" }>, align 8
@.d33 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"register dtor " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d36 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"release " }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"settle L" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aWriteKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 8}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"copy " }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" from " }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d45 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"spawn in S" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raised" }>, align 8
@.d48 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"payload set " }>, align 8
@.d49 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"payload pop" }>, align 8
@.d50 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" cleanup bb" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" runs" }>, align 8
@.d52 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"deferred at S" }>, align 8
@.d53 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"(no terminator)" }>, align 8
@.d54 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"goto bb" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"branch " }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d57 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"] else bb" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
@.d66 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
@.d67 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" holding " }>, align 8
@.d68 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" failed L" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" bb" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"wait S" }>, align 8
@.d72 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" then bb" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 16}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
ret:
  ret void
}

@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d76 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"resume" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d78 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" made of " }>, align 8
@.d79 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d80 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"element " }>, align 8
@.d81 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no case " }>, align 8
@.d82 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" in a " }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d84 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" made of parts" }>, align 8
@.d85 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"a call of " }>, align 8
@.d86 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" arguments to a function of " }>, align 8
@.d87 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" parameters" }>, align 8
@.d88 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"argument " }>, align 8
@.d89 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a call passing " }>, align 8
@.d90 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" scopes for its callee's " }>, align 8
@.d91 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a call passing the frame for a scope variable" }>, align 8
@.d92 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn: " }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d94 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"[term]: " }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"bb" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d97 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"]: " }>, align 8
@.d98 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"no block bb" }>, align 8
@.d99 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a text builder that is none" }>, align 8
@.d100 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a function value typed " }>, align 8
@.d101 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"constant " }>, align 8
@.d102 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" holds constant " }>, align 8
@.d103 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", not made before it" }>, align 8
@.d104 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"no local L" }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d107 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array typed " }>, align 8
@.d108 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a run-time-length array" }>, align 8
@.d109 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a new array's length that is no integer" }>, align 8
@.d110 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a new array's fill" }>, align 8
@.d111 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"no constant " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 49}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 i64 43, label %bb45 i64 44, label %bb46 i64 45, label %bb47 i64 46, label %bb48 i64 47, label %bb49 i64 48, label %bb50 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
bb45:
  %t91 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t91, i64 %t92)
  br label %bb1
bb46:
  %t93 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t93, i64 %t94)
  br label %bb1
bb47:
  %t95 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t95, i64 %t96)
  br label %bb1
bb48:
  %t97 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t97, i64 %t98)
  br label %bb1
bb49:
  %t99 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t99, i64 %t100)
  br label %bb1
bb50:
  %t101 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t101, i64 %t102)
  br label %bb1
ret:
  ret void
}

@.d112 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"no overflow test for " }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d114 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" operands" }>, align 8
@.d115 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"an overflow test of " }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d117 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", not an integer" }>, align 8
@.d118 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d119 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"projections" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d122 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", but it is not open" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d125 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" while S" }>, align 8
@.d126 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", opened in it, is open" }>, align 8
define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

@.d127 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"unreachable: no path from the entry" }>, align 8
@.d128 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"no scope variable V" }>, align 8
@.d129 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a reference typed " }>, align 8
@.d130 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a reference " }>, align 8
@.d131 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" to a " }>, align 8
@.d132 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the region of a " }>, align 8
@.d133 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error code" }>, align 8
@.d134 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" typed " }>, align 8
@.d135 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" of a " }>, align 8
@.d136 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no blocks" }>, align 8
@.d137 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"its type is no function type" }>, align 8
@.d138 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"its type has " }>, align 8
@.d139 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" parameters, its Params " }>, align 8
@.d140 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d141 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" is local L" }>, align 8
@.d142 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", not a Param" }>, align 8
@.d143 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d144 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" is a " }>, align 8
@.d145 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", its type says " }>, align 8
@.d146 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"capture L" }>, align 8
@.d147 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is no Capture local" }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d149 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" has the Unknown type" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d151 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"'s parent S" }>, align 8
@.d152 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" is not opened before it" }>, align 8
@.d153 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a task's copies are not one per target" }>, align 8
@.d154 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"targets" }>, align 8
@.d155 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"clauses" }>, align 8
@.d156 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"items" }>, align 8
@.d157 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"bytes" }>, align 8
@.d158 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"constant items" }>, align 8
@.d159 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d160 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d163 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"S" }>, align 8
@.d165 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no task " }>, align 8
@.d166 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the value stored" }>, align 8
@.d167 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d168 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", not a reference to a " }>, align 8
@.d169 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a destructor registered for a " }>, align 8
@.d170 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", which has none to run" }>, align 8
@.d171 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a release of a " }>, align 8
@.d172 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", not a reference or an owner" }>, align 8
@.d173 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a settle of a " }>, align 8
@.d174 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", not an owner" }>, align 8
@.d175 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d176 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" write of a " }>, align 8
@.d177 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"elements copied between places that are not both arrays" }>, align 8
@.d178 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"elements copied between a " }>, align 8
@.d179 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" and a " }>, align 8
@.d180 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a count of copied elements that is no integer" }>, align 8
@.d181 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a spawn into S" }>, align 8
@.d182 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d183 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a task with " }>, align 8
@.d184 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" targets for " }>, align 8
@.d185 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" results" }>, align 8
@.d186 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"a task's clauses for a call that cannot fail" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d187 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a task's result " }>, align 8
@.d188 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no terminator" }>, align 8
@.d189 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"cases" }>, align 8
@.d190 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no call " }>, align 8
@.d191 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"scope refs" }>, align 8
@.d192 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a branch on a " }>, align 8
@.d193 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a switch on a " }>, align 8
@.d194 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a call with no result stores one" }>, align 8
@.d195 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the call's result" }>, align 8
@.d196 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a call that can fail with no error edge" }>, align 8
@.d197 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"an error edge for a call that cannot fail" }>, align 8
@.d198 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the call's error code" }>, align 8
@.d199 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a tail call with somewhere to go after it" }>, align 8
@.d200 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a tail call giving another result than the function's" }>, align 8
@.d201 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a return with no value from a function giving a " }>, align 8
@.d202 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"a return with a value from a function giving none" }>, align 8
@.d203 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"the value returned" }>, align 8
@.d204 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a suspend in a function that is no generator's" }>, align 8
@.d205 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the value yielded" }>, align 8
@.d206 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a raise in a function that cannot fail" }>, align 8
@.d207 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"the error raised" }>, align 8
@.d208 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a wait for S" }>, align 8
@.d209 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which is no join" }>, align 8
@.d210 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a wait for a join that can fail with no failed edge" }>, align 8
@.d211 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a failed edge for a join that cannot fail" }>, align 8
@.d212 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the join's error code" }>, align 8
@.d213 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a message for a " }>, align 8
@.d214 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" exit" }>, align 8
@.d215 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an assert's message that is no text" }>, align 8
@.d216 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"text typed " }>, align 8
@.d217 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d218 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" read before it is initialized on every path" }>, align 8
@.d219 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"a range of " }>, align 8
@.d220 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" out of bounds" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d222 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.WriteKind.Bytes" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d223 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.WriteKind.Quoted" }>, align 8
@.d224 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Char" }>, align 8
@.d225 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.WriteKind.QuotedChar" }>, align 8
@.d226 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.WriteKind.Int" }>, align 8
@.d227 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Uint" }>, align 8
@.d228 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.WriteKind.Float" }>, align 8
@.d229 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.WriteKind.Bool" }>, align 8
@.d230 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.ExitKind.Done" }>, align 8
@.d231 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.ExitKind.Fail" }>, align 8
@.d232 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ExitKind.Abort" }>, align 8
@.d233 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.Unreachable" }>, align 8
@.d234 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.NullReached" }>, align 8
@.d235 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.ExitKind.NullError" }>, align 8
@.d236 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.ExitKind.Unhandled" }>, align 8
@.d237 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.ExitKind.Assert" }>, align 8
@.d238 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.SliceBounds" }>, align 8
@.d239 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.ArrayLength" }>, align 8
@.d240 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"mir.ExitKind.As" }>, align 8
@.d241 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"mir.ExitKind.FixedLength" }>, align 8
@.d242 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"mir.ExitKind.LaneLength" }>, align 8
@.d243 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"mir.ExitKind.GenRunning" }>, align 8
@.d244 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mir.ExitKind.Error" }>, align 8
@.d245 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.ExitKind.Escaped" }>, align 8
@.d246 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Neg" }>, align 8
@.d247 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitNot" }>, align 8
@.d248 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Not" }>, align 8
@.d249 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Add" }>, align 8
@.d250 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Sub" }>, align 8
@.d251 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Mul" }>, align 8
@.d252 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Div" }>, align 8
@.d253 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Rem" }>, align 8
@.d254 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shl" }>, align 8
@.d255 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shr" }>, align 8
@.d256 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitAnd" }>, align 8
@.d257 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.BitOr" }>, align 8
@.d258 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitXor" }>, align 8
@.d259 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Eq" }>, align 8
@.d260 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ne" }>, align 8
@.d261 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Lt" }>, align 8
@.d262 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Le" }>, align 8
@.d263 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Gt" }>, align 8
@.d264 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ge" }>, align 8
@.d265 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Same" }>, align 8
@.d266 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Convert" }>, align 8
@.d267 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Bitcast" }>, align 8
@.d268 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Len" }>, align 8
@.d269 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.IsCase" }>, align 8
@.d270 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicLoad" }>, align 8
@.d271 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AtomicStore" }>, align 8
@.d272 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.AtomicAdd" }>, align 8
@.d273 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicSwap" }>, align 8
@.d274 = private unnamed_addr constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"typed.PrimOp.AtomicCompareSwap" }>, align 8
@.d275 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Retire" }>, align 8
@.d276 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Destroy" }>, align 8
@.d277 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Drop" }>, align 8
@.d278 = private unnamed_addr constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"typed.PrimOp.LeadingZeros" }>, align 8
@.d279 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.PrimOp.TrailingZeros" }>, align 8
@.d280 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.PopCount" }>, align 8
@.d281 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.RotateLeft" }>, align 8
@.d282 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.RotateRight" }>, align 8
@.d283 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ByteSwap" }>, align 8
@.d284 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.Holds" }>, align 8
@.d285 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.LaneLen" }>, align 8
@.d286 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.NonEmpty" }>, align 8
@.d287 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Unpack" }>, align 8
@.d288 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Repack" }>, align 8
@.d289 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.AnyMake" }>, align 8
@.d290 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AnyInstance" }>, align 8
@.d291 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.AnyIs" }>, align 8
@.d292 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.ErrPush" }>, align 8
@.d293 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.ErrCaught" }>, align 8
@.d294 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ErrTaken" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddLocal(ptr %v0, ptr %a0, %"compiler/mir:Local" %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_f3abe41a98405543_7d26227a2bded35f = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRefMu_Hfcf461293be5a40629d8d6a3cbc76320(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ePush_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, { i64, [21 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2ePush_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare %"compiler/mir:ScopeInfo" @compiler_2fmir_3aScopeInfo_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2ePush_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, %"compiler/mir:ScopeInfo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2ePush_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:BasicBlock" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eLen_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2ePush_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_3averifier_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eplace(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ekey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eoperand(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1)
@olang_loc_1b99bf8ee4d105f3_d9e42d16d8895267 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2econstItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_dca1ca4acf899191_a3a5645eac28d4dd = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2eref(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2etask(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Task" %a1)
@olang_loc_63d4bc85d5a0ee63_941776bd89ba250f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3adumper_2ecases(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b20d2ead933ce67_842549c98b36ec43 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2fmir_2ecompiler_2fmir_3averifier_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ewant(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eparts(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
@olang_loc_a40c0fc9d6bbeb91_41b07a29ba18aefd = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2epointerLike(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c289c76542078e7_53d9d4aa9af07973 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_62f33ceaa6d0d243_a40627fd170062cf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f7be8aa76db69854_ffaa205b85e46cd8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eLen_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0)
@olang_loc_293fa35c34966465_23dfef653c6d5c71 = external constant [0 x i8]
@olang_loc_2eacfb98574d9c7d_9d1d6c478850d6e9 = external constant [0 x i8]
@olang_loc_bb9dfa8ddf3d51d3_a6a63b61a4411c97 = external constant [0 x i8]
@olang_loc_70d66502dd431e07_8b33d36aabf56353 = external constant [0 x i8]
@olang_loc_2986d82de8391aaf_d61db5ce8081183b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprojected(ptr %v0, ptr %a0, i32 %a1, { i64, [1 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eopen(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
@olang_loc_525ae97147cf6b9b_c46e40fbd793c77f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_1ab0dfa533b17ebc_4a4130204b0a3608 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePop_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_21ecf2a36b4d7692_5e1d5f90bd4192b6 = external constant [0 x i8]
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7127dab5ce57c749_b077692428e4994d = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82c1dfc51032d1af_585fe42c43fa9d8b = external constant [0 x i8]
@olang_loc_d0fb5c63af130ee_9fb6b0b43bcc334a = external constant [0 x i8]
@olang_loc_a5f83820f05cb9f9_5f257facca4b96a5 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2escope(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
@olang_loc_6be72733009cb689_7eadbfb9b429b955 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3averifier_2efits(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eflow(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ebuildsIn(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eusesScope(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_238ad76e6aec07bb_c5e46c61d4e3452f = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eprimType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2etagType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2esliceType(ptr %v0, ptr %a0, i32 %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2eintOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3d9554dfcf1aeb63_1386be72809b2127 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsSpread(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecallee(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2eops(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2erefs(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eLen_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eLen_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eLen_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eLen_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0)
@olang_loc_729af306d1a375bd_3b9d78bce782a851 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
@olang_loc_bce7b6ebde80be8c_35c7d20ece1a3fc0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ervalueShape(ptr %v0, ptr %a0, { i64, [15 x i64] } %a1)
@olang_loc_145fd452f8e36c9b_ff9c6902187c9987 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_299ef5e2a9c9a69f_7fc69ac68ccb4c23 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecalleeType(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13ff54b5c1d3c1e_cc5c8d48f26f2b22 = external constant [0 x i8]
@olang_loc_49b1b3021a029ae3_d2d6f71dc554b2d7 = external constant [0 x i8]
@olang_loc_4f65b4158cb36c84_7aab915b507980 = external constant [0 x i8]
@olang_loc_4fdb0c87eb50ced7_f9856407ece22343 = external constant [0 x i8]
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2ecasesOnce(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_37d613313db5ccb3_d9dd3d9ece558aa7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eClear_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2estmtFlow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3averifier_2etermFlow(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_91402ead91eecd74_d65ac3d6c8116e0 = external constant [0 x i8]
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %a0, i32 %a1)
@olang_loc_3eb640399bd8b02d_f3190a2cda9b9811 = external constant [0 x i8]
@olang_loc_a9954f8fd49ad07c_7121af0b4200b780 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
