; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4da891c857fa9a42_b9a25b213f22c276 = weak_odr constant [53 x i8] c"compiler/facts.olang:113: slice bounds out of range\0A\00"
@olang_loc_71967feed0a55bbd_8c46b469ed0132b9 = weak_odr constant [52 x i8] c"compiler/facts.olang:90: slice bounds out of range\0A\00"
@olang_loc_8ed5d3ba35d14a58_c4d17542e0ab7bdc = weak_odr constant [53 x i8] c"compiler/facts.olang:123: slice bounds out of range\0A\00"
@olang_loc_e390912e6a1bdc3f_6a056665eef072d3 = weak_odr constant [53 x i8] c"compiler/facts.olang:112: slice bounds out of range\0A\00"
@olang_loc_ed9b7f5b14b4ab41_cd157c649d3eec55 = weak_odr constant [53 x i8] c"compiler/facts.olang:115: slice bounds out of range\0A\00"
@olang_loc_fb92b303a6a491ca_28d0443004aa12f6 = weak_odr constant [52 x i8] c"compiler/facts.olang:73: slice bounds out of range\0A\00"
