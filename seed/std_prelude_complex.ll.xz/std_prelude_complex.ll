; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/complex:C16" = type { half, half }
%"std/prelude/complex:C32" = type { float, float }
%"std/prelude/complex:C64" = type { double, double }
define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eConj(%"std/prelude/complex:C16" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l4 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t4 = load half, ptr %t3, !tbaa !66
  %t6 = fneg half %t4
  %t9 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t2, half %t6)
  store %"std/prelude/complex:C16" %t9, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"std/prelude/complex:C16", ptr %l4
  store %"std/prelude/complex:C16" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eDiv(%"std/prelude/complex:C16" %a0, %"std/prelude/complex:C16" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l1 = alloca %"std/prelude/complex:C16"
  %l2 = alloca double
  %l3 = alloca double
  %l4 = alloca double
  %l5 = alloca double
  %l6 = alloca double
  %l42 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  store %"std/prelude/complex:C16" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t4 = fpext half %t2 to double
  store double %t4, ptr %l2, !tbaa !26
  %t6 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t7 = load half, ptr %t6, !tbaa !66
  %t9 = fpext half %t7 to double
  store double %t9, ptr %l3, !tbaa !26
  %t11 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 0
  %t12 = load half, ptr %t11, !tbaa !66
  %t14 = fpext half %t12 to double
  store double %t14, ptr %l4, !tbaa !26
  %t16 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 1
  %t17 = load half, ptr %t16, !tbaa !66
  %t19 = fpext half %t17 to double
  store double %t19, ptr %l5, !tbaa !26
  %t21 = load double, ptr %l4, !tbaa !26
  %t22 = load double, ptr %l4, !tbaa !26
  %t25 = fmul double %t21, %t22
  %t26 = load double, ptr %l5, !tbaa !26
  %t27 = load double, ptr %l5, !tbaa !26
  %t30 = fmul double %t26, %t27
  %t33 = fadd double %t25, %t30
  store double %t33, ptr %l6, !tbaa !26
  %t35 = load double, ptr %l2, !tbaa !26
  %t36 = load double, ptr %l4, !tbaa !26
  %t39 = fmul double %t35, %t36
  %t40 = load double, ptr %l3, !tbaa !26
  %t41 = load double, ptr %l5, !tbaa !26
  %t44 = fmul double %t40, %t41
  %t47 = fadd double %t39, %t44
  %t48 = load double, ptr %l6, !tbaa !26
  %t51 = fdiv double %t47, %t48
  %t53 = fptrunc double %t51 to half
  %t54 = load double, ptr %l3, !tbaa !26
  %t55 = load double, ptr %l4, !tbaa !26
  %t58 = fmul double %t54, %t55
  %t59 = load double, ptr %l2, !tbaa !26
  %t60 = load double, ptr %l5, !tbaa !26
  %t63 = fmul double %t59, %t60
  %t66 = fsub double %t58, %t63
  %t67 = load double, ptr %l6, !tbaa !26
  %t70 = fdiv double %t66, %t67
  %t72 = fptrunc double %t70 to half
  %t75 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t53, half %t72)
  store %"std/prelude/complex:C16" %t75, ptr %l42
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load %"std/prelude/complex:C16", ptr %l42
  store %"std/prelude/complex:C16" %t76, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eMinus(%"std/prelude/complex:C16" %a0, %"std/prelude/complex:C16" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l1 = alloca %"std/prelude/complex:C16"
  %l8 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  store %"std/prelude/complex:C16" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 0
  %t4 = load half, ptr %t3, !tbaa !66
  %t7 = fsub half %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t9 = load half, ptr %t8, !tbaa !66
  %t10 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 1
  %t11 = load half, ptr %t10, !tbaa !66
  %t14 = fsub half %t9, %t11
  %t17 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t7, half %t14)
  store %"std/prelude/complex:C16" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C16", ptr %l8
  store %"std/prelude/complex:C16" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eMul(%"std/prelude/complex:C16" %a0, %"std/prelude/complex:C16" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l1 = alloca %"std/prelude/complex:C16"
  %l16 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  store %"std/prelude/complex:C16" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 0
  %t4 = load half, ptr %t3, !tbaa !66
  %t7 = fmul half %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t9 = load half, ptr %t8, !tbaa !66
  %t10 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 1
  %t11 = load half, ptr %t10, !tbaa !66
  %t14 = fmul half %t9, %t11
  %t17 = fsub half %t7, %t14
  %t18 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t19 = load half, ptr %t18, !tbaa !66
  %t20 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 1
  %t21 = load half, ptr %t20, !tbaa !66
  %t24 = fmul half %t19, %t21
  %t25 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t26 = load half, ptr %t25, !tbaa !66
  %t27 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 0
  %t28 = load half, ptr %t27, !tbaa !66
  %t31 = fmul half %t26, %t28
  %t34 = fadd half %t24, %t31
  %t37 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t17, half %t34)
  store %"std/prelude/complex:C16" %t37, ptr %l16
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load %"std/prelude/complex:C16", ptr %l16
  store %"std/prelude/complex:C16" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eNeg(%"std/prelude/complex:C16" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l5 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t4 = fneg half %t2
  %t5 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t6 = load half, ptr %t5, !tbaa !66
  %t8 = fneg half %t6
  %t11 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t4, half %t8)
  store %"std/prelude/complex:C16" %t11, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/prelude/complex:C16", ptr %l5
  store %"std/prelude/complex:C16" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local half @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eNorm(%"std/prelude/complex:C16" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %rv = alloca half
  store %"std/prelude/complex:C16" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t4 = load half, ptr %t3, !tbaa !66
  %t7 = fmul half %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t9 = load half, ptr %t8, !tbaa !66
  %t10 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t11 = load half, ptr %t10, !tbaa !66
  %t14 = fmul half %t9, %t11
  %t17 = fadd half %t7, %t14
  store half %t17, ptr %rv
  br label %ret
ret:
  %rr = load half, ptr %rv
  ret half %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2ePlus(%"std/prelude/complex:C16" %a0, %"std/prelude/complex:C16" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l1 = alloca %"std/prelude/complex:C16"
  %l8 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  store %"std/prelude/complex:C16" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 0
  %t4 = load half, ptr %t3, !tbaa !66
  %t7 = fadd half %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t9 = load half, ptr %t8, !tbaa !66
  %t10 = getelementptr %"std/prelude/complex:C16", ptr %l1, i32 0, i32 1
  %t11 = load half, ptr %t10, !tbaa !66
  %t14 = fadd half %t9, %t11
  %t17 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t7, half %t14)
  store %"std/prelude/complex:C16" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C16", ptr %l8
  store %"std/prelude/complex:C16" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC16_2eScale(%"std/prelude/complex:C16" %a0, half %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C16"
  %l1 = alloca half
  %l8 = alloca %"std/prelude/complex:C16"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C16"
  store %"std/prelude/complex:C16" %a0, ptr %l0
  store half %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 0
  %t2 = load half, ptr %t1, !tbaa !66
  %t3 = load half, ptr %l1, !tbaa !66
  %t6 = fmul half %t2, %t3
  %t7 = getelementptr %"std/prelude/complex:C16", ptr %l0, i32 0, i32 1
  %t8 = load half, ptr %t7, !tbaa !66
  %t9 = load half, ptr %l1, !tbaa !66
  %t12 = fmul half %t8, %t9
  %t15 = call %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %s0, half %t6, half %t12)
  store %"std/prelude/complex:C16" %t15, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"std/prelude/complex:C16", ptr %l8
  store %"std/prelude/complex:C16" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eConj(%"std/prelude/complex:C32" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l4 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t4 = load float, ptr %t3, !tbaa !25
  %t6 = fneg float %t4
  %t9 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t2, float %t6)
  store %"std/prelude/complex:C32" %t9, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"std/prelude/complex:C32", ptr %l4
  store %"std/prelude/complex:C32" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eDiv(%"std/prelude/complex:C32" %a0, %"std/prelude/complex:C32" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l1 = alloca %"std/prelude/complex:C32"
  %l2 = alloca double
  %l3 = alloca double
  %l4 = alloca double
  %l5 = alloca double
  %l6 = alloca double
  %l42 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  store %"std/prelude/complex:C32" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t4 = fpext float %t2 to double
  store double %t4, ptr %l2, !tbaa !26
  %t6 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t7 = load float, ptr %t6, !tbaa !25
  %t9 = fpext float %t7 to double
  store double %t9, ptr %l3, !tbaa !26
  %t11 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 0
  %t12 = load float, ptr %t11, !tbaa !25
  %t14 = fpext float %t12 to double
  store double %t14, ptr %l4, !tbaa !26
  %t16 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 1
  %t17 = load float, ptr %t16, !tbaa !25
  %t19 = fpext float %t17 to double
  store double %t19, ptr %l5, !tbaa !26
  %t21 = load double, ptr %l4, !tbaa !26
  %t22 = load double, ptr %l4, !tbaa !26
  %t25 = fmul double %t21, %t22
  %t26 = load double, ptr %l5, !tbaa !26
  %t27 = load double, ptr %l5, !tbaa !26
  %t30 = fmul double %t26, %t27
  %t33 = fadd double %t25, %t30
  store double %t33, ptr %l6, !tbaa !26
  %t35 = load double, ptr %l2, !tbaa !26
  %t36 = load double, ptr %l4, !tbaa !26
  %t39 = fmul double %t35, %t36
  %t40 = load double, ptr %l3, !tbaa !26
  %t41 = load double, ptr %l5, !tbaa !26
  %t44 = fmul double %t40, %t41
  %t47 = fadd double %t39, %t44
  %t48 = load double, ptr %l6, !tbaa !26
  %t51 = fdiv double %t47, %t48
  %t53 = fptrunc double %t51 to float
  %t54 = load double, ptr %l3, !tbaa !26
  %t55 = load double, ptr %l4, !tbaa !26
  %t58 = fmul double %t54, %t55
  %t59 = load double, ptr %l2, !tbaa !26
  %t60 = load double, ptr %l5, !tbaa !26
  %t63 = fmul double %t59, %t60
  %t66 = fsub double %t58, %t63
  %t67 = load double, ptr %l6, !tbaa !26
  %t70 = fdiv double %t66, %t67
  %t72 = fptrunc double %t70 to float
  %t75 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t53, float %t72)
  store %"std/prelude/complex:C32" %t75, ptr %l42
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load %"std/prelude/complex:C32", ptr %l42
  store %"std/prelude/complex:C32" %t76, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eMinus(%"std/prelude/complex:C32" %a0, %"std/prelude/complex:C32" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l1 = alloca %"std/prelude/complex:C32"
  %l8 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  store %"std/prelude/complex:C32" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 0
  %t4 = load float, ptr %t3, !tbaa !25
  %t7 = fsub float %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t9 = load float, ptr %t8, !tbaa !25
  %t10 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 1
  %t11 = load float, ptr %t10, !tbaa !25
  %t14 = fsub float %t9, %t11
  %t17 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t7, float %t14)
  store %"std/prelude/complex:C32" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C32", ptr %l8
  store %"std/prelude/complex:C32" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eMul(%"std/prelude/complex:C32" %a0, %"std/prelude/complex:C32" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l1 = alloca %"std/prelude/complex:C32"
  %l16 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  store %"std/prelude/complex:C32" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 0
  %t4 = load float, ptr %t3, !tbaa !25
  %t7 = fmul float %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t9 = load float, ptr %t8, !tbaa !25
  %t10 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 1
  %t11 = load float, ptr %t10, !tbaa !25
  %t14 = fmul float %t9, %t11
  %t17 = fsub float %t7, %t14
  %t18 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t19 = load float, ptr %t18, !tbaa !25
  %t20 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 1
  %t21 = load float, ptr %t20, !tbaa !25
  %t24 = fmul float %t19, %t21
  %t25 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t26 = load float, ptr %t25, !tbaa !25
  %t27 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 0
  %t28 = load float, ptr %t27, !tbaa !25
  %t31 = fmul float %t26, %t28
  %t34 = fadd float %t24, %t31
  %t37 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t17, float %t34)
  store %"std/prelude/complex:C32" %t37, ptr %l16
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load %"std/prelude/complex:C32", ptr %l16
  store %"std/prelude/complex:C32" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eNeg(%"std/prelude/complex:C32" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l5 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t4 = fneg float %t2
  %t5 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t6 = load float, ptr %t5, !tbaa !25
  %t8 = fneg float %t6
  %t11 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t4, float %t8)
  store %"std/prelude/complex:C32" %t11, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/prelude/complex:C32", ptr %l5
  store %"std/prelude/complex:C32" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local float @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eNorm(%"std/prelude/complex:C32" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %rv = alloca float
  store %"std/prelude/complex:C32" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t4 = load float, ptr %t3, !tbaa !25
  %t7 = fmul float %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t9 = load float, ptr %t8, !tbaa !25
  %t10 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t11 = load float, ptr %t10, !tbaa !25
  %t14 = fmul float %t9, %t11
  %t17 = fadd float %t7, %t14
  store float %t17, ptr %rv
  br label %ret
ret:
  %rr = load float, ptr %rv
  ret float %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2ePlus(%"std/prelude/complex:C32" %a0, %"std/prelude/complex:C32" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l1 = alloca %"std/prelude/complex:C32"
  %l8 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  store %"std/prelude/complex:C32" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 0
  %t4 = load float, ptr %t3, !tbaa !25
  %t7 = fadd float %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t9 = load float, ptr %t8, !tbaa !25
  %t10 = getelementptr %"std/prelude/complex:C32", ptr %l1, i32 0, i32 1
  %t11 = load float, ptr %t10, !tbaa !25
  %t14 = fadd float %t9, %t11
  %t17 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t7, float %t14)
  store %"std/prelude/complex:C32" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C32", ptr %l8
  store %"std/prelude/complex:C32" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC32_2eScale(%"std/prelude/complex:C32" %a0, float %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C32"
  %l1 = alloca float
  %l8 = alloca %"std/prelude/complex:C32"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C32"
  store %"std/prelude/complex:C32" %a0, ptr %l0
  store float %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 0
  %t2 = load float, ptr %t1, !tbaa !25
  %t3 = load float, ptr %l1, !tbaa !25
  %t6 = fmul float %t2, %t3
  %t7 = getelementptr %"std/prelude/complex:C32", ptr %l0, i32 0, i32 1
  %t8 = load float, ptr %t7, !tbaa !25
  %t9 = load float, ptr %l1, !tbaa !25
  %t12 = fmul float %t8, %t9
  %t15 = call %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %s0, float %t6, float %t12)
  store %"std/prelude/complex:C32" %t15, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"std/prelude/complex:C32", ptr %l8
  store %"std/prelude/complex:C32" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eConj(%"std/prelude/complex:C64" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l4 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t4 = load double, ptr %t3, !tbaa !26
  %t6 = fneg double %t4
  %t9 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t2, double %t6)
  store %"std/prelude/complex:C64" %t9, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"std/prelude/complex:C64", ptr %l4
  store %"std/prelude/complex:C64" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eMinus(%"std/prelude/complex:C64" %a0, %"std/prelude/complex:C64" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l1 = alloca %"std/prelude/complex:C64"
  %l8 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  store %"std/prelude/complex:C64" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 0
  %t4 = load double, ptr %t3, !tbaa !26
  %t7 = fsub double %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t9 = load double, ptr %t8, !tbaa !26
  %t10 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 1
  %t11 = load double, ptr %t10, !tbaa !26
  %t14 = fsub double %t9, %t11
  %t17 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t7, double %t14)
  store %"std/prelude/complex:C64" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C64", ptr %l8
  store %"std/prelude/complex:C64" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eMul(%"std/prelude/complex:C64" %a0, %"std/prelude/complex:C64" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l1 = alloca %"std/prelude/complex:C64"
  %l16 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  store %"std/prelude/complex:C64" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 0
  %t4 = load double, ptr %t3, !tbaa !26
  %t7 = fmul double %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t9 = load double, ptr %t8, !tbaa !26
  %t10 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 1
  %t11 = load double, ptr %t10, !tbaa !26
  %t14 = fmul double %t9, %t11
  %t17 = fsub double %t7, %t14
  %t18 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t19 = load double, ptr %t18, !tbaa !26
  %t20 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 1
  %t21 = load double, ptr %t20, !tbaa !26
  %t24 = fmul double %t19, %t21
  %t25 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t26 = load double, ptr %t25, !tbaa !26
  %t27 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 0
  %t28 = load double, ptr %t27, !tbaa !26
  %t31 = fmul double %t26, %t28
  %t34 = fadd double %t24, %t31
  %t37 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t17, double %t34)
  store %"std/prelude/complex:C64" %t37, ptr %l16
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load %"std/prelude/complex:C64", ptr %l16
  store %"std/prelude/complex:C64" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eNeg(%"std/prelude/complex:C64" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l5 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t4 = fneg double %t2
  %t5 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t6 = load double, ptr %t5, !tbaa !26
  %t8 = fneg double %t6
  %t11 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t4, double %t8)
  store %"std/prelude/complex:C64" %t11, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/prelude/complex:C64", ptr %l5
  store %"std/prelude/complex:C64" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local double @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eNorm(%"std/prelude/complex:C64" %a0) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %rv = alloca double
  store %"std/prelude/complex:C64" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t4 = load double, ptr %t3, !tbaa !26
  %t7 = fmul double %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t9 = load double, ptr %t8, !tbaa !26
  %t10 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t11 = load double, ptr %t10, !tbaa !26
  %t14 = fmul double %t9, %t11
  %t17 = fadd double %t7, %t14
  store double %t17, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2ePlus(%"std/prelude/complex:C64" %a0, %"std/prelude/complex:C64" %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l1 = alloca %"std/prelude/complex:C64"
  %l8 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  store %"std/prelude/complex:C64" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 0
  %t4 = load double, ptr %t3, !tbaa !26
  %t7 = fadd double %t2, %t4
  %t8 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t9 = load double, ptr %t8, !tbaa !26
  %t10 = getelementptr %"std/prelude/complex:C64", ptr %l1, i32 0, i32 1
  %t11 = load double, ptr %t10, !tbaa !26
  %t14 = fadd double %t9, %t11
  %t17 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t7, double %t14)
  store %"std/prelude/complex:C64" %t17, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/complex:C64", ptr %l8
  store %"std/prelude/complex:C64" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_2estd_2fprelude_2fcomplex_3aC64_2eScale(%"std/prelude/complex:C64" %a0, double %a1) #0 {
entry:
  %l0 = alloca %"std/prelude/complex:C64"
  %l1 = alloca double
  %l8 = alloca %"std/prelude/complex:C64"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/complex:C64"
  store %"std/prelude/complex:C64" %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 0
  %t2 = load double, ptr %t1, !tbaa !26
  %t3 = load double, ptr %l1, !tbaa !26
  %t6 = fmul double %t2, %t3
  %t7 = getelementptr %"std/prelude/complex:C64", ptr %l0, i32 0, i32 1
  %t8 = load double, ptr %t7, !tbaa !26
  %t9 = load double, ptr %l1, !tbaa !26
  %t12 = fmul double %t8, %t9
  %t15 = call %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %s0, double %t6, double %t12)
  store %"std/prelude/complex:C64" %t15, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"std/prelude/complex:C64", ptr %l8
  store %"std/prelude/complex:C64" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define dso_local %"std/prelude/complex:C16" @std_2fprelude_2fcomplex_3aC16_2ector(ptr %v0, half %a0, half %a1) #0 {
entry:
  %rv = alloca %"std/prelude/complex:C16"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/complex:C16" undef, half %a0, 0
  %t8 = insertvalue %"std/prelude/complex:C16" %t6, half %a1, 1
  store %"std/prelude/complex:C16" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C16", ptr %rv
  ret %"std/prelude/complex:C16" %rr
}

define dso_local %"std/prelude/complex:C32" @std_2fprelude_2fcomplex_3aC32_2ector(ptr %v0, float %a0, float %a1) #0 {
entry:
  %rv = alloca %"std/prelude/complex:C32"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/complex:C32" undef, float %a0, 0
  %t8 = insertvalue %"std/prelude/complex:C32" %t6, float %a1, 1
  store %"std/prelude/complex:C32" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C32", ptr %rv
  ret %"std/prelude/complex:C32" %rr
}

define dso_local %"std/prelude/complex:C64" @std_2fprelude_2fcomplex_3aC64_2ector(ptr %v0, double %a0, double %a1) #0 {
entry:
  %rv = alloca %"std/prelude/complex:C64"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/complex:C64" undef, double %a0, 0
  %t8 = insertvalue %"std/prelude/complex:C64" %t6, double %a1, 1
  store %"std/prelude/complex:C64" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/complex:C64", ptr %rv
  ret %"std/prelude/complex:C64" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
