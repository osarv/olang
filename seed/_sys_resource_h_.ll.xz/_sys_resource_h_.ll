; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"<sys/resource.h>:rusage" = type { %"<time.h>:timeval", %"<time.h>:timeval", [14 x i64] }
%"<time.h>:timeval" = type { i64, i64 }
%"<sys/resource.h>:rlimit64" = type { i64, i64 }
%"<sys/resource.h>:rlimit" = type { i64, i64 }
@G_2e_3csys_2fresource_2eh_3e_2ePRIO__MAX = constant <{ [4 x i8] }> <{ [4 x i8] c"\14\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2ePRIO__MIN = constant <{ [4 x i8] }> <{ [4 x i8] c"\EC\FF\FF\FF" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2ePRIO__PGRP = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2ePRIO__PROCESS = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2ePRIO__USER = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__AS = constant <{ [4 x i8] }> <{ [4 x i8] c"\09\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__CORE = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__CPU = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__DATA = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__FSIZE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__LOCKS = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__MEMLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__MSGQUEUE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0C\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__NICE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0D\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__NLIMITS = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__NOFILE = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__NPROC = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__OFILE = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__RSS = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__RTPRIO = constant <{ [4 x i8] }> <{ [4 x i8] c"\0E\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__RTTIME = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__SIGPENDING = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__STACK = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRLIM__NLIMITS = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRUSAGE__CHILDREN = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRUSAGE__LWP = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRUSAGE__SELF = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fresource_2eh_3e_2eRUSAGE__THREAD = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__idrss(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 2
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__inblock(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 7
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__isrss(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 3
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__ixrss(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 1
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__majflt(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 5
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__maxrss(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 0
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__minflt(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 4
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__msgrcv(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 10
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__msgsnd(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 9
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__nivcsw(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 13
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__nsignals(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 11
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__nswap(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 6
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__nvcsw(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 12
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eru__oublock(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t4 = getelementptr [14 x i64], ptr %t3, i64 0, i64 8
  %t5 = load i64, ptr %t4, !tbaa !34
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__idrss(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 2
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__inblock(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 7
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__isrss(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 3
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__ixrss(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 1
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__majflt(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 5
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__maxrss(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 0
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__minflt(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 4
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__msgrcv(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 10
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__msgsnd(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 9
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__nivcsw(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 13
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__nsignals(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 11
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__nswap(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 6
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__nvcsw(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 12
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fresource_2eh_3e_2e_3csys_2fresource_2eh_3e_3arusage_2eset__ru__oublock(ptr %v0, ptr noalias dereferenceable(144) align 8 %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t9 = getelementptr %"<sys/resource.h>:rusage", ptr %a0, i32 0, i32 2
  %t10 = getelementptr [14 x i64], ptr %t9, i64 0, i64 8
  store i64 %a1, ptr %t10, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local %"<sys/resource.h>:rlimit64" @_3csys_2fresource_2eh_3e_3arlimit64_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<sys/resource.h>:rlimit64"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<sys/resource.h>:rlimit64" undef, i64 0, 0
  %t4 = insertvalue %"<sys/resource.h>:rlimit64" %t2, i64 0, 1
  store %"<sys/resource.h>:rlimit64" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<sys/resource.h>:rlimit64", ptr %rv
  ret %"<sys/resource.h>:rlimit64" %rr
}

define dso_local %"<sys/resource.h>:rlimit" @_3csys_2fresource_2eh_3e_3arlimit_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<sys/resource.h>:rlimit"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<sys/resource.h>:rlimit" undef, i64 0, 0
  %t4 = insertvalue %"<sys/resource.h>:rlimit" %t2, i64 0, 1
  store %"<sys/resource.h>:rlimit" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<sys/resource.h>:rlimit", ptr %rv
  ret %"<sys/resource.h>:rlimit" %rr
}

define dso_local void @_3csys_2fresource_2eh_3e_3arusage_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"<time.h>:timeval"
  %l3 = alloca %"<time.h>:timeval"
  %l4 = alloca %"<time.h>:timeval"
  %l6 = alloca %"<sys/resource.h>:rusage"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"<time.h>:timeval" @olang_2emir_2eHelperKind_2eZero_2e_3ctime_2eh_3e_3atimeval()
  store %"<time.h>:timeval" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"<time.h>:timeval", ptr %l3
  store %"<time.h>:timeval" %t2, ptr %l0
  %t3 = call %"<time.h>:timeval" @olang_2emir_2eHelperKind_2eZero_2e_3ctime_2eh_3e_3atimeval()
  store %"<time.h>:timeval" %t3, ptr %l4
  br label %bb2
bb2:
  %t4 = load %"<time.h>:timeval", ptr %l4
  %t5 = insertvalue [14 x i64] undef, i64 0, 0
  %t6 = insertvalue [14 x i64] %t5, i64 0, 1
  %t7 = insertvalue [14 x i64] %t6, i64 0, 2
  %t8 = insertvalue [14 x i64] %t7, i64 0, 3
  %t9 = insertvalue [14 x i64] %t8, i64 0, 4
  %t10 = insertvalue [14 x i64] %t9, i64 0, 5
  %t11 = insertvalue [14 x i64] %t10, i64 0, 6
  %t12 = insertvalue [14 x i64] %t11, i64 0, 7
  %t13 = insertvalue [14 x i64] %t12, i64 0, 8
  %t14 = insertvalue [14 x i64] %t13, i64 0, 9
  %t15 = insertvalue [14 x i64] %t14, i64 0, 10
  %t16 = insertvalue [14 x i64] %t15, i64 0, 11
  %t17 = insertvalue [14 x i64] %t16, i64 0, 12
  %t18 = insertvalue [14 x i64] %t17, i64 0, 13
  %t20 = getelementptr %"<sys/resource.h>:rusage", ptr %l6, i32 0, i32 0
  %t21 = load %"<time.h>:timeval", ptr %l0
  store %"<time.h>:timeval" %t21, ptr %t20
  %t22 = getelementptr %"<sys/resource.h>:rusage", ptr %l6, i32 0, i32 1
  store %"<time.h>:timeval" %t4, ptr %t22
  %t24 = getelementptr %"<sys/resource.h>:rusage", ptr %l6, i32 0, i32 2
  store [14 x i64] %t18, ptr %t24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"<time.h>:timeval" @olang_2emir_2eHelperKind_2eZero_2e_3ctime_2eh_3e_3atimeval() #0 {
entry:
  %l0 = alloca %"<time.h>:timeval"
  %rv = alloca %"<time.h>:timeval"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<time.h>:timeval" @_3ctime_2eh_3e_3atimeval_2ector(ptr %t1)
  store %"<time.h>:timeval" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<time.h>:timeval", ptr %l0
  store %"<time.h>:timeval" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<time.h>:timeval", ptr %rv
  ret %"<time.h>:timeval" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare %"<time.h>:timeval" @_3ctime_2eh_3e_3atimeval_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
