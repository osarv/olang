; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/doc:Example" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
define dso_local { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l100 = alloca i64
  %l102 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/text:StringBuilder"
  %l119 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l134 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t3, i64 %a1)
  store i64 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t21 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t15, i64 %t18)
  store i64 %t21, ptr %l22
  br label %bb7
bb7:
  %t22 = load i64, ptr %l22, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l23, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l26, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb10:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb12:
  %t41 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l26, !tbaa !24
  %t45 = getelementptr i8, ptr %t42, i64 %t43
  %t46 = sub i64 %t44, %t43
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t50)
  store i1 %t52, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_39c265aa723c0dcb_f35d02a7366497b7)
  unreachable
bb14:
  %t53 = load i1, ptr %l33, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s1, { i64, ptr } %t60, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t62, ptr %l39
  br label %bb20
bb19:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t65 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t65)
  br label %bb25
bb25:
  %t68 = load i64, ptr %l4, !tbaa !24
  store i64 %t68, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  br label %bb3
bb27:
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t71, ptr %l44
  br label %bb28
bb28:
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = icmp eq i64 %t72, 0
  br i1 %t73, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t75, ptr %l47, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l49, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t89, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t92, ptr %l51
  br label %bb32
bb32:
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = sub i64 %t93, 1
  store i64 %t94, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l55, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t102 = load i64, ptr %l3, !tbaa !24
  %t104 = sub i64 %t102, 1
  %t107 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t101, i64 %t104)
  store i64 %t107, ptr %l59
  br label %bb35
bb34:
  br label %bb75
bb35:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = sub i64 %t108, 1
  store i64 %t110, ptr %l61, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l62, !tbaa !24
  %t113 = load i64, ptr %l59, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t116 = load i64, ptr %l59, !tbaa !24
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb38:
  %t120 = load i64, ptr %l61, !tbaa !24
  %t121 = load i64, ptr %l62, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb40:
  %t124 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l59, !tbaa !24
  %t127 = load i64, ptr %l61, !tbaa !24
  %t128 = getelementptr i8, ptr %t125, i64 %t126
  %t129 = sub i64 %t127, %t126
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  store { i64, ptr } %t131, ptr %l7, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t135 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t133)
  store i64 %t135, ptr %l68
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_19c80d7aab96fce_b433fa540154765a)
  unreachable
bb42:
  %t136 = load i64, ptr %l68, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t141, ptr %l72, !tbaa !27
  %t142 = load i64, ptr %l8, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l74, !tbaa !24
  %t145 = icmp sge i64 0, 0
  br i1 %t145, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb52
bb45:
  %t147 = load i64, ptr %l73, !tbaa !24
  %t148 = icmp sle i64 0, %t147
  br i1 %t148, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb47:
  %t150 = load i64, ptr %l73, !tbaa !24
  %t151 = load i64, ptr %l74, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb49:
  %t154 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l73, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 0
  %t158 = sub i64 %t156, 0
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  %t162 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s5, { i64, ptr } %t160)
  store { i64, ptr } %t162, ptr %l79
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9)
  unreachable
bb51:
  %t163 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t166 = icmp sgt i64 %t164, 0
  store i1 %t166, ptr %l71, !tbaa !21
  br label %bb52
bb52:
  %t168 = load i1, ptr %l71, !tbaa !21
  br i1 %t168, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb74
bb55:
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load i64, ptr %l6, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb73
bb57:
  br label %bb58
bb58:
  %t175 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t175, ptr %l85, !tbaa !27
  %t176 = load i64, ptr %l6, !tbaa !24
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t176)
  store i64 %t179, ptr %l88
  br label %bb59
bb59:
  %t180 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = load i64, ptr %l6, !tbaa !24
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t181)
  store i64 %t184, ptr %l92
  br label %bb60
bb60:
  %t185 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t186 = load i64, ptr %l92, !tbaa !24
  %t187 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t185, i64 %t186)
  store i64 %t187, ptr %l93
  br label %bb61
bb61:
  %t188 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l94, !tbaa !24
  %t190 = load i64, ptr %l88, !tbaa !24
  %t191 = icmp sge i64 %t190, 0
  br i1 %t191, label %bb62, label %bb63
bb62:
  %t193 = load i64, ptr %l88, !tbaa !24
  %t194 = load i64, ptr %l93, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb64:
  %t197 = load i64, ptr %l93, !tbaa !24
  %t198 = load i64, ptr %l94, !tbaa !24
  %t199 = icmp sle i64 %t197, %t198
  br i1 %t199, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb66:
  %t201 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l88, !tbaa !24
  %t204 = load i64, ptr %l93, !tbaa !24
  %t205 = getelementptr i8, ptr %t202, i64 %t203
  %t206 = sub i64 %t204, %t203
  %t207 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  store { i64, ptr } %t208, ptr %l9, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l100, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t215 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s7, { i64, ptr } %t213)
  store { i64, ptr } %t215, ptr %l102
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_89c63e526fea8550_9190d8cdbdd5cacc)
  unreachable
bb68:
  %t216 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = load i64, ptr %l100, !tbaa !24
  %t220 = sub i64 %t218, %t217
  %t221 = load i64, ptr %l8, !tbaa !24
  %t224 = icmp ne i64 %t220, %t221
  br i1 %t224, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s7)
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t226 = load i64, ptr %l6, !tbaa !24
  %t229 = sub i64 %t226, 1
  store i64 %t229, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  br label %bb55
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb75:
  %t231 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t231, ptr %l110
  br label %bb76
bb76:
  %t232 = load %"std/prelude/text:StringBuilder", ptr %l110
  store %"std/prelude/text:StringBuilder" %t232, ptr %l10
  %t233 = load i64, ptr %l6, !tbaa !24
  store i64 %t233, ptr %l11, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s10
  %t235 = load i64, ptr %l11, !tbaa !24
  %t237 = icmp sge i64 %t235, 0
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s10)
  br label %bb97
bb79:
  br label %bb80
bb80:
  %t241 = load i64, ptr %l11, !tbaa !24
  %t242 = load i64, ptr %l6, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  br i1 %t245, label %bb81, label %bb82
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  store ptr %l10, ptr %l119, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t248, ptr %l120, !tbaa !27
  %t249 = load i64, ptr %l11, !tbaa !24
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t249)
  store i64 %t252, ptr %l123
  br label %bb85
bb85:
  %t253 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t253, ptr %l124, !tbaa !27
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t254)
  store i64 %t257, ptr %l127
  br label %bb86
bb86:
  %t258 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t259 = load i64, ptr %l127, !tbaa !24
  %t260 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t258, i64 %t259)
  store i64 %t260, ptr %l128
  br label %bb87
bb87:
  %t261 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l129, !tbaa !24
  %t263 = load i64, ptr %l123, !tbaa !24
  %t264 = icmp sge i64 %t263, 0
  br i1 %t264, label %bb88, label %bb89
bb88:
  %t266 = load i64, ptr %l123, !tbaa !24
  %t267 = load i64, ptr %l128, !tbaa !24
  %t268 = icmp sle i64 %t266, %t267
  br i1 %t268, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb90:
  %t270 = load i64, ptr %l128, !tbaa !24
  %t271 = load i64, ptr %l129, !tbaa !24
  %t272 = icmp sle i64 %t270, %t271
  br i1 %t272, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb92:
  %t274 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l123, !tbaa !24
  %t277 = load i64, ptr %l128, !tbaa !24
  %t278 = getelementptr i8, ptr %t275, i64 %t276
  %t279 = sub i64 %t277, %t276
  %t280 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t283 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s10, { i64, ptr } %t281)
  store { i64, ptr } %t283, ptr %l134
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_51c1b9bde331172f_b1d3b315fa602c93)
  unreachable
bb94:
  %t284 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t285 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t285, { i64, ptr } %t284)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t287 = load i64, ptr %l11, !tbaa !24
  %t290 = sub i64 %t287, 1
  store i64 %t290, ptr %l11, !tbaa !24
  br label %bb77
bb97:
  %t293 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l10)
  store { i64, ptr } %t293, ptr %l140
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t294 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t294, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l2, !tbaa !22
  %t19 = load i8, ptr %l2, !tbaa !22
  %t21 = icmp eq i8 %t19, 34
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 39
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb22
bb10:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t48 = load i8, ptr %l2, !tbaa !22
  %t51 = icmp ne i8 %t47, %t48
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l24, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = icmp eq i8 %t62, 92
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t71 = load i64, ptr %l1, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  br label %bb10
bb21:
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l1, !tbaa !24
  br label %bb45
bb22:
  %t81 = load i8, ptr %l2, !tbaa !22
  %t83 = icmp eq i8 %t81, 35
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = add i64 %t85, 1
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t93 = icmp slt i64 %t87, %t90
  br i1 %t93, label %bb25, label %bb26
bb24:
  br label %bb44
bb25:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t95, ptr %l52, !tbaa !27
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = icmp eq i8 %t103, 35
  store i1 %t105, ptr %l51, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb27
bb27:
  %t107 = load i1, ptr %l51, !tbaa !21
  br i1 %t107, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l58, !tbaa !27
  %t109 = load i64, ptr %l1, !tbaa !24
  %t111 = add i64 %t109, 2
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 0
  store i64 %t115, ptr %l63, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load i64, ptr %l60, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb30, label %bb31
bb29:
  br label %bb43
bb30:
  %t121 = load i64, ptr %l60, !tbaa !24
  %t122 = load i64, ptr %l63, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb32:
  %t125 = load i64, ptr %l63, !tbaa !24
  %t126 = load i64, ptr %l64, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb34:
  %t129 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l60, !tbaa !24
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = getelementptr i8, ptr %t130, i64 %t131
  %t134 = sub i64 %t132, %t131
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t138 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t136, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  %t139 = extractvalue { i32, i64 } %t138, 1
  %t140 = extractvalue { i32, i64 } %t138, 0
  store i32 %t140, ptr %l70
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb37, label %ok.142, !prof !99
ok.142:
  store i64 %t139, ptr %l69
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8d5034eaa81491fd_13883a423d047079)
  unreachable
bb36:
  %t143 = load i64, ptr %l69, !tbaa !24
  store i64 %t143, ptr %l57, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  store i64 -1, ptr %l57, !tbaa !24
  br label %bb39
bb39:
  %t144 = load i64, ptr %l57, !tbaa !24
  store i64 %t144, ptr %l3, !tbaa !24
  %t145 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp slt i64 %t145, 0
  br i1 %t147, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  store i64 -1, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t150 = load i64, ptr %l1, !tbaa !24
  %t153 = add i64 %t150, 2
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = add i64 %t157, 2
  store i64 %t159, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb43:
  %t161 = load i64, ptr %l1, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
bb44:
  %t163 = load i64, ptr %l1, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l1, !tbaa !24
  br label %bb45
bb45:
  br label %bb1
bb46:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eDeprecatedNames(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb7:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t19)
  store i1 %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s3, { i64, ptr } %t23)
  store { i64, ptr } %t25, ptr %l23
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s3, { i64, ptr } %t26, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t28, ptr %l25
  br label %bb12
bb12:
  %t29 = load i1, ptr %l25, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb16:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t32)
  store i64 %t34, ptr %l28
  br label %bb17
bb17:
  %t35 = load i64, ptr %l28, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l32, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  store i64 %t41, ptr %l33, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t42, 0
  store i64 %t45, ptr %l36, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l37, !tbaa !24
  %t48 = load i64, ptr %l33, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb28
bb20:
  %t51 = load i64, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l36, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb22:
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb24:
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = load i64, ptr %l36, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l42
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_af70a68dd18f91cd_78b5556af2db7259)
  unreachable
bb26:
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s2, { i64, ptr } %t69, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t71, ptr %l44
  br label %bb27
bb27:
  %t72 = load i1, ptr %l44, !tbaa !21
  store i1 %t72, ptr %l31, !tbaa !21
  br label %bb28
bb28:
  %t73 = load i1, ptr %l31, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb29, label %bb30
bb29:
  %t78 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t78, ptr %l47, !tbaa !27
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l48, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l49, !tbaa !24
  %t82 = icmp sge i64 0, 0
  br i1 %t82, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  %t84 = load i64, ptr %l48, !tbaa !24
  %t85 = icmp sle i64 0, %t84
  br i1 %t85, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb33:
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = load i64, ptr %l49, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb35:
  %t91 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = getelementptr i8, ptr %t92, i64 0
  %t95 = sub i64 %t93, 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t99, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac)
  unreachable
bb37:
  %t106 = load i1, ptr %l2, !tbaa !21
  br i1 %t106, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb40
bb39:
  %t108 = load i1, ptr %l7, !tbaa !21
  store i1 %t108, ptr %l57, !tbaa !21
  br label %bb40
bb40:
  %t110 = load i1, ptr %l57, !tbaa !21
  br i1 %t110, label %bb41, label %bb42
bb41:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t111, ptr %l60, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = call ptr @__olang_scope_of(ptr %t113, ptr null)
  %t115 = call ptr @__olang_scope_hold(ptr %t114)
  %t116 = ptrtoint ptr %t115 to i64
  %t118 = inttoptr i64 %t116 to ptr
  %t119 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t120 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %t118, ptr %s2, { i64, ptr } %t119)
  store { i64, ptr } %t120, ptr %l62
  br label %bb43
bb42:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb45
bb43:
  %t121 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t121, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t122, ptr %l63
  br label %bb44
bb44:
  %t123 = load i1, ptr %l63, !tbaa !21
  %t124 = xor i1 %t123, true
  store i1 %t124, ptr %l59, !tbaa !21
  br label %bb45
bb45:
  %t126 = load i1, ptr %l59, !tbaa !21
  br i1 %t126, label %bb46, label %bb47
bb46:
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t127, ptr %l65, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_scope_of(ptr %t129, ptr null)
  %t131 = call ptr @__olang_scope_hold(ptr %t130)
  %t132 = ptrtoint ptr %t131 to i64
  %t134 = inttoptr i64 %t132 to ptr
  %t135 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2ewordsOf(ptr %t134, ptr %v1, { i64, ptr } %t135)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l67
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %t138
  store ptr %t138, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb49
bb49:
  %t140 = load i64, ptr %l9, !tbaa !24
  store i64 %t140, ptr %l69, !tbaa !24
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t141)
  store i64 %t143, ptr %l71
  br label %bb50
bb50:
  %t144 = load i64, ptr %l69, !tbaa !24
  %t145 = load i64, ptr %l71, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb51, label %bb52
bb51:
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t150, i64 %t151)
  store { i64, ptr } %t154, ptr %l76
  br label %bb54
bb54:
  %t155 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %l1, { i64, ptr } %t155)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l9, !tbaa !24
  br label %bb49
bb57:
  br label %bb58
bb58:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb59:
  br label %bb3
bb60:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fdoc_2eEntry_2eitem(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %lp28 = alloca ptr
  %lp29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %l34 = alloca i64
  %l40 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l89 = alloca %"compiler/doc:Entry"
  %l92 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca i1
  %l114 = alloca %"compiler/doc:Entry"
  %l118 = alloca i32
  %l119 = alloca i64
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca i64
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca i64
  %l143 = alloca i64
  %l163 = alloca i1
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca i64
  %l173 = alloca ptr
  %l175 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l190 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l196 = alloca i1
  %l197 = alloca i1
  %l199 = alloca i64
  %l201 = alloca i64
  %l207 = alloca { i64, ptr }
  %l210 = alloca i1
  %l212 = alloca i64
  %l215 = alloca i64
  %l219 = alloca %"compiler/doc:Entry"
  %l226 = alloca ptr
  %l227 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l232 = alloca i1
  %l233 = alloca ptr
  %l235 = alloca %"compiler/doc:Entry"
  %l237 = alloca i1
  %l239 = alloca { i64, ptr }
  %l242 = alloca i1
  %l244 = alloca i1
  %l248 = alloca %"compiler/doc:Entry"
  %l252 = alloca ptr
  %l256 = alloca i32
  %l257 = alloca ptr
  %l258 = alloca i64
  %l262 = alloca i32
  %l263 = alloca i64
  %l269 = alloca ptr
  %l273 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca i64
  %l283 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l305 = alloca %"compiler/doc:Entry"
  %l307 = alloca { i64, ptr }
  %l310 = alloca i1
  %l312 = alloca i1
  %l316 = alloca %"compiler/doc:Entry"
  %l321 = alloca i64
  %l326 = alloca i1
  %l329 = alloca i64
  %l332 = alloca i64
  %l334 = alloca i64
  %l338 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l346 = alloca %"compiler/doc:Entry"
  %l350 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca i32
  %t141 = alloca %"compiler/doc:Entry", align 8
  %t511 = alloca %"compiler/doc:Entry", align 8
  %t562 = alloca %"compiler/doc:Entry", align 8
  %t565 = alloca %"compiler/doc:Entry", align 8
  %t591 = alloca %"compiler/doc:Entry", align 8
  %t748 = alloca %"compiler/doc:Entry", align 8
  %t770 = alloca %"compiler/doc:Entry", align 8
  %t856 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l40
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l40, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2d405ddcd9a8ab59_87891e6f641f4355)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l7, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/load:Loader", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l8, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t42, ptr %t43, ptr %t44, i64 %t45, { i64, ptr } %t46)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l59
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  store { i64, ptr } %t53, ptr %l58
  br label %bb5
bb5:
  %t57 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t57, ptr %l52, !tbaa !27
  br label %bb7
bb6:
  %t58 = load i32, ptr %l59, !tbaa !23
  %t59 = lshr i32 %t58, 16
  %t60 = and i32 %t58, 65535
  %t61 = icmp eq i32 %t59, 1
  %t62 = select i1 %t61, i32 1, i32 0
  %t63 = icmp eq i32 %t58, 0
  %t64 = shl i32 %t62, 16
  %t65 = or i32 %t64, %t60
  %t66 = select i1 %t63, i32 0, i32 %t65
  call void @__olang_scope_close(ptr %s0)
  store i32 %t66, ptr %rv
  br label %ret
bb7:
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t68, ptr %lp9
  %t69 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t70 = load ptr, ptr %lp9
  store { i64, ptr } %t69, ptr %t70, !tbaa !27
  %t71 = load ptr, ptr %lp9
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v4, ptr %v4, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l62
  br label %bb8
bb8:
  %t75 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v4, ptr %s0, ptr %v4, { i64, ptr } %t75, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store { i64, ptr } %t76, ptr %l63
  br label %bb9
bb9:
  %t77 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l3, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v3, ptr %t78, i64 %t79, { i64, ptr } %t80)
  store i64 %t84, ptr %l67
  br label %bb10
bb10:
  %t85 = load i64, ptr %l67, !tbaa !24
  store i64 %t85, ptr %l11, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t86, ptr %l68, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %t88, i64 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !37
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t90, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t92, ptr %l70
  br label %bb11
bb11:
  %t93 = load i1, ptr %l70, !tbaa !21
  br i1 %t93, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb15
bb13:
  %t94 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t94, ptr %l72, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %t96, i64 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !37
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t100, ptr %l74
  br label %bb14
bb14:
  %t101 = load i1, ptr %l74, !tbaa !21
  store i1 %t101, ptr %l71, !tbaa !21
  br label %bb15
bb15:
  %t102 = load i1, ptr %l71, !tbaa !21
  br i1 %t102, label %bb16, label %bb17
bb16:
  %t105 = call ptr @__olang_scope_hold(ptr %v4)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l77, !tbaa !24
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t107, label %bb18, label %bb19
bb17:
  %t109 = call ptr @__olang_scope_hold(ptr %v4)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l82, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t111, label %bb21, label %bb22
bb18:
  %t113 = call ptr @__olang_region_make(ptr %v4)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l77, !tbaa !24
  br label %bb19
bb19:
  %t115 = load ptr, ptr %lp9
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l77
  %t118 = inttoptr i64 %t117 to ptr
  %t120 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v4, ptr %t118, { i64, ptr } %t116)
  store { i64, ptr } %t120, ptr %l80
  br label %bb20
bb20:
  %t121 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t121, ptr %l76, !tbaa !27
  br label %bb23
bb21:
  %t123 = call ptr @__olang_region_make(ptr %v4)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l82, !tbaa !24
  br label %bb22
bb22:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l84, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %t127, i64 0
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !37
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = extractvalue { i64, ptr } %t129, 0
  %t133 = load i64, ptr %l82
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = call ptr @__olang_held_alloc(ptr %t134, i64 %t132)
  call void @olang_textcopy(ptr %t135, ptr %t131, i64 %t132)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l76, !tbaa !27
  br label %bb23
bb23:
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t141, ptr %v4, ptr %v4, ptr %v3, ptr %v4, { i64, ptr } %t142, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } %t140)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t141, i64 152, i1 false)
  br label %bb24
bb24:
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t144, ptr %lp13
  %t145 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %l89, i64 152, i1 false)
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp sge i64 %t146, 0
  br i1 %t148, label %bb25, label %bb26
bb25:
  %t150 = call ptr @__olang_scope_hold(ptr %v4)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l92, !tbaa !24
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t152, label %bb27, label %bb28
bb26:
  br label %bb32
bb27:
  %t154 = call ptr @__olang_region_make(ptr %v4)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l92, !tbaa !24
  br label %bb28
bb28:
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t158 = load i64, ptr %l92
  %t159 = inttoptr i64 %t158 to ptr
  %t162 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %t159, { i64, ptr } %t156, i64 %t157, i1 true)
  store { i64, ptr } %t162, ptr %l96
  br label %bb29
bb29:
  %t163 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t164 = load i64, ptr %l92
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = extractvalue { i64, ptr } %t163, 0
  %t167 = extractvalue { i64, ptr } %t163, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_held_alloc(ptr %t165, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t172 = load ptr, ptr %lp13
  %t173 = getelementptr %"compiler/doc:Entry", ptr %t172, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  store { i64, ptr } %t174, ptr %l98, !tbaa !27
  %t176 = load ptr, ptr %lp13
  %t177 = getelementptr %"compiler/doc:Entry", ptr %t176, i32 0, i32 1
  store { i64, ptr } %t171, ptr %t177, !tbaa !27
  %t178 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load { i64, ptr }, ptr %l98
  %t181 = extractvalue { i64, ptr } %t180, 1
  call void @__olang_region_release(ptr %t181)
  store { i64, ptr } zeroinitializer, ptr %l98
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t182 = load ptr, ptr %l6, !tbaa !29
  %t184 = getelementptr %"compiler/load:Module", ptr %t182, i32 0, i32 4
  %t185 = load i64, ptr %t184, !tbaa !24
  %t187 = load ptr, ptr %lp13
  %t188 = getelementptr %"compiler/doc:Entry", ptr %t187, i32 0, i32 3
  store i64 %t185, ptr %t188, !tbaa !24
  %t189 = load i64, ptr %l11, !tbaa !24
  %t191 = load ptr, ptr %lp13
  %t192 = getelementptr %"compiler/doc:Entry", ptr %t191, i32 0, i32 4
  store i64 %t189, ptr %t192, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t193, ptr %l103, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %t195, i64 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !37
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t199, ptr %l105
  br label %bb33
bb33:
  %t200 = load i1, ptr %l105, !tbaa !21
  br i1 %t200, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb37
bb35:
  %t201 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t201, ptr %l107, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %t203, i64 0
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !37
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s0, { i64, ptr } %t205, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t207, ptr %l109
  br label %bb36
bb36:
  %t208 = load i1, ptr %l109, !tbaa !21
  store i1 %t208, ptr %l106, !tbaa !21
  br label %bb37
bb37:
  %t209 = load i1, ptr %l106, !tbaa !21
  br i1 %t209, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb40
bb39:
  %t210 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t214 = icmp eq i64 %t212, 1
  store i1 %t214, ptr %l110, !tbaa !21
  br label %bb40
bb40:
  %t216 = load i1, ptr %l110, !tbaa !21
  br i1 %t216, label %bb41, label %bb42
bb41:
  %t217 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t217, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l114, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i64, ptr %l3, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t224 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v3, ptr %t218, i64 %t219, { i64, ptr } %t220)
  store i32 %t224, ptr %l118
  br label %bb44
bb44:
  %t225 = load i32, ptr %l118, !tbaa !23
  store i32 %t225, ptr %l14, !tbaa !23
  %t226 = call ptr @__olang_scope_hold(ptr %s0)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l119, !tbaa !24
  %t228 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15
  br i1 %t228, label %bb45, label %bb46
bb45:
  %t230 = call ptr @__olang_region_make(ptr %s0)
  %t231 = ptrtoint ptr %t230 to i64
  store i64 %t231, ptr %l119, !tbaa !24
  br label %bb46
bb46:
  %t232 = load i64, ptr %l119
  %t233 = inttoptr i64 %t232 to ptr
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t233, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l121
  br label %bb47
bb47:
  %t235 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15
  br i1 %t235, label %bb48, label %bb49
bb48:
  %t237 = load i64, ptr %l119
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = call ptr @__olang_region_or(ptr %t241, ptr null)
  %t243 = call ptr @__olang_region_home(ptr %t242)
  %t244 = icmp ne ptr %t243, null
  %t245 = select i1 %t244, ptr %t243, ptr null
  call void @__olang_region_settle_in(ptr %t238, ptr %t245)
  br label %bb49
bb49:
  %t246 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %l15
  %t247 = load i32, ptr %l14, !tbaa !23
  %t249 = icmp sge i32 %t247, 0
  br i1 %t249, label %bb50, label %bb51
bb50:
  %t251 = call ptr @__olang_scope_hold(ptr %s0)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l125, !tbaa !24
  %t253 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15
  br i1 %t253, label %bb52, label %bb53
bb51:
  br label %bb61
bb52:
  %t255 = call ptr @__olang_region_make(ptr %s0)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l125, !tbaa !24
  br label %bb53
bb53:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l14, !tbaa !23
  %t259 = load i1, ptr %l5, !tbaa !21
  %t260 = load i64, ptr %l125
  %t261 = inttoptr i64 %t260 to ptr
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %t261, ptr %t257, i32 %t258, i1 %t259)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l130
  br label %bb54
bb54:
  %t266 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15
  br i1 %t266, label %bb55, label %bb56
bb55:
  %t268 = load i64, ptr %l125
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = call ptr @__olang_region_or(ptr %t272, ptr null)
  %t274 = call ptr @__olang_region_home(ptr %t273)
  %t275 = icmp ne ptr %t274, null
  %t276 = select i1 %t275, ptr %t274, ptr null
  call void @__olang_region_settle_in(ptr %t269, ptr %t276)
  br label %bb56
bb56:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l132
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l15
  %t279 = load i1, ptr @olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15
  br i1 %t279, label %bb57, label %bb58
bb57:
  %t281 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132, i32 0, i32 0
  %t282 = load { i64, ptr }, ptr %t281
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = call ptr @__olang_region_or(ptr %t283, ptr null)
  %t285 = call ptr @__olang_region_home(ptr %t284)
  %t286 = icmp ne ptr %t285, null
  %t287 = select i1 %t286, ptr %t285, ptr null
  call void @__olang_region_drop(ptr %t287)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l132
  br label %bb58
bb58:
  %t288 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t288, label %bb59, label %bb60
bb59:
  %t290 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132, i32 0, i32 0
  %t291 = load { i64, ptr }, ptr %t290
  %t292 = extractvalue { i64, ptr } %t291, 0
  %t293 = extractvalue { i64, ptr } %t291, 1
  call void @__olang_region_release_part(ptr %t293, i64 %t292)
  store { i64, ptr } zeroinitializer, ptr %t290
  br label %bb60
bb60:
  br label %bb61
bb61:
  store i1 false, ptr %l16, !tbaa !21
  store i64 1, ptr %l17, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  store i64 %t296, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l17, !tbaa !24
  %t302 = icmp sgt i64 %t298, %t299
  br i1 %t302, label %bb62, label %bb63
bb62:
  %t304 = load i64, ptr %l19, !tbaa !24
  %t306 = icmp sgt i64 %t304, 0
  br i1 %t306, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb67
bb64:
  %t308 = load i64, ptr %l18, !tbaa !24
  %t309 = load i64, ptr %l17, !tbaa !24
  %t312 = sub i64 %t308, %t309
  %t313 = load i64, ptr %l19, !tbaa !24
  %t316 = add i64 %t312, %t313
  %t318 = sub i64 %t316, 1
  %t319 = load i64, ptr %l19, !tbaa !24
  %t322 = sdiv i64 %t318, %t319
  store i64 %t322, ptr %l143, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb66
bb66:
  %t324 = load i64, ptr %l143, !tbaa !24
  store i64 %t324, ptr %l140, !tbaa !24
  br label %bb67
bb67:
  %t325 = load i64, ptr %l140, !tbaa !24
  store i64 %t325, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s6
  %t326 = load i64, ptr %l21, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t330 = icmp slt i64 %t326, %t327
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s6)
  br label %bb190
bb70:
  br label %bb71
bb71:
  %t334 = load i64, ptr %l17, !tbaa !24
  %t335 = load i64, ptr %l21, !tbaa !24
  %t336 = load i64, ptr %l19, !tbaa !24
  %t339 = mul i64 %t335, %t336
  %t342 = add i64 %t334, %t339
  store i64 %t342, ptr %l22, !tbaa !24
  %t344 = load i1, ptr %l16, !tbaa !21
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb72, label %bb73
bb72:
  %t348 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t348, ptr %l164, !tbaa !27
  %t349 = load i64, ptr %l22, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %t352, i64 %t349
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !37
  %t356 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v4, ptr %v4, { i64, ptr } %t354)
  store { i64, ptr } %t356, ptr %l167
  br label %bb74
bb73:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb76
bb74:
  %t357 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t358 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t357, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t358, ptr %l168
  br label %bb75
bb75:
  %t359 = load i1, ptr %l168, !tbaa !21
  store i1 %t359, ptr %l163, !tbaa !21
  br label %bb76
bb76:
  %t360 = load i1, ptr %l163, !tbaa !21
  br i1 %t360, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 true, ptr %l16, !tbaa !21
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l169, !tbaa !29
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l170, !tbaa !29
  %t363 = load ptr, ptr %l2, !tbaa !29
  store ptr %t363, ptr %l171, !tbaa !29
  %t364 = load i64, ptr %l3, !tbaa !24
  store i64 %t364, ptr %l172, !tbaa !24
  %t365 = load ptr, ptr %lp13
  store ptr %t365, ptr %l173, !tbaa !29
  %t366 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t366, ptr %l175
  %t368 = call ptr @__olang_scope_hold(ptr %s7)
  %t369 = ptrtoint ptr %t368 to i64
  store i64 %t369, ptr %l176, !tbaa !24
  %t370 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t370, label %bb79, label %bb80
bb78:
  br label %bb86
bb79:
  %t372 = call ptr @__olang_region_make_part(ptr %s7)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l176, !tbaa !24
  br label %bb80
bb80:
  %t374 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175, i32 0, i32 0
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  store { i64, ptr } %t375, ptr %l178, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  store i64 %t377, ptr %l179, !tbaa !24
  %t378 = load i64, ptr %l179, !tbaa !24
  %t379 = mul i64 %t378, 8
  %t380 = load i64, ptr %l176
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = call ptr @__olang_held_alloc(ptr %t381, i64 %t379)
  %t383 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  store { i64, ptr } %t384, ptr %l180, !tbaa !27
  %t385 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = load i64, ptr %l179, !tbaa !24
  %t390 = mul i64 %t389, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t386, ptr %t388, i64 %t390, i1 false)
  %t391 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t392 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175, i32 0, i32 0
  store { i64, ptr } %t391, ptr %t392, !tbaa !27
  %t393 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t393, label %bb81, label %bb82
bb81:
  %t395 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175, i32 0, i32 0
  %t396 = load { i64, ptr }, ptr %t395, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  %t399 = icmp eq i64 %t397, 0
  br i1 %t399, label %bb83, label %bb84
bb82:
  %t401 = load i1, ptr %l5, !tbaa !21
  %t402 = load ptr, ptr %l169, !tbaa !29
  %t403 = load ptr, ptr %l170, !tbaa !29
  %t404 = load ptr, ptr %l171, !tbaa !29
  %t405 = load i64, ptr %l172, !tbaa !24
  %t406 = load ptr, ptr %l173, !tbaa !29
  %t407 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175
  call void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %s7, ptr %t402, ptr %t403, ptr %t404, i64 %t405, ptr %t406, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t407, i1 %t401)
  br label %bb85
bb83:
  %t409 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t409, !tbaa !27
  br label %bb84
bb84:
  %t410 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175, i32 0, i32 0
  %t411 = load i64, ptr %l176
  %t412 = inttoptr i64 %t411 to ptr
  %t413 = load { i64, ptr }, ptr %t410
  %t414 = extractvalue { i64, ptr } %t413, 1
  %t415 = call ptr @__olang_region_or(ptr %t414, ptr null)
  %t416 = icmp ne ptr %t415, null
  %t417 = select i1 %t416, ptr %t415, ptr null
  call void @__olang_region_settle_in(ptr %t412, ptr %t417)
  br label %bb82
bb85:
  call void @__olang_scope_close(ptr %s7)
  br label %bb86
bb86:
  %t418 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t418, ptr %l185, !tbaa !27
  %t419 = load i64, ptr %l22, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr { i64, ptr }, ptr %t422, i64 %t419
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !37
  %t426 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v4, ptr %v4, { i64, ptr } %t424)
  store { i64, ptr } %t426, ptr %l188
  br label %bb87
bb87:
  %t427 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t427, ptr %l23, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t430 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t428, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t430, ptr %l190
  br label %bb88
bb88:
  %t431 = load i1, ptr %l190, !tbaa !21
  br i1 %t431, label %bb89, label %bb90
bb89:
  %t432 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t434 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t432, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t434, ptr %l193
  br label %bb91
bb90:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb92
bb91:
  %t435 = load i1, ptr %l193, !tbaa !21
  %t436 = xor i1 %t435, true
  store i1 %t436, ptr %l191, !tbaa !21
  br label %bb92
bb92:
  %t438 = load i1, ptr %l191, !tbaa !21
  br i1 %t438, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb94:
  br label %bb95
bb95:
  %t439 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t441 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t439, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t441, ptr %l196
  br label %bb96
bb96:
  %t442 = load i1, ptr %l196, !tbaa !21
  br i1 %t442, label %bb97, label %bb98
bb97:
  %t443 = load ptr, ptr %lp13
  %t444 = getelementptr %"compiler/doc:Entry", ptr %t443, i32 0, i32 5
  %t446 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %t444)
  store i64 %t446, ptr %l199
  br label %bb99
bb98:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb100
bb99:
  %t447 = load i64, ptr %l199, !tbaa !24
  %t448 = icmp eq i64 %t447, 0
  store i1 %t448, ptr %l197, !tbaa !21
  br label %bb100
bb100:
  %t450 = load i1, ptr %l197, !tbaa !21
  br i1 %t450, label %bb101, label %bb102
bb101:
  %t451 = call ptr @__olang_scope_hold(ptr %v4)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l201, !tbaa !24
  %t453 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t453, label %bb103, label %bb104
bb102:
  br label %bb107
bb103:
  %t455 = call ptr @__olang_region_make(ptr %v4)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l201, !tbaa !24
  br label %bb104
bb104:
  %t457 = load ptr, ptr %lp13
  %t458 = getelementptr %"compiler/doc:Entry", ptr %t457, i32 0, i32 0
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t460 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t459, 1
  %t463 = extractvalue { i64, ptr } %t459, 0
  %t464 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t466 = add i64 %t463, %t465
  %t468 = extractvalue { i64, ptr } %t460, 1
  %t469 = extractvalue { i64, ptr } %t460, 0
  %t470 = add i64 %t466, %t469
  %t471 = load i64, ptr %l201
  %t472 = inttoptr i64 %t471 to ptr
  %t473 = call ptr @__olang_held_alloc(ptr %t472, i64 %t470)
  call void @olang_textcopy(ptr %t473, ptr %t462, i64 %t463)
  %t474 = getelementptr i8, ptr %t473, i64 %t463
  call void @olang_textcopy(ptr %t474, ptr %t464, i64 %t465)
  %t475 = getelementptr i8, ptr %t474, i64 %t465
  call void @olang_textcopy(ptr %t475, ptr %t468, i64 %t469)
  %t476 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t473, 1
  %t479 = load ptr, ptr %lp13
  %t480 = getelementptr %"compiler/doc:Entry", ptr %t479, i32 0, i32 0
  %t481 = load { i64, ptr }, ptr %t480, !tbaa !27
  store { i64, ptr } %t481, ptr %l207, !tbaa !27
  %t483 = load ptr, ptr %lp13
  %t484 = getelementptr %"compiler/doc:Entry", ptr %t483, i32 0, i32 0
  store { i64, ptr } %t477, ptr %t484, !tbaa !27
  %t485 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t485, label %bb105, label %bb106
bb105:
  %t487 = load { i64, ptr }, ptr %l207
  %t488 = extractvalue { i64, ptr } %t487, 1
  call void @__olang_region_release(ptr %t488)
  store { i64, ptr } zeroinitializer, ptr %l207
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb107:
  %t489 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t491 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t489, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t491, ptr %l210
  br label %bb108
bb108:
  %t492 = load i1, ptr %l210, !tbaa !21
  br i1 %t492, label %bb109, label %bb110
bb109:
  %t493 = load ptr, ptr %lp13
  %t494 = getelementptr %"compiler/doc:Entry", ptr %t493, i32 0, i32 5
  %t496 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %t494)
  store i64 %t496, ptr %l212
  br label %bb111
bb110:
  br label %bb118
bb111:
  %t497 = load i64, ptr %l212, !tbaa !24
  %t498 = sub i64 %t497, 1
  store i64 %t498, ptr %l24, !tbaa !24
  %t500 = load i64, ptr %l24, !tbaa !24
  store i64 %t500, ptr %l25, !tbaa !24
  %t502 = call ptr @__olang_scope_hold(ptr %v4)
  %t503 = ptrtoint ptr %t502 to i64
  store i64 %t503, ptr %l215, !tbaa !24
  %t504 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t504, label %bb112, label %bb113
bb112:
  %t506 = call ptr @__olang_region_make(ptr %v4)
  %t507 = ptrtoint ptr %t506 to i64
  store i64 %t507, ptr %l215, !tbaa !24
  br label %bb113
bb113:
  %t508 = load ptr, ptr %lp13
  %t509 = getelementptr %"compiler/doc:Entry", ptr %t508, i32 0, i32 5
  %t510 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t511, ptr %v4, ptr %v4, ptr %t509, i64 %t510)
  call void @llvm.memmove.p0.p0.i64(ptr %l219, ptr %t511, i64 152, i1 false)
  br label %bb114
bb114:
  %t514 = getelementptr %"compiler/doc:Entry", ptr %l219, i32 0, i32 0
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !27
  %t516 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t515, 1
  %t519 = extractvalue { i64, ptr } %t515, 0
  %t520 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t521 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t522 = add i64 %t519, %t521
  %t524 = extractvalue { i64, ptr } %t516, 1
  %t525 = extractvalue { i64, ptr } %t516, 0
  %t526 = add i64 %t522, %t525
  %t527 = load i64, ptr %l215
  %t528 = inttoptr i64 %t527 to ptr
  %t529 = call ptr @__olang_held_alloc(ptr %t528, i64 %t526)
  call void @olang_textcopy(ptr %t529, ptr %t518, i64 %t519)
  %t530 = getelementptr i8, ptr %t529, i64 %t519
  call void @olang_textcopy(ptr %t530, ptr %t520, i64 %t521)
  %t531 = getelementptr i8, ptr %t530, i64 %t521
  call void @olang_textcopy(ptr %t531, ptr %t524, i64 %t525)
  %t532 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t529, 1
  store { i64, ptr } %t533, ptr %l26, !tbaa !27
  %t536 = load ptr, ptr %lp13
  %t537 = getelementptr %"compiler/doc:Entry", ptr %t536, i32 0, i32 5
  %t538 = load i64, ptr %l25, !tbaa !24
  %t541 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eRefMut_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t537, i64 %t538)
  store ptr %t541, ptr %l226
  br label %bb115
bb115:
  %t542 = load ptr, ptr %l226, !tbaa !29
  store ptr %t542, ptr %l227, !tbaa !29
  %t544 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t545 = load ptr, ptr %l227, !tbaa !29
  %t546 = getelementptr %"compiler/doc:Entry", ptr %t545, i32 0, i32 0
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  store { i64, ptr } %t547, ptr %l229, !tbaa !27
  %t549 = load ptr, ptr %l227, !tbaa !29
  %t550 = getelementptr %"compiler/doc:Entry", ptr %t549, i32 0, i32 0
  store { i64, ptr } %t544, ptr %t550, !tbaa !27
  %t551 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t551, label %bb116, label %bb117
bb116:
  %t553 = load { i64, ptr }, ptr %l229
  %t554 = extractvalue { i64, ptr } %t553, 1
  call void @__olang_region_release(ptr %t554)
  store { i64, ptr } zeroinitializer, ptr %l229
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb118:
  %t555 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t557 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t555, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t557, ptr %l232
  br label %bb119
bb119:
  %t558 = load i1, ptr %l232, !tbaa !21
  br i1 %t558, label %bb120, label %bb121
bb120:
  %t559 = load ptr, ptr %lp13
  %t560 = getelementptr %"compiler/doc:Entry", ptr %t559, i32 0, i32 5
  store ptr %t560, ptr %l233, !tbaa !29
  %t561 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t562, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t561, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l235, ptr %t562, i64 152, i1 false)
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t564 = load ptr, ptr %l233, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t565, ptr %l235, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t564, ptr %t565)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb124:
  %t566 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t568 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s6, { i64, ptr } %t566, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t568, ptr %l237
  br label %bb125
bb125:
  %t569 = load i1, ptr %l237, !tbaa !21
  br i1 %t569, label %bb126, label %bb127
bb126:
  %t570 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t572 = call { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v4, ptr %v4, { i64, ptr } %t570)
  store { i64, ptr } %t572, ptr %l239
  br label %bb128
bb127:
  br label %bb161
bb128:
  %t573 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t573, ptr %lp28
  %t574 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t575 = load ptr, ptr %lp28
  store { i64, ptr } %t574, ptr %t575, !tbaa !27
  %t576 = load i1, ptr %l5, !tbaa !21
  %t578 = xor i1 %t576, true
  br i1 %t578, label %bb129, label %bb130
bb129:
  %t580 = load ptr, ptr %lp28
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !27
  %t583 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t581)
  store i1 %t583, ptr %l244
  br label %bb131
bb130:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb132
bb131:
  %t584 = load i1, ptr %l244, !tbaa !21
  %t585 = xor i1 %t584, true
  store i1 %t585, ptr %l242, !tbaa !21
  br label %bb132
bb132:
  %t587 = load i1, ptr %l242, !tbaa !21
  br i1 %t587, label %bb133, label %bb134
bb133:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb134:
  br label %bb135
bb135:
  %t588 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t589 = load ptr, ptr %lp28
  %t590 = load { i64, ptr }, ptr %t589, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t591, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t588, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } %t590)
  call void @llvm.memmove.p0.p0.i64(ptr %l248, ptr %t591, i64 152, i1 false)
  br label %bb136
bb136:
  %t594 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t594, ptr %lp29
  %t595 = load ptr, ptr %lp29
  call void @llvm.memmove.p0.p0.i64(ptr %t595, ptr %l248, i64 152, i1 false)
  %t596 = load i32, ptr %l14, !tbaa !23
  %t598 = icmp sge i32 %t596, 0
  br i1 %t598, label %bb137, label %bb138
bb137:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/check:Checker", ptr %t600, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !29
  store ptr %t603, ptr %l252, !tbaa !29
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t608 = load i32, ptr %l14, !tbaa !23
  %t611 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t607, i32 %t608)
  store i32 %t611, ptr %l256
  br label %bb139
bb138:
  br label %bb159
bb139:
  %t612 = load ptr, ptr %l8, !tbaa !29
  store ptr %t612, ptr %l257, !tbaa !29
  %t613 = call ptr @__olang_scope_hold(ptr %v0)
  %t614 = ptrtoint ptr %t613 to i64
  store i64 %t614, ptr %l258, !tbaa !24
  %t615 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t615, label %bb140, label %bb141
bb140:
  %t617 = load ptr, ptr %l257, !tbaa !29
  %t618 = call ptr @__olang_region_or(ptr %t617, ptr %v0)
  %t619 = call ptr @__olang_scope_hold(ptr %t618)
  %t620 = ptrtoint ptr %t619 to i64
  store i64 %t620, ptr %l258, !tbaa !24
  br label %bb141
bb141:
  %t621 = load ptr, ptr %l8, !tbaa !29
  %t622 = load ptr, ptr %lp28
  %t623 = load { i64, ptr }, ptr %t622, !tbaa !27
  %t624 = load i64, ptr %l258
  %t625 = inttoptr i64 %t624 to ptr
  %t628 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t625, ptr %v4, ptr %t621, { i64, ptr } %t623)
  store i32 %t628, ptr %l262
  br label %bb142
bb142:
  %t629 = load ptr, ptr %l252, !tbaa !29
  %t630 = load i32, ptr %l256, !tbaa !23
  %t631 = load i32, ptr %l262, !tbaa !23
  %t632 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t629, i32 %t630, i32 %t631)
  store i64 %t632, ptr %l263
  br label %bb143
bb143:
  %t633 = load i64, ptr %l263, !tbaa !24
  store i64 %t633, ptr %l30, !tbaa !24
  %t634 = load i64, ptr %l30, !tbaa !24
  %t636 = icmp sge i64 %t634, 0
  br i1 %t636, label %bb144, label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s17
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/check:Checker", ptr %t638, i32 0, i32 1
  %t641 = load ptr, ptr %t640, !tbaa !29
  %t643 = getelementptr %"compiler/generic:Program", ptr %t641, i32 0, i32 0
  %t644 = load ptr, ptr %t643, !tbaa !29
  %t646 = getelementptr %"compiler/load:Loader", ptr %t644, i32 0, i32 10
  store ptr %t646, ptr %l269, !tbaa !29
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/check:Checker", ptr %t647, i32 0, i32 1
  %t650 = load ptr, ptr %t649, !tbaa !29
  %t651 = load i64, ptr %l30, !tbaa !24
  %t654 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t650, i64 %t651)
  store i64 %t654, ptr %l273
  br label %bb146
bb145:
  br label %bb158
bb146:
  %t655 = load ptr, ptr %l269, !tbaa !29
  %t656 = load i64, ptr %l273, !tbaa !24
  %t657 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t655, i64 %t656)
  store ptr %t657, ptr %l274
  br label %bb147
bb147:
  %t658 = load ptr, ptr %l274, !tbaa !29
  store ptr %t658, ptr %l31, !tbaa !29
  %t659 = call ptr @__olang_scope_hold(ptr %v4)
  %t660 = ptrtoint ptr %t659 to i64
  store i64 %t660, ptr %l275, !tbaa !24
  %t661 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t661, label %bb148, label %bb149
bb148:
  %t663 = call ptr @__olang_region_make(ptr %v4)
  %t664 = ptrtoint ptr %t663 to i64
  store i64 %t664, ptr %l275, !tbaa !24
  br label %bb149
bb149:
  %t665 = load ptr, ptr %l31, !tbaa !29
  %t667 = getelementptr %"compiler/load:Module", ptr %t665, i32 0, i32 6
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t670 = icmp eq ptr %t668, null
  br i1 %t670, label %bb150, label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_280c17d24f0b9a32_ec56e4f0207863ae)
  unreachable
bb151:
  br label %bb152
bb152:
  %t672 = load ptr, ptr %l31, !tbaa !29
  %t674 = getelementptr %"compiler/load:Module", ptr %t672, i32 0, i32 6
  %t675 = load ptr, ptr %t674, !tbaa !29
  %t678 = getelementptr %"compiler/source:Source", ptr %t675, i32 0, i32 1
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  store { i64, ptr } %t679, ptr %l283, !tbaa !27
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/check:Checker", ptr %t680, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t684 = load i64, ptr %l30, !tbaa !24
  %t687 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s17, ptr %t683, i64 %t684)
  store ptr %t687, ptr %l287
  br label %bb153
bb153:
  %t688 = load ptr, ptr %l287, !tbaa !29
  %t690 = getelementptr %"compiler/ast:Func", ptr %t688, i32 0, i32 0
  %t691 = getelementptr %"compiler/source:Span", ptr %t690, i32 0, i32 0
  %t692 = load i32, ptr %t691, !tbaa !23
  %t694 = sext i32 %t692 to i64
  %t695 = load i64, ptr %l275
  %t696 = inttoptr i64 %t695 to ptr
  %t697 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t699 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t696, { i64, ptr } %t697, i64 %t694)
  store { i64, ptr } %t699, ptr %l291
  br label %bb154
bb154:
  %t700 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t701 = load i64, ptr %l275
  %t702 = inttoptr i64 %t701 to ptr
  %t703 = extractvalue { i64, ptr } %t700, 0
  %t704 = extractvalue { i64, ptr } %t700, 1
  %t705 = mul i64 %t703, 1
  %t706 = call ptr @__olang_held_alloc(ptr %t702, i64 %t705)
  call void @llvm.memcpy.p0.p0.i64(ptr %t706, ptr %t704, i64 %t705, i1 false)
  %t707 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t709 = load ptr, ptr %lp29
  %t710 = getelementptr %"compiler/doc:Entry", ptr %t709, i32 0, i32 1
  %t711 = load { i64, ptr }, ptr %t710, !tbaa !27
  store { i64, ptr } %t711, ptr %l293, !tbaa !27
  %t713 = load ptr, ptr %lp29
  %t714 = getelementptr %"compiler/doc:Entry", ptr %t713, i32 0, i32 1
  store { i64, ptr } %t708, ptr %t714, !tbaa !27
  %t715 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t715, label %bb155, label %bb156
bb155:
  %t717 = load { i64, ptr }, ptr %l293
  %t718 = extractvalue { i64, ptr } %t717, 1
  call void @__olang_region_release(ptr %t718)
  store { i64, ptr } zeroinitializer, ptr %l293
  br label %bb156
bb156:
  %t719 = load ptr, ptr %l31, !tbaa !29
  %t721 = getelementptr %"compiler/load:Module", ptr %t719, i32 0, i32 4
  %t722 = load i64, ptr %t721, !tbaa !24
  %t724 = load ptr, ptr %lp29
  %t725 = getelementptr %"compiler/doc:Entry", ptr %t724, i32 0, i32 3
  store i64 %t722, ptr %t725, !tbaa !24
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/check:Checker", ptr %t726, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !29
  %t730 = load i64, ptr %l30, !tbaa !24
  %t733 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s17, ptr %t729, i64 %t730)
  store ptr %t733, ptr %l300
  br label %bb157
bb157:
  %t734 = load ptr, ptr %l300, !tbaa !29
  %t736 = getelementptr %"compiler/ast:Func", ptr %t734, i32 0, i32 0
  %t737 = getelementptr %"compiler/source:Span", ptr %t736, i32 0, i32 0
  %t738 = load i32, ptr %t737, !tbaa !23
  %t740 = sext i32 %t738 to i64
  %t742 = load ptr, ptr %lp29
  %t743 = getelementptr %"compiler/doc:Entry", ptr %t742, i32 0, i32 4
  store i64 %t740, ptr %t743, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t744 = load ptr, ptr %lp13
  %t745 = getelementptr %"compiler/doc:Entry", ptr %t744, i32 0, i32 5
  %t746 = load ptr, ptr %lp29
  call void @llvm.memmove.p0.p0.i64(ptr %l305, ptr %t746, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t748, ptr %l305, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t745, ptr %t748)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb161:
  %t749 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t751 = call { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v4, ptr %v4, { i64, ptr } %t749)
  store { i64, ptr } %t751, ptr %l307
  br label %bb162
bb162:
  %t752 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t752, ptr %lp32
  %t753 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t754 = load ptr, ptr %lp32
  store { i64, ptr } %t753, ptr %t754, !tbaa !27
  %t755 = load i1, ptr %l5, !tbaa !21
  %t757 = xor i1 %t755, true
  br i1 %t757, label %bb163, label %bb164
bb163:
  %t759 = load ptr, ptr %lp32
  %t760 = load { i64, ptr }, ptr %t759, !tbaa !27
  %t762 = call i1 @compiler_2fdoc_2eExported(ptr %v4, { i64, ptr } %t760)
  store i1 %t762, ptr %l312
  br label %bb165
bb164:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb166
bb165:
  %t763 = load i1, ptr %l312, !tbaa !21
  %t764 = xor i1 %t763, true
  store i1 %t764, ptr %l310, !tbaa !21
  br label %bb166
bb166:
  %t766 = load i1, ptr %l310, !tbaa !21
  br i1 %t766, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb168:
  br label %bb169
bb169:
  %t767 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t768 = load ptr, ptr %lp32
  %t769 = load { i64, ptr }, ptr %t768, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t770, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t767, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } %t769)
  call void @llvm.memmove.p0.p0.i64(ptr %l316, ptr %t770, i64 152, i1 false)
  br label %bb170
bb170:
  %t773 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 152, i64 8)
  store ptr %t773, ptr %lp33
  %t774 = load ptr, ptr %lp33
  call void @llvm.memmove.p0.p0.i64(ptr %t774, ptr %l316, i64 152, i1 false)
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load i64, ptr %l3, !tbaa !24
  %t777 = load i32, ptr %l14, !tbaa !23
  %t778 = load ptr, ptr %lp32
  %t779 = load { i64, ptr }, ptr %t778, !tbaa !27
  %t784 = call i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v4, ptr %t775, i64 %t776, i32 %t777, { i64, ptr } %t779)
  store i64 %t784, ptr %l321
  br label %bb171
bb171:
  %t785 = load i64, ptr %l321, !tbaa !24
  store i64 %t785, ptr %l34, !tbaa !24
  %t786 = load i64, ptr %l34, !tbaa !24
  %t788 = icmp sge i64 %t786, 0
  br i1 %t788, label %bb172, label %bb173
bb172:
  %t790 = load i64, ptr %l11, !tbaa !24
  %t792 = icmp slt i64 %t790, 0
  br i1 %t792, label %bb174, label %bb175
bb173:
  br label %bb187
bb174:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb178
bb175:
  %t794 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t795 = load i64, ptr %l34, !tbaa !24
  %t798 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t794, i64 %t795)
  store i64 %t798, ptr %l329
  br label %bb176
bb176:
  %t799 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t800 = load i64, ptr %l11, !tbaa !24
  %t803 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t799, i64 %t800)
  store i64 %t803, ptr %l332
  br label %bb177
bb177:
  %t804 = load i64, ptr %l329, !tbaa !24
  %t805 = load i64, ptr %l332, !tbaa !24
  %t806 = icmp ne i64 %t804, %t805
  store i1 %t806, ptr %l326, !tbaa !21
  br label %bb178
bb178:
  %t808 = load i1, ptr %l326, !tbaa !21
  br i1 %t808, label %bb179, label %bb180
bb179:
  %t809 = call ptr @__olang_scope_hold(ptr %v4)
  %t810 = ptrtoint ptr %t809 to i64
  store i64 %t810, ptr %l334, !tbaa !24
  %t811 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t811, label %bb181, label %bb182
bb180:
  br label %bb186
bb181:
  %t813 = call ptr @__olang_region_make(ptr %v4)
  %t814 = ptrtoint ptr %t813 to i64
  store i64 %t814, ptr %l334, !tbaa !24
  br label %bb182
bb182:
  %t815 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t816 = load i64, ptr %l34, !tbaa !24
  %t817 = load i64, ptr %l334
  %t818 = inttoptr i64 %t817 to ptr
  %t821 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %t818, { i64, ptr } %t815, i64 %t816, i1 true)
  store { i64, ptr } %t821, ptr %l338
  br label %bb183
bb183:
  %t822 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t823 = load i64, ptr %l334
  %t824 = inttoptr i64 %t823 to ptr
  %t825 = extractvalue { i64, ptr } %t822, 0
  %t826 = extractvalue { i64, ptr } %t822, 1
  %t827 = mul i64 %t825, 1
  %t828 = call ptr @__olang_held_alloc(ptr %t824, i64 %t827)
  call void @llvm.memcpy.p0.p0.i64(ptr %t828, ptr %t826, i64 %t827, i1 false)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t828, 1
  %t831 = load ptr, ptr %lp33
  %t832 = getelementptr %"compiler/doc:Entry", ptr %t831, i32 0, i32 1
  %t833 = load { i64, ptr }, ptr %t832, !tbaa !27
  store { i64, ptr } %t833, ptr %l340, !tbaa !27
  %t835 = load ptr, ptr %lp33
  %t836 = getelementptr %"compiler/doc:Entry", ptr %t835, i32 0, i32 1
  store { i64, ptr } %t830, ptr %t836, !tbaa !27
  %t837 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t837, label %bb184, label %bb185
bb184:
  %t839 = load { i64, ptr }, ptr %l340
  %t840 = extractvalue { i64, ptr } %t839, 1
  call void @__olang_region_release(ptr %t840)
  store { i64, ptr } zeroinitializer, ptr %l340
  br label %bb185
bb185:
  br label %bb186
bb186:
  %t841 = load ptr, ptr %l6, !tbaa !29
  %t843 = getelementptr %"compiler/load:Module", ptr %t841, i32 0, i32 4
  %t844 = load i64, ptr %t843, !tbaa !24
  %t846 = load ptr, ptr %lp33
  %t847 = getelementptr %"compiler/doc:Entry", ptr %t846, i32 0, i32 3
  store i64 %t844, ptr %t847, !tbaa !24
  %t848 = load i64, ptr %l34, !tbaa !24
  %t850 = load ptr, ptr %lp33
  %t851 = getelementptr %"compiler/doc:Entry", ptr %t850, i32 0, i32 4
  store i64 %t848, ptr %t851, !tbaa !24
  br label %bb187
bb187:
  %t852 = load ptr, ptr %lp13
  %t853 = getelementptr %"compiler/doc:Entry", ptr %t852, i32 0, i32 5
  %t854 = load ptr, ptr %lp33
  call void @llvm.memmove.p0.p0.i64(ptr %l346, ptr %t854, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t856, ptr %l346, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v4, ptr %v4, ptr %t853, ptr %t856)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s6)
  br label %bb189
bb189:
  %t857 = load i64, ptr %l21, !tbaa !24
  %t860 = add i64 %t857, 1
  store i64 %t860, ptr %l21, !tbaa !24
  br label %bb68
bb190:
  %t862 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %l350, ptr %t862, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l350, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/doc:Module"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca %"compiler/doc:Module"
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca %"compiler/doc:Entry"
  %l37 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l9, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t3)
  store { i64, ptr } %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t21, { i64, ptr } %t19)
  br label %bb3
bb3:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb6:
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/doc:Module", ptr %t41, i64 %t38
  %t43 = load %"compiler/doc:Module", ptr %t42
  store %"compiler/doc:Module" %t43, ptr %l24
  %t45 = call ptr @__olang_scope_hold(ptr %s3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l25, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = call ptr @__olang_region_make_part(ptr %s3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t51 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t51, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l27, !tbaa !24
  %t55 = load i64, ptr %l27, !tbaa !24
  %t56 = mul i64 %t55, 152
  %t57 = load i64, ptr %l25
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = load i64, ptr %l27, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load i64, ptr %l29, !tbaa !24
  %t67 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t67, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = icmp slt i64 %t66, %t69
  br i1 %t70, label %bb15, label %bb13
bb12:
  %t72 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t73 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t74 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t73, i32 0, i32 0
  store { i64, ptr } %t72, ptr %t74, !tbaa !27
  %t75 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t75, label %bb17, label %bb18
bb13:
  %t77 = load i64, ptr %l29, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr %"compiler/doc:Entry", ptr %t79, i64 %t77
  call void @llvm.memset.p0.i64(ptr %t80, i8 0, i64 152, i1 false)
  br label %bb14
bb14:
  %t81 = load i64, ptr %l29, !tbaa !24
  %t82 = add i64 %t81, 1
  store i64 %t82, ptr %l29, !tbaa !24
  br label %bb10
bb15:
  %t83 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t84 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t83, i32 0, i32 0
  %t85 = load i64, ptr %l29, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/doc:Entry", ptr %t87, i64 %t85
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t88, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s3, ptr %l32)
  br label %bb16
bb16:
  %t90 = load i64, ptr %l29, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr %"compiler/doc:Entry", ptr %t92, i64 %t90
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %l32, i64 152, i1 false)
  br label %bb14
bb17:
  %t94 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t94, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb19, label %bb20
bb18:
  %t101 = load %"compiler/doc:Module", ptr %l24
  store %"compiler/doc:Module" %t101, ptr %l6
  store ptr %l2, ptr %l37, !tbaa !29
  %t102 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v1, ptr %s3, { i64, ptr } %t103)
  store { i64, ptr } %t105, ptr %l39
  br label %bb21
bb19:
  %t106 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t107 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t107, !tbaa !27
  br label %bb20
bb20:
  %t108 = getelementptr %"compiler/doc:Module", ptr %l24, i32 0, i32 3
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  %t110 = load i64, ptr %l25
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = load { i64, ptr }, ptr %t109
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = call ptr @__olang_region_or(ptr %t113, ptr null)
  %t115 = icmp ne ptr %t114, null
  %t116 = select i1 %t115, ptr %t114, ptr null
  call void @__olang_region_settle_in(ptr %t111, ptr %t116)
  br label %bb18
bb21:
  %t117 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s3, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l41
  br label %bb22
bb22:
  %t121 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t123 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t121, i64 %t122)
  %t138 = getelementptr i8, ptr %t137, i64 %t122
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  call void @olang_textcopy(ptr %t139, ptr %t127, i64 %t128)
  %t140 = getelementptr i8, ptr %t139, i64 %t128
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t137, 1
  %t145 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t145, { i64, ptr } %t143)
  br label %bb23
bb23:
  %t147 = getelementptr %"compiler/doc:Module", ptr %l6, i32 0, i32 2
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t150 = call { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v1, ptr %s3, { i64, ptr } %t148)
  store { i64, ptr } %t150, ptr %l45
  br label %bb24
bb24:
  %t151 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t151, ptr %l7, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t152, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t154, ptr %l47
  br label %bb25
bb25:
  %t155 = load i1, ptr %l47, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l2, ptr %l49, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s3, ptr %s5, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l51
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t161 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t163 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = add i64 %t162, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t161, i64 %t162)
  %t168 = getelementptr i8, ptr %t167, i64 %t162
  call void @olang_textcopy(ptr %t168, ptr %t164, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t172, { i64, ptr } %t170)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t175 = load i64, ptr %l4, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l4, !tbaa !24
  br label %bb4
bb33:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb34
bb34:
  %t181 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t181, ptr %l59, !tbaa !27
  %t183 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t183, ptr %l61
  br label %bb35
bb35:
  %t184 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t187 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %s0, ptr %v2, { i64, ptr } %t185, { i64, ptr } %t184)
  store { i64, ptr } %t187, ptr %l63
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t5, i64 0)
  store i64 %t7, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t13, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t23, i64 %t24)
  store i64 %t27, ptr %l21
  br label %bb10
bb10:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb13:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb15:
  %t45 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t52)
  store i1 %t54, ptr %l30
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b461083f788c6b86_e65d814f8bc052da)
  unreachable
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l1, !tbaa !24
  br label %bb21
bb21:
  br label %bb6
bb22:
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  br i1 %t66, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l40, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = icmp slt i64 %t84, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t94, i64 %t95)
  store i64 %t98, ptr %l49
  br label %bb28
bb27:
  br label %bb48
bb28:
  %t99 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb31:
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = load i64, ptr %l50, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb33:
  %t112 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = load i64, ptr %l49, !tbaa !24
  %t116 = getelementptr i8, ptr %t113, i64 %t114
  %t117 = sub i64 %t115, %t114
  %t118 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t116, 1
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t119)
  store { i64, ptr } %t121, ptr %l55
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b4b87f1043b41663_258689a2c0d07437)
  unreachable
bb35:
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t122, ptr %l4, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t125, ptr %l57
  br label %bb36
bb36:
  %t126 = load i1, ptr %l57, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t131, ptr %l61
  br label %bb39
bb38:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb40
bb39:
  %t132 = load i1, ptr %l61, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb40
bb40:
  %t135 = load i1, ptr %l59, !tbaa !21
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s5, { i64, ptr } %t136, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t138, ptr %l65
  br label %bb43
bb42:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb44
bb43:
  %t139 = load i1, ptr %l65, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t142 = load i1, ptr %l63, !tbaa !21
  br i1 %t142, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t143, ptr %l68, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l69, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l70, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l69, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t159 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t159, ptr %l71
  br label %bb49
bb49:
  %t160 = load %"std/prelude/text:StringBuilder", ptr %l71
  store %"std/prelude/text:StringBuilder" %t160, ptr %l5
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %l6, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb52:
  br label %bb53
bb53:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t171, i64 %t172)
  store i64 %t175, ptr %l79
  br label %bb54
bb54:
  %t176 = load i64, ptr %l79, !tbaa !24
  store i64 %t176, ptr %l7, !tbaa !24
  %t177 = load i64, ptr %l6, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = icmp sgt i64 %t177, %t178
  br i1 %t181, label %bb55, label %bb56
bb55:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 10)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  store ptr %l5, ptr %l84, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l85, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  store i64 %t185, ptr %l86, !tbaa !24
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l87, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l88, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb59, label %bb60
bb59:
  %t192 = load i64, ptr %l86, !tbaa !24
  %t193 = load i64, ptr %l87, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb61:
  %t196 = load i64, ptr %l87, !tbaa !24
  %t197 = load i64, ptr %l88, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb63:
  %t200 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l86, !tbaa !24
  %t203 = load i64, ptr %l87, !tbaa !24
  %t204 = getelementptr i8, ptr %t201, i64 %t202
  %t205 = sub i64 %t203, %t202
  %t206 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t204, 1
  %t209 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l93
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_a37384dcd940e048_c3ba5fc94841a74c)
  unreachable
bb65:
  %t210 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t211 = load ptr, ptr %l84, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t211, { i64, ptr } %t210)
  br label %bb66
bb66:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb67:
  br label %bb50
bb68:
  %t218 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t218, ptr %l98
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t219 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t219, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca %"compiler/names:Entry"
  %lp21 = alloca ptr
  %l22 = alloca i64
  %lp23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %lp31 = alloca ptr
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %lp34 = alloca ptr
  %lp35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"compiler/doc:Module"
  %l82 = alloca ptr
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca i64
  %l131 = alloca %"compiler/names:Entry"
  %l134 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca i1
  %l143 = alloca { i64, ptr }
  %l144 = alloca i1
  %l151 = alloca i64
  %l154 = alloca i1
  %l158 = alloca ptr
  %l166 = alloca i1
  %l170 = alloca %"compiler/doc:Entry"
  %l177 = alloca %"compiler/doc:Entry"
  %l178 = alloca i32
  %l180 = alloca i1
  %l182 = alloca %"compiler/doc:Entry"
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l218 = alloca ptr
  %l220 = alloca i1
  %l221 = alloca i1
  %l225 = alloca i64
  %l228 = alloca i1
  %l231 = alloca i32
  %l236 = alloca { i64, ptr }
  %l240 = alloca i1
  %l242 = alloca i1
  %l244 = alloca i64
  %l246 = alloca i64
  %l251 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i64
  %l261 = alloca { i64, ptr }
  %l264 = alloca %"compiler/doc:Entry"
  %l270 = alloca i64
  %l274 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l281 = alloca %"compiler/doc:Entry"
  %l285 = alloca i64
  %l288 = alloca i1
  %l295 = alloca { i64, ptr }
  %l299 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i64
  %l308 = alloca i64
  %l313 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l317 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca %"compiler/doc:Entry"
  %l332 = alloca i64
  %l336 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l343 = alloca %"compiler/doc:Entry"
  %l352 = alloca i64
  %l356 = alloca i64
  %l359 = alloca i64
  %l377 = alloca ptr
  %l378 = alloca i64
  %l379 = alloca ptr
  %l380 = alloca i64
  %l383 = alloca %"compiler/doc:Entry"
  %l385 = alloca %"compiler/doc:Entry"
  %l386 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca %"compiler/doc:Module"
  %t186 = alloca { ptr, ptr }, align 8
  %t319 = alloca %"compiler/doc:Entry", align 8
  %t339 = alloca %"compiler/doc:Entry", align 8
  %t525 = alloca %"compiler/doc:Entry", align 8
  %t593 = alloca %"compiler/doc:Entry", align 8
  %t707 = alloca %"compiler/doc:Entry", align 8
  %t775 = alloca %"compiler/doc:Entry", align 8
  %t848 = alloca %"compiler/doc:Entry", align 8
  %t851 = alloca %"compiler/doc:Entry", align 8
  %t853 = alloca %"compiler/doc:Entry", align 8
  %t856 = alloca %"compiler/doc:Entry", align 8
  %t859 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l47
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l47, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c14737b94c4967d9_488ba51a50b8fbfd)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l55, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e0
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = call ptr @__olang_region_make(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l55, !tbaa !24
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/load:Module", ptr %t37, i32 0, i32 2
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = load i64, ptr %l55
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call ptr @__olang_held_alloc(ptr %t45, i64 %t43)
  call void @olang_textcopy(ptr %t46, ptr %t42, i64 %t43)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l60, !tbaa !27
  %t50 = call ptr @__olang_scope_hold(ptr %v3)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l61, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e1
  br i1 %t52, label %bb7, label %bb8
bb7:
  %t54 = call ptr @__olang_region_make(ptr %v3)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l61, !tbaa !24
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = load i64, ptr %l61
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call ptr @__olang_held_alloc(ptr %t64, i64 %t62)
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l66, !tbaa !27
  %t69 = call ptr @__olang_scope_hold(ptr %v3)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l67, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e2
  br i1 %t71, label %bb9, label %bb10
bb9:
  %t73 = call ptr @__olang_region_make(ptr %v3)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l67, !tbaa !24
  br label %bb10
bb10:
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t76 = load i64, ptr %l67
  %t77 = inttoptr i64 %t76 to ptr
  %t79 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %t77, { i64, ptr } %t75)
  store { i64, ptr } %t79, ptr %l70
  br label %bb11
bb11:
  %t80 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t81 = load i64, ptr %l67
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_held_alloc(ptr %t82, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t92 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t89, { i64, ptr } %t90, { i64, ptr } %t88)
  store %"compiler/doc:Module" %t92, ptr %l72
  br label %bb12
bb12:
  %t93 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 80, i64 8)
  store ptr %t93, ptr %lp7
  %t94 = load %"compiler/doc:Module", ptr %l72
  %t95 = load ptr, ptr %lp7
  store %"compiler/doc:Module" %t94, ptr %t95
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/names:Resolver", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store ptr %t119, ptr %l82
  br label %bb13
bb13:
  %t120 = load ptr, ptr %l82, !tbaa !29
  store ptr %t120, ptr %l9, !tbaa !29
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l83
  br label %bb14
bb14:
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t123 = load ptr, ptr %l9, !tbaa !29
  %t125 = getelementptr %"compiler/names:Table", ptr %t123, i32 0, i32 0
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t125)
  store i64 %t127, ptr %l86
  br label %bb15
bb15:
  %t128 = load i64, ptr %l86, !tbaa !24
  store i64 %t128, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb16, label %bb17
bb16:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb21
bb18:
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l13, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l93, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb20
bb20:
  %t155 = load i64, ptr %l93, !tbaa !24
  store i64 %t155, ptr %l90, !tbaa !24
  br label %bb21
bb21:
  %t156 = load i64, ptr %l90, !tbaa !24
  store i64 %t156, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb22
bb22:
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t173)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t178 = load i64, ptr %l15, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l15, !tbaa !24
  br label %bb22
bb28:
  %t183 = load ptr, ptr %l9, !tbaa !29
  %t184 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t185 = ptrtoint ptr %t184 to i64
  %t187 = getelementptr { ptr, ptr }, ptr %t186, i32 0, i32 0
  store ptr %t183, ptr %t187, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t189 = call ptr @__olang_scope_hold(ptr %v0)
  %t190 = getelementptr { ptr, ptr }, ptr %t186, i32 0, i32 1
  store ptr %t189, ptr %t190, !tbaa !28
  %t191 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_40, 0
  %t192 = insertvalue { ptr, ptr } %t191, ptr %t186, 1
  %t195 = extractvalue { ptr, ptr } %t192, 0
  %t196 = extractvalue { ptr, ptr } %t192, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l10, ptr %t195, ptr %t196)
  br label %bb29
bb29:
  store ptr %l10, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t198 = load i64, ptr %l18, !tbaa !24
  store i64 %t198, ptr %l120, !tbaa !24
  %t199 = load ptr, ptr %l17, !tbaa !29
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t199)
  store i64 %t201, ptr %l122
  br label %bb31
bb31:
  %t202 = load i64, ptr %l120, !tbaa !24
  %t203 = load i64, ptr %l122, !tbaa !24
  %t204 = icmp slt i64 %t202, %t203
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb33:
  br label %bb34
bb34:
  %t208 = load ptr, ptr %l17, !tbaa !29
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l127
  br label %bb35
bb35:
  %t213 = load i64, ptr %l127, !tbaa !24
  %t214 = load ptr, ptr %l9, !tbaa !29
  %t216 = getelementptr %"compiler/names:Table", ptr %t214, i32 0, i32 0
  %t220 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t216, i64 %t213)
  store %"compiler/names:Entry" %t220, ptr %l131
  br label %bb36
bb36:
  %t221 = load %"compiler/names:Entry", ptr %l131
  store %"compiler/names:Entry" %t221, ptr %l20
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t223 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t224 = load i32, ptr %t223, !tbaa !23
  %t227 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s7, ptr %t222, i32 %t224)
  store { i64, ptr } %t227, ptr %l134
  br label %bb37
bb37:
  %t228 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t229, i64 %t230)
  %t232 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t234, ptr %lp21
  %t236 = load ptr, ptr %lp21
  store { i64, ptr } %t233, ptr %t236, !tbaa !27
  %t237 = load i1, ptr %l4, !tbaa !21
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb38, label %bb39
bb38:
  %t241 = load ptr, ptr %lp21
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  %t244 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t242)
  store i1 %t244, ptr %l140
  br label %bb40
bb39:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb41
bb40:
  %t245 = load i1, ptr %l140, !tbaa !21
  %t246 = xor i1 %t245, true
  store i1 %t246, ptr %l138, !tbaa !21
  br label %bb41
bb41:
  %t248 = load i1, ptr %l138, !tbaa !21
  br i1 %t248, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb43:
  br label %bb44
bb44:
  %t249 = load ptr, ptr %lp21
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l143, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t253 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s7, { i64, ptr } %t250, { i64, ptr } %t252)
  store i1 %t253, ptr %l144
  br label %bb45
bb45:
  %t254 = load i1, ptr %l144, !tbaa !21
  br i1 %t254, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb47:
  br label %bb48
bb48:
  %t255 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t256 = load i32, ptr %t255, !range !{i32 0, i32 9}
  %t258 = trunc i64 3 to i32
  %t259 = icmp eq i32 %t256, %t258
  br i1 %t259, label %bb49, label %bb50
bb49:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t265 = load i64, ptr %l3, !tbaa !24
  %t266 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t271 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t264, i64 %t265, i32 %t267)
  store i64 %t271, ptr %l151
  br label %bb51
bb50:
  %t272 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t273 = load i32, ptr %t272, !range !{i32 0, i32 9}
  %t275 = trunc i64 2 to i32
  %t276 = icmp eq i32 %t273, %t275
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb59, label %bb60
bb51:
  %t280 = load i64, ptr %l151, !tbaa !24
  store i64 %t280, ptr %l22, !tbaa !24
  %t281 = load i64, ptr %l22, !tbaa !24
  %t283 = icmp slt i64 %t281, 0
  br i1 %t283, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb55
bb53:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = load i64, ptr %l22, !tbaa !24
  %t292 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t288, i64 %t289)
  store ptr %t292, ptr %l158
  br label %bb54
bb54:
  %t293 = load ptr, ptr %l158, !tbaa !29
  %t295 = getelementptr %"compiler/ast:Func", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  %t300 = xor i1 %t298, true
  store i1 %t300, ptr %l154, !tbaa !21
  br label %bb55
bb55:
  %t302 = load i1, ptr %l154, !tbaa !21
  br i1 %t302, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb57:
  br label %bb58
bb58:
  br label %bb65
bb59:
  %t303 = getelementptr %"compiler/names:Entry", ptr %l20, i32 0, i32 2
  %t304 = load i32, ptr %t303, !range !{i32 0, i32 9}
  %t306 = trunc i64 4 to i32
  %t307 = icmp eq i32 %t304, %t306
  %t309 = xor i1 %t307, true
  store i1 %t309, ptr %l166, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb61
bb61:
  %t311 = load i1, ptr %l166, !tbaa !21
  br i1 %t311, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = load i64, ptr %l3, !tbaa !24
  %t316 = load ptr, ptr %lp21
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  %t318 = load i1, ptr %l4, !tbaa !21
  %t326 = call i32 @compiler_2fdoc_2eEntry_2eitem(ptr %t319, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t312, ptr %t313, ptr %a2, i64 %t315, { i64, ptr } %t317, i1 %t318)
  store i32 %t326, ptr %l178
  %t327 = icmp ne i32 %t326, 0
  br i1 %t327, label %bb67, label %ok.328, !prof !99
ok.328:
  call void @llvm.memmove.p0.p0.i64(ptr %l177, ptr %t319, i64 152, i1 false)
  br label %bb66
bb66:
  call void @llvm.memmove.p0.p0.i64(ptr %l170, ptr %l177, i64 152, i1 false)
  br label %bb69
bb67:
  %t329 = load i32, ptr %l178, !tbaa !23
  %t330 = ashr i32 %t329, 16
  %t332 = icmp eq i32 %t330, 1
  store i1 %t332, ptr %l180, !tbaa !21
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb69:
  %t333 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t333, ptr %lp23
  %t334 = load ptr, ptr %lp23
  call void @llvm.memmove.p0.p0.i64(ptr %t334, ptr %l170, i64 152, i1 false)
  %t335 = load ptr, ptr %lp7
  %t336 = getelementptr %"compiler/doc:Module", ptr %t335, i32 0, i32 3
  %t337 = load ptr, ptr %lp23
  call void @llvm.memmove.p0.p0.i64(ptr %l182, ptr %t337, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t339, ptr %l182, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t336, ptr %t339)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb71:
  %t340 = load i64, ptr %l18, !tbaa !24
  %t343 = add i64 %t340, 1
  store i64 %t343, ptr %l18, !tbaa !24
  br label %bb30
bb72:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t348)
  br label %bb73
bb73:
  store i64 0, ptr %l24, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t353)
  store i64 %t355, ptr %l190
  br label %bb74
bb74:
  %t356 = load i64, ptr %l190, !tbaa !24
  store i64 %t356, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t357 = load i64, ptr %l25, !tbaa !24
  %t358 = load i64, ptr %l24, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb75, label %bb76
bb75:
  %t363 = load i64, ptr %l26, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb80
bb77:
  %t367 = load i64, ptr %l25, !tbaa !24
  %t368 = load i64, ptr %l24, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l26, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l26, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l197, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb79
bb79:
  %t383 = load i64, ptr %l197, !tbaa !24
  store i64 %t383, ptr %l194, !tbaa !24
  br label %bb80
bb80:
  %t384 = load i64, ptr %l194, !tbaa !24
  store i64 %t384, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t385 = load i64, ptr %l28, !tbaa !24
  %t386 = load i64, ptr %l27, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s18)
  br label %bb156
bb83:
  br label %bb84
bb84:
  %t393 = load i64, ptr %l24, !tbaa !24
  %t394 = load i64, ptr %l28, !tbaa !24
  %t395 = load i64, ptr %l26, !tbaa !24
  %t398 = mul i64 %t394, %t395
  %t401 = add i64 %t393, %t398
  store i64 %t401, ptr %l29, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t407 = load i64, ptr %l29, !tbaa !24
  %t410 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t406, i64 %t407)
  store ptr %t410, ptr %l218
  br label %bb85
bb85:
  %t411 = load ptr, ptr %l218, !tbaa !29
  store ptr %t411, ptr %l30, !tbaa !29
  %t412 = load ptr, ptr %l30, !tbaa !29
  %t414 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t412)
  store i1 %t414, ptr %l220
  br label %bb86
bb86:
  %t415 = load i1, ptr %l220, !tbaa !21
  br i1 %t415, label %bb87, label %bb88
bb87:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/check:Checker", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t420 = load i64, ptr %l29, !tbaa !24
  %t423 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t419, i64 %t420)
  store i64 %t423, ptr %l225
  br label %bb89
bb88:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb90
bb89:
  %t424 = load i64, ptr %l3, !tbaa !24
  %t425 = load i64, ptr %l225, !tbaa !24
  %t427 = icmp eq i64 %t425, %t424
  store i1 %t427, ptr %l221, !tbaa !21
  br label %bb90
bb90:
  %t429 = load i1, ptr %l221, !tbaa !21
  br i1 %t429, label %bb91, label %bb92
bb91:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i64, ptr %l29, !tbaa !24
  %t434 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t430, i64 %t431)
  store i32 %t434, ptr %l231
  br label %bb93
bb92:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb94
bb93:
  %t435 = load i32, ptr %l231, !tbaa !23
  %t436 = icmp slt i32 %t435, 0
  store i1 %t436, ptr %l228, !tbaa !21
  br label %bb94
bb94:
  %t438 = load i1, ptr %l228, !tbaa !21
  br i1 %t438, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s19
  %t439 = load ptr, ptr %l8, !tbaa !29
  %t440 = load ptr, ptr %l30, !tbaa !29
  %t442 = getelementptr %"compiler/ast:Func", ptr %t440, i32 0, i32 9
  %t443 = load i32, ptr %t442, !tbaa !23
  %t446 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s19, ptr %t439, i32 %t443)
  store { i64, ptr } %t446, ptr %l236
  br label %bb97
bb96:
  br label %bb121
bb97:
  %t447 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t449)
  call void @olang_textcopy(ptr %t450, ptr %t448, i64 %t449)
  %t451 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t453, ptr %lp31
  %t455 = load ptr, ptr %lp31
  store { i64, ptr } %t452, ptr %t455, !tbaa !27
  %t456 = load i1, ptr %l4, !tbaa !21
  %t458 = xor i1 %t456, true
  br i1 %t458, label %bb98, label %bb99
bb98:
  %t460 = load ptr, ptr %lp31
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  %t463 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t461)
  store i1 %t463, ptr %l242
  br label %bb100
bb99:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb101
bb100:
  %t464 = load i1, ptr %l242, !tbaa !21
  %t465 = xor i1 %t464, true
  store i1 %t465, ptr %l240, !tbaa !21
  br label %bb101
bb101:
  %t467 = load i1, ptr %l240, !tbaa !21
  br i1 %t467, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb103:
  br label %bb104
bb104:
  %t468 = call ptr @__olang_scope_hold(ptr %v3)
  %t469 = ptrtoint ptr %t468 to i64
  store i64 %t469, ptr %l244, !tbaa !24
  %t470 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t470, label %bb105, label %bb106
bb105:
  %t472 = call ptr @__olang_region_make(ptr %v3)
  %t473 = ptrtoint ptr %t472 to i64
  store i64 %t473, ptr %l244, !tbaa !24
  br label %bb106
bb106:
  %t474 = call ptr @__olang_scope_hold(ptr %s19)
  %t475 = ptrtoint ptr %t474 to i64
  store i64 %t475, ptr %l246, !tbaa !24
  %t476 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t476, label %bb107, label %bb108
bb107:
  %t478 = call ptr @__olang_region_make(ptr %s19)
  %t479 = ptrtoint ptr %t478 to i64
  store i64 %t479, ptr %l246, !tbaa !24
  br label %bb108
bb108:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t482 = load i64, ptr %l29, !tbaa !24
  %t483 = load i64, ptr %l246
  %t484 = inttoptr i64 %t483 to ptr
  %t488 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %t484, ptr %t480, ptr %t481, i64 %t482)
  store { i64, ptr } %t488, ptr %l251
  br label %bb109
bb109:
  %t489 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t490 = load i64, ptr %l244
  %t491 = inttoptr i64 %t490 to ptr
  %t493 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s19, ptr %t491, { i64, ptr } %t489)
  store { i64, ptr } %t493, ptr %l253
  br label %bb110
bb110:
  %t494 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t494, ptr %l254, !tbaa !27
  %t495 = call ptr @__olang_scope_hold(ptr %v3)
  %t496 = ptrtoint ptr %t495 to i64
  store i64 %t496, ptr %l255, !tbaa !24
  %t497 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t497, label %bb111, label %bb112
bb111:
  %t499 = call ptr @__olang_region_make(ptr %v3)
  %t500 = ptrtoint ptr %t499 to i64
  store i64 %t500, ptr %l255, !tbaa !24
  br label %bb112
bb112:
  %t501 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t502 = load ptr, ptr %l30, !tbaa !29
  %t504 = getelementptr %"compiler/ast:Func", ptr %t502, i32 0, i32 0
  %t505 = getelementptr %"compiler/source:Span", ptr %t504, i32 0, i32 0
  %t506 = load i32, ptr %t505, !tbaa !23
  %t508 = sext i32 %t506 to i64
  %t509 = load i64, ptr %l255
  %t510 = inttoptr i64 %t509 to ptr
  %t513 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t510, { i64, ptr } %t501, i64 %t508)
  store { i64, ptr } %t513, ptr %l261
  br label %bb113
bb113:
  %t514 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t515 = load i64, ptr %l255
  %t516 = inttoptr i64 %t515 to ptr
  %t517 = extractvalue { i64, ptr } %t514, 0
  %t518 = extractvalue { i64, ptr } %t514, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_held_alloc(ptr %t516, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t523 = load ptr, ptr %lp31
  %t524 = load { i64, ptr }, ptr %t523, !tbaa !27
  %t526 = load { i64, ptr }, ptr %l254, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t525, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t526, { i64, ptr } %t522, { i64, ptr } %t524)
  call void @llvm.memmove.p0.p0.i64(ptr %l264, ptr %t525, i64 152, i1 false)
  br label %bb114
bb114:
  %t529 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t529, ptr %lp32
  %t530 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %t530, ptr %l264, i64 152, i1 false)
  %t531 = load ptr, ptr %l5, !tbaa !29
  %t533 = getelementptr %"compiler/load:Module", ptr %t531, i32 0, i32 4
  %t534 = load i64, ptr %t533, !tbaa !24
  %t536 = load ptr, ptr %lp32
  %t537 = getelementptr %"compiler/doc:Entry", ptr %t536, i32 0, i32 3
  store i64 %t534, ptr %t537, !tbaa !24
  %t538 = load ptr, ptr %l30, !tbaa !29
  %t540 = getelementptr %"compiler/ast:Func", ptr %t538, i32 0, i32 0
  %t541 = getelementptr %"compiler/source:Span", ptr %t540, i32 0, i32 0
  %t542 = load i32, ptr %t541, !tbaa !23
  %t544 = sext i32 %t542 to i64
  %t546 = load ptr, ptr %lp32
  %t547 = getelementptr %"compiler/doc:Entry", ptr %t546, i32 0, i32 4
  store i64 %t544, ptr %t547, !tbaa !24
  %t548 = call ptr @__olang_scope_hold(ptr %v3)
  %t549 = ptrtoint ptr %t548 to i64
  store i64 %t549, ptr %l270, !tbaa !24
  %t550 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t550, label %bb115, label %bb116
bb115:
  %t552 = call ptr @__olang_region_make(ptr %v3)
  %t553 = ptrtoint ptr %t552 to i64
  store i64 %t553, ptr %l270, !tbaa !24
  br label %bb116
bb116:
  %t554 = load ptr, ptr %l30, !tbaa !29
  %t555 = load ptr, ptr %l8, !tbaa !29
  %t558 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s19, ptr %t554, ptr %t555)
  store { i64, ptr } %t558, ptr %l274
  br label %bb117
bb117:
  %t559 = load ptr, ptr %lp31
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !27
  %t561 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t566 = add i64 %t563, %t565
  %t568 = extractvalue { i64, ptr } %t560, 1
  %t569 = extractvalue { i64, ptr } %t560, 0
  %t570 = add i64 %t566, %t569
  %t571 = load i64, ptr %l270
  %t572 = inttoptr i64 %t571 to ptr
  %t573 = call ptr @__olang_held_alloc(ptr %t572, i64 %t570)
  call void @olang_textcopy(ptr %t573, ptr %t562, i64 %t563)
  %t574 = getelementptr i8, ptr %t573, i64 %t563
  call void @olang_textcopy(ptr %t574, ptr %t564, i64 %t565)
  %t575 = getelementptr i8, ptr %t574, i64 %t565
  call void @olang_textcopy(ptr %t575, ptr %t568, i64 %t569)
  %t576 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t573, 1
  %t579 = load ptr, ptr %lp32
  %t580 = getelementptr %"compiler/doc:Entry", ptr %t579, i32 0, i32 8
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !27
  store { i64, ptr } %t581, ptr %l278, !tbaa !27
  %t583 = load ptr, ptr %lp32
  %t584 = getelementptr %"compiler/doc:Entry", ptr %t583, i32 0, i32 8
  store { i64, ptr } %t577, ptr %t584, !tbaa !27
  %t585 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t585, label %bb118, label %bb119
bb118:
  %t587 = load { i64, ptr }, ptr %l278
  %t588 = extractvalue { i64, ptr } %t587, 1
  call void @__olang_region_release(ptr %t588)
  store { i64, ptr } zeroinitializer, ptr %l278
  br label %bb119
bb119:
  %t589 = load ptr, ptr %lp7
  %t590 = getelementptr %"compiler/doc:Module", ptr %t589, i32 0, i32 3
  %t591 = load ptr, ptr %lp32
  call void @llvm.memmove.p0.p0.i64(ptr %l281, ptr %t591, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t593, ptr %l281, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t590, ptr %t593)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb121:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/check:Checker", ptr %t594, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !29
  %t598 = load i64, ptr %l29, !tbaa !24
  %t601 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t597, i64 %t598)
  store i64 %t601, ptr %l285
  br label %bb122
bb122:
  %t602 = load i64, ptr %l3, !tbaa !24
  %t603 = load i64, ptr %l285, !tbaa !24
  %t605 = icmp ne i64 %t603, %t602
  br i1 %t605, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l288, !tbaa !21
  br label %bb125
bb124:
  %t607 = load ptr, ptr %l30, !tbaa !29
  %t609 = getelementptr %"compiler/ast:Func", ptr %t607, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t612 = icmp eq ptr %t610, null
  store i1 %t612, ptr %l288, !tbaa !21
  br label %bb125
bb125:
  %t614 = load i1, ptr %l288, !tbaa !21
  br i1 %t614, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb127:
  br label %bb128
bb128:
  %t615 = load ptr, ptr %l8, !tbaa !29
  %t616 = load ptr, ptr %l30, !tbaa !29
  %t618 = getelementptr %"compiler/ast:Func", ptr %t616, i32 0, i32 2
  %t619 = load i32, ptr %t618, !tbaa !23
  %t622 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s18, ptr %t615, i32 %t619)
  store { i64, ptr } %t622, ptr %l295
  br label %bb129
bb129:
  %t623 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t623, 1
  %t625 = extractvalue { i64, ptr } %t623, 0
  %t626 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t625)
  call void @olang_textcopy(ptr %t626, ptr %t624, i64 %t625)
  %t627 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t626, 1
  %t629 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t629, ptr %lp33
  %t631 = load ptr, ptr %lp33
  store { i64, ptr } %t628, ptr %t631, !tbaa !27
  %t632 = load i1, ptr %l4, !tbaa !21
  %t634 = xor i1 %t632, true
  br i1 %t634, label %bb130, label %bb131
bb130:
  %t636 = load ptr, ptr %lp33
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  %t639 = call i1 @compiler_2fdoc_2eExported(ptr %v3, { i64, ptr } %t637)
  store i1 %t639, ptr %l301
  br label %bb132
bb131:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb133
bb132:
  %t640 = load i1, ptr %l301, !tbaa !21
  %t641 = xor i1 %t640, true
  store i1 %t641, ptr %l299, !tbaa !21
  br label %bb133
bb133:
  %t643 = load i1, ptr %l299, !tbaa !21
  br i1 %t643, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb135:
  br label %bb136
bb136:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load i64, ptr %l29, !tbaa !24
  %t648 = call i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %t644, i64 %t645)
  store i64 %t648, ptr %l305
  br label %bb137
bb137:
  %t649 = load i64, ptr %l3, !tbaa !24
  %t650 = load i64, ptr %l305, !tbaa !24
  %t652 = icmp eq i64 %t650, %t649
  br i1 %t652, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb139:
  br label %bb140
bb140:
  %t654 = call ptr @__olang_scope_hold(ptr %s18)
  %t655 = ptrtoint ptr %t654 to i64
  store i64 %t655, ptr %l308, !tbaa !24
  %t656 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t656, label %bb141, label %bb142
bb141:
  %t658 = call ptr @__olang_region_make(ptr %s18)
  %t659 = ptrtoint ptr %t658 to i64
  store i64 %t659, ptr %l308, !tbaa !24
  br label %bb142
bb142:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load ptr, ptr %l1, !tbaa !29
  %t662 = load i64, ptr %l29, !tbaa !24
  %t663 = load i64, ptr %l308
  %t664 = inttoptr i64 %t663 to ptr
  %t668 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %t664, ptr %t660, ptr %t661, i64 %t662)
  store { i64, ptr } %t668, ptr %l313
  br label %bb143
bb143:
  %t669 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t671 = call { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %s18, ptr %v3, { i64, ptr } %t669)
  store { i64, ptr } %t671, ptr %l315
  br label %bb144
bb144:
  %t672 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t672, ptr %lp34
  %t673 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t674 = load ptr, ptr %lp34
  store { i64, ptr } %t673, ptr %t674, !tbaa !27
  %t675 = load ptr, ptr %lp34
  %t676 = load { i64, ptr }, ptr %t675, !tbaa !27
  store { i64, ptr } %t676, ptr %l316, !tbaa !27
  %t677 = call ptr @__olang_scope_hold(ptr %v3)
  %t678 = ptrtoint ptr %t677 to i64
  store i64 %t678, ptr %l317, !tbaa !24
  %t679 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t679, label %bb145, label %bb146
bb145:
  %t681 = call ptr @__olang_region_make(ptr %v3)
  %t682 = ptrtoint ptr %t681 to i64
  store i64 %t682, ptr %l317, !tbaa !24
  br label %bb146
bb146:
  %t683 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t684 = load ptr, ptr %l30, !tbaa !29
  %t686 = getelementptr %"compiler/ast:Func", ptr %t684, i32 0, i32 0
  %t687 = getelementptr %"compiler/source:Span", ptr %t686, i32 0, i32 0
  %t688 = load i32, ptr %t687, !tbaa !23
  %t690 = sext i32 %t688 to i64
  %t691 = load i64, ptr %l317
  %t692 = inttoptr i64 %t691 to ptr
  %t695 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t692, { i64, ptr } %t683, i64 %t690)
  store { i64, ptr } %t695, ptr %l323
  br label %bb147
bb147:
  %t696 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t697 = load i64, ptr %l317
  %t698 = inttoptr i64 %t697 to ptr
  %t699 = extractvalue { i64, ptr } %t696, 0
  %t700 = extractvalue { i64, ptr } %t696, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_held_alloc(ptr %t698, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t705 = load ptr, ptr %lp33
  %t706 = load { i64, ptr }, ptr %t705, !tbaa !27
  %t708 = load { i64, ptr }, ptr %l316, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t707, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t708, { i64, ptr } %t704, { i64, ptr } %t706)
  call void @llvm.memmove.p0.p0.i64(ptr %l326, ptr %t707, i64 152, i1 false)
  br label %bb148
bb148:
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t711, ptr %lp35
  %t712 = load ptr, ptr %lp35
  call void @llvm.memmove.p0.p0.i64(ptr %t712, ptr %l326, i64 152, i1 false)
  %t713 = load ptr, ptr %l5, !tbaa !29
  %t715 = getelementptr %"compiler/load:Module", ptr %t713, i32 0, i32 4
  %t716 = load i64, ptr %t715, !tbaa !24
  %t718 = load ptr, ptr %lp35
  %t719 = getelementptr %"compiler/doc:Entry", ptr %t718, i32 0, i32 3
  store i64 %t716, ptr %t719, !tbaa !24
  %t720 = load ptr, ptr %l30, !tbaa !29
  %t722 = getelementptr %"compiler/ast:Func", ptr %t720, i32 0, i32 0
  %t723 = getelementptr %"compiler/source:Span", ptr %t722, i32 0, i32 0
  %t724 = load i32, ptr %t723, !tbaa !23
  %t726 = sext i32 %t724 to i64
  %t728 = load ptr, ptr %lp35
  %t729 = getelementptr %"compiler/doc:Entry", ptr %t728, i32 0, i32 4
  store i64 %t726, ptr %t729, !tbaa !24
  %t730 = call ptr @__olang_scope_hold(ptr %v3)
  %t731 = ptrtoint ptr %t730 to i64
  store i64 %t731, ptr %l332, !tbaa !24
  %t732 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t732, label %bb149, label %bb150
bb149:
  %t734 = call ptr @__olang_region_make(ptr %v3)
  %t735 = ptrtoint ptr %t734 to i64
  store i64 %t735, ptr %l332, !tbaa !24
  br label %bb150
bb150:
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t737 = load i64, ptr %l29, !tbaa !24
  %t740 = call { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %s18, ptr %t736, i64 %t737)
  store { i64, ptr } %t740, ptr %l336
  br label %bb151
bb151:
  %t741 = load ptr, ptr %lp33
  %t742 = load { i64, ptr }, ptr %t741, !tbaa !27
  %t743 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t743, 1
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t746 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t747 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t748 = add i64 %t745, %t747
  %t750 = extractvalue { i64, ptr } %t742, 1
  %t751 = extractvalue { i64, ptr } %t742, 0
  %t752 = add i64 %t748, %t751
  %t753 = load i64, ptr %l332
  %t754 = inttoptr i64 %t753 to ptr
  %t755 = call ptr @__olang_held_alloc(ptr %t754, i64 %t752)
  call void @olang_textcopy(ptr %t755, ptr %t744, i64 %t745)
  %t756 = getelementptr i8, ptr %t755, i64 %t745
  call void @olang_textcopy(ptr %t756, ptr %t746, i64 %t747)
  %t757 = getelementptr i8, ptr %t756, i64 %t747
  call void @olang_textcopy(ptr %t757, ptr %t750, i64 %t751)
  %t758 = insertvalue { i64, ptr } undef, i64 %t752, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t755, 1
  %t761 = load ptr, ptr %lp35
  %t762 = getelementptr %"compiler/doc:Entry", ptr %t761, i32 0, i32 8
  %t763 = load { i64, ptr }, ptr %t762, !tbaa !27
  store { i64, ptr } %t763, ptr %l340, !tbaa !27
  %t765 = load ptr, ptr %lp35
  %t766 = getelementptr %"compiler/doc:Entry", ptr %t765, i32 0, i32 8
  store { i64, ptr } %t759, ptr %t766, !tbaa !27
  %t767 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t767, label %bb152, label %bb153
bb152:
  %t769 = load { i64, ptr }, ptr %l340
  %t770 = extractvalue { i64, ptr } %t769, 1
  call void @__olang_region_release(ptr %t770)
  store { i64, ptr } zeroinitializer, ptr %l340
  br label %bb153
bb153:
  %t771 = load ptr, ptr %lp7
  %t772 = getelementptr %"compiler/doc:Module", ptr %t771, i32 0, i32 3
  %t773 = load ptr, ptr %lp35
  call void @llvm.memmove.p0.p0.i64(ptr %l343, ptr %t773, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t775, ptr %l343, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t772, ptr %t775)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb155:
  %t776 = load i64, ptr %l28, !tbaa !24
  %t779 = add i64 %t776, 1
  store i64 %t779, ptr %l28, !tbaa !24
  br label %bb81
bb156:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load i64, ptr %l3, !tbaa !24
  %t783 = load ptr, ptr %lp7
  %t784 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2fdoc_2emembers(ptr %v0, ptr %v3, ptr %t781, i64 %t782, ptr %t783, i1 %t784)
  br label %bb157
bb157:
  store i64 0, ptr %l36, !tbaa !24
  %t789 = load ptr, ptr %lp7
  %t790 = getelementptr %"compiler/doc:Module", ptr %t789, i32 0, i32 3
  %t792 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %t790)
  store i64 %t792, ptr %l352
  br label %bb158
bb158:
  %t793 = load i64, ptr %l352, !tbaa !24
  store i64 %t793, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t794 = load i64, ptr %l37, !tbaa !24
  %t795 = load i64, ptr %l36, !tbaa !24
  %t798 = icmp sgt i64 %t794, %t795
  br i1 %t798, label %bb159, label %bb160
bb159:
  %t800 = load i64, ptr %l38, !tbaa !24
  %t802 = icmp sgt i64 %t800, 0
  br i1 %t802, label %bb161, label %bb162
bb160:
  store i64 0, ptr %l356, !tbaa !24
  br label %bb164
bb161:
  %t804 = load i64, ptr %l37, !tbaa !24
  %t805 = load i64, ptr %l36, !tbaa !24
  %t808 = sub i64 %t804, %t805
  %t809 = load i64, ptr %l38, !tbaa !24
  %t812 = add i64 %t808, %t809
  %t814 = sub i64 %t812, 1
  %t815 = load i64, ptr %l38, !tbaa !24
  %t818 = sdiv i64 %t814, %t815
  store i64 %t818, ptr %l359, !tbaa !24
  br label %bb163
bb162:
  store i64 0, ptr %l359, !tbaa !24
  br label %bb163
bb163:
  %t820 = load i64, ptr %l359, !tbaa !24
  store i64 %t820, ptr %l356, !tbaa !24
  br label %bb164
bb164:
  %t821 = load i64, ptr %l356, !tbaa !24
  store i64 %t821, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb165
bb165:
  store %olang.scope zeroinitializer, ptr %s30
  %t822 = load i64, ptr %l40, !tbaa !24
  %t823 = load i64, ptr %l39, !tbaa !24
  %t826 = icmp slt i64 %t822, %t823
  %t828 = xor i1 %t826, true
  br i1 %t828, label %bb166, label %bb167
bb166:
  call void @__olang_scope_close(ptr %s30)
  br label %bb174
bb167:
  br label %bb168
bb168:
  %t830 = load i64, ptr %l36, !tbaa !24
  %t831 = load i64, ptr %l40, !tbaa !24
  %t832 = load i64, ptr %l38, !tbaa !24
  %t835 = mul i64 %t831, %t832
  %t838 = add i64 %t830, %t835
  store i64 %t838, ptr %l41, !tbaa !24
  %t840 = load ptr, ptr %lp7
  %t841 = getelementptr %"compiler/doc:Module", ptr %t840, i32 0, i32 3
  store ptr %t841, ptr %l377, !tbaa !29
  %t842 = load i64, ptr %l41, !tbaa !24
  store i64 %t842, ptr %l378, !tbaa !24
  %t843 = load ptr, ptr %l0, !tbaa !29
  store ptr %t843, ptr %l379, !tbaa !29
  %t844 = load i64, ptr %l3, !tbaa !24
  store i64 %t844, ptr %l380, !tbaa !24
  %t845 = load ptr, ptr %lp7
  %t846 = getelementptr %"compiler/doc:Module", ptr %t845, i32 0, i32 3
  %t847 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t848, ptr %v3, ptr %v3, ptr %t846, i64 %t847)
  call void @llvm.memmove.p0.p0.i64(ptr %l383, ptr %t848, i64 152, i1 false)
  br label %bb169
bb169:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t851, ptr %s30, ptr %l383)
  call void @llvm.memmove.p0.p0.i64(ptr %l385, ptr %t851, i64 152, i1 false)
  br label %bb170
bb170:
  %t854 = load ptr, ptr %l379, !tbaa !29
  %t855 = load i64, ptr %l380, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t856, ptr %l385, i64 152, i1 false)
  call void @compiler_2fdoc_2eattached(ptr %t853, ptr %v0, ptr %v3, ptr %s30, ptr %v3, ptr %t854, i64 %t855, ptr %t856, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l386, ptr %t853, i64 152, i1 false)
  br label %bb171
bb171:
  %t857 = load ptr, ptr %l377, !tbaa !29
  %t858 = load i64, ptr %l378, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t859, ptr %l386, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t857, i64 %t858, ptr %t859)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s30)
  br label %bb173
bb173:
  %t860 = load i64, ptr %l40, !tbaa !24
  %t863 = add i64 %t860, 1
  store i64 %t863, ptr %l40, !tbaa !24
  br label %bb165
bb174:
  %t865 = load ptr, ptr %lp7
  %t866 = load %"compiler/doc:Module", ptr %t865
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/doc:Module" %t866, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Module", ptr %rv
  ret %"compiler/doc:Module" %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2eTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t1, i64 %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t7, i64 %t8)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l19, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l18, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb5:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb7:
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t38)
  store i64 %t40, ptr %l25
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6)
  unreachable
bb9:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb19
bb11:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l31, !tbaa !24
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = icmp sle i64 0, %t52
  br i1 %t53, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb14:
  %t55 = load i64, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb16:
  %t59 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903)
  unreachable
bb18:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l28, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t90, ptr %l43
  br label %bb23
bb23:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t91, ptr %l6
  store ptr %l6, ptr %l44, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  store i64 %t93, ptr %l46, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t94, 0
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l50, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load i64, ptr %l46, !tbaa !24
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb26:
  %t107 = load i64, ptr %l49, !tbaa !24
  %t108 = load i64, ptr %l50, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb28:
  %t111 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = load i64, ptr %l49, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s0, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l55
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8)
  unreachable
bb30:
  %t121 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t122 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t122, { i64, ptr } %t121)
  br label %bb31
bb31:
  %t124 = load i64, ptr %l3, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp slt i64 %t128, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb34:
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t139 = load i64, ptr %l7, !tbaa !24
  %t142 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t138, i64 %t139)
  store i64 %t142, ptr %l66
  br label %bb36
bb36:
  %t143 = load i64, ptr %l66, !tbaa !24
  store i64 %t143, ptr %l8, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t144, ptr %l67, !tbaa !27
  %t145 = load i64, ptr %l7, !tbaa !24
  store i64 %t145, ptr %l68, !tbaa !24
  %t146 = load i64, ptr %l8, !tbaa !24
  store i64 %t146, ptr %l69, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l70, !tbaa !24
  %t149 = load i64, ptr %l68, !tbaa !24
  %t150 = icmp sge i64 %t149, 0
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t152 = load i64, ptr %l68, !tbaa !24
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = icmp sle i64 %t152, %t153
  br i1 %t154, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb39:
  %t156 = load i64, ptr %l69, !tbaa !24
  %t157 = load i64, ptr %l70, !tbaa !24
  %t158 = icmp sle i64 %t156, %t157
  br i1 %t158, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb41:
  %t160 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = load i64, ptr %l68, !tbaa !24
  %t163 = load i64, ptr %l69, !tbaa !24
  %t164 = getelementptr i8, ptr %t161, i64 %t162
  %t165 = sub i64 %t163, %t162
  %t166 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t164, 1
  store { i64, ptr } %t167, ptr %l9, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t171 = call i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %t169)
  store i1 %t171, ptr %l76
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5)
  unreachable
bb43:
  %t172 = load i1, ptr %l76, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb47
bb45:
  %t175 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l80, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t180 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s2, { i64, ptr } %t178)
  store { i64, ptr } %t180, ptr %l82
  br label %bb46
bb46:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = load i64, ptr %l80, !tbaa !24
  %t185 = sub i64 %t183, %t182
  %t186 = load i64, ptr %l5, !tbaa !24
  %t189 = icmp ne i64 %t185, %t186
  store i1 %t189, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t191 = load i1, ptr %l78, !tbaa !21
  br i1 %t191, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb49:
  br label %bb50
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 10)
  br label %bb51
bb51:
  store ptr %l6, ptr %l88, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t195 = call { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %s2, { i64, ptr } %t193)
  store { i64, ptr } %t195, ptr %l90
  br label %bb52
bb52:
  %t196 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t197 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t197, { i64, ptr } %t196)
  br label %bb53
bb53:
  %t199 = load i64, ptr %l8, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  br label %bb32
bb55:
  %t204 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t204, ptr %l95
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t205, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2eattached(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/doc:Entry"
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca %"compiler/doc:Entry"
  %l10 = alloca %"compiler/doc:Entry"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l18 = alloca %"compiler/doc:Entry"
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l32 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l41 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l68 = alloca i64
  %l73 = alloca %"compiler/doc:Entry"
  %l74 = alloca %"compiler/doc:Entry"
  %l75 = alloca i64
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca %"compiler/doc:Entry"
  %l87 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca %"compiler/doc:Entry"
  %l99 = alloca %"compiler/doc:Entry"
  %l100 = alloca i64
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca %"compiler/doc:Entry"
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l124 = alloca %"compiler/doc:Entry"
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca i64
  %l135 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t270 = alloca %"compiler/doc:Entry", align 8
  %t515 = alloca %"compiler/doc:Entry", align 8
  %t518 = alloca %"compiler/doc:Entry", align 8
  %t525 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 152, i1 false)
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l2, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l9, i64 152, i1 false)
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l11, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make_part(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t7 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = mul i64 %t11, 152
  %t13 = load i64, ptr %l11
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call ptr @__olang_held_alloc(ptr %t14, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  br label %bb3
bb3:
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t24 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = icmp slt i64 %t22, %t25
  br i1 %t26, label %bb8, label %bb6
bb5:
  %t28 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t29 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t30 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t30, !tbaa !27
  %t31 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t31, label %bb10, label %bb11
bb6:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/doc:Entry", ptr %t35, i64 %t33
  call void @llvm.memset.p0.i64(ptr %t36, i8 0, i64 152, i1 false)
  br label %bb7
bb7:
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = add i64 %t37, 1
  store i64 %t38, ptr %l15, !tbaa !24
  br label %bb3
bb8:
  %t39 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t40 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %l15, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/doc:Entry", ptr %t43, i64 %t41
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t44, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v3, ptr %l18)
  br label %bb9
bb9:
  %t46 = load i64, ptr %l15, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/doc:Entry", ptr %t48, i64 %t46
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %l18, i64 152, i1 false)
  br label %bb7
bb10:
  %t50 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb11:
  %t57 = call ptr @__olang_scope_hold(ptr %v3)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l23, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t59, label %bb14, label %bb15
bb12:
  %t61 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t62, !tbaa !27
  br label %bb13
bb13:
  %t63 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 5
  %t64 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %l11
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = load { i64, ptr }, ptr %t64
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = icmp ne ptr %t69, null
  %t71 = select i1 %t70, ptr %t69, ptr null
  call void @__olang_region_settle_in(ptr %t66, ptr %t71)
  br label %bb11
bb14:
  %t72 = call ptr @__olang_region_make_part(ptr %v3)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l23, !tbaa !24
  br label %bb15
bb15:
  %t74 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 7
  %t75 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t74, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l25, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l26, !tbaa !24
  %t79 = load i64, ptr %l26, !tbaa !24
  %t80 = mul i64 %t79, 32
  %t81 = load i64, ptr %l23
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l27, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l26, !tbaa !24
  %t91 = mul i64 %t90, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t93 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 7
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  store { i64, ptr } %t92, ptr %t94, !tbaa !27
  %t95 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t95, label %bb16, label %bb17
bb16:
  %t97 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 7
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb18, label %bb19
bb17:
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t104, ptr %lp4
  %t105 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %l10, i64 152, i1 false)
  %t106 = load ptr, ptr %lp4
  %t107 = getelementptr %"compiler/doc:Entry", ptr %t106, i32 0, i32 8
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t108, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t110, ptr %l32
  br label %bb20
bb18:
  %t111 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 7
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t111, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t112, !tbaa !27
  br label %bb19
bb19:
  %t113 = getelementptr %"compiler/doc:Entry", ptr %l10, i32 0, i32 7
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %l23
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = load { i64, ptr }, ptr %t114
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = call ptr @__olang_region_or(ptr %t118, ptr null)
  %t120 = icmp ne ptr %t119, null
  %t121 = select i1 %t120, ptr %t119, ptr null
  call void @__olang_region_settle_in(ptr %t116, ptr %t121)
  br label %bb17
bb20:
  %t122 = load i1, ptr %l32, !tbaa !21
  br i1 %t122, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s1, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t125, ptr %l34
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t126 = load i1, ptr %l34, !tbaa !21
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = call ptr @__olang_scope_hold(ptr %v3)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l36, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t129, label %bb26, label %bb27
bb25:
  %t131 = call ptr @__olang_scope_hold(ptr %v3)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l41, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t133, label %bb28, label %bb29
bb26:
  %t135 = call ptr @__olang_region_make(ptr %v3)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l36, !tbaa !24
  br label %bb27
bb27:
  %t137 = load ptr, ptr %lp4
  %t138 = getelementptr %"compiler/doc:Entry", ptr %t137, i32 0, i32 2
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = load i64, ptr %l36
  %t144 = inttoptr i64 %t143 to ptr
  %t145 = call ptr @__olang_held_alloc(ptr %t144, i64 %t142)
  call void @olang_textcopy(ptr %t145, ptr %t141, i64 %t142)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l35, !tbaa !27
  br label %bb30
bb28:
  %t150 = call ptr @__olang_region_make(ptr %v3)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l41, !tbaa !24
  br label %bb29
bb29:
  %t152 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t153 = load ptr, ptr %lp4
  %t154 = getelementptr %"compiler/doc:Entry", ptr %t153, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t152, 1
  %t158 = extractvalue { i64, ptr } %t152, 0
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t163 = extractvalue { i64, ptr } %t155, 1
  %t164 = extractvalue { i64, ptr } %t155, 0
  %t165 = add i64 %t161, %t164
  %t166 = load i64, ptr %l41
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_held_alloc(ptr %t167, i64 %t165)
  call void @olang_textcopy(ptr %t168, ptr %t157, i64 %t158)
  %t169 = getelementptr i8, ptr %t168, i64 %t158
  call void @olang_textcopy(ptr %t169, ptr %t159, i64 %t160)
  %t170 = getelementptr i8, ptr %t169, i64 %t160
  call void @olang_textcopy(ptr %t170, ptr %t163, i64 %t164)
  %t171 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t168, 1
  store { i64, ptr } %t172, ptr %l35, !tbaa !27
  br label %bb30
bb30:
  %t175 = load ptr, ptr %lp4
  %t176 = getelementptr %"compiler/doc:Entry", ptr %t175, i32 0, i32 8
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l47, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t179 = load ptr, ptr %lp4
  %t180 = getelementptr %"compiler/doc:Entry", ptr %t179, i32 0, i32 8
  store { i64, ptr } %t178, ptr %t180, !tbaa !27
  %t181 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t183 = load { i64, ptr }, ptr %l47
  %t184 = extractvalue { i64, ptr } %t183, 1
  call void @__olang_region_release(ptr %t184)
  store { i64, ptr } zeroinitializer, ptr %l47
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb33:
  %t185 = load ptr, ptr %lp4
  %t186 = getelementptr %"compiler/doc:Entry", ptr %t185, i32 0, i32 2
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t189, ptr %l50
  br label %bb34
bb34:
  %t190 = load i1, ptr %l50, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb35, label %bb36
bb35:
  %t193 = call ptr @__olang_scope_hold(ptr %v3)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l52, !tbaa !24
  %t195 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t195, label %bb37, label %bb38
bb36:
  br label %bb46
bb37:
  %t197 = call ptr @__olang_region_make(ptr %v3)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l52, !tbaa !24
  br label %bb38
bb38:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t201 = load ptr, ptr %lp4
  %t202 = getelementptr %"compiler/doc:Entry", ptr %t201, i32 0, i32 8
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = load i64, ptr %l52
  %t205 = inttoptr i64 %t204 to ptr
  %t209 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v3, ptr %t205, ptr %t199, i64 %t200, { i64, ptr } %t203)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l57
  br label %bb39
bb39:
  %t210 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t210, label %bb40, label %bb41
bb40:
  %t212 = load i64, ptr %l52
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = call ptr @__olang_region_or(ptr %t216, ptr null)
  %t218 = call ptr @__olang_region_home(ptr %t217)
  %t219 = icmp ne ptr %t218, null
  %t220 = select i1 %t219, ptr %t218, ptr null
  call void @__olang_region_settle_in(ptr %t213, ptr %t220)
  br label %bb41
bb41:
  %t221 = load ptr, ptr %lp4
  %t222 = getelementptr %"compiler/doc:Entry", ptr %t221, i32 0, i32 7
  %t223 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t222
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l59
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t225 = load ptr, ptr %lp4
  %t226 = getelementptr %"compiler/doc:Entry", ptr %t225, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %t226
  %t227 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t227, label %bb42, label %bb43
bb42:
  %t229 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = call ptr @__olang_region_or(ptr %t231, ptr null)
  %t233 = call ptr @__olang_region_home(ptr %t232)
  %t234 = icmp ne ptr %t233, null
  %t235 = select i1 %t234, ptr %t233, ptr null
  call void @__olang_region_drop(ptr %t235)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l59
  br label %bb43
bb43:
  %t236 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t236, label %bb44, label %bb45
bb44:
  %t238 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t239 = load { i64, ptr }, ptr %t238
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  call void @__olang_region_release_part(ptr %t241, i64 %t240)
  store { i64, ptr } zeroinitializer, ptr %t238
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t242 = call ptr @__olang_scope_hold(ptr %v3)
  %t243 = ptrtoint ptr %t242 to i64
  store i64 %t243, ptr %l62, !tbaa !24
  %t244 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t244, label %bb47, label %bb48
bb47:
  %t246 = call ptr @__olang_region_make(ptr %v3)
  %t247 = ptrtoint ptr %t246 to i64
  store i64 %t247, ptr %l62, !tbaa !24
  br label %bb48
bb48:
  %t248 = load i64, ptr %l62
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %t249, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %l64
  br label %bb49
bb49:
  %t251 = load i64, ptr %l62
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = call ptr @__olang_scope_alloc_a(ptr %t252, i64 32, i64 8)
  store ptr %t253, ptr %lp5
  %t254 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t255 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t254, ptr %t255
  %t256 = getelementptr %"compiler/doc:Entry", ptr %l2, i32 0, i32 5
  store ptr %t256, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t258 = load i64, ptr %l7, !tbaa !24
  store i64 %t258, ptr %l66, !tbaa !24
  %t259 = load ptr, ptr %l6, !tbaa !29
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t259)
  store i64 %t261, ptr %l68
  br label %bb51
bb51:
  %t262 = load i64, ptr %l66, !tbaa !24
  %t263 = load i64, ptr %l68, !tbaa !24
  %t264 = icmp slt i64 %t262, %t263
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s6)
  br label %bb101
bb53:
  br label %bb54
bb54:
  %t268 = load ptr, ptr %l6, !tbaa !29
  %t269 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t270, ptr %v1, ptr %v1, ptr %t268, i64 %t269)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t270, i64 152, i1 false)
  br label %bb55
bb55:
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %l73, i64 152, i1 false)
  %t273 = call ptr @__olang_scope_hold(ptr %v1)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l75, !tbaa !24
  %t275 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t275, label %bb56, label %bb57
bb56:
  %t277 = call ptr @__olang_region_make_part(ptr %v1)
  %t278 = ptrtoint ptr %t277 to i64
  store i64 %t278, ptr %l75, !tbaa !24
  br label %bb57
bb57:
  %t279 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t280 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t279, i32 0, i32 0
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  store i64 %t282, ptr %l77, !tbaa !24
  %t283 = load i64, ptr %l77, !tbaa !24
  %t284 = mul i64 %t283, 152
  %t285 = load i64, ptr %l75
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call ptr @__olang_held_alloc(ptr %t286, i64 %t284)
  %t288 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l78, !tbaa !27
  store i64 0, ptr %l79, !tbaa !24
  br label %bb58
bb58:
  %t290 = load i64, ptr %l79, !tbaa !24
  %t291 = load i64, ptr %l77, !tbaa !24
  %t292 = icmp slt i64 %t290, %t291
  br i1 %t292, label %bb59, label %bb60
bb59:
  %t294 = load i64, ptr %l79, !tbaa !24
  %t295 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t296 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t295, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = icmp slt i64 %t294, %t297
  br i1 %t298, label %bb63, label %bb61
bb60:
  %t300 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t301 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t302 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t301, i32 0, i32 0
  store { i64, ptr } %t300, ptr %t302, !tbaa !27
  %t303 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t303, label %bb65, label %bb66
bb61:
  %t305 = load i64, ptr %l79, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr %"compiler/doc:Entry", ptr %t307, i64 %t305
  call void @llvm.memset.p0.i64(ptr %t308, i8 0, i64 152, i1 false)
  br label %bb62
bb62:
  %t309 = load i64, ptr %l79, !tbaa !24
  %t310 = add i64 %t309, 1
  store i64 %t310, ptr %l79, !tbaa !24
  br label %bb58
bb63:
  %t311 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t312 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t311, i32 0, i32 0
  %t313 = load i64, ptr %l79, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr %"compiler/doc:Entry", ptr %t315, i64 %t313
  call void @llvm.memmove.p0.p0.i64(ptr %l82, ptr %t316, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v1, ptr %l82)
  br label %bb64
bb64:
  %t318 = load i64, ptr %l79, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr %"compiler/doc:Entry", ptr %t320, i64 %t318
  call void @llvm.memmove.p0.p0.i64(ptr %t321, ptr %l82, i64 152, i1 false)
  br label %bb62
bb65:
  %t322 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t323 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t322, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 0
  %t327 = icmp eq i64 %t325, 0
  br i1 %t327, label %bb67, label %bb68
bb66:
  %t329 = call ptr @__olang_scope_hold(ptr %v1)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l87, !tbaa !24
  %t331 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t331, label %bb69, label %bb70
bb67:
  %t333 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t334 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t333, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t334, !tbaa !27
  br label %bb68
bb68:
  %t335 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 5
  %t336 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t335, i32 0, i32 0
  %t337 = load i64, ptr %l75
  %t338 = inttoptr i64 %t337 to ptr
  %t339 = load { i64, ptr }, ptr %t336
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = call ptr @__olang_region_or(ptr %t340, ptr null)
  %t342 = icmp ne ptr %t341, null
  %t343 = select i1 %t342, ptr %t341, ptr null
  call void @__olang_region_settle_in(ptr %t338, ptr %t343)
  br label %bb66
bb69:
  %t344 = call ptr @__olang_region_make_part(ptr %v1)
  %t345 = ptrtoint ptr %t344 to i64
  store i64 %t345, ptr %l87, !tbaa !24
  br label %bb70
bb70:
  %t346 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 7
  %t347 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t346, i32 0, i32 0
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l89, !tbaa !27
  %t349 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  store i64 %t350, ptr %l90, !tbaa !24
  %t351 = load i64, ptr %l90, !tbaa !24
  %t352 = mul i64 %t351, 32
  %t353 = load i64, ptr %l87
  %t354 = inttoptr i64 %t353 to ptr
  %t355 = call ptr @__olang_held_alloc(ptr %t354, i64 %t352)
  %t356 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  store { i64, ptr } %t357, ptr %l91, !tbaa !27
  %t358 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = load i64, ptr %l90, !tbaa !24
  %t363 = mul i64 %t362, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t359, ptr %t361, i64 %t363, i1 false)
  %t364 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t365 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 7
  %t366 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t365, i32 0, i32 0
  store { i64, ptr } %t364, ptr %t366, !tbaa !27
  %t367 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t367, label %bb71, label %bb72
bb71:
  %t369 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 7
  %t370 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t369, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 0
  %t374 = icmp eq i64 %t372, 0
  br i1 %t374, label %bb73, label %bb74
bb72:
  %t376 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 152, i64 8)
  store ptr %t376, ptr %lp8
  %t377 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %t377, ptr %l74, i64 152, i1 false)
  %t378 = load ptr, ptr %lp5
  store ptr %t378, ptr %l95, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l96, !tbaa !29
  %t380 = load i64, ptr %l1, !tbaa !24
  store i64 %t380, ptr %l97, !tbaa !24
  %t381 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %l98, ptr %t381, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %l98, i64 152, i1 false)
  %t382 = call ptr @__olang_scope_hold(ptr %v3)
  %t383 = ptrtoint ptr %t382 to i64
  store i64 %t383, ptr %l100, !tbaa !24
  %t384 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t384, label %bb75, label %bb76
bb73:
  %t386 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 7
  %t387 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t386, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t387, !tbaa !27
  br label %bb74
bb74:
  %t388 = getelementptr %"compiler/doc:Entry", ptr %l74, i32 0, i32 7
  %t389 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t388, i32 0, i32 0
  %t390 = load i64, ptr %l87
  %t391 = inttoptr i64 %t390 to ptr
  %t392 = load { i64, ptr }, ptr %t389
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = call ptr @__olang_region_or(ptr %t393, ptr null)
  %t395 = icmp ne ptr %t394, null
  %t396 = select i1 %t395, ptr %t394, ptr null
  call void @__olang_region_settle_in(ptr %t391, ptr %t396)
  br label %bb72
bb75:
  %t397 = call ptr @__olang_region_make_part(ptr %v3)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l100, !tbaa !24
  br label %bb76
bb76:
  %t399 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t400 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t399, i32 0, i32 0
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  store i64 %t402, ptr %l102, !tbaa !24
  %t403 = load i64, ptr %l102, !tbaa !24
  %t404 = mul i64 %t403, 152
  %t405 = load i64, ptr %l100
  %t406 = inttoptr i64 %t405 to ptr
  %t407 = call ptr @__olang_held_alloc(ptr %t406, i64 %t404)
  %t408 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t407, 1
  store { i64, ptr } %t409, ptr %l103, !tbaa !27
  store i64 0, ptr %l104, !tbaa !24
  br label %bb77
bb77:
  %t410 = load i64, ptr %l104, !tbaa !24
  %t411 = load i64, ptr %l102, !tbaa !24
  %t412 = icmp slt i64 %t410, %t411
  br i1 %t412, label %bb78, label %bb79
bb78:
  %t414 = load i64, ptr %l104, !tbaa !24
  %t415 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t416 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t415, i32 0, i32 1
  %t417 = load i64, ptr %t416, !tbaa !24
  %t418 = icmp slt i64 %t414, %t417
  br i1 %t418, label %bb82, label %bb80
bb79:
  %t420 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t421 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t422 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t421, i32 0, i32 0
  store { i64, ptr } %t420, ptr %t422, !tbaa !27
  %t423 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t423, label %bb84, label %bb85
bb80:
  %t425 = load i64, ptr %l104, !tbaa !24
  %t426 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr %"compiler/doc:Entry", ptr %t427, i64 %t425
  call void @llvm.memset.p0.i64(ptr %t428, i8 0, i64 152, i1 false)
  br label %bb81
bb81:
  %t429 = load i64, ptr %l104, !tbaa !24
  %t430 = add i64 %t429, 1
  store i64 %t430, ptr %l104, !tbaa !24
  br label %bb77
bb82:
  %t431 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t432 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t431, i32 0, i32 0
  %t433 = load i64, ptr %l104, !tbaa !24
  %t434 = getelementptr { i64, ptr }, ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr %"compiler/doc:Entry", ptr %t435, i64 %t433
  call void @llvm.memmove.p0.p0.i64(ptr %l107, ptr %t436, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v3, ptr %l107)
  br label %bb83
bb83:
  %t438 = load i64, ptr %l104, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr %"compiler/doc:Entry", ptr %t440, i64 %t438
  call void @llvm.memmove.p0.p0.i64(ptr %t441, ptr %l107, i64 152, i1 false)
  br label %bb81
bb84:
  %t442 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t443 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t442, i32 0, i32 0
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t447 = icmp eq i64 %t445, 0
  br i1 %t447, label %bb86, label %bb87
bb85:
  %t449 = call ptr @__olang_scope_hold(ptr %v3)
  %t450 = ptrtoint ptr %t449 to i64
  store i64 %t450, ptr %l112, !tbaa !24
  %t451 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t451, label %bb88, label %bb89
bb86:
  %t453 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t454 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t453, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t454, !tbaa !27
  br label %bb87
bb87:
  %t455 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 5
  %t456 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t455, i32 0, i32 0
  %t457 = load i64, ptr %l100
  %t458 = inttoptr i64 %t457 to ptr
  %t459 = load { i64, ptr }, ptr %t456
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = call ptr @__olang_region_or(ptr %t460, ptr null)
  %t462 = icmp ne ptr %t461, null
  %t463 = select i1 %t462, ptr %t461, ptr null
  call void @__olang_region_settle_in(ptr %t458, ptr %t463)
  br label %bb85
bb88:
  %t464 = call ptr @__olang_region_make_part(ptr %v3)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l112, !tbaa !24
  br label %bb89
bb89:
  %t466 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 7
  %t467 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t466, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l114, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 0
  store i64 %t470, ptr %l115, !tbaa !24
  %t471 = load i64, ptr %l115, !tbaa !24
  %t472 = mul i64 %t471, 32
  %t473 = load i64, ptr %l112
  %t474 = inttoptr i64 %t473 to ptr
  %t475 = call ptr @__olang_held_alloc(ptr %t474, i64 %t472)
  %t476 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  store { i64, ptr } %t477, ptr %l116, !tbaa !27
  %t478 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = load i64, ptr %l115, !tbaa !24
  %t483 = mul i64 %t482, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t479, ptr %t481, i64 %t483, i1 false)
  %t484 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t485 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 7
  %t486 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t485, i32 0, i32 0
  store { i64, ptr } %t484, ptr %t486, !tbaa !27
  %t487 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t487, label %bb90, label %bb91
bb90:
  %t489 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 7
  %t490 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t489, i32 0, i32 0
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 0
  %t494 = icmp eq i64 %t492, 0
  br i1 %t494, label %bb92, label %bb93
bb91:
  %t496 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t498 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t496, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t498, ptr %l121
  br label %bb94
bb92:
  %t499 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 7
  %t500 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t499, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t500, !tbaa !27
  br label %bb93
bb93:
  %t501 = getelementptr %"compiler/doc:Entry", ptr %l99, i32 0, i32 7
  %t502 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t501, i32 0, i32 0
  %t503 = load i64, ptr %l112
  %t504 = inttoptr i64 %t503 to ptr
  %t505 = load { i64, ptr }, ptr %t502
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = call ptr @__olang_region_or(ptr %t506, ptr null)
  %t508 = icmp ne ptr %t507, null
  %t509 = select i1 %t508, ptr %t507, ptr null
  call void @__olang_region_settle_in(ptr %t504, ptr %t509)
  br label %bb91
bb94:
  %t510 = load i1, ptr %l121, !tbaa !21
  br i1 %t510, label %bb95, label %bb96
bb95:
  %t511 = load ptr, ptr %lp4
  %t512 = getelementptr %"compiler/doc:Entry", ptr %t511, i32 0, i32 8
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l122, !tbaa !27
  br label %bb97
bb96:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l122, !tbaa !27
  br label %bb97
bb97:
  %t516 = load ptr, ptr %l96, !tbaa !29
  %t517 = load i64, ptr %l97, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t518, ptr %l99, i64 152, i1 false)
  %t519 = load { i64, ptr }, ptr %l122, !tbaa !27
  call void @compiler_2fdoc_2eattached(ptr %t515, ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t516, i64 %t517, ptr %t518, { i64, ptr } %t519)
  call void @llvm.memmove.p0.p0.i64(ptr %l124, ptr %t515, i64 152, i1 false)
  br label %bb98
bb98:
  %t520 = load i64, ptr %l62
  %t521 = inttoptr i64 %t520 to ptr
  %t522 = load i64, ptr %l62
  %t523 = inttoptr i64 %t522 to ptr
  %t524 = load ptr, ptr %l95, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t525, ptr %l124, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %t521, ptr %t523, ptr %t524, ptr %t525)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s6)
  br label %bb100
bb100:
  %t526 = load i64, ptr %l7, !tbaa !24
  %t529 = add i64 %t526, 1
  store i64 %t529, ptr %l7, !tbaa !24
  br label %bb50
bb101:
  %t531 = load ptr, ptr %lp5
  %t532 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t531
  %t533 = load ptr, ptr %lp4
  %t534 = getelementptr %"compiler/doc:Entry", ptr %t533, i32 0, i32 5
  %t535 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t534
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t535, ptr %l129
  %t537 = load ptr, ptr %lp4
  %t538 = getelementptr %"compiler/doc:Entry", ptr %t537, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t532, ptr %t538
  %t539 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t539, label %bb102, label %bb103
bb102:
  %t541 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 0
  %t542 = load { i64, ptr }, ptr %t541
  %t543 = extractvalue { i64, ptr } %t542, 1
  %t544 = call ptr @__olang_region_or(ptr %t543, ptr null)
  %t545 = call ptr @__olang_region_home(ptr %t544)
  %t546 = icmp ne ptr %t545, null
  %t547 = select i1 %t546, ptr %t545, ptr null
  call void @__olang_region_drop(ptr %t547)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l129
  br label %bb103
bb103:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb104
bb104:
  %t548 = load i64, ptr %l131, !tbaa !24
  %t549 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 1
  %t550 = load i64, ptr %t549, !tbaa !24
  %t551 = icmp slt i64 %t548, %t550
  br i1 %t551, label %bb105, label %bb106
bb105:
  %t553 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 0
  %t554 = load i64, ptr %l131, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %t553, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr %"compiler/doc:Entry", ptr %t556, i64 %t554
  call void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %t557)
  br label %bb107
bb106:
  %t559 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t559, label %bb108, label %bb109
bb107:
  %t561 = load i64, ptr %l131, !tbaa !24
  %t562 = add i64 %t561, 1
  store i64 %t562, ptr %l131, !tbaa !24
  br label %bb104
bb108:
  %t563 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563
  %t565 = extractvalue { i64, ptr } %t564, 0
  %t566 = extractvalue { i64, ptr } %t564, 1
  call void @__olang_region_release_part(ptr %t566, i64 %t565)
  store { i64, ptr } zeroinitializer, ptr %t563
  br label %bb109
bb109:
  %t567 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l135, ptr %t567, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l135, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/text:LineIter"
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca %"compiler/source:Span"
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"std/prelude/text:LineIter"
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l98 = alloca %"std/prelude/text:StringBuilder"
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l107 = alloca %"std/prelude/text:LineIter"
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l113 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l22
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t37 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t35, i64 %t34)
  store i64 %t37, ptr %l25
  br label %bb5
bb5:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = sub i64 %t43, 1
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l32
  br label %bb6
bb6:
  %t53 = getelementptr %"compiler/source:Span", ptr %l32, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t59 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t57, i64 %t56)
  store i64 %t59, ptr %l35
  br label %bb7
bb7:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load i64, ptr %l2, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb10:
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = load i64, ptr %l39, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb12:
  %t77 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l37, !tbaa !24
  %t80 = load i64, ptr %l38, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s0, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l44
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b)
  unreachable
bb14:
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr ptr, ptr %t93, i64 0
  %t95 = load ptr, ptr %t94, !tbaa !39
  %t97 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t95)
  store %"compiler/source:Span" %t97, ptr %l49
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t98 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l51, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = sub i64 %t105, 1
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l57
  br label %bb19
bb19:
  %t115 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l60, !tbaa !24
  %t121 = load i64, ptr %l51, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb20, label %bb21
bb20:
  %t124 = load i64, ptr %l51, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb22:
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb24:
  %t132 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = getelementptr i8, ptr %t133, i64 %t134
  %t137 = sub i64 %t135, %t134
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t145, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_91fc21a6b7496c0a_24bc2c9db083308e)
  unreachable
bb26:
  store i64 -1, ptr %l4, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l67, !tbaa !24
  %t149 = load i64, ptr %l3, !tbaa !24
  store i64 %t149, ptr %l68, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l69, !tbaa !24
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb27, label %bb28
bb27:
  %t155 = load i64, ptr %l67, !tbaa !24
  %t156 = load i64, ptr %l68, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb29:
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = load i64, ptr %l69, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb31:
  %t163 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l67, !tbaa !24
  %t166 = load i64, ptr %l68, !tbaa !24
  %t167 = getelementptr i8, ptr %t164, i64 %t165
  %t168 = sub i64 %t166, %t165
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t170)
  store %"std/prelude/text:LineIter" %t172, ptr %l74
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f657276e2350bf29_71dbd11cb4dae2ed)
  unreachable
bb33:
  %t173 = load %"std/prelude/text:LineIter", ptr %l74
  store %"std/prelude/text:LineIter" %t173, ptr %l5
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t175 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l5)
  %t176 = extractvalue { i32, { i64, ptr } } %t175, 1
  %t177 = extractvalue { i32, { i64, ptr } } %t175, 0
  store i32 %t177, ptr %l78
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb36, label %ok.179, !prof !99
ok.179:
  store { i64, ptr } %t176, ptr %l77
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t180, ptr %l75, !tbaa !27
  br label %bb38
bb36:
  %t181 = load i32, ptr %l78, !tbaa !23
  %t182 = ashr i32 %t181, 16
  %t184 = icmp eq i32 %t182, 1
  store i1 %t184, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb38:
  %t185 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t185, ptr %l6, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t188 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s5, { i64, ptr } %t186)
  store { i64, ptr } %t188, ptr %l82
  br label %bb39
bb39:
  %t189 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp eq i64 %t190, 0
  br i1 %t192, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  store i64 %t196, ptr %l86, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s5, { i64, ptr } %t197)
  store { i64, ptr } %t199, ptr %l88
  br label %bb43
bb43:
  %t200 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = load i64, ptr %l86, !tbaa !24
  %t204 = sub i64 %t202, %t201
  store i64 %t204, ptr %l7, !tbaa !24
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp slt i64 %t206, 0
  br i1 %t208, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t211 = load i64, ptr %l4, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  store i1 %t214, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t216 = load i1, ptr %l93, !tbaa !21
  br i1 %t216, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l7, !tbaa !24
  store i64 %t217, ptr %l4, !tbaa !24
  br label %bb49
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  br label %bb34
bb51:
  %t219 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t219, ptr %l98
  br label %bb52
bb52:
  %t220 = load %"std/prelude/text:StringBuilder", ptr %l98
  store %"std/prelude/text:StringBuilder" %t220, ptr %l8
  store i1 true, ptr %l9, !tbaa !21
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t221, ptr %l99, !tbaa !27
  %t222 = load i64, ptr %l2, !tbaa !24
  store i64 %t222, ptr %l100, !tbaa !24
  %t223 = load i64, ptr %l3, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l102, !tbaa !24
  %t226 = load i64, ptr %l100, !tbaa !24
  %t227 = icmp sge i64 %t226, 0
  br i1 %t227, label %bb53, label %bb54
bb53:
  %t229 = load i64, ptr %l100, !tbaa !24
  %t230 = load i64, ptr %l101, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  br i1 %t231, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb55:
  %t233 = load i64, ptr %l101, !tbaa !24
  %t234 = load i64, ptr %l102, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb57:
  %t237 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l100, !tbaa !24
  %t240 = load i64, ptr %l101, !tbaa !24
  %t241 = getelementptr i8, ptr %t238, i64 %t239
  %t242 = sub i64 %t240, %t239
  %t243 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t244)
  store %"std/prelude/text:LineIter" %t246, ptr %l107
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_8ef8e25bc783e73c_af1dce04e2424510)
  unreachable
bb59:
  %t247 = load %"std/prelude/text:LineIter", ptr %l107
  store %"std/prelude/text:LineIter" %t247, ptr %l10
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t249 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l10)
  %t250 = extractvalue { i32, { i64, ptr } } %t249, 1
  %t251 = extractvalue { i32, { i64, ptr } } %t249, 0
  store i32 %t251, ptr %l111
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb62, label %ok.253, !prof !99
ok.253:
  store { i64, ptr } %t250, ptr %l110
  br label %bb61
bb61:
  %t254 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t254, ptr %l108, !tbaa !27
  br label %bb64
bb62:
  %t255 = load i32, ptr %l111, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l113, !tbaa !21
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb84
bb64:
  %t259 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t259, ptr %l11, !tbaa !27
  %t260 = load i1, ptr %l9, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb65, label %bb66
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 10)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  store i1 false, ptr %l9, !tbaa !21
  store ptr %l8, ptr %l117, !tbaa !29
  %t265 = load i64, ptr %l4, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb69, label %bb70
bb69:
  %t269 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = load i64, ptr %l4, !tbaa !24
  %t275 = icmp sge i64 %t271, %t272
  store i1 %t275, ptr %l120, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb71
bb71:
  %t277 = load i1, ptr %l120, !tbaa !21
  br i1 %t277, label %bb72, label %bb73
bb72:
  %t278 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t278, ptr %l126, !tbaa !27
  %t279 = load i64, ptr %l4, !tbaa !24
  store i64 %t279, ptr %l127, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t280, 0
  store i64 %t283, ptr %l130, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l131, !tbaa !24
  %t286 = load i64, ptr %l127, !tbaa !24
  %t287 = icmp sge i64 %t286, 0
  br i1 %t287, label %bb74, label %bb75
bb73:
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t291 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s9, { i64, ptr } %t289)
  store { i64, ptr } %t291, ptr %l137
  br label %bb80
bb74:
  %t292 = load i64, ptr %l127, !tbaa !24
  %t293 = load i64, ptr %l130, !tbaa !24
  %t294 = icmp sle i64 %t292, %t293
  br i1 %t294, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb76:
  %t296 = load i64, ptr %l130, !tbaa !24
  %t297 = load i64, ptr %l131, !tbaa !24
  %t298 = icmp sle i64 %t296, %t297
  br i1 %t298, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb78:
  %t300 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l127, !tbaa !24
  %t303 = load i64, ptr %l130, !tbaa !24
  %t304 = getelementptr i8, ptr %t301, i64 %t302
  %t305 = sub i64 %t303, %t302
  %t306 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t304, 1
  store { i64, ptr } %t307, ptr %l125, !tbaa !27
  br label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef)
  unreachable
bb80:
  %t309 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t309, ptr %l125, !tbaa !27
  br label %bb81
bb81:
  %t310 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = call ptr @__olang_scope_of(ptr %t311, ptr null)
  %t313 = call ptr @__olang_scope_hold(ptr %t312)
  %t314 = ptrtoint ptr %t313 to i64
  %t316 = inttoptr i64 %t314 to ptr
  %t317 = load ptr, ptr %l117, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l125, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %t316, ptr %t317, { i64, ptr } %t318)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s9)
  br label %bb83
bb83:
  br label %bb60
bb84:
  %t320 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l8)
  store { i64, ptr } %t320, ptr %l140
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t321 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t321, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecommentText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t8, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = icmp sge i64 1, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = icmp sle i64 1, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb5:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb7:
  %t23 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = getelementptr i8, ptr %t24, i64 1
  %t27 = sub i64 %t25, 1
  %t28 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t33, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a)
  unreachable
bb9:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l20, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  br label %bb19
bb12:
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb14:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb16:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s1, { i64, ptr } %t57)
  store { i64, ptr } %t59, ptr %l26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7)
  unreachable
bb18:
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb19:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s0, { i64, ptr } %t67)
  store { i64, ptr } %t69, ptr %l29
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/doc:Entry"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca %"compiler/doc:Entry"
  %l40 = alloca %"compiler/doc:Entry"
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l48 = alloca %"compiler/doc:Entry"
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca %"compiler/doc:Entry"
  %l89 = alloca %"compiler/doc:Entry"
  %l90 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca %"compiler/doc:Entry"
  %l102 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t80 = alloca %"compiler/doc:Entry", align 8
  %t274 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t24, { i64, ptr } %t22)
  br label %bb3
bb3:
  store ptr %l1, ptr %l16, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/doc:Module", ptr %t26, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l19
  br label %bb4
bb4:
  %t32 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t35, i64 %t36)
  %t43 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t43, ptr %t38, i64 %t39)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t47, { i64, ptr } %t45)
  br label %bb5
bb5:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Module", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t52)
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/doc:Module", ptr %t55, i32 0, i32 3
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l27
  br label %bb7
bb7:
  %t60 = load i64, ptr %l27, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb47
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/doc:Module", ptr %t64, i32 0, i32 3
  store ptr %t66, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l32, !tbaa !24
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l34
  br label %bb12
bb12:
  %t72 = load i64, ptr %l32, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb14:
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t79 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t80, ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t80, i64 152, i1 false)
  br label %bb16
bb16:
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l39, i64 152, i1 false)
  %t83 = call ptr @__olang_scope_hold(ptr %v0)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l41, !tbaa !24
  %t85 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t85, label %bb17, label %bb18
bb17:
  %t87 = call ptr @__olang_region_make_part(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t89 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t90 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l43, !tbaa !24
  %t93 = load i64, ptr %l43, !tbaa !24
  %t94 = mul i64 %t93, 152
  %t95 = load i64, ptr %l41
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call ptr @__olang_held_alloc(ptr %t96, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t100 = load i64, ptr %l45, !tbaa !24
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = load i64, ptr %l45, !tbaa !24
  %t105 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t105, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = icmp slt i64 %t104, %t107
  br i1 %t108, label %bb24, label %bb22
bb21:
  %t110 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t111 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t111, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t112, !tbaa !27
  %t113 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t113, label %bb26, label %bb27
bb22:
  %t115 = load i64, ptr %l45, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/doc:Entry", ptr %t117, i64 %t115
  call void @llvm.memset.p0.i64(ptr %t118, i8 0, i64 152, i1 false)
  br label %bb23
bb23:
  %t119 = load i64, ptr %l45, !tbaa !24
  %t120 = add i64 %t119, 1
  store i64 %t120, ptr %l45, !tbaa !24
  br label %bb19
bb24:
  %t121 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t122 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l45, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/doc:Entry", ptr %t125, i64 %t123
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t126, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l48)
  br label %bb25
bb25:
  %t128 = load i64, ptr %l45, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr %"compiler/doc:Entry", ptr %t130, i64 %t128
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %l48, i64 152, i1 false)
  br label %bb23
bb26:
  %t132 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t137 = icmp eq i64 %t135, 0
  br i1 %t137, label %bb28, label %bb29
bb27:
  %t139 = call ptr @__olang_scope_hold(ptr %v0)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l53, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t141, label %bb30, label %bb31
bb28:
  %t143 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t143, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t144, !tbaa !27
  br label %bb29
bb29:
  %t145 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 5
  %t146 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t145, i32 0, i32 0
  %t147 = load i64, ptr %l41
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %t146
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  br label %bb27
bb30:
  %t154 = call ptr @__olang_region_make_part(ptr %v0)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t156 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 7
  %t157 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t156, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l55, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l56, !tbaa !24
  %t161 = load i64, ptr %l56, !tbaa !24
  %t162 = mul i64 %t161, 32
  %t163 = load i64, ptr %l53
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = call ptr @__olang_held_alloc(ptr %t164, i64 %t162)
  %t166 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  store { i64, ptr } %t167, ptr %l57, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = load i64, ptr %l56, !tbaa !24
  %t173 = mul i64 %t172, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t169, ptr %t171, i64 %t173, i1 false)
  %t174 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t175 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 7
  %t176 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t175, i32 0, i32 0
  store { i64, ptr } %t174, ptr %t176, !tbaa !27
  %t177 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t177, label %bb32, label %bb33
bb32:
  %t179 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 7
  %t180 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t179, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t184 = icmp eq i64 %t182, 0
  br i1 %t184, label %bb34, label %bb35
bb33:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l40, i64 152, i1 false)
  %t186 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 1
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v0, ptr %s5, { i64, ptr } %t187)
  store { i64, ptr } %t189, ptr %l62
  br label %bb36
bb34:
  %t190 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 7
  %t191 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t190, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t191, !tbaa !27
  br label %bb35
bb35:
  %t192 = getelementptr %"compiler/doc:Entry", ptr %l40, i32 0, i32 7
  %t193 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t192, i32 0, i32 0
  %t194 = load i64, ptr %l53
  %t195 = inttoptr i64 %t194 to ptr
  %t196 = load { i64, ptr }, ptr %t193
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = call ptr @__olang_region_or(ptr %t197, ptr null)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  call void @__olang_region_settle_in(ptr %t195, ptr %t200)
  br label %bb33
bb36:
  %t201 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t201, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t203, ptr %l64
  br label %bb37
bb37:
  %t204 = load i1, ptr %l64, !tbaa !21
  %t205 = xor i1 %t204, true
  br i1 %t205, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb40
bb40:
  %t207 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t207, ptr %l5, !tbaa !27
  store ptr %l1, ptr %l67, !tbaa !29
  %t208 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t209)
  store { i64, ptr } %t211, ptr %l69
  br label %bb41
bb41:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t212, ptr %l70, !tbaa !27
  %t213 = getelementptr %"compiler/doc:Entry", ptr %l4, i32 0, i32 2
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  %t216 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %s5, { i64, ptr } %t214)
  store { i64, ptr } %t216, ptr %l72
  br label %bb42
bb42:
  %t217 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t219 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t217, i64 %t218)
  %t241 = getelementptr i8, ptr %t240, i64 %t218
  call void @olang_textcopy(ptr %t241, ptr %t220, i64 %t221)
  %t242 = getelementptr i8, ptr %t241, i64 %t221
  call void @olang_textcopy(ptr %t242, ptr %t223, i64 %t224)
  %t243 = getelementptr i8, ptr %t242, i64 %t224
  call void @olang_textcopy(ptr %t243, ptr %t227, i64 %t228)
  %t244 = getelementptr i8, ptr %t243, i64 %t228
  call void @olang_textcopy(ptr %t244, ptr %t230, i64 %t231)
  %t245 = getelementptr i8, ptr %t244, i64 %t231
  call void @olang_textcopy(ptr %t245, ptr %t234, i64 %t235)
  %t246 = getelementptr i8, ptr %t245, i64 %t235
  call void @olang_textcopy(ptr %t246, ptr %t237, i64 %t238)
  %t247 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t240, 1
  %t250 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t250, { i64, ptr } %t248)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t252 = load i64, ptr %l3, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l3, !tbaa !24
  br label %bb11
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/doc:Module", ptr %t258, i32 0, i32 3
  store ptr %t260, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t262 = load i64, ptr %l7, !tbaa !24
  store i64 %t262, ptr %l81, !tbaa !24
  %t263 = load ptr, ptr %l6, !tbaa !29
  %t265 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t263)
  store i64 %t265, ptr %l83
  br label %bb49
bb49:
  %t266 = load i64, ptr %l81, !tbaa !24
  %t267 = load i64, ptr %l83, !tbaa !24
  %t268 = icmp slt i64 %t266, %t267
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb75
bb51:
  br label %bb52
bb52:
  %t272 = load ptr, ptr %l6, !tbaa !29
  %t273 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t274, ptr %v0, ptr %v0, ptr %t272, i64 %t273)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t274, i64 152, i1 false)
  br label %bb53
bb53:
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %l88, i64 152, i1 false)
  %t277 = call ptr @__olang_scope_hold(ptr %v0)
  %t278 = ptrtoint ptr %t277 to i64
  store i64 %t278, ptr %l90, !tbaa !24
  %t279 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t279, label %bb54, label %bb55
bb54:
  %t281 = call ptr @__olang_region_make_part(ptr %v0)
  %t282 = ptrtoint ptr %t281 to i64
  store i64 %t282, ptr %l90, !tbaa !24
  br label %bb55
bb55:
  %t283 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t284 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t283, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  store i64 %t286, ptr %l92, !tbaa !24
  %t287 = load i64, ptr %l92, !tbaa !24
  %t288 = mul i64 %t287, 152
  %t289 = load i64, ptr %l90
  %t290 = inttoptr i64 %t289 to ptr
  %t291 = call ptr @__olang_held_alloc(ptr %t290, i64 %t288)
  %t292 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l93, !tbaa !27
  store i64 0, ptr %l94, !tbaa !24
  br label %bb56
bb56:
  %t294 = load i64, ptr %l94, !tbaa !24
  %t295 = load i64, ptr %l92, !tbaa !24
  %t296 = icmp slt i64 %t294, %t295
  br i1 %t296, label %bb57, label %bb58
bb57:
  %t298 = load i64, ptr %l94, !tbaa !24
  %t299 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t300 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t299, i32 0, i32 1
  %t301 = load i64, ptr %t300, !tbaa !24
  %t302 = icmp slt i64 %t298, %t301
  br i1 %t302, label %bb61, label %bb59
bb58:
  %t304 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t305 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t306 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t305, i32 0, i32 0
  store { i64, ptr } %t304, ptr %t306, !tbaa !27
  %t307 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t307, label %bb63, label %bb64
bb59:
  %t309 = load i64, ptr %l94, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr %"compiler/doc:Entry", ptr %t311, i64 %t309
  call void @llvm.memset.p0.i64(ptr %t312, i8 0, i64 152, i1 false)
  br label %bb60
bb60:
  %t313 = load i64, ptr %l94, !tbaa !24
  %t314 = add i64 %t313, 1
  store i64 %t314, ptr %l94, !tbaa !24
  br label %bb56
bb61:
  %t315 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t316 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t315, i32 0, i32 0
  %t317 = load i64, ptr %l94, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr %"compiler/doc:Entry", ptr %t319, i64 %t317
  call void @llvm.memmove.p0.p0.i64(ptr %l97, ptr %t320, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l97)
  br label %bb62
bb62:
  %t322 = load i64, ptr %l94, !tbaa !24
  %t323 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr %"compiler/doc:Entry", ptr %t324, i64 %t322
  call void @llvm.memmove.p0.p0.i64(ptr %t325, ptr %l97, i64 152, i1 false)
  br label %bb60
bb63:
  %t326 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t327 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t326, i32 0, i32 0
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t331 = icmp eq i64 %t329, 0
  br i1 %t331, label %bb65, label %bb66
bb64:
  %t333 = call ptr @__olang_scope_hold(ptr %v0)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l102, !tbaa !24
  %t335 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t335, label %bb67, label %bb68
bb65:
  %t337 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t338 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t337, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t338, !tbaa !27
  br label %bb66
bb66:
  %t339 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 5
  %t340 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t339, i32 0, i32 0
  %t341 = load i64, ptr %l90
  %t342 = inttoptr i64 %t341 to ptr
  %t343 = load { i64, ptr }, ptr %t340
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = call ptr @__olang_region_or(ptr %t344, ptr null)
  %t346 = icmp ne ptr %t345, null
  %t347 = select i1 %t346, ptr %t345, ptr null
  call void @__olang_region_settle_in(ptr %t342, ptr %t347)
  br label %bb64
bb67:
  %t348 = call ptr @__olang_region_make_part(ptr %v0)
  %t349 = ptrtoint ptr %t348 to i64
  store i64 %t349, ptr %l102, !tbaa !24
  br label %bb68
bb68:
  %t350 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 7
  %t351 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t350, i32 0, i32 0
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l104, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  store i64 %t354, ptr %l105, !tbaa !24
  %t355 = load i64, ptr %l105, !tbaa !24
  %t356 = mul i64 %t355, 32
  %t357 = load i64, ptr %l102
  %t358 = inttoptr i64 %t357 to ptr
  %t359 = call ptr @__olang_held_alloc(ptr %t358, i64 %t356)
  %t360 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  store { i64, ptr } %t361, ptr %l106, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = load i64, ptr %l105, !tbaa !24
  %t367 = mul i64 %t366, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t363, ptr %t365, i64 %t367, i1 false)
  %t368 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t369 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 7
  %t370 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t369, i32 0, i32 0
  store { i64, ptr } %t368, ptr %t370, !tbaa !27
  %t371 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t371, label %bb69, label %bb70
bb69:
  %t373 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 7
  %t374 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t373, i32 0, i32 0
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t378 = icmp eq i64 %t376, 0
  br i1 %t378, label %bb71, label %bb72
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l89, i64 152, i1 false)
  call void @compiler_2fdoc_2eentryHtml(ptr %s0, ptr %s9, ptr %l1, ptr %l8, i1 false)
  br label %bb73
bb71:
  %t382 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 7
  %t383 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t382, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t383, !tbaa !27
  br label %bb72
bb72:
  %t384 = getelementptr %"compiler/doc:Entry", ptr %l89, i32 0, i32 7
  %t385 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t384, i32 0, i32 0
  %t386 = load i64, ptr %l102
  %t387 = inttoptr i64 %t386 to ptr
  %t388 = load { i64, ptr }, ptr %t385
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = call ptr @__olang_region_or(ptr %t389, ptr null)
  %t391 = icmp ne ptr %t390, null
  %t392 = select i1 %t391, ptr %t390, ptr null
  call void @__olang_region_settle_in(ptr %t387, ptr %t392)
  br label %bb70
bb73:
  call void @__olang_scope_close(ptr %s9)
  br label %bb74
bb74:
  %t393 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t393, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb48
bb75:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/doc:Module", ptr %t398, i32 0, i32 0
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l116, !tbaa !27
  %t403 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t403, ptr %l118
  br label %bb76
bb76:
  %t404 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t407 = call { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %s0, ptr %v1, { i64, ptr } %t405, { i64, ptr } %t404)
  store { i64, ptr } %t407, ptr %l120
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t408 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t408, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/doc:Entry"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/doc:Entry"
  %l29 = alloca %"compiler/doc:Entry"
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca %"compiler/doc:Entry"
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t56 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/doc:Module", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t10 = extractvalue { i64, ptr } %t6, 1
  %t11 = extractvalue { i64, ptr } %t6, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t20)
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/doc:Module", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t29, ptr %l13
  br label %bb3
bb3:
  %t30 = load i1, ptr %l13, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/doc:Module", ptr %t34, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  call void @compiler_2fdoc_2eindented(ptr %s0, ptr %v0, ptr %s2, ptr %l1, { i64, ptr } %t37, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/doc:Module", ptr %t40, i32 0, i32 3
  store ptr %t42, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l3, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l23
  br label %bb10
bb10:
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb12:
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t56, ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t56, i64 152, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %l28, i64 152, i1 false)
  %t59 = call ptr @__olang_scope_hold(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l30, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t63 = call ptr @__olang_region_make_part(ptr %v0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l30, !tbaa !24
  br label %bb16
bb16:
  %t65 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t66 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t65, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l32, !tbaa !24
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = mul i64 %t69, 152
  %t71 = load i64, ptr %l30
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call ptr @__olang_held_alloc(ptr %t72, i64 %t70)
  %t74 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  br label %bb17
bb17:
  %t76 = load i64, ptr %l34, !tbaa !24
  %t77 = load i64, ptr %l32, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t82 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t81, i32 0, i32 1
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = icmp slt i64 %t80, %t83
  br i1 %t84, label %bb22, label %bb20
bb19:
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t87 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t88 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t87, i32 0, i32 0
  store { i64, ptr } %t86, ptr %t88, !tbaa !27
  %t89 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t89, label %bb24, label %bb25
bb20:
  %t91 = load i64, ptr %l34, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/doc:Entry", ptr %t93, i64 %t91
  call void @llvm.memset.p0.i64(ptr %t94, i8 0, i64 152, i1 false)
  br label %bb21
bb21:
  %t95 = load i64, ptr %l34, !tbaa !24
  %t96 = add i64 %t95, 1
  store i64 %t96, ptr %l34, !tbaa !24
  br label %bb17
bb22:
  %t97 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %l34, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr %"compiler/doc:Entry", ptr %t101, i64 %t99
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t102, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l37)
  br label %bb23
bb23:
  %t104 = load i64, ptr %l34, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr %"compiler/doc:Entry", ptr %t106, i64 %t104
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %l37, i64 152, i1 false)
  br label %bb21
bb24:
  %t108 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t113 = icmp eq i64 %t111, 0
  br i1 %t113, label %bb26, label %bb27
bb25:
  %t115 = call ptr @__olang_scope_hold(ptr %v0)
  %t116 = ptrtoint ptr %t115 to i64
  store i64 %t116, ptr %l42, !tbaa !24
  %t117 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t117, label %bb28, label %bb29
bb26:
  %t119 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t120 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t119, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t120, !tbaa !27
  br label %bb27
bb27:
  %t121 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 5
  %t122 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l30
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = load { i64, ptr }, ptr %t122
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = call ptr @__olang_region_or(ptr %t126, ptr null)
  %t128 = icmp ne ptr %t127, null
  %t129 = select i1 %t128, ptr %t127, ptr null
  call void @__olang_region_settle_in(ptr %t124, ptr %t129)
  br label %bb25
bb28:
  %t130 = call ptr @__olang_region_make_part(ptr %v0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l42, !tbaa !24
  br label %bb29
bb29:
  %t132 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 7
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l44, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l45, !tbaa !24
  %t137 = load i64, ptr %l45, !tbaa !24
  %t138 = mul i64 %t137, 32
  %t139 = load i64, ptr %l42
  %t140 = inttoptr i64 %t139 to ptr
  %t141 = call ptr @__olang_held_alloc(ptr %t140, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l46, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l45, !tbaa !24
  %t149 = mul i64 %t148, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t151 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 7
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t151, i32 0, i32 0
  store { i64, ptr } %t150, ptr %t152, !tbaa !27
  %t153 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t153, label %bb30, label %bb31
bb30:
  %t155 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 7
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t155, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb32, label %bb33
bb31:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l29, i64 152, i1 false)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb34
bb32:
  %t163 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 7
  %t164 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t163, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t164, !tbaa !27
  br label %bb33
bb33:
  %t165 = getelementptr %"compiler/doc:Entry", ptr %l29, i32 0, i32 7
  %t166 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t165, i32 0, i32 0
  %t167 = load i64, ptr %l42
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = load { i64, ptr }, ptr %t166
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  call void @__olang_region_settle_in(ptr %t168, ptr %t173)
  br label %bb31
bb34:
  call void @compiler_2fdoc_2eentryText(ptr %s0, ptr %s4, ptr %s4, ptr %l1, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t176 = load i64, ptr %l3, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l3, !tbaa !24
  br label %bb9
bb37:
  %t182 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t182, ptr %l57
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t183 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca i32
  %l47 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i64
  %l69 = alloca ptr
  %l78 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i64
  %l89 = alloca i64
  %l94 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l18, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l21, !tbaa !24
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  br label %bb35
bb7:
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = icmp sle i64 0, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb9:
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb11:
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 0
  %t33 = sub i64 %t31, 0
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i64, ptr %l18, !tbaa !24
  %t39 = call i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %t36, i64 %t37, { i64, ptr } %t35)
  store i32 %t39, ptr %l26
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d85afc985d0ab39_76fcb7f235eece65)
  unreachable
bb13:
  %t40 = load i32, ptr %l26, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp slt i32 %t41, 0
  br i1 %t43, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t60, 0
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb19:
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = load i64, ptr %l40, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb21:
  %t77 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l36, !tbaa !24
  %t80 = load i64, ptr %l39, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t87 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t85, { i64, ptr } %t84)
  store i32 %t87, ptr %l45
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1f1e658c6da2070c_2842ab33ef4c4808)
  unreachable
bb23:
  %t88 = load i32, ptr %l45, !tbaa !23
  store i32 %t88, ptr %l5, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr %l4, !tbaa !23
  %t100 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l51
  br label %bb24
bb24:
  %t101 = load i32, ptr %l5, !tbaa !23
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i32, ptr %l51, !tbaa !23
  %t105 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t102, i32 %t103, i32 %t101)
  store i64 %t105, ptr %l53
  br label %bb25
bb25:
  %t106 = load i64, ptr %l53, !tbaa !24
  store i64 %t106, ptr %l6, !tbaa !24
  %t107 = load i64, ptr %l6, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb26, label %bb27
bb26:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l4, !tbaa !23
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l61
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t123 = load i32, ptr %l5, !tbaa !23
  %t124 = load ptr, ptr %l57, !tbaa !29
  %t125 = load i32, ptr %l61, !tbaa !23
  %t127 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t124, i32 %t125, i32 %t123, i1 true)
  store i64 %t127, ptr %l63
  br label %bb29
bb29:
  %t128 = load i64, ptr %l63, !tbaa !24
  store i64 %t128, ptr %l6, !tbaa !24
  br label %bb30
bb30:
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = icmp sge i64 %t129, 0
  br i1 %t131, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s4, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l69
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t141 = load ptr, ptr %l69, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Func", ptr %t141, i32 0, i32 0
  %t144 = getelementptr %"compiler/source:Span", ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sext i32 %t145 to i64
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t147, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 3
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t162 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t158, { i64, ptr } %t159)
  store i32 %t162, ptr %l78
  br label %bb36
bb36:
  %t163 = load i32, ptr %l78, !tbaa !23
  store i32 %t163, ptr %l7, !tbaa !23
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/names:Resolver", ptr %t170, i32 0, i32 1
  %t173 = load i64, ptr %l1, !tbaa !24
  %t176 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l84
  br label %bb37
bb37:
  %t177 = load ptr, ptr %l84, !tbaa !29
  %t179 = getelementptr %"compiler/names:Table", ptr %t177, i32 0, i32 0
  store ptr %t179, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb38
bb38:
  %t181 = load i64, ptr %l9, !tbaa !24
  store i64 %t181, ptr %l87, !tbaa !24
  %t182 = load ptr, ptr %l8, !tbaa !29
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t182)
  store i64 %t184, ptr %l89
  br label %bb39
bb39:
  %t185 = load i64, ptr %l87, !tbaa !24
  %t186 = load i64, ptr %l89, !tbaa !24
  %t187 = icmp slt i64 %t185, %t186
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t191 = load ptr, ptr %l8, !tbaa !29
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store %"compiler/names:Entry" %t195, ptr %l94
  br label %bb43
bb43:
  %t196 = load %"compiler/names:Entry", ptr %l94
  store %"compiler/names:Entry" %t196, ptr %l10
  %t197 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = load i32, ptr %l7, !tbaa !23
  %t202 = icmp eq i32 %t198, %t199
  br i1 %t202, label %bb44, label %bb45
bb44:
  %t204 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 1
  %t205 = getelementptr %"compiler/source:Span", ptr %t204, i32 0, i32 0
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = sext i32 %t206 to i64
  call void @__olang_scope_close(ptr %s0)
  store i64 %t208, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t210 = load i64, ptr %l9, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l9, !tbaa !24
  br label %bb38
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca { ptr, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i1, ptr %l9, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l11
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t8, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t9 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_76, 0
  %t10 = insertvalue { ptr, ptr } %t9, ptr null, 1
  store { ptr, ptr } %t10, ptr %l4
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t12)
  store %"std/prelude/text:LineIter" %t14, ptr %l14
  br label %bb7
bb7:
  %t15 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t15, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l17
  br label %bb9
bb9:
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb12
bb10:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb12:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = load { ptr, ptr }, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i1, ptr %l3, !tbaa !21
  %t36 = extractvalue { ptr, ptr } %t32, 0
  %t37 = extractvalue { ptr, ptr } %t32, 1
  call void %t36(ptr %t37, ptr %s0, ptr %v0, ptr %l2, ptr %t33, i1 %t34)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb17:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t41, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t43, ptr %l28
  br label %bb18
bb18:
  %t44 = load i1, ptr %l28, !tbaa !21
  store i1 %t44, ptr %l7, !tbaa !21
  %t46 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t46, ptr %l30
  br label %bb19
bb19:
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = icmp sgt i64 %t47, 0
  br i1 %t48, label %bb20, label %bb21
bb20:
  %t50 = load i1, ptr %l7, !tbaa !21
  %t51 = load i1, ptr %l3, !tbaa !21
  %t54 = icmp ne i1 %t50, %t51
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load { ptr, ptr }, ptr %l4
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i1, ptr %l3, !tbaa !21
  %t61 = extractvalue { ptr, ptr } %t57, 0
  %t62 = extractvalue { ptr, ptr } %t57, 1
  call void %t61(ptr %t62, ptr %s0, ptr %v0, ptr %l2, ptr %t58, i1 %t59)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t66 = load i1, ptr %l7, !tbaa !21
  store i1 %t66, ptr %l3, !tbaa !21
  %t69 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t69, ptr %l42
  br label %bb27
bb27:
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = icmp sgt i64 %t70, 0
  br i1 %t71, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  store ptr %l2, ptr %l45, !tbaa !29
  %t74 = load i1, ptr %l3, !tbaa !21
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb34, label %bb35
bb33:
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t85, ptr %l47, !tbaa !27
  br label %bb40
bb34:
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = icmp sle i64 4, %t87
  br i1 %t88, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb36:
  %t90 = load i64, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb38:
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 4
  %t98 = sub i64 %t96, 4
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d85c9f08fc02aff9_18b1e7df62bde535)
  unreachable
bb40:
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t102, { i64, ptr } %t103)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  br label %bb8
bb43:
  %t104 = load { ptr, ptr }, ptr %l4
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i1, ptr %l3, !tbaa !21
  %t108 = extractvalue { ptr, ptr } %t104, 0
  %t109 = extractvalue { ptr, ptr } %t104, 1
  call void %t108(ptr %t109, ptr %s0, ptr %v0, ptr %l2, ptr %t105, i1 %t106)
  br label %bb44
bb44:
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/doc:Example"
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/doc:Entry"
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca %"compiler/doc:Example"
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/doc:Entry"
  %l65 = alloca %"compiler/doc:Entry"
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca %"compiler/doc:Entry"
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l87 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t152 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t3, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/doc:Entry", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/doc:Entry", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v1, ptr %s0, { i64, ptr } %t13)
  store { i64, ptr } %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t18, ptr %l20
  br label %bb6
bb6:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l4, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t23)
  store { i64, ptr } %t25, ptr %l24
  br label %bb7
bb7:
  %t26 = load i1, ptr %l4, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/doc:Entry", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s0, { i64, ptr } %t31)
  store { i64, ptr } %t33, ptr %l29
  br label %bb11
bb11:
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t34, i64 %t35)
  %t58 = getelementptr i8, ptr %t57, i64 %t35
  call void @olang_textcopy(ptr %t58, ptr %t37, i64 %t38)
  %t59 = getelementptr i8, ptr %t58, i64 %t38
  call void @olang_textcopy(ptr %t59, ptr %t40, i64 %t41)
  %t60 = getelementptr i8, ptr %t59, i64 %t41
  call void @olang_textcopy(ptr %t60, ptr %t44, i64 %t45)
  %t61 = getelementptr i8, ptr %t60, i64 %t45
  call void @olang_textcopy(ptr %t61, ptr %t47, i64 %t48)
  %t62 = getelementptr i8, ptr %t61, i64 %t48
  call void @olang_textcopy(ptr %t62, ptr %t51, i64 %t52)
  %t63 = getelementptr i8, ptr %t62, i64 %t52
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t57, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t67, { i64, ptr } %t65)
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/doc:Entry", ptr %t70, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2fdoc_2edocHtml(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/doc:Entry", ptr %t76, i32 0, i32 7
  store ptr %t78, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i64, ptr %l6, !tbaa !24
  store i64 %t80, ptr %l37, !tbaa !24
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t81)
  store i64 %t83, ptr %l39
  br label %bb15
bb15:
  %t84 = load i64, ptr %l37, !tbaa !24
  %t85 = load i64, ptr %l39, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t90, i64 %t91)
  store %"compiler/doc:Example" %t94, ptr %l44
  br label %bb19
bb19:
  %t95 = load %"compiler/doc:Example", ptr %l44
  store %"compiler/doc:Example" %t95, ptr %l7
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l45, !tbaa !29
  %t97 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t98)
  store { i64, ptr } %t100, ptr %l47
  br label %bb20
bb20:
  %t101 = getelementptr %"compiler/doc:Example", ptr %l7, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v1, ptr %s4, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l49
  br label %bb21
bb21:
  %t105 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t105, i64 %t106)
  %t122 = getelementptr i8, ptr %t121, i64 %t106
  call void @olang_textcopy(ptr %t122, ptr %t108, i64 %t109)
  %t123 = getelementptr i8, ptr %t122, i64 %t109
  call void @olang_textcopy(ptr %t123, ptr %t111, i64 %t112)
  %t124 = getelementptr i8, ptr %t123, i64 %t112
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t121, 1
  %t129 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t129, { i64, ptr } %t127)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb14
bb24:
  store i1 false, ptr %l8, !tbaa !21
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/doc:Entry", ptr %t136, i32 0, i32 5
  store ptr %t138, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %l57, !tbaa !24
  %t141 = load ptr, ptr %l9, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t141)
  store i64 %t143, ptr %l59
  br label %bb26
bb26:
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = load i64, ptr %l59, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb28:
  br label %bb29
bb29:
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t151 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t152, ptr %v1, ptr %v1, ptr %t150, i64 %t151)
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %t152, i64 152, i1 false)
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %l64, i64 152, i1 false)
  %t155 = call ptr @__olang_scope_hold(ptr %v1)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l66, !tbaa !24
  %t157 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t157, label %bb31, label %bb32
bb31:
  %t159 = call ptr @__olang_region_make_part(ptr %v1)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l66, !tbaa !24
  br label %bb32
bb32:
  %t161 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l68, !tbaa !24
  %t165 = load i64, ptr %l68, !tbaa !24
  %t166 = mul i64 %t165, 152
  %t167 = load i64, ptr %l66
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l69, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  br label %bb33
bb33:
  %t172 = load i64, ptr %l70, !tbaa !24
  %t173 = load i64, ptr %l68, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  br i1 %t174, label %bb34, label %bb35
bb34:
  %t176 = load i64, ptr %l70, !tbaa !24
  %t177 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t178 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t177, i32 0, i32 1
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = icmp slt i64 %t176, %t179
  br i1 %t180, label %bb38, label %bb36
bb35:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t183 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t184 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t183, i32 0, i32 0
  store { i64, ptr } %t182, ptr %t184, !tbaa !27
  %t185 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t185, label %bb40, label %bb41
bb36:
  %t187 = load i64, ptr %l70, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/doc:Entry", ptr %t189, i64 %t187
  call void @llvm.memset.p0.i64(ptr %t190, i8 0, i64 152, i1 false)
  br label %bb37
bb37:
  %t191 = load i64, ptr %l70, !tbaa !24
  %t192 = add i64 %t191, 1
  store i64 %t192, ptr %l70, !tbaa !24
  br label %bb33
bb38:
  %t193 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t193, i32 0, i32 0
  %t195 = load i64, ptr %l70, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr %"compiler/doc:Entry", ptr %t197, i64 %t195
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t198, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v1, ptr %l73)
  br label %bb39
bb39:
  %t200 = load i64, ptr %l70, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr %"compiler/doc:Entry", ptr %t202, i64 %t200
  call void @llvm.memmove.p0.p0.i64(ptr %t203, ptr %l73, i64 152, i1 false)
  br label %bb37
bb40:
  %t204 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t205 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t209 = icmp eq i64 %t207, 0
  br i1 %t209, label %bb42, label %bb43
bb41:
  %t211 = call ptr @__olang_scope_hold(ptr %v1)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l78, !tbaa !24
  %t213 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t213, label %bb44, label %bb45
bb42:
  %t215 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t216 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t215, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t216, !tbaa !27
  br label %bb43
bb43:
  %t217 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 5
  %t218 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t217, i32 0, i32 0
  %t219 = load i64, ptr %l66
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = load { i64, ptr }, ptr %t218
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = call ptr @__olang_region_or(ptr %t222, ptr null)
  %t224 = icmp ne ptr %t223, null
  %t225 = select i1 %t224, ptr %t223, ptr null
  call void @__olang_region_settle_in(ptr %t220, ptr %t225)
  br label %bb41
bb44:
  %t226 = call ptr @__olang_region_make_part(ptr %v1)
  %t227 = ptrtoint ptr %t226 to i64
  store i64 %t227, ptr %l78, !tbaa !24
  br label %bb45
bb45:
  %t228 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 7
  %t229 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t228, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  store { i64, ptr } %t230, ptr %l80, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l81, !tbaa !24
  %t233 = load i64, ptr %l81, !tbaa !24
  %t234 = mul i64 %t233, 32
  %t235 = load i64, ptr %l78
  %t236 = inttoptr i64 %t235 to ptr
  %t237 = call ptr @__olang_held_alloc(ptr %t236, i64 %t234)
  %t238 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l82, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = load i64, ptr %l81, !tbaa !24
  %t245 = mul i64 %t244, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t241, ptr %t243, i64 %t245, i1 false)
  %t246 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t247 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 7
  %t248 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t247, i32 0, i32 0
  store { i64, ptr } %t246, ptr %t248, !tbaa !27
  %t249 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t249, label %bb46, label %bb47
bb46:
  %t251 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 7
  %t252 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t251, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t256 = icmp eq i64 %t254, 0
  br i1 %t256, label %bb48, label %bb49
bb47:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l65, i64 152, i1 false)
  %t258 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t259 = load i1, ptr %t258, !tbaa !21
  br i1 %t259, label %bb50, label %bb51
bb48:
  %t261 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 7
  %t262 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t261, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t262, !tbaa !27
  br label %bb49
bb49:
  %t263 = getelementptr %"compiler/doc:Entry", ptr %l65, i32 0, i32 7
  %t264 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t263, i32 0, i32 0
  %t265 = load i64, ptr %l78
  %t266 = inttoptr i64 %t265 to ptr
  %t267 = load { i64, ptr }, ptr %t264
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = call ptr @__olang_region_or(ptr %t268, ptr null)
  %t270 = icmp ne ptr %t269, null
  %t271 = select i1 %t270, ptr %t269, ptr null
  call void @__olang_region_settle_in(ptr %t266, ptr %t271)
  br label %bb47
bb50:
  %t272 = load i1, ptr %l8, !tbaa !21
  %t274 = xor i1 %t272, true
  store i1 %t274, ptr %l87, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb52
bb52:
  %t276 = load i1, ptr %l87, !tbaa !21
  br i1 %t276, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t277 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t277, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  %t279 = getelementptr %"compiler/doc:Entry", ptr %l11, i32 0, i32 6
  %t280 = load i1, ptr %t279, !tbaa !21
  store i1 %t280, ptr %l8, !tbaa !21
  %t282 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdoc_2eentryHtml(ptr %v0, ptr %s8, ptr %t282, ptr %l11, i1 true)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t285 = load i64, ptr %l10, !tbaa !24
  %t288 = add i64 %t285, 1
  store i64 %t288, ptr %l10, !tbaa !24
  br label %bb25
bb59:
  %t290 = load i1, ptr %l2, !tbaa !21
  br i1 %t290, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t292 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t292, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eentryText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Example"
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/doc:Entry"
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:LineIter"
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca %"compiler/doc:Example"
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca %"compiler/doc:Entry"
  %l81 = alloca %"compiler/doc:Entry"
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca %"compiler/doc:Entry"
  %l94 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l103 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t177 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/doc:Entry", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t9, ptr %l18
  br label %bb2
bb2:
  %t10 = load i1, ptr %l18, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i1 true, ptr %l4, !tbaa !21
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/doc:Entry", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t17)
  store %"std/prelude/text:LineIter" %t19, ptr %l23
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:LineIter", ptr %l23
  store %"std/prelude/text:LineIter" %t20, ptr %l5
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l27
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb9, label %ok.26, !prof !99
ok.26:
  store { i64, ptr } %t23, ptr %l26
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t27, ptr %l24, !tbaa !27
  br label %bb11
bb9:
  %t28 = load i32, ptr %l27, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb11:
  %t32 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l30, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l31, !tbaa !27
  store { i64, ptr } %t32, ptr %l32, !tbaa !27
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l34, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l34, !tbaa !27
  br label %bb14
bb14:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t41, i64 %t42)
  %t55 = getelementptr i8, ptr %t54, i64 %t42
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t48, i64 %t49)
  %t57 = getelementptr i8, ptr %t56, i64 %t49
  call void @olang_textcopy(ptr %t57, ptr %t51, i64 %t52)
  %t58 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t54, 1
  %t61 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } %t59)
  br label %bb15
bb15:
  store i1 false, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb7
bb17:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/doc:Entry", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t68, ptr %l40
  br label %bb18
bb18:
  %t69 = load i1, ptr %l40, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/doc:Entry", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = getelementptr i8, ptr %t84, i64 %t80
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s4, ptr %t72, { i64, ptr } %t76, { i64, ptr } %t87)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/doc:Entry", ptr %t92, i32 0, i32 7
  store ptr %t94, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t96 = load i64, ptr %l8, !tbaa !24
  store i64 %t96, ptr %l50, !tbaa !24
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %t97)
  store i64 %t99, ptr %l52
  br label %bb24
bb24:
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l52, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb26:
  br label %bb27
bb27:
  %t106 = load ptr, ptr %l7, !tbaa !29
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v1, ptr %v1, ptr %t106, i64 %t107)
  store %"compiler/doc:Example" %t110, ptr %l57
  br label %bb28
bb28:
  %t111 = load %"compiler/doc:Example", ptr %l57
  store %"compiler/doc:Example" %t111, ptr %l9
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = getelementptr %"compiler/doc:Example", ptr %l9, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t113, 1
  %t118 = extractvalue { i64, ptr } %t113, 0
  %t119 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t123 = extractvalue { i64, ptr } %t115, 1
  %t124 = extractvalue { i64, ptr } %t115, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t117, i64 %t118)
  %t130 = getelementptr i8, ptr %t129, i64 %t118
  call void @olang_textcopy(ptr %t130, ptr %t119, i64 %t120)
  %t131 = getelementptr i8, ptr %t130, i64 %t120
  call void @olang_textcopy(ptr %t131, ptr %t123, i64 %t124)
  %t132 = getelementptr i8, ptr %t131, i64 %t124
  call void @olang_textcopy(ptr %t132, ptr %t126, i64 %t127)
  %t133 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t129, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t112, { i64, ptr } %t134)
  br label %bb29
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/doc:Example", ptr %l9, i32 0, i32 1
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = getelementptr i8, ptr %t148, i64 %t144
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  call void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %s7, ptr %t138, { i64, ptr } %t140, { i64, ptr } %t151)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb31:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l8, !tbaa !24
  br label %bb23
bb32:
  store i1 false, ptr %l10, !tbaa !21
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/doc:Entry", ptr %t161, i32 0, i32 5
  store ptr %t163, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s12
  %t165 = load i64, ptr %l12, !tbaa !24
  store i64 %t165, ptr %l73, !tbaa !24
  %t166 = load ptr, ptr %l11, !tbaa !29
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %t166)
  store i64 %t168, ptr %l75
  br label %bb34
bb34:
  %t169 = load i64, ptr %l73, !tbaa !24
  %t170 = load i64, ptr %l75, !tbaa !24
  %t171 = icmp slt i64 %t169, %t170
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb36:
  br label %bb37
bb37:
  %t175 = load ptr, ptr %l11, !tbaa !29
  %t176 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %t177, ptr %v1, ptr %v1, ptr %t175, i64 %t176)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t177, i64 152, i1 false)
  br label %bb38
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %l80, i64 152, i1 false)
  %t180 = call ptr @__olang_scope_hold(ptr %v1)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l82, !tbaa !24
  %t182 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t182, label %bb39, label %bb40
bb39:
  %t184 = call ptr @__olang_region_make_part(ptr %v1)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l82, !tbaa !24
  br label %bb40
bb40:
  %t186 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t187 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t186, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l84, !tbaa !24
  %t190 = load i64, ptr %l84, !tbaa !24
  %t191 = mul i64 %t190, 152
  %t192 = load i64, ptr %l82
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = call ptr @__olang_held_alloc(ptr %t193, i64 %t191)
  %t195 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l85, !tbaa !27
  store i64 0, ptr %l86, !tbaa !24
  br label %bb41
bb41:
  %t197 = load i64, ptr %l86, !tbaa !24
  %t198 = load i64, ptr %l84, !tbaa !24
  %t199 = icmp slt i64 %t197, %t198
  br i1 %t199, label %bb42, label %bb43
bb42:
  %t201 = load i64, ptr %l86, !tbaa !24
  %t202 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t202, i32 0, i32 1
  %t204 = load i64, ptr %t203, !tbaa !24
  %t205 = icmp slt i64 %t201, %t204
  br i1 %t205, label %bb46, label %bb44
bb43:
  %t207 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t208 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t209 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t208, i32 0, i32 0
  store { i64, ptr } %t207, ptr %t209, !tbaa !27
  %t210 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t210, label %bb48, label %bb49
bb44:
  %t212 = load i64, ptr %l86, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr %"compiler/doc:Entry", ptr %t214, i64 %t212
  call void @llvm.memset.p0.i64(ptr %t215, i8 0, i64 152, i1 false)
  br label %bb45
bb45:
  %t216 = load i64, ptr %l86, !tbaa !24
  %t217 = add i64 %t216, 1
  store i64 %t217, ptr %l86, !tbaa !24
  br label %bb41
bb46:
  %t218 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t219 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t218, i32 0, i32 0
  %t220 = load i64, ptr %l86, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr %"compiler/doc:Entry", ptr %t222, i64 %t220
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t223, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v1, ptr %l89)
  br label %bb47
bb47:
  %t225 = load i64, ptr %l86, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr %"compiler/doc:Entry", ptr %t227, i64 %t225
  call void @llvm.memmove.p0.p0.i64(ptr %t228, ptr %l89, i64 152, i1 false)
  br label %bb45
bb48:
  %t229 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t230 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t229, i32 0, i32 0
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t234 = icmp eq i64 %t232, 0
  br i1 %t234, label %bb50, label %bb51
bb49:
  %t236 = call ptr @__olang_scope_hold(ptr %v1)
  %t237 = ptrtoint ptr %t236 to i64
  store i64 %t237, ptr %l94, !tbaa !24
  %t238 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t238, label %bb52, label %bb53
bb50:
  %t240 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t241 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t240, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t241, !tbaa !27
  br label %bb51
bb51:
  %t242 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 5
  %t243 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t242, i32 0, i32 0
  %t244 = load i64, ptr %l82
  %t245 = inttoptr i64 %t244 to ptr
  %t246 = load { i64, ptr }, ptr %t243
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = call ptr @__olang_region_or(ptr %t247, ptr null)
  %t249 = icmp ne ptr %t248, null
  %t250 = select i1 %t249, ptr %t248, ptr null
  call void @__olang_region_settle_in(ptr %t245, ptr %t250)
  br label %bb49
bb52:
  %t251 = call ptr @__olang_region_make_part(ptr %v1)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l94, !tbaa !24
  br label %bb53
bb53:
  %t253 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 7
  %t254 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t253, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  store { i64, ptr } %t255, ptr %l96, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  store i64 %t257, ptr %l97, !tbaa !24
  %t258 = load i64, ptr %l97, !tbaa !24
  %t259 = mul i64 %t258, 32
  %t260 = load i64, ptr %l94
  %t261 = inttoptr i64 %t260 to ptr
  %t262 = call ptr @__olang_held_alloc(ptr %t261, i64 %t259)
  %t263 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  store { i64, ptr } %t264, ptr %l98, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = load i64, ptr %l97, !tbaa !24
  %t270 = mul i64 %t269, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t266, ptr %t268, i64 %t270, i1 false)
  %t271 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t272 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 7
  %t273 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t272, i32 0, i32 0
  store { i64, ptr } %t271, ptr %t273, !tbaa !27
  %t274 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t274, label %bb54, label %bb55
bb54:
  %t276 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 7
  %t277 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t276, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t281 = icmp eq i64 %t279, 0
  br i1 %t281, label %bb56, label %bb57
bb55:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l81, i64 152, i1 false)
  %t283 = getelementptr %"compiler/doc:Entry", ptr %l13, i32 0, i32 6
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb58, label %bb59
bb56:
  %t286 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 7
  %t287 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t286, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t287, !tbaa !27
  br label %bb57
bb57:
  %t288 = getelementptr %"compiler/doc:Entry", ptr %l81, i32 0, i32 7
  %t289 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t288, i32 0, i32 0
  %t290 = load i64, ptr %l94
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = load { i64, ptr }, ptr %t289
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = icmp ne ptr %t294, null
  %t296 = select i1 %t295, ptr %t294, ptr null
  call void @__olang_region_settle_in(ptr %t291, ptr %t296)
  br label %bb55
bb58:
  %t297 = load i1, ptr %l10, !tbaa !21
  %t299 = xor i1 %t297, true
  store i1 %t299, ptr %l103, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb60
bb60:
  %t301 = load i1, ptr %l103, !tbaa !21
  br i1 %t301, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 1
  %t306 = extractvalue { i64, ptr } %t303, 0
  %t307 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t305, i64 %t306)
  %t311 = getelementptr i8, ptr %t310, i64 %t306
  call void @olang_textcopy(ptr %t311, ptr %t307, i64 %t308)
  %t312 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t310, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t302, { i64, ptr } %t313)
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t317 = getelementptr %"compiler/doc:Entry", ptr %l13, i32 0, i32 6
  %t318 = load i1, ptr %t317, !tbaa !21
  store i1 %t318, ptr %l10, !tbaa !21
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 1
  %t324 = extractvalue { i64, ptr } %t321, 0
  %t325 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t323, i64 %t324)
  %t329 = getelementptr i8, ptr %t328, i64 %t324
  call void @olang_textcopy(ptr %t329, ptr %t325, i64 %t326)
  %t330 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t328, 1
  call void @compiler_2fdoc_2eentryText(ptr %v0, ptr %s12, ptr %s12, ptr %t320, ptr %l13, { i64, ptr } %t331)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb66
bb66:
  %t336 = load i64, ptr %l12, !tbaa !24
  %t339 = add i64 %t336, 1
  store i64 %t339, ptr %l12, !tbaa !24
  br label %bb33
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/doc:Example"
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca ptr
  %l76 = alloca ptr
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb50
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l8, !tbaa !29
  %t23 = load ptr, ptr %l8, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t24 = load ptr, ptr %l21, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 12}
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l8, !tbaa !29
  %t34 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35
  store { i64, ptr } %t36, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  br label %bb23
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v1, ptr %v0, ptr %s3, ptr %t38, ptr %t48)
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %v3, { i64, ptr } %t52, { i64, ptr } %t53)
  store i1 %t56, ptr %l35
  br label %bb11
bb11:
  %t57 = load i1, ptr %l35, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb13:
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l4, !tbaa !29
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = call ptr @__olang_scope_hold(ptr %v4)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l38, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aExample_2e0
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = call ptr @__olang_region_make(ptr %v4)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l38, !tbaa !24
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = load i64, ptr %l38
  %t70 = inttoptr i64 %t69 to ptr
  %t73 = call { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v1, ptr %v2, ptr %t70, ptr %t67, { i64, ptr } %t68)
  store { i64, ptr } %t73, ptr %l42
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t75 = load i64, ptr %l38
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = extractvalue { i64, ptr } %t74, 0
  %t78 = extractvalue { i64, ptr } %t74, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_held_alloc(ptr %t76, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = call ptr @__olang_scope_hold(ptr %v4)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l44, !tbaa !24
  %t85 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aExample_2e1
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t87 = call ptr @__olang_region_make(ptr %v4)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t91 = load i64, ptr %l44
  %t92 = inttoptr i64 %t91 to ptr
  %t95 = call { i64, ptr } @compiler_2fdoc_2ebodyText(ptr %v2, ptr %v1, ptr %t92, { i64, ptr } %t89, { i64, ptr } %t90)
  store { i64, ptr } %t95, ptr %l48
  br label %bb20
bb20:
  %t96 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t97 = load i64, ptr %l44
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = extractvalue { i64, ptr } %t96, 0
  %t100 = extractvalue { i64, ptr } %t96, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_held_alloc(ptr %t98, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t107 = call %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t105, { i64, ptr } %t104)
  store %"compiler/doc:Example" %t107, ptr %l50
  br label %bb21
bb21:
  %t108 = load ptr, ptr %l37, !tbaa !29
  %t109 = load %"compiler/doc:Example", ptr %l50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v4, ptr %v4, ptr %t108, %"compiler/doc:Example" %t109)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb23:
  %t110 = load ptr, ptr %l8, !tbaa !29
  store ptr %t110, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t111 = load ptr, ptr %l51, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l51, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 12}
  %t117 = icmp eq i64 %t115, 8
  store i1 %t117, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t118 = load i1, ptr %l52, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = getelementptr { i64, [8 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l10, !tbaa !29
  br label %bb28
bb27:
  br label %bb43
bb28:
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TopIf", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb29, label %bb30
bb29:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l61, !tbaa !29
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = getelementptr %"compiler/ast:TopIf", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb31, label %bb32
bb30:
  br label %bb35
bb31:
  call void @__olang_check_failed(ptr @olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e)
  unreachable
bb32:
  br label %bb33
bb33:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/ast:TopIf", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/ast:TopBranch", ptr %t145, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t153, { i64, ptr } %t149, { i64, ptr } %t150, { i64, ptr } %t151, ptr %t152)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t160 = getelementptr %"compiler/ast:TopIf", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb36, label %bb37
bb36:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l76, !tbaa !29
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t170 = getelementptr %"compiler/ast:TopIf", ptr %t168, i32 0, i32 3
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = icmp eq ptr %t171, null
  br i1 %t173, label %bb38, label %bb39
bb37:
  br label %bb42
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5be1599e6a61f501_71a8850ae192da35)
  unreachable
bb39:
  br label %bb40
bb40:
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = getelementptr %"compiler/ast:TopIf", ptr %t175, i32 0, i32 3
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t181 = getelementptr %"compiler/ast:TopBranch", ptr %t178, i32 0, i32 1
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t186 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2fdoc_2eexamplesIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t186, { i64, ptr } %t182, { i64, ptr } %t183, { i64, ptr } %t184, ptr %t185)
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_fe551cd114f4cb63_729eb01933a49f67)
  unreachable
bb48:
  br label %bb49
bb49:
  %t191 = load i64, ptr %l6, !tbaa !24
  %t194 = add i64 %t191, 1
  store i64 %t194, ptr %l6, !tbaa !24
  br label %bb1
bb50:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2efirstSentence(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l8
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l11
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t21, ptr %l16
  br label %bb8
bb8:
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t24 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t24, ptr %l18
  br label %bb12
bb12:
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp sgt i64 %t25, 0
  br i1 %t26, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l21, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l23
  br label %bb17
bb17:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t32, { i64, ptr } %t33)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb3
bb20:
  %t35 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t35, ptr %l25
  br label %bb21
bb21:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t36, ptr %lp4
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = load ptr, ptr %lp4
  store { i64, ptr } %t37, ptr %t38, !tbaa !27
  %t39 = load ptr, ptr %lp4
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) })
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l29
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb23, label %ok.46, !prof !99
ok.46:
  store i64 %t43, ptr %l28
  br label %bb22
bb22:
  %t47 = load i64, ptr %l28, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 -1, ptr %l26, !tbaa !24
  br label %bb25
bb25:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb26, label %bb27
bb26:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l34, !tbaa !24
  %t56 = load ptr, ptr %lp4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l35, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb28, label %bb29
bb27:
  %t61 = load ptr, ptr %lp4
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l32, !tbaa !27
  br label %bb34
bb28:
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = icmp sle i64 0, %t64
  br i1 %t65, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb30:
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = load i64, ptr %l35, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb32:
  %t71 = load ptr, ptr %lp4
  %t72 = getelementptr { i64, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l34, !tbaa !24
  %t75 = getelementptr i8, ptr %t73, i64 0
  %t76 = sub i64 %t74, 0
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l32, !tbaa !27
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_46ab965e7000f695_6c81a9a0ef748b89)
  unreachable
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdoc_2ememberAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca i32
  %l41 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i32
  %l92 = alloca i64
  %l96 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l115 = alloca i64
  %l118 = alloca i1
  %l123 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i1
  %l145 = alloca i64
  %l148 = alloca i1
  %l153 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i1
  %l175 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l30, !tbaa !29
  %t18 = call ptr @__olang_scope_hold(ptr %v0)
  %t19 = ptrtoint ptr %t18 to i64
  store i64 %t19, ptr %l31, !tbaa !24
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l30, !tbaa !29
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr %v0)
  %t24 = call ptr @__olang_scope_hold(ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l31, !tbaa !24
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = load i64, ptr %l31
  %t29 = inttoptr i64 %t28 to ptr
  %t32 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t29, ptr %v1, ptr %t26, { i64, ptr } %t27)
  store i32 %t32, ptr %l35
  br label %bb6
bb6:
  %t33 = load i32, ptr %l35, !tbaa !23
  store i32 %t33, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 10
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store ptr %t46, ptr %l41
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l41, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 6
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l6, !tbaa !29
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_301af787a8ab5449_ce9576e6695793ad)
  unreachable
bb9:
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/source:Source", ptr %t56, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l7, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l2, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l53
  br label %bb11
bb11:
  %t72 = load i32, ptr %l53, !range !{i32 0, i32 6}
  %t74 = trunc i64 2 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l56, !tbaa !29
  %t78 = load i64, ptr %l1, !tbaa !24
  store i64 %t78, ptr %l57, !tbaa !24
  %t79 = load ptr, ptr %l4, !tbaa !29
  store ptr %t79, ptr %l58, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l63
  br label %bb14
bb13:
  br label %bb34
bb14:
  %t90 = load ptr, ptr %l58, !tbaa !29
  %t91 = load i32, ptr %l63, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t90, i32 %t91)
  store { i64, ptr } %t92, ptr %l64
  br label %bb15
bb15:
  %t93 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t94, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t100 = load ptr, ptr %l56, !tbaa !29
  %t101 = load i64, ptr %l57, !tbaa !24
  %t103 = call i64 @compiler_2fdoc_2edeclAt(ptr %v0, ptr %s2, ptr %t100, i64 %t101, { i64, ptr } %t98)
  store i64 %t103, ptr %l67
  br label %bb16
bb16:
  %t104 = load i64, ptr %l67, !tbaa !24
  store i64 %t104, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t110, ptr %l72, !tbaa !27
  %t111 = load i64, ptr %l8, !tbaa !24
  store i64 %t111, ptr %l73, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 0
  store i64 %t115, ptr %l76, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l77, !tbaa !24
  %t118 = load i64, ptr %l73, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb20, label %bb21
bb20:
  %t121 = load i64, ptr %l73, !tbaa !24
  %t122 = load i64, ptr %l76, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb22:
  %t125 = load i64, ptr %l76, !tbaa !24
  %t126 = load i64, ptr %l77, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb24:
  %t129 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l73, !tbaa !24
  %t132 = load i64, ptr %l76, !tbaa !24
  %t133 = getelementptr i8, ptr %t130, i64 %t131
  %t134 = sub i64 %t132, %t131
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t138 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t136, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) })
  %t139 = extractvalue { i32, i64 } %t138, 1
  %t140 = extractvalue { i32, i64 } %t138, 0
  store i32 %t140, ptr %l83
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb27, label %ok.142, !prof !99
ok.142:
  store i64 %t139, ptr %l82
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e0afceaceca5551a_2521421923c730de)
  unreachable
bb26:
  %t143 = load i64, ptr %l82, !tbaa !24
  store i64 %t143, ptr %l71, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  store i64 -1, ptr %l71, !tbaa !24
  br label %bb29
bb29:
  %t144 = load i64, ptr %l71, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = icmp slt i64 %t145, 0
  br i1 %t147, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t150 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t151 = load i64, ptr %l8, !tbaa !24
  %t152 = load i64, ptr %l9, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t160 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %t150, i64 %t155, { i64, ptr } %t156)
  store i64 %t160, ptr %l92
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  %t161 = load i64, ptr %l92, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
bb34:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t166 = load i32, ptr %l2, !tbaa !23
  %t169 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t165, i32 %t166)
  store ptr %t169, ptr %l96
  br label %bb35
bb35:
  %t170 = load ptr, ptr %l96, !tbaa !29
  store ptr %t170, ptr %l10, !tbaa !29
  %t171 = load ptr, ptr %l10, !tbaa !29
  %t173 = icmp eq ptr %t171, null
  br i1 %t173, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb38
bb37:
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = getelementptr %"compiler/ast:TypeDecl", ptr %t175, i32 0, i32 3
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  store i1 %t180, ptr %l99, !tbaa !21
  br label %bb38
bb38:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb39, label %bb40
bb39:
  store i64 -1, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t184 = load ptr, ptr %l10, !tbaa !29
  %t186 = getelementptr %"compiler/ast:TypeDecl", ptr %t184, i32 0, i32 3
  %t187 = load ptr, ptr %t186, !tbaa !29
  store ptr %t187, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l11, !tbaa !29
  store ptr %t189, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t190 = load ptr, ptr %l106, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = load ptr, ptr %l106, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 5}
  %t196 = icmp eq i64 %t194, 1
  store i1 %t196, ptr %l107, !tbaa !21
  br label %bb43
bb43:
  %t197 = load i1, ptr %l107, !tbaa !21
  br i1 %t197, label %bb44, label %bb45
bb44:
  %t198 = load ptr, ptr %l11, !tbaa !29
  %t200 = getelementptr { i64, [6 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { { i64, ptr }, ptr }, ptr %t200, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201
  store { i64, ptr } %t202, ptr %l12, !tbaa !27
  br label %bb46
bb45:
  br label %bb56
bb46:
  %t204 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t204, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l15, !tbaa !24
  %t210 = load i64, ptr %l15, !tbaa !24
  %t211 = sub i64 %t210, 1
  store i64 %t211, ptr %l115, !tbaa !24
  %t212 = load i64, ptr %l15, !tbaa !24
  %t213 = icmp slt i64 %t212, 2147483648
  %t214 = load i64, ptr %l14, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  %t218 = and i1 %t213, %t215
  store i1 %t218, ptr %l118, !tbaa !21
  br label %bb47
bb47:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t220 = load i64, ptr %l15, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb48, label %bb49
bb48:
  br label %bb55
bb49:
  br label %bb50
bb50:
  %t227 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t227, ptr %l123, !tbaa !27
  %t228 = load i64, ptr %l14, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr ptr, ptr %t231, i64 %t228
  %t233 = load ptr, ptr %t232, !tbaa !39
  store ptr %t233, ptr %l16, !tbaa !29
  %t235 = load ptr, ptr %l16, !tbaa !29
  %t237 = getelementptr %"compiler/ast:CaseDecl", ptr %t235, i32 0, i32 1
  %t238 = load i32, ptr %t237, !tbaa !23
  %t239 = load i32, ptr %l5, !tbaa !23
  %t242 = icmp eq i32 %t238, %t239
  br i1 %t242, label %bb51, label %bb52
bb51:
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/ast:CaseDecl", ptr %t244, i32 0, i32 0
  %t247 = getelementptr %"compiler/source:Span", ptr %t246, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = sext i32 %t248 to i64
  store i64 %t250, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t252 = load i64, ptr %l14, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l14, !tbaa !24
  br label %bb47
bb55:
  br label %bb83
bb56:
  %t257 = load ptr, ptr %l11, !tbaa !29
  store ptr %t257, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t258 = load ptr, ptr %l136, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb57, label %bb58
bb57:
  %t261 = load ptr, ptr %l136, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 5}
  %t264 = icmp eq i64 %t262, 2
  store i1 %t264, ptr %l137, !tbaa !21
  br label %bb58
bb58:
  %t265 = load i1, ptr %l137, !tbaa !21
  br i1 %t265, label %bb59, label %bb60
bb59:
  %t266 = load ptr, ptr %l11, !tbaa !29
  %t268 = getelementptr { i64, [6 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t268, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l17, !tbaa !27
  br label %bb61
bb60:
  br label %bb71
bb61:
  %t272 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t272, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  store i64 %t276, ptr %l20, !tbaa !24
  %t278 = load i64, ptr %l20, !tbaa !24
  %t279 = sub i64 %t278, 1
  store i64 %t279, ptr %l145, !tbaa !24
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = icmp slt i64 %t280, 2147483648
  %t282 = load i64, ptr %l19, !tbaa !24
  %t283 = icmp sge i64 %t282, 0
  %t286 = and i1 %t281, %t283
  store i1 %t286, ptr %l148, !tbaa !21
  br label %bb62
bb62:
  %t287 = load i64, ptr %l19, !tbaa !24
  %t288 = load i64, ptr %l20, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb63, label %bb64
bb63:
  br label %bb70
bb64:
  br label %bb65
bb65:
  %t295 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t295, ptr %l153, !tbaa !27
  %t296 = load i64, ptr %l19, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr ptr, ptr %t299, i64 %t296
  %t301 = load ptr, ptr %t300, !tbaa !39
  store ptr %t301, ptr %l21, !tbaa !29
  %t303 = load ptr, ptr %l21, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %t305, !tbaa !23
  %t307 = load i32, ptr %l5, !tbaa !23
  %t310 = icmp eq i32 %t306, %t307
  br i1 %t310, label %bb66, label %bb67
bb66:
  %t312 = load ptr, ptr %l21, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Func", ptr %t312, i32 0, i32 0
  %t315 = getelementptr %"compiler/source:Span", ptr %t314, i32 0, i32 0
  %t316 = load i32, ptr %t315, !tbaa !23
  %t318 = sext i32 %t316 to i64
  store i64 %t318, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t320 = load i64, ptr %l19, !tbaa !24
  %t323 = add i64 %t320, 1
  store i64 %t323, ptr %l19, !tbaa !24
  br label %bb62
bb70:
  br label %bb83
bb71:
  %t325 = load ptr, ptr %l11, !tbaa !29
  store ptr %t325, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t326 = load ptr, ptr %l166, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb72, label %bb73
bb72:
  %t329 = load ptr, ptr %l166, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 5}
  %t332 = icmp eq i64 %t330, 0
  store i1 %t332, ptr %l167, !tbaa !21
  br label %bb73
bb73:
  %t333 = load i1, ptr %l167, !tbaa !21
  br i1 %t333, label %bb74, label %bb75
bb74:
  %t334 = load ptr, ptr %l11, !tbaa !29
  %t336 = getelementptr { i64, [6 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { ptr }, ptr %t336, i32 0, i32 0
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l22, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t340 = load ptr, ptr %l22, !tbaa !29
  %t342 = getelementptr %"compiler/ast:StructBody", ptr %t340, i32 0, i32 2
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  %t344 = load i32, ptr %l5, !tbaa !23
  %t347 = call i64 @compiler_2fdoc_2evarNamed(ptr %v0, { i64, ptr } %t343, i32 %t344)
  store i64 %t347, ptr %l175
  br label %bb77
bb77:
  %t348 = load i64, ptr %l175, !tbaa !24
  store i64 %t348, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e)
  unreachable
bb83:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdoc_2ememberName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t15)
  store i1 %t17, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb12
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t25)
  store i1 %t27, ptr %l15
  br label %bb7
bb7:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 %t31
  %t36 = load i8, ptr %t35, !tbaa !32
  %t38 = icmp eq i8 %t36, 95
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %l6, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l6, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l25, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l27, !tbaa !24
  %t53 = icmp sge i64 0, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = icmp sle i64 0, %t55
  br i1 %t56, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb20:
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = load i64, ptr %l27, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
bb22:
  %t62 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = getelementptr i8, ptr %t63, i64 0
  %t66 = sub i64 %t64, 0
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fdfaf893749e1d49_869eafdea154472d)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2emembers(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %lp12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %lp15 = alloca ptr
  %l21 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i1
  %l66 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l79 = alloca i1
  %l81 = alloca i1
  %l86 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l111 = alloca { i64, ptr }
  %l114 = alloca %"compiler/doc:Entry"
  %l119 = alloca i64
  %l121 = alloca { i64, ptr }
  %l123 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l134 = alloca { i64, ptr }
  %l138 = alloca %"compiler/doc:Entry"
  %s2 = alloca %olang.scope
  %t241 = alloca %"compiler/doc:Entry", align 8
  %t332 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l21
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l21, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 6
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2c161ece78a24477_8abc4a29ddab9f5b)
  unreachable
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 6
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/source:Source", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberCount(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l31
  br label %bb5
bb5:
  %t37 = load i64, ptr %l31, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb11
bb8:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l38, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb10
bb10:
  %t64 = load i64, ptr %l38, !tbaa !24
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l35, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l11, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberModule(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l59
  br label %bb16
bb16:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load i64, ptr %l59, !tbaa !24
  %t95 = icmp ne i64 %t93, %t92
  br i1 %t95, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb20
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberInPlace(ptr %v0, ptr %t100, i64 %t101)
  store i1 %t104, ptr %l66
  br label %bb19
bb19:
  %t105 = load i1, ptr %l66, !tbaa !21
  store i1 %t105, ptr %l62, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l62, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb22:
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l70, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l74
  br label %bb24
bb24:
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l74, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t125, i32 %t126)
  store { i64, ptr } %t127, ptr %l75
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t129, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t134, ptr %lp12
  %t136 = load ptr, ptr %lp12
  store { i64, ptr } %t133, ptr %t136, !tbaa !27
  %t139 = xor i1 %a3, true
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %lp12
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t144 = call i1 @compiler_2fdoc_2eExported(ptr %v1, { i64, ptr } %t142)
  store i1 %t144, ptr %l81
  br label %bb28
bb27:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb29
bb28:
  %t145 = load i1, ptr %l81, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l79, !tbaa !21
  br label %bb29
bb29:
  %t148 = load i1, ptr %l79, !tbaa !21
  br i1 %t148, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb31:
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = call %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberSpan(ptr %v0, ptr %t152, i64 %t153)
  store %"compiler/source:Span" %t156, ptr %l86
  br label %bb33
bb33:
  %t157 = load %"compiler/source:Span", ptr %l86
  store %"compiler/source:Span" %t157, ptr %l13
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i64, ptr %l11, !tbaa !24
  %t165 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v0, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l90
  br label %bb34
bb34:
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t166)
  store %"compiler/source:Span" %t167, ptr %l91
  br label %bb35
bb35:
  %t168 = load %"compiler/source:Span", ptr %l91
  store %"compiler/source:Span" %t168, ptr %l14
  %t169 = call ptr @__olang_scope_hold(ptr %v1)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l92, !tbaa !24
  %t171 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e0
  br i1 %t171, label %bb36, label %bb37
bb36:
  %t173 = call ptr @__olang_region_make(ptr %v1)
  %t174 = ptrtoint ptr %t173 to i64
  store i64 %t174, ptr %l92, !tbaa !24
  br label %bb37
bb37:
  %t175 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t175, ptr %l94, !tbaa !27
  %t176 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  store i64 %t179, ptr %l96, !tbaa !24
  %t180 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t181 = load i32, ptr %t180, !tbaa !23
  %t183 = sext i32 %t181 to i64
  store i64 %t183, ptr %l98, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l99, !tbaa !24
  %t186 = load i64, ptr %l96, !tbaa !24
  %t187 = icmp sge i64 %t186, 0
  br i1 %t187, label %bb38, label %bb39
bb38:
  %t189 = load i64, ptr %l96, !tbaa !24
  %t190 = load i64, ptr %l98, !tbaa !24
  %t191 = icmp sle i64 %t189, %t190
  br i1 %t191, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_1cb365347d6e720_3c1b65543fd0c444)
  unreachable
bb40:
  %t193 = load i64, ptr %l98, !tbaa !24
  %t194 = load i64, ptr %l99, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1cb365347d6e720_3c1b65543fd0c444)
  unreachable
bb42:
  %t197 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l96, !tbaa !24
  %t200 = load i64, ptr %l98, !tbaa !24
  %t201 = getelementptr i8, ptr %t198, i64 %t199
  %t202 = sub i64 %t200, %t199
  %t203 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t201, 1
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = load i64, ptr %l92
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = call ptr @__olang_held_alloc(ptr %t209, i64 %t207)
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  store { i64, ptr } %t212, ptr %l105, !tbaa !27
  %t214 = call ptr @__olang_scope_hold(ptr %v1)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l106, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e1
  br i1 %t216, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_1cb365347d6e720_3c1b65543fd0c444)
  unreachable
bb44:
  %t218 = call ptr @__olang_region_make(ptr %v1)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t221 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t225 = load i64, ptr %l106
  %t226 = inttoptr i64 %t225 to ptr
  %t229 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t226, { i64, ptr } %t220, i64 %t224)
  store { i64, ptr } %t229, ptr %l111
  br label %bb46
bb46:
  %t230 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t231 = load i64, ptr %l106
  %t232 = inttoptr i64 %t231 to ptr
  %t233 = extractvalue { i64, ptr } %t230, 0
  %t234 = extractvalue { i64, ptr } %t230, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_held_alloc(ptr %t232, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %lp12
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l105, !tbaa !27
  call void @compiler_2fdoc_3aEntry_2ector(ptr %t241, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %t240)
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t241, i64 152, i1 false)
  br label %bb47
bb47:
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 152, i64 8)
  store ptr %t245, ptr %lp15
  %t246 = load ptr, ptr %lp15
  call void @llvm.memmove.p0.p0.i64(ptr %t246, ptr %l114, i64 152, i1 false)
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/load:Module", ptr %t247, i32 0, i32 4
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = load ptr, ptr %lp15
  %t253 = getelementptr %"compiler/doc:Entry", ptr %t252, i32 0, i32 3
  store i64 %t250, ptr %t253, !tbaa !24
  %t254 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t255 = load i32, ptr %t254, !tbaa !23
  %t257 = sext i32 %t255 to i64
  %t259 = load ptr, ptr %lp15
  %t260 = getelementptr %"compiler/doc:Entry", ptr %t259, i32 0, i32 4
  store i64 %t257, ptr %t260, !tbaa !24
  %t261 = call ptr @__olang_scope_hold(ptr %v1)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l119, !tbaa !24
  %t263 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t263, label %bb48, label %bb49
bb48:
  %t265 = call ptr @__olang_region_make(ptr %v1)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l119, !tbaa !24
  br label %bb49
bb49:
  %t267 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t267, ptr %l121, !tbaa !27
  %t268 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t269 = load i32, ptr %t268, !tbaa !23
  %t271 = sext i32 %t269 to i64
  store i64 %t271, ptr %l123, !tbaa !24
  %t272 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 1
  %t273 = load i32, ptr %t272, !tbaa !23
  %t275 = sext i32 %t273 to i64
  store i64 %t275, ptr %l125, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  store i64 %t277, ptr %l126, !tbaa !24
  %t278 = load i64, ptr %l123, !tbaa !24
  %t279 = icmp sge i64 %t278, 0
  br i1 %t279, label %bb50, label %bb51
bb50:
  %t281 = load i64, ptr %l123, !tbaa !24
  %t282 = load i64, ptr %l125, !tbaa !24
  %t283 = icmp sle i64 %t281, %t282
  br i1 %t283, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_735c5a3de920021b_138313d8ba3a6daf)
  unreachable
bb52:
  %t285 = load i64, ptr %l125, !tbaa !24
  %t286 = load i64, ptr %l126, !tbaa !24
  %t287 = icmp sle i64 %t285, %t286
  br i1 %t287, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_735c5a3de920021b_138313d8ba3a6daf)
  unreachable
bb54:
  %t289 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = load i64, ptr %l123, !tbaa !24
  %t292 = load i64, ptr %l125, !tbaa !24
  %t293 = getelementptr i8, ptr %t290, i64 %t291
  %t294 = sub i64 %t292, %t291
  %t295 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t293, 1
  %t297 = load ptr, ptr %lp12
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t296, 1
  %t301 = extractvalue { i64, ptr } %t296, 0
  %t302 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t304 = add i64 %t301, %t303
  %t306 = extractvalue { i64, ptr } %t298, 1
  %t307 = extractvalue { i64, ptr } %t298, 0
  %t308 = add i64 %t304, %t307
  %t309 = load i64, ptr %l119
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = call ptr @__olang_held_alloc(ptr %t310, i64 %t308)
  call void @olang_textcopy(ptr %t311, ptr %t300, i64 %t301)
  %t312 = getelementptr i8, ptr %t311, i64 %t301
  call void @olang_textcopy(ptr %t312, ptr %t302, i64 %t303)
  %t313 = getelementptr i8, ptr %t312, i64 %t303
  call void @olang_textcopy(ptr %t313, ptr %t306, i64 %t307)
  %t314 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t311, 1
  %t317 = load ptr, ptr %lp15
  %t318 = getelementptr %"compiler/doc:Entry", ptr %t317, i32 0, i32 8
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  store { i64, ptr } %t319, ptr %l134, !tbaa !27
  %t321 = load ptr, ptr %lp15
  %t322 = getelementptr %"compiler/doc:Entry", ptr %t321, i32 0, i32 8
  store { i64, ptr } %t315, ptr %t322, !tbaa !27
  %t323 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t323, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_735c5a3de920021b_138313d8ba3a6daf)
  unreachable
bb56:
  %t325 = load { i64, ptr }, ptr %l134
  %t326 = extractvalue { i64, ptr } %t325, 1
  call void @__olang_region_release(ptr %t326)
  store { i64, ptr } zeroinitializer, ptr %l134
  br label %bb57
bb57:
  %t329 = getelementptr %"compiler/doc:Module", ptr %a2, i32 0, i32 3
  %t330 = load ptr, ptr %lp15
  call void @llvm.memmove.p0.p0.i64(ptr %l138, ptr %t330, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t332, ptr %l138, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v1, ptr %v1, ptr %t329, ptr %t332)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb59:
  %t333 = load i64, ptr %l10, !tbaa !24
  %t336 = add i64 %t333, 1
  store i64 %t336, ptr %l10, !tbaa !24
  br label %bb12
bb60:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdoc_2emethodName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = add i64 %t15, 2
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 0
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l26, !tbaa !24
  %t34 = icmp sge i64 3, 0
  br i1 %t34, label %bb13, label %bb14
bb7:
  %t36 = load i64, ptr %l13, !tbaa !24
  %t37 = load i64, ptr %l16, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb9:
  %t40 = load i64, ptr %l16, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb11:
  %t44 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l16, !tbaa !24
  %t48 = getelementptr i8, ptr %t45, i64 %t46
  %t49 = sub i64 %t47, %t46
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l10, !tbaa !27
  br label %bb19
bb12:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb13:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 3, %t53
  br i1 %t54, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb17:
  %t60 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 3
  %t64 = sub i64 %t62, 3
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l10, !tbaa !27
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_93a5825f4266fe40_3fd51f523aa7a28c)
  unreachable
bb19:
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t68, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t69, %t72
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t83)
  store i1 %t85, ptr %l39
  br label %bb23
bb22:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb31
bb23:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t93)
  store i1 %t95, ptr %l44
  br label %bb26
bb26:
  %t96 = load i1, ptr %l44, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp eq i8 %t104, 95
  store i1 %t106, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l45, !tbaa !21
  store i1 %t108, ptr %l35, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l35, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l3, !tbaa !24
  br label %bb35
bb35:
  br label %bb20
bb36:
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l54, !tbaa !27
  %t118 = load i64, ptr %l3, !tbaa !24
  store i64 %t118, ptr %l55, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l56, !tbaa !24
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb37, label %bb38
bb37:
  %t123 = load i64, ptr %l55, !tbaa !24
  %t124 = icmp sle i64 0, %t123
  br i1 %t124, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb39:
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = icmp sle i64 %t126, %t127
  br i1 %t128, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
bb41:
  %t130 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l55, !tbaa !24
  %t133 = getelementptr i8, ptr %t131, i64 0
  %t134 = sub i64 %t132, 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = extractvalue { i64, ptr } %t136, 0
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t138, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t142, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_249ae2d6db78c99d_2e3c698f52d646b9)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdoc_2epushBuilders(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %lp11 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/doc:Entry"
  %l40 = alloca %"compiler/doc:Entry"
  %l41 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca %"compiler/doc:Entry"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t59 = alloca %"compiler/doc:Entry", align 8
  %t162 = alloca %"compiler/doc:Entry", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %l5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t2 = load i64, ptr %l8, !tbaa !24
  store i64 %t2, ptr %l13, !tbaa !24
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp slt i64 %t6, %t7
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load i64, ptr %l20, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t40, i32 %t39)
  store { i64, ptr } %t42, ptr %l31
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t49, ptr %lp10
  %t51 = load ptr, ptr %lp10
  store { i64, ptr } %t48, ptr %t51, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %lp10
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t66 = call i32 @compiler_2fdoc_2eEntry_2eitem(ptr %t59, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t52, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %t57, i1 %a6)
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb10, label %ok.68, !prof !99
ok.68:
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t59, i64 152, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %l40, i64 152, i1 false)
  br label %bb12
bb10:
  %t69 = load i32, ptr %l41, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb12:
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 152, i64 8)
  store ptr %t73, ptr %lp11
  %t74 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %l33, i64 152, i1 false)
  %t75 = load ptr, ptr %lp11
  %t76 = getelementptr %"compiler/doc:Entry", ptr %t75, i32 0, i32 6
  store i1 true, ptr %t76, !tbaa !21
  %t77 = call ptr @__olang_scope_hold(ptr %v3)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l44, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = call ptr @__olang_region_make(ptr %v3)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l49
  br label %bb15
bb15:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/load:Loader", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s2, ptr %t101, ptr %t100)
  store { i64, ptr } %t103, ptr %l54
  br label %bb16
bb16:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l58, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l62
  br label %bb17
bb17:
  %t122 = load ptr, ptr %l62, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Func", ptr %t122, i32 0, i32 9
  %t125 = load i32, ptr %t124, !tbaa !23
  %t126 = load ptr, ptr %l58, !tbaa !29
  %t128 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t126, i32 %t125)
  store { i64, ptr } %t128, ptr %l65
  br label %bb18
bb18:
  %t129 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = load i64, ptr %l44
  %t140 = inttoptr i64 %t139 to ptr
  %t141 = call ptr @__olang_held_alloc(ptr %t140, i64 %t138)
  call void @olang_textcopy(ptr %t141, ptr %t130, i64 %t131)
  %t142 = getelementptr i8, ptr %t141, i64 %t131
  call void @olang_textcopy(ptr %t142, ptr %t132, i64 %t133)
  %t143 = getelementptr i8, ptr %t142, i64 %t133
  call void @olang_textcopy(ptr %t143, ptr %t136, i64 %t137)
  %t144 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  %t147 = load ptr, ptr %lp11
  %t148 = getelementptr %"compiler/doc:Entry", ptr %t147, i32 0, i32 8
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  store { i64, ptr } %t149, ptr %l68, !tbaa !27
  %t151 = load ptr, ptr %lp11
  %t152 = getelementptr %"compiler/doc:Entry", ptr %t151, i32 0, i32 8
  store { i64, ptr } %t145, ptr %t152, !tbaa !27
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e8
  br i1 %t153, label %bb19, label %bb20
bb19:
  %t155 = load { i64, ptr }, ptr %l68
  %t156 = extractvalue { i64, ptr } %t155, 1
  call void @__olang_region_release(ptr %t156)
  store { i64, ptr } zeroinitializer, ptr %l68
  br label %bb20
bb20:
  %t159 = getelementptr %"compiler/doc:Entry", ptr %a4, i32 0, i32 5
  %t160 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t160, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %l72, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v3, ptr %v3, ptr %t159, ptr %t162)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb1
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdoc_2ereceiverModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a1)
  store i32 %t20, ptr %l12
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l13, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  store i32 %t31, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l21
  br label %bb4
bb4:
  %t43 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l28
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t58 = load i32, ptr %l28, !tbaa !23
  store i32 %t58, ptr %l2, !tbaa !23
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l33
  br label %bb9
bb9:
  %t69 = load i32, ptr %l33, !range !{i32 0, i32 33}
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l39, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l44
  br label %bb13
bb13:
  %t91 = load ptr, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l44, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t91, i32 %t92)
  store i64 %t93, ptr %l45
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdoc_2evarNamed(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l61 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb32
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 22}
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb25
bb9:
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb10, label %bb11
bb10:
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb12:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l38, !tbaa !24
  store i64 %t71, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t72 = load i64, ptr %l35, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l47, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = icmp slt i64 %t75, 2147483648
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  %t81 = and i1 %t76, %t78
  store i1 %t81, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l61, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t113 = icmp eq i32 %t109, %a1
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t115 = load ptr, ptr %l6, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l67, !tbaa !27
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/source:Span", ptr %t122, i64 %t119
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store i64 %t127, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb16
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8ab72cd26d658e2b_1072abfe1978b2bf)
  unreachable
bb30:
  br label %bb31
bb31:
  %t134 = load i64, ptr %l3, !tbaa !24
  %t137 = add i64 %t134, 1
  store i64 %t137, ptr %l3, !tbaa !24
  br label %bb1
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2ewordsOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb33
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t19)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 95
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l14, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l2, !tbaa !24
  br label %bb32
bb11:
  br label %bb12
bb12:
  %t41 = load i64, ptr %l2, !tbaa !24
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp slt i64 %t43, %t46
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = call i1 @compiler_2fdoc_2ewordChar(i8 %t57)
  store i1 %t59, ptr %l32
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t60 = load i1, ptr %l32, !tbaa !21
  store i1 %t60, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l28, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l2, !tbaa !24
  br label %bb21
bb21:
  br label %bb13
bb22:
  store ptr %l1, ptr %l37, !tbaa !29
  %t69 = call ptr @__olang_scope_hold(ptr %v1)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l38, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = call ptr @__olang_region_make(ptr %v1)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l38, !tbaa !24
  br label %bb24
bb24:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l40, !tbaa !27
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %l42, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l43, !tbaa !24
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = icmp sge i64 %t80, 0
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t83 = load i64, ptr %l41, !tbaa !24
  %t84 = load i64, ptr %l42, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb27:
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = load i64, ptr %l43, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb29:
  %t91 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l42, !tbaa !24
  %t95 = getelementptr i8, ptr %t92, i64 %t93
  %t96 = sub i64 %t94, %t93
  %t97 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = extractvalue { i64, ptr } %t98, 0
  %t102 = load i64, ptr %l38
  %t103 = inttoptr i64 %t102 to ptr
  %t104 = call ptr @__olang_held_alloc(ptr %t103, i64 %t101)
  call void @olang_textcopy(ptr %t104, ptr %t100, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t108 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t108, { i64, ptr } %t106)
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_648623c9a60da9e4_705f5426fdf26810)
  unreachable
bb31:
  br label %bb32
bb32:
  br label %bb2
bb33:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"compiler/doc:Example" @compiler_2fdoc_3aExample_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/doc:Example"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/doc:Example" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/doc:Example" %t6, { i64, ptr } %a1, 1
  store %"compiler/doc:Example" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/doc:Example", ptr %rv
  ret %"compiler/doc:Example" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d3 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d8 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e1 = weak hidden constant i1 false
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_region_release(ptr) noinline
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d11 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@olang_2esole_2ecompiler__2fdoc__2eEntry__2eitem_2elocal_2e15 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
declare ptr @__olang_region_make_part(ptr) noinline
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fn (" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0A    " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0A    " }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"meets " }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<h1>" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</h1>\0A<ul>\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0 = weak hidden constant i1 false
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca %"compiler/doc:Entry"
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make_part(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/doc:Entry", ptr %t7, i32 0, i32 5
  %t9 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t8, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = mul i64 %t12, 152
  %t14 = load i64, ptr %l1
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  %t17 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/doc:Entry", ptr %t24, i32 0, i32 5
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = icmp slt i64 %t23, %t27
  br i1 %t28, label %bb8, label %bb6
bb5:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/doc:Entry", ptr %t31, i32 0, i32 5
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t32, i32 0, i32 0
  store { i64, ptr } %t30, ptr %t33, !tbaa !27
  %t34 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t34, label %bb10, label %bb11
bb6:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/doc:Entry", ptr %t38, i64 %t36
  call void @llvm.memset.p0.i64(ptr %t39, i8 0, i64 152, i1 false)
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb3
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/doc:Entry", ptr %t42, i32 0, i32 5
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/doc:Entry", ptr %t47, i64 %t45
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t48, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l8)
  br label %bb9
bb9:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/doc:Entry", ptr %t52, i64 %t50
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %l8, i64 152, i1 false)
  br label %bb7
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/doc:Entry", ptr %t54, i32 0, i32 5
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t55, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp eq i64 %t58, 0
  br i1 %t60, label %bb12, label %bb13
bb11:
  %t62 = call ptr @__olang_scope_hold(ptr %v0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l13, !tbaa !24
  %t64 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t64, label %bb14, label %bb15
bb12:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/doc:Entry", ptr %t66, i32 0, i32 5
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t67, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t68, !tbaa !27
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/doc:Entry", ptr %t69, i32 0, i32 5
  %t71 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %l1
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = load { i64, ptr }, ptr %t71
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_settle_in(ptr %t73, ptr %t78)
  br label %bb11
bb14:
  %t79 = call ptr @__olang_region_make_part(ptr %v0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l13, !tbaa !24
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/doc:Entry", ptr %t81, i32 0, i32 7
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 32
  %t89 = load i64, ptr %l13
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = call ptr @__olang_held_alloc(ptr %t90, i64 %t88)
  %t92 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l17, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l16, !tbaa !24
  %t99 = mul i64 %t98, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/doc:Entry", ptr %t101, i32 0, i32 7
  %t103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t102, i32 0, i32 0
  store { i64, ptr } %t100, ptr %t103, !tbaa !27
  %t104 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/doc:Entry", ptr %t106, i32 0, i32 7
  %t108 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t107, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb18, label %bb19
bb17:
  br label %ret
bb18:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/doc:Entry", ptr %t114, i32 0, i32 7
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t116, !tbaa !27
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/doc:Entry", ptr %t117, i32 0, i32 7
  %t119 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %l13
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = load { i64, ptr }, ptr %t119
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = icmp ne ptr %t124, null
  %t126 = select i1 %t125, ptr %t124, ptr null
  call void @__olang_region_settle_in(ptr %t121, ptr %t126)
  br label %bb17
ret:
  ret void
}

@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<li><a href=\22" }>, align 8
@.d28 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22><code>" }>, align 8
@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"</code></a>" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</li>\0A" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</ul>\0A" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"#!" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import\22" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aModule_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aModule_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aModule_2e2 = weak hidden constant i1 false
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_40(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e8 = weak hidden constant i1 false
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/doc:Entry"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 152, i1 false)
  %t2 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/doc:Entry", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0 = weak hidden constant i1 false
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e5 = weak hidden constant i1 false
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/doc:Entry", ptr %t3, i32 0, i32 5
  %t5 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = call ptr @__olang_region_or(ptr %t7, ptr null)
  %t9 = call ptr @__olang_region_home(ptr %t8)
  %t10 = icmp ne ptr %t9, null
  %t11 = select i1 %t10, ptr %t9, ptr null
  call void @__olang_region_drop(ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t4
  br label %bb2
bb2:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t14, i32 0, i32 7
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_drop(ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t15
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/doc:Entry", ptr %t24, i32 0, i32 5
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = icmp slt i64 %t23, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/doc:Entry", ptr %t30, i32 0, i32 5
  %t32 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/doc:Entry", ptr %t35, i64 %t33
  call void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %t36)
  br label %bb8
bb7:
  %t38 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t38, label %bb9, label %bb10
bb8:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb5
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/doc:Entry", ptr %t42, i32 0, i32 5
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  call void @__olang_region_release_part(ptr %t47, i64 %t46)
  store { i64, ptr } zeroinitializer, ptr %t44
  br label %bb10
bb10:
  %t48 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Entry", ptr %t50, i32 0, i32 7
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t51, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  call void @__olang_region_release_part(ptr %t55, i64 %t54)
  store { i64, ptr } zeroinitializer, ptr %t52
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"<p><a href=\22index.html\22>index</a></p>\0A<h1>" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</h1>\0A" }>, align 8
@.d57 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"<pre>import \22" }>, align 8
@.d58 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22</pre>\0A" }>, align 8
@.d59 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<h2>Index</h2>\0A<ul>\0A" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" class=\22dep\22" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"<li><a href=\22#" }>, align 8
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\22><code" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d66 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</code></a></li>\0A" }>, align 8
@.d67 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"</ul>\0A<h2>Items</h2>\0A" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"module " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"<div class=\22doc\22>" }>, align 8
define internal void @olang_lambda_76(ptr %env, ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb5
bb5:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  br i1 %a2, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s2, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l12
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t17, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t19, ptr %l16
  br label %bb10
bb8:
  %t20 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t35, { i64, ptr } %t33)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  %t37 = load i1, ptr %l16, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l17, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s5, { i64, ptr } %t39)
  store { i64, ptr } %t41, ptr %l19
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l22, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = call { i64, ptr } @compiler_2fdoc_2eEscape(ptr %s0, ptr %s7, { i64, ptr } %t43)
  store { i64, ptr } %t45, ptr %l24
  br label %bb15
bb13:
  %t46 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t48 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = getelementptr i8, ptr %t55, i64 %t47
  call void @olang_textcopy(ptr %t56, ptr %t49, i64 %t50)
  %t57 = getelementptr i8, ptr %t56, i64 %t50
  call void @olang_textcopy(ptr %t57, ptr %t52, i64 %t53)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t55, 1
  %t61 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t61, { i64, ptr } %t59)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb15:
  %t63 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t65 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t63, i64 %t64)
  %t73 = getelementptr i8, ptr %t72, i64 %t64
  call void @olang_textcopy(ptr %t73, ptr %t66, i64 %t67)
  %t74 = getelementptr i8, ptr %t73, i64 %t67
  call void @olang_textcopy(ptr %t74, ptr %t69, i64 %t70)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t72, 1
  %t78 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t78, { i64, ptr } %t76)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s7)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t80)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d79 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d80 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<div class=\22member\22>" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" class=\22dep\22" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"<pre id=\22" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d87 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</pre>\0A" }>, align 8
@.d88 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"<details class=\22example\22><summary>Example: " }>, align 8
@.d89 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</summary><pre>" }>, align 8
@.d90 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</pre></details>\0A" }>, align 8
@.d91 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"<h3 class=\22member\22>Builders</h3>\0A" }>, align 8
@.d92 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</div>\0A" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"   # deprecated" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d100 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    example \22" }>, align 8
@.d101 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d102 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d103 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    builders\0A" }>, align 8
@.d104 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@olang_2esole_2ecompiler_2fdoc_3aExample_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aExample_2e1 = weak hidden constant i1 false
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c". " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d109 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d111 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Deprecated:" }>, align 8
@.d112 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<pre>" }>, align 8
@.d113 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"</pre>" }>, align 8
@.d114 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"<p class=\22note\22>" }>, align 8
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
@.d116 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<p>" }>, align 8
@.d117 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"</p>" }>, align 8
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/doc:Entry"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/doc:Entry", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 152
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t14, i64 %t12
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fdoc_3aEntry(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 152, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/doc:Entry", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 152, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_39c265aa723c0dcb_f35d02a7366497b7 = external constant [0 x i8]
declare i1 @compiler_2fdoc_2ecommentOnly(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_19c80d7aab96fce_b433fa540154765a = external constant [0 x i8]
@olang_loc_9683d737f51f9c2d_3e5fa69f874e5ef9 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_89c63e526fea8550_9190d8cdbdd5cacc = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_51c1b9bde331172f_b1d3b315fa602c93 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_8d5034eaa81491fd_13883a423d047079 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_af70a68dd18f91cd_78b5556af2db7259 = external constant [0 x i8]
@olang_loc_98679b512d162ff0_b3a7bdc1615dd2ac = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2d405ddcd9a8ab59_87891e6f641f4355 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdoc_2efirstLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdoc_3aEntry_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2fdoc_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eLen_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eAt_3ccompiler_2fdoc_3aEntry_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eRefMut_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ePush_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_280c17d24f0b9a32_ec56e4f0207863ae = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdoc_2eEscape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2epage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b461083f788c6b86_e65d814f8bc052da = external constant [0 x i8]
@olang_loc_b4b87f1043b41663_258689a2c0d07437 = external constant [0 x i8]
@olang_loc_a37384dcd940e048_c3ba5fc94841a74c = external constant [0 x i8]
@olang_loc_c14737b94c4967d9_488ba51a50b8fbfd = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2eSetAt_3ccompiler_2fdoc_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_aa580bdfcb2172ca_10b69c24ef22e0a6 = external constant [0 x i8]
@olang_loc_5ae7e5dcd5a7f5a7_fbb3b56461f27903 = external constant [0 x i8]
@olang_loc_c23ed26ca5ddcffc_eddff7587c8384e8 = external constant [0 x i8]
@olang_loc_8c4dbcba0a97fde9_988e318d0852f0c5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_722baa3fc26cfee7_b02c6ccf1a7d7c8b = external constant [0 x i8]
@olang_loc_91fc21a6b7496c0a_24bc2c9db083308e = external constant [0 x i8]
@olang_loc_f657276e2350bf29_71dbd11cb4dae2ed = external constant [0 x i8]
@olang_loc_8ef8e25bc783e73c_af1dce04e2424510 = external constant [0 x i8]
@olang_loc_e4977d0c8bb13ec3_d6b61981e1b0bcef = external constant [0 x i8]
@olang_loc_a19d25c11d1c900e_ebad96d485f5fa5a = external constant [0 x i8]
@olang_loc_2d0d65f28716dc0b_2ad69f27bb061bb7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdoc_2eindented(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_d85afc985d0ab39_76fcb7f235eece65 = external constant [0 x i8]
@olang_loc_1f1e658c6da2070c_2842ab33ef4c4808 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_d85c9f08fc02aff9_18b1e7df62bde535 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fast_2eTestTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fast_2eTestDesc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2ePush_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Example" %a1)
@olang_loc_82ead09773c0d67a_6116d0cf5a0b9e8e = external constant [0 x i8]
@olang_loc_5be1599e6a61f501_71a8850ae192da35 = external constant [0 x i8]
@olang_loc_fe551cd114f4cb63_729eb01933a49f67 = external constant [0 x i8]
@olang_loc_46ab965e7000f695_6c81a9a0ef748b89 = external constant [0 x i8]
@olang_loc_301af787a8ab5449_ce9576e6695793ad = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0afceaceca5551a_2521421923c730de = external constant [0 x i8]
declare i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_bbff6dd16e0207fa_fe10dea2b5bb774e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_fdfaf893749e1d49_869eafdea154472d = external constant [0 x i8]
@olang_loc_2c161ece78a24477_8abc4a29ddab9f5b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberModule(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberInPlace(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberSpan(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_1cb365347d6e720_3c1b65543fd0c444 = external constant [0 x i8]
@olang_loc_735c5a3de920021b_138313d8ba3a6daf = external constant [0 x i8]
@olang_loc_93a5825f4266fe40_3fd51f523aa7a28c = external constant [0 x i8]
@olang_loc_249ae2d6db78c99d_2e3c698f52d646b9 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8ab72cd26d658e2b_1072abfe1978b2bf = external constant [0 x i8]
declare i1 @compiler_2fdoc_2ewordChar(i8 %a0)
@olang_loc_648623c9a60da9e4_705f5426fdf26810 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
