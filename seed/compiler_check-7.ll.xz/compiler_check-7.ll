; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
define dso_local ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 5}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [6 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { { i64, ptr }, ptr }, ptr %t30, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l23, !tbaa !29
  br label %bb14
bb13:
  store ptr null, ptr %l23, !tbaa !29
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l23, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store ptr null, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe14b63572f1977b_411de5df8083206f)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_980c9dc24d8ab357_bac7a576dce6b97b)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eViewsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l37 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp slt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 14
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 14
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  store ptr %t30, ptr %l2, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v0, ptr %t31, ptr %t32)
  store i64 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 7
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t49, i64 %t50)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l34
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb13, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l33
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t58 = load i64, ptr %l33, !tbaa !24
  store i64 %t58, ptr %l27, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l27, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l4
  %t65 = load { i64, [2 x i64] }, ptr %l4
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb24
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t83)
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l48
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb21, label %ok.90, !prof !99
ok.90:
  store i64 %t87, ptr %l47
  br label %bb20
bb20:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l41, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l37, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f6ac6f37bd028998_7777cf96519f6a94)
  unreachable
bb29:
  %t93 = load i64, ptr %l37, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/typed:Local"
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l76 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l5, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l5, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l16
  br label %bb3
bb3:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i1, ptr %l20, !tbaa !21
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l34
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l24, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t55 = load i32, ptr %l34, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t53, i32 %t54, i32 %t55)
  store i1 %t56, ptr %l35
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  store i1 %t57, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l21, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l37, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l38
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t63, i32 %a2)
  store { i64, ptr } %t67, ptr %l41
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l45
  br label %bb17
bb17:
  %t80 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t89 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t87, { i64, ptr } %t86)
  store %"compiler/diagmsg:Msg" %t89, ptr %l47
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l37, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l38
  %t92 = load %"compiler/diagmsg:Msg", ptr %l47
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t90, %"compiler/source:Span" %t91, %"compiler/diagmsg:Msg" %t92)
  store i64 %t93, ptr %l48
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l50
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Body", ptr %t97, i32 0, i32 7
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t99, i64 %t100)
  store %"compiler/typed:Local" %t103, ptr %l54
  br label %bb22
bb22:
  %t104 = load %"compiler/typed:Local", ptr %l54
  store %"compiler/typed:Local" %t104, ptr %l6
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l57, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l62
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l5, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l67
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l72
  br label %bb25
bb25:
  %t141 = load i64, ptr %l67, !tbaa !24
  %t142 = load i64, ptr %l72, !tbaa !24
  %t143 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t141, i64 %t142)
  store i64 %t143, ptr %l73
  br label %bb26
bb26:
  %t144 = load ptr, ptr %l57, !tbaa !29
  %t145 = load i32, ptr %l62, !tbaa !23
  %t146 = load i64, ptr %l73, !tbaa !24
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t144, i32 %t145, i64 %t146)
  store i32 %t147, ptr %l74
  br label %bb27
bb27:
  %t148 = load i32, ptr %l74, !tbaa !23
  %t149 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  store i32 %t148, ptr %t149, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l76
  br label %bb28
bb28:
  %t153 = load ptr, ptr %l76, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Body", ptr %t153, i32 0, i32 7
  %t156 = load i64, ptr %l3, !tbaa !24
  %t157 = load %"compiler/typed:Local", ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t155, i64 %t156, %"compiler/typed:Local" %t157)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/generic:Unmet"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/generic:Unmet"
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca %"std/prelude/text:StringBuilder"
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l54 = alloca i64
  %l59 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"compiler/diagmsg:Msg"
  %l77 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t4, i32 %t5, i32 %t6, i1 true, i64 0)
  store %"compiler/generic:Unmet" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:Unmet", ptr %l13
  store %"compiler/generic:Unmet" %t11, ptr %l4
  %t12 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l19
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 5
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %t27, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb8
bb7:
  %t33 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb17, label %bb18
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = call %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %s2, ptr %t40, i32 %t42)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l28
  br label %bb12
bb12:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l28
  store %"std/prelude/text:StringBuilder" %t46, ptr %l6
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t48, ptr %l30
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l33
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l34, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t61, ptr %l35, !tbaa !27
  %t63 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l6)
  store { i64, ptr } %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %s2, ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t71, { i64, ptr } %t72, { i64, ptr } %t70)
  store %"compiler/diagmsg:Msg" %t74, ptr %l39
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l29, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l30
  %t77 = load %"compiler/diagmsg:Msg", ptr %l39
  %t78 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t75, %"compiler/source:Span" %t76, %"compiler/diagmsg:Msg" %t77)
  store i64 %t78, ptr %l40
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l42, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t80, ptr %l43
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l46
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l69, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t87, ptr %l70
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l73
  br label %bb30
bb19:
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t100, ptr %l48, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t101, i32 %t103)
  store { i64, ptr } %t106, ptr %l51
  br label %bb20
bb20:
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t114 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t117 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %s5, ptr %s0, ptr %s5, ptr %s5, { i64, ptr } %t114, { i64, ptr } %t115, { i64, ptr } %t113)
  store %"compiler/diagmsg:Msg" %t117, ptr %l53
  br label %bb21
bb21:
  %t118 = load ptr, ptr %l42, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l43
  %t120 = load %"compiler/diagmsg:Msg", ptr %l53
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t118, %"compiler/source:Span" %t119, %"compiler/diagmsg:Msg" %t120)
  store i64 %t121, ptr %l54
  br label %bb22
bb22:
  %t122 = load i64, ptr %l54, !tbaa !24
  store i64 %t122, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  %t128 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t133 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t126, i32 %t127, i32 %t129)
  store i64 %t133, ptr %l59
  br label %bb23
bb23:
  %t134 = load i64, ptr %l59, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l62, !tbaa !29
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l64, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t144 = load i32, ptr %t143, !tbaa !23
  %t147 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t142, i32 %t144)
  store { i64, ptr } %t147, ptr %l67
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t148 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t149 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %s6, { i64, ptr } %t148)
  store %"compiler/diagmsg:Msg" %t149, ptr %l68
  br label %bb27
bb27:
  %t150 = load ptr, ptr %l62, !tbaa !29
  %t151 = load i64, ptr %l63, !tbaa !24
  %t152 = load i64, ptr %l64, !tbaa !24
  %t153 = load %"compiler/diagmsg:Msg", ptr %l68
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s6, ptr %t150, i64 %t151, i64 %t152, %"compiler/diagmsg:Msg" %t153)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb30:
  %t154 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %s7, ptr %s0, ptr %s7, { i64, ptr } %t160, { i64, ptr } %t161)
  store %"compiler/diagmsg:Msg" %t164, ptr %l76
  br label %bb31
bb31:
  %t165 = load ptr, ptr %l69, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l70
  %t167 = load %"compiler/diagmsg:Msg", ptr %l76
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l77
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l13 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %t7, i32 %t8, %"compiler/source:Span" %t6)
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l13, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 3, ptr %t17
  %t19 = insertvalue { i64, i64, i64 } undef, i64 %t7, 0
  %t21 = insertvalue { i64, i64, i64 } %t19, i64 %t11, 1
  %t23 = insertvalue { i64, i64, i64 } %t21, i64 %t15, 2
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  store { i64, i64, i64 } %t23, ptr %t24
  %t25 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l16, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t37, i32 %t41)
  store { i64, ptr } %t44, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t46, ptr %l26
  br label %bb10
bb10:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2epastAway(ptr %v1, ptr %v2, ptr %a1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = call ptr @compiler_2fcheck_2ewholeTemp(ptr %v2, ptr %v2, ptr %t20)
  store ptr %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l16, !tbaa !29
  store ptr %t23, ptr %l8, !tbaa !29
  br label %bb20
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Promote", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2epastAway(ptr %v2, ptr %v2, ptr %t42)
  store ptr %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l8, !tbaa !29
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store ptr null, ptr %l8, !tbaa !29
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_943b293e8fd49f1f_6252e979531a6d2b)
  unreachable
bb20:
  %t47 = load ptr, ptr %l8, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb24
bb22:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v2, ptr %a0, ptr %t53)
  store i1 %t56, ptr %l32
  br label %bb23
bb23:
  %t57 = load i1, ptr %l32, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l29, !tbaa !21
  br label %bb24
bb24:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t62 = load ptr, ptr %l5, !tbaa !29
  store ptr %t62, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %t32, ptr %t33, i64 %t34, i32 %t35, i32 %t36)
  br label %bb9
bb9:
  br label %bb51
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t57, ptr %t58, ptr %t59)
  br label %bb16
bb16:
  br label %bb51
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t79, ptr %t80, ptr %t81)
  br label %bb23
bb23:
  br label %bb51
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t111, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb51
bb32:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t122 = load ptr, ptr %l64, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load ptr, ptr %l9, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Payload", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t136, ptr %t137, ptr %t141)
  br label %bb38
bb38:
  br label %bb51
bb39:
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 8}
  %t153 = icmp eq i64 %t151, 6
  store i1 %t153, ptr %l76, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t161, ptr %t162, ptr %t163)
  br label %bb45
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e)
  unreachable
bb51:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeRefusal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb38
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = load i32, ptr %l4, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyRefusal(ptr %v0, ptr %v2, ptr %a0, i64 %t39)
  store { i64, ptr } %t42, ptr %l23
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  br label %bb37
bb12:
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 5}
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l13, !tbaa !27
  br label %bb37
bb18:
  %t55 = load ptr, ptr %l3, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 5}
  %t62 = icmp eq i64 %t60, 2
  store i1 %t62, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t64, ptr %l13, !tbaa !27
  br label %bb37
bb24:
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 5}
  %t73 = icmp eq i64 %t71, 3
  store i1 %t73, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t74 = load i1, ptr %l37, !tbaa !21
  br i1 %t74, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t75, ptr %l13, !tbaa !27
  br label %bb37
bb30:
  %t77 = load ptr, ptr %l3, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t78 = load ptr, ptr %l42, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l42, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 5}
  %t84 = icmp eq i64 %t82, 4
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t86, ptr %l13, !tbaa !27
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4f357d5c515ec460_c39407ade47891c4)
  unreachable
bb37:
  %t88 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l48, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t101, ptr %l13, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t103, ptr %l51, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l52, !tbaa !24
  %t106 = load i64, ptr %l52, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l53, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l52, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t117, ptr %l51, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_5259ca87fe3b4871_3fe667824d420b5)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyRefusal(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb10
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l19
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t34, i64 %t35)
  store ptr %t36, ptr %l20
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Func", ptr %t37, i32 0, i32 7
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t44, ptr %l23, !tbaa !27
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb10:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t52 = load { i64, [2 x i64] }, ptr %l2
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 2
  br i1 %t55, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7a179da39a9781e9_720543b731edd2ed)
  unreachable
bb21:
  %t61 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l36, !tbaa !24
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = mul i64 %t72, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/typed:Block"
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l35 = alloca %"compiler/typed:If"
  %rv = alloca ptr
  %t15 = alloca { i64, [3 x i64] }, align 8
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 37
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t10, 0
  %t20 = insertvalue { %"compiler/source:Span", i32, i32 } %t18, i32 0, 1
  %t22 = insertvalue { %"compiler/source:Span", i32, i32 } %t20, i32 %t13, 2
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t22, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t24, ptr %t26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t9, ptr %t26)
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 7
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l23, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 37
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store { i64, ptr } %t45, ptr %l27
  br label %bb4
bb4:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t48 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t46, { i64, ptr } %t47)
  store %"compiler/typed:Block" %t48, ptr %l28
  br label %bb5
bb5:
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t49, ptr %lp5
  %t50 = load %"compiler/typed:Block", ptr %l28
  %t51 = load ptr, ptr %lp5
  store %"compiler/typed:Block" %t50, ptr %t51
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v0, ptr %t53, %"compiler/source:Span" %t54, ptr %a2)
  store ptr %t59, ptr %l33
  br label %bb6
bb6:
  %t60 = load ptr, ptr %lp5
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t63 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t61, ptr %t60, ptr null)
  store %"compiler/typed:If" %t63, ptr %l35
  br label %bb7
bb7:
  %t64 = load %"compiler/typed:If", ptr %l35
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:If" %t64, ptr %t65
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 3, ptr %t67
  %t68 = load %"compiler/source:Span", ptr %l29
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t68, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t65, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNameTaken(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l87 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t13, i32 %t14, i32 %t15)
  store i1 %t19, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l17, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l18, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l17, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t38)
  store i1 %t40, ptr %l20
  br label %bb10
bb10:
  %t41 = load i1, ptr %l20, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb12:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb18
bb16:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t47, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t49, ptr %l26
  br label %bb17
bb17:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb22
bb20:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t54, ptr %l29
  br label %bb21
bb21:
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb26
bb24:
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t59, ptr %l32
  br label %bb25
bb25:
  %t60 = load i1, ptr %l32, !tbaa !21
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb26
bb26:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb30
bb28:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t64, ptr %l35
  br label %bb29
bb29:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb30
bb30:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb34
bb32:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t67, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t69, ptr %l38
  br label %bb33
bb33:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l36, !tbaa !21
  br label %bb34
bb34:
  %t71 = load i1, ptr %l36, !tbaa !21
  br i1 %t71, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb38
bb36:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t74, ptr %l41
  br label %bb37
bb37:
  %t75 = load i1, ptr %l41, !tbaa !21
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb38
bb38:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb42
bb40:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t79, ptr %l44
  br label %bb41
bb41:
  %t80 = load i1, ptr %l44, !tbaa !21
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb42
bb42:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb46
bb44:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t82, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t84, ptr %l47
  br label %bb45
bb45:
  %t85 = load i1, ptr %l47, !tbaa !21
  store i1 %t85, ptr %l45, !tbaa !21
  br label %bb46
bb46:
  %t86 = load i1, ptr %l45, !tbaa !21
  br i1 %t86, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb50
bb48:
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t89, ptr %l50
  br label %bb49
bb49:
  %t90 = load i1, ptr %l50, !tbaa !21
  store i1 %t90, ptr %l48, !tbaa !21
  br label %bb50
bb50:
  %t91 = load i1, ptr %l48, !tbaa !21
  br i1 %t91, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb54
bb52:
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t92, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t94, ptr %l53
  br label %bb53
bb53:
  %t95 = load i1, ptr %l53, !tbaa !21
  store i1 %t95, ptr %l51, !tbaa !21
  br label %bb54
bb54:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb58
bb56:
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t99, ptr %l56
  br label %bb57
bb57:
  %t100 = load i1, ptr %l56, !tbaa !21
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb58
bb58:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t102, ptr %l58, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l59, !tbaa !24
  %t105 = load i64, ptr %l59, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l60, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l59, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t116, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l63
  br label %bb62
bb62:
  %t123 = load i1, ptr %l63, !tbaa !21
  br i1 %t123, label %bb63, label %bb64
bb63:
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t124, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t126, ptr %l66
  br label %bb65
bb64:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb86
bb65:
  %t127 = load i1, ptr %l66, !tbaa !21
  br i1 %t127, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb69
bb67:
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t128, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t130, ptr %l69
  br label %bb68
bb68:
  %t131 = load i1, ptr %l69, !tbaa !21
  store i1 %t131, ptr %l67, !tbaa !21
  br label %bb69
bb69:
  %t132 = load i1, ptr %l67, !tbaa !21
  br i1 %t132, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb73
bb71:
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t135, ptr %l72
  br label %bb72
bb72:
  %t136 = load i1, ptr %l72, !tbaa !21
  store i1 %t136, ptr %l70, !tbaa !21
  br label %bb73
bb73:
  %t137 = load i1, ptr %l70, !tbaa !21
  br i1 %t137, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb77
bb75:
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t140, ptr %l75
  br label %bb76
bb76:
  %t141 = load i1, ptr %l75, !tbaa !21
  store i1 %t141, ptr %l73, !tbaa !21
  br label %bb77
bb77:
  %t142 = load i1, ptr %l73, !tbaa !21
  br i1 %t142, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb81
bb79:
  %t143 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t143, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t145, ptr %l78
  br label %bb80
bb80:
  %t146 = load i1, ptr %l78, !tbaa !21
  store i1 %t146, ptr %l76, !tbaa !21
  br label %bb81
bb81:
  %t147 = load i1, ptr %l76, !tbaa !21
  br i1 %t147, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb85
bb83:
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t148, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t150, ptr %l81
  br label %bb84
bb84:
  %t151 = load i1, ptr %l81, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb85
bb85:
  %t152 = load i1, ptr %l79, !tbaa !21
  store i1 %t152, ptr %l64, !tbaa !21
  br label %bb86
bb86:
  %t153 = load i1, ptr %l64, !tbaa !21
  br i1 %t153, label %bb87, label %bb88
bb87:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l84, !tbaa !24
  %t157 = load i64, ptr %l84, !tbaa !24
  %t158 = mul i64 %t157, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l85, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  %t168 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t168, ptr %l83, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t169 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  %t170 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t172, ptr %l87
  br label %bb90
bb90:
  %t173 = load i1, ptr %l87, !tbaa !21
  br i1 %t173, label %bb91, label %bb92
bb91:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t178, ptr %l91
  br label %bb93
bb92:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb94
bb93:
  %t179 = load i1, ptr %l91, !tbaa !21
  store i1 %t179, ptr %l88, !tbaa !21
  br label %bb94
bb94:
  %t180 = load i1, ptr %l88, !tbaa !21
  br i1 %t180, label %bb95, label %bb96
bb95:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l1, !tbaa !23
  %t185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v0, ptr %t181, i32 %t182)
  store ptr %t185, ptr %l95
  br label %bb97
bb96:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb98
bb97:
  %t186 = load ptr, ptr %l95, !tbaa !29
  %t188 = getelementptr %"compiler/check:rawTable", ptr %t186, i32 0, i32 0
  %t189 = load i32, ptr %t188, !tbaa !23
  %t190 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t193 = icmp ne i32 %t189, %t190
  store i1 %t193, ptr %l92, !tbaa !21
  br label %bb98
bb98:
  %t195 = load i1, ptr %l92, !tbaa !21
  br i1 %t195, label %bb99, label %bb100
bb99:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t196, ptr %l101, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l102, !tbaa !24
  %t199 = load i64, ptr %l102, !tbaa !24
  %t200 = mul i64 %t199, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l103, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l102, !tbaa !24
  %t209 = mul i64 %t208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t205, ptr %t207, i64 %t209, i1 false)
  %t210 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t210, ptr %l101, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t211 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t211, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t212, ptr %l105, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l106, !tbaa !24
  %t215 = load i64, ptr %l106, !tbaa !24
  %t216 = mul i64 %t215, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  store { i64, ptr } %t219, ptr %l107, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l106, !tbaa !24
  %t225 = mul i64 %t224, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t221, ptr %t223, i64 %t225, i1 false)
  %t226 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t226, ptr %l105, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t227 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t227, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb15
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l16
  br label %bb9
bb8:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb14
bb9:
  %t25 = load i1, ptr %l16, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l22
  br label %bb12
bb12:
  %t36 = load i1, ptr %l22, !tbaa !21
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l18, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l13, !tbaa !21
  store i1 %t38, ptr %l9, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l9, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t17 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l5
  store i32 %a2, ptr %l6, !tbaa !23
  store ptr %a3, ptr %l7, !tbaa !29
  store { i64, ptr } %a4, ptr %l8, !tbaa !27
  %t6 = load %"compiler/source:Span", ptr %l1
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %t6)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %t11, { i64, ptr } %t12, i32 %t13, i1 false, i1 false)
  store %"compiler/typed:Call" %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load %"compiler/typed:Call", ptr %l13
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Call" %t15, ptr %t16
  store { i64, [5 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 0
  store i64 6, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l5
  %t20 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t19, 0
  %t21 = load i32, ptr %l6, !tbaa !23
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } %t20, i32 %t21, 1
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, ptr %t16, 2
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t24, ptr %t25
  %t26 = load { i64, [5 x i64] }, ptr %t17
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t26, ptr %t28
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca %"compiler/generic:Desc"
  %l15 = alloca %"compiler/generic:Desc"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Desc"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp sle i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = call %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %s1, i64 %t13, i32 %t14, i64 0, i64 0)
  store %"compiler/generic:Desc" %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  %t18 = load %"compiler/generic:Desc", ptr %l11
  store %"compiler/generic:Desc" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t22, i32 %t23)
  store %"compiler/generic:Desc" %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load %"compiler/generic:Desc", ptr %l15
  store %"compiler/generic:Desc" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Desc", ptr %rv
  ret %"compiler/generic:Desc" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i32
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i32, ptr %l17, !tbaa !23
  store i32 %t21, ptr %l8, !tbaa !23
  br label %bb29
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 98}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t45 = trunc i64 48 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i32 %t52, ptr %l31
  br label %bb15
bb14:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb16
bb15:
  %t53 = load i32, ptr %l31, !tbaa !23
  store i32 %t53, ptr %l28, !tbaa !23
  br label %bb16
bb16:
  %t54 = load i32, ptr %l28, !tbaa !23
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb29
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 98}
  store i32 %t68, ptr %l5
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l6, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t78, i32 0, i32 3
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t90 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v1, ptr %t82, i32 %t83, ptr %t84, ptr %t85)
  store i32 %t90, ptr %l46
  br label %bb23
bb23:
  %t91 = load i32, ptr %l46, !tbaa !23
  store i32 %t91, ptr %l8, !tbaa !23
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 0, ptr %l8, !tbaa !23
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_54e68041531f6906_51860f3f569bf3d2)
  unreachable
bb29:
  %t92 = load i32, ptr %l8, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i64
  %l16 = alloca %"compiler/check:errBind"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 57
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 57
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/check:errBind" %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = getelementptr %"compiler/check:errBind", ptr %l16, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t31 = icmp eq i32 %t27, %a1
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb3
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = zext i8 %t18 to i64
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l10, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l14 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb16
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 16
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l14
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l1, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 14
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l24
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %t42)
  store i64 %t43, ptr %l25
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb2
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l17 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca i32
  %l54 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca %"compiler/generic:Context"
  %l67 = alloca ptr
  %l70 = alloca i32
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:Block"
  %l105 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, [3 x i64] }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l125 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t115 = alloca %"compiler/generic:Context", align 8
  %t153 = alloca { i64, [3 x i64] }, align 8
  %t252 = alloca %"compiler/check:ContractAsk", align 8
  %t263 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 53
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp ne i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load i1, ptr %l27, !tbaa !21
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v1, ptr %t25)
  store i1 %t27, ptr %l30
  br label %bb11
bb11:
  %t28 = load i1, ptr %l30, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l2
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t51, ptr %l40
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 7, ptr %t71
  %t73 = insertvalue { i64, i32 } undef, i64 %t67, 0
  %t75 = insertvalue { i64, i32 } %t73, i32 %t69, 1
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64, i32 } %t75, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t77, ptr %l46
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t83, i32 0, i32 %t84, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t87, ptr %l51
  br label %bb17
bb17:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load { i64, [2 x i64] }, ptr %l46
  %t92 = load i32, ptr %l51, !tbaa !23
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t90, { i64, [2 x i64] } %t91, i32 %t92, i64 %t88, %"compiler/source:Span" %t89)
  store i64 %t95, ptr %l54
  br label %bb18
bb18:
  %t96 = load i64, ptr %l54, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 19
  %t100 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100, i64 1)
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t103, i64 %t104, i64 %t105, i32 %t106, i32 0)
  store ptr %t111, ptr %l62
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l62, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t115, ptr %v0, i64 %t114, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t115, i64 160, i1 false)
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = getelementptr %"compiler/check:frame", ptr %t117, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %l65, i64 160, i1 false)
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t119)
  store ptr %t121, ptr %l67
  br label %bb22
bb22:
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l67, !tbaa !29
  %t126 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t123, i32 -1, i32 0, %"compiler/source:Span" %t122)
  store i32 %t126, ptr %l70
  br label %bb23
bb23:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 37
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l73
  br label %bb24
bb24:
  %t132 = load i64, ptr %l73, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 37
  store ptr %t135, ptr %l75, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t136, ptr %l76
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l77, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l78
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t141 = load i64, ptr %l8, !tbaa !24
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t139, ptr %t140, i64 %t141)
  store ptr %t145, ptr %l82
  br label %bb25
bb25:
  %t146 = load i32, ptr %l4, !tbaa !23
  %t147 = load ptr, ptr %l77, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l78
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v0, ptr %v0, ptr %t147, %"compiler/source:Span" %t148, ptr %t149, i32 %t146)
  store ptr %t151, ptr %l84
  br label %bb26
bb26:
  %t152 = load ptr, ptr %l84, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 0
  store i64 6, ptr %t154
  %t155 = load %"compiler/source:Span", ptr %l76
  %t156 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t155, 0
  %t158 = insertvalue { %"compiler/source:Span", ptr } %t156, ptr %t152, 1
  %t159 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t158, ptr %t159
  %t160 = load { i64, [3 x i64] }, ptr %t153
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t160, ptr %t162
  %t163 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t163, ptr %t162)
  br label %bb27
bb27:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t165)
  store ptr %t167, ptr %l89
  br label %bb28
bb28:
  %t168 = load ptr, ptr %l89, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 37
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store { i64, ptr } %t175, ptr %l94
  br label %bb29
bb29:
  %t176 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t177 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t176)
  store %"compiler/typed:Block" %t177, ptr %l95
  br label %bb30
bb30:
  %t178 = load %"compiler/typed:Block", ptr %l95
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t178, ptr %t179
  %t181 = load ptr, ptr %l90, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Body", ptr %t181, i32 0, i32 11
  store ptr %t179, ptr %t182, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t183)
  br label %bb31
bb31:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 19
  %t188 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188, i64 2)
  br label %bb32
bb32:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/load:Loader", ptr %t197, i32 0, i32 4
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t200)
  store { { i64, [3 x i64] }, { i64, ptr } } %t202, ptr %l105
  br label %bb33
bb33:
  %t203 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l105
  store { { i64, [3 x i64] }, { i64, ptr } } %t203, ptr %l13
  %t204 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t205 = load { i64, [3 x i64] }, ptr %t204
  %t207 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 118
  store ptr %t212, ptr %l109, !tbaa !29
  %t213 = load i64, ptr %l10, !tbaa !24
  store i64 %t213, ptr %l110, !tbaa !24
  %t214 = load i64, ptr %l7, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l112
  %t216 = load i64, ptr %l7, !tbaa !24
  store i64 %t216, ptr %l113, !tbaa !24
  %t217 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t217, ptr %l114
  %t218 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t218, ptr %l115, !tbaa !27
  store { i64, [3 x i64] } %t205, ptr %l116
  %t222 = extractvalue { i64, ptr } %t208, 1
  %t223 = extractvalue { i64, ptr } %t208, 0
  %t224 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t222, i64 %t223)
  %t225 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l119, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l4, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t234, i32 %t235)
  store { i64, ptr } %t238, ptr %l122
  br label %bb34
bb34:
  %t239 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t240, i64 %t241)
  %t243 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = load i64, ptr %l110, !tbaa !24
  %t254 = load i64, ptr %l111, !tbaa !24
  %t255 = load %"compiler/source:Span", ptr %l112
  %t256 = load i64, ptr %l113, !tbaa !24
  %t257 = load %"compiler/source:Span", ptr %l114
  %t258 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t259 = load { i64, [3 x i64] }, ptr %l116
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t252, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t253, i64 %t254, %"compiler/source:Span" %t255, i64 %t256, %"compiler/source:Span" %t257, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t258, { i64, [3 x i64] } %t259, { i64, ptr } %t260, { i64, ptr } %t251)
  call void @llvm.memmove.p0.p0.i64(ptr %l125, ptr %t252, i64 136, i1 false)
  br label %bb35
bb35:
  %t262 = load ptr, ptr %l109, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t263, ptr %l125, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v0, ptr %t262, ptr %t263)
  br label %bb36
bb36:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 119
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t266, i64 -1)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvertedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 9
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 49}
  store i32 %t32, ptr %l3
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t34 = load i32, ptr %l3, !range !{i32 0, i32 49}
  %t36 = trunc i64 20 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l5, !tbaa !21
  br label %bb31
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t53 = load ptr, ptr %l27, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 18}
  %t59 = icmp eq i64 %t57, 9
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l28, !tbaa !21
  store i1 %t60, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l25, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t68, i32 0, i32 2
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 49}
  store i32 %t70, ptr %l4
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t72 = load i32, ptr %l4, !range !{i32 0, i32 49}
  %t74 = trunc i64 20 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t79 = call i1 @compiler_2fcheck_2eisCallExpr(ptr %v2, ptr %a2)
  store i1 %t79, ptr %l38
  br label %bb24
bb23:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb25
bb24:
  %t80 = load i1, ptr %l38, !tbaa !21
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t81 = load i1, ptr %l36, !tbaa !21
  store i1 %t81, ptr %l5, !tbaa !21
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f8af5d5c89bab054_38683d7e2233a658)
  unreachable
bb31:
  %t82 = load i1, ptr %l5, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i1
  %l109 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca %"compiler/diagmsg:Msg"
  %l123 = alloca i64
  %l128 = alloca i1
  %l133 = alloca i1
  %l146 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l187 = alloca %"compiler/source:Span"
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %wh3 = alloca ptr
  %wc3 = alloca ptr
  %ws3 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 5
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l31, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 0
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l33, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:TypeParam", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l35, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l37, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeParam", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l41
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t47 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = trunc i64 %t48 to i32
  %t51 = load i32, ptr %l37, !tbaa !23
  %t53 = add i32 %t51, %t50
  %t54 = load i32, ptr %l35, !tbaa !23
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t54, i32 %t53)
  store %"compiler/source:Span" %t56, ptr %l45
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TypeParam", ptr %t58, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l49
  br label %bb8
bb8:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TypeDecl", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t65, i32 %t69)
  store { i64, ptr } %t72, ptr %l53
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeParam", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t73, i32 %t77)
  store { i64, ptr } %t80, ptr %l57
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t84 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } %t82, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t84, ptr %l58
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l33, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l45
  %t87 = load %"compiler/diagmsg:Msg", ptr %l58
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t85, %"compiler/source:Span" %t86, %"compiler/diagmsg:Msg" %t87)
  store i64 %t88, ptr %l59
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/ast:StructBody", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l62, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 0
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t99 = getelementptr %"compiler/ast:TypeParam", ptr %t97, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t89, i32 %t100)
  store { i64, ptr } %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v2, ptr %s3, ptr %t105)
  %t108 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 1
  %t109 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, 0, 0
  store ptr %t108, ptr %wh3
  store ptr %t109, ptr %wc3
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t107, ptr %l67
  br label %bb15
bb15:
  %t110 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l67
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t110, ptr %l5
  br label %bb16
bb16:
  %t112 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s3, ptr %l5)
  %t113 = extractvalue { i32, ptr } %t112, 1
  %t114 = extractvalue { i32, ptr } %t112, 0
  store i32 %t114, ptr %l71
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb18, label %ok.116, !prof !99
ok.116:
  store ptr %t113, ptr %l70
  br label %bb17
bb17:
  %t117 = load ptr, ptr %l70, !tbaa !29
  store ptr %t117, ptr %l68, !tbaa !29
  br label %bb20
bb18:
  %t118 = load i32, ptr %l71, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  store i1 %t121, ptr %l73, !tbaa !21
  br label %bb19
bb19:
  br label %bb82
bb20:
  %t122 = load ptr, ptr %l68, !tbaa !29
  store ptr %t122, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr %"compiler/ast:VarDecl", ptr %t123, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb21, label %bb22
bb21:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb26
bb23:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t141 = load i64, ptr %l7, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l83, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb25
bb25:
  %t156 = load i64, ptr %l83, !tbaa !24
  store i64 %t156, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t157 = load i64, ptr %l80, !tbaa !24
  store i64 %t157, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb28, label %bb29
bb28:
  br label %bb80
bb29:
  br label %bb30
bb30:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t167 = load i64, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l12, !tbaa !24
  %t176 = load ptr, ptr %l6, !tbaa !29
  %t178 = getelementptr %"compiler/ast:VarDecl", ptr %t176, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t185 = getelementptr %"compiler/ast:VarDecl", ptr %t183, i32 0, i32 3
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = icmp sgt i64 %t188, 0
  store i1 %t190, ptr %l104, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb33
bb33:
  %t192 = load i1, ptr %l104, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l109, !tbaa !29
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t196 = getelementptr %"compiler/ast:VarDecl", ptr %t194, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l111, !tbaa !27
  %t198 = load i64, ptr %l12, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/source:Span", ptr %t201, i64 %t198
  %t203 = load %"compiler/source:Span", ptr %t202
  store %"compiler/source:Span" %t203, ptr %l113
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l6, !tbaa !29
  %t207 = getelementptr %"compiler/ast:VarDecl", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l116, !tbaa !27
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  %t217 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t204, i32 %t214)
  store { i64, ptr } %t217, ptr %l119
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t218 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  %t220 = extractvalue { i64, ptr } %t218, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t225 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t228 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %s7, ptr %v0, ptr %s7, { i64, ptr } %t224, { i64, ptr } %t225)
  store %"compiler/diagmsg:Msg" %t228, ptr %l122
  br label %bb37
bb37:
  %t229 = load ptr, ptr %l109, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l113
  %t231 = load %"compiler/diagmsg:Msg", ptr %l122
  %t232 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t229, %"compiler/source:Span" %t230, %"compiler/diagmsg:Msg" %t231)
  store i64 %t232, ptr %l123
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  store i32 0, ptr %ws3
  br label %wend3
wend3.c0:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb39:
  %t233 = load ptr, ptr %l6, !tbaa !29
  %t235 = getelementptr %"compiler/ast:VarDecl", ptr %t233, i32 0, i32 2
  %t236 = load ptr, ptr %t235, !tbaa !29
  store ptr %t236, ptr %l13, !tbaa !29
  %t238 = load ptr, ptr %l13, !tbaa !29
  %t240 = icmp eq ptr %t238, null
  br i1 %t240, label %bb40, label %bb41
bb40:
  %t242 = load ptr, ptr %l6, !tbaa !29
  %t244 = getelementptr %"compiler/ast:VarDecl", ptr %t242, i32 0, i32 3
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t249 = icmp eq i64 %t247, 0
  store i1 %t249, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t251 = load i1, ptr %l128, !tbaa !21
  br i1 %t251, label %bb43, label %bb44
bb43:
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t254 = getelementptr %"compiler/ast:StructBody", ptr %t252, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t259 = icmp sgt i64 %t257, 0
  store i1 %t259, ptr %l133, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb45
bb45:
  %t261 = load i1, ptr %l133, !tbaa !21
  br i1 %t261, label %bb46, label %bb47
bb46:
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = getelementptr %"compiler/ast:StructBody", ptr %t262, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l16, !tbaa !24
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l16, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb49, label %bb50
bb49:
  br label %bb56
bb50:
  br label %bb51
bb51:
  %t279 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t279, ptr %l146, !tbaa !27
  %t280 = load i64, ptr %l15, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 %t280
  %t285 = load ptr, ptr %t284, !tbaa !39
  store ptr %t285, ptr %l17, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Param", ptr %t287, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load ptr, ptr %l6, !tbaa !29
  %t293 = getelementptr %"compiler/ast:VarDecl", ptr %t291, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l152, !tbaa !27
  %t295 = load i64, ptr %l12, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr i32, ptr %t298, i64 %t295
  %t300 = load i32, ptr %t299, !tbaa !33
  %t303 = icmp eq i32 %t290, %t300
  br i1 %t303, label %bb52, label %bb53
bb52:
  %t305 = load ptr, ptr %l17, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Param", ptr %t305, i32 0, i32 2
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l13, !tbaa !29
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t310 = load i64, ptr %l15, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l15, !tbaa !24
  br label %bb48
bb56:
  br label %bb57
bb57:
  %t314 = load ptr, ptr %l13, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb58, label %bb59
bb58:
  br label %bb79
bb59:
  br label %bb60
bb60:
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/ast:StructBody", ptr %t318, i32 0, i32 5
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  store { i64, ptr } %t321, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t323, 0
  store i64 %t325, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t327 = load i64, ptr %l19, !tbaa !24
  %t328 = load i64, ptr %l20, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb63:
  br label %bb64
bb64:
  %t335 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t335, ptr %l170, !tbaa !27
  %t336 = load i64, ptr %l19, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  store ptr %t341, ptr %l21, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l173, !tbaa !29
  %t344 = load ptr, ptr %l13, !tbaa !29
  %t346 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t344)
  store %"compiler/source:Span" %t346, ptr %l175
  br label %bb65
bb65:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l21, !tbaa !29
  %t350 = getelementptr %"compiler/ast:TypeParam", ptr %t348, i32 0, i32 1
  %t351 = load i32, ptr %t350, !tbaa !23
  %t354 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t347, i32 %t351)
  store { i64, ptr } %t354, ptr %l179
  br label %bb66
bb66:
  %t355 = load ptr, ptr %l173, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l175
  %t357 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t358 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v0, ptr %t355, %"compiler/source:Span" %t356, { i64, ptr } %t357)
  store %"compiler/source:Span" %t358, ptr %l180
  br label %bb67
bb67:
  %t359 = getelementptr %"compiler/source:Span", ptr %l180, i32 0, i32 0
  %t360 = load i32, ptr %t359, !tbaa !23
  %t362 = icmp slt i32 %t360, 0
  br i1 %t362, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l183, !tbaa !29
  %t365 = load ptr, ptr %l6, !tbaa !29
  %t367 = getelementptr %"compiler/ast:VarDecl", ptr %t365, i32 0, i32 1
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l185, !tbaa !27
  %t369 = load i64, ptr %l12, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr %"compiler/source:Span", ptr %t372, i64 %t369
  %t374 = load %"compiler/source:Span", ptr %t373
  store %"compiler/source:Span" %t374, ptr %l187
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l6, !tbaa !29
  %t378 = getelementptr %"compiler/ast:VarDecl", ptr %t376, i32 0, i32 0
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l190, !tbaa !27
  %t380 = load i64, ptr %l12, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr i32, ptr %t383, i64 %t380
  %t385 = load i32, ptr %t384, !tbaa !33
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s15, ptr %t375, i32 %t385)
  store { i64, ptr } %t388, ptr %l193
  br label %bb71
bb71:
  %t389 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  store { i64, ptr } %t395, ptr %l194, !tbaa !27
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l21, !tbaa !29
  %t399 = getelementptr %"compiler/ast:TypeParam", ptr %t397, i32 0, i32 1
  %t400 = load i32, ptr %t399, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t396, i32 %t400)
  store { i64, ptr } %t403, ptr %l198
  br label %bb72
bb72:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr %"compiler/ast:TypeDecl", ptr %t405, i32 0, i32 0
  %t408 = load i32, ptr %t407, !tbaa !23
  %t411 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t404, i32 %t408)
  store { i64, ptr } %t411, ptr %l202
  br label %bb73
bb73:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load ptr, ptr %l21, !tbaa !29
  %t415 = getelementptr %"compiler/ast:TypeParam", ptr %t413, i32 0, i32 1
  %t416 = load i32, ptr %t415, !tbaa !23
  %t419 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t412, i32 %t416)
  store { i64, ptr } %t419, ptr %l206
  br label %bb74
bb74:
  %t420 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t424 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %s15, ptr %v0, ptr %v0, ptr %v0, ptr %s15, { i64, ptr } %t420, { i64, ptr } %t421, { i64, ptr } %t422, { i64, ptr } %t423)
  store %"compiler/diagmsg:Msg" %t424, ptr %l207
  br label %bb75
bb75:
  %t425 = load ptr, ptr %l183, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l187
  %t427 = load %"compiler/diagmsg:Msg", ptr %l207
  %t428 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t425, %"compiler/source:Span" %t426, %"compiler/diagmsg:Msg" %t427)
  store i64 %t428, ptr %l208
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  store i32 1, ptr %ws3
  br label %wend3
wend3.c1:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb77:
  %t429 = load i64, ptr %l19, !tbaa !24
  %t431 = add i64 %t429, 1
  store i64 %t431, ptr %l19, !tbaa !24
  br label %bb61
bb78:
  br label %bb79
bb79:
  %t433 = load i64, ptr %l11, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l11, !tbaa !24
  br label %bb27
bb80:
  br label %bb81
bb81:
  br label %bb16
bb82:
  store i32 2, ptr %ws3
  br label %wend3
wend3.c2:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
wend3:
  %t437 = load ptr, ptr %wh3
  %t438 = load ptr, ptr %wc3
  %t439 = call ptr @llvm.coro.promise(ptr %t437, i32 8, i1 false)
  %t440 = getelementptr { { i32, ptr }, i32 }, ptr %t439, i32 0, i32 1
  store i32 2, ptr %t440
  %t441 = call { i32, ptr } %t438(ptr %t437, ptr null)
  %t442 = load i32, ptr %ws3
  switch i32 %t442, label %wend3.c0 [ i32 1, label %wend3.c1 i32 2, label %wend3.c2 ]
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l5, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l13
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %t24)
  store i64 %t25, ptr %l14
  br label %bb10
bb10:
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb12, label %bb13
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:If", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t53, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l18, !tbaa !29
  %t60 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t58, i64 %t57)
  store i1 %t60, ptr %l26
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  store i1 %t61, ptr %l17, !tbaa !21
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb13:
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:If", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load ptr, ptr %l27, !tbaa !29
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %t70, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb15
bb15:
  %t73 = load i1, ptr %l35, !tbaa !21
  store i1 %t73, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l17, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1bc36e5fea83eb2f_c65858cd7310966b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l4, !tbaa !65
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t2, i32 %t3)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !65
  %t8 = load i64, ptr %l7, !tbaa !65
  %t9 = and i64 %t7, %t8
  store i64 %t9, ptr %l3, !tbaa !65
  %t11 = load i64, ptr %l3, !tbaa !65
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load i64, ptr %l3, !tbaa !65
  store i64 %t17, ptr %l12, !tbaa !65
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load i64, ptr %l12, !tbaa !65
  %t24 = load i64, ptr %l15, !tbaa !65
  %t25 = icmp eq i64 %t23, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l17, !tbaa !23
  br label %bb9
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l3, !tbaa !65
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t34, i32 %t35, i64 %t36)
  store i32 %t40, ptr %l24
  br label %bb8
bb8:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l17, !tbaa !23
  br label %bb9
bb9:
  %t42 = load i32, ptr %l17, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/diagmsg:Msg"
  %l38 = alloca %"compiler/diagmsg:Msg"
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 16
  store i64 %t10, ptr %t13, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l8, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t42, i32 %t43)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l35
  br i1 %a3, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t61 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %s5)
  store %"compiler/diagmsg:Msg" %t61, ptr %l38
  br label %bb16
bb15:
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s5)
  store %"compiler/diagmsg:Msg" %t62, ptr %l39
  br label %bb17
bb16:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l38
  store %"compiler/diagmsg:Msg" %t63, ptr %l37
  br label %bb18
bb17:
  %t64 = load %"compiler/diagmsg:Msg", ptr %l39
  store %"compiler/diagmsg:Msg" %t64, ptr %l37
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l35
  %t67 = load %"compiler/diagmsg:Msg", ptr %l37
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t65, %"compiler/source:Span" %t66, %"compiler/diagmsg:Msg" %t67)
  store i64 %t68, ptr %l40
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i64 %t31, ptr %l16
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t32)
  store %"compiler/check:litv" %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t34, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2bda502508e1b1d_a3083ba563ab0481)
  unreachable
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/check:litv" %t40, ptr %l21
  br label %bb17
bb17:
  %t41 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenResultMet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l33 = alloca i1
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t44)
  store i1 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %t51)
  store i1 %t55, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb9
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6)
  unreachable
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l16 = alloca i32
  %l23 = alloca i64
  %l27 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %l93 = alloca ptr
  %l98 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l111 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i32, ptr %l16, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l23
  br label %bb11
bb11:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l36
  br label %bb19
bb19:
  %t66 = load i32, ptr %l36, !tbaa !23
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l44
  br label %bb23
bb23:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l39, !tbaa !29
  %t85 = load i32, ptr %l44, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l47
  br label %bb24
bb24:
  %t88 = load i1, ptr %l47, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb25:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t91 = trunc i64 22 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t96 = trunc i64 23 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb31
bb31:
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t114 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t111, i32 %t112, i64 %t110)
  store i1 %t114, ptr %l59
  br label %bb32
bb32:
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %rv
  br label %ret
bb33:
  %t116 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t118 = trunc i64 24 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l62, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l67
  br label %bb37
bb37:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load ptr, ptr %l62, !tbaa !29
  %t134 = load i32, ptr %l67, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i1 %t136, ptr %l69
  br label %bb38
bb38:
  %t137 = load i1, ptr %l69, !tbaa !21
  store i1 %t137, ptr %rv
  br label %ret
bb39:
  %t138 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb63
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l75
  br label %bb43
bb43:
  %t151 = load i1, ptr %l75, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb44, label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l80
  br label %bb47
bb47:
  %t160 = load i32, ptr %l80, !range !{i32 0, i32 6}
  store i32 %t160, ptr %l4
  %t161 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t163 = trunc i64 0 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l88
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t177 = load i64, ptr %l2, !tbaa !24
  %t178 = load ptr, ptr %l83, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t178, i32 %t179, i64 %t177)
  store i1 %t181, ptr %l90
  br label %bb51
bb51:
  %t182 = load i1, ptr %l90, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l93, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l98
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t199 = load i64, ptr %l2, !tbaa !24
  %t200 = load ptr, ptr %l93, !tbaa !29
  %t201 = load i32, ptr %l98, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t200, i32 %t201, i64 %t199)
  store i1 %t203, ptr %l100
  br label %bb56
bb56:
  %t204 = load i1, ptr %l100, !tbaa !21
  store i1 %t204, ptr %rv
  br label %ret
bb57:
  %t205 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t207 = trunc i64 4 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb58, label %bb59
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l103, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l1, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l108
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t224 = load ptr, ptr %l103, !tbaa !29
  %t225 = load i32, ptr %l108, !tbaa !23
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t224, i32 %t225, i64 %t223)
  store i1 %t227, ptr %l111
  br label %bb61
bb61:
  %t228 = load i1, ptr %l111, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb62:
  store i1 false, ptr %rv
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i1 false, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @olang_loc_7aa3345d2beba7fc_151c01b23d5f0fc0)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l127 = alloca i32
  %l129 = alloca i32
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca i1
  %l144 = alloca ptr
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l169 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t21 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [3 x i64] }, align 8
  %t347 = alloca { i64, [5 x i64] }, align 8
  %t359 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  store i1 false, ptr %t7, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 5
  store i32 %t15, ptr %t18, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t24 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t20, 0
  %t25 = insertvalue { %"compiler/source:Span", ptr } %t24, ptr null, 1
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t21
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t19, ptr %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 36
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l30
  br label %bb6
bb6:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t44, 2305843009213693951
  br i1 %t45, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb9:
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb11:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb16
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb16
bb16:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb18:
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t104, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb21
bb21:
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l70, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l73
  br label %bb22
bb22:
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l73
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t127, ptr %t128, %"compiler/source:Span" %t129)
  store ptr %t130, ptr %l74
  br label %bb23
bb23:
  %t131 = load ptr, ptr %l74, !tbaa !29
  store ptr %t131, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t135 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t132)
  store i32 %t135, ptr %l77
  br label %bb24
bb24:
  %t136 = load i32, ptr %l77, !tbaa !23
  store i32 %t136, ptr %l13, !tbaa !23
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t141 = icmp eq i32 %t137, %t138
  br i1 %t141, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  %t143 = load i32, ptr %l13, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  store i1 %t147, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l81, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t151, ptr %l86, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 %t152
  %t157 = load ptr, ptr %t156, !tbaa !39
  %t159 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t157)
  store %"compiler/source:Span" %t159, ptr %l89
  br label %bb30
bb29:
  %t160 = load i32, ptr %l13, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  br i1 %t164, label %bb33, label %bb34
bb30:
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %s4)
  store %"compiler/diagmsg:Msg" %t166, ptr %l90
  br label %bb31
bb31:
  %t167 = load ptr, ptr %l85, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l89
  %t169 = load %"compiler/diagmsg:Msg", ptr %l90
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l91
  br label %bb32
bb32:
  %t171 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t171, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t174, ptr %l97, !tbaa !27
  %t175 = load i64, ptr %l11, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t173, ptr %t180, ptr %t181, i1 false)
  store i32 %t185, ptr %l101
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t186 = load i32, ptr %l101, !tbaa !23
  store i32 %t186, ptr %l13, !tbaa !23
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i32, ptr %l13, !tbaa !23
  %t191 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t187
  store i32 %t188, ptr %t193, !tbaa !33
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 36
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l106, !tbaa !29
  %t198 = load ptr, ptr %l12, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  %t199 = load i32, ptr %l13, !tbaa !23
  store i32 %t199, ptr %l108, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t200, ptr %l109, !tbaa !27
  %t201 = load i64, ptr %l11, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l112
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l106, !tbaa !29
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i32, ptr %l108, !tbaa !23
  %t212 = load %"compiler/source:Span", ptr %l112
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t209, ptr %t210, i32 %t211, %"compiler/source:Span" %t212)
  store ptr %t213, ptr %l113
  br label %bb39
bb39:
  %t214 = load ptr, ptr %l105, !tbaa !29
  %t215 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t214, ptr %t215)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l10, !tbaa !24
  br label %bb17
bb42:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 36
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t222, i64 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t227, ptr %l14, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = icmp eq i64 %t230, 1
  br i1 %t232, label %bb44, label %bb45
bb44:
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t235 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i32, ptr %t236, i64 0
  %t238 = load i32, ptr %t237, !tbaa !33
  %t241 = getelementptr %"compiler/check:frame", ptr %t234, i32 0, i32 5
  store i32 %t238, ptr %t241, !tbaa !23
  %t242 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t242, ptr %l125, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 0
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l15, !tbaa !29
  %t248 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 0
  %t251 = load i32, ptr %t250, !tbaa !33
  store i32 %t251, ptr %l127, !tbaa !23
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t252)
  store i32 %t254, ptr %l129
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t255 = load i32, ptr %l127, !tbaa !23
  %t256 = load i32, ptr %l129, !tbaa !23
  %t257 = icmp eq i32 %t255, %t256
  br i1 %t257, label %bb47, label %bb48
bb47:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l132, !tbaa !29
  %t260 = load ptr, ptr %l15, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t260)
  store i32 %t263, ptr %l135
  br label %bb49
bb48:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb51
bb49:
  %t264 = load ptr, ptr %l132, !tbaa !29
  %t265 = load i32, ptr %l135, !tbaa !23
  %t266 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t266, ptr %l136
  br label %bb50
bb50:
  %t267 = load i1, ptr %l136, !tbaa !21
  store i1 %t267, ptr %l131, !tbaa !21
  br label %bb51
bb51:
  %t268 = load i1, ptr %l131, !tbaa !21
  br i1 %t268, label %bb52, label %bb53
bb52:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 0
  %t275 = load i32, ptr %t274, !tbaa !33
  %t276 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 0
  store i64 2, ptr %t278
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t271, 0
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t275, 1
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t276, 2
  %t285 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [4 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t286, ptr %t288
  %t292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t269, %"compiler/source:Span" %t270, ptr %t288)
  store ptr %t292, ptr %l144
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t293 = load ptr, ptr %l144, !tbaa !29
  store ptr %t293, ptr %l15, !tbaa !29
  br label %bb55
bb55:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  %t296 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 0
  store i64 6, ptr %t299
  %t301 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t295, 0
  %t303 = insertvalue { %"compiler/source:Span", ptr } %t301, ptr %t296, 1
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t303, ptr %t304
  %t305 = load { i64, [3 x i64] }, ptr %t298
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t305, ptr %t307
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t294, ptr %t307)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t310 = load ptr, ptr %l3, !tbaa !29
  store ptr %t310, ptr %l151, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  store ptr %t316, ptr %l154, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t326 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t322, { i64, ptr } %t323)
  store i32 %t326, ptr %l159
  br label %bb58
bb58:
  %t327 = load ptr, ptr %l154, !tbaa !29
  %t328 = load i32, ptr %l159, !tbaa !23
  %t329 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t329, ptr %l160
  br label %bb59
bb59:
  %t330 = load i32, ptr %l160, !tbaa !23
  %t331 = load ptr, ptr %l151, !tbaa !29
  %t332 = getelementptr %"compiler/check:frame", ptr %t331, i32 0, i32 5
  store i32 %t330, ptr %t332, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l161, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l162
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l163
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 5
  %t339 = load i32, ptr %t338, !tbaa !23
  store i32 %t339, ptr %l165, !tbaa !23
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t344 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t340, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t344, ptr %l169
  br label %bb60
bb60:
  %t345 = load %"compiler/typed:Make", ptr %l169
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t345, ptr %t346
  store { i64, [5 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 0
  store i64 7, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l163
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l165, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, i32 %t351, 1
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr } %t352, ptr %t346, 2
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t354, ptr %t355
  %t356 = load { i64, [5 x i64] }, ptr %t347
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t356, ptr %t358
  store { i64, [3 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 0
  store i64 6, ptr %t360
  %t361 = load %"compiler/source:Span", ptr %l162
  %t362 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t361, 0
  %t364 = insertvalue { %"compiler/source:Span", ptr } %t362, ptr %t358, 1
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t364, ptr %t365
  %t366 = load { i64, [3 x i64] }, ptr %t359
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t366, ptr %t368
  %t369 = load ptr, ptr %l161, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t368)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisZeroLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 2 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4a75f471ea948b24_16ed41ec7c1e5db8)
  unreachable
bb16:
  %t36 = load i1, ptr %l4, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %l38 = alloca i1
  %l43 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l10
  br label %bb1
bb1:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load i32, ptr %l17, !tbaa !23
  store i32 %t26, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l22
  br label %bb7
bb7:
  %t37 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l31
  br label %bb10
bb10:
  %t54 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t56 = trunc i64 19 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t68, ptr %l38
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l43
  br label %bb16
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l4, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l48
  br label %bb17
bb17:
  %t90 = load i32, ptr %l43, !tbaa !23
  %t91 = load i32, ptr %l48, !tbaa !23
  %t92 = icmp eq i32 %t90, %t91
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l56
  br label %bb20
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l61
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l51, !tbaa !29
  %t116 = load i32, ptr %l56, !tbaa !23
  %t117 = load i32, ptr %l61, !tbaa !23
  %t118 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaidAlike(ptr %v0, ptr %t115, i32 %t116, i32 %t117)
  store i1 %t118, ptr %l62
  br label %bb22
bb22:
  %t119 = load i1, ptr %l62, !tbaa !21
  store i1 %t119, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l50, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i64
  %l15 = alloca %"compiler/check:laneNode"
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 39
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t19, i64 %t20)
  store %"compiler/check:laneNode" %t23, ptr %l15
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb10
bb10:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t45 = load i32, ptr %l26, !tbaa !23
  store i32 %t45, ptr %l23, !tbaa !23
  br label %bb14
bb14:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:laneNode"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i1
  %l30 = alloca %"compiler/check:laneNode"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l42 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t143 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %s0, ptr %t3, i64 %a1, ptr %l3)
  br label %bb2
bb2:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t10)
  store i64 %t12, ptr %l17
  br label %bb4
bb4:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb59
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l22
  br label %bb8
bb8:
  %t24 = load i64, ptr %l22, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/check:laneVals", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l26
  br label %bb9
bb9:
  %t32 = load i1, ptr %l26, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb58
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 39
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/check:laneNode" %t39, ptr %l30
  br label %bb13
bb13:
  %t40 = load %"compiler/check:laneNode", ptr %l30
  store %"compiler/check:laneNode" %t40, ptr %l7
  %t41 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t46 = icmp eq i64 %t42, %t43
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/check:laneVals", ptr %t48, i32 0, i32 1
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l36, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l37, !tbaa !29
  %t53 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l38
  %t55 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb16, label %bb17
bb15:
  br label %bb21
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d04702acd6c67beb_c6baeec7be1e7af7)
  unreachable
bb17:
  br label %bb18
bb18:
  %t60 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l38
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v0, ptr %t62, %"compiler/source:Span" %t63, ptr %t61)
  store i64 %t65, ptr %l42
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t66, i64 %t67, i64 %t68)
  br label %bb20
bb20:
  br label %bb58
bb21:
  %t69 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_57a7d7e6d1174c7c_73fda2027ad2ad8)
  unreachable
bb23:
  br label %bb24
bb24:
  %t74 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l8, !tbaa !29
  %t77 = load ptr, ptr %l8, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t85 = load i1, ptr %l47, !tbaa !21
  br i1 %t85, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t86 = load ptr, ptr %l8, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 18}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb57
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb56
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = icmp eq ptr %t96, null
  br i1 %t98, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_fd3b2969d106d871_acdc32576a39b9ed)
  unreachable
bb39:
  br label %bb40
bb40:
  %t100 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %s6, ptr %t101)
  store ptr %t103, ptr %l57
  br label %bb41
bb41:
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = call i64 @compiler_2fcheck_2elocalIdOf(ptr %s6, ptr %t104)
  store i64 %t105, ptr %l58
  br label %bb42
bb42:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb43, label %bb44
bb43:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l61, !tbaa !29
  %t112 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t113 = load %"compiler/source:Span", ptr %t112
  store %"compiler/source:Span" %t113, ptr %l62
  %t114 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = icmp eq ptr %t115, null
  br i1 %t117, label %bb45, label %bb46
bb44:
  br label %bb54
bb45:
  call void @__olang_check_failed(ptr @olang_loc_9336e0175c2e9c6a_aabb9d2690ac9706)
  unreachable
bb46:
  br label %bb47
bb47:
  %t119 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb48
bb48:
  %t124 = load ptr, ptr %l61, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l62
  %t126 = load i32, ptr %l67, !tbaa !23
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t124, %"compiler/source:Span" %t125, i32 %t126)
  store i64 %t127, ptr %l68
  br label %bb49
bb49:
  %t128 = load i64, ptr %l68, !tbaa !24
  store i64 %t128, ptr %l9, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  %t130 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 2
  %t131 = load %"compiler/source:Span", ptr %t130
  store %"compiler/source:Span" %t131, ptr %l70
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = trunc i64 %t132 to i32
  store i32 %t134, ptr %l73, !tbaa !23
  %t136 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_12a21cc2c4eb057_a597a544841c60b)
  unreachable
bb51:
  br label %bb52
bb52:
  %t141 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 7
  %t142 = load ptr, ptr %t141, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 0
  store i64 0, ptr %t144
  %t145 = load %"compiler/source:Span", ptr %l70
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t145, 0
  %t147 = load i32, ptr %l73, !tbaa !23
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr } %t146, i32 %t147, 1
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr } %t148, ptr %t142, 2
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t150, ptr %t151
  %t152 = load { i64, [3 x i64] }, ptr %t143
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t152, ptr %t154
  %t155 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t155, ptr %t154)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/check:laneVals", ptr %t157, i32 0, i32 1
  %t160 = load i64, ptr %l6, !tbaa !24
  %t161 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t159, i64 %t160, i64 %t161)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_286fe13485cd942f_1c0d0a1e63f5e7b3)
  unreachable
bb57:
  br label %bb58
bb58:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l5, !tbaa !24
  br label %bb3
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l20 = alloca ptr
  %t23 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t1, i64 %a3, i64 %a4, i64 %a5, i64 %a6)
  store ptr %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t14, ptr %l15
  store ptr %t12, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v0, ptr %t16, %"compiler/source:Span" %t17, i64 %a2)
  store ptr %t22, ptr %l20
  br label %bb2
bb2:
  store { i64, [3 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 0
  store i64 4, ptr %t24
  %t25 = load %"compiler/source:Span", ptr %l15
  %t26 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t25, 0
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = insertvalue { %"compiler/source:Span", ptr, ptr } %t26, ptr %t27, 1
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = insertvalue { %"compiler/source:Span", ptr, ptr } %t28, ptr %t29, 2
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t23, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t30, ptr %t31
  %t32 = load { i64, [3 x i64] }, ptr %t23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t32, ptr %t34
  %t35 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t35, ptr %t34)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/check:reflList"
  %l3 = alloca { { i64, ptr }, { i64, ptr } }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca { { i64, ptr }, { i64, ptr } }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/check:reflList" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = icmp eq i32 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5ab97e381db75496_a4ed3933adca62ca)
  unreachable
bb5:
  %t12 = mul i64 0, 8
  %t13 = insertvalue { i64, ptr } undef, i64 0, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5ab97e381db75496_a4ed3933adca62ca)
  unreachable
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l14, !tbaa !23
  %t22 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t26)
  store ptr %t28, ptr %l18
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load ptr, ptr %l13, !tbaa !29
  %t34 = load i32, ptr %l14, !tbaa !23
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = load i64, ptr %l16, !tbaa !24
  %t38 = call { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %s0, ptr %t33, i32 %t34, i64 %t35, i64 %t36, i64 %t32)
  store { { i64, ptr }, { i64, ptr } } %t38, ptr %l21
  br label %bb9
bb9:
  %t39 = load { { i64, ptr }, { i64, ptr } }, ptr %l21
  store { { i64, ptr }, { i64, ptr } } %t39, ptr %l3
  %t40 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l23, !tbaa !24
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l24, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t55, ptr %lp4
  %t56 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t57 = load ptr, ptr %lp4
  store { i64, ptr } %t56, ptr %t57, !tbaa !27
  %t58 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t63, ptr %l27
  br label %bb10
bb10:
  %t64 = load i1, ptr %l27, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l29, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l30
  %t69 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = call { i64, ptr } @compiler_2fcheck_2elistName(ptr %s2, i64 %t70)
  store { i64, ptr } %t72, ptr %l32
  br label %bb13
bb12:
  br label %bb21
bb13:
  %t73 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 1
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t80, i32 %t82)
  store { i64, ptr } %t85, ptr %l36
  br label %bb14
bb14:
  %t86 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNotList(ptr %s2, ptr %s2, ptr %s0, ptr %s2, { i64, ptr } %t94, { i64, ptr } %t92, { i64, ptr } %t93)
  store %"compiler/diagmsg:Msg" %t97, ptr %l39
  br label %bb15
bb15:
  %t98 = load ptr, ptr %l29, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l30
  %t100 = load %"compiler/diagmsg:Msg", ptr %l39
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t98, %"compiler/source:Span" %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l40
  br label %bb16
bb16:
  %t102 = icmp sge i64 0, 0
  br i1 %t102, label %bb17, label %bb18
bb17:
  %t104 = icmp sle i64 0, 1152921504606846975
  br i1 %t104, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fce01e404a5d04ab_bd3fcfdbd155739f)
  unreachable
bb19:
  %t106 = mul i64 0, 8
  %t107 = insertvalue { i64, ptr } undef, i64 0, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fce01e404a5d04ab_bd3fcfdbd155739f)
  unreachable
bb21:
  %t110 = load ptr, ptr %lp4
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l68 = alloca { i64, ptr }
  %l75 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb34
bb8:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l31
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i32, ptr %l5, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t48, i64 %t51)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, ptr %l36
  br label %bb15
bb15:
  %t55 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l36
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t55, ptr %l6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load i32, ptr %l2, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t61, i32 %t62, i32 %t63)
  store i1 %t67, ptr %l42
  br label %bb16
bb16:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 31
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t75, ptr %l47
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb19:
  %t76 = load i1, ptr %l47, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb23
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 33
  %t80 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t79, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t80)
  store i1 %t83, ptr %l52
  br label %bb22
bb22:
  %t84 = load i1, ptr %l52, !tbaa !21
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l48, !tbaa !21
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load i32, ptr %l5, !tbaa !23
  %t89 = sext i32 %t87 to i64
  call void @__olang_scope_close(ptr %s3)
  store i64 %t89, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_1a03149f0250e548_14220af7ccd85b74)
  unreachable
bb33:
  br label %bb55
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t92 = load ptr, ptr %l55, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 18}
  %t98 = icmp eq i64 %t96, 9
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t102, i32 0, i32 4
  %t104 = load { i64, ptr }, ptr %t103
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  br label %bb39
bb38:
  br label %bb50
bb39:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t106, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb40
bb40:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb41, label %bb42
bb41:
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t120 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t120, ptr %l68, !tbaa !27
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l2, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %t128, ptr %t126, i32 %t131)
  store i64 %t135, ptr %l75
  br label %bb44
bb44:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = load i64, ptr %l12, !tbaa !24
  store i64 %t141, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l9, !tbaa !24
  br label %bb40
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_f003e05343083a19_c7eedaa93b775a5)
  unreachable
bb55:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t38 = alloca i64
  %t70 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t19)
  store ptr %t21, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb5:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l20, !tbaa !23
  %t31 = icmp sge i64 1, 0
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = icmp sle i64 1, 2305843009213693951
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9c04d5f47d2250f6_3417b2e0d095e072)
  unreachable
bb9:
  %t35 = mul i64 1, 4
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = load i32, ptr %l20, !tbaa !23
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, 1
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i32, ptr %t36, i64 %t42
  store i32 %t37, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t36, 1
  %t48 = load ptr, ptr %l13, !tbaa !29
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s0, ptr %t48, { i64, ptr } %t47)
  store i1 %t50, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9c04d5f47d2250f6_3417b2e0d095e072)
  unreachable
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  store i1 %t51, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l12, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l29
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t63 = load i32, ptr %l29, !tbaa !23
  store i32 %t63, ptr %l3, !tbaa !23
  br label %bb16
bb16:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = trunc i64 %t66 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t73 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %a1, 0
  %t75 = insertvalue { %"compiler/source:Span", i32, i32 } %t73, i32 %t65, 1
  %t77 = insertvalue { %"compiler/source:Span", i32, i32 } %t75, i32 %t68, 2
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t70
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t79, ptr %t81
  call void @__olang_scope_close(ptr %s0)
  store ptr %t81, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l20, !tbaa !24
  br label %bb13
bb12:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i64
  %l19 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %t26, i64 %t27, i32 %a2)
  store i64 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bddcfdd9cfe1623c_a2c83caf107f9198)
  unreachable
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoBuilder(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/msgs:Nearest"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l32 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca i32
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/diagmsg:Msg"
  %l77 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store %"compiler/msgs:Nearest" %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load %"compiler/msgs:Nearest", ptr %l12
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t8, ptr %t9
  store ptr %t9, ptr %l5, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuildersOf(ptr %v0, ptr %s1, ptr %t14, i32 %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l17
  br label %bb3
bb3:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t20 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t20
  store ptr %t20, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l7, !tbaa !24
  store i64 %t22, ptr %l19, !tbaa !24
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t23)
  store i64 %t25, ptr %l21
  br label %bb5
bb5:
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l8, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 10
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t70, i32 %t69)
  store { i64, ptr } %t72, ptr %l44
  br label %bb15
bb15:
  %t73 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t74 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t73)
  store i1 %t74, ptr %l45
  br label %bb16
bb16:
  %t75 = load i1, ptr %l45, !tbaa !21
  store i1 %t75, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l36, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l5, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l51
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t87 = load ptr, ptr %l51, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Func", ptr %t87, i32 0, i32 10
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load ptr, ptr %l47, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t91, i32 %t90)
  store { i64, ptr } %t93, ptr %l54
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l54, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t94, { i64, ptr } %t95)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb4
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l57, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l58
  %t102 = load i32, ptr %l3, !tbaa !23
  store i32 %t102, ptr %l59, !tbaa !23
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t103, i32 %t104)
  store { i64, ptr } %t107, ptr %l62
  br label %bb26
bb26:
  %t108 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t110 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = add i64 %t109, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t108, i64 %t109)
  %t115 = getelementptr i8, ptr %t114, i64 %t109
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l64, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l3, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t125, i32 %t126)
  store { i64, ptr } %t129, ptr %l67
  br label %bb27
bb27:
  %t130 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l68, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l4, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t137, i32 %t138)
  store { i64, ptr } %t141, ptr %l71
  br label %bb28
bb28:
  %t142 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l72, !tbaa !27
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t151 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t149)
  store { i64, ptr } %t151, ptr %l74
  br label %bb29
bb29:
  %t152 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t162 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoBuilder(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } %t160, { i64, ptr } %t158)
  store %"compiler/diagmsg:Msg" %t162, ptr %l76
  br label %bb30
bb30:
  %t163 = load ptr, ptr %l57, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l58
  %t165 = load i32, ptr %l59, !tbaa !23
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load %"compiler/diagmsg:Msg", ptr %l76
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %s0, ptr %t163, %"compiler/source:Span" %t164, i32 %t165, { i64, ptr } %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l77
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l33 = alloca { i64, i32 }
  %l40 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca %"compiler/check:payloadItem"
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l81 = alloca %"compiler/check:payloadItem"
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 9}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 2
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  br label %bb6
bb5:
  br label %bb41
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s1, ptr %t26)
  store ptr %t28, ptr %l27
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l27, !tbaa !29
  store ptr %t29, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %lp2
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34
  call void @__olang_scope_close(ptr %s1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t41 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s1, ptr %t37, ptr %t38)
  store { i64, i32 } %t41, ptr %l33
  br label %bb11
bb11:
  %t42 = load { i64, i32 }, ptr %l33
  store { i64, i32 } %t42, ptr %l6
  %t43 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  store i32 %t47, ptr %l8, !tbaa !23
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %lp2
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53
  call void @__olang_scope_close(ptr %s1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l8, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l45
  br label %bb15
bb15:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s1, ptr %t71, i32 %t72, i64 %t70)
  store { i64, ptr } %t74, ptr %l47
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t75, ptr %l9, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  br label %bb40
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l11, !tbaa !24
  store i64 %t90, ptr %l13, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t92, ptr %l56, !tbaa !27
  %t93 = load i64, ptr %l11, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l14, !tbaa !29
  %t100 = load ptr, ptr %l14, !tbaa !29
  store ptr %t100, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t101 = load ptr, ptr %l59, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 9}
  %t107 = icmp eq i64 %t105, 8
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t109 = load ptr, ptr %l14, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t111, i32 0, i32 1
  %t113 = load i32, ptr %t112
  store i32 %t113, ptr %l15, !tbaa !23
  %t115 = load ptr, ptr %l14, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t121 = load ptr, ptr %lp2
  store ptr %t121, ptr %l67, !tbaa !29
  %t122 = load i32, ptr %l15, !tbaa !23
  %t123 = load ptr, ptr %l16, !tbaa !29
  %t126 = call %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v1, ptr %v2, i32 %t122, ptr %t123)
  store %"compiler/check:payloadItem" %t126, ptr %l70
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t128 = load %"compiler/check:payloadItem", ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v2, ptr %v2, ptr %t127, %"compiler/check:payloadItem" %t128)
  br label %bb27
bb27:
  br label %bb38
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t135 = icmp slt i64 %t129, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %lp2
  store ptr %t137, ptr %l75, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t138, ptr %l76, !tbaa !27
  %t139 = load i64, ptr %l13, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t146 = getelementptr %"compiler/ast:Param", ptr %t144, i32 0, i32 1
  %t147 = load i32, ptr %t146, !tbaa !23
  %t148 = load ptr, ptr %l14, !tbaa !29
  %t151 = call %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v1, ptr %v2, i32 %t147, ptr %t148)
  store %"compiler/check:payloadItem" %t151, ptr %l81
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t152 = load ptr, ptr %l75, !tbaa !29
  %t153 = load %"compiler/check:payloadItem", ptr %l81
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v2, ptr %v2, ptr %t152, %"compiler/check:payloadItem" %t153)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_99a2219cf20f55d9_bdfeae2ff747ebc5)
  unreachable
bb38:
  br label %bb39
bb39:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l11, !tbaa !24
  br label %bb17
bb40:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_aa9d1041871ddc08_900eaa132351bb14)
  unreachable
bb46:
  %t158 = load ptr, ptr %lp2
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l18
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 7}
  %t26 = trunc i64 5 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t30)
  store ptr %t32, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t36 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t34, i32 %t33)
  store %"compiler/typed:Local" %t36, ptr %l28
  br label %bb11
bb11:
  %t37 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t39, i32 %t38)
  store i1 %t41, ptr %l30
  br label %bb12
bb12:
  %t42 = load i1, ptr %l30, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t48, i64 %t51)
  store i1 %t54, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %l10, !tbaa !21
  br label %bb67
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l3, !tbaa !24
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l4, !tbaa !23
  br label %bb23
bb22:
  br label %bb33
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i32, ptr %l4, !tbaa !23
  %t89 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s2, ptr %t83, i64 %t84, i32 %t85)
  store ptr %t89, ptr %l51
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = icmp eq ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  %t102 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t96, i64 %t97, i32 %t98)
  store ptr %t102, ptr %l58
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l58, !tbaa !29
  store ptr %t103, ptr %l5, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_24dda45681d8cee1_6133aaee564c4ee5)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/ast:VarDecl", ptr %t108, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %t112)
  store i1 %t114, ptr %l64
  br label %bb31
bb31:
  %t115 = load i1, ptr %l64, !tbaa !21
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53, !tbaa !21
  store i1 %t116, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb33:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 8}
  %t124 = icmp eq i64 %t122, 2
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t125 = load i1, ptr %l66, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 2
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l73, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t138)
  store i32 %t141, ptr %l76
  br label %bb39
bb39:
  %t142 = load ptr, ptr %l73, !tbaa !29
  %t143 = load i32, ptr %l76, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t144, ptr %l77
  br label %bb40
bb40:
  %t145 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t146 = load i64, ptr %l77, !tbaa !24
  %t148 = and i64 %t146, %t145
  %t150 = icmp ne i64 %t148, 0
  store i1 %t150, ptr %l10, !tbaa !21
  br label %bb67
bb41:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t153 = load ptr, ptr %l81, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l82, !tbaa !21
  br label %bb43
bb43:
  %t160 = load i1, ptr %l82, !tbaa !21
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  store i1 %t171, ptr %l89
  br label %bb47
bb47:
  %t172 = load i1, ptr %l89, !tbaa !21
  store i1 %t172, ptr %l10, !tbaa !21
  br label %bb67
bb48:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t174 = load ptr, ptr %l90, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = load ptr, ptr %l90, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 8}
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t181 = load i1, ptr %l91, !tbaa !21
  br i1 %t181, label %bb51, label %bb52
bb51:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Elem", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t188, ptr %t192)
  store i1 %t195, ptr %l99
  br label %bb54
bb54:
  %t196 = load i1, ptr %l99, !tbaa !21
  store i1 %t196, ptr %l10, !tbaa !21
  br label %bb67
bb55:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb56, label %bb57
bb56:
  %t201 = load ptr, ptr %l100, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 8}
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb57
bb57:
  %t205 = load i1, ptr %l101, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Payload", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t212, ptr %t216)
  store i1 %t219, ptr %l109
  br label %bb61
bb61:
  %t220 = load i1, ptr %l109, !tbaa !21
  store i1 %t220, ptr %l10, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_f10316e290a7e1b9_b7814005b7d82bcd)
  unreachable
bb67:
  %t221 = load i1, ptr %l10, !tbaa !21
  store i1 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %l38 = alloca i1
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l17
  br label %bb7
bb7:
  %t19 = load i32, ptr %l17, !range !{i32 0, i32 6}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l32
  br label %bb16
bb16:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l38
  br label %bb20
bb20:
  %t62 = load i1, ptr %l38, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l47
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i32, ptr %l47, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l48
  br label %bb25
bb25:
  %t83 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t83, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t96, ptr %l55, !tbaa !27
  %t97 = load i64, ptr %l4, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 %t97
  %t102 = load i32, ptr %t101, !tbaa !33
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %t104, i32 %t102, i64 %t108)
  store i1 %t112, ptr %l62
  br label %bb30
bb30:
  %t113 = load i1, ptr %l62, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb31, label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t117 = load i64, ptr %l4, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l4, !tbaa !24
  br label %bb26
bb35:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:reflList" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l30 = alloca i64
  %l41 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l49 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 3
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l10, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t6, %"compiler/check:reflList" %a2, i64 %a3)
  store i32 %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t13, i32 %t14, i32 %t15)
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Compr", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  store i32 %t22, ptr %l18, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l23
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l23, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t33, i32 %t34, i64 %a4)
  store i32 %t36, ptr %l25
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l18, !tbaa !23
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb5
bb5:
  %t41 = load i32, ptr %l26, !tbaa !23
  store i32 %t41, ptr %l6, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Compr", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  store i64 %t49, ptr %l30
  br label %bb6
bb6:
  %t50 = load i64, ptr %l30, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Compr", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t51, i32 %t55, i32 %t56)
  br label %bb7
bb7:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Compr", ptr %t61, i32 0, i32 3
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t60, i32 %t64, i32 %t65)
  br label %bb8
bb8:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Compr", ptr %t74, i32 0, i32 5
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb11, label %bb12
bb10:
  br label %bb17
bb11:
  call void @__olang_check_failed(ptr @olang_loc_320f9d8592ce2991_bf25bbc6142ecf8d)
  unreachable
bb12:
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Compr", ptr %t81, i32 0, i32 5
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t84)
  store %"compiler/source:Span" %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s1)
  store %"compiler/diagmsg:Msg" %t87, ptr %l48
  br label %bb15
bb15:
  %t88 = load ptr, ptr %l41, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l47
  %t90 = load %"compiler/diagmsg:Msg", ptr %l48
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t88, %"compiler/source:Span" %t89, %"compiler/diagmsg:Msg" %t90)
  store i64 %t91, ptr %l49
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 139
  store i1 true, ptr %t94, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp eq i64 %t95, 1
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:reflList"
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:Desc"
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca %"compiler/check:reflList"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca %"compiler/check:reflVal"
  %l103 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/diagmsg:Msg"
  %l114 = alloca i64
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca { i64, ptr }
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l145 = alloca i1
  %l146 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca { i64, ptr }
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l172 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i32
  %l188 = alloca ptr
  %l193 = alloca %"compiler/generic:Desc"
  %l195 = alloca i1
  %l196 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l204 = alloca { i64, ptr }
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i1
  %l215 = alloca i1
  %l222 = alloca ptr
  %l227 = alloca %"compiler/check:reflVal"
  %l232 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l267 = alloca %"compiler/diagmsg:Msg"
  %l268 = alloca i64
  %l271 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t11 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 14, ptr %t12
  %t14 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t16 = insertvalue { %"compiler/source:Span", ptr, i32 } %t14, ptr %t9, 1
  %t18 = insertvalue { %"compiler/source:Span", ptr, i32 } %t16, i32 %t10, 2
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t18, ptr %t19
  %t20 = load { i64, [4 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store { i64, [4 x i64] } %t20, ptr %t22
  %t25 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %s0, ptr %t7, ptr %t22)
  store %"compiler/check:reflList" %t25, ptr %l25
  br label %bb2
bb2:
  %t26 = load %"compiler/check:reflList", ptr %l25
  store %"compiler/check:reflList" %t26, ptr %l6
  %t27 = getelementptr %"compiler/check:reflList", ptr %l6, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l28
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33)
  store { i64, ptr } %t36, ptr %l31
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %s1, ptr %s1, { i64, ptr } %t49)
  store %"compiler/diagmsg:Msg" %t51, ptr %l34
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l28
  %t54 = load %"compiler/diagmsg:Msg", ptr %l34
  %t55 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t52, %"compiler/source:Span" %t53, %"compiler/diagmsg:Msg" %t54)
  store i64 %t55, ptr %l35
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t56, %"compiler/source:Span" %t57)
  store ptr %t60, ptr %l38
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i32 %t67, ptr %l42
  br label %bb10
bb10:
  %t68 = load i32, ptr %l42, !tbaa !23
  store i32 %t68, ptr %l7, !tbaa !23
  %t69 = load i32, ptr %l7, !tbaa !23
  %t71 = icmp sge i32 %t69, 0
  br i1 %t71, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i32, ptr %l7, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb13, label %bb14
bb12:
  br label %bb112
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t79, %"compiler/source:Span" %t80)
  store ptr %t83, ptr %l50
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t84 = load ptr, ptr %l50, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t84, ptr %rv
  br label %ret
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l7, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l54
  br label %bb17
bb17:
  %t91 = load i1, ptr %l54, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l58
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb20:
  %t97 = load i1, ptr %l58, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l7, !tbaa !23
  %t103 = load i32, ptr %l4, !tbaa !23
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t101, i32 %t102, i32 %t103)
  store i1 %t107, ptr %l64
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t108 = load i1, ptr %l64, !tbaa !21
  store i1 %t108, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t111)
  store i1 %t113, ptr %l67
  br label %bb29
bb29:
  %t114 = load i1, ptr %l67, !tbaa !21
  br i1 %t114, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l68, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l69
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l1
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s6, ptr %t117, %"compiler/source:Span" %t118)
  store { i64, ptr } %t121, ptr %l72
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t122 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t123, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s6, ptr %s6, { i64, ptr } %t134)
  store %"compiler/diagmsg:Msg" %t136, ptr %l75
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l69
  %t139 = load %"compiler/diagmsg:Msg", ptr %l75
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t137, %"compiler/source:Span" %t138, %"compiler/diagmsg:Msg" %t139)
  store i64 %t140, ptr %l76
  br label %bb34
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t141, %"compiler/source:Span" %t142)
  store ptr %t145, ptr %l79
  br label %bb35
bb35:
  %t146 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t146, ptr %rv
  br label %ret
bb36:
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t150, ptr %l82
  br label %bb37
bb37:
  %t151 = load i1, ptr %l82, !tbaa !21
  br i1 %t151, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb41
bb39:
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t154, ptr %l85
  br label %bb40
bb40:
  %t155 = load i1, ptr %l85, !tbaa !21
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb41
bb41:
  %t156 = load i1, ptr %l83, !tbaa !21
  br i1 %t156, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb45
bb43:
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t157, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t159, ptr %l88
  br label %bb44
bb44:
  %t160 = load i1, ptr %l88, !tbaa !21
  store i1 %t160, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l86, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb49
bb47:
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t162, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t164, ptr %l91
  br label %bb48
bb48:
  %t165 = load i1, ptr %l91, !tbaa !21
  store i1 %t165, ptr %l89, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l89, !tbaa !21
  br i1 %t166, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb53
bb51:
  %t167 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t167, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t169, ptr %l94
  br label %bb52
bb52:
  %t170 = load i1, ptr %l94, !tbaa !21
  store i1 %t170, ptr %l92, !tbaa !21
  br label %bb53
bb53:
  %t171 = load i1, ptr %l92, !tbaa !21
  br i1 %t171, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load i32, ptr %l4, !tbaa !23
  %t178 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t172, ptr %t173, i32 %t174)
  store %"compiler/check:reflVal" %t178, ptr %l98
  br label %bb56
bb55:
  br label %bb87
bb56:
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t179, ptr %lp8
  %t180 = load %"compiler/check:reflVal", ptr %l98
  %t181 = load ptr, ptr %lp8
  store %"compiler/check:reflVal" %t180, ptr %t181
  %t182 = load ptr, ptr %lp8
  %t183 = getelementptr %"compiler/check:reflVal", ptr %t182, i32 0, i32 0
  %t184 = load i1, ptr %t183, !tbaa !21
  br i1 %t184, label %bb57, label %bb58
bb57:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t188 = load ptr, ptr %lp8
  %t189 = load %"compiler/check:reflVal", ptr %t188
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t186, %"compiler/source:Span" %t187, %"compiler/check:reflVal" %t189)
  store ptr %t193, ptr %l103
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t194 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t194, ptr %rv
  br label %ret
bb60:
  %t196 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t198, ptr %l106
  br label %bb61
bb61:
  %t199 = load i1, ptr %l106, !tbaa !21
  br i1 %t199, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l107, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t201, ptr %l108
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l7, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l111
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t207 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %s10, ptr %s10, { i64, ptr } %t213)
  store %"compiler/diagmsg:Msg" %t215, ptr %l113
  br label %bb65
bb65:
  %t216 = load ptr, ptr %l107, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l108
  %t218 = load %"compiler/diagmsg:Msg", ptr %l113
  %t219 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t216, %"compiler/source:Span" %t217, %"compiler/diagmsg:Msg" %t218)
  store i64 %t219, ptr %l114
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb67:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t220, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t222, ptr %l116
  br label %bb68
bb68:
  %t223 = load i1, ptr %l116, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l117, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t225, ptr %l118
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l7, !tbaa !23
  %t230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t226, i32 %t227)
  store { i64, ptr } %t230, ptr %l121
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t231 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t239 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %s11, ptr %s11, { i64, ptr } %t237)
  store %"compiler/diagmsg:Msg" %t239, ptr %l123
  br label %bb72
bb72:
  %t240 = load ptr, ptr %l117, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l118
  %t242 = load %"compiler/diagmsg:Msg", ptr %l123
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t240, %"compiler/source:Span" %t241, %"compiler/diagmsg:Msg" %t242)
  store i64 %t243, ptr %l124
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t244, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t246, ptr %l126
  br label %bb75
bb75:
  %t247 = load i1, ptr %l126, !tbaa !21
  br i1 %t247, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb79
bb77:
  %t248 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t250 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t248, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t250, ptr %l129
  br label %bb78
bb78:
  %t251 = load i1, ptr %l129, !tbaa !21
  store i1 %t251, ptr %l127, !tbaa !21
  br label %bb79
bb79:
  %t252 = load i1, ptr %l127, !tbaa !21
  br i1 %t252, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l130, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t254, ptr %l131
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l7, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t255, i32 %t256)
  store { i64, ptr } %t259, ptr %l134
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t260 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t267 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t270 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %s12, ptr %v0, ptr %s12, { i64, ptr } %t266, { i64, ptr } %t267)
  store %"compiler/diagmsg:Msg" %t270, ptr %l137
  br label %bb83
bb83:
  %t271 = load ptr, ptr %l130, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l131
  %t273 = load %"compiler/diagmsg:Msg", ptr %l137
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t271, %"compiler/source:Span" %t272, %"compiler/diagmsg:Msg" %t273)
  store i64 %t274, ptr %l138
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l141
  br label %bb86
bb86:
  %t280 = load ptr, ptr %l141, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t280, ptr %rv
  br label %ret
bb87:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l7, !tbaa !23
  %t286 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t282, i32 %t283)
  store i1 %t286, ptr %l145
  br label %bb88
bb88:
  %t287 = load i1, ptr %l145, !tbaa !21
  br i1 %t287, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb92
bb90:
  %t288 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %t288)
  store i1 %t290, ptr %l148
  br label %bb91
bb91:
  %t291 = load i1, ptr %l148, !tbaa !21
  store i1 %t291, ptr %l146, !tbaa !21
  br label %bb92
bb92:
  %t292 = load i1, ptr %l146, !tbaa !21
  br i1 %t292, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l7, !tbaa !23
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l152
  br label %bb96
bb96:
  %t299 = load i1, ptr %l152, !tbaa !21
  br i1 %t299, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l7, !tbaa !23
  %t305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t301, i32 %t302)
  store i1 %t305, ptr %l156
  br label %bb100
bb100:
  %t306 = load i1, ptr %l156, !tbaa !21
  br i1 %t306, label %bb101, label %bb102
bb101:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l7, !tbaa !23
  %t311 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t307, i32 %t308)
  store i32 %t311, ptr %l160
  br label %bb103
bb102:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb104
bb103:
  %t312 = load i32, ptr %l160, !range !{i32 0, i32 6}
  %t314 = trunc i64 2 to i32
  %t315 = icmp eq i32 %t312, %t314
  store i1 %t315, ptr %l157, !tbaa !21
  br label %bb104
bb104:
  %t317 = load i1, ptr %l157, !tbaa !21
  br i1 %t317, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l164, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t320, ptr %l165
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l7, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t321, i32 %t322)
  store { i64, ptr } %t325, ptr %l168
  br label %bb108
bb108:
  %t326 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  %t328 = extractvalue { i64, ptr } %t326, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t333 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t336 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t332, { i64, ptr } %t333)
  store %"compiler/diagmsg:Msg" %t336, ptr %l171
  br label %bb109
bb109:
  %t337 = load ptr, ptr %l164, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l165
  %t339 = load %"compiler/diagmsg:Msg", ptr %l171
  %t340 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t337, %"compiler/source:Span" %t338, %"compiler/diagmsg:Msg" %t339)
  store i64 %t340, ptr %l172
  br label %bb110
bb110:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t345 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t341, %"compiler/source:Span" %t342)
  store ptr %t345, ptr %l175
  br label %bb111
bb111:
  %t346 = load ptr, ptr %l175, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t346, ptr %rv
  br label %ret
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l3, !tbaa !29
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store i32 %t352, ptr %l179
  br label %bb113
bb113:
  %t353 = load i32, ptr %l179, !tbaa !23
  store i32 %t353, ptr %l9, !tbaa !23
  %t354 = load i32, ptr %l9, !tbaa !23
  %t356 = icmp slt i32 %t354, 0
  br i1 %t356, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t359 = load i32, ptr %l9, !tbaa !23
  %t360 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t363 = icmp eq i32 %t359, %t360
  br i1 %t363, label %bb117, label %bb118
bb117:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l188
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t370 = load ptr, ptr %l188, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t370, ptr %rv
  br label %ret
bb120:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t376 = load i32, ptr %l9, !tbaa !23
  %t379 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t375, i32 %t376)
  store %"compiler/generic:Desc" %t379, ptr %l193
  br label %bb121
bb121:
  %t380 = load %"compiler/generic:Desc", ptr %l193
  store %"compiler/generic:Desc" %t380, ptr %l10
  %t381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t383 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t381, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t383, ptr %l195
  br label %bb122
bb122:
  %t384 = load i1, ptr %l195, !tbaa !21
  br i1 %t384, label %bb123, label %bb124
bb123:
  %t385 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t390 = icmp ne i64 %t386, %t387
  store i1 %t390, ptr %l196, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb125
bb125:
  %t392 = load i1, ptr %l196, !tbaa !21
  br i1 %t392, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s18
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l200, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t394, ptr %l201
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s18, ptr %t395, %"compiler/source:Span" %t396)
  store { i64, ptr } %t399, ptr %l204
  br label %bb128
bb127:
  br label %bb132
bb128:
  %t400 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t401, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } %t405, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  %t414 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s18, ptr %s18, { i64, ptr } %t412)
  store %"compiler/diagmsg:Msg" %t414, ptr %l207
  br label %bb129
bb129:
  %t415 = load ptr, ptr %l200, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l201
  %t417 = load %"compiler/diagmsg:Msg", ptr %l207
  %t418 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t415, %"compiler/source:Span" %t416, %"compiler/diagmsg:Msg" %t417)
  store i64 %t418, ptr %l208
  br label %bb130
bb130:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t419, %"compiler/source:Span" %t420)
  store ptr %t423, ptr %l211
  br label %bb131
bb131:
  %t424 = load ptr, ptr %l211, !tbaa !29
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t424, ptr %rv
  br label %ret
bb132:
  %t426 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t426, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t428, ptr %l214
  br label %bb133
bb133:
  %t429 = load i1, ptr %l214, !tbaa !21
  br i1 %t429, label %bb134, label %bb135
bb134:
  %t430 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t435 = icmp eq i64 %t431, %t432
  store i1 %t435, ptr %l215, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb136
bb136:
  %t437 = load i1, ptr %l215, !tbaa !21
  br i1 %t437, label %bb137, label %bb138
bb137:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load %"compiler/generic:Desc", ptr %l10
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v2, ptr %t438, %"compiler/source:Span" %t439, %"compiler/generic:Desc" %t440)
  store ptr %t444, ptr %l222
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t445 = load ptr, ptr %l222, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t445, ptr %rv
  br label %ret
bb140:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l3, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t453 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t447, ptr %t448, i32 %t449)
  store %"compiler/check:reflVal" %t453, ptr %l227
  br label %bb141
bb141:
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t454, ptr %lp11
  %t455 = load %"compiler/check:reflVal", ptr %l227
  %t456 = load ptr, ptr %lp11
  store %"compiler/check:reflVal" %t455, ptr %t456
  %t457 = load ptr, ptr %lp11
  %t458 = getelementptr %"compiler/check:reflVal", ptr %t457, i32 0, i32 0
  %t459 = load i1, ptr %t458, !tbaa !21
  br i1 %t459, label %bb142, label %bb143
bb142:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load %"compiler/source:Span", ptr %l1
  %t463 = load ptr, ptr %lp11
  %t464 = load %"compiler/check:reflVal", ptr %t463
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t461, %"compiler/source:Span" %t462, %"compiler/check:reflVal" %t464)
  store ptr %t468, ptr %l232
  br label %bb144
bb143:
  br label %bb145
bb144:
  %t469 = load ptr, ptr %l232, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t469, ptr %rv
  br label %ret
bb145:
  %t471 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t472 = load i64, ptr %t471, !tbaa !24
  store i64 %t472, ptr %l12, !tbaa !24
  %t474 = load i64, ptr %l12, !tbaa !24
  %t475 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t478 = icmp eq i64 %t474, %t475
  br i1 %t478, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  store { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb149:
  %t480 = load i64, ptr %l12, !tbaa !24
  %t481 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t484 = icmp eq i64 %t480, %t481
  br i1 %t484, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb153:
  %t486 = load i64, ptr %l12, !tbaa !24
  %t487 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t490 = icmp eq i64 %t486, %t487
  br i1 %t490, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  store { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb157:
  %t492 = load i64, ptr %l12, !tbaa !24
  %t493 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t496 = icmp eq i64 %t492, %t493
  br i1 %t496, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store { i64, ptr } { i64 123, ptr getelementptr inbounds (<{ i64, [123 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_6fa12bf18c08968_7f63ef0109416d3c)
  unreachable
bb166:
  %t498 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t498, ptr %l13, !tbaa !27
  %t499 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t500 = load i64, ptr %t499, !tbaa !24
  store i64 %t500, ptr %l14, !tbaa !24
  %t502 = load i64, ptr %l14, !tbaa !24
  %t503 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t506 = icmp eq i64 %t502, %t503
  br i1 %t506, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb170:
  %t508 = load i64, ptr %l14, !tbaa !24
  %t509 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t512 = icmp eq i64 %t508, %t509
  br i1 %t512, label %bb171, label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb174
bb173:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb174:
  %t514 = load i64, ptr %l14, !tbaa !24
  %t515 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t518 = icmp eq i64 %t514, %t515
  br i1 %t518, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb178:
  %t520 = load i64, ptr %l14, !tbaa !24
  %t521 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t524 = icmp eq i64 %t520, %t521
  br i1 %t524, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb182
bb181:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb182:
  br i1 true, label %bb183, label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb186
bb185:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_366830190f407939_a82d5f1c611378ed)
  unreachable
bb187:
  %t526 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l262, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t528, ptr %l263
  %t530 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t532 = load ptr, ptr @__olang_prog_scope
  %t533 = load ptr, ptr @__olang_prog_scope
  %t537 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %t532, ptr %v0, ptr %t533, ptr %s0, { i64, ptr } %t526, { i64, ptr } %t530, { i64, ptr } %t531)
  store %"compiler/diagmsg:Msg" %t537, ptr %l267
  br label %bb188
bb188:
  %t538 = load ptr, ptr %l262, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l263
  %t540 = load %"compiler/diagmsg:Msg", ptr %l267
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t538, %"compiler/source:Span" %t539, %"compiler/diagmsg:Msg" %t540)
  store i64 %t541, ptr %l268
  br label %bb189
bb189:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l1
  %t546 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t542, %"compiler/source:Span" %t543)
  store ptr %t546, ptr %l271
  br label %bb190
bb190:
  %t547 = load ptr, ptr %l271, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t547, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 90
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 90
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  store i32 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i1, ptr %l2, !tbaa !21
  %t20 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 90
  store i1 %t17, ptr %t20, !tbaa !21
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 17}
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i32, ptr %l3, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i64 %t42, ptr %t43)
  br label %bb11
bb11:
  br label %bb35
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 1
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb30
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i32, ptr %l7, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t90 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t85, i64 %t86, i64 %t89, ptr %t90)
  br label %bb23
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1e97160fa78b00b5_b2a2d0ea90892ee9)
  unreachable
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_de2cb745672f71c4_3d4b81a63c3c3818)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 83
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t29, ptr %t30)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t33, ptr %l19
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t34, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t35)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"compiler/check:roOrigin"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca %"compiler/check:roOrigin"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca %"compiler/check:roOrigin"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l13
  br label %bb4
bb4:
  %t13 = load i1, ptr %l13, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 18}
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 76
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t35, i64 %t36)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39, ptr %l25
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t40, i1 false)
  store %"compiler/check:roOrigin" %t43, ptr %l28
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t46 = load %"compiler/check:roOrigin", ptr %l28
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t44, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45, %"compiler/check:roOrigin" %t46)
  br label %bb16
bb16:
  br label %bb40
bb17:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 18}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 76
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t65, i64 %t66)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t69, ptr %l39
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t73 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t70, i1 true)
  store %"compiler/check:roOrigin" %t73, ptr %l42
  br label %bb24
bb24:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l39
  %t76 = load %"compiler/check:roOrigin", ptr %l42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t74, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t75, %"compiler/check:roOrigin" %t76)
  br label %bb25
bb25:
  br label %bb40
bb26:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 10
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 76
  store ptr %t94, ptr %l50, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t95, i64 %t96)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, ptr %l53
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Slice", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t106 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t103, i1 true)
  store %"compiler/check:roOrigin" %t106, ptr %l57
  br label %bb33
bb33:
  %t107 = load ptr, ptr %l50, !tbaa !29
  %t108 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l53
  %t109 = load %"compiler/check:roOrigin", ptr %l57
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t107, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, %"compiler/check:roOrigin" %t109)
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9ed68493f04b873b_45e1787ed2cd21af)
  unreachable
bb40:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca i32
  %l43 = alloca ptr
  %rv = alloca ptr
  %t75 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:seqOf", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t9, ptr %l8
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:seqOf", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t15, %"compiler/source:Span" %t16, ptr %t17)
  store ptr %t21, ptr %l15
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = icmp sge i64 0, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = icmp sle i64 0, 1152921504606846975
  br i1 %t25, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_207369a2ec6f9fee_7129d1e6d10224a2)
  unreachable
bb6:
  %t27 = mul i64 0, 8
  %t28 = insertvalue { i64, ptr } undef, i64 0, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_207369a2ec6f9fee_7129d1e6d10224a2)
  unreachable
bb8:
  %t32 = icmp sle i64 0, 1152921504606846975
  br i1 %t32, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_207369a2ec6f9fee_7129d1e6d10224a2)
  unreachable
bb10:
  %t34 = mul i64 0, 8
  %t35 = insertvalue { i64, ptr } undef, i64 0, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = icmp sge i64 0, 0
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_207369a2ec6f9fee_7129d1e6d10224a2)
  unreachable
bb12:
  %t39 = icmp sle i64 0, 2305843009213693951
  br i1 %t39, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3d307812d0489f63_908317b964e2b157)
  unreachable
bb14:
  %t41 = mul i64 0, 4
  %t42 = insertvalue { i64, ptr } undef, i64 0, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l8
  %t46 = load %"compiler/source:Span", ptr %l9
  %t47 = load i64, ptr %l11, !tbaa !24
  %t48 = load ptr, ptr %l16, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t44, %"compiler/source:Span" %t45, %"compiler/source:Span" %t46, i64 %t47, ptr %t48, { i64, ptr } %t49, { i64, ptr } %t50, { i64, ptr } %t43)
  store ptr %t52, ptr %l26
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_3d307812d0489f63_908317b964e2b157)
  unreachable
bb16:
  %t53 = load ptr, ptr %l26, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l27, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t55, ptr %l28
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t56)
  store i32 %t58, ptr %l30
  br label %bb18
bb18:
  store i32 22, ptr %l31
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l32
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t66)
  store i32 %t68, ptr %l37
  br label %bb19
bb19:
  %t69 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t70, i32 %t71, i64 %t69)
  store i32 %t73, ptr %l39
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 0
  store i64 3, ptr %t76
  %t77 = load %"compiler/source:Span", ptr %l32
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t77, 0
  %t79 = load i32, ptr %l39, !tbaa !23
  %t80 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, i32 %t79, 1
  %t82 = insertvalue { %"compiler/source:Span", i32, ptr } %t80, ptr %t74, 2
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t82, ptr %t83
  %t84 = load { i64, [5 x i64] }, ptr %t75
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t84, ptr %t86
  %t87 = load ptr, ptr %l27, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l28
  %t89 = load i32, ptr %l30, !tbaa !23
  %t90 = load i32, ptr %l31, !range !{i32 0, i32 49}
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, i32 %t90, ptr %t86, ptr null)
  store ptr %t92, ptr %l43
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l43, !tbaa !29
  store ptr %t93, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l39 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t10, ptr %t9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t13, ptr %l10)
  store i32 %t15, ptr %l12
  br label %bb3
bb3:
  %t16 = load i32, ptr %l12, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 55
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %t19, i64 %t23, i32 %t24)
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 59
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t31, i64 %t35)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38, ptr %l23
  br label %bb5
bb5:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %t40, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t41, i32 %t39)
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 14
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/check:frame", ptr %t46, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t45, i64 %t49)
  store ptr %t52, ptr %l29
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l29, !tbaa !29
  store ptr %t53, ptr %l3, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t70)
  store i32 %t73, ptr %l39
  br label %bb8
bb8:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t79, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb9
bb9:
  %t87 = load i32, ptr %l2, !tbaa !23
  store i32 %t87, ptr %l46, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t93, i32 %t97)
  store i32 %t100, ptr %l52
  br label %bb10
bb10:
  %t101 = load ptr, ptr %l33, !tbaa !29
  %t102 = load i32, ptr %l39, !tbaa !23
  %t103 = load i32, ptr %l45, !tbaa !23
  %t104 = load i32, ptr %l46, !tbaa !23
  %t105 = load i32, ptr %l52, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t101, i32 %t102, i32 %t103, i32 %t104, i32 %t105, i64 0, i1 false, i32 0)
  store i32 %t106, ptr %l53
  br label %bb11
bb11:
  %t107 = load i32, ptr %l53, !tbaa !23
  %t108 = load ptr, ptr %l30, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 2
  store i32 %t107, ptr %t109, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l137 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [3 x i64] }, align 8
  %t216 = alloca { i64, [4 x i64] }, align 8
  %t272 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l17, !tbaa !23
  %t12 = load i1, ptr %l4, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load i32, ptr %l17, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t14, i32 %t15, { i64, ptr } %t16, i64 0)
  store i64 %t17, ptr %l20
  br label %bb8
bb8:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l24
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l25
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t29, 0
  %t36 = insertvalue { %"compiler/source:Span", i32 } %t34, i32 %t30, 1
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t27, %"compiler/source:Span" %t28, ptr %t40)
  store ptr %t44, ptr %l33
  br label %bb11
bb10:
  br label %bb27
bb11:
  %t45 = load ptr, ptr %l33, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb14:
  %t50 = mul i64 0, 8
  %t51 = insertvalue { i64, ptr } undef, i64 0, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t52, ptr %l37, !tbaa !27
  %t53 = icmp sge i64 0, 0
  br i1 %t53, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb16:
  %t55 = icmp sle i64 0, 1152921504606846975
  br i1 %t55, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb18:
  %t57 = mul i64 0, 8
  %t58 = insertvalue { i64, ptr } undef, i64 0, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = icmp sge i64 0, 0
  br i1 %t60, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb20:
  %t62 = icmp sle i64 0, 2305843009213693951
  br i1 %t62, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb22:
  %t64 = mul i64 0, 4
  %t65 = insertvalue { i64, ptr } undef, i64 0, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t67 = load ptr, ptr %l23, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l24
  %t69 = load %"compiler/source:Span", ptr %l25
  %t70 = load i64, ptr %l26, !tbaa !24
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t67, %"compiler/source:Span" %t68, %"compiler/source:Span" %t69, i64 %t70, ptr %t71, { i64, ptr } %t72, { i64, ptr } %t73, { i64, ptr } %t66)
  store ptr %t75, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb24:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l46
  %t79 = load ptr, ptr %l2, !tbaa !29
  store ptr %t79, ptr %l47, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l3, !tbaa !23
  %t83 = load %"compiler/source:Span", ptr %l1
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t80, ptr %t76, i32 %t82, %"compiler/source:Span" %t83)
  store ptr %t88, ptr %l52
  br label %bb25
bb25:
  store { i64, [3 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 0
  store i64 1, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l46
  %t92 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t91, 0
  %t93 = load ptr, ptr %l47, !tbaa !29
  %t94 = insertvalue { %"compiler/source:Span", ptr, ptr } %t92, ptr %t93, 1
  %t95 = load ptr, ptr %l52, !tbaa !29
  %t96 = insertvalue { %"compiler/source:Span", ptr, ptr } %t94, ptr %t95, 2
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t96, ptr %t97
  %t98 = load { i64, [3 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t101, ptr %t100)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l56, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  store i32 %t105, ptr %l57, !tbaa !23
  %t106 = load i1, ptr %l4, !tbaa !21
  br i1 %t106, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load i32, ptr %l57, !tbaa !23
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t108, i32 %t109, { i64, ptr } %t110, i64 1)
  store i64 %t111, ptr %l60
  br label %bb31
bb31:
  %t112 = load i64, ptr %l60, !tbaa !24
  store i64 %t112, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  %t118 = load i32, ptr %l3, !tbaa !23
  store i32 %t118, ptr %l64, !tbaa !23
  %t119 = load i1, ptr %l4, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb33:
  br label %bb41
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb36
bb36:
  %t121 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t121, ptr %l67
  %t122 = load i1, ptr %l4, !tbaa !21
  br i1 %t122, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb39
bb39:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l64, !tbaa !23
  %t126 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t127 = load %"compiler/source:Span", ptr %l67
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s3, ptr %s3, ptr %t124, i32 %t125, { i64, ptr } %t126, %"compiler/source:Span" %t127, { i64, ptr } %t128, i64 0, i1 false)
  store i1 %t129, ptr %l70
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load i1, ptr %l70, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
bb41:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l71, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l74, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  store ptr %t143, ptr %l77, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l7, !tbaa !24
  %t151 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t147, i64 %t148)
  store i32 %t151, ptr %l81
  br label %bb42
bb42:
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = load i32, ptr %l81, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l82
  br label %bb43
bb43:
  %t155 = load ptr, ptr %l74, !tbaa !29
  %t156 = load i32, ptr %l82, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t155, i32 %t156)
  store { i64, ptr } %t157, ptr %l83
  br label %bb44
bb44:
  %t158 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 1
  %t162 = load i32, ptr %t161, !tbaa !33
  %t163 = load ptr, ptr %l71, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t163, i32 %t162)
  store i32 %t165, ptr %l86
  br label %bb45
bb45:
  %t166 = load i32, ptr %l86, !tbaa !23
  store i32 %t166, ptr %l8, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l8, !tbaa !23
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t167, i32 %t168)
  store i1 %t171, ptr %l89
  br label %bb46
bb46:
  %t172 = load i1, ptr %l89, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l92, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l93
  %t178 = load i32, ptr %l8, !tbaa !23
  store i32 %t178, ptr %l94, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l97, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l8, !tbaa !23
  %t189 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l100
  br label %bb50
bb50:
  %t190 = load ptr, ptr %l97, !tbaa !29
  %t191 = load i32, ptr %l100, !tbaa !23
  %t192 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t192, ptr %l101
  br label %bb51
bb51:
  %t193 = load i1, ptr %l101, !tbaa !21
  br i1 %t193, label %bb52, label %bb53
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l8, !tbaa !23
  %t198 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l105
  br label %bb54
bb53:
  store i64 1, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  %t199 = load i32, ptr %l105, !tbaa !23
  %t200 = call i64 @compiler_2fcheck_2efloatBits(i32 %t199, double 0x3ff0000000000000)
  store i64 %t200, ptr %l106
  br label %bb55
bb55:
  %t201 = load i64, ptr %l106, !tbaa !24
  store i64 %t201, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t202 = load ptr, ptr %l92, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l93
  %t204 = load i32, ptr %l94, !tbaa !23
  %t205 = load i64, ptr %l102, !tbaa !24
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t202, %"compiler/source:Span" %t203, i32 %t204, i64 %t205)
  store ptr %t206, ptr %l107
  br label %bb57
bb57:
  %t207 = load ptr, ptr %l107, !tbaa !29
  store ptr %t207, ptr %l9, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l108, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t209, ptr %l109
  %t210 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t210, ptr %l110
  %t211 = load i64, ptr %l7, !tbaa !24
  store i64 %t211, ptr %l111, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  %t214 = load %"compiler/source:Span", ptr %l1
  %t215 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 0
  store i64 7, ptr %t217
  %t219 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t214, 0
  %t221 = insertvalue { %"compiler/source:Span", i32 } %t219, i32 %t215, 1
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t216
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t223, ptr %t225
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t212, %"compiler/source:Span" %t213, ptr %t225)
  store ptr %t229, ptr %l118
  br label %bb58
bb58:
  %t230 = load ptr, ptr %l118, !tbaa !29
  store ptr %t230, ptr %l119, !tbaa !29
  %t231 = icmp sge i64 0, 0
  br i1 %t231, label %bb59, label %bb60
bb59:
  %t233 = icmp sle i64 0, 1152921504606846975
  br i1 %t233, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb61:
  %t235 = mul i64 0, 8
  %t236 = insertvalue { i64, ptr } undef, i64 0, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t237, ptr %l122, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l9, !tbaa !29
  %t242 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t238, ptr %t239)
  store { i64, ptr } %t242, ptr %l125
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb63:
  %t243 = icmp sge i64 0, 0
  br i1 %t243, label %bb64, label %bb65
bb64:
  %t245 = icmp sle i64 0, 2305843009213693951
  br i1 %t245, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb66:
  %t247 = mul i64 0, 4
  %t248 = insertvalue { i64, ptr } undef, i64 0, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t250 = load ptr, ptr %l108, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l109
  %t252 = load %"compiler/source:Span", ptr %l110
  %t253 = load i64, ptr %l111, !tbaa !24
  %t254 = load ptr, ptr %l119, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t250, %"compiler/source:Span" %t251, %"compiler/source:Span" %t252, i64 %t253, ptr %t254, { i64, ptr } %t255, { i64, ptr } %t256, { i64, ptr } %t249)
  store ptr %t258, ptr %l129
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb68:
  %t259 = load ptr, ptr %l129, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l130, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t261, ptr %l131
  %t262 = load ptr, ptr %l2, !tbaa !29
  store ptr %t262, ptr %l132, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l3, !tbaa !23
  %t266 = load %"compiler/source:Span", ptr %l1
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t263, ptr %t259, i32 %t265, %"compiler/source:Span" %t266)
  store ptr %t271, ptr %l137
  br label %bb69
bb69:
  store { i64, [3 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 0
  store i64 1, ptr %t273
  %t274 = load %"compiler/source:Span", ptr %l131
  %t275 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t274, 0
  %t276 = load ptr, ptr %l132, !tbaa !29
  %t277 = insertvalue { %"compiler/source:Span", ptr, ptr } %t275, ptr %t276, 1
  %t278 = load ptr, ptr %l137, !tbaa !29
  %t279 = insertvalue { %"compiler/source:Span", ptr, ptr } %t277, ptr %t278, 2
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t279, ptr %t280
  %t281 = load { i64, [3 x i64] }, ptr %t272
  %t283 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t281, ptr %t283
  %t284 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t284, ptr %t283)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store ptr %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store ptr null, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load ptr, ptr %l4, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_feabd87b4a742d50_a08e759c84965044)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l37 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca %"compiler/generic:Context"
  %l50 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/typed:Block"
  %l95 = alloca i64
  %l98 = alloca i1
  %l101 = alloca i64
  %l104 = alloca i1
  %l112 = alloca ptr
  %rv = alloca i64
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t80 = alloca %"compiler/generic:Context", align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb1
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 15
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l21
  br label %bb2
bb2:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 126
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l25
  br label %bb3
bb3:
  %t30 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t30, ptr %l8
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 7, ptr %t36
  %t38 = insertvalue { i64, i32 } undef, i64 %t32, 0
  %t40 = insertvalue { i64, i32 } %t38, i32 %t34, 1
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t42, ptr %l29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t48, i32 0, i32 %t49, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t52, ptr %l34
  br label %bb4
bb4:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load %"compiler/source:Span", ptr %l8
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load { i64, [2 x i64] }, ptr %l29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t55, { i64, [2 x i64] } %t56, i32 %t57, i64 %t53, %"compiler/source:Span" %t54)
  store i64 %t60, ptr %l37
  br label %bb5
bb5:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 19
  %t65 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65, i64 1)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load i32, ptr %l3, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t68, i64 %t69, i64 %t70, i32 %t71, i32 0)
  store ptr %t76, ptr %l45
  br label %bb7
bb7:
  %t77 = load ptr, ptr %l45, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t80, ptr %v0, i64 %t79, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t80, i64 160, i1 false)
  br label %bb8
bb8:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %l48, i64 160, i1 false)
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t84)
  store ptr %t86, ptr %l50
  br label %bb9
bb9:
  %t87 = load %"compiler/source:Span", ptr %l8
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t91 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t88, i32 -1, i32 0, %"compiler/source:Span" %t87)
  store i32 %t91, ptr %l53
  br label %bb10
bb10:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 37
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l56
  br label %bb11
bb11:
  %t97 = load i64, ptr %l56, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  %t98 = load i32, ptr %l3, !tbaa !23
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t102 = icmp eq i32 %t98, %t99
  br i1 %t102, label %bb12, label %bb13
bb12:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t104, ptr %t105)
  store ptr %t108, ptr %l63
  br label %bb14
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t110, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb15
bb14:
  %t118 = load ptr, ptr %l63, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  br label %bb17
bb15:
  %t119 = load i32, ptr %l3, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr %l8
  %t121 = load ptr, ptr %l64, !tbaa !29
  %t122 = load ptr, ptr %l69, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t121, ptr %t122, i32 %t119, %"compiler/source:Span" %t120)
  store ptr %t125, ptr %l72
  br label %bb16
bb16:
  %t126 = load ptr, ptr %l72, !tbaa !29
  store ptr %t126, ptr %l60, !tbaa !29
  br label %bb17
bb17:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 37
  %t131 = load %"compiler/source:Span", ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 6, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t131, 0
  %t139 = insertvalue { %"compiler/source:Span", ptr } %t137, ptr %t127, 1
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t139, ptr %t140
  %t141 = load { i64, [3 x i64] }, ptr %t134
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t141, ptr %t143
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t130, ptr %t143)
  br label %bb18
bb18:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l81
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l81, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 37
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t152, i64 %t153)
  store { i64, ptr } %t156, ptr %l86
  br label %bb20
bb20:
  %t157 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t158 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t157)
  store %"compiler/typed:Block" %t158, ptr %l87
  br label %bb21
bb21:
  %t159 = load %"compiler/typed:Block", ptr %l87
  %t160 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t159, ptr %t160
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 11
  store ptr %t160, ptr %t163, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t164)
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 19
  %t169 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t168, i64 %t169, i64 2)
  br label %bb23
bb23:
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t172)
  br label %bb24
bb24:
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l95
  br label %bb25
bb25:
  %t177 = load i64, ptr %l5, !tbaa !24
  %t178 = load i64, ptr %l95, !tbaa !24
  %t180 = icmp sgt i64 %t178, %t177
  br i1 %t180, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb29
bb27:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 15
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l101
  br label %bb28
bb28:
  %t187 = load i64, ptr %l6, !tbaa !24
  %t188 = load i64, ptr %l101, !tbaa !24
  %t190 = icmp sgt i64 %t188, %t187
  store i1 %t190, ptr %l98, !tbaa !21
  br label %bb29
bb29:
  %t192 = load i1, ptr %l98, !tbaa !21
  br i1 %t192, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb32
bb31:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 126
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i64, ptr %l7, !tbaa !24
  %t200 = icmp sgt i64 %t196, %t197
  store i1 %t200, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t202 = load i1, ptr %l104, !tbaa !21
  br i1 %t202, label %bb33, label %bb34
bb33:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 14
  %t206 = load i64, ptr %l9, !tbaa !24
  %t209 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t205, i64 %t206)
  store ptr %t209, ptr %l112
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Body", ptr %t210, i32 0, i32 11
  store ptr null, ptr %t212, !tbaa !29
  store i64 -1, ptr %rv
  br label %ret
bb36:
  %t214 = load i64, ptr %l9, !tbaa !24
  store i64 %t214, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca i32
  %l54 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i64
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t33, i64 -1, i64 %a1, i32 %t35, i32 0)
  store ptr %t39, ptr %l26
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  store ptr %t60, ptr %l8, !tbaa !29
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Sig", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Func", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Sig", ptr %t73, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Func", ptr %t84, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 0
  %t92 = getelementptr %"compiler/source:Span", ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  store i32 %t93, ptr %l50, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s5, ptr %t94, i32 %t98)
  store { i64, ptr } %t101, ptr %l54
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t105 = trunc i64 %t103 to i32
  %t106 = load i32, ptr %l50, !tbaa !23
  %t108 = add i32 %t106, %t105
  %t109 = load i32, ptr %l48, !tbaa !23
  %t111 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t109, i32 %t108)
  store %"compiler/source:Span" %t111, ptr %l58
  br label %bb23
bb23:
  %t112 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %s5)
  store %"compiler/diagmsg:Msg" %t112, ptr %l59
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l58
  %t115 = load %"compiler/diagmsg:Msg", ptr %l59
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t113, %"compiler/source:Span" %t114, %"compiler/diagmsg:Msg" %t115)
  store i64 %t116, ptr %l60
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb13
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t121)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_cc3b7a6e318210b6_464c855cb4a991aa)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:Context"
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l8 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l9 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:typeCase"
  %l27 = alloca %"compiler/check:typeCase"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l46 = alloca %"compiler/generic:Context"
  %l49 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l50 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l52 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l53 = alloca i32
  %l55 = alloca i1
  %l61 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l62 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l64 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l65 = alloca i32
  %l67 = alloca i1
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca i32
  %l107 = alloca i32
  %l115 = alloca i32
  %l121 = alloca i32
  %l124 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca i64
  %l171 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca i32
  %l181 = alloca i32
  %l182 = alloca i32
  %l185 = alloca i1
  %l186 = alloca i32
  %l188 = alloca i64
  %l191 = alloca %"compiler/check:typeCase"
  %l200 = alloca i32
  %l202 = alloca %"compiler/check:typeCase"
  %l205 = alloca i1
  %l206 = alloca i32
  %l208 = alloca i64
  %l209 = alloca %"compiler/check:typeCase"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca %"compiler/check:typeCase"
  %t37 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l28
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4, ptr %l2, i1 false)
  br label %bb2
bb2:
  %t9 = shl i64 1, 40
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l36
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/source:Span", ptr %l36, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load i64, ptr %l34, !tbaa !24
  %t21 = sub i64 %t19, %t18
  store i64 %t21, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l41
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l41, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 4
  %t30 = getelementptr %"compiler/generic:Context", ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 4
  %t35 = getelementptr %"compiler/generic:Context", ptr %t34, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t37, ptr %s0, i64 %t31, i64 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t37, i64 160, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l46, i64 160, i1 false)
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 4
  %t43 = getelementptr %"compiler/generic:Context", ptr %t42, i32 0, i32 2
  %t45 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t43)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t45, ptr %l49
  br label %bb6
bb6:
  %t46 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l49
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t46, ptr %l6
  br label %bb7
bb7:
  %t48 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l6)
  %t49 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 1
  %t50 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 0
  store i32 %t50, ptr %l53
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb9, label %ok.52, !prof !99
ok.52:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t49, ptr %l52
  br label %bb8
bb8:
  %t53 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l52
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t53, ptr %l50
  br label %bb11
bb9:
  %t54 = load i32, ptr %l53, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l55, !tbaa !21
  br label %bb10
bb10:
  br label %bb14
bb11:
  %t58 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l50
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t58, ptr %l7
  %t59 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  %t60 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t59, i32 %t61, i32 %t63)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb7
bb14:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 4
  %t70 = getelementptr %"compiler/generic:Context", ptr %t69, i32 0, i32 3
  %t72 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t70)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t72, ptr %l61
  br label %bb15
bb15:
  %t73 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l61
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t73, ptr %l8
  br label %bb16
bb16:
  %t75 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l8)
  %t76 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 1
  %t77 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 0
  store i32 %t77, ptr %l65
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb18, label %ok.79, !prof !99
ok.79:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t76, ptr %l64
  br label %bb17
bb17:
  %t80 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l64
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t80, ptr %l62
  br label %bb20
bb18:
  %t81 = load i32, ptr %l65, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l67, !tbaa !21
  br label %bb19
bb19:
  br label %bb23
bb20:
  %t85 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l62
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t85, ptr %l9
  %t86 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 3
  %t87 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t86, i32 %t88, i32 %t90)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb16
bb23:
  store i64 0, ptr %l10, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t95, ptr %l72
  br label %bb24
bb24:
  %t96 = load i64, ptr %l72, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb30
bb27:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l79, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb29
bb29:
  %t123 = load i64, ptr %l79, !tbaa !24
  store i64 %t123, ptr %l76, !tbaa !24
  br label %bb30
bb30:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb32, label %bb33
bb32:
  br label %bb39
bb33:
  br label %bb34
bb34:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  store ptr %t143, ptr %l97, !tbaa !29
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i64 %t144)
  store i32 %t147, ptr %l100
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i64, ptr %l3, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t153, i64 %t154, i64 %t155, i64 %t156)
  store i32 %t161, ptr %l107
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l97, !tbaa !29
  %t163 = load i32, ptr %l100, !tbaa !23
  %t164 = load i32, ptr %l107, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t162, i32 %t163, i32 %t164)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l14, !tbaa !24
  br label %bb31
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t178 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v1, ptr %t172, ptr %l5, ptr %t173)
  store i32 %t178, ptr %l115
  br label %bb40
bb40:
  %t179 = load i32, ptr %l115, !tbaa !23
  store i32 %t179, ptr %l16, !tbaa !23
  %t180 = load i32, ptr %l16, !tbaa !23
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t184 = icmp eq i32 %t180, %t181
  br i1 %t184, label %bb41, label %bb42
bb41:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t190 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  store i32 %t190, ptr %l121
  br label %bb43
bb42:
  br label %bb74
bb43:
  %t191 = load i32, ptr %l121, !tbaa !23
  store i32 %t191, ptr %l17, !tbaa !23
  %t192 = load i32, ptr %l17, !tbaa !23
  %t194 = icmp sge i32 %t192, 0
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l17, !tbaa !23
  %t205 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t201, i32 %t202)
  store i64 %t205, ptr %l129
  br label %bb46
bb45:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb47
bb46:
  %t206 = load i64, ptr %l129, !tbaa !24
  store i64 %t206, ptr %l124, !tbaa !24
  br label %bb47
bb47:
  %t207 = load i64, ptr %l124, !tbaa !24
  store i64 %t207, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t212 = load i64, ptr %l18, !tbaa !24
  store i64 %t212, ptr %l132, !tbaa !24
  %t213 = load i64, ptr %l132, !tbaa !24
  %t214 = icmp sge i64 %t213, 0
  br i1 %t214, label %bb50, label %bb51
bb49:
  br label %bb73
bb50:
  %t216 = load i64, ptr %l132, !tbaa !24
  %t217 = icmp sle i64 %t216, 2305843009213693951
  br i1 %t217, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb52:
  %t219 = load i64, ptr %l132, !tbaa !24
  %t220 = mul i64 %t219, 4
  %t221 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l18, !tbaa !24
  store i64 %t225, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t227 = load i64, ptr %l21, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb54:
  %t233 = load i64, ptr %l22, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb59
bb56:
  %t237 = load i64, ptr %l21, !tbaa !24
  %t238 = load i64, ptr %l20, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l22, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l143, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb58
bb58:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l140, !tbaa !24
  br label %bb59
bb59:
  %t254 = load i64, ptr %l140, !tbaa !24
  store i64 %t254, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  %t255 = load i64, ptr %l24, !tbaa !24
  %t256 = load i64, ptr %l23, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t263 = load i64, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l24, !tbaa !24
  %t265 = load i64, ptr %l22, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l25, !tbaa !24
  %t273 = load i64, ptr %l25, !tbaa !24
  store i64 %t273, ptr %l161, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l164, !tbaa !29
  %t280 = load i64, ptr %l3, !tbaa !24
  store i64 %t280, ptr %l165, !tbaa !24
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t282, ptr %l167
  br label %bb64
bb64:
  %t283 = load i64, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l167, !tbaa !24
  %t286 = add i64 %t284, %t283
  %t287 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t288 = load ptr, ptr %l164, !tbaa !29
  %t289 = load i64, ptr %l165, !tbaa !24
  %t292 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t288, i64 %t289, i64 %t286, i64 %t287)
  store i32 %t292, ptr %l171
  br label %bb65
bb65:
  %t293 = load i32, ptr %l171, !tbaa !23
  %t294 = load i64, ptr %l161, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t294
  store i32 %t293, ptr %t297, !tbaa !33
  br label %bb66
bb66:
  %t298 = load i64, ptr %l24, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l24, !tbaa !24
  br label %bb60
bb67:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  store ptr %t305, ptr %l175, !tbaa !29
  %t306 = load i32, ptr %l17, !tbaa !23
  store i32 %t306, ptr %l176, !tbaa !23
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s9, ptr %t312, { i64, ptr } %t313)
  store i32 %t316, ptr %l181
  br label %bb68
bb68:
  %t317 = load ptr, ptr %l175, !tbaa !29
  %t318 = load i32, ptr %l176, !tbaa !23
  %t319 = load i32, ptr %l181, !tbaa !23
  %t320 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t317, i32 %t318, i32 %t319)
  store i32 %t320, ptr %l182
  br label %bb69
bb69:
  %t321 = load i32, ptr %l182, !tbaa !23
  store i32 %t321, ptr %l16, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l16, !tbaa !23
  %t326 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t322, i32 %t323)
  store i1 %t326, ptr %l185
  br label %bb70
bb70:
  %t327 = load i32, ptr %l16, !tbaa !23
  store i32 %t327, ptr %l186, !tbaa !23
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t329, ptr %l188
  br label %bb71
bb71:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t331 = load i64, ptr %l188, !tbaa !24
  %t333 = add i64 %t331, %t330
  %t334 = load i1, ptr %l185, !tbaa !21
  %t335 = load i32, ptr %l186, !tbaa !23
  %t337 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s9, i1 false, i1 %t334, i32 %t335, i64 %t333)
  store %"compiler/check:typeCase" %t337, ptr %l191
  br label %bb72
bb72:
  %t338 = load %"compiler/check:typeCase", ptr %l191
  store %"compiler/check:typeCase" %t338, ptr %l26
  %t339 = load i64, ptr %l3, !tbaa !24
  %t341 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 4
  store i64 %t339, ptr %t341, !tbaa !24
  %t342 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 5
  store i1 true, ptr %t342, !tbaa !21
  %t343 = load %"compiler/check:typeCase", ptr %l26
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t343, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t345 = load i32, ptr %l16, !tbaa !23
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t349 = icmp eq i32 %t345, %t346
  br i1 %t349, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s13
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t356 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store i32 %t356, ptr %l200
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t359 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s13, i1 false, i1 false, i32 %t357, i64 0)
  store %"compiler/check:typeCase" %t359, ptr %l202
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t360 = load %"compiler/check:typeCase", ptr %l202
  store %"compiler/check:typeCase" %t360, ptr %rv
  br label %ret
bb79:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l16, !tbaa !23
  %t365 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t361, i32 %t362)
  store i1 %t365, ptr %l205
  br label %bb80
bb80:
  %t366 = load i32, ptr %l16, !tbaa !23
  store i32 %t366, ptr %l206, !tbaa !23
  %t368 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t368, ptr %l208
  br label %bb81
bb81:
  %t369 = load i1, ptr %l205, !tbaa !21
  %t370 = load i32, ptr %l206, !tbaa !23
  %t371 = load i64, ptr %l208, !tbaa !24
  %t372 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s0, i1 false, i1 %t369, i32 %t370, i64 %t371)
  store %"compiler/check:typeCase" %t372, ptr %l209
  br label %bb82
bb82:
  %t373 = load %"compiler/check:typeCase", ptr %l209
  store %"compiler/check:typeCase" %t373, ptr %l27
  %t374 = load i64, ptr %l3, !tbaa !24
  %t376 = getelementptr %"compiler/check:typeCase", ptr %l27, i32 0, i32 4
  store i64 %t374, ptr %t376, !tbaa !24
  %t377 = load %"compiler/check:typeCase", ptr %l27
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t377, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca i32
  %l18 = alloca i64
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l64 = alloca %"compiler/generic:varRow"
  %l66 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l17
  br label %bb3
bb3:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t14)
  store i64 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i64, ptr %l18, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l21, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l26
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l26, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l27
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l36, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l36, !tbaa !24
  store i64 %t67, ptr %l33, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l54, !tbaa !29
  %t87 = load i64, ptr %l10, !tbaa !24
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t91, { i64, ptr } %t92)
  br label %bb20
bb20:
  store ptr %l2, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t103 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t97, i64 %t98, i64 %t99)
  store %"compiler/generic:varRow" %t103, ptr %l64
  br label %bb21
bb21:
  %t104 = getelementptr %"compiler/generic:varRow", ptr %l64, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t106, i32 %t105)
  store { i64, ptr } %t108, ptr %l66
  br label %bb22
bb22:
  %t109 = load ptr, ptr %l58, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l66, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t109, { i64, ptr } %t110)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb24
bb24:
  store ptr %l2, ptr %l68, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t113, ptr %l70, !tbaa !27
  %t114 = load i64, ptr %l10, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t112, i32 %t119)
  store { i64, ptr } %t122, ptr %l73
  br label %bb25
bb25:
  %t123 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t130, { i64, ptr } %t129)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb13
bb28:
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t137, ptr %l78
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t138, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Entry"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l28 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l29 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l31 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l32 = alloca i32
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %l70 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/names:Entry"
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca %"compiler/diagmsg:Msg"
  %l129 = alloca i64
  %l132 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l16, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l17
  %t9 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %s1)
  store %"compiler/diagmsg:Msg" %t9, ptr %l18
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l17
  %t12 = load %"compiler/diagmsg:Msg", ptr %l18
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t10, %"compiler/source:Span" %t11, %"compiler/diagmsg:Msg" %t12)
  store i64 %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load ptr, ptr %l22, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l23
  br label %bb7
bb7:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l25
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 8
  %t29 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t27)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t29, ptr %l28
  br label %bb9
bb9:
  %t30 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l28
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t30, ptr %l4
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l4)
  %t33 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 1
  %t34 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 0
  store i32 %t34, ptr %l32
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb12, label %ok.36, !prof !99
ok.36:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t33, ptr %l31
  br label %bb11
bb11:
  %t37 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l31
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t37, ptr %l29
  br label %bb14
bb12:
  %t38 = load i32, ptr %l32, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb14:
  %t42 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l29
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t42, ptr %l5
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t45)
  store { i64, ptr } %t48, ptr %l37
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t50, ptr %l38
  br label %bb16
bb16:
  %t51 = load i1, ptr %l38, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l41, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t55, i64 %t57)
  store i32 %t60, ptr %l44
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb19:
  %t61 = load i32, ptr %l2, !tbaa !23
  %t62 = load ptr, ptr %l41, !tbaa !29
  %t63 = load i32, ptr %l44, !tbaa !23
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t62, i32 %t63, i32 %t61)
  store i1 %t65, ptr %l46
  br label %bb20
bb20:
  %t66 = load i1, ptr %l46, !tbaa !21
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t68 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t69)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  br label %bb10
bb27:
  %t72 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_75, 0
  %t73 = insertvalue { ptr, ptr } %t72, ptr null, 1
  %t76 = extractvalue { ptr, ptr } %t73, 0
  %t77 = extractvalue { ptr, ptr } %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l3, ptr %t76, ptr %t77)
  br label %bb28
bb28:
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l51
  br label %bb29
bb29:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l6
  store ptr %l3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l53, !tbaa !24
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t82)
  store i64 %t84, ptr %l55
  br label %bb31
bb31:
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l60
  br label %bb35
bb35:
  %t96 = load i64, ptr %l60, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store ptr %l6, ptr %l61, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l62, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t98)
  store ptr %t100, ptr %l64
  br label %bb36
bb36:
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Body", ptr %t101, i32 0, i32 7
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t103, i64 %t104)
  store %"compiler/typed:Local" %t107, ptr %l68
  br label %bb37
bb37:
  %t108 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load ptr, ptr %l62, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t110, i32 %t109)
  store { i64, ptr } %t112, ptr %l70
  br label %bb38
bb38:
  %t113 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t114, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t126, { i64, ptr } %t125)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l8, !tbaa !24
  br label %bb30
bb41:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/names:Resolver", ptr %t138, i32 0, i32 1
  store ptr %t140, ptr %l78, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t141)
  store ptr %t143, ptr %l80
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l80, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 1
  %t147 = load i64, ptr %t146, !tbaa !24
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t148, i64 %t147)
  store ptr %t150, ptr %l83
  br label %bb43
bb43:
  %t151 = load ptr, ptr %l83, !tbaa !29
  %t153 = getelementptr %"compiler/names:Table", ptr %t151, i32 0, i32 0
  store ptr %t153, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb44
bb44:
  %t155 = load i64, ptr %l11, !tbaa !24
  store i64 %t155, ptr %l86, !tbaa !24
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t156)
  store i64 %t158, ptr %l88
  br label %bb45
bb45:
  %t159 = load i64, ptr %l86, !tbaa !24
  %t160 = load i64, ptr %l88, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb46, label %bb47
bb46:
  br label %bb62
bb47:
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l10, !tbaa !29
  %t166 = load i64, ptr %l11, !tbaa !24
  %t169 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store %"compiler/names:Entry" %t169, ptr %l93
  br label %bb49
bb49:
  %t170 = load %"compiler/names:Entry", ptr %l93
  store %"compiler/names:Entry" %t170, ptr %l12
  %t171 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t172 = load i32, ptr %t171, !range !{i32 0, i32 9}
  %t174 = trunc i64 2 to i32
  %t175 = icmp eq i32 %t172, %t174
  br i1 %t175, label %bb50, label %bb51
bb50:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l98, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t179)
  store ptr %t181, ptr %l100
  br label %bb52
bb51:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb55
bb52:
  %t182 = load ptr, ptr %l100, !tbaa !29
  %t184 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 1
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = load ptr, ptr %l98, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t188, i64 %t185, i32 %t187)
  store i32 %t191, ptr %l104
  br label %bb53
bb53:
  %t192 = load i32, ptr %l2, !tbaa !23
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = load i32, ptr %l104, !tbaa !23
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t193, i32 %t194, i32 %t192)
  store i1 %t196, ptr %l106
  br label %bb54
bb54:
  %t197 = load i1, ptr %l106, !tbaa !21
  store i1 %t197, ptr %l96, !tbaa !21
  br label %bb55
bb55:
  %t198 = load i1, ptr %l96, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l6, ptr %l107, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s11, ptr %t199, i32 %t201)
  store { i64, ptr } %t204, ptr %l110
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t205 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t206, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t218, { i64, ptr } %t217)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t220 = load i64, ptr %l11, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l11, !tbaa !24
  br label %bb44
bb62:
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t225, ptr %l116
  br label %bb63
bb63:
  %t226 = load i64, ptr %l116, !tbaa !24
  %t227 = icmp sgt i64 %t226, 8
  br i1 %t227, label %bb64, label %bb65
bb64:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %s0, ptr %l6, i64 8)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l119, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t231, ptr %l120
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l2, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t232, i32 %t233)
  store { i64, ptr } %t236, ptr %l123
  br label %bb68
bb68:
  %t237 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l124, !tbaa !27
  %t245 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store { i64, ptr } %t245, ptr %l126
  br label %bb69
bb69:
  %t246 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  %t248 = extractvalue { i64, ptr } %t246, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t255 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t253, { i64, ptr } %t252)
  store %"compiler/diagmsg:Msg" %t255, ptr %l128
  br label %bb70
bb70:
  %t256 = load ptr, ptr %l119, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l120
  %t258 = load %"compiler/diagmsg:Msg", ptr %l128
  %t259 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t256, %"compiler/source:Span" %t257, %"compiler/diagmsg:Msg" %t258)
  store i64 %t259, ptr %l129
  br label %bb71
bb71:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t264, ptr %l132
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t265 = load ptr, ptr %l132, !tbaa !29
  store ptr %t265, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca ptr
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i1, ptr %l9, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l12
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  %t21 = getelementptr %"compiler/generic:Context", ptr %t20, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t21, i32 %t22, i32 %t23)
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t27, i32 %t28, i32 %t29)
  store i32 %t33, ptr %l20
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, i64, i64 }
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l38 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i32
  %l76 = alloca ptr
  %s0 = alloca %olang.scope
  %t55 = alloca { i64, [1 x i64] }, align 8
  %t72 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l14
  store { i64, i64, i64 } %t13, ptr %l4
  %t14 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l19
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l24
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:ForIn", ptr %t41, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp ne i32 %t44, 0
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:ForIn", ptr %t49, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = load %"compiler/source:Span", ptr %l1
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [1 x i64] }, ptr %t55, i32 0, i32 0
  store i64 0, ptr %t56
  %t57 = load { i64, [1 x i64] }, ptr %t55
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t48, i32 %t52, %"compiler/source:Span" %t53, i32 %t54, i32 3, { i64, [1 x i64] } %t57)
  store i64 %t64, ptr %l38
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:ForIn", ptr %t66, i32 0, i32 1
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load %"compiler/source:Span", ptr %l1
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 0
  store i64 0, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t72
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t65, i32 %t69, %"compiler/source:Span" %t70, i32 %t71, i32 3, { i64, [1 x i64] } %t74)
  store i64 %t81, ptr %l46
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 126
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = add i64 %t85, 1
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 126
  store i64 %t87, ptr %t90, !tbaa !24
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/ast:ForIn", ptr %t91, i32 0, i32 4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb12, label %bb13
bb12:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:ForIn", ptr %t101, i32 0, i32 4
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t100, { i64, ptr } %t104)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t107)
  store ptr %t109, ptr %l59
  br label %bb16
bb16:
  %t110 = load ptr, ptr %l59, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 10
  %t114 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t112)
  %t115 = extractvalue { i32, i64 } %t114, 1
  %t116 = extractvalue { i32, i64 } %t114, 0
  store i32 %t116, ptr %l63
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb18, label %ok.118, !prof !99
ok.118:
  store i64 %t115, ptr %l62
  br label %bb17
bb17:
  %t119 = load i64, ptr %l62, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t120)
  store ptr %t122, ptr %l66
  br label %bb21
bb21:
  %t123 = load ptr, ptr %l66, !tbaa !29
  %t125 = getelementptr %"compiler/check:frame", ptr %t123, i32 0, i32 11
  %t127 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t125)
  %t128 = extractvalue { i32, i64 } %t127, 1
  %t129 = extractvalue { i32, i64 } %t127, 0
  store i32 %t129, ptr %l70
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb23, label %ok.131, !prof !99
ok.131:
  store i64 %t128, ptr %l69
  br label %bb22
bb22:
  %t132 = load i64, ptr %l69, !tbaa !24
  store i64 %t132, ptr %l64, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l5, !tbaa !24
  %t135 = load i64, ptr %l6, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t137 = load i64, ptr %l3, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %s0, ptr %t133, i64 %t134, i64 %t135, i64 %t136, i64 %t137)
  store ptr %t143, ptr %l76
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l12 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l15 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l16 = alloca i32
  %l22 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 9
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, %a1
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 9
  %t21 = call { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %t19)
  %t22 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t21, 1
  %t23 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t21, 0
  store i32 %t23, ptr %l16
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb8, label %ok.25, !prof !99
ok.25:
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t22, ptr %l15
  br label %bb7
bb7:
  %t26 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l15
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t26, ptr %l12
  br label %bb10
bb8:
  br label %bb9
bb9:
  br label %ret
bb10:
  %t27 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t27, ptr %l3
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 8
  %t36 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %t35, i32 %t37)
  store i1 %t40, ptr %l22
  br label %bb13
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 8
  %t44 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t43, i32 %t45, i64 %t47)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb2
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i1
  %l29 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l62 = alloca %"compiler/check:heldCand"
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l88 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca { i64, i64, i64 }
  %l102 = alloca ptr
  %l107 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca ptr
  %l121 = alloca ptr
  %l126 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca i64
  %l149 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l162 = alloca ptr
  %s4 = alloca %olang.scope
  %t100 = alloca { i64, [3 x i64] }, align 8
  %t146 = alloca { i64, [3 x i64] }, align 8
  %t300 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l20
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t3)
  store i32 %t6, ptr %l23
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l20
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l24, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v2, ptr %t12, ptr %t13)
  store i1 %t16, ptr %l27
  br label %bb3
bb3:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 17
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = trunc i64 %t24 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t23, i32 %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t31 = load ptr, ptr %l35, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l35, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t45 = load ptr, ptr %l8, !tbaa !29
  store ptr %t45, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t46 = load ptr, ptr %l41, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l42, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l8, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l9, !tbaa !23
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l48
  br label %bb19
bb19:
  %t63 = load i32, ptr %l9, !tbaa !23
  %t64 = load ptr, ptr %l48, !tbaa !29
  %t66 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t64, i32 %t63)
  store %"compiler/typed:Local" %t66, ptr %l50
  br label %bb20
bb20:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l50, i32 0, i32 4
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 7}
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 103
  store ptr %t75, ptr %l54, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l56
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load ptr, ptr %l56, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i32, ptr %l9, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i64, ptr %l7, !tbaa !24
  %t90 = call %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %s4, i64 %t82, i64 %t85, i64 %t86)
  store %"compiler/check:heldCand" %t90, ptr %l62
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load %"compiler/check:heldCand", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t91, %"compiler/check:heldCand" %t92)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b35f41bb006554d6_a1d87dcad76a5f72)
  unreachable
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_943678799cf3b8f7_240de00f13c53f3)
  unreachable
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  %t99 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 0
  store i64 0, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t94, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t99, 2
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t109, ptr %t111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t93, ptr %t111)
  br label %bb39
bb39:
  store i64 -1, ptr %l10, !tbaa !24
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:ForIn", ptr %t114, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb40, label %bb41
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l74, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l75
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t123)
  store i32 %t125, ptr %l77
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t126 = load ptr, ptr %l74, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l75
  %t128 = load i32, ptr %l77, !tbaa !23
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t126, %"compiler/source:Span" %t127, i32 %t128)
  store i64 %t129, ptr %l78
  br label %bb43
bb43:
  %t130 = load i64, ptr %l78, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l79, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l80
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = trunc i64 %t133 to i32
  store i32 %t135, ptr %l83, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l85
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l87
  br label %bb44
bb44:
  %t142 = load ptr, ptr %l84, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l85
  %t144 = load i32, ptr %l87, !tbaa !23
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t142, %"compiler/source:Span" %t143, i32 %t144, i64 0)
  store ptr %t145, ptr %l88
  br label %bb45
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l80
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l83, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, i32 %t150, 1
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, ptr %t152, 2
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t153, ptr %t154
  %t155 = load { i64, [3 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t155, ptr %t157
  %t158 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t158, ptr %t157)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 37
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l93
  br label %bb48
bb48:
  %t165 = load i64, ptr %l93, !tbaa !24
  store i64 %t165, ptr %l11, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t171 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t166, i32 2, %"compiler/source:Span" %t167)
  store { i64, i64, i64 } %t171, ptr %l97
  br label %bb49
bb49:
  %t172 = load { i64, i64, i64 }, ptr %l97
  store { i64, i64, i64 } %t172, ptr %l12
  %t173 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l14, !tbaa !24
  %t179 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l102
  br label %bb50
bb50:
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 10
  %t188 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t191)
  store ptr %t193, ptr %l107
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l107, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 11
  %t197 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  br label %bb53
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l112
  store i64 %a4, ptr %l113, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load i64, ptr %l7, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, i64 %t205)
  store ptr %t209, ptr %l117
  br label %bb54
bb54:
  %t210 = icmp sge i64 0, 0
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t212 = icmp sle i64 0, 1152921504606846975
  br i1 %t212, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb57:
  %t214 = mul i64 0, 8
  %t215 = insertvalue { i64, ptr } undef, i64 0, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l112
  %t219 = load i64, ptr %l113, !tbaa !24
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i64 %t219, ptr %t220, { i64, ptr } %t216)
  store ptr %t222, ptr %l121
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb59:
  %t223 = load ptr, ptr %l121, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l13, !tbaa !24
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t224, %"compiler/source:Span" %t225, ptr %t223, i64 %t227)
  store ptr %t232, ptr %l126
  br label %bb60
bb60:
  %t233 = load ptr, ptr %l126, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load ptr, ptr %l2, !tbaa !29
  %t237 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t234, %"compiler/source:Span" %t235, ptr %t236, i64 %t237, ptr %t233)
  br label %bb61
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t244, ptr %t245, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t252)
  store ptr %t254, ptr %l138
  br label %bb63
bb63:
  %t255 = load ptr, ptr %l138, !tbaa !29
  %t257 = getelementptr %"compiler/check:frame", ptr %t255, i32 0, i32 10
  %t259 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t257)
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l142
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb65, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l141
  br label %bb64
bb64:
  %t264 = load i64, ptr %l141, !tbaa !24
  store i64 %t264, ptr %l136, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t265)
  store ptr %t267, ptr %l145
  br label %bb68
bb68:
  %t268 = load ptr, ptr %l145, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 11
  %t272 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l149
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb70, label %ok.276, !prof !99
ok.276:
  store i64 %t273, ptr %l148
  br label %bb69
bb69:
  %t277 = load i64, ptr %l148, !tbaa !24
  store i64 %t277, ptr %l143, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l13, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load i64, ptr %l15, !tbaa !24
  %t282 = load i64, ptr %l11, !tbaa !24
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t278, i64 %t279, i64 %t280, i64 %t281, i64 %t282)
  store ptr %t288, ptr %l155
  br label %bb73
bb73:
  %t289 = load ptr, ptr %l155, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l156, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t291, ptr %l157
  store ptr %t289, ptr %l158, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t295 = load i64, ptr %l10, !tbaa !24
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v0, ptr %t293, %"compiler/source:Span" %t294, i64 %t295)
  store ptr %t299, ptr %l162
  br label %bb74
bb74:
  store { i64, [3 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 0
  store i64 4, ptr %t301
  %t302 = load %"compiler/source:Span", ptr %l157
  %t303 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t302, 0
  %t304 = load ptr, ptr %l158, !tbaa !29
  %t305 = insertvalue { %"compiler/source:Span", ptr, ptr } %t303, ptr %t304, 1
  %t306 = load ptr, ptr %l162, !tbaa !29
  %t307 = insertvalue { %"compiler/source:Span", ptr, ptr } %t305, ptr %t306, 2
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t307, ptr %t308
  %t309 = load { i64, [3 x i64] }, ptr %t300
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t309, ptr %t311
  %t312 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t312, ptr %t311)
  br label %bb75
bb75:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, i64, i64 }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca { i64, i64, i64 }
  %l88 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l144 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l171 = alloca i64
  %l175 = alloca { i64, i64, i64 }
  %l179 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l197 = alloca i32
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca %"compiler/typed:Elem"
  %l241 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i32
  %l258 = alloca i64
  %l260 = alloca ptr
  %l263 = alloca i64
  %l264 = alloca i32
  %l270 = alloca ptr
  %l273 = alloca i64
  %l277 = alloca { i64, i64, i64 }
  %l281 = alloca ptr
  %l282 = alloca ptr
  %l283 = alloca %"compiler/source:Span"
  %l284 = alloca i64
  %l285 = alloca ptr
  %l286 = alloca %"compiler/source:Span"
  %l288 = alloca i32
  %l289 = alloca ptr
  %l290 = alloca ptr
  %l293 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca %"compiler/source:Span"
  %l296 = alloca i64
  %l297 = alloca ptr
  %l298 = alloca %"compiler/source:Span"
  %l300 = alloca i32
  %l301 = alloca ptr
  %l302 = alloca ptr
  %l308 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca %"compiler/source:Span"
  %l319 = alloca i64
  %l323 = alloca ptr
  %l324 = alloca ptr
  %l330 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t190 = alloca { i64, [3 x i64] }, align 8
  %t238 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t390 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [4 x i64] }, align 8
  %t586 = alloca { i64, [3 x i64] }, align 8
  %t633 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l39
  br label %bb1
bb1:
  %t8 = load i64, ptr %l39, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l41
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l43
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l40, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l41
  %t16 = load i32, ptr %l43, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l44
  br label %bb3
bb3:
  %t18 = load i64, ptr %l44, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l45, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l46
  %t21 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l49, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l50, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l51
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l53
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l51
  %t32 = load i32, ptr %l53, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l54
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l46
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l49, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l54, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:ForIn", ptr %t48, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l60, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l61
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l63
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l61
  %t62 = load i32, ptr %l63, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t60, %"compiler/source:Span" %t61, i32 %t62)
  store i64 %t63, ptr %l64
  br label %bb10
bb10:
  %t64 = load i64, ptr %l64, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l65, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l66
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l69, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l70, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l73
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l71
  %t78 = load i32, ptr %l73, !tbaa !23
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, i64 0)
  store ptr %t79, ptr %l74
  br label %bb12
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l66
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l69, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l74, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t92, ptr %t91)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 37
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l79
  br label %bb15
bb15:
  %t99 = load i64, ptr %l79, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l83
  br label %bb16
bb16:
  %t106 = load { i64, i64, i64 }, ptr %l83
  store { i64, i64, i64 } %t106, ptr %l11
  %t107 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t116)
  store ptr %t118, ptr %l88
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t125)
  store ptr %t127, ptr %l93
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 11
  %t131 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l97, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l98
  store i64 %a4, ptr %l99, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t139 = load i64, ptr %l7, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139)
  store ptr %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l8, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load ptr, ptr %l108, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t152, ptr %t153)
  store { i64, ptr } %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l97, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l98
  %t157 = load i64, ptr %l99, !tbaa !24
  %t158 = load ptr, ptr %l103, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157, ptr %t158, { i64, ptr } %t159)
  store ptr %t160, ptr %l110
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l110, !tbaa !29
  store ptr %t161, ptr %l15, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t162)
  store i32 %t165, ptr %l113
  br label %bb25
bb25:
  %t166 = load i32, ptr %l113, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l16, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t167, %"compiler/source:Span" %t168, i32 %t169)
  store i64 %t173, ptr %l117
  br label %bb26
bb26:
  %t174 = load i64, ptr %l117, !tbaa !24
  store i64 %t174, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t176, ptr %l119
  %t177 = load i64, ptr %l17, !tbaa !24
  %t179 = trunc i64 %t177 to i32
  store i32 %t179, ptr %l122, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t184 = load i64, ptr %l12, !tbaa !24
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t181, %"compiler/source:Span" %t182, ptr %t183, i64 %t184)
  store ptr %t189, ptr %l127
  br label %bb27
bb27:
  store { i64, [3 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l119
  %t193 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l122, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } %t193, i32 %t194, 1
  %t196 = load ptr, ptr %l127, !tbaa !29
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, ptr %t196, 2
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t202, ptr %t201)
  br label %bb28
bb28:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l130, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l131
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t206)
  store i32 %t208, ptr %l133
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l130, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l131
  %t211 = load i32, ptr %l133, !tbaa !23
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t209, %"compiler/source:Span" %t210, i32 %t211)
  store i64 %t212, ptr %l134
  br label %bb30
bb30:
  %t213 = load i64, ptr %l134, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l135, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l136
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = trunc i64 %t216 to i32
  store i32 %t218, ptr %l139, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l140, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l141
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t222)
  store i32 %t224, ptr %l143
  br label %bb31
bb31:
  store i32 22, ptr %l144
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l17, !tbaa !24
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, i64 %t227)
  store ptr %t231, ptr %l148
  br label %bb32
bb32:
  %t232 = load ptr, ptr %l140, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l141
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load i32, ptr %l144, !range !{i32 0, i32 49}
  %t236 = load ptr, ptr %l148, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i32 %t235, ptr %t236, ptr null)
  store ptr %t237, ptr %l149
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l139, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t244, 2
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [3 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t247, ptr %t249
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t250, ptr %t249)
  br label %bb34
bb34:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l153
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l155
  br label %bb35
bb35:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l153
  %t259 = load i32, ptr %l155, !tbaa !23
  %t260 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259)
  store i64 %t260, ptr %l156
  br label %bb36
bb36:
  %t261 = load i64, ptr %l156, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l157, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l158
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = trunc i64 %t264 to i32
  store i32 %t266, ptr %l161, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l162, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l163
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l165
  br label %bb37
bb37:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l163
  %t275 = load i32, ptr %l165, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t273, %"compiler/source:Span" %t274, i32 %t275, i64 0)
  store ptr %t276, ptr %l166
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l158
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l161, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l166, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t289, ptr %t288)
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 37
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l171
  br label %bb40
bb40:
  %t296 = load i64, ptr %l171, !tbaa !24
  store i64 %t296, ptr %l20, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t302 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t297, i32 2, %"compiler/source:Span" %t298)
  store { i64, i64, i64 } %t302, ptr %l175
  br label %bb41
bb41:
  %t303 = load { i64, i64, i64 }, ptr %l175
  store { i64, i64, i64 } %t303, ptr %l21
  %t304 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l22, !tbaa !24
  %t307 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l24, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t313)
  store ptr %t315, ptr %l181
  br label %bb42
bb42:
  %t316 = load ptr, ptr %l181, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 10
  %t320 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t318)
  %t321 = extractvalue { i32, i64 } %t320, 1
  %t322 = extractvalue { i32, i64 } %t320, 0
  store i32 %t322, ptr %l185
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb44, label %ok.324, !prof !99
ok.324:
  store i64 %t321, ptr %l184
  br label %bb43
bb43:
  %t325 = load i64, ptr %l184, !tbaa !24
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t326)
  store ptr %t328, ptr %l187
  br label %bb47
bb47:
  %t329 = load ptr, ptr %l187, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 10
  %t332 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb48
bb48:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l191, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l192, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l193
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l194, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l195
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t340, ptr %l196, !tbaa !23
  store i32 15, ptr %l197
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t343 = load i64, ptr %l19, !tbaa !24
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t343)
  store ptr %t347, ptr %l201
  br label %bb49
bb49:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load i64, ptr %l18, !tbaa !24
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 %t350)
  store ptr %t354, ptr %l205
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l195
  %t358 = load i32, ptr %l196, !tbaa !23
  %t359 = load i32, ptr %l197, !range !{i32 0, i32 49}
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, i32 %t359, ptr %t360, ptr %t355)
  store ptr %t362, ptr %l207
  br label %bb51
bb51:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l193
  %t366 = load ptr, ptr %l207, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t364, %"compiler/source:Span" %t365, ptr %t366, i64 %t363)
  store ptr %t368, ptr %l209
  br label %bb52
bb52:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t370)
  br label %bb53
bb53:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l16, !tbaa !23
  %t375 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l212
  br label %bb54
bb54:
  %t376 = load i32, ptr %l212, !tbaa !23
  store i32 %t376, ptr %l25, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l213
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l16, !tbaa !23
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l216
  br label %bb55
bb55:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l17, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l220
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 0
  store i64 2, ptr %t391
  %t392 = load %"compiler/source:Span", ptr %l213
  %t393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t392, 0
  %t394 = load i32, ptr %l216, !tbaa !23
  %t395 = insertvalue { %"compiler/source:Span", i32, ptr } %t393, i32 %t394, 1
  %t396 = load ptr, ptr %l220, !tbaa !29
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } %t395, ptr %t396, 2
  %t398 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t397, ptr %t398
  %t399 = load { i64, [4 x i64] }, ptr %t390
  %t401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t399, ptr %t401
  store ptr %t401, ptr %l26, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l223, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l224
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l225
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = load i32, ptr %l25, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l230
  br label %bb57
bb57:
  %t416 = load ptr, ptr %l26, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t419 = load i64, ptr %l19, !tbaa !24
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t417, %"compiler/source:Span" %t418, i64 %t419)
  store ptr %t423, ptr %l235
  br label %bb58
bb58:
  %t424 = load ptr, ptr %l231, !tbaa !29
  %t425 = load ptr, ptr %l235, !tbaa !29
  %t427 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t424, ptr %t425, i32 0)
  store %"compiler/typed:Elem" %t427, ptr %l237
  br label %bb59
bb59:
  %t428 = load %"compiler/typed:Elem", ptr %l237
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t428, ptr %t429
  store { i64, [4 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 0
  store i64 4, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l225
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t432, 0
  %t434 = load i32, ptr %l230, !tbaa !23
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr } %t433, i32 %t434, 1
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr } %t435, ptr %t429, 2
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t430
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l223, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l224
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t442, %"compiler/source:Span" %t443, ptr %t441)
  store ptr %t445, ptr %l241
  br label %bb60
bb60:
  %t446 = load ptr, ptr %l241, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t447, %"compiler/source:Span" %t448, ptr %t449, i64 %t450, ptr %t446)
  br label %bb61
bb61:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t457, ptr %t458, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t465)
  store ptr %t467, ptr %l253
  br label %bb63
bb63:
  %t468 = load ptr, ptr %l253, !tbaa !29
  %t470 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 10
  %t472 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t470)
  %t473 = extractvalue { i32, i64 } %t472, 1
  %t474 = extractvalue { i32, i64 } %t472, 0
  store i32 %t474, ptr %l257
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb65, label %ok.476, !prof !99
ok.476:
  store i64 %t473, ptr %l256
  br label %bb64
bb64:
  %t477 = load i64, ptr %l256, !tbaa !24
  store i64 %t477, ptr %l251, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t478)
  store ptr %t480, ptr %l260
  br label %bb68
bb68:
  %t481 = load ptr, ptr %l260, !tbaa !29
  %t483 = getelementptr %"compiler/check:frame", ptr %t481, i32 0, i32 11
  %t485 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t483)
  %t486 = extractvalue { i32, i64 } %t485, 1
  %t487 = extractvalue { i32, i64 } %t485, 0
  store i32 %t487, ptr %l264
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb70, label %ok.489, !prof !99
ok.489:
  store i64 %t486, ptr %l263
  br label %bb69
bb69:
  %t490 = load i64, ptr %l263, !tbaa !24
  store i64 %t490, ptr %l258, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i64, ptr %l22, !tbaa !24
  %t493 = load i64, ptr %l23, !tbaa !24
  %t494 = load i64, ptr %l24, !tbaa !24
  %t495 = load i64, ptr %l20, !tbaa !24
  %t501 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t491, i64 %t492, i64 %t493, i64 %t494, i64 %t495)
  store ptr %t501, ptr %l270
  br label %bb73
bb73:
  %t502 = load ptr, ptr %l270, !tbaa !29
  store ptr %t502, ptr %l28, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 37
  %t507 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t505)
  store i64 %t507, ptr %l273
  br label %bb74
bb74:
  %t508 = load i64, ptr %l273, !tbaa !24
  store i64 %t508, ptr %l29, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l1
  %t514 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t509, i32 3, %"compiler/source:Span" %t510)
  store { i64, i64, i64 } %t514, ptr %l277
  br label %bb75
bb75:
  %t515 = load { i64, i64, i64 }, ptr %l277
  store { i64, i64, i64 } %t515, ptr %l30
  %t516 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 0
  %t517 = load i64, ptr %t516, !tbaa !24
  store i64 %t517, ptr %l31, !tbaa !24
  %t519 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 1
  %t520 = load i64, ptr %t519, !tbaa !24
  store i64 %t520, ptr %l32, !tbaa !24
  %t522 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 2
  %t523 = load i64, ptr %t522, !tbaa !24
  store i64 %t523, ptr %l33, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l281, !tbaa !29
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l282, !tbaa !29
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l283
  %t528 = load i64, ptr %l19, !tbaa !24
  store i64 %t528, ptr %l284, !tbaa !24
  %t529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t529, ptr %l285, !tbaa !29
  %t530 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t530, ptr %l286
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t531)
  store i32 %t533, ptr %l288
  br label %bb76
bb76:
  %t534 = load ptr, ptr %l285, !tbaa !29
  %t535 = load %"compiler/source:Span", ptr %l286
  %t536 = load i32, ptr %l288, !tbaa !23
  %t537 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t534, %"compiler/source:Span" %t535, i32 %t536, i64 1)
  store ptr %t537, ptr %l289
  br label %bb77
bb77:
  %t538 = load ptr, ptr %l282, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l283
  %t540 = load i64, ptr %l284, !tbaa !24
  %t541 = load ptr, ptr %l289, !tbaa !29
  %t542 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t538, %"compiler/source:Span" %t539, i64 %t540, ptr %t541)
  store ptr %t542, ptr %l290
  br label %bb78
bb78:
  %t543 = load ptr, ptr %l281, !tbaa !29
  %t544 = load ptr, ptr %l290, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t543, ptr %t544)
  br label %bb79
bb79:
  %t545 = load i64, ptr %l9, !tbaa !24
  %t547 = icmp sge i64 %t545, 0
  br i1 %t547, label %bb80, label %bb81
bb80:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l293, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  store ptr %t550, ptr %l294, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t551, ptr %l295
  %t552 = load i64, ptr %l9, !tbaa !24
  store i64 %t552, ptr %l296, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l297, !tbaa !29
  %t554 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t554, ptr %l298
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t555)
  store i32 %t557, ptr %l300
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t558 = load ptr, ptr %l297, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l298
  %t560 = load i32, ptr %l300, !tbaa !23
  %t561 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t558, %"compiler/source:Span" %t559, i32 %t560, i64 1)
  store ptr %t561, ptr %l301
  br label %bb83
bb83:
  %t562 = load ptr, ptr %l294, !tbaa !29
  %t563 = load %"compiler/source:Span", ptr %l295
  %t564 = load i64, ptr %l296, !tbaa !24
  %t565 = load ptr, ptr %l301, !tbaa !29
  %t566 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t562, %"compiler/source:Span" %t563, i64 %t564, ptr %t565)
  store ptr %t566, ptr %l302
  br label %bb84
bb84:
  %t567 = load ptr, ptr %l293, !tbaa !29
  %t568 = load ptr, ptr %l302, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t567, ptr %t568)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i64, ptr %l31, !tbaa !24
  %t571 = load i64, ptr %l32, !tbaa !24
  %t572 = load i64, ptr %l33, !tbaa !24
  %t573 = load i64, ptr %l29, !tbaa !24
  %t579 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t569, i64 %t570, i64 %t571, i64 %t572, i64 %t573)
  store ptr %t579, ptr %l308
  br label %bb87
bb87:
  %t580 = load ptr, ptr %l308, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load %"compiler/source:Span", ptr %l1
  %t583 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t586
  %t587 = getelementptr { i64, [3 x i64] }, ptr %t586, i32 0, i32 0
  store i64 4, ptr %t587
  %t589 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t582, 0
  %t591 = insertvalue { %"compiler/source:Span", ptr, ptr } %t589, ptr %t583, 1
  %t593 = insertvalue { %"compiler/source:Span", ptr, ptr } %t591, ptr %t580, 2
  %t594 = getelementptr { i64, [3 x i64] }, ptr %t586, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t593, ptr %t594
  %t595 = load { i64, [3 x i64] }, ptr %t586
  %t597 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t595, ptr %t597
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t581, ptr %t597)
  br label %bb88
bb88:
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l316, !tbaa !29
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l317, !tbaa !29
  %t602 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t602, ptr %l318
  %t603 = load i64, ptr %l8, !tbaa !24
  store i64 %t603, ptr %l319, !tbaa !24
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t605 = load %"compiler/source:Span", ptr %l1
  %t606 = load i64, ptr %l18, !tbaa !24
  %t610 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t604, %"compiler/source:Span" %t605, i64 %t606)
  store ptr %t610, ptr %l323
  br label %bb89
bb89:
  %t611 = load ptr, ptr %l317, !tbaa !29
  %t612 = load %"compiler/source:Span", ptr %l318
  %t613 = load i64, ptr %l319, !tbaa !24
  %t614 = load ptr, ptr %l323, !tbaa !29
  %t615 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t611, %"compiler/source:Span" %t612, i64 %t613, ptr %t614)
  store ptr %t615, ptr %l324
  br label %bb90
bb90:
  %t616 = load ptr, ptr %l316, !tbaa !29
  %t617 = load ptr, ptr %l324, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t616, ptr %t617)
  br label %bb91
bb91:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load i64, ptr %l12, !tbaa !24
  %t620 = load i64, ptr %l13, !tbaa !24
  %t621 = load i64, ptr %l14, !tbaa !24
  %t622 = load i64, ptr %l10, !tbaa !24
  %t628 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t618, i64 %t619, i64 %t620, i64 %t621, i64 %t622)
  store ptr %t628, ptr %l330
  br label %bb92
bb92:
  %t629 = load ptr, ptr %l330, !tbaa !29
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t633
  %t634 = getelementptr { i64, [3 x i64] }, ptr %t633, i32 0, i32 0
  store i64 4, ptr %t634
  %t636 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t631, 0
  %t638 = insertvalue { %"compiler/source:Span", ptr, ptr } %t636, ptr %t629, 1
  %t639 = insertvalue { %"compiler/source:Span", ptr, ptr } %t638, ptr null, 2
  %t640 = getelementptr { i64, [3 x i64] }, ptr %t633, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t639, ptr %t640
  %t641 = load { i64, [3 x i64] }, ptr %t633
  %t643 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t641, ptr %t643
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t630, ptr %t643)
  br label %bb93
bb93:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesImmut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = load i32, ptr %l6, !tbaa !23
  %t11 = icmp ne i32 %t9, %t8
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesNoQuestion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca i1
  %l17 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 26
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 6
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t23, i32 %t27)
  store { i64, ptr } %t30, ptr %l17
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp sgt i64 %t32, 0
  store i1 %t34, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l11, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 14
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t40, i64 %t44)
  store ptr %t47, ptr %l25
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 1
  %t51 = load { i64, [2 x i64] }, ptr %t50
  store { i64, [2 x i64] } %t51, ptr %l2
  %t53 = load { i64, [2 x i64] }, ptr %l2
  %t55 = extractvalue { i64, [2 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  %t58 = load { i64, [2 x i64] }, ptr %l2
  %t60 = extractvalue { i64, [2 x i64] } %t58, 0
  %t61 = icmp eq i64 %t60, 1
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_17791ca4bfbb451a_6d701f0037462966)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load i1, ptr %l28, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d78, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d79, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:narrowed"
  %l6 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:narrowed"
  store %"compiler/check:narrowed" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 2
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 4
  %t10 = load i64, ptr %t9, !tbaa !24
  %t16 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t2, i64 %t4, i32 %t6, i64 %t8, i64 %t10, i1 true)
  store %"compiler/check:narrowed" %t16, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/check:narrowed", ptr %l6
  store %"compiler/check:narrowed" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb12:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb13, label %bb14
bb13:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb14
bb14:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb18:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb19, label %bb20
bb19:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 13
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb20
bb20:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb24:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb25, label %bb26
bb25:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 30}
  %t44 = icmp eq i64 %t42, 18
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb26
bb26:
  %t45 = load i1, ptr %l19, !tbaa !21
  br i1 %t45, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb30:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb31, label %bb32
bb31:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 30}
  %t53 = icmp eq i64 %t51, 19
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb32
bb32:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb36:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb37, label %bb38
bb37:
  %t59 = load ptr, ptr %l26, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 22
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb38
bb38:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb42:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb43, label %bb44
bb43:
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 30}
  %t71 = icmp eq i64 %t69, 23
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb44
bb44:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb48:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb49, label %bb50
bb49:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 30}
  %t80 = icmp eq i64 %t78, 24
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb50
bb50:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb54:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb55, label %bb56
bb55:
  %t86 = load ptr, ptr %l38, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 30}
  %t89 = icmp eq i64 %t87, 25
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb56
bb56:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb60:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb61, label %bb62
bb61:
  %t95 = load ptr, ptr %l42, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 30}
  %t98 = icmp eq i64 %t96, 15
  store i1 %t98, ptr %l43, !tbaa !21
  br label %bb62
bb62:
  %t99 = load i1, ptr %l43, !tbaa !21
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d149dd778abfbb99_ce32867ac8840ced)
  unreachable
bb71:
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 97
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 102
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 65
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 70
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisRest(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_69063e233c23bbc5_4e0c3b9f00520e59)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l57 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t6 = load ptr, ptr %l15, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i1, ptr %l1, !tbaa !21
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t20, i1 %t22, ptr %t23)
  br label %bb9
bb9:
  br label %bb63
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 30}
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 98}
  store i32 %t40, ptr %l4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t50 = trunc i64 48 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i1, ptr %l1, !tbaa !21
  %t57 = xor i1 %t55, true
  %t58 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t53, i1 %t57, ptr %t58)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb63
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 30}
  %t69 = icmp eq i64 %t67, 10
  store i1 %t69, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t85, i32 0, i32 3
  %t87 = load i1, ptr %t86
  store i1 %t87, ptr %l8, !tbaa !21
  br label %bb25
bb24:
  br label %bb38
bb25:
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l51
  br label %bb26
bb26:
  %t92 = load i1, ptr %l51, !tbaa !21
  br i1 %t92, label %bb27, label %bb28
bb27:
  %t93 = load i1, ptr %l8, !tbaa !21
  %t94 = load i1, ptr %l1, !tbaa !21
  %t97 = icmp eq i1 %t93, %t94
  store i1 %t97, ptr %l52, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb29
bb29:
  %t99 = load i1, ptr %l52, !tbaa !21
  br i1 %t99, label %bb30, label %bb31
bb30:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %t100)
  store { i64, ptr } %t102, ptr %l57
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t103 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t103, ptr %l9, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v1, ptr %v1, ptr %t110, { i64, ptr } %t111)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb63
bb38:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb39, label %bb40
bb39:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 30}
  %t121 = icmp eq i64 %t119, 5
  store i1 %t121, ptr %l64, !tbaa !21
  br label %bb40
bb40:
  %t122 = load i1, ptr %l64, !tbaa !21
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126, !range !{i32 0, i32 98}
  store i32 %t127, ptr %l10
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l11, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t137, i32 0, i32 3
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l12, !tbaa !29
  br label %bb43
bb42:
  br label %bb58
bb43:
  %t141 = load i32, ptr %l10, !range !{i32 0, i32 98}
  %t143 = trunc i64 45 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb44, label %bb45
bb44:
  %t146 = load i1, ptr %l1, !tbaa !21
  store i1 %t146, ptr %l75, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb46
bb46:
  %t148 = load i1, ptr %l75, !tbaa !21
  br i1 %t148, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb52
bb48:
  %t149 = load i32, ptr %l10, !range !{i32 0, i32 98}
  %t151 = trunc i64 46 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb49, label %bb50
bb49:
  %t154 = load i1, ptr %l1, !tbaa !21
  %t156 = xor i1 %t154, true
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb51
bb51:
  %t158 = load i1, ptr %l80, !tbaa !21
  store i1 %t158, ptr %l77, !tbaa !21
  br label %bb52
bb52:
  %t159 = load i1, ptr %l77, !tbaa !21
  br i1 %t159, label %bb53, label %bb54
bb53:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load i1, ptr %l1, !tbaa !21
  %t163 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t160, i1 %t162, ptr %t163)
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t167 = load ptr, ptr %l12, !tbaa !29
  %t169 = load i1, ptr %l1, !tbaa !21
  %t170 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t167, i1 %t169, ptr %t170)
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_971e562861b388d3_547076ac47399cf7)
  unreachable
bb63:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_55e43ab8a3145b19_623cb1abd394c54d)
  unreachable
bb12:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 3
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 4
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb8:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp eq i64 %t13, 5
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb12:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp eq i64 %t17, 6
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb16:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 7
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb20:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 8
  br i1 %t27, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb24:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp eq i64 %t29, 9
  br i1 %t31, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb28:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t33, 10
  br i1 %t35, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb32:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t37, 11
  br i1 %t39, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb36:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t41, 12
  br i1 %t43, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb40:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = icmp eq i64 %t45, 13
  br i1 %t47, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d103, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb44:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = icmp eq i64 %t49, 14
  br i1 %t51, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_25d55d46e6c695b2_1c5feb2a345583d6)
  unreachable
bb53:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervBool(ptr %v0, i1 %a0) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  br i1 %a0, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 true, i64 %t5, i64 %t6, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, i32 %t4)
  store %"compiler/check:reflVal" %t8, ptr %l5
  br label %bb4
bb4:
  %t9 = load %"compiler/check:reflVal", ptr %l5
  store %"compiler/check:reflVal" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i1 @compiler_2fcheck_2eregisteredBefore(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:DropHolding", ptr %a0, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp eq i64 %t21, %a1
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp eq i64 %t28, %a2
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2erootGaps(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/check:Gap"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/check:Gap"
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 15
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/check:Gap" %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load %"compiler/check:Gap", ptr %l16
  store %"compiler/check:Gap" %t22, ptr %l5
  %t23 = getelementptr %"compiler/check:Gap", ptr %l5, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t28 = icmp eq i64 %t24, %a1
  br i1 %t28, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = getelementptr %"compiler/check:Gap", ptr %l5, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t31)
  br label %bb10
bb9:
  br label %bb12
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t40 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t40, ptr %l26
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2erootRules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/diag:Said"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"compiler/diag:Said"
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/load:Loader", ptr %t3, i32 0, i32 10
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 12
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 4
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %s1, ptr %t21)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l16
  br label %bb3
bb3:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t25 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t25
  store ptr %t25, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s1, ptr %t28)
  store i64 %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s1, ptr %s1, ptr %t37, i64 %t38)
  store %"compiler/diag:Said" %t41, ptr %l25
  br label %bb9
bb9:
  %t42 = load %"compiler/diag:Said", ptr %l25
  store %"compiler/diag:Said" %t42, ptr %l5
  %t43 = getelementptr %"compiler/diag:Said", ptr %l5, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = getelementptr %"compiler/diag:Said", ptr %l5, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } %t64)
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l4, !tbaa !24
  br label %bb4
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t73, ptr %l37
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l19, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = icmp ne i32 %t68, %t75
  br i1 %t78, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb10
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Seq", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l18
  br label %bb11
bb11:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Seq", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb16:
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_baaa1af575455ed0_90a91bbf0a009424)
  unreachable
bb24:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/check:ctSource"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:ctSource" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/check:ctSource" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/check:ctSource" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/check:ctSource" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:ctSource" %t18, { i64, ptr } %a4, 4
  store %"compiler/check:ctSource" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ctSource", ptr %rv
  ret %"compiler/check:ctSource" %rr
}

define dso_local %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:errNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:errNarrow" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:errNarrow" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/check:errNarrow" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:errNarrow" %t14, i1 %a3, 3
  store %"compiler/check:errNarrow" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errNarrow", ptr %rv
  ret %"compiler/check:errNarrow" %rr
}

define dso_local %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10) #0 {
entry:
  %rv = alloca %"compiler/check:laneNode"
  br label %start
start:
  br label %bb0
bb0:
  %t24 = insertvalue %"compiler/check:laneNode" undef, i64 %a0, 0
  %t26 = insertvalue %"compiler/check:laneNode" %t24, i32 %a1, 1
  %t28 = insertvalue %"compiler/check:laneNode" %t26, %"compiler/source:Span" %a2, 2
  %t30 = insertvalue %"compiler/check:laneNode" %t28, %"compiler/source:Span" %a3, 3
  %t32 = insertvalue %"compiler/check:laneNode" %t30, i64 %a4, 4
  %t34 = insertvalue %"compiler/check:laneNode" %t32, i64 %a5, 5
  %t36 = insertvalue %"compiler/check:laneNode" %t34, i64 %a6, 6
  %t38 = insertvalue %"compiler/check:laneNode" %t36, ptr %a7, 7
  %t40 = insertvalue %"compiler/check:laneNode" %t38, i32 %a8, 8
  %t42 = insertvalue %"compiler/check:laneNode" %t40, i64 %a9, 9
  %t44 = insertvalue %"compiler/check:laneNode" %t42, i32 %a10, 10
  store %"compiler/check:laneNode" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneNode", ptr %rv
  ret %"compiler/check:laneNode" %rr
}

define dso_local %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/check:payloadItem"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:payloadItem" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/check:payloadItem" %t6, ptr %a1, 1
  store %"compiler/check:payloadItem" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:payloadItem", ptr %rv
  ret %"compiler/check:payloadItem" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d1 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"an extern fn's call" }>, align 8
@.d2 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a call through a function value" }>, align 8
@.d3 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a call through an any" }>, align 8
@.d4 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"a call of what the compiler supplies" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"no call of a function" }>, align 8
@.d6 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"an export fn's call" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a constructor's call" }>, align 8
@.d9 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a lambda's call" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a case" }>, align 8
@.d11 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Errors" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d23 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a member reflection reads through a type's name" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inf" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"NaN" }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Epsilon" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"SmallestNormal" }>, align 8
@.d30 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"a limit of the number type" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"From" }>, align 8
@.d32 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the raw value's reverse" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"a builder " }>, align 8
@.d38 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d39 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d40 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"OutOfRange" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d44 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Default" }>, align 8
@.d52 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"Name, Type, Offset, BitOffset, Bits, Of, Attr and HasAttr" }>, align 8
@.d53 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"Name, Fields, Attr and HasAttr" }>, align 8
@.d54 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"Name, Type, HasDefault, Default, Attr and HasAttr" }>, align 8
@.d55 = private constant <{ i64, [123 x i8] }> <{ i64 0, [123 x i8] c"Name, Type, Params, Results, Errors, Attr, HasAttr, NoReturn, Exported, Extern, Commutes and G42's facts - and it is called" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"field" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d60 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"function" }>, align 8
@.d61 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d63 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d67 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d68 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'++'" }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'--'" }>, align 8
@.d70 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"instantiated here" }>, align 8
@.d71 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", with " }>, align 8
@.d72 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define internal i1 @olang_lambda_75(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d78 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/enums" }>, align 8
@.d79 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"CaseError" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"WrongCase" }>, align 8
@.d81 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"an increment as a value (S3a)" }>, align 8
@.d82 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'is' with a type (E32)" }>, align 8
@.d83 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'as' (E32)" }>, align 8
@.d84 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a generic name as a value" }>, align 8
@.d85 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a nested row (E21)" }>, align 8
@.d86 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a comprehension (E27)" }>, align 8
@.d87 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a lambda (D16)" }>, align 8
@.d88 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a match value (S12b)" }>, align 8
@.d89 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a range outside a for (S9b)" }>, align 8
@.d90 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"'default' outside a call (E14a)" }>, align 8
@.d91 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"an index of this kind" }>, align 8
@.d92 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"an expression of this kind" }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d94 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d95 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d98 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d99 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d102 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d103 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_fe14b63572f1977b_411de5df8083206f = external constant [0 x i8]
@olang_loc_980c9dc24d8ab357_bac7a576dce6b97b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f6ac6f37bd028998_7777cf96519f6a94 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ewholeTemp(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_943b293e8fd49f1f_6252e979531a6d2b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e = external constant [0 x i8]
@olang_loc_4f357d5c515ec460_c39407ade47891c4 = external constant [0 x i8]
@olang_loc_5259ca87fe3b4871_3fe667824d420b5 = external constant [0 x i8]
@olang_loc_7a179da39a9781e9_720543b731edd2ed = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %v0, i64 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_54e68041531f6906_51860f3f569bf3d2 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2eisCallExpr(ptr %v0, ptr %a0)
@olang_loc_f8af5d5c89bab054_38683d7e2233a658 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_9f409528a62be557_96e98ebb70e4ac13 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1bc36e5fea83eb2f_c65858cd7310966b = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
@olang_loc_2bda502508e1b1d_a3083ba563ab0481 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_48c434cc052a730a_3ea1b318a5aaa0d6 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7aa3345d2beba7fc_151c01b23d5f0fc0 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
@olang_loc_4a75f471ea948b24_16ed41ec7c1e5db8 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d04702acd6c67beb_c6baeec7be1e7af7 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_57a7d7e6d1174c7c_73fda2027ad2ad8 = external constant [0 x i8]
@olang_loc_fd3b2969d106d871_acdc32576a39b9ed = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fcheck_2elocalIdOf(ptr %v0, ptr %a0)
@olang_loc_9336e0175c2e9c6a_aabb9d2690ac9706 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_12a21cc2c4eb057_a597a544841c60b = external constant [0 x i8]
@olang_loc_286fe13485cd942f_1c0d0a1e63f5e7b3 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_5ab97e381db75496_a4ed3933adca62ca = external constant [0 x i8]
declare { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fcheck_2elistName(ptr %v0, i64 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNotList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_fce01e404a5d04ab_bd3fcfdbd155739f = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_1a03149f0250e548_14220af7ccd85b74 = external constant [0 x i8]
@olang_loc_f003e05343083a19_c7eedaa93b775a5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c04d5f47d2250f6_3417b2e0d095e072 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_bddcfdd9cfe1623c_a2c83caf107f9198 = external constant [0 x i8]
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuildersOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoBuilder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:payloadItem" %a1)
@olang_loc_99a2219cf20f55d9_bdfeae2ff747ebc5 = external constant [0 x i8]
@olang_loc_aa9d1041871ddc08_900eaa132351bb14 = external constant [0 x i8]
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_24dda45681d8cee1_6133aaee564c4ee5 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
@olang_loc_f10316e290a7e1b9_b7814005b7d82bcd = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_320f9d8592ce2991_bf25bbc6142ecf8d = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflVal" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6fa12bf18c08968_7f63ef0109416d3c = external constant [0 x i8]
@olang_loc_366830190f407939_a82d5f1c611378ed = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
@olang_loc_1e97160fa78b00b5_b2a2d0ea90892ee9 = external constant [0 x i8]
@olang_loc_de2cb745672f71c4_3d4b81a63c3c3818 = external constant [0 x i8]
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:roOrigin" %a2)
@olang_loc_9ed68493f04b873b_45e1787ed2cd21af = external constant [0 x i8]
@olang_loc_207369a2ec6f9fee_7129d1e6d10224a2 = external constant [0 x i8]
@olang_loc_3d307812d0489f63_908317b964e2b157 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_fe73ad2ef66395ad_6bb388f528f40629 = external constant [0 x i8]
@olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
@olang_loc_729de81d3b051823_7dce08f61f50e4bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_feabd87b4a742d50_a08e759c84965044 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
@olang_loc_cc3b7a6e318210b6_464c855cb4a991aa = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_894a72349cd7ef67_30624e129d4b77a3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %v0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %a0)
declare { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__He0d1b669a6d0fad4ef2d0863356e160c(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, %"compiler/check:heldCand" %a1)
@olang_loc_b35f41bb006554d6_a1d87dcad76a5f72 = external constant [0 x i8]
@olang_loc_943678799cf3b8f7_240de00f13c53f3 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_17791ca4bfbb451a_6d701f0037462966 = external constant [0 x i8]
declare %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5)
@olang_loc_d149dd778abfbb99_ce32867ac8840ced = external constant [0 x i8]
@olang_loc_69063e233c23bbc5_4e0c3b9f00520e59 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_971e562861b388d3_547076ac47399cf7 = external constant [0 x i8]
@olang_loc_55e43ab8a3145b19_623cb1abd394c54d = external constant [0 x i8]
@olang_loc_25d55d46e6c695b2_1c5feb2a345583d6 = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_db336c98c3d140f2_e2aca3dd623cb216 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
@olang_loc_baaa1af575455ed0_90a91bbf0a009424 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
